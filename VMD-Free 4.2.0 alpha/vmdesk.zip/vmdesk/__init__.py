bl_info = {
    "name" : "vmdesk-Free",
    "author" : "Iiispace",
    "version" : (4, 2, 0),
    "blender" : (4, 0),
    "location" : "View3d > Tool",
    "warning" : "",
    "description" : "Requirement: blender 4.0, 4.1, 4.2",
    "wiki_url" : "",
    "category" : "3D View",
}

if "bpy" in locals():

    # from importlib import reload
    m.RELOAD_STATE[0] = True

import bpy

from bpy.utils import register_class, unregister_class
from bpy.props import (
    BoolProperty,
    IntProperty,
    FloatProperty,
    StringProperty,
    FloatVectorProperty,
    PointerProperty)
from bpy.types import (
    BlendData,
    Object,
    NodeTreeInterfaceSocket,
    NodeTreeInterfaceSocketColor,
    NodeTreeInterfaceSocketRotation)

from . handle import load_post, load_pre, bl_unload, BL_INFO
from . util.const import FLOAT_min, FLOAT_max

## /* clear_repeat
from .  import m

# <<< 1forfile (_reg_,, $lambda _file_, _cls_: f'from . {_file_[1 : _file_.rfind(chr(92))].replace(".py", ""
#     ).replace(chr(92), ".")} import {_file_[_file_.rfind(chr(92)) + 1 :].replace(".py", "")}\n'$)
from .  import npanel
from .  import prefs
from .  import userops
from . utilbl import ops
# >>>
## */

IS_UNREG = [False]
ADDON_KEYMAPS = []


def register():

    #|
    for k, e in bl_info.items(): BL_INFO[k] = e

    # <<< 1forfile (_reg_,, $lambda _file_, _cls_: f'register_class({_file_[_file_.rfind(
    #     chr(92)) + 1 :].replace(".py", "")}.{_cls_})\n'$)
    register_class(m.Admin)
    register_class(npanel.VmdPanel)
    register_class(npanel.VmdPanelTemp)
    register_class(npanel.VmdPanelGeneral)
    register_class(npanel.VmdPanelSize)
    register_class(npanel.VmdPanelColor)
    register_class(npanel.VmdPanelModifierEditor)
    register_class(npanel.VmdPanelSettingEditor)
    register_class(prefs.PrefsModifierEditor)
    register_class(prefs.PrefsSettingEditor)
    register_class(prefs.PrefsKey)
    register_class(prefs.PrefsSize)
    register_class(prefs.PrefsColor)
    register_class(prefs.PrefsTemp)
    register_class(prefs.Prefs)
    register_class(userops.OpsEditor)
    register_class(userops.OpsLoadFactory)
    register_class(userops.OpsReloadIcon)
    register_class(userops.OpsReloadFont)
    register_class(userops.OpsUiScale)
    register_class(ops.OpInternal)
    register_class(ops.OpBevelProfile)
    register_class(ops.OpFalloffCurve)
    register_class(ops.OpScanFile)
    register_class(ops.OpScanFolder)
    # >>>

    # ---------------------------------------------------------------------------------------------------------












    # ---------------------------------------------------------------------------------------------------------

    handlers = bpy.app.handlers
    if load_post not in handlers.load_post: handlers.load_post.append(load_post)
    if load_pre not in handlers.load_pre: handlers.load_pre.append(load_pre)
    # if local_undo.after_undo not in bpy.app.handlers.undo_post:
    #     bpy.app.handlers.undo_post.append(local_undo.after_undo)
    # if local_undo.before_undo not in bpy.app.handlers.undo_pre:
    #     bpy.app.handlers.undo_pre.append(local_undo.before_undo)
    # if local_undo.after_redo not in bpy.app.handlers.redo_post:
    #     bpy.app.handlers.redo_post.append(local_undo.after_redo)
    # if local_undo.before_redo not in bpy.app.handlers.redo_pre:
    #     bpy.app.handlers.redo_pre.append(local_undo.before_redo)
    BlendData.link_mds = {}
    Object.vmd_offset = FloatVectorProperty(name="Distance", options=set(), subtype="TRANSLATION", unit="LENGTH")
    NodeTreeInterfaceSocket.vmd_is_radian = BoolProperty(name="Is Radian", options=set())
    NodeTreeInterfaceSocketColor.min_value = FloatProperty(default=0.0, options=set())
    NodeTreeInterfaceSocketColor.max_value = FloatProperty(default=FLOAT_max, options=set())
    NodeTreeInterfaceSocketColor.subtype = StringProperty(default="NONE", options=set())
    NodeTreeInterfaceSocketRotation.min_value = FloatProperty(default=FLOAT_min, options=set())
    NodeTreeInterfaceSocketRotation.max_value = FloatProperty(default=FLOAT_max, options=set())
    NodeTreeInterfaceSocketRotation.subtype = StringProperty(default="EULER", options=set())

    # NodeSocketInterfaceColor.array_length = IntProperty(default=4, options=set())
    # NodeSocketInterfaceColor.step = FloatProperty(default=0.3, options=set())
    # NodeSocketInterfaceColor.unit = StringProperty(default="NONE", options=set())
    # NodeSocketInterfaceColor.hard_min = FloatProperty(default=0.0, options=set())
    # NodeSocketInterfaceColor.hard_max = FloatProperty(default=1.0, options=set())

    # reg_keymap()

    if IS_UNREG[0] is True:

        m.RELOAD_STATE[0] = True
    #|

def unregister():

    #|
    # <<< 1forfile (_reg_,, $lambda _file_, _cls_: f'unregister_class({_file_[_file_.rfind(
    #     chr(92)) + 1 :].replace(".py", "")}.{_cls_})\n'$)
    unregister_class(m.Admin)
    unregister_class(npanel.VmdPanel)
    unregister_class(npanel.VmdPanelTemp)
    unregister_class(npanel.VmdPanelGeneral)
    unregister_class(npanel.VmdPanelSize)
    unregister_class(npanel.VmdPanelColor)
    unregister_class(npanel.VmdPanelModifierEditor)
    unregister_class(npanel.VmdPanelSettingEditor)
    unregister_class(prefs.PrefsModifierEditor)
    unregister_class(prefs.PrefsSettingEditor)
    unregister_class(prefs.PrefsKey)
    unregister_class(prefs.PrefsSize)
    unregister_class(prefs.PrefsColor)
    unregister_class(prefs.PrefsTemp)
    unregister_class(prefs.Prefs)
    unregister_class(userops.OpsEditor)
    unregister_class(userops.OpsLoadFactory)
    unregister_class(userops.OpsReloadIcon)
    unregister_class(userops.OpsReloadFont)
    unregister_class(userops.OpsUiScale)
    unregister_class(ops.OpInternal)
    unregister_class(ops.OpBevelProfile)
    unregister_class(ops.OpFalloffCurve)
    unregister_class(ops.OpScanFile)
    unregister_class(ops.OpScanFolder)
    # >>>

    # ---------------------------------------------------------------------------------------------------------












    # ---------------------------------------------------------------------------------------------------------

    handlers = bpy.app.handlers
    if load_post in handlers.load_post: handlers.load_post.remove(load_post)
    if load_pre in handlers.load_pre: handlers.load_pre.remove(load_pre)
    # if local_undo.after_undo in bpy.app.handlers.undo_post:
    #     bpy.app.handlers.undo_post.remove(local_undo.after_undo)
    # if local_undo.before_undo in bpy.app.handlers.undo_pre:
    #     bpy.app.handlers.undo_pre.remove(local_undo.before_undo)
    # if local_undo.after_redo in bpy.app.handlers.redo_post:
    #     bpy.app.handlers.redo_post.remove(local_undo.after_redo)
    # if local_undo.before_redo in bpy.app.handlers.redo_pre:
    #     bpy.app.handlers.redo_pre.remove(local_undo.before_redo)

    bl_unload()
    # unreg_keymap()
    m.P = None
    m.ADMIN = None
    IS_UNREG[0] = True
    #|

def reg_keymap():
    #|
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        m.cls_ops_kms = [
            mo.OP_MO,
            dr_ed.OP_DR,
            mesh_ed.OP_MESH,
            setting_ed.OP_SETTING,
            light_tool_ed.OP_LIGHT_TOOL,
        ]
        r = 3
        for cls in m.cls_ops_kms:
            km = wm.keyconfigs.addon.keymaps.new(name='Window')
            kmi = km.keymap_items.new(cls.bl_idname, type=f'F1{r}', value='PRESS')
            kmi.properties.use_pos = True
            ADDON_KEYMAPS.append((km, kmi))
            r += 1
    #|

def unreg_keymap():
    #|
    for km, kmi in ADDON_KEYMAPS:
        km.keymap_items.remove(kmi)
    ADDON_KEYMAPS.clear()
    #|

if __name__ == "__main__":  register()
