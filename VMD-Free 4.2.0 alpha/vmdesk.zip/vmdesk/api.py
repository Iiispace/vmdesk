import bpy

from bpy.types import NodesModifier

attr_NodesModifier_bake_directory = "bake_directory" if "bake_directory" in NodesModifier.bl_rna.properties else "simulation_bake_directory"
