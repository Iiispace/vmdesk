import bpy




## _file_ ##
def _import_():
    # //* 0blocks_ModifierEditor_import_blg
    # *// =|
    # <<< 1copy (0blocks_ModifierEditor_import_blg,, $$)
    global FONT0,D_SIZE
    # >>>
    # <<< 1copy (0blocks_ModifierEditor_import_blg,, ${'global': 'from ... utilbl.blg import'}$)
    from ... utilbl.blg import FONT0,D_SIZE
    # >>>

    # //* 0blocks_ModifierEditor_import_m
    # *// =|
    # <<< 1copy (0blocks_ModifierEditor_import_m,, $$)
    global P,Admin,upd_size
    # >>>
    # <<< 1copy (0blocks_ModifierEditor_import_m,, ${'global': 'from ... m import'}$)
    from ... m import P,Admin,upd_size
    # >>>
    #|
