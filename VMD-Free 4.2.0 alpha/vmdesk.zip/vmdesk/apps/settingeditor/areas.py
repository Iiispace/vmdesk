import bpy, base64
from blf import size as blfSize
from blf import color as blfColor
from blf import position as blfPos
from blf import draw as blfDraw
from blf import dimensions as blfDimen
from gpu.state import blend_set
from math import floor
from types import SimpleNamespace

from ... utilbl import blg
from ... handle import BL_INFO
from ... prefs import OVERRIDE_SUBTYPES, PrefsSize
from ... util.types import (
    RnaSubtab,
    RnaButton,
    RnaString,
    RnaEnum,
    RnaBool,
    RnaFloat,
    LocalHistory,
    HistoryValue,
    r_collection_create)
from ... util.com import r_mouse_y_index, r_filter_function, r_tuple
from ... util.filtexp import evalfiltexp
from ... win import Head
from ... area import AreaBlockTab, StructAreaModal
from ... block import (
    BlockUtil,
    BlockUtils,
    BlockPref,
    BlockSubtab,
    BlockSep,
    BlockFull,
    ButtonSep,
    ButtonGroup,
    ButtonGroupAlignL,
    ButtonGroupAlignLR,
    ButtonGroupFull,
    ButtonGroupTwo,
    ButtonFn,
    ButtonFnImgHover,
    ButtonString,
    ButtonStringXYRead,
    ButtonStringPref,
    ButtonStringMatchButton,
    ButtonFloatPref,
    ButtonBoolPref,
    ButtonBoolCall,
    ButtonEnumPref,
    ButtonFnImgList,
    ButtonFnBlf,
    BlockPrefNoInfo,
    PREF_HISTORY,
    Title)
from ... keysys import (
    kill_evt_except,
    MOUSE,
    EVT_TYPE,
    TRIGGER,
    TIME_KEYS,
    r_end_trigger,
    KeyMap,
    KEYMAPS,
    write_keytype,
    write_keyvalue,
    write_keyendvalue,
    write_keyexact,
    write_keyduration,
    write_calc_exp,
    ENUMS_keymap_value)
from ... utilbl.blg import (
    Blf,
    BlfColor,
    BlfClipColor,
    Scissor,
    GpuBox,
    GpuRim,
    GpuBox_area,
    GpuBox_box_setting_list_bg,
    GpuRimAreaHover,
    GpuRimBlfbuttonTextHover,
    GpuRimSettingTabActive,
    report,
    decoReport,
    reload_gpu_texture)

callback_ids_ModifierEditor = {
    "area_list_inner",
    "area_rowlen_obj",
    "area_rowlen_mds",
    "area_widthfac_tab",
    "area_widthfac_filter"}
callback_ids_SettingEditor = {
    "area_height"}


class AreaSettingHeader(StructAreaModal):
    __slots__ = (
        'w',
        'u_draw',
        'box_area',
        'buttons',
        'local_tabhistory',
        'header_media_text',
        'focus_element')

    ITEM_IDS = {
        'save': 0,
        'search': 1,
        'back': 2,
        'next': 3,
        'up': 4,
        'text': 5}

    def __init__(self, w, LL, RR, BB, TT):
        self.w = w
        self.u_draw = self.i_draw
        self.header_media_text = ""

        self.box_area = GpuBox_area()
        # box_hover = GpuImg_area_icon_hover()

        self.buttons = [
            ButtonFnImgHover(self, RNA_header_button, save_pref, 'GpuImg_save'),
            ButtonFnImgHover(self, RNA_header_button, self.evt_tab_search, 'GpuImg_search'),
            ButtonFnImgHover(self, RNA_header_button, self.evt_tab_back, 'GpuImg_arrow_left',
                'GpuImg_arrow_left_disable'),
            ButtonFnImgHover(self, RNA_header_button, self.evt_tab_next, 'GpuImg_arrow_right',
                'GpuImg_arrow_right_disable'),
            ButtonFnImgHover(self, RNA_header_button, self.evt_tab_up, 'GpuImg_arrow_up',
                'GpuImg_arrow_up_disable'),
            ButtonStringSettingHeader(self, RNA_header_media_text, self),
        ]
        self.buttons[2].dark()
        self.buttons[3].dark()
        self.buttons[4].dark()
        self.upd_size(LL, RR, BB, TT)
        #|

    def upd_size(self, LL, RR, BB, TT):
        self.box_area.LRBT_upd(LL, RR, BB, TT)
        d0 = SIZE_dd_border[0]
        widget_rim = SIZE_border[3]
        h = SIZE_widget[0]
        d1 = floor(h / 5)

        LL += d0
        TT -= d0
        BB += d0
        T = TT - widget_rim
        B = BB + widget_rim

        L = LL + widget_rim
        R = L + h
        buttons = self.buttons
        B = buttons[0].init_bat(L, R, T)
        L = R + h
        R = L + h
        B = buttons[1].init_bat(L, R, T)
        L = R + d1 + d1
        R = L + h
        B = buttons[2].init_bat(L, R, T)
        L = R
        R = L + h
        B = buttons[3].init_bat(L, R, T)
        L = R + d1
        R = L + h
        B = buttons[4].init_bat(L, R, T)
        buttons[5].init_bat(R + d1, RR - d0, TT)
        #|

    def r_focus_element(self):
        for e in self.buttons:
            if e.inside(MOUSE): return e
        return None

    def history_init(self):

        self.local_tabhistory = LocalHistory(self, P.undo_steps_local, self.r_push_tabitem)
        #|
    def r_push_tabitem(self):
        return self.w.active_tab
        #|
    def to_tabhistory_index(self, index):
        Admin.REDRAW()
        w = self.w
        e = self.local_tabhistory.array[index]
        w.active_tab = e
        a = w.areas[
            # <<< 1copy (0ed_SettingEditor_AREAIND_data,, $$)
            2
            # >>>
        ]
        a.active_tab = e
        a.init_tab(e, push=False)
        #|
    def tabhistory_push(self):
        self.local_tabhistory.push()
        self.update_button_darklight()
        self.buttons[AreaSettingHeader.ITEM_IDS['text']].init_buttons(self.w.active_tab)
        #|
    def evt_tab_back(self):
        Admin.REDRAW()
        kill_evt_except()
        his = self.local_tabhistory
        if his.index == 0:

            return

        his.index -= 1
        self.to_tabhistory_index(his.index)
        self.update_button_darklight()
        self.buttons[AreaSettingHeader.ITEM_IDS['text']].init_buttons(self.w.active_tab)
        self.w.upd_data()
        #|
    def evt_tab_next(self):
        Admin.REDRAW()
        kill_evt_except()
        his = self.local_tabhistory
        if his.index + 1 >= len(his.array):

            return

        his.index += 1
        self.to_tabhistory_index(his.index)
        self.update_button_darklight()
        self.buttons[AreaSettingHeader.ITEM_IDS['text']].init_buttons(self.w.active_tab)
        self.w.upd_data()
        #|
    def evt_tab_up(self):
        Admin.REDRAW()
        kill_evt_except()
        current_tab = self.w.active_tab
        if not current_tab: return
        if len(current_tab) == 1:

            return

        self.w.active_tab = current_tab[: -1]
        self.w.upd_data()
        #|
    def evt_tab_search(self):
        Admin.REDRAW()
        kill_evt_except()
        self.w.active_tab = ("search",)
        self.w.upd_data()
        a = self.w.areas[
            # <<< 1copy (0ed_SettingEditor_AREAIND_data,, $$)
            2
            # >>>
        ]
        a.items[0].buttons[0].to_dropdown()
        #|

    def dxy(self, dx, dy):
        self.box_area.dxy_upd(dx, dy)
        for e in self.buttons: e.dxy(dx, dy)
        #|

    def i_draw(self):
        blend_set('ALPHA')
        self.box_area.bind_draw()
        for e in self.buttons: e.draw_box()

        for e in self.buttons: e.draw_blf()
        #|

    def update_button_darklight(self):
        his_index = self.local_tabhistory.index
        if his_index > 0:
            self.buttons[AreaSettingHeader.ITEM_IDS["back"]].light()
        else:
            self.buttons[AreaSettingHeader.ITEM_IDS["back"]].dark()
        if his_index == len(self.local_tabhistory.array) - 1:
            self.buttons[AreaSettingHeader.ITEM_IDS["next"]].dark()
        else:
            self.buttons[AreaSettingHeader.ITEM_IDS["next"]].light()

        if self.w.active_tab and len(self.w.active_tab) != 1:
            self.buttons[AreaSettingHeader.ITEM_IDS["up"]].light()
        else:
            self.buttons[AreaSettingHeader.ITEM_IDS["up"]].dark()
        #|
    def upd_data(self):
        self.update_button_darklight()
        #|
    #|
    #|

class AreaSettingList(StructAreaModal):
    __slots__ = (
        'w',
        'u_draw',
        'items',
        'box_area',
        'box_background',
        'box_hover',
        'box_active',
        'active_tab',
        'focus_element')

    ITEM_IDS = {
        'system': 0,
        'size': 1,
        'personalization': 2,
        'apps': 3,
        'keymap': 4}

    def __init__(self, w, LL, TT):
        #|
        self.w = w
        self.u_draw = self.i_draw

        self.box_area = GpuBox_area()
        self.box_background = GpuBox_box_setting_list_bg()
        self.box_hover = GpuRimAreaHover()
        self.box_active = GpuRimSettingTabActive()
        self.box_active.upd()
        self.active_tab = None

        bufn = self.evt_button
        f0 = self.button_inside_evt_callback
        f1 = self.button_outside_evt_callback
        self.items = [
            ButtonFnImgList(self, None, lambda: bufn('system'),
                'GpuImg_settings_system', 'System', None, f0, f1),
            ButtonFnImgList(self, None, lambda: bufn('size'),
                'GpuImg_settings_size', 'Size', None, f0, f1),
            ButtonFnImgList(self, None, lambda: bufn('personalization'),
                'GpuImg_settings_personalization', 'Personalization', None, f0, f1),
            ButtonFnImgList(self, None, lambda: bufn('apps'),
                'GpuImg_settings_apps', 'Apps', None, f0, f1),
            ButtonFnImgList(self, None, lambda: bufn('keymap'),
                'GpuImg_settings_keymap', 'Keymap', None, f0, f1),
        ]
        self.upd_size(LL, TT)
        #|

    def upd_size(self, LL, TT):
        box_area = self.box_area
        d0 = SIZE_dd_border[0]
        scissor_win = self.w.scissor
        h = SIZE_widget[0]
        outer = SIZE_setting_list_border[0]

        L0 = LL + d0
        T0 = TT - d0
        B = T0 - outer

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        ButtonFnImgList.set_offset(L0, D_SIZE['font_main_dy'], outer, h)
        gap = SIZE_setting_list_border[1]
        R = ButtonFnImgList.BLF_X + round(
            blfDimen(FONT0, "Personalization")[0]) + ButtonFnImgList.BLF_OFFSET_Y + outer

        for e in self.items: B = e.init_bat_dimen(L0, R, B) - gap

        B = B + gap - outer
        self.box_background.LRBT_upd(L0, R, B, T0)
        box_area.LRBT_upd(LL, R + d0, B - d0, TT)
        self.box_hover.LRBT_upd(0, 0, 0, 0, 0)
        # <<< 1copy (0areas_AreaSettingList_update_box_active,, $$)
        self.active_tab = self.w.active_tab
        if self.active_tab and self.active_tab[0] != "search":
            tab = self.active_tab[0]
            widget_rim = SIZE_border[3]
            e = self.items[AreaSettingList.ITEM_IDS[self.active_tab[0]]].box_button
            self.box_active.LRBT_upd(self.box_area.L, self.box_area.R,
                e.B - widget_rim, e.T + widget_rim, widget_rim)
        else:
            if self.box_active.d != 0: self.box_active.LRBT_upd(0, 0, 0, 0, 0)
        # >>>
        #|

    def r_focus_element(self):
        for e in self.items:
            if e.inside(MOUSE): return e
        return None
        #|

    def dxy(self, dx, dy):
        self.box_area.dxy_upd(dx, dy)
        self.box_background.dxy_upd(dx, dy)
        self.box_hover.dxy_upd(dx, dy)
        self.box_active.dxy_upd(dx, dy)

        for e in self.items: e.dxy(dx, dy)
        #|

    def i_draw(self):
        blend_set('ALPHA')
        self.box_area.bind_draw()
        self.box_background.bind_draw()
        self.box_active.bind_draw()
        self.box_hover.bind_draw()

        for e in self.items: e.draw_box()

        blfColor(FONT0, *COL_box_setting_list_fg)
        blfSize(FONT0, D_SIZE['font_main'])
        for e in self.items:
            o = e.blf_value
            blfPos(FONT0, o.x, o.y, 0)
            blfDraw(FONT0, o.text)
        #|

    def evt_button(self, identifier):

        Admin.REDRAW()
        self.w.active_tab = (identifier,)
        self.w.areas[
            # <<< 1copy (0ed_SettingEditor_AREAIND_data,, $$)
            2
            # >>>
        ].init_tab(self.w.active_tab, evtkill=False)
        self.w.upd_data()
        #|
    def button_inside_evt_callback(self, button):
        widget_rim = SIZE_border[3]
        e = button.box_button
        self.box_hover.LRBT_upd(self.box_area.L, self.box_area.R,
            e.B - widget_rim, e.T + widget_rim, widget_rim)
        #|
    def button_outside_evt_callback(self, button):
        if self.box_hover.d != 0: self.box_hover.LRBT_upd(0, 0, 0, 0, 0)
        #|

    def upd_data(self):
        if self.active_tab == self.w.active_tab: return

        # /* 0areas_AreaSettingList_update_box_active
        self.active_tab = self.w.active_tab
        if self.active_tab and self.active_tab[0] != "search":
            tab = self.active_tab[0]
            widget_rim = SIZE_border[3]
            e = self.items[AreaSettingList.ITEM_IDS[self.active_tab[0]]].box_button
            self.box_active.LRBT_upd(self.box_area.L, self.box_area.R,
                e.B - widget_rim, e.T + widget_rim, widget_rim)
        else:
            if self.box_active.d != 0: self.box_active.LRBT_upd(0, 0, 0, 0, 0)
        # */
    #|
    #|

class AreaBlockTabSettingEditor(AreaBlockTab):
    __slots__ = ()
    about = ""

    def tabhistory_push(self): self.w.areas[0].tabhistory_push()

    def init_tab_search(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_SettingEditor.is_fold_search
        self.items[:] = [BlockPrefSearchHead(self)]
        #|

    def init_tab_system(self):

        rnas = RNAS["system"]

        self.items[:] = [
            BlockSubtab(self, rnas["display"], lambda: self.init_tab(("system", "display"))),
            BlockSubtab(self, rnas["control"], lambda: self.init_tab(("system", "control"))),
            BlockSubtab(self, rnas["menu"], lambda: self.init_tab(("system", "menu"))),
            BlockSubtab(self, rnas["expression"], lambda: self.init_tab(("system", "expression"))),
            BlockSubtab(self, rnas["library"], lambda: self.init_tab(("system", "library"))),
            BlockSubtab(self, rnas["all_settings"], lambda: self.init_tab(("system", "all_settings"))),
            BlockSubtab(self, rnas["about"], lambda: self.init_tab(("system", "about"))),
        ]
        #|
    def init_tab_system_display(self):
        self.items[:] = [
            BlockPref(self, P_BL_RNA_PROPS["sys_auto_off"], P),
            BlockPref(self, P_BL_RNA_PROPS["show_length_unit"], P),
            BlockPref(self, P_BL_RNA_PROPS["win_check_overlap"], P),
            BlockPref(self, P_BL_RNA_PROPS["win_overlap_offset"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_case"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_whole_word"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_end"], P),
            BlockPref(self, P_BL_RNA_PROPS["cursor_beam_time"], P),
            BlockPref(self, P_BL_RNA_PROPS["use_select_all"], P),
            BlockPref(self, P_BL_RNA_PROPS["use_py_exp"], P),
            BlockPref(self, P_BL_RNA_PROPS["show_rm_keymap"], P),
            BlockPref(self, P_BL_RNA_PROPS["format_float"], P),
            BlockPref(self, P_BL_RNA_PROPS["format_hex"], P),
            BlockPref(self, P_BL_RNA_PROPS["cursor_picker"], P),
        ]
        #|
    def init_tab_system_control(self):
        self.items[:] = [
            BlockPref(self, P_BL_RNA_PROPS["lock_win_size"], P),
            BlockPref(self, P_BL_RNA_PROPS["th_drag"], P),
            BlockPref(self, P_BL_RNA_PROPS["th_double_click"], P),
            BlockPref(self, P_BL_RNA_PROPS["win_check_overlap"], P),
            BlockPref(self, P_BL_RNA_PROPS["win_overlap_offset"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_case"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_whole_word"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_end"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_autopan_active"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_adaptive_selection"], P),
            BlockPref(self, P_BL_RNA_PROPS["use_select_all"], P),
            BlockPref(self, P_BL_RNA_PROPS["pan_invert"], P),
            BlockPref(self, P_BL_RNA_PROPS["scroll_distance"], P),
            BlockPref(self, P_BL_RNA_PROPS["valbox_drag_fac_int"], P),
            BlockPref(self, P_BL_RNA_PROPS["valbox_drag_fac_float"], P),
            BlockPref(self, P_BL_RNA_PROPS["button_repeat_time"], P),
            BlockPref(self, P_BL_RNA_PROPS["button_repeat_interval"], P),
            BlockPref(self, P_BL_RNA_PROPS["use_py_exp"], P),
            BlockPref(self, P_BL_RNA_PROPS["adaptive_rm_output"], P),
            BlockPref(self, P_BL_RNA_PROPS["undo_steps_local"], P),
            BlockPref(self, P_BL_RNA_PROPS["anim_filter"], P),
            BlockPref(self, P_BL_RNA_PROPS["animtime_filter"], P),
        ]
        #|
    def init_tab_system_menu(self):
        self.items[:] = [
            BlockPref(self, P_BL_RNA_PROPS["show_length_unit"], P),
            BlockPref(self, P_BL_RNA_PROPS["lock_win_size"], P),
            BlockPref(self, P_BL_RNA_PROPS["win_check_overlap"], P),
            BlockPref(self, P_BL_RNA_PROPS["win_overlap_offset"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_case"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_whole_word"], P),
            BlockPref(self, P_BL_RNA_PROPS["filter_match_end"], P),
            BlockPref(self, P_BL_RNA_PROPS["cursor_beam_time"], P),
            BlockPref(self, P_BL_RNA_PROPS["use_select_all"], P),
            BlockPref(self, P_BL_RNA_PROPS["pan_invert"], P),
            BlockPref(self, P_BL_RNA_PROPS["scroll_distance"], P),
            BlockPref(self, P_BL_RNA_PROPS["valbox_drag_fac_int"], P),
            BlockPref(self, P_BL_RNA_PROPS["valbox_drag_fac_float"], P),
            BlockPref(self, P_BL_RNA_PROPS["button_repeat_time"], P),
            BlockPref(self, P_BL_RNA_PROPS["button_repeat_interval"], P),
            BlockPref(self, P_BL_RNA_PROPS["use_py_exp"], P),
            BlockPref(self, P_BL_RNA_PROPS["show_rm_keymap"], P),
            BlockPref(self, P_BL_RNA_PROPS["adaptive_rm_output"], P),
            BlockPref(self, P_BL_RNA_PROPS["format_float"], P),
            BlockPref(self, P_BL_RNA_PROPS["format_hex"], P),
        ]
        #|
    def init_tab_system_expression(self):
        self.items[:] = [r_block_calc_exp(self)]
        #|
    def init_tab_system_library(self):
        self.items[:] = [
            r_block_md_lib_refresh(self),
            r_block_md_lib_filepath(self),
            BlockPref(self, P_BL_RNA_PROPS["md_lib_filter"], P),
            BlockPref(self, P_BL_RNA_PROPS["md_lib_method"], P),
            BlockPref(self, P_BL_RNA_PROPS["md_lib_use_essentials"], P),
        ]
        #|
    def init_tab_system_all_settings(self):


        self.items[:] = [
            r_block_pref_export(self),
            BlockSep(),
        ] + [BlockPref(self, rna, P)  for rna in P_BL_RNA_PROPS  if rna.identifier not in {
            "md_lib_filepath",
            "calc_exp",
        }]
        BlockUtil.DEFAULT_FOLD_STATE = P_SettingEditor.is_fold
        b0 = BlockUtil(self, None, Title("Size"))
        b0.area = self
        pp = P.size
        subtypes = OVERRIDE_SUBTYPES[PrefsSize]
        b0.items = [BlockPrefNoInfo(b0, rna, pp, subtypes[rna.identifier]
            if rna.identifier in subtypes else None)
            for rna in P_SIZE_BL_RNA_PROPS]

        b1 = BlockUtil(self, None, Title("Color"))
        b1.area = self
        pp = P.color
        b1.items = [BlockPref(b1, rna, pp)  for rna in P_COLOR_BL_RNA_PROPS]

        b2 = BlockUtil(self, None, Title("Settings Editor"))
        b2.area = self
        pp = P_SettingEditor
        b2.items = [BlockPref(b2, rna, pp)
            for idd, rna in pp.bl_rna.properties.items() if idd not in {
            'bl_idname', 'name'} and rna.type != "POINTER"]

        b3 = BlockUtil(self, None, Title("Modifier Editor"))
        b3.area = self
        pp = P.ModifierEditor
        b3.items = [BlockPref(b3, rna, pp)
            for idd, rna in pp.bl_rna.properties.items() if idd not in {
            'bl_idname', 'name'} and rna.type != "POINTER"]

        self.items += [
            r_block_md_lib_filepath(self),
            r_block_calc_exp(self),
            BlockSep(),
            b0,
            b1,
            b2,
            b3,
        ]
        #|
    def init_tab_system_about(self):

        if not AreaBlockTabSettingEditor.about: AreaBlockTabSettingEditor.about = r_about()

        button0 = ButtonStringXYRead(None, RNA_about, AreaBlockTabSettingEditor)
        button0.row_count = P_SettingEditor.area_height

        self.items[:] = [BlockFull(self, button0)]
        #|

    def init_tab_size(self):

        rnas = RNAS["size"]

        self.items[:] = [
            BlockSubtab(self, rnas["ui_size"], lambda: self.init_tab(("size", "ui_size"))),
            BlockPref(self, RNA_ui_scale_100, lambda: bpy.ops.wm.vmd_ui_scale(factor=1.0)),
            BlockPref(self, RNA_ui_scale_133, lambda: bpy.ops.wm.vmd_ui_scale(factor=1.33)),
            BlockPref(self, RNA_ui_scale_166, lambda: bpy.ops.wm.vmd_ui_scale(factor=1.66)),
            BlockPref(self, RNA_ui_scale_200, lambda: bpy.ops.wm.vmd_ui_scale(factor=2.0)),
        ]
        #|
    def init_tab_size_ui_size(self):


        pp = P.size
        subtypes = OVERRIDE_SUBTYPES[PrefsSize]
        self.items[:] = [BlockPrefNoInfo(self, rna, pp, subtypes[rna.identifier]
            if rna.identifier in subtypes else None)
            for rna in P_SIZE_BL_RNA_PROPS]

        pp = P.ModifierEditor
        rnas = pp.bl_rna.properties
        self.items += [BlockPref(self, rnas[idd], pp)  for idd in callback_ids_ModifierEditor]
        pp = P.SettingEditor
        rnas = pp.bl_rna.properties
        self.items += [BlockPref(self, rnas[idd], pp)  for idd in callback_ids_SettingEditor]

        to_modal_drag_callfront = self.to_modal_drag_callfront
        end_modal_drag_callback = self.end_modal_drag_callback

        for blok in self.items:
            blok.button0.to_modal_drag_callfront = to_modal_drag_callfront
            blok.button0.end_modal_drag_callback = end_modal_drag_callback
            blok.button0.set_callback = upd_size
        #|

    def to_modal_drag_callfront(self):

        self.w.upd_size_state = None
        #|
    def end_modal_drag_callback(self):

        self.w.upd_size_state = True
        reload_gpu_texture()
        upd_size()
        #|

    def init_tab_personalization(self):

        rnas = RNAS["personalization"]

        self.items[:] = [
            BlockSubtab(self, rnas["ui_color"][0], lambda: self.init_tab(("personalization", "ui_color"))),
            BlockSubtab(self, rnas["shadow"], lambda: self.init_tab(("personalization", "shadow"))),
            BlockSubtab(self, rnas["theme"], lambda: self.init_tab(("personalization", "theme"))),
            BlockSubtab(self, rnas["font"][0], lambda: self.init_tab(("personalization", "font"))),
        ]
        #|
    def init_tab_personalization_ui_color(self):

        rnas = RNAS["personalization"]["ui_color"][1]

        self.items[:] = [
            BlockSubtab(self, rnas["all"], lambda: self.init_tab(("personalization", "ui_color", "all"))),
            BlockSubtab(self, rnas["window"], lambda: self.init_tab(("personalization", "ui_color", "window"))),
            BlockSubtab(self, rnas["menu"], lambda: self.init_tab(("personalization", "ui_color", "menu"))),
            BlockSubtab(self, rnas["foreground"], lambda: self.init_tab(("personalization", "ui_color", "foreground"))),
            BlockSubtab(self, rnas["hover"], lambda: self.init_tab(("personalization", "ui_color", "hover"))),
            BlockSubtab(self, rnas["taskbar"], lambda: self.init_tab(("personalization", "ui_color", "taskbar"))),
        ]
        #|
    def init_tab_personalization_ui_color_all(self):


        pp = P.color
        self.items[:] = [BlockPref(self, rna, pp)  for rna in P_COLOR_BL_RNA_PROPS]
        #|
    def init_tab_personalization_ui_color_window(self):


        pp = P.color
        self.items[:] = [BlockPref(self, rna, pp)  for idd, rna in P_COLOR_BL_RNA_PROPS.items(
            )  if idd[0 : 4] == "win_" or idd == "win"]
        #|
    def init_tab_personalization_ui_color_menu(self):


        pp = P.color
        self.items[:] = [BlockPref(self, rna, pp)  for idd, rna in P_COLOR_BL_RNA_PROPS.items(
            )  if not (idd[0 : 4] == "win_" or idd == "win")]
        #|
    def init_tab_personalization_ui_color_foreground(self):


        pp = P.color
        self.items[:] = [BlockPref(self, rna, pp)  for idd, rna in P_COLOR_BL_RNA_PROPS.items(
            )  if idd.find('_fg') != -1]
        #|
    def init_tab_personalization_ui_color_hover(self):


        pp = P.color
        self.items[:] = [BlockPref(self, rna, pp)  for idd, rna in P_COLOR_BL_RNA_PROPS.items(
            )  if idd.find('_hover') != -1]
        #|
    def init_tab_personalization_ui_color_taskbar(self):


        pp = P.color
        self.items[:] = [BlockPref(self, rna, pp)  for rna in (
            P_COLOR_BL_RNA_PROPS[idd]  for idd in (
                "box_tb",
                "box_tb_multibar",
            ))]
        #|
    def init_tab_personalization_shadow(self):


        pp = P.color
        c0 = BlockPref(self, P_COLOR_BL_RNA_PROPS["win_shadow"], pp)
        c1 = BlockPref(self, P_COLOR_BL_RNA_PROPS["dd_shadow"], pp)

        pp = P.size
        subtypes = OVERRIDE_SUBTYPES[PrefsSize]
        rna = P_SIZE_BL_RNA_PROPS["win_shadow_offset"]
        b0 = BlockPrefNoInfo(self, rna, pp, subtypes[rna.identifier]  if rna.identifier in subtypes else None)
        rna = P_SIZE_BL_RNA_PROPS["dd_shadow_offset"]
        b1 = BlockPrefNoInfo(self, rna, pp, subtypes[rna.identifier]  if rna.identifier in subtypes else None)
        rna = P_SIZE_BL_RNA_PROPS["shadow_softness"]
        b2 = BlockPrefNoInfo(self, rna, pp, subtypes[rna.identifier]  if rna.identifier in subtypes else None)

        b0.button0.to_modal_drag_callfront = self.to_modal_drag_callfront
        b1.button0.to_modal_drag_callfront = self.to_modal_drag_callfront
        b2.button0.to_modal_drag_callfront = self.to_modal_drag_callfront
        b0.button0.end_modal_drag_callback = self.end_modal_drag_callback
        b1.button0.end_modal_drag_callback = self.end_modal_drag_callback
        b2.button0.end_modal_drag_callback = self.end_modal_drag_callback
        b0.button0.set_callback = upd_size
        b1.button0.set_callback = upd_size
        b2.button0.set_callback = upd_size

        self.items[:] = [c0, b0, c1, b1, b2]
        #|
    def init_tab_personalization_font(self):

        rnas = RNAS["personalization"]["font"][1]

        self.items[:] = [
            BlockSubtab(self, rnas["color"], lambda: self.init_tab(("personalization", "font", "color"))),
            BlockSubtab(self, rnas["path"], lambda: self.init_tab(("personalization", "font", "path"))),
        ]
        #|
    def init_tab_personalization_font_color(self): self.init_tab_personalization_ui_color_foreground()
    def init_tab_personalization_font_path(self): self.init_tab_keymap_ops()
    def init_tab_personalization_theme(self): self.init_tab_keymap_ops()

    def init_tab_apps(self):

        rnas = RNAS["apps"]

        self.items[:] = [
            BlockSubtab(self, rnas["ModifierEditor"], lambda: self.init_tab(("apps", "ModifierEditor"))),
            BlockSubtab(self, rnas["SettingEditor"], lambda: self.init_tab(("apps", "SettingEditor"))),
        ]
        #|
    def init_tab_apps_ModifierEditor(self):


        pp = P.ModifierEditor
        self.items[:] = [BlockPref(self, rna, pp)
            for idd, rna in pp.bl_rna.properties.items() if idd not in {
            'bl_idname', 'name'} and rna.type != "POINTER"]
        #|
    def init_tab_apps_SettingEditor(self):


        pp = P_SettingEditor
        self.items[:] = [BlockPref(self, rna, pp)
            for idd, rna in pp.bl_rna.properties.items() if idd not in {
            'bl_idname', 'name'} and rna.type != "POINTER"]
        #|

    def init_tab_keymap(self):

        rnas = RNAS["keymap"]

        self.items[:] = [
            BlockSubtab(self, rnas["addon_key"][0], lambda: self.init_tab(("keymap", "addon_key"))),
            BlockSubtab(self, rnas["ops"], lambda: self.init_tab(("keymap", "ops"))),
        ]
        #|
    def init_tab_keymap_addon_key(self):

        rnas = RNAS["keymap"]["addon_key"][1]

        self.items[:] = [
            BlockSubtab(self, rnas["all"], lambda: self.init_tab(("keymap", "addon_key", "all"))),
            BlockSubtab(self, rnas["global"], lambda: self.init_tab(("keymap", "addon_key", "global"))),
            BlockSubtab(self, rnas["text"], lambda: self.init_tab(("keymap", "addon_key", "text"))),
            BlockSubtab(self, rnas["area"], lambda: self.init_tab(("keymap", "addon_key", "area"))),
            BlockSubtab(self, rnas["valuebox"], lambda: self.init_tab(("keymap", "addon_key", "valuebox"))),
        ]
        #|
    def init_tab_keymap_addon_key_all(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_SettingEditor.is_fold
        self.items[:] = [BlockPrefKeystroke(self, k)  for k in KEYMAPS]
        #|
    def init_tab_keymap_addon_key_global(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_SettingEditor.is_fold
        self.items[:] = [BlockPrefKeystroke(self, k)  for k in (
            'esc',
            'dd_esc',
            'click',
            'title_move',
            'title_button',
            'resize',
            'pan',
            'pan_win',
            'rm',
            'rm_km_toggle',
            'rm_km_change',
            'redo',
            'undo',
            'detail',
            'fold_all_recursive_toggle',
            'fold_all_toggle',
            'fold_recursive_toggle',
            'fold_toggle',
            'rename',
        )]
        #|
    def init_tab_keymap_addon_key_text(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_SettingEditor.is_fold
        self.items[:] = [BlockPrefKeystroke(self, k)  for k in KEYMAPS  if k[0 : 3] == "dd_"]
        #|
    def init_tab_keymap_addon_key_area(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_SettingEditor.is_fold
        self.items[:] = [BlockPrefKeystroke(self, k)  for k in KEYMAPS  if k[0 : 5] == "area_"]
        #|
    def init_tab_keymap_addon_key_valuebox(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_SettingEditor.is_fold
        self.items[:] = [BlockPrefKeystroke(self, k)  for k in KEYMAPS  if k[0 : 7] == "valbox_"]
        #|
    def init_tab_keymap_ops(self):

        _info = SimpleNamespace()
        _info.info = "Coming Soon"
        button0 = ButtonStringXYRead(None, RnaString("info", "Info"), _info)
        button0.row_count = P_SettingEditor.area_height

        self.items[:] = [BlockFull(self, button0)]
        #|

    @staticmethod
    def bufn_edit_expression(button0=None, box_block=None):

        if button0 is None: return
        else:
            L, R, B, T = button0.box_button.r_LRBT()

        def confirm_fn(s):
            exc = write_calc_exp(s, P)
            if exc == None:
                save_pref()
                return False
            return f'Compile Error.\n{exc}'

        def r_default_value(): return P.bl_rna.properties["calc_exp"].default

        DropDownText(button0, (box_block.L, R, T), P.calc_exp, confirm_fn, r_default_value)
        #|
    #|
    #|

class AreaKeymapCatch(StructAreaModal):
    __slots__ = (
        'w',
        'u_draw',
        'items',
        'box_area',
        'box_background',
        'blf_title',
        'button_keycombcatch',
        'button_save',
        'button_clear',
        'trigger_id',
        'trigger_index',
        'keycombcatch',
        'focus_element',
        'keycatch_list',
        'km')

    @staticmethod
    def r_height(L, R):
        T = 0
        widget_rim = SIZE_border[3]
        T = T - SIZE_dd_border[0]
        offset = widget_rim + D_SIZE['font_main_dx']
        y0 = T - offset - D_SIZE['font_subtitle_dT']
        button_keycombcatch_T = y0 - offset - D_SIZE['font_subtitle_dy']
        B = button_keycombcatch_T - D_SIZE['widget_full_h']
        button_save_T = B - SIZE_button[1] * 2 - SIZE_button[2]
        B = button_save_T - D_SIZE['widget_full_h']
        B -= SIZE_border[3] + offset + widget_rim
        return - B
        #|

    def __init__(self, w, LL, RR, BB, TT, trigger_id, trigger_index):
        self.w = w
        self.km = KEYMAPS[trigger_id]
        self.u_draw = self.i_draw
        self.trigger_id = trigger_id
        self.trigger_index = trigger_index
        self.box_area = GpuBox_area()
        self.box_background = GpuBox_box_setting_list_bg()

        self.blf_title = BlfColor("Place your mouse over this area and press the desired key",
            color=COL_block_fg_info)
        self.keycombcatch = ""
        self.keycatch_list = []
        self.button_keycombcatch = ButtonString(self, RNA_keycombcatch, self)
        self.button_save = ButtonFn(self, RNA_keycatch_save, self.bufn_save)
        self.button_clear = ButtonFn(self, RNA_keycatch_clear, self.bufn_clear)

        self.upd_size(LL, RR, BB, TT)
        #|

    def upd_size(self, LL, RR, BB, TT):
        d0 = SIZE_dd_border[0]
        widget_rim = SIZE_border[3]
        self.box_area.LRBT_upd(LL, RR, BB, TT)
        L = LL + d0
        R = RR - d0
        B = BB + d0
        T = TT - d0
        self.box_background.LRBT_upd(L, R, B, T)

        offset = widget_rim + D_SIZE['font_main_dx']
        L0 = L + offset
        x0 = L0 + D_SIZE['font_subtitle_dx']
        y0 = T - offset - D_SIZE['font_subtitle_dT']
        self.blf_title.x = x0
        self.blf_title.y = y0

        B = self.button_keycombcatch.init_bat(L0, R - offset, y0 - offset - D_SIZE['font_subtitle_dy'])
        T0 = B - SIZE_button[1] * 2 - SIZE_button[2]
        self.button_save.init_bat(L0 + widget_rim, RR, T0)
        self.button_clear.init_bat(self.button_save.box_button.R + SIZE_button[1], RR, T0)
        #|

    def r_focus_element(self):
        e = None
        if self.button_keycombcatch.inside(MOUSE): e = self.button_keycombcatch
        elif self.button_save.inside(MOUSE): e = self.button_save
        elif self.button_clear.inside(MOUSE): e = self.button_clear
        return e
        #|

    def modal_focus_element_back(self, e):
        if EVT_TYPE[1] == "PRESS":
            if len(self.keycatch_list) >= 4: del self.keycatch_list[0]
            if EVT_TYPE[0] not in {None, '', 'NONE', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
                k = f'{EVT_TYPE[0]}'
                if k not in self.keycatch_list:
                    self.keycatch_list.append(k)
                    self.button_keycombcatch.set(", ".join(self.keycatch_list), refresh=False, undo_push=False)
                    self.button_keycombcatch.upd_data()
                    self.w.update_repeat_info(self.keycatch_list, (self.trigger_id, self.trigger_index))
                    Admin.REDRAW()
        return False
        #|

    def bufn_save(self, refresh=True):

        km = KEYMAPS[self.trigger_id]
        oldvalue = ", ".join(km.types0  if self.trigger_index == 0 else km.types1)
        success = write_keytype_with_report(self.keycombcatch, self.trigger_id, self.trigger_index)
        if success:
            save_pref()
            km = KEYMAPS[self.trigger_id]
            newvalue = ", ".join(km.types0  if self.trigger_index == 0 else km.types1)
            def set_value(v):
                write_keytype_with_report(v, self.trigger_id, self.trigger_index)
                update_data()
                Admin.REDRAW()
                #|
            PREF_HISTORY.push_context = HistoryValue(oldvalue, newvalue, set_value, "KeyComb")
            PREF_HISTORY.push()
        if refresh: update_data()
        Admin.REDRAW()
        #|
    def bufn_clear(self, refresh=True):

        self.keycatch_list.clear()
        self.button_keycombcatch.set("", undo_push=False)
        self.button_keycombcatch.upd_data()
        self.w.update_repeat_info(self.keycatch_list, (self.trigger_id, self.trigger_index))
        Admin.REDRAW()
        #|

    def dxy(self, dx, dy):
        self.box_area.dxy_upd(dx, dy)
        self.box_background.dxy_upd(dx, dy)
        self.button_keycombcatch.dxy(dx, dy)
        self.button_save.dxy(dx, dy)
        self.button_clear.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy
        #|

    def i_draw(self):
        blend_set('ALPHA')
        self.box_area.bind_draw()
        self.box_background.bind_draw()
        self.button_keycombcatch.draw_box()
        self.button_save.draw_box()
        self.button_clear.draw_box()

        self.button_keycombcatch.draw_blf()
        self.button_save.draw_blf()
        self.button_clear.draw_blf()

        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_subtitle'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self):

        self.button_keycombcatch.upd_data()
        if self.km is KEYMAPS[self.trigger_id]: return
        self.km = KEYMAPS[self.trigger_id]

        self.w.update_repeat_info(self.keycatch_list, (self.trigger_id, self.trigger_index))
        self.w.update_keymap_info()
        #|
    #|
    #|



class BlockPrefKeystroke(BlockUtils):
    __slots__ = (
        'km',
        'trigger_id',
        'keycomb0',
        'keycomb1',
        'keyvalue0',
        'keyvalue1',
        'keyendvalue0',
        'keyendvalue1',
        'keyexact0',
        'keyexact1',
        'keyduration0',
        'keyduration1',
        'button_duration0',
        'button_duration1')

    def __init__(self, w, trigger_id):
        self.trigger_id = trigger_id
        self.update_km_properties()
        rna = P_KEYMAPS_BL_RNA_PROPS[trigger_id]
        b_keycomb0 = ButtonStringKeyComb(None, RNA_keycomb0, self, subtype_override=("Comb 1",))
        b_keycomb1 = ButtonStringKeyComb(None, RNA_keycomb1, self, subtype_override=("Comb 2",))
        b_keycomb0.trigger_id = trigger_id
        b_keycomb1.trigger_id = trigger_id
        buttons = [
            ButtonGroupTwo(self,
                ButtonFn(None, RNA_edit_keystroke1, self.bufn_edit_keystroke1),
                ButtonFn(None, RNA_edit_keystroke0, self.bufn_edit_keystroke0)
            ),
            ButtonGroupFull(self, b_keycomb0, title=""),
            ButtonGroupFull(self, b_keycomb1, title=""),
        ]
        if trigger_id == "click":
            items = [
                ButtonSep(),
                ButtonGroup(self, ButtonBoolKeyExact(None, RNA_keyexact0, self)),
                ButtonGroup(self, ButtonBoolKeyExact(None, RNA_keyexact1, self)),
            ]
            for r in {1, 2}:
                items[r].button0.trigger_id = trigger_id
        elif self.km.use_end_key:
            items = [
                ButtonSep(),
                ButtonGroup(self, ButtonEnumKeyValue(None, RNA_keyvalue0, self)),
                ButtonGroup(self, ButtonEnumKeyEndValue(None, RNA_keyendvalue0, self)),
                ButtonGroup(self, ButtonFloatKeyDuration(None, RNA_keyduration0, self)),
                ButtonGroup(self, ButtonBoolKeyExact(None, RNA_keyexact0, self)),
                ButtonSep(),
                ButtonGroup(self, ButtonEnumKeyValue(None, RNA_keyvalue1, self)),
                ButtonGroup(self, ButtonEnumKeyEndValue(None, RNA_keyendvalue1, self)),
                ButtonGroup(self, ButtonFloatKeyDuration(None, RNA_keyduration1, self)),
                ButtonGroup(self, ButtonBoolKeyExact(None, RNA_keyexact1, self)),
                ButtonSep(),
            ]
            for r in {1, 2, 3, 4, 6, 7, 8, 9}:
                items[r].button0.trigger_id = trigger_id
            self.button_duration0 = items[3].button0
            self.button_duration1 = items[8].button0
        else:
            items = [
                ButtonSep(),
                ButtonGroup(self, ButtonEnumKeyValue(None, RNA_keyvalue0, self)),
                ButtonGroup(self, ButtonFloatKeyDuration(None, RNA_keyduration0, self)),
                ButtonGroup(self, ButtonBoolKeyExact(None, RNA_keyexact0, self)),
                ButtonSep(),
                ButtonGroup(self, ButtonEnumKeyValue(None, RNA_keyvalue1, self)),
                ButtonGroup(self, ButtonFloatKeyDuration(None, RNA_keyduration1, self)),
                ButtonGroup(self, ButtonBoolKeyExact(None, RNA_keyexact1, self)),
                ButtonSep(),
            ]
            for r in {1, 2, 3, 5, 6, 7}:
                items[r].button0.trigger_id = trigger_id
            self.button_duration0 = items[2].button0
            self.button_duration1 = items[6].button0
        self.update_darklight()
        super().__init__(w, items, buttons, title=rna.name)
        #|

    def bufn_edit_keystroke0(self):

        KeymapEditor(id_class="", use_pos=True, pos_offset=(-15, 15), use_fit=True,
            trigger_id=self.trigger_id, trigger_index=0)
        #|
    def bufn_edit_keystroke1(self):

        KeymapEditor(id_class="", use_pos=True, pos_offset=(-15, 15), use_fit=True,
            trigger_id=self.trigger_id, trigger_index=1)
        #|

    def update_km_properties(self):
        km = KEYMAPS[self.trigger_id]
        self.km = km
        self.keycomb0 = ", ".join(e.lower().replace('_', ' ').capitalize()  for e in km.types0)
        self.keycomb1 = ", ".join(e.lower().replace('_', ' ').capitalize()  for e in km.types1)
        self.keyvalue0 = km.value0
        self.keyvalue1 = km.value1
        self.keyexact0 = km.exact0
        self.keyexact1 = km.exact1
        self.keyduration0 = km.duration0
        self.keyduration1 = km.duration1
        if km.use_end_key:
            self.keyendvalue0 = km.end_value0
            self.keyendvalue1 = km.end_value1
        #|
    def update_darklight(self):
        if hasattr(self, "button_duration0"):
            km = self.km
            if km.use_end_key:
                if km.value0 in TIME_KEYS or km.end_value0 in TIME_KEYS:
                    self.button_duration0.light()
                else: self.button_duration0.dark()
                if km.value1 in TIME_KEYS or km.end_value1 in TIME_KEYS:
                    self.button_duration1.light()
                else: self.button_duration1.dark()
            else:
                if km.value0 in TIME_KEYS:
                    self.button_duration0.light()
                else: self.button_duration0.dark()
                if km.value1 in TIME_KEYS:
                    self.button_duration1.light()
                else: self.button_duration1.dark()
        #|
    def upd_data(self):
        if self.km is not KEYMAPS[self.trigger_id]:

            self.update_km_properties()
        self.update_darklight()
        super().upd_data()
        #|
    #|
    #|
class BlockPrefSearchHead(BlockUtils):
    __slots__ = (
        'text_search',
        'use_search_name',
        'use_search_id',
        'use_search_description',
        'use_search_cat_pref',
        'use_search_cat_pref_color',
        'use_search_cat_pref_size',
        'use_search_cat_pref_apps',
        'use_search_cat_pref_keymap')

    def __init__(self, w):
        self.w = w
        self.text_search = ""
        self.use_search_name = P_SettingEditor.use_search_name
        self.use_search_id = P_SettingEditor.use_search_id
        self.use_search_description = P_SettingEditor.use_search_description
        self.use_search_cat_pref = P_SettingEditor.use_search_cat_pref
        self.use_search_cat_pref_color = P_SettingEditor.use_search_cat_pref_color
        self.use_search_cat_pref_size = P_SettingEditor.use_search_cat_pref_size
        self.use_search_cat_pref_apps = P_SettingEditor.use_search_cat_pref_apps
        self.use_search_cat_pref_keymap = P_SettingEditor.use_search_cat_pref_keymap

        buttons = [ButtonStringFind(self, RNA_text_search, self)]
        items = [
            ButtonGroupAlignLR(self, ButtonBoolCall(None, RNA_use_search_name, self), title="Name",
                title_head="Include"),
            ButtonGroupAlignL(self, ButtonBoolCall(None, RNA_use_search_id, self), title="ID"),
            ButtonGroupAlignL(self, ButtonBoolCall(None, RNA_use_search_description, self), title="Description"),
            BlockSep(),
            ButtonGroupAlignLR(self, ButtonBoolCall(None, RNA_use_search_cat_pref, self), title="General",
                title_head="Category"),
            ButtonGroupAlignL(self, ButtonBoolCall(None, RNA_use_search_cat_pref_color, self), title="Color"),
            ButtonGroupAlignL(self, ButtonBoolCall(None, RNA_use_search_cat_pref_size, self), title="Size"),
            ButtonGroupAlignL(self, ButtonBoolCall(None, RNA_use_search_cat_pref_apps, self), title="Editor"),
            ButtonGroupAlignL(self, ButtonBoolCall(None, RNA_use_search_cat_pref_keymap, self), title="Keymap"),
            BlockSep(),
        ]
        text_callback = self.button_text_callback
        buttons[0].set_callback = text_callback
        items[0].button0.set_callback = text_callback
        items[1].button0.set_callback = text_callback
        items[2].button0.set_callback = text_callback
        items[0].button0.get_default_value = lambda: P_SettingEditor.use_search_name
        items[1].button0.get_default_value = lambda: P_SettingEditor.use_search_id
        items[2].button0.get_default_value = lambda: P_SettingEditor.use_search_description

        items[4].button0.set_callback = text_callback
        items[5].button0.set_callback = text_callback
        items[6].button0.set_callback = text_callback
        items[7].button0.set_callback = text_callback
        items[8].button0.set_callback = text_callback
        items[4].button0.get_default_value = lambda: P_SettingEditor.use_search_cat_pref
        items[5].button0.get_default_value = lambda: P_SettingEditor.use_search_cat_pref_color
        items[6].button0.get_default_value = lambda: P_SettingEditor.use_search_cat_pref_size
        items[8].button0.get_default_value = lambda: P_SettingEditor.use_search_cat_pref_apps
        items[7].button0.get_default_value = lambda: P_SettingEditor.use_search_cat_pref_keymap
        super().__init__(w, items, buttons, title="Find")
        #|

    def button_text_callback(self, v=None):

        text = self.text_search
        a = self.w
        items = a.items
        if not text:
            items[:] = items[0 : 1]
            a.init_draw_range()
            a.get_cv_height()
            a.upd_scroll_init()
            a.upd_scroll()
            return

        P_ModifierEditor = P.ModifierEditor
        P_SettingEditor = P.SettingEditor
        to_modal_drag_callfront = a.to_modal_drag_callfront
        end_modal_drag_callback = a.end_modal_drag_callback

        def r_result(s):
            results = []
            b0 = self.buttons[0]
            filter_fn = r_filter_function(b0.is_match_case, b0.is_match_whole_word, b0.is_match_end)
            use_search_name = self.use_search_name
            use_search_id = self.use_search_id
            use_search_description = self.use_search_description

            subtypes_size = OVERRIDE_SUBTYPES[PrefsSize]
            is_appended = {
                "calc_exp": False,
                "md_lib_filepath": False,
            }

            def r_block_general(rna, pp):
                rna_identifier = rna.identifier
                if rna_identifier in {"calc_exp", "edit_expression"}:
                    if is_appended["calc_exp"] is False:
                        is_appended["calc_exp"] = True
                        return r_block_calc_exp(a)
                    else:
                        return BlockSep()
                if rna_identifier in {"md_lib_edit", "md_lib_filepath"}:
                    if is_appended["md_lib_filepath"] is False:
                        is_appended["md_lib_filepath"] = True
                        return r_block_md_lib_filepath(a)
                    else:
                        return BlockSep()
                if rna_identifier == "md_lib_refresh": return r_block_md_lib_refresh(a)

                return BlockPref(a, rna, pp)
            def r_block_size(rna, pp):
                e = BlockPrefNoInfo(a, rna, pp, subtypes_size[rna.identifier]
                    if rna.identifier in subtypes_size else None)
                e.button0.to_modal_drag_callfront = to_modal_drag_callfront
                e.button0.end_modal_drag_callback = end_modal_drag_callback
                e.button0.set_callback = upd_size
                return e
            def r_block_keymap(rna, pp): return BlockPrefKeystroke(a, rna.identifier)

            def for_cat(rnas, pp, r_block):
                for rna in rnas:
                    if use_search_name:
                        if filter_fn(rna.name, s):
                            results.append((rna, pp, r_block))
                            continue
                    if use_search_id:
                        if filter_fn(rna.identifier, s):
                            results.append((rna, pp, r_block))
                            continue
                    if use_search_description:
                        if filter_fn(rna.description, s):
                            results.append((rna, pp, r_block))
                            continue

            if self.use_search_cat_pref:
                for_cat(P_BL_RNA_PROPS, P, r_block_general)
                for_cat([RNA_md_lib_edit, RNA_md_lib_refresh, RNA_edit_expression], None, r_block_general)
            if self.use_search_cat_pref_color: for_cat(P_COLOR_BL_RNA_PROPS, P.color, r_block_general)
            if self.use_search_cat_pref_size: for_cat(P_SIZE_BL_RNA_PROPS, P.size, r_block_size)
            if self.use_search_cat_pref_apps:
                P_app = P_ModifierEditor
                for_cat(
                    (rna  for idd, rna in P_app.bl_rna.properties.items() if idd not in {
                    'bl_idname', 'name'} and rna.type != "POINTER"),
                    P_app, r_block_general
                )
                P_app = P_SettingEditor
                for_cat(
                    (rna  for idd, rna in P_app.bl_rna.properties.items() if idd not in {
                    'bl_idname', 'name'} and rna.type != "POINTER"),
                    P_app, r_block_general
                )
            if self.use_search_cat_pref_keymap: for_cat(P_KEYMAPS_BL_RNA_PROPS, None, r_block_keymap)
            return results
            #|
        def report_ifnot_str(): report("Type error, sequence elements must be strings", "WARNING")

        if text[0 : 2] == ";;": out = r_result(text[1 :])
        elif text[0] == ";":
            success, result = r_filtexp_tuple(text[1 :])
            if not success: return

            fn_name, result = result
            out_set = set()
            out = []
            if fn_name == "union":
                for tx in result:
                    if not isinstance(tx, str): return report_ifnot_str()
                    ls = r_result(tx)
                    out += [e  for e in ls if e[0 : 2] not in out_set]
                    out_set.update(e[0 : 2]  for e in ls)
            elif fn_name == "intersection":
                if result:
                    tx = result[0]
                    if not isinstance(tx, str): return report_ifnot_str()
                    out = r_result(tx)
                for tx in result[1 :]:
                    if not isinstance(tx, str): return report_ifnot_str()
                    out = [x  for x in out if x[0 : 2] in frozenset(e[0 : 2]  for e in r_result(tx))]
            elif fn_name == "difference":
                if result:
                    tx = result[0]
                    if not isinstance(tx, str): return report_ifnot_str()
                    out = r_result(tx)
                for tx in result[1 :]:
                    if not isinstance(tx, str): return report_ifnot_str()
                    out_set = {e[0 : 2]  for e in r_result(tx)}
                    out = [x  for x in out if x[0 : 2] not in out_set]
            else:
                report("Function error", "WARNING")
                return
        else:
            out = r_result(text)

        BlockUtil.DEFAULT_FOLD_STATE = P_SettingEditor.is_fold
        items[:] = items[0 : 1]
        for rna, pp, r_block in out:
            items.append(r_block(rna, pp))

            if pp is P_ModifierEditor:
                if rna.identifier in callback_ids_ModifierEditor: pass
                else: continue
            elif pp is P_SettingEditor:
                if rna.identifier in callback_ids_SettingEditor: pass
                else: continue
            else:
                continue

            e = items[-1].button0
            e.to_modal_drag_callfront = to_modal_drag_callfront
            e.end_modal_drag_callback = end_modal_drag_callback
            e.set_callback = upd_size


        a.init_draw_range()
        a.get_cv_height()
        a.upd_scroll_init()
        a.upd_scroll()
        #|
    #|
    #|
@ decoReport("WARNING")
def r_filtexp_tuple(s):
    success, result = evalfiltexp(s)
    if not success: return success, result

    fn_name, result = result
    success, result = r_tuple(result)
    return success, (fn_name, result)
    #|

def r_block_calc_exp(self):
    e = BlockPref(self, RNA_edit_expression,
        lambda: AreaBlockTabSettingEditor.bufn_edit_expression(button0, self.items[0].box_block))
    button0 = e.button0
    return e
    #|
def r_block_md_lib_filepath(self):
    e = BlockPref(self, RNA_md_lib_edit, lambda: LibraryModifier.ui_edit_path(button0, self.items[0].box_block))
    button0 = e.button0
    return e
    #|
def r_block_md_lib_refresh(self):
    return BlockPref(self, RNA_md_lib_refresh, LibraryModifier.ui_refresh_path)
    #|
def r_block_pref_export(self):
    return BlockPref(self, RNA_pref_export, pref_export_copy_to_clipboard)

def pref_export_copy_to_clipboard(is_report=True):
    if not P: return
    b64encode = base64.b64encode
    s = ""

    def format_value(rna, v):
        if isinstance(v, str):
            if rna.type == "STRING": v = b64encode(v.encode())
        elif hasattr(v, "__iter__"):
            v = [v  for v in v]
        return v

    for identifier, rna in P_BL_RNA_PROPS.items():
        s += f'{identifier} = {format_value(rna, getattr(P, identifier))}\n'

    pp = P.size
    head = "size."
    for identifier, rna in pp.bl_rna.properties.items():
        if identifier in {'bl_idname', 'name', 'rna_type'}: continue
        if rna.type == "POINTER": continue
        s += f'{head}{identifier} = {format_value(rna, getattr(pp, identifier))}\n'

    pp = P.color
    head = "color."
    for identifier, rna in pp.bl_rna.properties.items():
        if identifier in {'bl_idname', 'name', 'rna_type'}: continue
        if rna.type == "POINTER": continue
        s += f'{head}{identifier} = {format_value(rna, getattr(pp, identifier))}\n'

    pp = P.keymaps
    head = "keymaps."
    for identifier, rna in pp.bl_rna.properties.items():
        if identifier in {'bl_idname', 'name', 'rna_type'}: continue
        if rna.type == "POINTER": continue
        s += f'{head}{identifier} = {format_value(rna, getattr(pp, identifier))}\n'

    pp = P.SettingEditor
    head = "SettingEditor."
    for identifier, rna in pp.bl_rna.properties.items():
        if identifier in {'bl_idname', 'name', 'rna_type'}: continue
        if rna.type == "POINTER": continue
        s += f'{head}{identifier} = {format_value(rna, getattr(pp, identifier))}\n'

    pp = P.ModifierEditor
    head = "ModifierEditor."
    for identifier, rna in pp.bl_rna.properties.items():
        if identifier in {'bl_idname', 'name', 'rna_type'}: continue
        if rna.type == "POINTER": continue
        s += f'{head}{identifier} = {format_value(rna, getattr(pp, identifier))}\n'

    bpy.context.window_manager.clipboard = s
    if is_report: report("Copy to Clipboard")
    #|


class ButtonStringKeyComb(ButtonStringPref):
    __slots__ = 'trigger_id'

    def set(self, v, refresh=True, undo_push=True):
        oldvalue = self.get()
        write_keytype_with_report(v, self.trigger_id, 0  if self.rna.identifier[-1] == "0" else 1)
        if refresh: update_data()
        self.evt_undo_push(undo_push, oldvalue)
        Admin.REDRAW()
        #|

    def r_default_value(self):
        km = KeyMap("", P_KEYMAPS_BL_RNA_PROPS[self.trigger_id].default_array)
        return ",".join(km.types0  if self.rna.identifier[-1] == "0" else km.types1)
        #|
    #|
    #|
class ButtonEnumKeyValue(ButtonEnumPref):
    __slots__ = 'trigger_id'

    def set(self, v, refresh=True, undo_push=True):
        oldvalue = self.get()
        write_keyvalue_with_report(v, self.trigger_id, 0  if self.rna.identifier[-1] == "0" else 1)
        if refresh: update_data()
        self.evt_undo_push(undo_push, oldvalue)
        Admin.REDRAW()
        #|

    def r_default_value(self):
        km = KeyMap("", P_KEYMAPS_BL_RNA_PROPS[self.trigger_id].default_array)
        return km.value0  if self.rna.identifier[-1] == "0" else km.value1
        #|
    #|
    #|
class ButtonEnumKeyEndValue(ButtonEnumPref):
    __slots__ = 'trigger_id'

    def set(self, v, refresh=True, undo_push=True):
        write_keyendvalue_with_report(v, self.trigger_id, 0  if self.rna.identifier[-1] == "0" else 1)
        if refresh: update_data()
        #|

    def r_default_value(self):
        km = KeyMap("", P_KEYMAPS_BL_RNA_PROPS[self.trigger_id].default_array)
        return km.end_value0  if self.rna.identifier[-1] == "0" else km.end_value1
        #|
    #|
    #|
class ButtonBoolKeyExact(ButtonBoolPref):
    __slots__ = 'trigger_id'

    def set(self, v, refresh=True, undo_push=True):
        oldvalue = self.get()
        write_keyexact_with_report(v, self.trigger_id, 0  if self.rna.identifier[-1] == "0" else 1)
        if refresh: update_data()
        self.evt_undo_push(undo_push, oldvalue)
        Admin.REDRAW()
        #|

    def r_default_value(self):
        km = KeyMap("", P_KEYMAPS_BL_RNA_PROPS[self.trigger_id].default_array)
        return km.exact0  if self.rna.identifier[-1] == "0" else km.exact1
        #|
    #|
    #|
class ButtonFloatKeyDuration(ButtonFloatPref):
    __slots__ = 'trigger_id'

    def set(self, v, refresh=True, undo_push=True):
        oldvalue = self.get()
        write_duration_with_report(v, self.trigger_id, 0  if self.rna.identifier[-1] == "0" else 1)
        if refresh: update_data()
        self.evt_undo_push(undo_push, oldvalue)
        Admin.REDRAW()
        #|

    def r_default_value(self):
        km = KeyMap("", P_KEYMAPS_BL_RNA_PROPS[self.trigger_id].default_array)
        return km.duration0  if self.rna.identifier[-1] == "0" else km.duration1
        #|
    #|
    #|

class ButtonStringSettingHeader(ButtonString):
    __slots__ = 'buttons', 'box_hover', 'focus_element'

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        v = getattr(pp, rna.identifier)
        self.blf_value = BlfClipColor(v, v, 0, 0, COL_box_text_fg)
        self.box_hover = GpuRimBlfbuttonTextHover()
        #|

    def r_init_tab_fn(self, tabs):
        def _init_tab():
            self.w.w.active_tab = tabs
            self.w.w.upd_data()
        return _init_tab
        #|

    def init_buttons(self, tabs):
        if tabs:
            f0 = self.button_inside_evt_callback
            f1 = self.button_outside_evt_callback
            r_init_tab_fn = self.r_init_tab_fn
            self.buttons = [
                ButtonFnBlf(self, None, r_init_tab_fn(tabs[: r + 1]),
                    "", COL_box_text_fg, f0, f1)
                for r in range(len(tabs))
            ]
            L, R, B, T = self.box_button.inner
            h = SIZE_widget[0]
            font_main_dx = D_SIZE['font_main_dx']
            # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
            blfSize(FONT0, D_SIZE['font_main'])
            blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
            # >>>
            ButtonFnBlf.set_offset(L, font_main_dx, D_SIZE['font_main_dy'], h)

            e = self.buttons[0]
            for r, e in enumerate(self.buttons):
                if r == 0:
                    name = tabs[0].title()
                else:
                    name = r_tab_rna(tabs[: r + 1]).name

                e.blf_value.unclip_text = name
                ButtonFnBlf.BLF_X = L + font_main_dx
                R = ButtonFnBlf.BLF_X + round(blfDimen(FONT0, name)[0]) + font_main_dx
                e.init_bat_dimen(L, R, T)
                L = R + h
        else:
            self.buttons = []
        #|

    def init_bat(self, L, R, T):
        B = super().init_bat(L, R, T)
        self.init_buttons(self.w.w.active_tab)
        self.box_hover.LRBT_upd(0, 0, 0, 0, 0)
        return B
        #|

    def inside_evt(self):
        for e in self.buttons:
            if e.inside(MOUSE):
                self.focus_element = e
                return e.inside_evt()

        self.focus_element = None
        super().inside_evt()
        #|
    def outside_evt(self):
        super().outside_evt()
        if self.box_hover.d != 0: self.box_hover.LRBT_upd(0, 0, 0, 0, 0)
        #|

    def button_inside_evt_callback(self, button):
        self.box_hover.LRBT_upd(*button.box_button.r_LRBT(), SIZE_border[3])
        #|
    def button_outside_evt_callback(self, button):
        if self.box_hover.d != 0: self.box_hover.LRBT_upd(0, 0, 0, 0, 0)
        #|

    def modal(self):
        focus_button = None
        for e in self.buttons:
            if e.inside(MOUSE):
                focus_button = e
                break

        if focus_button is None:
            if self.focus_element != None:
                self.focus_element = None
                self.box_button.color = COL_box_text_active

            if self.box_hover.d != 0: self.box_hover.LRBT_upd(0, 0, 0, 0, 0)
            Admin.REDRAW()
            return super().modal()
        else:
            if self.focus_element != focus_button:
                if hasattr(self.focus_element, "outside_evt"): self.focus_element.outside_evt()
                self.focus_element = focus_button
                self.box_button.color = COL_box_text
                focus_button.inside_evt()

            return focus_button.modal()
        return False
        #|

    def to_dropdown(self, killevt=True, select_all=None):
        return DropDownString(self, self.box_button.r_LRBT(), r_tab_as_string(self.w.w.active_tab))
        #|
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        bpy.context.window_manager.clipboard = r_tab_as_string(self.w.w.active_tab)
        if is_report: report("Copy to Clipboard")
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.blf_value.x += dx
        self.blf_value.y += dy
        for e in self.buttons: e.dxy(dx, dy)
        self.box_hover.dxy_upd(dx, dy)
        #|

    def draw_box(self):
        self.box_button.bind_draw()
        self.box_hover.bind_draw()
        #|
    def draw_blf(self):
        for e in self.buttons: e.draw_blf()
        #|

    def set(self, v, refresh=True, undo_push=True):
        tabs = r_tabs_by_string(v)
        if tabs != None:
            self.w.w.active_tab = tabs
            self.w.w.upd_data()
        #|
    #|
    #|

class ButtonStringFind(ButtonStringMatchButton):
    __slots__ = ()

    OFFSET_FAC = 1
    OFFSET_TEXT = "find"

    #|
    #|


def write_with_report(success, message, is_save_pref):
    if success:
        if message: report(message)
        if is_save_pref: save_pref()
    else:
        report(message, "WARNING")
    #|
def write_keytype_with_report(s, trigger_id, trigger_index, is_save_pref=False):
    success, message = write_keytype(s, trigger_id, trigger_index)
    write_with_report(success, message, is_save_pref)
    return success
    #|
def write_keyvalue_with_report(s, trigger_id, trigger_index, is_save_pref=False):
    success, message = write_keyvalue(s, trigger_id, trigger_index)
    write_with_report(success, message, is_save_pref)
    return success
    #|
def write_keyendvalue_with_report(s, trigger_id, trigger_index, is_save_pref=False):
    success, message = write_keyendvalue(s, trigger_id, trigger_index)
    write_with_report(success, message, is_save_pref)
    return success
    #|
def write_keyexact_with_report(s, trigger_id, trigger_index, is_save_pref=False):
    success, message = write_keyexact(s, trigger_id, trigger_index)
    write_with_report(success, message, is_save_pref)
    return success
    #|
def write_duration_with_report(s, trigger_id, trigger_index, is_save_pref=False):
    success, message = write_keyduration(s, trigger_id, trigger_index)
    write_with_report(success, message, is_save_pref)
    return success
    #|


def r_tab_rna(tabs): # need len >= 2
    e = RNAS[tabs[0]]
    for identifier in tabs[1 :]:
        if isinstance(e, tuple): e = e[1][identifier]
        else: e = e[identifier]
    if isinstance(e, tuple): return e[0]
    else: return e
    #|
def r_tab_as_string(tabs):
    if tabs:
        if len(tabs) == 1: return tabs[0].title()
        s = f'{tabs[0].title()}\\'
        e = RNAS[tabs[0]]
        for identifier in tabs[1 :]:
            if isinstance(e, tuple): e = e[1][identifier]
            else: e = e[identifier]
            if isinstance(e, tuple): s += f'{e[0].name}\\'
            else: s += f'{e.name}\\'
        return s[: -1]
    return ""
    #|
def r_tabs_by_string(s):
    if not isinstance(s, str): return None
    s = s.strip().replace("/", "\\")
    if s[-1 :] == "\\": s = s[: -1]
    if not s: return None
    li = s.split("\\")
    if not li: return None

    id0 = li[0].lower()
    if id0 not in RNAS: return None
    tabs = [id0]
    if len(li) == 1: return tuple(tabs)

    its = RNAS[id0]
    for name in li[1 :]:
        name = name.lower()
        name_to_id = {e[0].name.lower()  if isinstance(e, tuple) else e.name.lower(): k  for k, e in its.items()}
        if name not in name_to_id: return None
        identifier = name_to_id[name]
        tabs.append(identifier)
        its = its[identifier]
        if isinstance(its, tuple): its = its[1]
    return tuple(tabs)
    #|


RNAS = {
    "search": {},
    "system": {
        "display": RnaSubtab("display", "Display", "Window position, Taskbar, Enable/disable features", "GpuImg_settings_system_display"),
        "control": RnaSubtab("control", "Control", "Scroll speed, Drag threshold, Pan method", "GpuImg_settings_system_control"),
        "menu": RnaSubtab("menu", "Menu", "Drop Down Menu behavior, Format, Text Box", "GpuImg_settings_system_menu"),
        "expression": RnaSubtab("expression", "Expression", "Calculator expressions and button functions", "GpuImg_settings_system_expression"),
        "library": RnaSubtab("library", "Library", "Library Data", "GpuImg_settings_system_library"),
        "all_settings": RnaSubtab("all_settings", "All Settings", "All addon properties", "GpuImg_settings_system_all_settings"),
        "about": RnaSubtab("about", "About", "Information, Support and help", "GpuImg_settings_system_about"),
    },
    "size": {
        "ui_size": RnaSubtab("ui_size", "UI Size", "Interface size", "GpuImg_settings_size_ui_size"),
    },
    "personalization": {
        "ui_color": (RnaSubtab("ui_color", "UI Color", "Interface colors", "GpuImg_settings_personalization_ui_color"), {
            "all": RnaSubtab("all", "All", "All UI color", "GpuImg_settings_system_all_settings"),
            "window": RnaSubtab("window", "Window", "Window color", "GpuImg_settings_personalization_ui_color_window"),
            "menu": RnaSubtab("menu", "Menu", "Menu color", "GpuImg_settings_system_menu"),
            "foreground": RnaSubtab("foreground", "Foreground", "Font color", "GpuImg_settings_personalization_ui_color_foreground"),
            "hover": RnaSubtab("hover", "Hover", "Widget hover color", "GpuImg_settings_personalization_ui_color_hover"),
            "taskbar": RnaSubtab("taskbar", "Taskbar", "Taskbar color", "GpuImg_settings_personalization_ui_color_taskbar"),
        }),
        "shadow": RnaSubtab("shadow", "Shadow", "Editor drop shadow appearance", "GpuImg_settings_personalization_shadow"),
        "theme": RnaSubtab("theme", "Theme", "UI theme", "GpuImg_settings_keymap_ops"),
        "font": (RnaSubtab("font", "Font", "UI font", "GpuImg_settings_personalization_font"), {
            "color": RnaSubtab("color", "Color", "Font color", "GpuImg_settings_personalization_ui_color_foreground"),
            "path": RnaSubtab("path", "Path", "UI font path", "GpuImg_settings_keymap_ops"),
        }),
    },
    "apps": {
        "ModifierEditor": RnaSubtab("ModifierEditor", "Modifier Editor", "Shows the modifiers in a specific object.", "GpuImg_ModifierEditor"),
        "SettingEditor": RnaSubtab("SettingEditor", "Settings Editor", "Current Editor.", "GpuImg_SettingEditor"),
    },
    "keymap": {
        "addon_key": (RnaSubtab("addon_key", "Addon Keystroke", "Shortcut Combinations for Current Addon.", "GpuImg_settings_keymap_addon_key"), {
            "all": RnaSubtab("all", "All", "All Addon Keymap", "GpuImg_settings_system_all_settings"),
            "global": RnaSubtab("global", "Global", "General Keymap", "GpuImg_settings_keymap_addon_key_global"),
            "text": RnaSubtab("text", "Text", "Text Input / Scroll Keymap", "GpuImg_settings_keymap_addon_key_text"),
            "area": RnaSubtab("area", "Area", "Area Event Keymap", "GpuImg_settings_keymap_addon_key_area"),
            "valuebox": RnaSubtab("valuebox", "Value Box", "Widget / Color Panel Keymap", "GpuImg_settings_keymap_addon_key_valuebox"),
        }),
        "ops": RnaSubtab("ops", "Blender Operator", "Blender Operator Shortcut.", "GpuImg_settings_keymap_ops"),
    },
}
RNA_edit_expression = RnaButton("edit_expression",
    name = "Calculator Expressions",
    button_text = "Edit Expression",
    description = "Edit expression in Text Editor.")
RNA_edit_keystroke0 = RnaButton("edit_keystroke0",
    name = "Edit Keystroke 1",
    button_text = "Edit 1",
    description = "Edit key combinations 1.",
    size = -3)
RNA_edit_keystroke1 = RnaButton("edit_keystroke1",
    name = "Edit Keystroke 2",
    button_text = "Edit 2",
    description = "Edit key combinations 2.",
    size = -3)
RNA_keycatch_save = RnaButton("keycatch_save",
    name = "Keymap Save",
    button_text = "Save",
    description = "Save Keystroke.",
    size = 3)
RNA_keycatch_clear = RnaButton("keycatch_clear",
    name = "Keymap Clear",
    button_text = "Clear",
    description = "Clear Keystroke.",
    size = 3)
RNA_keycomb0 = RnaString("keycomb0",
    name = "Comb 1",
    description = "Key Combination 1")
RNA_keycomb1 = RnaString("keycomb1",
    name = "Comb 2",
    description = "Key Combination 2")
RNA_keycombcatch = RnaString("keycombcatch",
    name = "Keystroke Catch",
    description = "Captures key combinations when the mouse is placed over a specific area.",
    is_readonly = True)
RNA_keyvalue0 = RnaEnum("keyvalue0", ENUMS_keymap_value,
    name = "Value 1",
    description = "Behavior that triggers the keymap Combination 1.",
    default = "PRESS")
RNA_keyvalue1 = RnaEnum("keyvalue1", ENUMS_keymap_value,
    name = "Value 2",
    description = "Behavior that triggers the keymap Combination 2.",
    default = "PRESS")
RNA_keyendvalue0 = RnaEnum("keyendvalue0", ENUMS_keymap_value,
    name = "End Value 1",
    description = "Behavior that triggers the keymap Combination 1.",
    default = "RELEASE")
RNA_keyendvalue1 = RnaEnum("keyendvalue1", ENUMS_keymap_value,
    name = "End Value 2",
    description = "Behavior that triggers the keymap Combination 2.",
    default = "RELEASE")
RNA_keyexact0 = RnaBool("keyexact0",
    name = "Is Exact 1",
    description = "When set to True, Keymap 1 will trigger when the number of keys pressed equals the key combination.")
RNA_keyexact1 = RnaBool("keyexact1",
    name = "Is Exact 2",
    description = "When set to True, Keymap 2 will trigger when the number of keys pressed equals the key combination.")
RNA_keyduration0 = RnaFloat('keyduration0',
    name = "Duration 1",
    description = "Used for Keymap 1 value in (Double Press, Double Release, Hold)",
    default = 0.3,
    hard_min = 0.0,
    hard_max = 9.0)
RNA_keyduration1 = RnaFloat('keyduration1',
    name = "Duration 2",
    description = "Used for Keymap 2 value in (Double Press, Double Release, Hold)",
    default = 0.3,
    hard_min = 0.0,
    hard_max = 9.0)
RNA_header_button = RnaButton("header_button",
    name = "Header Button",
    button_text = "",
    description = "Settings Editor header button.")
RNA_header_media_text = RnaString("header_media_text",
    name = "Directory Path",
    description = "Path of directory in Settings Editor")
RNA_text_search = RnaString("text_search",
    name = "Search Text",
    description = "Search for properties in the Settings Editor.")
RNA_use_search_id = RnaBool("use_search_id",
    name = "Include ID",
    description = "Search properties from identifier.")
RNA_use_search_name = RnaBool("use_search_name",
    name = "Include Name",
    description = "Search properties from name.")
RNA_use_search_description = RnaBool("use_search_description",
    name = "Include Description",
    description = "Search properties from description.")
RNA_use_search_cat_pref = RnaBool("use_search_cat_pref",
    name = "Include General Properties",
    description = "Search Properties by general category.")
RNA_use_search_cat_pref_color = RnaBool("use_search_cat_pref_color",
    name = "Include Color Properties",
    description = "Search properties by color category.")
RNA_use_search_cat_pref_size = RnaBool("use_search_cat_pref_size",
    name = "Include Size Properties",
    description = "Search properties by size category.")
RNA_use_search_cat_pref_keymap = RnaBool("use_search_cat_pref_keymap",
    name = "Include Keymap Properties",
    description = "Search properties by keymap category.")
RNA_use_search_cat_pref_apps = RnaBool("use_search_cat_pref_apps",
    name = "Include Editor Properties",
    description = "Search properties by editor category.")
RNA_about = RnaString("about",
    name = "About",
    description = "Info",
    default = "",
    is_readonly = True)
RNA_md_lib_refresh = RnaButton("md_lib_refresh",
    name = "Refresh",
    button_text = "Update Library",
    description = "Update library paths")
RNA_md_lib_edit = RnaButton("md_lib_edit",
    name = "Modifier Library Paths",
    button_text = "Edit Directories",
    description = "Edit library paths")
RNA_ui_scale_100 = RnaButton("ui_scale_100",
    name = "UI Scale 1.0",
    button_text = "Set UI Scale to 1.0",
    description = "Set add-on UI Scale to 1.0")
RNA_ui_scale_133 = RnaButton("ui_scale_133",
    name = "UI Scale 1.33",
    button_text = "Set UI Scale to 1.33",
    description = "Set add-on UI Scale to 1.33")
RNA_ui_scale_166 = RnaButton("ui_scale_166",
    name = "UI Scale 1.66",
    button_text = "Set UI Scale to 1.66",
    description = "Set add-on UI Scale to 1.66")
RNA_ui_scale_200 = RnaButton("ui_scale_200",
    name = "UI Scale 2.0",
    button_text = "Set UI Scale to 2.0",
    description = "Set add-on UI Scale to 2.0")
RNA_pref_export = RnaButton("pref_export",
    name = "Export Preference Settings",
    button_text = "Copy to Clipboard",
    description = "Export Add-on Preference Settings")


def r_about():
    addon_version = ".".join(str(e)  for e in BL_INFO["version"])
    if BL_INFO["version"][-1] == 0: addon_version += " (Alpha)"

    return f'''Information
        Blender Version :  {bpy.app.version_string}
        Addon Version :  {BL_INFO["name"]} {addon_version}
        Description :  {BL_INFO["description"]}

        Blender Market :\n                https://blendermarket.com/products/vmdesk
        GitHub :\n                https://github.com/Iiispace/vmdesk
        \nBug Report
        Blender Market :\n                https://blendermarket.com/products/vmdesk
        E-mail :\n                oorcer@gmail.com
    '''
    #|


## _file_ ##
def _import_():
    # //* 0areas_SettingEditor_import_blg
    # *// =|
    # <<< 1copy (0areas_SettingEditor_import_blg,, $$)
    global FONT0,D_SIZE,SIZE_widget,SIZE_border,SIZE_dd_border,SIZE_setting_list_border,SIZE_block,SIZE_button,COL_box_setting_list_fg,COL_block_fg_info,COL_box_text,COL_box_text_rim,COL_box_text_fg,COL_box_text_active
    # >>>
    # <<< 1copy (0areas_SettingEditor_import_blg,, ${'global': 'from ... utilbl.blg import'}$)
    from ... utilbl.blg import FONT0,D_SIZE,SIZE_widget,SIZE_border,SIZE_dd_border,SIZE_setting_list_border,SIZE_block,SIZE_button,COL_box_setting_list_fg,COL_block_fg_info,COL_box_text,COL_box_text_rim,COL_box_text_fg,COL_box_text_active
    # >>>

    # //* 0areas_SettingEditor_import_m
    # *// =|
    # <<< 1copy (0areas_SettingEditor_import_m,, $$)
    global P,Admin,W_HEAD,update_data,save_pref,upd_size,LibraryModifier
    # >>>
    # <<< 1copy (0areas_SettingEditor_import_m,, ${'global': 'from ... m import'}$)
    from ... m import P,Admin,W_HEAD,update_data,save_pref,upd_size,LibraryModifier
    # >>>

    global P_BL_RNA_PROPS, P_SIZE_BL_RNA_PROPS, P_COLOR_BL_RNA_PROPS, P_KEYMAPS_BL_RNA_PROPS
    P_BL_RNA_PROPS = r_collection_create(
        [rna  for idd, rna in P.bl_rna.properties.items() if idd not in {
        'bl_idname', 'name', 'rna_type', 'refresh', 'de'} and rna.type != "POINTER"]
    )
    P_SIZE_BL_RNA_PROPS = r_collection_create(
        [rna  for idd, rna in P.size.bl_rna.properties.items() if idd not in {
        'bl_idname', 'name', 'rna_type'} and rna.type != "POINTER"]
    )
    P_COLOR_BL_RNA_PROPS = r_collection_create(
        [rna  for idd, rna in P.color.bl_rna.properties.items() if idd not in {
        'bl_idname', 'name', 'rna_type'} and rna.type != "POINTER"]
    )
    P_KEYMAPS_BL_RNA_PROPS = r_collection_create(
        [rna  for idd, rna in P.keymaps.bl_rna.properties.items() if idd not in {
        'bl_idname', 'name', 'rna_type'} and rna.type != "POINTER"]
    )

    global DropDownText, DropDownString
    from ... dd import DropDownText, DropDownString

    global KeymapEditor, P_SettingEditor
    from . ed import KeymapEditor

    P_SettingEditor = P.SettingEditor
    #|
