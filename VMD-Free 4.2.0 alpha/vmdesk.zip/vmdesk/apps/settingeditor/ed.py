# from blf import size as blfSize
from blf import dimensions as blfDimen
from math import floor

from ... win import Window
from ... utilbl import blg
from ... util.types import RnaString, LocalHistory
from ... keysys import (
    kill_evt_except,
    MOUSE,
    EVT_TYPE,
    TRIGGER,
    TRIGGER_END,
    TRIGGER_IND,
    KEYMAPS,
    r_keyinfo,
    r_keyrepeatinfo)
from ... area import AreaBlockSimple
from ... block import BlockFull, ButtonStringXYRead, PREF_HISTORY
from ... utilbl.blg import report

from . areas import AreaSettingHeader, AreaSettingList, AreaBlockTabSettingEditor, AreaKeymapCatch


LONGEST_TITLE = "Color: Window Title Close Button Hover Hold"

## _editor_ ##
class SettingEditor(Window):
    __slots__ = 'active_tab'

    name = 'Settings'

    # //* 0ed_SettingEditor_AREAIND_header
    # *//
    # //* 0ed_SettingEditor_AREAIND_data
    # *//

    def fin_callfront(self):
        self.areas[
            # <<< 1copy (0ed_SettingEditor_AREAIND_header,, $$)
            0
            # >>>
        ].local_tabhistory.kill()
        #|

    def init(self, boxes, blfs):
        self.active_tab = ("system",)

        # /* 0ed_SettingEditor_init
        border_outer = SIZE_border[0]
        border_inner = SIZE_border[1]
        widget_rim = SIZE_border[3]
        border = SIZE_dd_border[0]
        L0 = self.box_win.L + border_outer
        T0 = self.box_win.title_B - border_outer
        B0 = T0 - border - border - D_SIZE['widget_full_h']
        T1 = B0 - border_inner

        BB = T1 - P.SettingEditor.area_height * SIZE_widget[0] - (border + widget_rim + widget_rim) * 2
        d2 = (SIZE_dd_border[0] + widget_rim + widget_rim) * 2
        offset_x = SIZE_block[1] + D_SIZE['font_main_dx']
        # */

        area1 = AreaSettingList(self, L0, T1) # set_size already
        L1 = area1.box_area.R + border_inner
        RR = L1 + d2 + offset_x * 2 + SIZE_widget[0] + floor(blfDimen(FONT0, LONGEST_TITLE)[0]
            ) + SIZE_block[2] + D_SIZE['widget_width']

        self.areas = [
            AreaSettingHeader(self, L0, RR, B0, T0),
            area1,
            AreaBlockTabSettingEditor(self, L1, RR, BB, T1)
        ]
        self.areas[0].history_init()
        self.areas[2].init_tab(self.active_tab, push=False)
        #|
    def upd_size_areas(self):
        # a2 = self.areas[2]
        # if hasattr(a2, "upd_size_fix_canvas_init"): a2.upd_size_fix_canvas_init()

        # <<< 1copy (0ed_SettingEditor_init,, $$)
        border_outer = SIZE_border[0]
        border_inner = SIZE_border[1]
        widget_rim = SIZE_border[3]
        border = SIZE_dd_border[0]
        L0 = self.box_win.L + border_outer
        T0 = self.box_win.title_B - border_outer
        B0 = T0 - border - border - D_SIZE['widget_full_h']
        T1 = B0 - border_inner

        BB = T1 - P.SettingEditor.area_height * SIZE_widget[0] - (border + widget_rim + widget_rim) * 2
        d2 = (SIZE_dd_border[0] + widget_rim + widget_rim) * 2
        offset_x = SIZE_block[1] + D_SIZE['font_main_dx']
        # >>>

        self.areas[1].upd_size(L0, T1)
        L1 = self.areas[1].box_area.R + border_inner
        RR = L1 + d2 + offset_x * 2 + SIZE_widget[0] + floor(blfDimen(FONT0, LONGEST_TITLE)[0]
            ) + SIZE_block[2] + D_SIZE['widget_width']

        self.areas[0].upd_size(L0, RR, B0, T0)
        self.areas[2].upd_size(L1, RR, BB, T1)

        # if hasattr(a2, "upd_size_fix_canvas_end"): a2.upd_size_fix_canvas_end()
        #|

    def evt_redo(self):

        kill_evt_except()
        if PREF_HISTORY.index + 1 >= len(PREF_HISTORY.array):
            report('Currently in last step')
            return

        try:
            PREF_HISTORY.index += 1
            his = PREF_HISTORY.array[PREF_HISTORY.index]
            his.set_value(his.value_to)
            report(f'Redo {his.info} | value to: {his.value_to}')
        except Exception as e:

            report('Unexpected error, please report to the author')
        #|
    def evt_undo(self):

        kill_evt_except()
        his = PREF_HISTORY.array[PREF_HISTORY.index]
        if PREF_HISTORY.index == 0:
            report('Currently in first step')
            return
        try:
            his.set_value(his.value_from)
            PREF_HISTORY.index -= 1
            report(f'Undo {his.info} | value from: {his.value_from}')
        except Exception as e:

            report('Unexpected error, please report to the author')
        #|
    #|
    #|


class KeymapEditor(Window):
    __slots__ = 'keyinfo', 'km', 'keyinfo_check_repeat'

    name = 'Keymap'

    # //* 0ed_KeymapEditor_AREAIND_info
    # *//
    # //* 0ed_KeymapEditor_AREAIND_catch
    # *//
    # //* 0ed_KeymapEditor_AREAIND_info_check_repeat
    # *//

    def init(self, boxes, blfs):
        # /* 0ed_KeymapEditor_init
        editor_width = round(D_SIZE["widget_width"] * 3.731)
        row_count_info = 8
        row_count_info_check_repeat = 4
        border_outer = SIZE_border[0]
        border_inner = SIZE_border[1]
        widget_rim = SIZE_border[3]
        border = SIZE_dd_border[0]
        LL = self.box_win.L + border_outer
        T0 = self.box_win.title_B - border_outer
        RR = LL + editor_width
        B0 = T0 - (border + widget_rim + widget_rim) * 2 - SIZE_widget[0] * row_count_info
        T1 = B0 - border_inner
        B1 = T1 - AreaKeymapCatch.r_height(None, None)
        T2 = B1 - border_inner
        B2 = T2 - (border + widget_rim + widget_rim) * 2 - SIZE_widget[0] * row_count_info_check_repeat
        # */

        kw = Window.INIT_DATA
        trigger_id = kw["trigger_id"]
        trigger_index = kw["trigger_index"]
        self.km = KEYMAPS[trigger_id]

        self.keyinfo = r_keyinfo(P.keymaps.bl_rna.properties[trigger_id], trigger_id, trigger_index)
        self.keyinfo_check_repeat = ""

        a0b0 = ButtonStringXYRead(None, RNA_keyinfo, self)
        a0b0.row_count = row_count_info
        a2b0 = ButtonStringXYRead(None, RNA_keyinfo_check_repeat, self)
        a2b0.row_count = row_count_info_check_repeat

        a0 = AreaBlockSimple(self, LL, RR, B0, T0)
        a1 = AreaKeymapCatch(self, LL, RR, B1, T1, trigger_id, trigger_index)
        a2 = AreaBlockSimple(self, LL, RR, B2, T2)
        a0.items += [BlockFull(a0, a0b0)]
        a2.items += [BlockFull(a2, a2b0)]
        self.areas = [a0, a1, a2]
        a0.init_draw_range()
        a2.init_draw_range()
        #|
    def upd_size_areas(self):
        # <<< 1copy (0ed_KeymapEditor_init,, $$)
        editor_width = round(D_SIZE["widget_width"] * 3.731)
        row_count_info = 8
        row_count_info_check_repeat = 4
        border_outer = SIZE_border[0]
        border_inner = SIZE_border[1]
        widget_rim = SIZE_border[3]
        border = SIZE_dd_border[0]
        LL = self.box_win.L + border_outer
        T0 = self.box_win.title_B - border_outer
        RR = LL + editor_width
        B0 = T0 - (border + widget_rim + widget_rim) * 2 - SIZE_widget[0] * row_count_info
        T1 = B0 - border_inner
        B1 = T1 - AreaKeymapCatch.r_height(None, None)
        T2 = B1 - border_inner
        B2 = T2 - (border + widget_rim + widget_rim) * 2 - SIZE_widget[0] * row_count_info_check_repeat
        # >>>

        self.areas[0].upd_size(LL, RR, B0, T0)
        self.areas[1].upd_size(LL, RR, B1, T1)
        self.areas[2].upd_size(LL, RR, B2, T2)
        #|

    def update_keymap_info(self):
        km = self.km
        a = self.areas[
            # <<< 1copy (0ed_KeymapEditor_AREAIND_catch,, $$)
            1
            # >>>
        ]
        self.keyinfo = r_keyinfo(P.keymaps.bl_rna.properties[a.trigger_id], a.trigger_id, a.trigger_index)
        self.areas[
            # <<< 1copy (0ed_KeymapEditor_AREAIND_info,, $$)
            0
            # >>>
        ].items[0].upd_data()
        #|
    def update_repeat_info(self, keycatch_list, current_id_index=None):
        self.keyinfo_check_repeat = r_keyrepeatinfo(keycatch_list, current_id_index)
        self.areas[
            # <<< 1copy (0ed_KeymapEditor_AREAIND_info_check_repeat,, $$)
            2
            # >>>
        ].items[0].upd_data()
        #|
    #|
    #|


RNA_keyinfo = RnaString("keyinfo",
    name = "Keymap Info",
    description = "KeyMap Information.",
    subtype = "LINES",
    is_readonly = True)
RNA_keyinfo_check_repeat = RnaString("keyinfo_check_repeat",
    name = "Keymap Conflict Info",
    description = "KeyMap Conflict Information.",
    subtype = "LINES",
    is_readonly = True)


## _file_ ##
def _import_():
    #|
    # /* 0ed_SettingEditor_import_blg
    global FONT0, D_SIZE, SIZE_widget, SIZE_border, SIZE_dd_border, SIZE_block
    # */
    # <<< 1copy (0ed_SettingEditor_import_blg,, ${'global': 'from ... utilbl.blg import'}$)
    from ... utilbl.blg import FONT0, D_SIZE, SIZE_widget, SIZE_border, SIZE_dd_border, SIZE_block
    # >>>

    # /* 0ed_SettingEditor_import_m
    global P
    # */
    # <<< 1copy (0ed_SettingEditor_import_m,, ${'global': 'from ... m import'}$)
    from ... m import P
    # >>>
    #|
