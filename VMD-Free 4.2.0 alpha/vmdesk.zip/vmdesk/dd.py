import bpy

from blf import size as blfSize
from blf import color as blfColor
from blf import position as blfPos
from blf import draw as blfDraw
from blf import dimensions as blfDimen
from gpu.state import active_framebuffer_get, blend_set
from math import floor
from colorsys import rgb_to_hsv, hsv_to_rgb
from tempfile import mkdtemp
from os.path import join as os_path_join

from . colorlist import L_rgb_to_glc, glc_to_hex, D_glc_null, NULL_INFO
from . utilbl import blg
from . util.const import FLO_0000, TUP_RGBA, TUP_HSV, TUP_HEX
from . util.types import (
    Name,
    IdentifierNameValue,
    RnaFloatVector,
    RnaString,
    RnaButton,
    RnaEnum,
    BoxGroup,
    Udraw)
from . util.com import value_to_display, is_value, N, bin_search
from . util.deco import successResult
from . util.dirlib import del_folder
from . utilbl.general import update_scene_push
from . utilbl.md import (
    ops_mds_copy_to_object,
    md_rnas_MESH,
    md_rnas_CURVE,
    md_rnas_SURFACE,
    md_rnas_VOLUME,
    md_rnas_LATTICE)
from . keysys import (
    kill_evt,
    kill_evt_except,
    MOUSE,
    MOUSE_WINDOW,
    EVT_TYPE,
    TRIGGER,
    r_end_trigger,
    ITEMS_CALC_TAB,
    rm_get_info_km)
from . win import DropDown, r_full_protect_dxy, Head
from . area import (
    AreaFilterY,
    AreaValBox,
    AreaBlock1,
    AreaString,
    AreaStringXY,
    AreaBlockSimple,
    AreaBlockTab,
    AreaColorHue)
from . block import (
    BlockCalcDisplay,
    BlockCalcButton,
    BlockR,
    BlockFull,
    ButtonFloatVector,
    ButtonSep,
    ButtonString,
    ButtonFn,
    ButtonFnFreeSize,
    ButtonFnImg,
    ButtonSplit,
    GnVector,
    D_gn_subtype_unit,
    RNA_button_keyframe,
    ButtonFnImgHoverKeyframe,
    ButtonEnumXYTemp)
from . utilbl.blg import (
    Blf,
    BlfColor,
    BlfClip,
    GpuBox,
    GpuRim,
    GpuDropDown,
    GpuDropDownRim,
    GpuShadowDropDown,
    GpuImgNull,
    GpuImgUtil,
    GpuImg_NODETREE,
    GpuImg_OUTLINER_OB_UNKNOW,
    GpuImg_driver_true,
    GpuImg_keyframe_next_false_even,
    GpuImg_keyframe_next_false_odd,
    GpuImg_keyframe_current_true_even,
    GpuImg_keyframe_current_true_odd,
    GpuImg_keyframe_false,
    r_blf_clipping_end,
    Scissor,
    report)



class ButtonFloatVectorColor(ButtonFloatVector):
    __slots__ = 'update_callback', 'callback_enable'

    def set(self, v, index, refresh=True, undo_push=True):
        super().set(v, index, refresh)
        self.upd_data()
        if self.callback_enable: self.update_callback()
        #|
    #|
    #|
class GnVectorColor(GnVector):
    __slots__ = 'update_callback', 'callback_enable'

    def __init__(self, w, rna, pp, step=1.0, subtype_override=None):
        self.w = w
        self.rna = rna
        self.step = step
        self.unit = "NONE"

        self.r_pp, self.r_object, self.r_datapath_head = pp
        self.pp = self.r_pp()

        self.box_button = GpuRim(COL_box_val, COL_box_val_rim)
        self.box_active = GpuBox(COL_box_val_fo)

        self.text_format = D_format[self.unit]

        vv = self.get()
        self.array_length = len(vv)
        self.blf_value = [BlfClip(self.text_format(v), v)  for v in vv]
        self.blf_value[0].color = COL_box_val_fg

        self.draw_blf = self.i_draw_blf_subtype
        self.dxy = self.i_dxy_subtype
        self.blf_subtype = [Blf(tx)  for _, tx in zip(vv, subtype_override)]
        self.blf_subtype[0].color = COL_box_button_fg_info

        self.draw_box = self.i_draw_box
        self.active_index = None
        #|

    def evt_undo_push(self, undo_push, oldvalue): pass

    def set(self, v, index, refresh=True, undo_push=True):
        super().set(v, index, refresh)
        self.upd_data()
        if self.callback_enable: self.update_callback()
        #|
    #|
    #|
class ButtonStringColorHex(ButtonString):
    __slots__ = 'set_callfront'

    def set(self, v, refresh=True, undo_push=True):
        self.set_callfront(v.strip().replace(" ", "").replace("0x", "").replace("#", ""))
        #|
    #|
    #|

class AreaFilterYDropDownRMKeymap(AreaFilterY):
    __slots__ = ()

    def i_modal_dd_filt_submodal(self, i):
        if TRIGGER['rm']():
            self.fn_filt_rm(i)
            return True
        if TRIGGER['rm_km_change']():
            if i != None and i < len(self.filt.match_items):
                if self.filt.match_items[i].identifier in BL_RNA_PROP_keymaps:
                    self.evt_km_change(self.filt.match_items[i].identifier)
                    return True
        if TRIGGER['rm_km_toggle']():
            self.evt_km_toggle()
            return True
        return False
        #|

    def evt_km_change(self, identifier):

        id_class = "SettingEditor"
        w = D_EDITOR[id_class](id_class=id_class, use_pos=False, use_fit=False)
        a = w.areas[2]
        a.init_tab(("search",))
        w.upd_data()
        a.items[0].buttons[0].evt_toggle_match_whole_word(True)
        a.items[0].buttons[0].set(identifier)
        items = a.items[0].items
        items[0].button0.set(False)
        items[1].button0.set(True)
        items[2].button0.set(False)
        items[4].button0.set(False)
        items[5].button0.set(False)
        items[6].button0.set(False)
        items[7].button0.set(False)
        items[8].button0.set(True)

        for e in W_DRAW.copy():
            if e.__class__.__name__.find("DropDown") != -1:
                bring_draw_to_top_safe(e)
        #|
    def evt_km_toggle(self):

        kill_evt_except()
        Admin.REDRAW()
        filt = self.filt
        filt.get_info = rm_get_info_km  if filt.get_info == None else None
        filt.filter_text(self.blf_text.text, filt.active_index)
        #|
    def fn_filt_rm(self, i):
        self.kill_push_timer()

        items = []
        if i != None and i < len(self.filt.match_items):
            if self.filt.match_items[i].identifier in BL_RNA_PROP_keymaps:
                items.append(("rm_km_change", lambda: self.evt_km_change(self.filt.match_items[i].identifier)))

        items.append(("rm_km_toggle", self.evt_km_toggle))

        DropDownRMKeymap(self, MOUSE, items)
        #|
    #|
    #|


class DropDownTask(DropDown):
    __slots__ = ()

    def __init__(self, w, pos, items, title):
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0

        size = (SIZE_widget[0] * 16 + d0x2,
            d0x2 + d1 + (SIZE_filter[2] + SIZE_border[3]) * 2 + max(SIZE_filter[0], D_SIZE['widget_full_h']))

        super().__init__(w=w, pos=pos, size=size, use_titlebar=True, title=title, items=items)

        self.areas[0].to_modal_dd()
        #|
    def init(self, boxes, blfs):

        init = DropDown.INIT_DATA
        L = self.box_win.L
        T = self.box_win.title_B
        items = init['items']
        size_x, size_y = init['size']

        self.areas = [AreaFilterY(self, L, L + size_x, T - size_y, T, lambda: items, is_dropdown=True)]
        #|

    def fin_callback(self):

        #|
        if self.data["use_text_output"] != None:

            filt = self.areas[0].filt
            tx = self.areas[0].blf_text.unclip_text
            if filt.active_index != None:
                e = filt.match_items[filt.active_index]
                if e.name == tx:
                    w = e.value

                    if w in W_MODAL:
                        if W_MODAL[-1] == w: m.ADMIN.evt_min(w)
                        else: bring_to_front(w)
                    else:
                        m.ADMIN.evt_unmin(w)
        #|
    #|
    #|

class DropDownRM(DropDown):
    __slots__ = ()

    def __init__(self, w, pos, items,
                get_icon = None,
                get_info = None,
                title = "Context Menu",
                size_x = None,
                size_y = None,
                input_text = ""):
        #|
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        blfSize(FONT0, D_SIZE['font_main'])

        if size_x == None:
            size_x = max(SIZE_widget[0] * 12, min(REGION_DATA.R - REGION_DATA.L,
                SIZE_widget[0] + d0x2 + D_SIZE['font_main_dx'] * 2 + floor(max(
                    blfDimen(FONT0, e.name)[0]  for e in items))))
        if size_y == None:
            size_y = min(REGION_DATA.T - REGION_DATA.B - SIZE_tb[0] - SIZE_title[1],
                d0x2 + d1 + (SIZE_filter[2] + SIZE_border[3]) * 2 + (len(items) + 1) * D_SIZE['widget_full_h'])

        super().__init__(w=w, pos=pos, size=(size_x, size_y), use_titlebar=True, title=title,
            items=items, get_icon=get_icon, get_info=get_info, input_text=input_text)

        self.areas[0].to_modal_dd()
        #|
    def init(self, boxes, blfs):

        init = DropDown.INIT_DATA
        L = self.box_win.L
        T = self.box_win.title_B
        size_x, size_y = init['size']
        items = init['items']

        self.areas = [AreaFilterY(self, L, L + size_x, T - size_y, T, lambda: items,
            get_icon = init['get_icon'],
            get_info = init['get_info'],
            input_text = init['input_text'],
            is_dropdown = True)]
        #|

    def fin_callback(self):

        #|
        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        if data["use_text_output"] != None:

            if data["use_text_output"]:
                if P.adaptive_rm_output:
                    if self.areas[0].blf_text.unclip_text.strip():
                        if data["best_item"] != None: data["best_item"].value()
            else:
                if data["best_item"] != None: data["best_item"].value()

        data.clear()
        #|
    #|
    #|
class DropDownRMKeymap(DropDownRM):
    __slots__ = ()

    def __init__(self, w, pos, lis_id_fn,
                title="Context Menu",
                fin_callfront=None,
                override_name=None):

        get_info = rm_get_info_km  if P.show_rm_keymap else None

        if override_name is None:
            super().__init__(w, pos,
                [IdentifierNameValue(idd, (BL_RNA_PROP_keymaps[idd].name  if idd in BL_RNA_PROP_keymaps else idd
                    ), fx)  for idd, fx in lis_id_fn],
                get_icon=None, get_info=get_info, title=title)
        else:
            super().__init__(w, pos,
                [IdentifierNameValue(idd, ((override_name[idd]  if idd in override_name else BL_RNA_PROP_keymaps[idd].name
                    )  if idd in BL_RNA_PROP_keymaps else idd
                    ), fx)  for idd, fx in lis_id_fn],
                get_icon=None, get_info=get_info, title=title)

        if fin_callfront is not None: self.data["fin_callfront"] = fin_callfront
        self.areas[0].__class__ = AreaFilterYDropDownRMKeymap
        #|
    #|
    #|
class DropDownString(DropDown):
    __slots__ = ()

    def __init__(self, w, LRBT, input_text):
        d0 = SIZE_dd_border[0]
        # d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        LL, RR, BB, TT = LRBT

        size = RR - LL + d0x2, TT - BB + d0x2

        super().__init__(w=w, pos=(LL - d0, TT + d0), size=size, use_titlebar=False, protect_pos=False,
            input_text=input_text)

        self.areas[0].to_modal_dd()
        #|
    def init(self, boxes, blfs):

        init = DropDown.INIT_DATA
        L = self.box_win.L
        T = self.box_win.title_B
        size_x, size_y = init['size']

        self.areas = [AreaString(self, L, L + size_x, T - size_y, T, input_text=init['input_text'])]
        #|

    def fin_callback(self):

        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        w = self.w
        is_readonly = hasattr(w, "rna") and hasattr(w.rna, "is_readonly") and w.rna.is_readonly

        if data["use_text_output"] == None or is_readonly: pass
        else:

            try: w.set(self.areas[0].blf_text.unclip_text)
            except: report("Value Error")

        data.clear()
        #|
    #|
    #|
class DropDownStringXY(DropDown):
    __slots__ = ()

    def __init__(self, w, LRBT, input_text, font_id=None, killevt=True, select_all=None):
        d0 = SIZE_dd_border[0]
        # d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        LL, RR, BB, TT = LRBT

        super().__init__(w=w,
            pos = (LL - d0, TT + d0),
            size = (RR - LL + d0x2, TT - BB + d0x2),
            use_titlebar = False,
            protect_pos = False,
            killevt = killevt,
            input_text = input_text,
            font_id = FONT0  if font_id is None else font_id)

        self.areas[0].to_modal_dd(select_all=select_all)
        #|
    def init(self, boxes, blfs):

        #|
        init = DropDown.INIT_DATA
        L = self.box_win.L
        T = self.box_win.title_B
        size_x, size_y = init['size']

        self.areas = [AreaStringXY(self, L, L + size_x, T - size_y, T,
            input_text = init['input_text'],
            font_id = init['font_id'])]
        #|

    def fin_callback(self):

        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        w = self.w
        is_readonly = hasattr(w, "rna") and hasattr(w.rna, "is_readonly") and w.rna.is_readonly

        if is_readonly: pass
        elif data["use_text_output"] == None:
            w.b_str = None
            w.upd_data()
        else:

            try:
                w.set(self.areas[0].text)
            except:
                report("Value Error")

        data.clear()
        #|
    #|
    #|
class DropDownText(DropDown):
    __slots__ = 'save_confirm_message', 'confirm_fn', 'r_default_value'

    def __init__(self, w, LRT, input_text, confirm_fn, r_default_value,
                row_count = 28,
                font_id = None,
                killevt = True,
                title = "Text Editor",
                save_confirm_message = "\n    It will save all preferences.\n    This process cannot be Undo/Redo.\n    Do you want to continue?",
                title_buttons = None):

        self.confirm_fn = confirm_fn
        self.r_default_value = r_default_value
        self.save_confirm_message = save_confirm_message

        d0 = SIZE_dd_border[0]
        # d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        line_h = SIZE_widget[0]
        widget_rim = SIZE_border[3]
        LL, RR, TT = LRT
        BB = TT - row_count * line_h - widget_rim - widget_rim
        inner = SIZE_title[1] // 20
        button_h = SIZE_title[1] - inner - inner - widget_rim - widget_rim
        button_font_size = floor(button_h * SIZE_foreground[2])
        button_save = ButtonFnFreeSize(None, RNA_save, self.bufn_save, button_font_size, button_h)
        button_reset = ButtonFnFreeSize(None, RNA_reset, self.bufn_reset, button_font_size, button_h)
        title_button = [
            ("close", self.fin_from_area),
            (button_save, button_save.r_override_width()),
            (button_reset, button_reset.r_override_width())]
        if title_buttons is not None:
            for e in title_buttons:
                o = ButtonFnFreeSize(None, e[0], e[1], button_font_size, button_h)
                title_button.append((o, o.r_override_width()))

        super().__init__(w=w,
            pos = (LL - d0, TT + d0),
            size = (RR - LL + d0x2, TT - BB + d0x2),
            use_titlebar = True,
            protect_pos = True,
            killevt = killevt,
            input_text = input_text,
            row_count = row_count,
            font_id = FONT1  if font_id is None else font_id,
            title = title,
            title_button = title_button
        )

        self.data['input_text'] = input_text
        self.areas[0].to_modal_dd(select_all=False, modal_type="i_modal_dd_editor_protect")
        #|
    def init(self, boxes, blfs):

        #|
        init = DropDown.INIT_DATA
        L = self.box_win.L
        T = self.box_win.title_B
        size_x, size_y = init['size']

        self.areas = [AreaStringXY(self, L, L + size_x, T - size_y, T,
            input_text = init['input_text'],
            font_id = init['font_id'])]
        #|

    def fin_callback(self):

        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        data.clear()
        #|
    def bufn_save(self):

        self.areas[0].kill_push_timer()

        if self.save_confirm_message:
            DropDownYesNo(self, MOUSE, self.set_state_to_confirm_and_check, input_text=self.save_confirm_message)
        else:
            self.set_state_to_confirm_and_check()
        #|
    def bufn_reset(self):

        Admin.REDRAW()
        a0 = self.areas[0]
        a0.evt_select_all()
        a0.beam_input(self.r_default_value())
        a0.kill_push_timer()
        #|
    def set_state_to_confirm_and_check(self):
        exc = self.confirm_fn(self.areas[0].bl_text.as_string())
        if exc:
            DropDownOk(self, MOUSE, input_text=f'{exc}', width_fac=3.0)
        else:
            self.areas[0].evt_cancel()
        #|
    def fin_from_area(self):
        if self.data['input_text'] == self.areas[0].bl_text.as_string(): self.areas[0].evt_cancel()
        else:
            DropDownYesNo(self, MOUSE, self.areas[0].evt_cancel,
                input_text="\n    There are unsaved changes.\n    Do you want to close?")
        #|
    #|
    #|
class DropDownEnum(DropDownRM):
    __slots__ = 'write_text'

    def __init__(self, w, LRBT, title,
                items = None,
                input_text = "",
                fixed_width = False,
                write_text = None,
                get_icon = None,
                get_info = None):

        self.write_text = write_text
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        pos = (LRBT[0] - d0, LRBT[3] + d0 + SIZE_title[1])
        size_x = LRBT[1] - LRBT[0] + d0x2  if fixed_width else None

        if items != None:
            if items:
                if hasattr(w, "get"):
                    if hasattr(items, "find"):
                        index = items.find(w.get())
                    else:
                        ob = w.get()
                        try:
                            index = next(i  for i, e in enumerate(items)  if e == ob)
                        except:
                            index = -1
                else:
                    index = -1
            else:
                items = [Name("")]
                index = -1
        elif hasattr(w, "rna") and hasattr(w.rna, "enum_items"):
            items = [Name(e.name)  for e in w.rna.enum_items]
            index = w.rna.enum_items.find(w.get())
        else:
            items = [Name("")]
            index = -1

        size_y = min(LRBT[3] - REGION_DATA.B - SIZE_tb[0],
            d0x2 + d1 + (SIZE_filter[2] + SIZE_border[3]) * 2 + (len(items) + 1) * D_SIZE['widget_full_h'])

        super().__init__(w, pos, items, size_x=size_x, size_y=size_y, title=title, input_text=input_text,
            get_icon=get_icon, get_info=get_info)
        if index != -1:
            self.areas[0].filt.set_active_index(index)
        #|

    def fin_callback(self):

        #|
        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        if data["use_text_output"] != None:

            if data["use_text_output"]:
                tx = self.areas[0].blf_text.unclip_text
            else:
                if data["best_item"] == None:
                    tx = self.areas[0].blf_text.unclip_text
                else:
                    tx = data["best_item"].name

            w = self.w
            if hasattr(w, "rna") and hasattr(w.rna, "enum_items"): write_fn = self.write_enum
            else: write_fn = self.write_string

            try:
                if self.write_text == None: write_fn(tx)
                else: self.write_text(tx, data["best_item"], data["use_text_output"])
            except: report("Value Error")

        data.clear()
        #|

    def write_string(self, tx):
        self.w.set(tx)
        #|
    def write_enum(self, tx):
        rna = self.w.rna
        if tx[ : 1] == ";" and tx.strip() == "None":
            self.w.set(None)
            return

        self.w.set(tx)
        #|
    #|
    #|
class DropDownEnumPointer(DropDownRM):
    __slots__ = 'preview_cache'

    def __init__(self, w, LRBT, title, all_objects,
                allow_types = None,
                r_except_objects = None,
                items = None,
                input_text = "",
                fixed_width = False,
                get_icon = None,
                get_info = None):

        except_objects = set()  if r_except_objects == None else r_except_objects()
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        pos = (LRBT[0] - d0, LRBT[3] + d0 + SIZE_title[1])
        size_x = LRBT[1] - LRBT[0] + d0x2  if fixed_width else None

        if allow_types == None:
            items = [ob  for ob in all_objects  if ob not in except_objects]
        else:
            items = [ob  for ob in all_objects  if ob.type in allow_types and ob not in except_objects]

        if items:
            if hasattr(items, "find"):
                index = items.find(w.get())
            else:
                ob = w.get()
                try:
                    index = next(i  for i, e in enumerate(items)  if e == ob)
                except:
                    index = -1
        else:
            items = [Name("")]
            index = -1

        size_y = min(LRBT[3] - REGION_DATA.B - SIZE_tb[0],
            d0x2 + d1 + (SIZE_filter[2] + SIZE_border[3]) * 2 + (len(items) + 1) * D_SIZE['widget_full_h'])

        super().__init__(w, pos, items, size_x=size_x, size_y=size_y, title=title, input_text=input_text,
            get_icon=get_icon, get_info=get_info)
        if index != -1:
            self.areas[0].filt.set_active_index(index)
        #|

    def fin_callback(self):

        #|
        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        if hasattr(self, "preview_cache"): self.preview_cache.kill()

        if data["use_text_output"] != None:

            if data["use_text_output"]:
                tx = self.areas[0].blf_text.unclip_text
                objects = self.areas[0].filt.items
                ob = objects[tx]  if tx in objects else tx
            else:
                ob = data["best_item"]

            try: self.w.set(ob)
            except: report("Value Error")

        data.clear()
        #|
    #|
    #|
class DropDownEnumTexture(DropDownEnumPointer):
    __slots__ = ()

    def __init__(self, w, LRBT, title, all_objects,
                allow_types = None,
                r_except_objects = None,
                items = None,
                input_text = "",
                fixed_width = False):

        super().__init__(w, LRBT, title, all_objects,
            allow_types=allow_types,
            r_except_objects=r_except_objects,
            items=items,
            input_text=input_text,
            fixed_width=fixed_width,
            get_icon=None,
            get_info=get_info_users)
        #|

    #|
    #|
class DropDownEnumImage(DropDownEnumPointer):
    __slots__ = ()

    def __init__(self, w, LRBT, title, all_objects,
                allow_types = None,
                r_except_objects = None,
                items = None,
                input_text = "",
                fixed_width = False):

        self.preview_cache = PreviewCache(self, bpy.data.images)

        super().__init__(w, LRBT, title, all_objects,
            allow_types=allow_types,
            r_except_objects=r_except_objects,
            items=items,
            input_text=input_text,
            fixed_width=fixed_width,
            get_icon=self.preview_cache.get_icon,
            get_info=get_info_users)
        #|

    #|
    #|
class DropDownEnumMaterial(DropDownEnumPointer):
    __slots__ = ()

    def __init__(self, w, LRBT, title, all_objects,
                allow_types = None,
                r_except_objects = None,
                items = None,
                input_text = "",
                fixed_width = False):

        # self.preview_cache = PreviewCacheMaterial(self, bpy.data.materials)

        super().__init__(w, LRBT, title, all_objects,
            allow_types=allow_types,
            r_except_objects=r_except_objects,
            items=items,
            input_text=input_text,
            fixed_width=fixed_width,
            get_icon=None,
            get_info=get_info_users)
        #|

    #|
    #|

class DropDownValTab(DropDown):
    __slots__ = ()

    def __init__(self, w, block0, title="Calculator Tabs"):
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        box_text = block0.box_text
        blf_text = block0.blf_text
        filt = block0.filt

        size = ((box_text.R - box_text.L) * 2,
            d0x2 + d1 + (SIZE_filter[2] + SIZE_border[3]) * 2 + max(SIZE_filter[0], D_SIZE['widget_full_h']))

        super().__init__(w=w,
            pos = (box_text.L - d0, box_text.T + SIZE_title[1] + d0),
            size = size,
            use_titlebar = True,
            title = title,
            input_text = blf_text.unclip_text,
            items = filt.items)

        a = self.areas[0]
        a.to_modal_dd()
        a.evt_toggle_match_case(None, filt.match_case)
        a.evt_toggle_match_whole_word(None, filt.match_whole_word)
        a.evt_toggle_match_end(None, filt.match_end)
        #|
    def init(self, boxes, blfs):

        init = DropDown.INIT_DATA
        L = self.box_win.L
        T = self.box_win.title_B
        items = init['items']
        size_x, size_y = init['size']

        self.areas = [AreaFilterY(self, L, L + size_x, T - size_y, T, lambda: items,
            is_dropdown=True, input_text=init['input_text'])]
        #|

    def fin_callback(self):

        data = self.data

        if data["use_text_output"] != None:

            filt = self.areas[0].filt
            blf_text = self.areas[0].blf_text
            area_tab = self.w.w.area_tab
            area_tab.filt.match_end = filt.match_end
            area_tab.filt.match_whole_word = filt.match_whole_word
            area_tab.filt.match_case = filt.match_case

            area_tab.evt_area_del_text()
            area_tab.evt_area_paste(blf_text.unclip_text)
            area_tab.blf_text.text = ""
        #|
    #|
    #|
class DropDownVal(DropDown):
    __slots__ = 'area_textbox', 'area_display', 'area_button', 'area_tab', 'same_as_py_value', 'text_format'

    def __init__(self, w, LRBT, tx, py_val, rna, array_range=None, tab="Int"):

        self.same_as_py_value = True
        self.text_format = w.text_format  if hasattr(w, "text_format") else None

        if isinstance(rna.hard_min  if hasattr(rna, "hard_min") else rna.min_value, int):
            input_text = value_to_display(py_val)
        else:
            rna_unit = rna.unit  if hasattr(rna, "unit") else D_gn_subtype_unit[rna.subtype]
            unit_factor = r_unit_factor(rna_unit, self.text_format)
            if unit_factor != 1.0:
                self.same_as_py_value = False
                py_val /= unit_factor

            input_text = value_to_display(py_val)
            if rna_unit == "ROTATION":
                tab = "Radians"  if unit_factor == 1.0 else "Degrees"
            else:
                tab = "Float"

        blfs = []

        self.u_draw = self.i_draw
        self.w = w
        self.data = {
            "rna": rna,
            "array_range": array_range,
            "text_format": self.text_format
        }
        self.scissor = Scissor()

        title = rna.name
        if array_range != None: title += f" [{array_range.start} : {array_range.stop}]"
        evt = Admin.EVT
        LL, RR, BB, TT = LRBT
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        rim_d = SIZE_dd_border[2]
        d0x2 = d0 + d0

        title_B = - SIZE_title[1]
        # R, B = kw["size"]
        R = d0x2 + RR - LL
        B = title_B - 999
        ex_width = SIZE_widget[0] * 5 + SIZE_border[3] * 2
        R += ex_width

        if isinstance(title, str):
            title_y = title_B + D_SIZE['font_dd_title_dy']
            title_x = D_SIZE['font_dd_title_dx']
            # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_dd_title'}$)
            blfSize(FONT0, D_SIZE['font_dd_title'])
            blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
            # >>>
            blfs.append(BlfClip(r_blf_clipping_end(title, title_x, R - title_x
                ), title, title_x, title_y))

        box_win = GpuDropDown(0, R, B, 0, title_B)
        box_rim = GpuDropDownRim(-rim_d, R + rim_d, B - rim_d, rim_d, rim_d)
        box_hover = GpuBox(FLO_0000)
        box_shadow = GpuShadowDropDown(
            SIZE_dd_shadow_offset[0],
            R + SIZE_dd_shadow_offset[1],
            B + SIZE_dd_shadow_offset[2],
            SIZE_dd_shadow_offset[3],
            SIZE_shadow_softness[1])


        boxes = [
            box_shadow,
            box_rim,
            box_win,
            box_hover]

        self.boxes = boxes
        self.blfs = blfs
        self.box_rim = box_rim
        self.box_win = box_win
        self.box_hover = box_hover

        x = LL - d0
        y = TT + d0 + SIZE_title[1]

        for e in boxes: e.dxy_upd(x, y)
        for e in blfs:
            e.x += x
            e.y += y


        LL = box_win.L
        RR = box_win.R
        TT = box_win.title_B
        B0 = TT - D_SIZE['widget_full_h'] - d0x2
        R0 = RR - ex_width

        a0 = AreaValBox(self, LL, RR, B0, TT, input_text=input_text)
        a1 = AreaBlock1(self, LL, RR, B0, B0, BlockCalcDisplay(None))
        T1 = a1.box_area.B
        a2 = AreaBlock1(self, LL, R0, T1, T1, BlockCalcButton(None))
        B = a2.box_area.B
        a3 = AreaFilterY(self, R0, RR, B, T1, lambda: ITEMS_CALC_TAB)
        a3.filt.set_active_index_callback = a0.set_active_index_callback
        self.area_textbox = a0
        self.area_display = a1
        self.area_button = a2
        self.area_tab = a3
        self.areas = [a0, a1, a2, a3]

        box_win.B = B
        box_rim.B = B - rim_d
        box_shadow.B = B + SIZE_dd_shadow_offset[2]
        self.scissor.LRBT(LL, RR, B, box_win.title_B)
        self.dxy(*r_full_protect_dxy(box_rim.L, box_rim.R, box_rim.B, box_rim.T))

        filt = a3.filt
        filt.upd_scroll_init()
        filt.upd_scroll()

        W_HEAD.append(self)
        W_DRAW.append(self)

        Admin.REDRAW()
        Admin.TAG_CURSOR = 'DEFAULT'
        kill_evt()

        a0.to_modal_dd()
        e = list(filter(lambda e: e.name == tab, a3.filt.items))
        if e: a3.filt.set_active_index(e[0].value)
        #|

    def modal(self): pass

    def fin_callback(self):

        #|
        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        if hasattr(self.w, "active_index"): self.w.active_index = None

        if data["use_text_output"] != None:

            out = self.area_textbox.calc_text() # py value
            if isinstance(out, str):
                if out[: 1] == "#":
                    array_range = data["array_range"]
                    try:
                        if array_range == None:
                            self.w.set(out)
                        else:
                            self.w.set([out] * len(array_range), (array_range.start, array_range.stop))
                    except:
                        report("Fail to Add Driver")
                else:
                    report(out)
            else:
                rna = data["rna"]
                array_range = data["array_range"]
                try:
                    if hasattr(rna, "hard_min"):
                        hard_min = rna.hard_min
                        hard_max = rna.hard_max
                    else:
                        hard_min = rna.min_value
                        hard_max = rna.max_value
                    v = min(max(hard_min, out), hard_max)
                    if array_range == None:
                        self.w.set(v)
                    else:
                        self.w.set([v] * len(array_range), (array_range.start, array_range.stop))
                except:
                    report("Value Error")
        #|
    #|
    #|

class DropDownColor(DropDown):
    __slots__ = (
        'color_value',
        'hsv',
        'hex',
        'hex_str',
        'button_rgb',
        'button_hsv',
        'button_hex_str',
        'update_button_media',
        'hex_format',
        'hue_size',
        'color_space')

    def __init__(self, w, box_button, rna, pp, color_space="Scene Linear"):
        self.color_space = color_space
        title = f"{color_space}  |  {rna.name}"
        self.hex_format = getattr(DropDownColor, f'r_format_{P.format_hex}',
            DropDownColor.r_format_UPPERCASE_SEPARATOR)
        rgb = w.get()
        self.color_value = rgb
        self.hsv = list(rgb_to_hsv(max(0.0, rgb[0]), max(0.0, rgb[1]), max(0.0, rgb[2])))
        self.hex = list(self.r_media_rgb255(rgb[0], rgb[1], rgb[2]))
        self.hex_str = self.hex_format(self.hex)
        L, R, B, T = box_button.r_LRBT()
        d0 = SIZE_dd_border[0]
        widget_rim = SIZE_border[3]
        outer = (d0 + widget_rim) * 2
        a1_width = SIZE_block[2] * 2 + D_SIZE['widget_width'] + D_SIZE['widget_full_h']
        size_y = outer + max(SIZE_block[2] * 2 + SIZE_button[3], 8 * D_SIZE['widget_full_h'])
        size_x = a1_width + size_y + SIZE_button[2] + (widget_rim + SIZE_button[1]) * 2 + SIZE_widget[0] + SIZE_widget[0] // 4
        if hasattr(w, "bufn_keyframe"): size_x += SIZE_widget[0]
        pos = (R + d0 - size_x, T + d0)

        super().__init__(w=w, pos=pos, size=(size_x, size_y), use_titlebar=True, title=title,
            box_button=box_button, rna=rna, pp=pp, a1_width=a1_width)

        self.data["is_confirm"] = False
        #|
    def init(self, boxes, blfs):

        init = DropDown.INIT_DATA
        data = self.data
        d0 = SIZE_dd_border[0]
        LL, RR, BB, TT = self.box_win.r_LRBT()
        Tt = self.box_win.title_B
        size_x, size_y = init['size']

        L0 = RR - init['a1_width']
        a0 = AreaColorHue(self, LL, L0, BB, Tt, self.modal_drag_H_callback, self.modal_drag_SV_callback)
        a1 = AreaBlockSimple(self, L0, RR, BB, Tt)
        a1b0 = BlockR(a1)
        self.button_rgb = ButtonFloatVectorColor(a1b0, init['rna'], init['pp'], subtype_override=TUP_RGBA)
        self.button_rgb.update_callback = self.button_rgb_update_callback
        self.button_rgb.callback_enable = True

        self.button_hsv = ButtonFloatVectorColor(a1b0, RNA_hsv, self, subtype_override=TUP_HSV)
        self.button_hsv.update_callback = self.button_hsv_update_callback
        self.button_hsv.callback_enable = True

        self.button_hex_str = ButtonStringColorHex(a1b0, RNA_hex_str_glc, self, subtype_override=TUP_HEX)
        self.button_hex_str.set_callfront = self.button_hex_str_set_callfront

        a1b0.buttons = [
            self.button_rgb,
            ButtonSep(),
            self.button_hsv,
            ButtonSep(),
            self.button_hex_str,
            ButtonSep(),
            ButtonFnImg(a1b0, RNA_eyedropper, self.bufn_eyedropper, 'GpuImg_eyedropper')
        ]
        self.areas = [a0, a1]
        self.hue_size = max(a1b0.r_height(0), SIZE_button[3])
        # a1b1 = BlockR(a1)
        # a1b1.buttons = []
        a1.items.append(a1b0)
        # a1.items.append(a1b1)
        a1.init_draw_range()

        # if SIZE_title[1] > d0 + d0:
        box_button = init['box_button']
        data['box_button'] = box_button
        data['box_button_LRBT'] = box_button.r_LRBT()
        data['input_color'] = tuple(self.color_value)
        box_button.B = Tt + d0
        box_button.T = TT - d0
        box_button.R = RR - d0
        box_button.L = a1b0.buttons[0].box_button.L
        box_button.upd()
        if hasattr(self.w, "box_grid"):
            data['box_grid'] = self.w.box_grid
            data['box_grid_LRBT'] = data['box_grid'].r_LRBT()
            data['box_rgb'] = self.w.box_rgb
            data['box_rgb_LRBT'] = data['box_rgb'].r_LRBT()

            B = box_button.inner[2]
            T = box_button.inner[3]
            cx = box_button.r_center_x()
            data['box_grid'].B = B
            data['box_grid'].T = T
            data['box_grid'].L = cx
            data['box_grid'].R = box_button.inner[1]
            data['box_rgb'].B = B
            data['box_rgb'].T = T
            data['box_rgb'].L = box_button.inner[0]
            data['box_rgb'].R = cx
            data['box_grid'].upd()
            data['box_rgb'].upd()

            w_boxes = [data['box_grid'], box_button, data['box_rgb']]
        else:
            w_boxes = [box_button]

        boxes.append(BoxGroup(w_boxes, self.w.draw_box))

        self.update_button_media = a0.update_button_media
        a0.update_button_media(rgb_to_hsv(self.hex[0] / 255.0, self.hex[1] / 255.0, self.hex[2] / 255.0))
        #|

    def r_media_rgb255(self, r01, g01, b01):
        ind_r = glc_to_hex(r01)
        ind_g = glc_to_hex(g01)
        ind_b = glc_to_hex(b01)
        return (
            D_glc_null[ind_r] if ind_r in D_glc_null else ind_r,
            D_glc_null[ind_g] if ind_g in D_glc_null else ind_g,
            D_glc_null[ind_b] if ind_b in D_glc_null else ind_b)
        #|

    def button_rgb_update_callback(self):
        self.button_hsv.callback_enable = False
        rgb = self.color_value
        self.button_hsv.set(rgb_to_hsv(max(0.0, rgb[0]), max(0.0, rgb[1]), max(0.0, rgb[2])), (0, 3))
        self.hex[:] = self.r_media_rgb255(rgb[0], rgb[1], rgb[2])
        self.hex_str = self.hex_format(self.hex)
        self.button_hex_str.blf_value.text = self.hex_str
        self.update_button_media(rgb_to_hsv(self.hex[0] / 255.0, self.hex[1] / 255.0, self.hex[2] / 255.0))
        self.button_hsv.callback_enable = True
        #|
    def button_hsv_update_callback(self):
        self.button_rgb.callback_enable = False
        self.button_rgb.set(hsv_to_rgb(*self.hsv), (0, 3))
        rgb = self.color_value
        self.hex[:] = self.r_media_rgb255(rgb[0], rgb[1], rgb[2])
        self.hex_str = self.hex_format(self.hex)
        self.button_hex_str.blf_value.text = self.hex_str
        hsv = rgb_to_hsv(self.hex[0] / 255.0, self.hex[1] / 255.0, self.hex[2] / 255.0)
        if hsv[1] == 0.0:
            self.update_button_media((self.hsv[0], hsv[1], hsv[2]))
        else:
            self.update_button_media(hsv)
        self.button_rgb.callback_enable = True
        #|
    def button_hex_str_set_callfront(self, s):
        if len(s) < 6: s = "0" * (6 - len(s)) + s
        r = int(s[0 : 2], 16)
        g = int(s[2 : 4], 16)
        b = int(s[4 : 6], 16)
        is_null = r in D_glc_null or g in D_glc_null or b in D_glc_null
        self.button_rgb.set([L_rgb_to_glc[r], L_rgb_to_glc[g], L_rgb_to_glc[b]], (0, 3))
        if is_null:
            self.button_hex_str.blf_value.text = self.hex_format([r, g, b]) + " Invalid"
            return False
        return True
        #|
    def modal_drag_H_callback(self, fac):
        self.button_hsv.set(fac, 0)
        #|
    def modal_drag_SV_callback(self, fac_x, fac_y):
        rgb_media_space = hsv_to_rgb(self.hsv[0], fac_x, fac_y)
        # r = min(max(0, round(rgb_media_space[0] * 255)), 255)
        # g = min(max(0, round(rgb_media_space[1] * 255)), 255)
        # b = min(max(0, round(rgb_media_space[2] * 255)), 255)
        # hsv = rgb_to_hsv(L_rgb_to_glc[r], L_rgb_to_glc[g], L_rgb_to_glc[b])
        # self.button_hsv.set(hsv[1 : 3], (1, 3))
        self.button_hsv.set(rgb_to_hsv(
            L_rgb_to_glc[min(max(0, round(rgb_media_space[0] * 255)), 255)],
            L_rgb_to_glc[min(max(0, round(rgb_media_space[1] * 255)), 255)],
            L_rgb_to_glc[min(max(0, round(rgb_media_space[2] * 255)), 255)]
        )[1 : 3], (1, 3))
        #|

    def evt_click_outside(self): self.evt_dd_confirm()
    def evt_dd_confirm(self):
        self.data["is_confirm"] = True
        self.fin()
        #|

    def fin_callback(self):
        if hasattr(self, "update_modal"):
            W_MODAL.remove(self.update_modal)


        data = self.data
        if 'box_button' in data:
            e = data['box_button']
            LRBT = data['box_button_LRBT']
            e.L = LRBT[0]
            e.R = LRBT[1]
            e.B = LRBT[2]
            e.T = LRBT[3]
            e.upd()
            if 'box_grid' in data:
                e = data['box_grid']
                LRBT = data['box_grid_LRBT']
                e.L = LRBT[0]
                e.R = LRBT[1]
                e.B = LRBT[2]
                e.T = LRBT[3]
                e.upd()
                e = data['box_rgb']
                LRBT = data['box_rgb_LRBT']
                e.L = LRBT[0]
                e.R = LRBT[1]
                e.B = LRBT[2]
                e.T = LRBT[3]
                e.upd()

        if "fin_callfront" in data: data["fin_callfront"]()

        if data["is_confirm"]:

            self.w.set(self.w.get(), (0, len(data["input_color"])), undo_push=data["input_color"])
        else:

            self.w.set(data["input_color"], (0, len(data["input_color"])), undo_push=False)
        #|

    def bufn_eyedropper(self):

        Admin.REDRAW()
        kill_evt_except()
        _end_trigger0 = TRIGGER['esc']
        _end_trigger1 = TRIGGER['dd_esc']
        trigger_confirm0 = TRIGGER['click']
        trigger_confirm1 = TRIGGER['dd_confirm']

        LL = REGION_DATA.L
        RR = REGION_DATA.R
        BB = REGION_DATA.B + SIZE_tb[0]
        TT = REGION_DATA.T
        full_h = D_SIZE['widget_full_h']
        h = SIZE_widget[0]
        wi = D_SIZE['widget_width']
        widget_rim = SIZE_border[3]
        depth = full_h // 3
        box_bg = GpuRim(COL_box_val, COL_box_val_rim, d=widget_rim)
        box_color = GpuBox([0.0, 0.0, 0.0, 1.0])
        blf_hex = BlfColor(color=COL_box_val_fg)
        hex_format = self.hex_format

        # /* 0dd_bufn_eyedropper_update_box
        if LL <= MOUSE[0] < RR and BB <= MOUSE[1] < TT:
            R = MOUSE[0] + full_h + wi
            if R > RR: R = MOUSE[0] - full_h
            L = R - wi
            T = BB + full_h  if MOUSE[1] < BB + full_h else MOUSE[1]
            B = T - full_h
        else:
            L = min(max(MOUSE[0] + depth, LL), RR - wi)
            R = L + wi
            T = min(max(MOUSE[1] + depth, BB + full_h), TT)
            B = T - full_h

        box_bg.L = L
        box_bg.R = R
        box_bg.B = B
        box_bg.T = T
        box_bg.upd()
        L0, R0, B0, T0 = box_bg.inner
        box_color.LRBT_upd(L0, L0 + h, B0, T0)

        r, g, b = active_framebuffer_get().read_color(*MOUSE_WINDOW, 1, 1, 3, 0, 'FLOAT').to_list()[0][0]
        r = min(max(0, round(r * 255)), 255)
        g = min(max(0, round(g * 255)), 255)
        b = min(max(0, round(b * 255)), 255)
        box_color.color[0 : 3] = L_rgb_to_glc[r], L_rgb_to_glc[g], L_rgb_to_glc[b]
        blf_hex.text = "# " + hex_format([r, g, b])
        if r in D_glc_null or g in D_glc_null or b in D_glc_null:
            blf_hex.color = COL_box_val_fg_error
        else:
            blf_hex.color = COL_box_val_fg
        blf_hex.x = box_color.R + D_SIZE['font_main_dx']
        blf_hex.y = B0 + D_SIZE['font_main_dy']
        # */

        def _modal():
            Admin.REDRAW()
            if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or _end_trigger0() or _end_trigger1():
                W_HEAD[-1].fin()
                return

            # <<< 1copy (0dd_bufn_eyedropper_update_box,, $$)
            if LL <= MOUSE[0] < RR and BB <= MOUSE[1] < TT:
                R = MOUSE[0] + full_h + wi
                if R > RR: R = MOUSE[0] - full_h
                L = R - wi
                T = BB + full_h  if MOUSE[1] < BB + full_h else MOUSE[1]
                B = T - full_h
            else:
                L = min(max(MOUSE[0] + depth, LL), RR - wi)
                R = L + wi
                T = min(max(MOUSE[1] + depth, BB + full_h), TT)
                B = T - full_h

            box_bg.L = L
            box_bg.R = R
            box_bg.B = B
            box_bg.T = T
            box_bg.upd()
            L0, R0, B0, T0 = box_bg.inner
            box_color.LRBT_upd(L0, L0 + h, B0, T0)

            r, g, b = active_framebuffer_get().read_color(*MOUSE_WINDOW, 1, 1, 3, 0, 'FLOAT').to_list()[0][0]
            r = min(max(0, round(r * 255)), 255)
            g = min(max(0, round(g * 255)), 255)
            b = min(max(0, round(b * 255)), 255)
            box_color.color[0 : 3] = L_rgb_to_glc[r], L_rgb_to_glc[g], L_rgb_to_glc[b]
            blf_hex.text = "# " + hex_format([r, g, b])
            if r in D_glc_null or g in D_glc_null or b in D_glc_null:
                blf_hex.color = COL_box_val_fg_error
            else:
                blf_hex.color = COL_box_val_fg
            blf_hex.x = box_color.R + D_SIZE['font_main_dx']
            blf_hex.y = B0 + D_SIZE['font_main_dy']
            # >>>

            if trigger_confirm0() or trigger_confirm1():
                w.data["is_confirm"] = True
                W_HEAD[-1].fin()
                return
            #|
        def _modal_end():

            Admin.TAG_CURSOR = 'DEFAULT'
            W_DRAW.remove(u_draw)

            if w.data["is_confirm"]:
                try: self.button_hex_str.set(blf_hex.text)
                except: pass

            kill_evt_except()
            #|
        def _draw():
            blend_set('ALPHA')
            box_bg.bind_draw()
            box_color.bind_draw()

            blfSize(FONT0, D_SIZE['font_main'])
            blfColor(FONT0, *blf_hex.color)
            blfPos(FONT0, blf_hex.x, blf_hex.y, 0)
            blfDraw(FONT0, blf_hex.text)
            #|

        Admin.TAG_CURSOR = 'EYEDROPPER'
        w = Head(self, _modal, _modal_end)
        w.data = {"is_confirm": False}
        u_draw = Udraw(_draw)
        W_DRAW.append(u_draw)
        #|

    @staticmethod
    def r_format_UPPERCASE_SEPARATOR(ivec3):
        return f"{'%02X' % ivec3[0]} {'%02X' % ivec3[1]} {'%02X' % ivec3[2]}"
        #|
    @staticmethod
    def r_format_LOWERCASE_SEPARATOR(ivec3):
        return f"{'%02x' % ivec3[0]} {'%02x' % ivec3[1]} {'%02x' % ivec3[2]}"
        #|
    @staticmethod
    def r_format_UPPERCASE(ivec3):
        return f"{'%02X' % ivec3[0]}{'%02X' % ivec3[1]}{'%02X' % ivec3[2]}"
        #|
    @staticmethod
    def r_format_LOWERCASE(ivec3):
        return f"{'%02x' % ivec3[0]}{'%02x' % ivec3[1]}{'%02x' % ivec3[2]}"
        #|
    #|
    #|
class DropDownColorSRGB(DropDownColor):
    __slots__ = ()

    def r_media_rgb255(self, r01, g01, b01):
        ind_r = min(max(0, round(r01 * 255)), 255)
        ind_g = min(max(0, round(g01 * 255)), 255)
        ind_b = min(max(0, round(b01 * 255)), 255)
        return (
            D_glc_null[ind_r] if ind_r in D_glc_null else ind_r,
            D_glc_null[ind_g] if ind_g in D_glc_null else ind_g,
            D_glc_null[ind_b] if ind_b in D_glc_null else ind_b)
        #|

    def button_hex_str_set_callfront(self, s):
        if len(s) < 6: s = "0" * (6 - len(s)) + s
        r = int(s[0 : 2], 16)
        g = int(s[2 : 4], 16)
        b = int(s[4 : 6], 16)
        is_null = r in D_glc_null or g in D_glc_null or b in D_glc_null
        self.button_rgb.set([r / 255.0, g / 255.0, b / 255.0], (0, 3))
        if is_null:
            self.button_hex_str.blf_value.text = self.hex_format([r, g, b]) + " Invalid"
            return False
        return True
        #|
    #|
    #|
class DropDownColorAnim(DropDownColor):
    __slots__ = 'button_keyframes', 'update_modal'

    def init(self, boxes, blfs):

        init = DropDown.INIT_DATA
        data = self.data
        d0 = SIZE_dd_border[0]
        LL, RR, BB, TT = self.box_win.r_LRBT()
        Tt = self.box_win.title_B
        size_x, size_y = init['size']
        h = SIZE_widget[0]

        L0 = RR - init['a1_width']
        a0 = AreaColorHue(self, LL, L0, BB, Tt, self.modal_drag_H_callback, self.modal_drag_SV_callback)
        a1 = AreaBlockSimple(self, L0, RR, BB, Tt)
        a1b0 = BlockR(a1)

        if hasattr(init['rna'], "array_length"): TODO
        else:
            w = self.w
            pp = w.r_pp, w.r_object, w.r_datapath_head
            self.button_rgb = GnVectorColor(w, init['rna'], pp, subtype_override=TUP_RGBA)
        self.button_rgb.update_callback = self.button_rgb_update_callback
        self.button_rgb.callback_enable = True

        self.button_hsv = ButtonFloatVectorColor(a1b0, RNA_hsv, self, subtype_override=TUP_HSV)
        self.button_hsv.update_callback = self.button_hsv_update_callback
        self.button_hsv.callback_enable = True

        self.button_hex_str = ButtonStringColorHex(a1b0, RNA_hex_str_glc, self, subtype_override=TUP_HEX)
        self.button_hex_str.set_callfront = self.button_hex_str_set_callfront

        a1b0.buttons = [
            self.button_rgb,
            ButtonSep(),
            self.button_hsv,
            ButtonSep(),
            self.button_hex_str,
            ButtonSep(),
            ButtonFnImg(a1b0, RNA_eyedropper, self.bufn_eyedropper, 'GpuImg_eyedropper')
        ]
        self.areas = [a0, a1]
        self.hue_size = max(a1b0.r_height(0), SIZE_button[3])
        # a1b1 = BlockR(a1)
        # a1b1.buttons = []
        a1.items.append(a1b0)
        # a1.items.append(a1b1)
        a1.box_area.L -= h
        a1.box_area.upd()
        a1.box_region.L -= h
        a1.box_region.upd()
        a1.init_draw_range()
        a0.box_area.R -= h
        a0.box_area.upd()

        # if SIZE_title[1] > d0 + d0:
        box_button = init['box_button']
        data['box_button'] = box_button
        data['box_button_LRBT'] = box_button.r_LRBT()
        data['input_color'] = tuple(self.color_value)
        box_button.B = Tt + d0
        box_button.T = TT - d0
        box_button.R = RR - d0
        box_button.L = a1b0.buttons[0].box_button.L
        box_button.upd()
        if hasattr(self.w, "box_grid"):
            data['box_grid'] = self.w.box_grid
            data['box_grid_LRBT'] = data['box_grid'].r_LRBT()
            data['box_rgb'] = self.w.box_rgb
            data['box_rgb_LRBT'] = data['box_rgb'].r_LRBT()

            B = box_button.inner[2]
            T = box_button.inner[3]
            cx = box_button.r_center_x()
            data['box_grid'].B = B
            data['box_grid'].T = T
            data['box_grid'].L = cx
            data['box_grid'].R = box_button.inner[1]
            data['box_rgb'].B = B
            data['box_rgb'].T = T
            data['box_rgb'].L = box_button.inner[0]
            data['box_rgb'].R = cx
            data['box_grid'].upd()
            data['box_rgb'].upd()

            w_boxes = [data['box_grid'], box_button, data['box_rgb']]
        else:
            w_boxes = [box_button]

        boxes.append(BoxGroup(w_boxes, self.w.draw_box))

        self.update_button_media = a0.update_button_media
        a0.update_button_media(rgb_to_hsv(self.hex[0] / 255.0, self.hex[1] / 255.0, self.hex[2] / 255.0))

        # keyframe button
        button_rgb = self.button_rgb
        r_bufn_keyframe = self.r_bufn_keyframe
        button_keyframes = [
            ButtonFnImgHoverKeyframe(a1b0, RNA_button_keyframe, r_bufn_keyframe(0)),
            ButtonFnImgHoverKeyframe(a1b0, RNA_button_keyframe, r_bufn_keyframe(1)),
            ButtonFnImgHoverKeyframe(a1b0, RNA_button_keyframe, r_bufn_keyframe(2)),
            ButtonFnImgHoverKeyframe(a1b0, RNA_button_keyframe, r_bufn_keyframe(3))
        ]
        a1b0.buttons += button_keyframes
        self.button_keyframes = button_keyframes

        R = button_rgb.blf_subtype[0].x - SIZE_border[3]
        L = a1.box_region.inner[0]
        L = round((L + R - h) / 2)
        R = L + h
        T = button_rgb.box_button.T - SIZE_border[3]
        for e in button_keyframes:
            T = e.init_bat(L, R, T)

        r_fcurve = w.r_fcurve
        r_driver = w.r_driver
        button_rgb_blf_value = button_rgb.blf_value
        button_rgb_set = button_rgb.set
        color_value = self.color_value

        class UpdateModal:
            __slots__ = ()
            def upd_data(self):
                old_v = [e.unclip_text  for e in button_rgb_blf_value]

                if all(e0 == e1  for e0, e1 in zip(old_v, color_value)): pass
                else: button_rgb_set(color_value, (0, 4))

                for button, fc, dr, v in zip(button_keyframes, r_fcurve(), r_driver(), color_value):
                    if dr:
                        if button.box_button.__class__ != GpuImg_driver_true:
                            button.box_button.__class__ = GpuImg_driver_true
                        continue

                    if fc:
                        r = bpy.context.scene.frame_current
                        kp = fc.keyframe_points
                        ind_E = len(kp) -1
                        if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                            if fc.evaluate(r) == v:
                                if button.box_button.__class__ != GpuImg_keyframe_next_false_even:
                                    button.box_button.__class__ = GpuImg_keyframe_next_false_even
                            else:
                                if button.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                                    button.box_button.__class__ = GpuImg_keyframe_next_false_odd
                        else:
                            if fc.evaluate(r) == v:
                                if button.box_button.__class__ != GpuImg_keyframe_current_true_even:
                                    button.box_button.__class__ = GpuImg_keyframe_current_true_even
                            else:
                                if button.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                                    button.box_button.__class__ = GpuImg_keyframe_current_true_odd
                        continue

                    if button.box_button.__class__ != GpuImg_keyframe_false:
                        button.box_button.__class__ = GpuImg_keyframe_false

        self.update_modal = UpdateModal()
        W_MODAL.insert(-1, self.update_modal)
        self.update_modal.upd_data()
        #|

    def r_bufn_keyframe(self, index):
        def bufn_keyframe():
            self.button_rgb.bufn_keyframe(index)
        return bufn_keyframe
        #|
    #|
    #|

class DropDownYesNo(DropDown):
    __slots__ = 'button_yes', 'button_no', 'fn_yes', 'fn_no'

    def __init__(self, w, pos,
                fn_yes = None,
                fn_no = None,
                title = "Confirm Dialog",
                input_text = "Are You Confirm?",
                text_yes = "Yes",
                text_no = "No",
                font_id = None,
                row_count = 6,
                width_fac = 2.0):

        self.fn_yes = fn_yes
        self.fn_no = fn_no
        RNA_yes.default = text_yes
        RNA_no.default = text_no
        width = round(width_fac * D_SIZE['widget_width'])
        LL = pos[0]
        RR = LL + width
        TT = pos[1]
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        line_h = SIZE_widget[0]
        BB = TT - row_count * line_h - SIZE_border[3] * 2
        area_button_h = d1 + d1 + D_SIZE['widget_full_h'] + d0x2

        super().__init__(w=w,
            pos = (LL - d0, TT + d0),
            size = (RR - LL + d0x2, TT - BB + d0x2 + area_button_h),
            use_titlebar = True,
            protect_pos = True,
            killevt = True,
            input_text = input_text,
            row_count = row_count,
            font_id = FONT0  if font_id is None else font_id,
            title = title,
            title_button = [("close", self.fin_from_area)],
            area_button_h = area_button_h)

        self.areas[0].to_modal_dd(select_all=False, modal_type="i_modal_dd_editor_protect")
        #|
    def init(self, boxes, blfs):

        #|
        init = DropDown.INIT_DATA
        size_x, size_y = init['size']
        L = self.box_win.L
        R = L + size_x
        T = self.box_win.title_B
        B = T - size_y + init['area_button_h']

        self.areas = [AreaStringXY(self, L, R, B, T,
            input_text = init['input_text'],
            font_id = init['font_id'])]

        button_yes = ButtonFn(self, RNA_yes, self.bufn_yes)
        button_no = ButtonFn(self, RNA_no, self.fin_from_area)
        self.button_yes = button_yes
        self.button_no = button_no
        boxes.append(button_yes.box_button)
        boxes.append(button_no.box_button)
        blfs.append(button_yes.blf_value)
        blfs.append(button_no.blf_value)

        widget_rim = SIZE_border[3]
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        B -= SIZE_dd_border[0] + d1
        L += d0 + widget_rim
        R -= d0 + widget_rim
        button_width = (R - L - d0 - d1) // 2
        button_yes.init_bat(L, L + button_width, B)
        button_no.init_bat(R - button_width, R, B)
        #|

    def fin_from_area(self): self.areas[0].evt_cancel()
    def fin_callback(self):
        data = self.data

        if "fin_callfront" in data: data["fin_callfront"]()

        if "is_confirm" in data and data["is_confirm"]:

            if self.fn_yes != None: self.fn_yes()
        else:

            if self.fn_no != None: self.fn_no()

        data.clear()
        #|
    def bufn_yes(self):

        self.data["is_confirm"] = True
        self.fin_from_area()
        #|

    def basis_win_evt_protect(self):
        e = None
        if self.button_yes.inside(MOUSE): e = self.button_yes
        elif self.button_no.inside(MOUSE): e = self.button_no
        else:
            for o in self.title_buttons:
                if o.inside(MOUSE):
                    e = o
                    break

        if e is None:
            if hasattr(self.focus_element, "outside_evt"): self.focus_element.outside_evt()
            self.focus_element = None
        else:
            if self.focus_element != e:
                if hasattr(self.focus_element, "outside_evt"): self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()
                kill_evt_except()

            if e.modal(): return N

        if self.box_win.inbox(MOUSE) and MOUSE[1] > self.box_win.title_B:
            if TRIGGER['title_move'](): return self.to_modal_move

        return None
        #|
    #|
    #|
class DropDownOk(DropDownYesNo):
    __slots__ = ()

    def __init__(self, w, pos,
                fn_yes = None,
                title = "Dialog",
                input_text = "Ok?",
                text_yes = "OK",
                font_id = None,
                row_count = 6,
                width_fac = 2.0):

        super().__init__(w, pos,
            fn_yes = fn_yes,
            title = title,
            input_text = input_text,
            text_yes = text_yes,
            text_no = "",
            font_id = font_id,
            row_count = row_count,
            width_fac = width_fac)

        self.button_no.box_button.LRBT_upd(0, 0, 0, 0, 0)
        self.button_no.blf_value.x = 0
        self.button_no.blf_value.y = 0
        #|
    #|
    #|
class DropDownInfoUtil(DropDown):
    __slots__ = 'endfn', 'buttons', 'area_items', 'active_tab'

    def __init__(self, w, pos, buttons,
                area_items = None,
                endfn = None,
                title = "Dialog",
                input_text = "",
                font_id = None,
                row_count = 6,
                width_fac = 2.0,
                block_size = 6):

        self.buttons = buttons
        self.area_items = area_items
        self.endfn = endfn
        width = round(width_fac * D_SIZE['widget_width'])
        LL = pos[0]
        RR = LL + width
        TT = pos[1]
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        line_h = SIZE_widget[0]
        widget_rim_2 = SIZE_border[3] * 2
        BB = TT - row_count * line_h - widget_rim_2
        size_x = RR - LL + d0x2
        area_width = size_x - d0x2 - widget_rim_2
        button_gap = SIZE_button[1]
        area_button_h = d1 + d1 + d0x2 + sum(e.r_height(area_width) + button_gap  for e in buttons)
        area_block_h = 0  if area_items is None else AreaBlockTab.calc_height_by_len(block_size)

        super().__init__(w=w,
            pos = (LL - d0, TT + d0),
            size = (size_x, TT - BB + d0x2 + area_button_h + area_block_h),
            use_titlebar = True,
            protect_pos = True,
            killevt = True,
            input_text = input_text,
            row_count = row_count,
            font_id = FONT0  if font_id is None else font_id,
            title = title,
            title_button = [("close", self.fin_from_area)],
            area_button_h = area_button_h,
            area_block_h = area_block_h)

        self.areas[0].to_modal_dd(select_all=False, modal_type="i_modal_dd_editor_protect")
        #|
    def init(self, boxes, blfs):

        #|
        init = DropDown.INIT_DATA
        size_x, size_y = init['size']
        L = self.box_win.L
        R = L + size_x
        T = self.box_win.title_B
        B = T - size_y + init['area_button_h'] + init['area_block_h']

        self.areas = [AreaStringXY(self, L, R, B, T,
            input_text = init['input_text'],
            font_id = init['font_id'])]

        if self.area_items is not None:
            T = B
            B = T - init['area_block_h']
            a1 = AreaBlockTab(self, L, R, B, T)
            self.areas.append(a1)
            a1.items = self.area_items
            self.active_tab = None
            a1.active_tab = None

        widget_rim = SIZE_border[3]
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        B -= SIZE_dd_border[0] + d1
        L += d0 + widget_rim
        R -= d0 + widget_rim
        button_gap = SIZE_button[1]

        for e in self.buttons:
            B = e.init_bat(L, R, B) - button_gap
        #|

    def fin_from_area(self): self.areas[0].evt_cancel()
    def fin_callback(self):
        data = self.data

        if "fin_callfront" in data: data["fin_callfront"]()

        if self.endfn != None: self.endfn(data)

        data.clear()
        #|

    def r_area_tab(self): return self.areas[1]

    def basis_win_evt_protect(self):
        e = None
        for o in self.title_buttons:
            if o.inside(MOUSE):
                e = o
                break
        if e is None:
            for o in self.buttons:
                if o.inside(MOUSE):
                    e = o
                    break

            if self.area_items and e is None and self.areas[1].box_area.inbox(MOUSE):
                self.areas[1].modal()
                return N

        if e is None:
            if hasattr(self.focus_element, "outside_evt"): self.focus_element.outside_evt()
            self.focus_element = None
        else:
            if self.focus_element != e:
                if hasattr(self.focus_element, "outside_evt"): self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()
                if hasattr(e, "evtkill") and e.evtkill == False: pass
                else: kill_evt_except()

            e.modal()
            return N

        if self.box_win.inbox(MOUSE) and MOUSE[1] > self.box_win.title_B:
            if TRIGGER['title_move'](): return self.to_modal_move

        if self.areas[0].box_area.inbox(MOUSE): return None
        return N
        #|

    def dxy(self, dx, dy):
        super().dxy(dx, dy)
        for e in self.buttons: e.dxy(dx, dy)
        #|
    def i_draw(self):
        super().i_draw()
        blend_set('ALPHA')
        for e in self.buttons: e.draw_box()
        for e in self.buttons: e.draw_blf()
        #|
    #|
    #|
class DropDownListUtil(DropDown):
    __slots__ = 'endfn', 'area_items', 'active_tab'

    def __init__(self, w, pos, items,
                area_items = None,
                endfn = None,
                get_icon = None,
                get_info = None,
                title = "Menu",
                size_x = None,
                size_y = None,
                input_text = "",
                block_size = 6):

        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        d0x2 = d0 + d0
        button_gap = SIZE_button[1]
        blfSize(FONT0, D_SIZE['font_main'])

        if size_x == None:
            size_x = max(SIZE_widget[0] * 12, min(REGION_DATA.R - REGION_DATA.L,
                SIZE_widget[0] + d0x2 + D_SIZE['font_main_dx'] * 2 + floor(max(
                    blfDimen(FONT0, e.name)[0]  for e in items))))
        if size_y == None:
            size_y = min(REGION_DATA.T - REGION_DATA.B - SIZE_tb[0] - SIZE_title[1],
                d0x2 + d1 + (SIZE_filter[2] + SIZE_border[3]) * 2 + (len(items) + 1) * D_SIZE['widget_full_h'])

        area_block_h = 0  if area_items is None else AreaBlockTab.calc_height_by_len(block_size)

        super().__init__(w=w, pos=pos, size=(size_x, size_y), use_titlebar=True, title=title,
            items=items, get_icon=get_icon, get_info=get_info, input_text=input_text,
            area_block_h = area_block_h)

        self.areas[0].to_modal_dd()
        #|
    def init(self, boxes, blfs):

        init = DropDown.INIT_DATA
        L = self.box_win.L
        T = self.box_win.title_B
        size_x, size_y = init['size']
        items = init['items']

        B = T - size_y + init['area_block_h']
        R = L + size_x

        self.areas = [AreaFilterY(self, L, R, B, T, lambda: items,
            get_icon = init['get_icon'],
            get_info = init['get_info'],
            input_text = init['input_text'],
            is_dropdown = True)]

        if self.area_items is not None:
            T = B
            B = T - init['area_block_h']
            a1 = AreaBlockTab(self, L, R, B, T)
            self.areas.append(a1)
            a1.items = self.area_items
            self.active_tab = None
            a1.active_tab = None
        #|

    def fin_from_area(self): self.areas[0].evt_cancel()
    def fin_callback(self):

        #|
        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        if data["use_text_output"] != None:

            if data["use_text_output"]:
                if P.adaptive_rm_output:
                    if self.areas[0].blf_text.unclip_text.strip():
                        if data["best_item"] != None: data["best_item"].value()
            else:
                if data["best_item"] != None: data["best_item"].value()

        data.clear()
        #|

    def r_area_tab(self): return self.areas[1]

    def basis_win_evt(self):
        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']() or TRIGGER['dd_esc']():
            return self.areas[0].evt_cancel
        return None
        #|
    def dd_basis_evt(self):
        if self.areas[1].box_area.inbox(MOUSE) is False: return None
        self.areas[1].modal()
        return N
        #|
    #|
    #|

class DropDownNewModifier(DropDownListUtil):
    __slots__ = 'bpy_object', 'md_lib_method'

    def __init__(self, w, pos, bpy_object):
        self.bpy_object = bpy_object
        self.md_lib_method = P.md_lib_method
        if m.LIBRARY_MODIFIER is None: m.LibraryModifier.ui_refresh_path(report_dialog=False)

        if bpy_object.type not in m.LIBRARY_MODIFIER.types_items: return

        area_items = []
        self.area_items = area_items

        super().__init__(w, pos, m.LIBRARY_MODIFIER.types_items[bpy_object.type],
            area_items = area_items,
            get_icon = self.get_icon,
            get_info = self.get_info,
            title = "Add Modifier",
            size_x = round(D_SIZE['widget_width'] * 2.1),
            size_y = pos[1] - REGION_DATA.B - SIZE_tb[0] - SIZE_title[1],
            block_size = 1)

        area_tab = self.r_area_tab()
        button0 = ButtonEnumXYTemp(None, P.bl_rna.properties["md_lib_method"], self, row_length=3)
        area_items.append(BlockFull(area_tab, button0))
        area_tab.init_items_tab()
        #|

    def get_icon(self, e):
        if hasattr(e, "identifier"):
            if e.identifier in blg.D_geticon_Modifier: return blg.D_geticon_Modifier[e.identifier]()
            return GpuImg_OUTLINER_OB_UNKNOW
        return GpuImg_NODETREE()
        #|
    def get_info(self, e):
        if hasattr(e, "library"):
            if hasattr(e.library, "version") and e.library.version:
                return f'{e.library.filepath}  |  {e.library.version}'
            return e.library.filepath
        return ""
        #|

    def fin_callback(self):

        #|
        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        if data["use_text_output"] != None:

            oj = self.bpy_object
            item = None

            if data["use_text_output"]:
                tx = self.areas[0].blf_text.unclip_text
            else:
                if data["best_item"] == None:
                    tx = self.areas[0].blf_text.unclip_text
                else:
                    item = data["best_item"]
                    tx = item.name

            if item is None:
                name_to_item = {e.name: e  for e in self.areas[0].filt.items}
                if tx in name_to_item: item = name_to_item[tx]

            if item is not None:
                if hasattr(item, "identifier"):
                    if hasattr(item, "library"):
                        success, result = DropDownNewModifier.new_md_copy(oj, item.library.filepath, item.library.version, item.name)
                        if success: update_scene_push(f'VMD Add Modifier: {tx}')
                        if result: report(f"Failed. {result}")
                    else:
                        oj.modifiers.new(tx, item.identifier)
                        update_scene_push(f'VMD Add Modifier: {tx}')
                elif hasattr(item, "library"):
                    if self.md_lib_method == "REUSE": append_fn = DropDownNewModifier.new_gn_reuse
                    elif self.md_lib_method == "APPEND": append_fn = DropDownNewModifier.new_gn_append
                    else: append_fn = DropDownNewModifier.new_gn_link

                    success, result = append_fn(oj, item.library.filepath, item.name)
                    if success: update_scene_push(f'VMD Add Modifier: {tx}')
                    if result: report(f"Failed. {result}")

        data.clear()
        #|

    @staticmethod
    @ successResult
    def new_gn_reuse(oj, file_path, node_name):
        inner_path = "NodeTree"
        if node_name in bpy.data.node_groups:
            node = bpy.data.node_groups[node_name]
        else:
            # <<< 1copy (0dd_new_gn_append,, $$)
            node_groups = bpy.data.node_groups
            if node_name in node_groups:
                old_node_groups = set(node_groups)
                # <<< 1copy (0dd_bpy_ops_wm_append,, ${'link=True':'link=False'}$)
                bpy.ops.wm.append(
                    filepath=os_path_join(file_path, inner_path, node_name),
                    directory=os_path_join(file_path, inner_path),
                    filename=node_name,
                    link=False)
                # >>>
                node = next(ob  for ob in node_groups  if ob not in old_node_groups)
            else:
                # <<< 1copy (0dd_bpy_ops_wm_append,, ${'link=True':'link=False'}$)
                bpy.ops.wm.append(
                    filepath=os_path_join(file_path, inner_path, node_name),
                    directory=os_path_join(file_path, inner_path),
                    filename=node_name,
                    link=False)
                # >>>
                node = node_groups[node_name]

            md = oj.modifiers.new(node_name, "NODES")
            md.node_group = node
            # >>>
            return

        md = oj.modifiers.new(node_name, "NODES")
        md.node_group = node
        #|
    @staticmethod
    @ successResult
    def new_gn_append(oj, file_path, node_name):
        inner_path = "NodeTree"
        # /* 0dd_new_gn_append
        node_groups = bpy.data.node_groups
        if node_name in node_groups:
            old_node_groups = set(node_groups)
            # <<< 1copy (0dd_bpy_ops_wm_append,, ${'link=True':'link=False'}$)
            bpy.ops.wm.append(
                filepath=os_path_join(file_path, inner_path, node_name),
                directory=os_path_join(file_path, inner_path),
                filename=node_name,
                link=False)
            # >>>
            node = next(ob  for ob in node_groups  if ob not in old_node_groups)
        else:
            # <<< 1copy (0dd_bpy_ops_wm_append,, ${'link=True':'link=False'}$)
            bpy.ops.wm.append(
                filepath=os_path_join(file_path, inner_path, node_name),
                directory=os_path_join(file_path, inner_path),
                filename=node_name,
                link=False)
            # >>>
            node = node_groups[node_name]

        md = oj.modifiers.new(node_name, "NODES")
        md.node_group = node
        # */
    @staticmethod
    @ successResult
    def new_gn_link(oj, file_path, node_name):
        inner_path = "NodeTree"
        node_groups = bpy.data.node_groups
        name_tuple = node_name, file_path
        if name_tuple not in node_groups:
            # /* 0dd_bpy_ops_wm_append
            bpy.ops.wm.append(
                filepath=os_path_join(file_path, inner_path, node_name),
                directory=os_path_join(file_path, inner_path),
                filename=node_name,
                link=True)
            # */
        node = node_groups[name_tuple]
        md = oj.modifiers.new(node_name, "NODES")
        md.node_group = node
        #|
    @staticmethod
    def new_md_copy(oj, file_path, object_name, modifier_name):
        try:
            inner_path = "Object"
            objects = bpy.data.objects
            old_objects = set(objects)

            if object_name in objects:
                # <<< 1copy (0dd_bpy_ops_wm_append,, ${'link=True':'link=False', 'node_name':'object_name'}$)
                bpy.ops.wm.append(
                    filepath=os_path_join(file_path, inner_path, object_name),
                    directory=os_path_join(file_path, inner_path),
                    filename=object_name,
                    link=False)
                # >>>
                new_object = next(ob  for ob in objects if ob not in old_objects)
            else:
                # <<< 1copy (0dd_bpy_ops_wm_append,, ${'link=True':'link=False', 'node_name':'object_name'}$)
                bpy.ops.wm.append(
                    filepath=os_path_join(file_path, inner_path, object_name),
                    directory=os_path_join(file_path, inner_path),
                    filename=object_name,
                    link=False)
                # >>>
                new_object = objects[object_name]

            if not hasattr(new_object, "type") or oj.type != new_object.type:
                objects.remove(new_object)
                return False, "Source object type mismatch"
            if not hasattr(new_object, "modifiers") or not new_object.modifiers:
                objects.remove(new_object)
                return False, "Source object has no modifiers"
            if modifier_name not in new_object.modifiers:
                objects.remove(new_object)
                return False, "Source object modifier not found"
            source_md = new_object.modifiers[modifier_name]

            success, fails = ops_mds_copy_to_object(
                new_object, oj, [modifier_name], "COPY", True, True)

            objects.remove(new_object)

            if success: return True, ""
            else: return False, "Cannot copy modifiers from source object"
        except Exception as ex:
            return False, str(ex)
        return True, ""
        #|
    #|
    #|
class DropDownStartMenu(DropDownListUtil):
    __slots__ = ()

    def __init__(self, icon_LRBT):
        L, R, B, T = icon_LRBT
        area_items = []
        self.area_items = area_items
        pos = (L, T + SIZE_widget[0] * 12)

        items = [
            IdentifierNameValue("SettingEditor", "Settings", None),
            IdentifierNameValue("ModifierEditor", "Modifier Editor", None),
        ]

        super().__init__(None, pos, items,
            area_items = area_items,
            get_icon = self.get_icon,
            get_info = self.get_info,
            title = "Start Menu",
            size_x = round(D_SIZE['widget_width'] * 2.1),
            size_y = pos[1] - REGION_DATA.B - SIZE_tb[0] - SIZE_title[1],
            block_size = 1)

        area_tab = self.r_area_tab()
        button0 = ButtonFn(None, RNA_sys_off, self.bufn_sys_off)
        button1 = ButtonFn(None, RNA_sys_sleep, self.bufn_sys_sleep)
        g0 = ButtonSplit(None, button1, button0, gap=SIZE_border[3])
        area_items.append(BlockFull(area_tab, g0))
        area_tab.init_items_tab()
        #|

    def get_icon(self, e):
        if hasattr(e, "identifier"): return getattr(blg, f'GpuImg_{e.identifier}', GpuImgNull)()
        return GpuImgNull()
        #|
    def get_info(self, e):
        return ""
        #|

    def fin_callback(self):

        #|
        data = self.data
        if "fin_callfront" in data: data["fin_callfront"]()

        if data["use_text_output"] != None:

            item = None

            if data["use_text_output"]:
                tx = self.areas[0].blf_text.unclip_text
            else:
                if data["best_item"] == None:
                    tx = self.areas[0].blf_text.unclip_text
                else:
                    item = data["best_item"]
                    tx = item.name

            if item is None:
                name_to_item = {e.name: e  for e in self.areas[0].filt.items}
                if tx in name_to_item: item = name_to_item[tx]

            if item is not None:
                if hasattr(item, "identifier"):
                    bpy.ops.wm.vmd_editor('INVOKE_DEFAULT', id_class=item.identifier, use_pos=False, use_fit=False)

        data.clear()
        #|

    def bufn_sys_off(self):
        W_HEAD[-1].fin()
        self.fin_from_area()
        m.ADMIN.evt_sys_off()
        #|
    def bufn_sys_sleep(self):
        W_HEAD[-1].fin()
        self.fin_from_area()
        m.ADMIN.evt_sys_off(sleep=True)
        #|
    #|
    #|


def get_info_users(e):
    if hasattr(e, "library") and e.library and e.library.filepath:
        s = f"{e.library.filepath}  |  "
    else:
        s = ""

    if hasattr(e, "users"):
        if e.use_fake_user: return f'{s}{e.users} F'
        return f'{s}{e.users}'
    return s
    #|

class PreviewCache:
    __slots__ = (
        'w',
        'gpu_images',
        'bpy_data_type')

    def __init__(self, w, bpy_data_type):
        self.w = w
        self.gpu_images = {}
        self.bpy_data_type = bpy_data_type
        #|

    def kill(self):

        self.gpu_images.clear()
        del self.gpu_images
        #|

    def get_icon(self, e):
        if e in self.gpu_images: return self.gpu_images[e]
        else:
            gpu_image = GpuImgUtil(e)
            self.gpu_images[e] = gpu_image
            return gpu_image
        #|
    #|
    #|
class PreviewCacheMaterial(PreviewCache):
    __slots__ = (
        'temp_scene',
        'temp_world',
        'temp_mesh',
        'temp_plane',
        'temp_cam',
        'temp_camera',
        'temp_folder',
        'temp_filepath')

    def __init__(self, w, bpy_data_type):
        super().__init__(w, bpy_data_type)

        resolution = SIZE_widget[0] * 4

        temp_folder = mkdtemp()

        temp_filepath = f'{temp_folder}\\0.png'

        bpydata = bpy.data
        scene = bpydata.scenes.new("")
        scene.render.engine = "BLENDER_EEVEE"
        scene.render.image_settings.file_format = "PNG"
        scene.render.filepath = temp_filepath
        scene.eevee.taa_render_samples = 1
        scene.eevee.taa_samples = 0
        scene.eevee.use_taa_reprojection = False
        scene.render.resolution_x = resolution
        scene.render.resolution_y = resolution
        scene.frame_end = 1
        world = bpydata.worlds.new("")
        world.color = 1.0, 1.0, 1.0
        scene.world = world

        me = bpydata.meshes.new("")
        me.from_pydata([(-1.0, -1.0, 0.0), (1.0, -1.0, 0.0), (-1.0, 1.0, 0.0), (1.0, 1.0, 0.0)], [], [(0, 1, 3, 2)])
        me.uv_layers.new()
        plane = bpydata.objects.new("", me)
        cam_offset = 1
        cam_distance = 2
        cam = bpydata.cameras.new("")
        cam.type = "ORTHO"
        cam.clip_start = 0.1
        cam.clip_end = 10
        cam.ortho_scale = cam_distance
        camera = bpydata.objects.new("", cam)
        camera.location[2] = cam_offset + cam_distance
        scene.collection.objects.link(camera)
        scene.collection.objects.link(plane)
        scene.camera = camera

        self.temp_folder = temp_folder
        self.temp_filepath = temp_filepath
        self.temp_scene = scene
        self.temp_world = world
        self.temp_mesh = me
        self.temp_plane = plane
        self.temp_cam = cam
        self.temp_camera = camera
        #|

    def kill(self):
        del_folder(self.temp_folder)
        bpydata = bpy.data

        bpydata.objects.remove(self.temp_camera)
        bpydata.objects.remove(self.temp_plane)
        bpydata.cameras.remove(self.temp_cam)
        bpydata.meshes.remove(self.temp_mesh)
        bpydata.worlds.remove(self.temp_world)
        bpydata.scenes.remove(self.temp_scene)
        del self.temp_cam
        del self.temp_mesh
        del self.temp_camera
        del self.temp_plane
        del self.temp_world
        del self.temp_scene
        del self.temp_filepath
        del self.temp_folder
        super().kill()
        #|

    def get_icon(self, e):
        if e in self.gpu_images: return self.gpu_images[e]
        else:
            self.temp_plane.active_material = e
            bpy.ops.render.render(animation=False, write_still=True, scene=self.temp_scene.name)
            img = bpy_images_load(self.temp_filepath)
            img.alpha_mode = "PREMUL"
            gpu_image = GpuImgUtil(img)
            bpy_images_remove(img)
            self.gpu_images[e] = gpu_image
            return gpu_image
        #|
    #|
    #|


RNA_hsv = RnaFloatVector("hsv",
    name = "HSV",
    description = "Color Panel HSV",
    default = (0.0, 0.0, 0.0),
    subtype = "COLOR")
RNA_hex_str_glc = RnaString("hex_str",
    name = "Gamma Corrected Hex",
    default = "\"0\"",
    description = "Color Panel hex value.\nInvalid value in (\n" + NULL_INFO[0] + "\n)")
RNA_eyedropper = RnaButton("eyedropper",
    name = "Eyedropper",
    button_text = "",
    description = "Sample a color from the Blender window to store in a property.",
    size = -1)
RNA_yes = RnaButton("yes",
    name = "Yes",
    button_text = "Yes",
    description = "Button Yes.")
RNA_no = RnaButton("no",
    name = "No",
    button_text = "No",
    description = "Button No.")
RNA_save = RnaButton("save",
    name = "Save",
    button_text = "Save",
    description = "Button Save.",
    size = -3)
RNA_reset = RnaButton("reset",
    name = "Reset",
    button_text = "Reset",
    description = "Button Reset.",
    size = -3)
RNA_sys_off = RnaButton("sys_off",
    name = "System Off",
    button_text = "Off",
    description = "")
RNA_sys_sleep = RnaButton("sys_sleep",
    name = "System Sleep",
    button_text = "Sleep",
    description = "")


## _file_ ##
def _import_():
    #|

    # //* 0dd_import_blg
    # *// =|
    # <<< 1copy (0dd_import_blg,, $$)
    global FONT0,FONT1,D_SIZE,SIZE_tb,SIZE_title,SIZE_border,SIZE_dd_border,SIZE_filter,SIZE_widget,SIZE_dd_shadow_offset,SIZE_shadow_softness,SIZE_button,SIZE_block,SIZE_foreground,COL_box_val,COL_box_val_rim,COL_box_val_fo,COL_box_val_fg,COL_box_val_fg_error,COL_box_button_fg_info
    # >>>
    # <<< 1copy (0dd_import_blg,, ${'global': 'from . utilbl.blg import'}$)
    from . utilbl.blg import FONT0,FONT1,D_SIZE,SIZE_tb,SIZE_title,SIZE_border,SIZE_dd_border,SIZE_filter,SIZE_widget,SIZE_dd_shadow_offset,SIZE_shadow_softness,SIZE_button,SIZE_block,SIZE_foreground,COL_box_val,COL_box_val_rim,COL_box_val_fo,COL_box_val_fg,COL_box_val_fg_error,COL_box_button_fg_info
    # >>>

    # //* 0dd_import_m
    # *// =|
    # <<< 1copy (0dd_import_m,, $$)
    global P,Admin,W_MODAL,W_HEAD,W_DRAW,bring_to_front,REGION_DATA,UnitSystem,r_unit_factor,save_pref,bring_draw_to_top_safe
    # >>>
    # <<< 1copy (0dd_import_m,, ${'global': 'from . m import'}$)
    from . m import P,Admin,W_MODAL,W_HEAD,W_DRAW,bring_to_front,REGION_DATA,UnitSystem,r_unit_factor,save_pref,bring_draw_to_top_safe
    # >>>


    global m, BL_RNA_PROP_keymaps, D_EDITOR, D_format, bpy_images_load, bpy_images_remove
    from .  import m

    BL_RNA_PROP_keymaps = P.keymaps.bl_rna.properties
    from . userops import D_EDITOR
    D_format = m.UnitSystem.D_format

    bpy_images_load = bpy.data.images.load
    bpy_images_remove = bpy.data.images.remove
    #|
