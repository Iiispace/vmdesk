import bpy

from bpy.types import Operator
from bpy.props import StringProperty 

class OpDev(Operator):
    __slots__ = ()
    bl_idname = "wm.vmd_dev"
    bl_label = "VMD Dev"
    bl_options = {'INTERNAL'}

    key: StringProperty(name = "Key")

    def invoke(self, context, event):
        #|
        getattr(DevFns, self.key)(context, event)
        return {'FINISHED'}
        #|
    #|
    #|


class DevFns:
    __slots__ = ()

    @staticmethod
    def fn_e(context, evt):

        self = open_modifier_editor(evt, False)
        self.dxy(20, 0)
        self.areas[3].items[0].bufn_new_modifier()
        # if bpy.context.object:
        #     ob = bpy.context.object
        #     if hasattr(ob, "modifiers"):
        #         for e in bpy.types.Modifier.bl_rna.properties['type'].enum_items:
        #             ob.modifiers.new("", e.identifier)
        # ty = "NODES"
        # ty = "HOOK"
        # bpy.data.objects["Cube"].modifiers.new("", type=ty)

        # bpy.data.objects["Sphere"].modifiers.new("", type=ty)
        # bpy.ops.wm.vmd_editor('INVOKE_DEFAULT', id_class='ModifierEditor', use_pos=False, use_fit=False)
        # self = m.W_MODAL[1]
        # self.dxy(-450, 0)
        # self.set_active_object(object=bpy.data.objects["Sphere"])
        # self.areas[4].filt.set_active_index(1, True)

        # bpy.data.textures.new("", "IMAGE")
        # bpy.data.textures.new("", "NOISE")
        # bpy.data.textures.new("", "WOOD")
        # bpy.data.objects["Cube"].modifiers[-1].cache_file = bpy.data.cache_files[0]

        # e = self.areas[4].filt.match_items
        # self.areas[4].filt.selnames = {r: e[r].name  for r in range(4, 8)}
        # self.areas[4].filt.selnames[10] = e[10].name
        # self.areas[4].filt.selnames[11] = e[11].name
        # self.dxy(200, 0)

        # bpy.ops.wm.vmd_editor('INVOKE_DEFAULT', id_class='ModifierEditor', use_pos=False, use_fit=False)
        # w1 = m.W_MODAL[1]
        # w1.dxy(-400, 300)
        # w1.set_active_object(object=bpy.data.objects["Cube"])

        # bpy.ops.wm.vmd_editor('INVOKE_DEFAULT', id_class='ModifierEditor', use_pos=False, use_fit=False)
        # w2 = m.W_MODAL[2]
        # w2.dxy(-500, -200)
        # w2.set_active_object(object=bpy.data.objects["Torus"])


    @staticmethod
    def fn_o(context, evt):

        self = open_setting_editor(evt)
        return
        #|
    @staticmethod
    def get_mouse(context, evt):


        ob = bpy.context.object
        gen_md_code(ob.modifiers[-1])
        return
        # for idd, at in bpy.types.Modifier.bl_rna.properties['type'].enum_items.items():
        #     ob.modifiers.new(type=idd, name=idd)

        from .  import m
        self = m.W_MODAL[0]

        return
        #|
    @staticmethod
    def fn_unit_to_feet(context, evt):
        bpy.context.scene.unit_settings.system = "IMPERIAL"
        bpy.context.scene.unit_settings.scale_length = 2
        #|
    @staticmethod
    def fn_unit_to_metric(context, evt):
        bpy.context.scene.unit_settings.system = "METRIC"
        #|
    #|
    #|

class TaskBar:
    __slots__ = ()
    #|
    @staticmethod
    def call_first_task(id_class='ModifierEditor'):
        #| call 2 editor and press first task in taskbar
        bpy.ops.wm.vmd_editor('INVOKE_DEFAULT', id_class=id_class, use_pos=False, use_fit=False)
        bpy.ops.wm.vmd_editor('INVOKE_DEFAULT', id_class=id_class, use_pos=False, use_fit=False)
        from .  import m
        from . util.types import Name
        from . dd import TaskMenu

        self = m.ADMIN
        task = m.TASKS[0]
        icon = task.box_icon
        # <<< 1dict (2win_blfs,, $
        # items = [Name(w.blfs[|blf_title|].unclip_text)  for w in task.ws]$)
        items = [Name(w.blfs[0].unclip_text)  for w in task.ws]
        # >>>

        items = [Name(e) for e in (
            "oenth_",
            "on..ona_abet",
            "cubecube",
            "cube_cube",
            "cube e 5.3",
            "whole word.u",
            "box 2",
            "box.001",
            "box.002",
            "box.003",
            "box.004",
            "box.001",
            "box.001",
            "box.001",
        )] + [Name(f'Cube.{r}') for r in range(100)]

        TaskMenu(w=self, pos=(icon.L, icon.B), width=300, items=items,
            use_titlebar=True, title=task.ws[0].__class__.name, input="cube")
        #|
    #|

def gen_md_code(md):
    s_head = '''
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = []

        '''

    s8 = "\n" + " " * 8
    ls = ""
    ls += f'def init_tab_{md.type}(self):{s8}'
    ls += f"print('    areas_I_AreaBlockTabModifierEditor_I_init_tab_{md.type}')"
    ls += s_head

    for at, e in md.bl_rna.properties.items():
        if at in {
            "rna_type",
            "name",
            "type",
            "show_viewport",
            "show_render",
            "show_in_editmode",
            "show_on_cage",
            "show_on_cage",
            "show_expanded",
            "is_active",
            "is_override_data",
            "use_apply_on_spline",
            "execution_time",
        }: continue

        if at == "object":
            ls += f'ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {chr(123)}"MESH"{chr(125)}, r_except_objects=self.r_object_set), rr_refdriver("object")),{s8}'
            continue
        elif at == "vertex_group":
            ls += f'ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),{s8}'
            ls += f'g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group")){s8}'
            continue

        ty = e.type
        if ty == "BOOLEAN":
            ls += f'ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["{at}"], pp), *rr_fcdr("{at}")),{s8}'
        elif ty == "INT":
            if e.is_array:
                ls += f'ButtonGroupAnimVector(b0, ButtonIntVectorPush(None, rnas["{at}"], pp), *rr_fcdr_array("{at}", RANGE_3)),{s8}'
            else:
                ls += f'ButtonGroupAnim(b0, ButtonIntPush(None, rnas["{at}"], pp), *rr_fcdr("{at}")),{s8}'
        elif ty == "FLOAT":
            if e.is_array:
                ls += f'ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["{at}"], pp), *rr_fcdr_array("{at}", RANGE_3)),{s8}'
            else:
                ls += f'ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["{at}"], pp), *rr_fcdr("{at}")),{s8}'
        elif ty == "ENUM":
            if e.is_enum_flag:
                ls += f'ButtonGroupAnim(b0, ButtonEnumXYFlagPush(None, rnas["{at}"], pp), *rr_fcdr("{at}")),{s8}'
            else:
                ls += f'ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["{at}"], pp), *rr_fcdr("{at}")),{s8}'
        else:
            ls += f'{at}: {ty}{s8}'

    ls += f'self.items[:] = [b0]\n\n        def upd_data_callback():\n            modifier = self.w.active_modifier\n\n        self.upd_data_callback = upd_data_callback\n        #|'


    #|

def r_all_pref_rnas(pp):
    ls = []
    for k, e in pp.bl_rna.properties.items():
        if k in {"bl_idname", "rna_type", "name"}: continue

        if e.type == "POINTER": ls += r_all_pref_rnas(getattr(pp, k))
        else: ls.append(e)

    return ls

def open_setting_editor(evt, tab=None): # tab = ("search",)
    from .  import m
    bpy.ops.wm.vmd_editor('INVOKE_DEFAULT', id_class='SettingEditor', use_pos=False, use_fit=False)
    self = m.W_MODAL[-1]
    if tab is not None:
        self.areas[2].init_tab(tab)
        self.upd_data()
    m.Admin.EVT = evt
    return self
    #|
def open_modifier_editor(evt, sync_object=None, sync_modifier=None):
    from .  import m
    bpy.ops.wm.vmd_editor('INVOKE_DEFAULT', id_class='ModifierEditor', use_pos=False, use_fit=False)
    self = m.W_MODAL[-1]

    if sync_object is not None:
        self.areas[1].items[0].set_sync(sync_object)

    if sync_modifier is not None:
        self.areas[3].items[0].set_sync(sync_modifier)
    return self
    #|
def debug_setting_search(evt):
    from .  import m

    all_pref_rnas = r_all_pref_rnas(m.P)

    self = open_setting_editor(evt)
    a = self.areas[2]
    bu_find = a.items[0].buttons[0]
    bu_find.evt_toggle_match_case(True)
    bu_find.evt_toggle_match_whole_word(True)
    items = a.items[0].items
    items[0].button0.set(False)
    items[1].button0.set(True)
    items[2].button0.set(False)
    items[4].button0.set(True)
    items[5].button0.set(True)
    items[6].button0.set(True)
    items[7].button0.set(True)
    items[8].button0.set(True)

    messages = []

    for rna in all_pref_rnas:
        bu_find.set(rna.identifier)
        if len(a.items) == 1:
            messages.append(f"Not find: {rna.identifier}")
        elif len(a.items) != 2:
            messages.append(f"More than one: {rna.identifier}")


    for message in messages: print(message)

    #|
