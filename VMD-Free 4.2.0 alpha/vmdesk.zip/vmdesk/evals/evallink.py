import bpy

def tr_upd_md(fc, obj):
    try:
        dr = fc.driver
        path = fc.data_path
        tar = dr.variables[0].targets[0]

        vl = eval(f'tar.id.{tar.data_path}')
        path = 'obj.' + fc.data_path[2 : -2].replace('\\"', '"')

        if eval(path) != vl:
            exec(path + "=vl")

        return True
    except: return False
    #|
