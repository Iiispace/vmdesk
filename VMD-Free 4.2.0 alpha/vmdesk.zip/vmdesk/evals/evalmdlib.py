import bpy

def eval_md_lib(code):
    try:
        exec(code)
    except Exception as exx:
        return None, str(exx)

    try:
        if "directories" in locals(): return locals()["directories"], ""

        return None, 'Local variable "directories" requires'
    except Exception as exx:
        return None, str(exx)

    return None, "Unknown Error"
    #|
