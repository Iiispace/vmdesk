import bpy

from blf import size as blfSize
from blf import color as blfColor
from blf import position as blfPos
from blf import draw as blfDraw
from blf import dimensions as blfDimen
from bpy.types import Operator, SpaceView3D, Object
from gpu.state import blend_set
from bpy.app.handlers import depsgraph_update_post
from bpy.app.handlers import frame_change_post
from bpy.utils.units import to_value as units_to_value
from bpy.utils.units import to_string as units_to_string
from bpy.types import TOPBAR_HT_upper_bar
from math import floor
from collections import OrderedDict
from pathlib import Path

from . keysys import get_evt, kill_evt, kill_evt_except, MOUSE, TRIGGER, EVT_TYPE, MOUSE_WINDOW
from . util.types import RegionData, NameValue, NameLibrary, NameLibraryIdentifier, FilepathVersion, RnaButton
from . util.deco import successResult
from . util.com import (
    N,
    rs_format_int6,
    rs_format_float6,
    rs_format_float6_rstrip,
    rs_format_float_left,
    r_py_end_bracket_index,
    r_glob_files)
from . util.const import (
    D_unit_replace,
    D_length_unit_to_display,
    D_mass_unit_to_display,
    D_time_unit_to_display,
    D_temperature_unit_to_display,
    FLOAT_deg)
from . utilbl.ops import OpScanFolder
from . utilbl.md import (
    md_rnas_MESH,
    md_rnas_CURVE,
    md_rnas_SURFACE,
    md_rnas_VOLUME,
    md_rnas_LATTICE)
from . dd import DropDownTask, DropDownOk, DropDownText, DropDownStartMenu
from . evals.evalutil import bpyeval_ob
from . evals.evalmdlib import eval_md_lib
from .  import area, block


ADDON_FOLDER = __file__[: -4]
RELOAD_STATE = [False]

P = None

W_PROCESS = []
W_HEAD = []
W_MODAL = []
W_DRAW = []
W_FOCUS = [None]
TASKS = []
D_TASKS_IND = {}
DRAW_HANDLE = None
ADMIN = None
CONTEXT_AREA = None
CONTEXT_REGION = None
CURSOR_WARP = None
REGION_DATA = RegionData()
TAG_UPDATE = [False, False, True] # tag_update, is_updating, is_enable_auto_update
TAG_RENAME = [False]
LIBRARY_MODIFIER = None

_pan_xy = [0, 0]
_pan_xy_org = [0, 0]
_is_allow_task_evt = True


def blenddata_update_post(dummy):
    TAG_UPDATE[0] = True

    try: Admin.REDRAW()
    except: pass
    #|

class BlendDataTemp:
    __slots__ = ()

    active_object = None
    active_object_name = ""
    objects = None

    @classmethod
    def kill(cls):
        cls.objects = None
        #|
    @classmethod
    def init(cls):
        active_object = bpy.context.object
        cls.active_object = active_object
        cls.active_object_name = active_object.name  if hasattr(active_object, "name") else ""
        cls.objects = None
        #|
    @classmethod
    def r_upd_objects(cls):
        if cls.objects == None:
            objects = tuple(
                # <<< 1copy (bl_objects,, $$)
                bpy.context.view_layer.objects
                # >>>
            )
            cls.objects = objects
            return objects
        return cls.objects
        #|

    @staticmethod
    def r_all_objects():
        return tuple(
            # <<< 1copy (bl_objects,, $$)
            bpy.context.view_layer.objects
            # >>>
        )
    #|
    #|

def update_data():
    TAG_UPDATE[0] = False
    # /* 0m_update_data
    TAG_UPDATE[1] = True

    BlendDataTemp.init()
    for e in W_MODAL: e.upd_data()
    BlendDataTemp.kill()
    TAG_UPDATE[1] = False

    if TAG_RENAME[0] is True:
        TAG_RENAME[0] = False
    # */
def i_draw_callback_px():
    if bpy.context.area == CONTEXT_AREA:
        if TAG_UPDATE[0]:
            # /* 0m_draw_update_data
            TAG_UPDATE[0] = False
            if TAG_UPDATE[2]:
                # <<< 1copy (0m_update_data,, $$)
                TAG_UPDATE[1] = True

                BlendDataTemp.init()
                for e in W_MODAL: e.upd_data()
                BlendDataTemp.kill()
                TAG_UPDATE[1] = False

                if TAG_RENAME[0] is True:
                    TAG_RENAME[0] = False
                # >>>
            # */

        for e in W_DRAW: e.u_draw()

        ADMIN.u_draw()
    #|
U_DRAW_CALLBACK_PX = i_draw_callback_px
def draw_callback_px():
    try: ADMIN.u_draw
    except:
        kill_admin()
        return

    U_DRAW_CALLBACK_PX()
    #|

def remove_timer():
    bpy.context.window_manager.event_timer_remove(Admin.TIMER)
    Admin.TIMER = None

    #|

def tag_obj_rename(): TAG_RENAME[0] = True

ACTIVE_MODIFIER = [None]
def topbar_header_draw_callback(self, context):
    ob = context.object
    if hasattr(ob, "modifiers") and hasattr(ob.modifiers, "active"):
        if ob.modifiers.active != ACTIVE_MODIFIER[0]:
            ACTIVE_MODIFIER[0] = ob.modifiers.active
            TAG_UPDATE[0] = True

    #|

def reg_update_post_and_subscribe():
    if blenddata_update_post not in depsgraph_update_post:   depsgraph_update_post.append(blenddata_update_post)
    if blenddata_update_post not in frame_change_post:       frame_change_post.append(blenddata_update_post)
    TOPBAR_HT_upper_bar.remove(topbar_header_draw_callback)
    TOPBAR_HT_upper_bar.append(topbar_header_draw_callback)

    subscribe_rna(
        key=(Object, "name"),
        owner=tag_obj_rename,
        args=(),
        notify=tag_obj_rename)
    #|
def unreg_update_post_and_unsubscribe():
    if blenddata_update_post in depsgraph_update_post:   depsgraph_update_post.remove(blenddata_update_post)
    if blenddata_update_post in frame_change_post:       frame_change_post.remove(blenddata_update_post)
    TOPBAR_HT_upper_bar.remove(topbar_header_draw_callback)

    clear_by_owner(tag_obj_rename)
    #|

# Need change ret
def kill_admin():
    if Admin.TIMER is not None: remove_timer()
    area.unreg_all_timer()
    block.unreg_all_timer()

    unreg_update_post_and_unsubscribe()

    bpy.context.window.cursor_modal_restore()

    try: Admin.REDRAW()
    except: pass

    global DRAW_HANDLE, ADMIN

    SpaceView3D.draw_handler_remove(DRAW_HANDLE, 'WINDOW')
    DRAW_HANDLE = None
    prefs_callback_disable()

    # <<< 1copy (0m_Admin,, $$, $lambda line: line  if line.find('=') == -1 else line.replace(
    #     line.strip(), f'Admin.{line.strip()}')$)
    # ---------------------------------------------------------------------------------------------------------
    Admin.IS_RUNNING = False

    Admin.CONTEXT = None
    Admin.EVT = None
    Admin.REDRAW = None
    Admin.TIMER = None
    Admin.TAG_CURSOR = ''
    Admin.IS_INSIDE = False
    Admin.TB_ENABLE = True
    Admin.CURSOR_TYPE = None
    # ---------------------------------------------------------------------------------------------------------
    # >>>

    W_HEAD.clear()
    W_FOCUS[0] = None
    TAG_UPDATE[:] = [False, False, True]
    ADMIN = None


    return {'FINISHED'}
    #|

def call_admin(context):
    if Admin.IS_RUNNING: return True
    if context.area.type != 'VIEW_3D': return False
    if context.region.type != 'WINDOW': return False

    bpy.ops.wm.vmd_admin('INVOKE_DEFAULT')

    if W_MODAL: update_data()
    upd_size()
    return True
    #|

def push_modal_safe():
    if ADMIN == None: return
    ADMIN.push_modal()
    #|

def upd_size():
    #| call from Npanel
    prefs_callback_disable()

    upd_font_size()

    ADMIN.upd_size()

    for e in W_PROCESS: e.upd_size()

    prefs_callback_enable()
    #|

def upd_win_active(): #| call from Npanel
    if not W_MODAL: return

    if not W_HEAD: UpdWinActiveHead() # update P_temp when release
    prefs.U_UPD_WIN_ACTIVE = N
    # <<< 1copy (disable_auto_upd,, $$)
    TAG_UPDATE[2] = False
    # >>>

    self = W_MODAL[-1]
    x, y = P_temp.pos
    dx = x - self.box_win.L
    dy = y - self.box_win.T
    if dx or dy:
        self.dxy(dx, dy)
    else: # ref: win.i_modal_resize_click_R
        sizeX, sizeY = P_temp.size

        dx = sizeX - self.box_win.R + self.box_win.L
        if dx:
            _lim_R = REGION_DATA.R
            if self.scissor.w + dx < 4 * SIZE_title[0]: dx = 4 * SIZE_title[0] - self.scissor.w
            else:
                if self.box_win.R + dx > _lim_R: dx = _lim_R - self.box_win.R
            self.scissor.w += dx
            self.box_win.R += dx
            self.box_rim.R += dx
            # <<< 1dict (2win_boxes,, $
            # e = self.boxes[|box_shadow|]$)
            e = self.boxes[0]
            # >>>
            e.R += dx
            self.box_title_button.dx(dx)
            # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_title'}$)
            blfSize(FONT0, D_SIZE['font_title'])
            blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
            # >>>
            # <<< 1dict (2win_blfs,, $
            # blf_title = self.blfs[|blf_title|]$)
            blf_title = self.blfs[0]
            # >>>
            blf_title.text = r_blf_clipping_end(blf_title.unclip_text, blf_title.x,
                self.box_title_button.L - D_SIZE['font_title_dx'])

            self.dxy(0, 0)
            self.resize_upd()
        else:
            dy = self.box_win.title_B - self.box_win.B - sizeY
            if dy:
                _lim_B = REGION_DATA.B + SIZE_tb[0]
                if self.scissor.h - dy < 0: dy = self.scissor.h
                else:
                    if self.box_win.B + dy < _lim_B: dy = _lim_B - self.box_win.B
                self.scissor.y += dy
                self.scissor.h -= dy
                self.box_win.B += dy
                self.box_rim.B += dy
                # <<< 1dict (2win_boxes,, $
                # e = self.boxes[|box_shadow|]$)
                e = self.boxes[0]
                # >>>
                e.B += dy

                self.dxy(0, 0)
                self.resize_upd()
            else:
                posX, posY = P_temp.canvas
                e = self.areas[0].box_area
                dx = posX - e.L + self.box_win.L + SIZE_border[0]
                if dx:
                    for e in self.areas: e.dxy(dx, 0)
                else:
                    dy = posY - e.T + self.box_win.title_B - SIZE_border[0]
                    for e in self.areas: e.dxy(0, dy)

    # <<< 1copy (enable_auto_upd,, $$)
    TAG_UPDATE[2] = True
    # >>>
    prefs.U_UPD_WIN_ACTIVE = upd_win_active
    #|

def upd_pref():
    TAG_UPDATE[0] = True

    #|

def prefs_callback_enable():
    prefs.U_UPD_SIZE = upd_size
    prefs.U_UPD_WIN_ACTIVE = upd_win_active
    prefs.U_UPD_PREF = upd_pref
    #|
def prefs_callback_disable():
    prefs.U_UPD_SIZE = N
    prefs.U_UPD_WIN_ACTIVE = N
    prefs.U_UPD_PREF = N
    #|

def upd_temp_pref(self):
    prefs.U_UPD_WIN_ACTIVE = N
    box_win = self.box_win
    P_temp.pos = box_win.L, box_win.T
    P_temp.size = box_win.R - box_win.L, box_win.title_B - box_win.B
    e = self.areas[0].box_area
    P_temp.canvas = e.L - box_win.L - SIZE_border[0], e.T - box_win.title_B + SIZE_border[0]
    prefs.U_UPD_WIN_ACTIVE = upd_win_active
    #|
def bring_to_front(self):

    #|
    upd_temp_pref(self)

    if W_MODAL:
        W_MODAL[-1].box_win.color = COL_win_title_inactive

    W_MODAL.remove(self)
    W_DRAW.remove(self)
    W_MODAL.append(self)
    W_DRAW.append(self)

    self.box_win.color = COL_win_title

    # <<< 1dict (2m_ADMIN_boxes,, $
    # ADMIN.boxes[|box_tb_active|].LRBT_upd(*TASKS[D_TASKS_IND[self.__class__.__name__]].box_icon.r_LRBT())$)
    ADMIN.boxes[2].LRBT_upd(*TASKS[D_TASKS_IND[self.__class__.__name__]].box_icon.r_LRBT())
    # >>>
    Admin.REDRAW()
    #|
def bring_draw_to_top_safe(self):
    if self in W_DRAW:
        W_DRAW.remove(self)
        W_DRAW.append(self)
        return True
    return False
    #|

def init_loop_mouse(cursor_icon='HAND'):
    #|
    global _loop_mouse_info_L, _loop_mouse_info_R, _loop_mouse_info_B, _loop_mouse_info_T, _loop_mouse_info_L2, _loop_mouse_info_R2, _loop_mouse_info_B2, _loop_mouse_info_T2, _loop_mouse_info_dx_lim, _loop_mouse_info_dy_lim

    context_window = bpy.context.window

    _loop_mouse_info_L = 3
    _loop_mouse_info_R = context_window.width - 6
    _loop_mouse_info_B = 3
    _loop_mouse_info_T = context_window.height - 6
    _loop_mouse_info_L2 = _loop_mouse_info_L + 5
    _loop_mouse_info_R2 = _loop_mouse_info_R - 5
    _loop_mouse_info_B2 = _loop_mouse_info_B + 5
    _loop_mouse_info_T2 = _loop_mouse_info_T - 5
    _loop_mouse_info_dx_lim = (_loop_mouse_info_R - _loop_mouse_info_L) // 2
    _loop_mouse_info_dy_lim = (_loop_mouse_info_T - _loop_mouse_info_B) // 2

    _pan_xy[:] = MOUSE_WINDOW
    _pan_xy_org[:] = MOUSE_WINDOW
    Admin.TAG_CURSOR = cursor_icon
    #|
def end_loop_mouse(override_pos=None):
    #|
    if override_pos is None:
        CURSOR_WARP(*_pan_xy_org)
        MOUSE[:] = _pan_xy_org
    else:
        x, y = override_pos
        if x == None: x = _pan_xy_org[0]
        if y == None: y = _pan_xy_org[1]
        CURSOR_WARP(x, y)
        MOUSE[:] = x, y
    Admin.TAG_CURSOR = 'DEFAULT'
    #|
def loop_mouse():
    #|
    if MOUSE_WINDOW[0] <= _loop_mouse_info_L:
        if MOUSE_WINDOW[1] <= _loop_mouse_info_B:
            CURSOR_WARP(_loop_mouse_info_R2, _loop_mouse_info_T2)
            _pan_xy[0] = _loop_mouse_info_R2
            _pan_xy[1] = _loop_mouse_info_T2
        elif MOUSE_WINDOW[1] >= _loop_mouse_info_T:
            CURSOR_WARP(_loop_mouse_info_R2, _loop_mouse_info_B2)
            _pan_xy[0] = _loop_mouse_info_R2
            _pan_xy[1] = _loop_mouse_info_B2
        else:
            CURSOR_WARP(_loop_mouse_info_R2, MOUSE_WINDOW[1])
            _pan_xy[0] = _loop_mouse_info_R2
            _pan_xy[1] = MOUSE_WINDOW[1]
    elif MOUSE_WINDOW[0] >= _loop_mouse_info_R:
        if MOUSE_WINDOW[1] <= _loop_mouse_info_B:
            CURSOR_WARP(_loop_mouse_info_L2, _loop_mouse_info_T2)
            _pan_xy[0] = _loop_mouse_info_L2
            _pan_xy[1] = _loop_mouse_info_T2
        elif MOUSE_WINDOW[1] >= _loop_mouse_info_T:
            CURSOR_WARP(_loop_mouse_info_L2, _loop_mouse_info_B2)
            _pan_xy[0] = _loop_mouse_info_L2
            _pan_xy[1] = _loop_mouse_info_B2
        else:
            CURSOR_WARP(_loop_mouse_info_L2, MOUSE_WINDOW[1])
            _pan_xy[0] = _loop_mouse_info_L2
            _pan_xy[1] = MOUSE_WINDOW[1]
    elif MOUSE_WINDOW[1] <= _loop_mouse_info_B:
        CURSOR_WARP(MOUSE_WINDOW[0], _loop_mouse_info_T2)
        _pan_xy[0] = MOUSE_WINDOW[0]
        _pan_xy[1] = _loop_mouse_info_T2
    elif MOUSE_WINDOW[1] >= _loop_mouse_info_T:
        CURSOR_WARP(MOUSE_WINDOW[0], _loop_mouse_info_B2)
        _pan_xy[0] = MOUSE_WINDOW[0]
        _pan_xy[1] = _loop_mouse_info_B2
    else:
        _pan_xy[0] = MOUSE_WINDOW[0]
        _pan_xy[1] = MOUSE_WINDOW[1]
    #|
def r_pan_dxy():
    #|
    if P.pan_invert:
        dx = _pan_xy[0] - MOUSE_WINDOW[0]
        dy = _pan_xy[1] - MOUSE_WINDOW[1]
    else:
        dx = MOUSE_WINDOW[0] - _pan_xy[0]
        dy = MOUSE_WINDOW[1] - _pan_xy[1]

    if abs(dx) > _loop_mouse_info_dx_lim: dx = 0
    if abs(dy) > _loop_mouse_info_dy_lim: dy = 0
    return dx, dy
    #|
def r_mouse_dxy():
    #|
    dx = MOUSE_WINDOW[0] - _pan_xy[0]
    dy = MOUSE_WINDOW[1] - _pan_xy[1]

    if abs(dx) > _loop_mouse_info_dx_lim: dx = 0
    if abs(dy) > _loop_mouse_info_dy_lim: dy = 0
    return dx, dy
    #|
def r_mouse_from_region(x, y):
    return x + Admin.EVT.mouse_x - Admin.EVT.mouse_region_x, y + Admin.EVT.mouse_y - Admin.EVT.mouse_region_y
    #|
def r_mouse_from_window(x, y):
    return x + Admin.EVT.mouse_region_x - Admin.EVT.mouse_x, y + Admin.EVT.mouse_region_y - Admin.EVT.mouse_y
    #|

def save_pref():

    bpy.ops.wm.save_userpref()
    report("Preferences saved")
    #|


def active_object_set(e):
    try:
        bpy.context.view_layer.objects.active = e
        return True
    except: return False
    #|
def object_mode_set(s):
    try:
        bpy.ops.object.mode_set(mode=s)
        return True
    except: return False
    #|

def modal_object_picker_init(allow_types, r_except_objects, end_fn):
    kill_evt_except()
    context = bpy.context
    old_object = context.object
    old_selected_objects = context.selected_objects.copy()
    old_mode = old_object.mode  if hasattr(old_object, "mode") else None

    REDRAW = Admin.REDRAW
    bpy_ops_view3d_select = bpy.ops.view3d.select
    bpy_ops_object_select_all = bpy.ops.object.select_all

    object_mode_set("OBJECT")
    bpy_ops_object_select_all(action="DESELECT")
    context.window.cursor_modal_set(P.cursor_picker)
    except_objects = set()  if r_except_objects == None else r_except_objects()

    focus_object = None
    shadow_dL, shadow_dR, shadow_dB, shadow_dT = blg.SIZE_dd_shadow_offset

    widget_full_h = D_SIZE['widget_full_h']
    widget_h = SIZE_widget[0]
    widget_rim = SIZE_border[3]
    font_size = D_SIZE['font_main']
    font_dx = D_SIZE['font_main_dx']
    font_dT = D_SIZE['font_main_dT']
    font_dx2 = font_dx + font_dx
    regionR = REGION_DATA.R
    regionB = REGION_DATA.B + widget_full_h
    regionT = REGION_DATA.T

    # box_shadow = blg.GpuShadowDropDown(d=blg.SIZE_shadow_softness[1])
    box_bg = blg.GpuBox_block()
    box_button = blg.GpuRim(blg.COL_box_text, blg.COL_box_text_rim, d=widget_rim)
    GpuImg_OBJECT_DATA = blg.GpuImg_OBJECT_DATA
    box_icon_object = GpuImg_OBJECT_DATA()
    blf_name = blg.BlfColor(color=blg.COL_box_text_fg)

    def i_draw_object_picker():
        if focus_object is not None:
            blend_set('ALPHA')
            # box_shadow.bind_draw()
            box_bg.bind_draw()
            box_button.bind_draw()
            box_icon_object.bind_draw()

            e = blf_name
            blfSize(FONT0, D_SIZE['font_main'])
            blfColor(FONT0, *e.color)
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|
    def localmodal_fin(confirm=False):
        kill_evt_except()
        context.window.cursor_modal_set("DEFAULT")
        global U_DRAW_CALLBACK_PX
        U_DRAW_CALLBACK_PX = i_draw_callback_px
        ADMIN.u_modal = ADMIN.i_modal

        bpy_ops_object_select_all(action="DESELECT")
        for e in old_selected_objects: e.select_set(True)
        active_object_set(old_object)
        object_mode_set(old_mode)

        try:
            if confirm and focus_object: end_fn(focus_object)
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Unexpected error, please report to the author: 01\n{ex}')
        update_data()
        #|
    def i_localmodal_object_picker(evt):
        REDRAW()
        get_evt()
        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']() or TRIGGER['dd_esc']():
            localmodal_fin()
            return {'RUNNING_MODAL'}
        if TRIGGER['click']() or TRIGGER['dd_confirm']():
            localmodal_fin(True)
            return {'RUNNING_MODAL'}

        bpy_ops_object_select_all("INVOKE_DEFAULT", action="DESELECT")
        bpy_ops_view3d_select("INVOKE_DEFAULT", deselect_all=True)
        ob = context.selected_objects[0]  if context.selected_objects else None
        if ob in except_objects: ob = None
        if ob != None and allow_types != None:
            if ob.type not in allow_types: ob = None

        nonlocal focus_object
        if ob != focus_object:
            focus_object = ob
            if ob is not None:
                # /* 0m_init_picker_draw
                blfSize(FONT0, font_size)
                x, y = MOUSE
                L = x + widget_full_h
                T = y
                B = T - widget_full_h
                R = L + widget_full_h + font_dx2 + round(blfDimen(FONT0, ob.name)[0])
                if R > regionR:
                    dx = regionR - R
                    R += dx
                    L += dx
                if T > regionT:
                    dy = regionT - T
                    T += dy
                    B += dy
                elif T < regionB:
                    dy = regionB - B - widget_full_h
                    T += dy
                    B += dy

                box_button.L = L
                box_button.R = R
                box_button.B = B
                box_button.T = T
                box_button.upd()
                L0, R0, B0, T0 = box_button.inner
                box_icon_object.LRBT_upd(L0, L0 + widget_h, B0, T0)
                blf_name.x = box_icon_object.R + font_dx
                blf_name.y = T0 - font_dT
                L -= widget_rim
                R += widget_rim
                B -= widget_rim
                T += widget_rim
                box_bg.LRBT_upd(L, R, B, T)
                # box_shadow.L = L + shadow_dL -100
                # box_shadow.R = R + shadow_dR
                # box_shadow.B = B + shadow_dB
                # box_shadow.T = T + shadow_dT + 100
                # box_shadow.upd()

                blf_name.text = ob.name
                img_cls = getattr(blg, f"GpuImg_OUTLINER_OB_{ob.type}", GpuImg_OBJECT_DATA)
                if box_icon_object.__class__ != img_cls: box_icon_object.__class__ = img_cls
                # */
        else:
            if ob is not None:
                # <<< 1copy (0m_init_picker_draw,, $$)
                blfSize(FONT0, font_size)
                x, y = MOUSE
                L = x + widget_full_h
                T = y
                B = T - widget_full_h
                R = L + widget_full_h + font_dx2 + round(blfDimen(FONT0, ob.name)[0])
                if R > regionR:
                    dx = regionR - R
                    R += dx
                    L += dx
                if T > regionT:
                    dy = regionT - T
                    T += dy
                    B += dy
                elif T < regionB:
                    dy = regionB - B - widget_full_h
                    T += dy
                    B += dy

                box_button.L = L
                box_button.R = R
                box_button.B = B
                box_button.T = T
                box_button.upd()
                L0, R0, B0, T0 = box_button.inner
                box_icon_object.LRBT_upd(L0, L0 + widget_h, B0, T0)
                blf_name.x = box_icon_object.R + font_dx
                blf_name.y = T0 - font_dT
                L -= widget_rim
                R += widget_rim
                B -= widget_rim
                T += widget_rim
                box_bg.LRBT_upd(L, R, B, T)
                # box_shadow.L = L + shadow_dL -100
                # box_shadow.R = R + shadow_dR
                # box_shadow.B = B + shadow_dB
                # box_shadow.T = T + shadow_dT + 100
                # box_shadow.upd()

                blf_name.text = ob.name
                img_cls = getattr(blg, f"GpuImg_OUTLINER_OB_{ob.type}", GpuImg_OBJECT_DATA)
                if box_icon_object.__class__ != img_cls: box_icon_object.__class__ = img_cls
                # >>>
        return {'RUNNING_MODAL'}
        #|

    REDRAW()
    global U_DRAW_CALLBACK_PX
    U_DRAW_CALLBACK_PX = i_draw_object_picker
    ADMIN.u_modal = i_localmodal_object_picker
    #|


## _reg_ ##
class Admin(Operator):
    __slots__ = (
        'u_modal',
        'u_modal_tb',
        'u_draw',
        'boxes')

    bl_idname = "wm.vmd_admin"
    bl_label = "VMD Admin"
    bl_options = {"INTERNAL"}

    # /* 0m_Admin
    # ---------------------------------------------------------------------------------------------------------
    IS_RUNNING = False

    CONTEXT = None
    EVT = None
    REDRAW = None
    TIMER = None
    TAG_CURSOR = ''
    IS_INSIDE = False
    TB_ENABLE = True
    CURSOR_TYPE = None
    # ---------------------------------------------------------------------------------------------------------
    # */

    def invoke(self, context, event):

        #|
        if P == None:

            from . handle import load_post
            load_post(None)

        if Admin.IS_RUNNING: return {'FINISHED'}
        Admin.IS_RUNNING = True

        global ADMIN, CONTEXT_AREA, CONTEXT_REGION, DRAW_HANDLE, CURSOR_WARP, U_DRAW_CALLBACK_PX

        U_DRAW_CALLBACK_PX = i_draw_callback_px

        ADMIN = self
        CONTEXT_AREA = context.area
        CONTEXT_REGION = context.region
        CURSOR_WARP = context.window.cursor_warp

        Admin.CONTEXT = context
        Admin.EVT = event
        Admin.REDRAW = CONTEXT_AREA.tag_redraw
        Admin.IS_INSIDE = False
        Admin.TB_ENABLE = True

        REGION_DATA.upd(CONTEXT_AREA, CONTEXT_REGION)

        self.u_modal = self.i_modal
        self.u_modal_tb = self.to_modal_tb
        self.u_draw = self.i_draw

        h = SIZE_tb[0]
        B = REGION_DATA.B
        T = B + h
        box_tb = GpuBox_box_tb(0, context.region.width, B, T)
        box_tb.upd()
        L = REGION_DATA.L + SIZE_tb[1]
        box_tb_start = GpuImg_tb_start(L, L + h, B, T)
        box_tb_start.upd()
        box_tb_active = GpuImg_tb_active()
        box_tb_active.upd()
        box_tb_hover = GpuImg_tb_hover()
        box_tb_hover.upd()
        self.boxes = (
            # /* 2m_ADMIN_boxes $dict$
            box_tb,
            box_tb_start,
            box_tb_active,
            box_tb_hover
            # */
        )

        if TASKS:

            pass

        DRAW_HANDLE = SpaceView3D.draw_handler_add(draw_callback_px, (), 'WINDOW', 'POST_PIXEL')
        reg_update_post_and_subscribe()
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
        #|

    def upd_size(self):
        boxes = self.boxes
        h = SIZE_tb[0]
        B = REGION_DATA.B
        T = B + h

        # <<< 1dict (2m_ADMIN_boxes,, $
        # boxes[|box_tb|].LRBT_upd(0, CONTEXT_REGION.width, B, T)$)
        boxes[0].LRBT_upd(0, CONTEXT_REGION.width, B, T)
        # >>>
        L = REGION_DATA.L + SIZE_tb[1]
        R = L + h
        # <<< 1dict (2m_ADMIN_boxes,, $
        # boxes[|box_tb_start|].LRBT_upd(L, R, B, T)$)
        boxes[1].LRBT_upd(L, R, B, T)
        # >>>

        # <<< 1dict (2m_ADMIN_boxes,, $
        # tb_hover = boxes[|box_tb_hover|]$)
        tb_hover = boxes[3]
        # >>>
        if tb_hover.L == 0 and tb_hover.R == 0 and tb_hover.B == 0 and tb_hover.T == 0: pass
        else: tb_hover.LRBT_upd(0, 0, 0, 0)

        for e in TASKS:
            L += h
            R += h
            e.box_icon.LRBT_upd(L, R, B, T)
            e.update_multibar()

        if W_MODAL:
            self = W_MODAL[-1]
            # <<< 1dict (2m_ADMIN_boxes,, $
            # ADMIN.boxes[|box_tb_active|].LRBT_upd(*TASKS[D_TASKS_IND[self.__class__.__name__]].box_icon.r_LRBT())$)
            ADMIN.boxes[2].LRBT_upd(*TASKS[D_TASKS_IND[self.__class__.__name__]].box_icon.r_LRBT())
            # >>>
        else:
            # <<< 1dict (2m_ADMIN_boxes,, $
            # boxes[|box_tb_active|].LRBT_upd(0, 0, 0, 0)$)
            boxes[2].LRBT_upd(0, 0, 0, 0)
            # >>>
        #|

    def modal(self, context, event):
        if context.area is None:
            kill_admin()
            return {'FINISHED'}
        if context.space_data.region_quadviews:
            self.report({'WARNING'}, "This Add-on does not support Quad View in the current version.")
            kill_admin()
            return {'FINISHED'}

        Admin.EVT = event
        return self.u_modal(event)
        #|

    def i_modal(self, evt):
        # /* 0m_Admin_i_modal
        if Admin.IS_INSIDE == True:
            get_evt()

            if W_HEAD:
                W_HEAD[-1].modal()
                # <<< 1copy (Admin_set_cursor,, $$)
                if Admin.TAG_CURSOR:
                    if Admin.TAG_CURSOR == 'restore':
                        bpy.context.window.cursor_modal_restore()

                        Admin.CURSOR_TYPE = None
                    else:
                        if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                            bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                            Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                    Admin.TAG_CURSOR = ''
                # >>>
                return {'RUNNING_MODAL'}

            x = evt.mouse_region_x
            y = evt.mouse_region_y
            rd = REGION_DATA
            if x < rd.L or x > rd.R or y < rd.B or y > rd.T:
                # <<< 1copy (0m_outside_evt,, $$)

                Admin.IS_INSIDE = False
                bpy.context.window.cursor_modal_restore()
                if W_FOCUS[0] != None:
                    if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
                    W_FOCUS[0] = None
                kill_evt()
                # >>>
                return {'PASS_THROUGH'}

            if Admin.TB_ENABLE == True:
                if y < rd.B + SIZE_tb[0]:
                    rd.upd(CONTEXT_AREA, CONTEXT_REGION)
                    if rd.L + SIZE_tb[1] < x < rd.R and rd.B < y < rd.B + SIZE_tb[0]:
                        self.u_modal_tb()
                        # <<< 1copy (Admin_set_cursor,, $$)
                        if Admin.TAG_CURSOR:
                            if Admin.TAG_CURSOR == 'restore':
                                bpy.context.window.cursor_modal_restore()

                                Admin.CURSOR_TYPE = None
                            else:
                                if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                                    bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                                    Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                            Admin.TAG_CURSOR = ''
                        # >>>
                        return {'RUNNING_MODAL'}

            for e in reversed(W_MODAL):
                if e.modal() == True:
                    if W_FOCUS[0] != e:
                        if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
                        W_FOCUS[0] = e
                    # <<< 1copy (Admin_set_cursor,, $$)
                    if Admin.TAG_CURSOR:
                        if Admin.TAG_CURSOR == 'restore':
                            bpy.context.window.cursor_modal_restore()

                            Admin.CURSOR_TYPE = None
                        else:
                            if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                                bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                                Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                        Admin.TAG_CURSOR = ''
                    # >>>
                    return {'RUNNING_MODAL'}

            # <<< 1copy (0m_outside_evt,, $$)

            Admin.IS_INSIDE = False
            bpy.context.window.cursor_modal_restore()
            if W_FOCUS[0] != None:
                if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
                W_FOCUS[0] = None
            kill_evt()
            # >>>
            return {'PASS_THROUGH'}
        else:
            x = evt.mouse_region_x
            y = evt.mouse_region_y
            rd = REGION_DATA
            if x < rd.L or x > rd.R or y < rd.B or y > rd.T: return {'PASS_THROUGH'}

            if Admin.TB_ENABLE == True:
                if y < rd.B + SIZE_tb[0]:
                    rd.upd(CONTEXT_AREA, CONTEXT_REGION)
                    if rd.L + SIZE_tb[1] < x < rd.R and rd.B < y < rd.B + SIZE_tb[0]:
                        self.inside_evt()
                        kill_evt()
                        get_evt()
                        self.u_modal_tb()
                        # <<< 1copy (Admin_set_cursor,, $$)
                        if Admin.TAG_CURSOR:
                            if Admin.TAG_CURSOR == 'restore':
                                bpy.context.window.cursor_modal_restore()

                                Admin.CURSOR_TYPE = None
                            else:
                                if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                                    bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                                    Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                            Admin.TAG_CURSOR = ''
                        # >>>
                        return {'RUNNING_MODAL'}

            kill_evt()
            get_evt()
            for e in reversed(W_MODAL):
                if e.modal() == True:
                    if W_FOCUS[0] != e:
                        if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
                        W_FOCUS[0] = e
                    # <<< 1copy (Admin_set_cursor,, $$)
                    if Admin.TAG_CURSOR:
                        if Admin.TAG_CURSOR == 'restore':
                            bpy.context.window.cursor_modal_restore()

                            Admin.CURSOR_TYPE = None
                        else:
                            if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                                bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                                Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                        Admin.TAG_CURSOR = ''
                    # >>>
                    return {'RUNNING_MODAL'}

            return {'PASS_THROUGH'}
        # */

    def i_modal_push(self, evt):
        self.u_modal = self.i_modal
        if Admin.TIMER is not None: remove_timer()

        # <<< 1copy (0m_Admin_i_modal,, $$)
        if Admin.IS_INSIDE == True:
            get_evt()

            if W_HEAD:
                W_HEAD[-1].modal()
                # <<< 1copy (Admin_set_cursor,, $$)
                if Admin.TAG_CURSOR:
                    if Admin.TAG_CURSOR == 'restore':
                        bpy.context.window.cursor_modal_restore()

                        Admin.CURSOR_TYPE = None
                    else:
                        if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                            bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                            Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                    Admin.TAG_CURSOR = ''
                # >>>
                return {'RUNNING_MODAL'}

            x = evt.mouse_region_x
            y = evt.mouse_region_y
            rd = REGION_DATA
            if x < rd.L or x > rd.R or y < rd.B or y > rd.T:
                # <<< 1copy (0m_outside_evt,, $$)

                Admin.IS_INSIDE = False
                bpy.context.window.cursor_modal_restore()
                if W_FOCUS[0] != None:
                    if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
                    W_FOCUS[0] = None
                kill_evt()
                # >>>
                return {'PASS_THROUGH'}

            if Admin.TB_ENABLE == True:
                if y < rd.B + SIZE_tb[0]:
                    rd.upd(CONTEXT_AREA, CONTEXT_REGION)
                    if rd.L + SIZE_tb[1] < x < rd.R and rd.B < y < rd.B + SIZE_tb[0]:
                        self.u_modal_tb()
                        # <<< 1copy (Admin_set_cursor,, $$)
                        if Admin.TAG_CURSOR:
                            if Admin.TAG_CURSOR == 'restore':
                                bpy.context.window.cursor_modal_restore()

                                Admin.CURSOR_TYPE = None
                            else:
                                if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                                    bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                                    Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                            Admin.TAG_CURSOR = ''
                        # >>>
                        return {'RUNNING_MODAL'}

            for e in reversed(W_MODAL):
                if e.modal() == True:
                    if W_FOCUS[0] != e:
                        if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
                        W_FOCUS[0] = e
                    # <<< 1copy (Admin_set_cursor,, $$)
                    if Admin.TAG_CURSOR:
                        if Admin.TAG_CURSOR == 'restore':
                            bpy.context.window.cursor_modal_restore()

                            Admin.CURSOR_TYPE = None
                        else:
                            if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                                bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                                Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                        Admin.TAG_CURSOR = ''
                    # >>>
                    return {'RUNNING_MODAL'}

            # <<< 1copy (0m_outside_evt,, $$)

            Admin.IS_INSIDE = False
            bpy.context.window.cursor_modal_restore()
            if W_FOCUS[0] != None:
                if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
                W_FOCUS[0] = None
            kill_evt()
            # >>>
            return {'PASS_THROUGH'}
        else:
            x = evt.mouse_region_x
            y = evt.mouse_region_y
            rd = REGION_DATA
            if x < rd.L or x > rd.R or y < rd.B or y > rd.T: return {'PASS_THROUGH'}

            if Admin.TB_ENABLE == True:
                if y < rd.B + SIZE_tb[0]:
                    rd.upd(CONTEXT_AREA, CONTEXT_REGION)
                    if rd.L + SIZE_tb[1] < x < rd.R and rd.B < y < rd.B + SIZE_tb[0]:
                        self.inside_evt()
                        kill_evt()
                        get_evt()
                        self.u_modal_tb()
                        # <<< 1copy (Admin_set_cursor,, $$)
                        if Admin.TAG_CURSOR:
                            if Admin.TAG_CURSOR == 'restore':
                                bpy.context.window.cursor_modal_restore()

                                Admin.CURSOR_TYPE = None
                            else:
                                if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                                    bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                                    Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                            Admin.TAG_CURSOR = ''
                        # >>>
                        return {'RUNNING_MODAL'}

            kill_evt()
            get_evt()
            for e in reversed(W_MODAL):
                if e.modal() == True:
                    if W_FOCUS[0] != e:
                        if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
                        W_FOCUS[0] = e
                    # <<< 1copy (Admin_set_cursor,, $$)
                    if Admin.TAG_CURSOR:
                        if Admin.TAG_CURSOR == 'restore':
                            bpy.context.window.cursor_modal_restore()

                            Admin.CURSOR_TYPE = None
                        else:
                            if Admin.CURSOR_TYPE != Admin.TAG_CURSOR:
                                bpy.context.window.cursor_modal_set(Admin.TAG_CURSOR)

                                Admin.CURSOR_TYPE = Admin.TAG_CURSOR

                        Admin.TAG_CURSOR = ''
                    # >>>
                    return {'RUNNING_MODAL'}

            return {'PASS_THROUGH'}
        # >>>
        #|

    def to_modal_tb(self):
        w = TaskBarModalHead()

        # <<< 1dict (2m_ADMIN_boxes,, $
        # if MOUSE[0] < self.boxes[|box_tb_start|].R:$)
        if MOUSE[0] < self.boxes[1].R:
        # >>>
            self.evt_start()
            return
        else:
            for e in TASKS:
                if e.box_icon.in_LR(MOUSE):
                    self.evt_task(e)
                    return

        # <<< 1dict (2m_ADMIN_boxes,, $
        # self.boxes[|box_tb_hover|].LRBT_upd(0, 0, 0, 0)$)
        self.boxes[3].LRBT_upd(0, 0, 0, 0)
        # >>>
        Admin.REDRAW()
        w.modal()
        #|

    def evt_task(self, task):
        #|
        # <<< 1dict (2m_ADMIN_boxes,, $
        # hover = self.boxes[|box_tb_hover|]$)
        hover = self.boxes[3]
        # >>>
        icon = task.box_icon

        # /* 0m_evt_task_check
        global _is_allow_task_evt
        if hover.L == icon.L and hover.R == icon.R and hover.B == icon.B and hover.T == icon.T:
            if EVT_TYPE[1] == 'RELEASE':
                _is_allow_task_evt = True
        else:
            hover.LRBT_upd(*icon.r_LRBT())
            Admin.REDRAW()
            _is_allow_task_evt = True
        # */

        if TRIGGER['click']() and _is_allow_task_evt:
            _is_allow_task_evt = False

            if len(task.ws) == 1:
                w = task.ws[0]
                if w in W_MODAL:
                    if W_MODAL[-1] == w: self.evt_min(w)
                    else: bring_to_front(w)
                else: self.evt_unmin(w)
            else:
                # <<< 1dict (2win_blfs,, $
                # items = [NameValue(w.blfs[|blf_title|].unclip_text, w)  for w in task.ws]$)
                items = [NameValue(w.blfs[0].unclip_text, w)  for w in task.ws]
                # >>>
                DropDownTask(self, (icon.L, icon.B), items, task.ws[0].__class__.name)
        #|
    def evt_start(self):
        #|
        # <<< 1dict (2m_ADMIN_boxes,, $
        # hover = self.boxes[|box_tb_hover|]$)
        hover = self.boxes[3]
        # >>>
        # <<< 1dict (2m_ADMIN_boxes,, $
        # icon = self.boxes[|box_tb_start|]$)
        icon = self.boxes[1]
        # >>>

        # <<< 1copy (0m_evt_task_check,, $$)
        global _is_allow_task_evt
        if hover.L == icon.L and hover.R == icon.R and hover.B == icon.B and hover.T == icon.T:
            if EVT_TYPE[1] == 'RELEASE':
                _is_allow_task_evt = True
        else:
            hover.LRBT_upd(*icon.r_LRBT())
            Admin.REDRAW()
            _is_allow_task_evt = True
        # >>>

        if TRIGGER['click']() and _is_allow_task_evt:
            _is_allow_task_evt = False

            DropDownStartMenu(icon.r_LRBT())
        #|
    def evt_min(self, w):

        #|
        Admin.REDRAW()
        cls_name = w.__class__.__name__
        task = TASKS[D_TASKS_IND[cls_name]]
        W_MODAL.remove(w)
        W_DRAW.remove(w)

        W_FOCUS[0] = None
        if W_MODAL:
            self = W_MODAL[-1]
            self.box_win.color = COL_win_title
            # <<< 1dict (2m_ADMIN_boxes,, $
            # ADMIN.boxes[|box_tb_active|].LRBT_upd(*TASKS[D_TASKS_IND[self.__class__.__name__]].box_icon.r_LRBT())$)
            ADMIN.boxes[2].LRBT_upd(*TASKS[D_TASKS_IND[self.__class__.__name__]].box_icon.r_LRBT())
            # >>>
        else:
            # <<< 1dict (2m_ADMIN_boxes,, $
            # ADMIN.boxes[|box_tb_active|].LRBT_upd(0, 0, 0, 0)$)
            ADMIN.boxes[2].LRBT_upd(0, 0, 0, 0)
            # >>>

        if hasattr(w, "evt_min_callback"): w.evt_min_callback()
        #|
    def evt_unmin(self, w):

        #|
        Admin.REDRAW()
        cls_name = w.__class__.__name__
        task = TASKS[D_TASKS_IND[cls_name]]
        if W_MODAL:
            W_MODAL[-1].box_win.color = COL_win_title_inactive
        W_MODAL.append(w)
        W_DRAW.append(w)
        w.box_win.color = COL_win_title

        # <<< 1dict (2m_ADMIN_boxes,, $
        # self.boxes[|box_tb_active|].LRBT_upd(*task.box_icon.r_LRBT())$)
        self.boxes[2].LRBT_upd(*task.box_icon.r_LRBT())
        # >>>

        tag_obj_rename()
        # <<< 1copy (0m_update_data,, ${'for e in W_MODAL: e.upd_data()':'w.upd_data()'}$)
        TAG_UPDATE[1] = True

        BlendDataTemp.init()
        w.upd_data()
        BlendDataTemp.kill()
        TAG_UPDATE[1] = False

        if TAG_RENAME[0] is True:
            TAG_RENAME[0] = False
        # >>>
        if hasattr(w, "evt_unmin_callback"): w.evt_unmin_callback()
        #|
    def evt_sys_off(self, sleep=False):
        def modal_fin(evt):
            kill_admin()
            if sleep is False:
                W_PROCESS.clear()
                W_MODAL.clear()
                W_DRAW.clear()
                TASKS.clear()
                D_TASKS_IND.clear()
            return {"FINISHED"}

        self.u_modal = modal_fin
        if Admin.TIMER is None:
            Admin.TIMER = bpy.context.window_manager.event_timer_add(0, window=bpy.context.window)
        #|

    def to_modal_fin(self):
        self.u_modal = lambda evt: kill_admin()
        if Admin.TIMER is None:
            Admin.TIMER = bpy.context.window_manager.event_timer_add(0, window=bpy.context.window)
        #|

    def push_modal(self):
        #|
        self.u_modal = self.i_modal_push
        if Admin.TIMER is None:
            Admin.TIMER = bpy.context.window_manager.event_timer_add(0, window=bpy.context.window)

        #|

    def inside_evt(self):
        context = bpy.context
        Admin.IS_INSIDE = True
        Admin.CURSOR_TYPE = None
        Admin.TAG_CURSOR = 'DEFAULT'
        REGION_DATA.upd(CONTEXT_AREA, CONTEXT_REGION)

        # <<< 1dict (2m_ADMIN_boxes,, $
        # e = self.boxes[|box_tb|]$)
        e = self.boxes[0]
        # >>>
        # <<< 1dict (2m_ADMIN_boxes,, $
        # if e.R == CONTEXT_REGION.width and e.B == REGION_DATA.B and self.boxes[|box_tb_start|].L == REGION_DATA.L + SIZE_tb[1]: pass$)
        if e.R == CONTEXT_REGION.width and e.B == REGION_DATA.B and self.boxes[1].L == REGION_DATA.L + SIZE_tb[1]: pass
        # >>>
        else:
            self.upd_size()
            Admin.REDRAW()


        # <<< 1copy (0m_draw_update_data,, $$)
        TAG_UPDATE[0] = False
        if TAG_UPDATE[2]:
            # <<< 1copy (0m_update_data,, $$)
            TAG_UPDATE[1] = True

            BlendDataTemp.init()
            for e in W_MODAL: e.upd_data()
            BlendDataTemp.kill()
            TAG_UPDATE[1] = False

            if TAG_RENAME[0] is True:
                TAG_RENAME[0] = False
            # >>>
        # >>>
        #|
    def outside_evt(self):
        # /* 0m_outside_evt

        Admin.IS_INSIDE = False
        bpy.context.window.cursor_modal_restore()
        if W_FOCUS[0] != None:
            if hasattr(W_FOCUS[0], "outside_evt"): W_FOCUS[0].outside_evt()
            W_FOCUS[0] = None
        kill_evt()
        # */

    def disable_taskbar(self):
        Admin.TB_ENABLE = False
        self.u_draw = N
        #|
    def enable_taskbar(self):
        Admin.TB_ENABLE = True
        self.u_draw = self.i_draw
        #|

    def i_draw(self):
        #|
        blend_set('ALPHA')
        for e in self.boxes: e.bind_draw()
        for e in TASKS:
            e.box_icon.bind_draw()
            e.box_multibar.bind_draw()
        #|

    def reg(self, w):
        if W_MODAL:
            W_MODAL[-1].box_win.color = COL_win_title_inactive

        cls = w.__class__

        W_PROCESS.append(w)
        W_MODAL.append(w)
        W_DRAW.append(w)
        # if hasattr(cls, "WS"):
        #     if isinstance(cls.WS, set): cls.WS.add(w)

        cls_name = cls.__name__
        task = r_task_by_clsname(cls_name)
        if task == None:
            D_TASKS_IND[cls_name] = len(TASKS)
            task = Task(w, getattr(blg, f'GpuImg_{cls_name}'))
            TASKS.append(task)
        else:
            task.ws.append(w)
            task.update_multibar()

        # <<< 1dict (2m_ADMIN_boxes,, $
        # self.boxes[|box_tb_active|].LRBT_upd(*task.box_icon.r_LRBT())$)
        self.boxes[2].LRBT_upd(*task.box_icon.r_LRBT())
        # >>>
        #|

    def unreg(self, w):
        cls = w.__class__

        W_PROCESS.remove(w)
        W_MODAL.remove(w)
        W_DRAW.remove(w)
        # if hasattr(cls, "WS"):
        #     if isinstance(cls.WS, set): cls.WS.remove(w)

        cls_name = cls.__name__
        ind = D_TASKS_IND[cls_name]
        task = TASKS[ind]
        task.ws.remove(w)
        if task.ws: task.update_multibar()
        else:
            del TASKS[ind]
            D_TASKS_IND.clear()
            h = SIZE_tb[0]
            # <<< 1dict (2m_ADMIN_boxes,, $
            # tb_start = ADMIN.boxes[|box_tb_start|]$)
            tb_start = ADMIN.boxes[1]
            # >>>
            L = tb_start.R
            R = L + h

            for r, e in enumerate(TASKS):
                D_TASKS_IND[e.ws[0].__class__.__name__] = r
                ee = e.box_icon
                ee.L = L
                ee.R = R
                ee.upd()
                L += h
                R += h
                e.update_multibar()

        if W_MODAL:
            act = W_MODAL[-1]
            act.box_win.color = COL_win_title
            # <<< 1dict (2m_ADMIN_boxes,, $
            # ADMIN.boxes[|box_tb_active|].LRBT_upd(*TASKS[D_TASKS_IND[act.__class__.__name__]].box_icon.r_LRBT())$)
            ADMIN.boxes[2].LRBT_upd(*TASKS[D_TASKS_IND[act.__class__.__name__]].box_icon.r_LRBT())
            # >>>
            upd_temp_pref(act)
        else:
            # <<< 1dict (2m_ADMIN_boxes,, $
            # self.boxes[|box_tb_active|].LRBT_upd(0, 0, 0, 0)$)
            self.boxes[2].LRBT_upd(0, 0, 0, 0)
            # >>>
        #|
    #|
    #|

class Task:
    __slots__ = (
        'ws',
        'box_icon',
        'box_multibar')

    def __init__(self, w, icon):
        self.ws = [w]
        h = SIZE_tb[0]
        # <<< 1dict (2m_ADMIN_boxes,, $
        # tb_start = ADMIN.boxes[|box_tb_start|]$)
        tb_start = ADMIN.boxes[1]
        # >>>
        L = tb_start.R + len(TASKS) * h
        self.box_icon = icon(L, L + h, tb_start.B, tb_start.T)
        self.box_icon.upd()
        self.box_multibar = GpuBox_box_tb_multibar()
        self.box_multibar.upd()
        #|

    def update_multibar(self):
        if len(self.ws) == 1:
            self.box_multibar.LRBT_upd(0, 0, 0, 0)
        else:
            e = self.box_icon
            d = SIZE_tb[0] // 20
            self.box_multibar.LRBT_upd(e.L + d, e.R - d, e.B, min(e.T, e.B + SIZE_tb[2]))
        #|
    #|
    #|
def r_task_by_clsname(clsname):
    if clsname in D_TASKS_IND: return TASKS[D_TASKS_IND[clsname]]
    return None
    #|

class TaskBarModalHead:
    __slots__ = ()

    def __init__(self):
        W_HEAD.append(self)
        #|

    def modal(self):
        boxes = ADMIN.boxes
        # <<< 1dict (2m_ADMIN_boxes,, $
        # tb_start = boxes[|box_tb_start|]$)
        tb_start = boxes[1]
        # >>>

        if tb_start.L < MOUSE[0] < REGION_DATA.R and tb_start.B < MOUSE[1] < tb_start.T:
            if MOUSE[0] < tb_start.R:
                ADMIN.evt_start()
                return
            else:
                for e in TASKS:
                    if e.box_icon.in_LR(MOUSE):
                        ADMIN.evt_task(e)
                        return

            # <<< 1dict (2m_ADMIN_boxes,, $
            # boxes[|box_tb_hover|].LRBT_upd(0, 0, 0, 0)$)
            boxes[3].LRBT_upd(0, 0, 0, 0)
            # >>>
            Admin.REDRAW()
        else:
            W_HEAD.remove(self)
            # <<< 1dict (2m_ADMIN_boxes,, $
            # boxes[|box_tb_hover|].LRBT_upd(0, 0, 0, 0)$)
            boxes[3].LRBT_upd(0, 0, 0, 0)
            # >>>
            Admin.REDRAW()
            push_modal_safe()
        #|
    #|
    #|

class UpdWinActiveHead:
    __slots__ = ()

    def __init__(self):
        W_HEAD.append(self)
        #|

    def modal(self):

        W_HEAD.remove(self)

        upd_temp_pref(W_MODAL[-1])
        #|
    #|
    #|


def r_unit_factor(rna_unit, text_format):
    if rna_unit == "ROTATION":
        if text_format.__name__.find("deg") == -1: return 1.0
        else: return FLOAT_deg
    else:
        return UnitSystem.D_unit_factor[rna_unit]
    #|
class UnitSystem:
    __slots__ = ()

    unit_system = ""
    unit_length = ""
    unit_rotation = ""
    unit_mass = ""
    unit_time = ""
    unit_temperature = ""
    format_int = rs_format_int6
    format_float = rs_format_float6
    D_format = {
        'INT': rs_format_int6,
        'NONE': rs_format_float6,
        'LENGTH': None,
        'AREA': None,
        'VOLUME': None,
        'ROTATION': None,
        'TIME': rs_format_float6,
        'TIME_ABSOLUTE': None,
        'VELOCITY': None,
        'ACCELERATION': None,
        'MASS': None,
        'CAMERA': None,
        'POWER': None,
        'TEMPERATURE': None}
    D_unit_factor = {
        'INT': 1.0,
        'NONE': 1.0,
        'LENGTH': 1.0,
        'AREA': 1.0,
        'VOLUME': 1.0,
        'ROTATION': 1.0,
        'TIME': 1.0,
        'TIME_ABSOLUTE': 1.0,
        'VELOCITY': 1.0,
        'ACCELERATION': 1.0,
        'MASS': 1.0,
        'CAMERA': 1.0,
        'POWER': 1.0,
        'TEMPERATURE': 1.0}
    D_unit_display = {
        'INT': '',
        'NONE': '',
        'LENGTH': '',
        'AREA': '',
        'VOLUME': '',
        'ROTATION': '°', # fixed
        'TIME': '',
        'TIME_ABSOLUTE': '',
        'VELOCITY': '',
        'ACCELERATION': '',
        'MASS': '',
        'CAMERA': '',
        'POWER': '',
        'TEMPERATURE': ''}
    D_type_format_float = {
        'THOUSAND_SEPARATOR': rs_format_float6_rstrip,
        'THOUSAND_SEPARATOR_FULL': rs_format_float6,
        'NO_SEPARATOR_LEFT': rs_format_float_left}

    @staticmethod
    def r_unit_flo(s, unit_system, unit_length, rna_unit="LENGTH"):
        unit_scale = bpy.context.scene.unit_settings.scale_length
        if unit_scale <= 9.999999717180685e-10: unit_scale = 1.0
        if unit_scale == 1.0:
            return units_to_value(unit_system, rna_unit, s, str_ref_unit=unit_length)
        return units_to_value(unit_system, rna_unit, s, str_ref_unit=unit_length) / unit_scale
        #|

    @classmethod
    def rs_format_length(cls, f):
        return f'{cls.format_float(f / D_unit_factor["LENGTH"])} {D_unit_display["LENGTH"]}'
        #|
    @classmethod
    def rs_format_area(cls, f):
        return f'{cls.format_float(f / D_unit_factor["AREA"])} {D_unit_display["AREA"]}'
        #|
    @classmethod
    def rs_format_volume(cls, f):
        return f'{cls.format_float(f / D_unit_factor["VOLUME"])} {D_unit_display["VOLUME"]}'
        #|
    @classmethod
    def rs_format_deg(cls, f):
        return f'{cls.format_float(f / FLOAT_deg)} °'
        #|
    @classmethod
    def rs_format_mass(cls, f):
        return f'{cls.format_float(f / D_unit_factor["MASS"])} {D_unit_display["MASS"]}'
        #|
    @classmethod
    def rs_format_time(cls, f):
        return f'{cls.format_float(f / D_unit_factor["TIME_ABSOLUTE"])} {D_unit_display["TIME_ABSOLUTE"]}'
        #|
    @classmethod
    def rs_format_velocity(cls, f):
        return f'{cls.D_format["LENGTH"](f)} / s'
        #|
    @classmethod
    def rs_format_acceleration(cls, f):
        return f'{cls.D_format["LENGTH"](f)} / s²'
        #|
    @classmethod
    def rs_format_temperature(cls, f): pass
    @classmethod
    def rs_format_length_adaptive(cls, f):
        return "  " + units_to_string(cls.unit_system, "LENGTH", f, precision=20)
        #|
    @classmethod
    def rs_format_area_adaptive(cls, f):
        return "  " + units_to_string(cls.unit_system, "AREA", f, precision=20)
        #|
    @classmethod
    def rs_format_volume_adaptive(cls, f):
        return "  " + units_to_string(cls.unit_system, "VOLUME", f, precision=20)
        #|
    @classmethod
    def rs_format_mass_adaptive(cls, f):
        return "  " + units_to_string(cls.unit_system, "MASS", f, precision=20)
        #|
    @classmethod
    def rs_format_time_adaptive(cls, f):
        return "  " + units_to_string(cls.unit_system, "TIME", f, precision=20)
        #|
    @classmethod
    def rs_format_temperature_adaptive(cls, f):
        return "  " + units_to_string(cls.unit_system, "TEMPERATURE", f, precision=20)
        #|
    @classmethod
    def rs_format_percentage_int(cls, f):
        return f'{cls.format_int(f)} %'
        #|
    @classmethod
    def rs_format_percentage_float(cls, f):
        return f'{cls.format_float(f)} %'
        #|

    @classmethod
    def update(cls):
        if not bpy.context or not bpy.context.scene: return
        unit_system = bpy.context.scene.unit_settings.system
        unit_length = bpy.context.scene.unit_settings.length_unit
        unit_rotation = bpy.context.scene.unit_settings.system_rotation
        unit_mass = bpy.context.scene.unit_settings.mass_unit
        unit_time = bpy.context.scene.unit_settings.time_unit
        unit_temperature = bpy.context.scene.unit_settings.temperature_unit
        cls.unit_system = unit_system
        cls.unit_length = unit_length
        cls.unit_rotation = unit_rotation
        cls.unit_mass = unit_mass
        cls.unit_time = unit_time
        cls.unit_temperature = unit_temperature

        r_unit_flo = cls.r_unit_flo
        f1 = r_unit_flo("1", unit_system, unit_length)
        f2 = f1 * f1
        D_unit_factor["VOLUME"] = f1 * f2
        D_unit_factor["AREA"] = f2
        D_unit_factor["LENGTH"] = f1
        D_unit_factor["VELOCITY"] = f1
        D_unit_factor["ACCELERATION"] = f1
        D_unit_factor["CAMERA"] = f1
        e = cls.D_format

        if P.format_float in cls.D_type_format_float:
            format_float = cls.D_type_format_float[P.format_float]
        else:
            format_float = rs_format_float6_rstrip
        cls.format_float = format_float
        e["NONE"] = format_float
        e["TIME"] = format_float
        e["POWER"] = format_float

        if unit_system == "METRIC":
            if unit_length in D_length_unit_to_display:
                D_unit_display["LENGTH"] = D_length_unit_to_display[unit_length]
                e["LENGTH"] = cls.rs_format_length
                e["AREA"] = cls.rs_format_area
                e["VOLUME"] = cls.rs_format_volume
            else:
                D_unit_display["LENGTH"] = ""
                e["LENGTH"] = cls.rs_format_length_adaptive
                e["AREA"] = cls.rs_format_area_adaptive
                e["VOLUME"] = cls.rs_format_volume_adaptive
        elif unit_system == "IMPERIAL":
            if unit_length in D_length_unit_to_display:
                D_unit_display["LENGTH"] = D_length_unit_to_display[unit_length]
                e["LENGTH"] = cls.rs_format_length
                e["AREA"] = cls.rs_format_area
                e["VOLUME"] = cls.rs_format_volume
            else:
                D_unit_display["LENGTH"] = ""
                e["LENGTH"] = cls.rs_format_length_adaptive
                e["AREA"] = cls.rs_format_area_adaptive
                e["VOLUME"] = cls.rs_format_volume_adaptive
        else:
            D_unit_display["LENGTH"] = ""
            e["LENGTH"] = format_float
            e["AREA"] = cls.rs_format_area
            e["VOLUME"] = cls.rs_format_volume

        if P.show_length_unit == False: D_unit_display["LENGTH"] = ""
        if D_unit_display["LENGTH"]:
            if D_unit_display["LENGTH"] == '"':
                D_unit_display["AREA"] = "in²"
                D_unit_display["VOLUME"] = "in³"
            elif D_unit_display["LENGTH"] == "'":
                D_unit_display["AREA"] = "ft²"
                D_unit_display["VOLUME"] = "ft³"
            else:
                D_unit_display["AREA"] = D_unit_display["LENGTH"] + "²"
                D_unit_display["VOLUME"] = D_unit_display["LENGTH"] + "³"
        else:
            D_unit_display["AREA"] = "unit²"
            D_unit_display["VOLUME"] = "unit³"


        if unit_rotation == "DEGREES":
            D_unit_factor["ROTATION"] = FLOAT_deg
            e["ROTATION"] = cls.rs_format_deg
        else:
            D_unit_factor["ROTATION"] = 1.0
            e["ROTATION"] = format_float

        if unit_mass in D_mass_unit_to_display:
            e["MASS"] = cls.rs_format_mass
            u = D_mass_unit_to_display[unit_mass]
            D_unit_display["MASS"] = u
            if u in D_unit_replace: u = D_unit_replace[u]
        else:
            e["MASS"] = cls.rs_format_mass_adaptive
            u = ""
            D_unit_display["MASS"] = u
        D_unit_factor["MASS"] = r_unit_flo(f'1 {u}', unit_system, unit_length, "MASS")

        if unit_time in D_time_unit_to_display:
            e["TIME_ABSOLUTE"] = cls.rs_format_time
            u = D_time_unit_to_display[unit_time]
            D_unit_display["TIME_ABSOLUTE"] = u
            if u in D_unit_replace: u = D_unit_replace[u]
        else:
            e["TIME_ABSOLUTE"] = cls.rs_format_time_adaptive
            u = ""
            D_unit_display["TIME_ABSOLUTE"] = u
        D_unit_factor["TIME_ABSOLUTE"] = r_unit_flo(f'1 {u}', unit_system, unit_length, "TIME_ABSOLUTE")

        if unit_temperature in D_temperature_unit_to_display:
            e["TEMPERATURE"] = cls.rs_format_temperature_adaptive
            u = D_temperature_unit_to_display[unit_temperature]
            D_unit_display["TEMPERATURE"] = u
            if u in D_unit_replace: u = D_unit_replace[u]
        else:
            e["TEMPERATURE"] = cls.rs_format_temperature_adaptive
            u = ""
            D_unit_display["TEMPERATURE"] = u
        # D_unit_factor["TEMPERATURE"] = r_unit_flo(f'1 {u}', unit_system, unit_length, "TEMPERATURE")

        e["CAMERA"] = e["LENGTH"]
        e["VELOCITY"] = cls.rs_format_velocity
        e["ACCELERATION"] = cls.rs_format_acceleration
        #|

    #|
    #|
D_unit_factor = UnitSystem.D_unit_factor
D_unit_display = UnitSystem.D_unit_display


class LibraryModifier:
    __slots__ = (
        'gn_paths',
        'md_paths_MESH',
        'md_paths_CURVE',
        'md_paths_SURFACE',
        'md_paths_VOLUME',
        'md_paths_LATTICE',
        'types_items')

    def __init__(self):
        self.gn_paths = OrderedDict()
        self.md_paths_MESH = OrderedDict()
        self.md_paths_CURVE = OrderedDict()
        self.md_paths_SURFACE = OrderedDict()
        self.md_paths_VOLUME = OrderedDict()
        self.md_paths_LATTICE = OrderedDict()
        self.types_items = {
            "MESH": [],
            "CURVE": [],
            "SURFACE": [],
            "VOLUME": [],
            "LATTICE": [],
        }
        #|

    @staticmethod
    @ successResult
    def glob_blends(path, recursive, markonly):
        gn_paths = LIBRARY_MODIFIER.gn_paths
        md_paths_MESH = LIBRARY_MODIFIER.md_paths_MESH
        md_paths_CURVE = LIBRARY_MODIFIER.md_paths_CURVE
        md_paths_SURFACE = LIBRARY_MODIFIER.md_paths_SURFACE
        md_paths_VOLUME = LIBRARY_MODIFIER.md_paths_VOLUME
        md_paths_LATTICE = LIBRARY_MODIFIER.md_paths_LATTICE

        if P.md_lib_filter:
            lib_filter_text = P.md_lib_filter
            def filter_fx(ob):
                try: return bpyeval_ob(lib_filter_text, ob)
                except: return False
        else:
            def filter_fx(ob): return True

        libs = bpy.data.libraries
        old_libs = set(libs)
        nodes = bpy.data.node_groups
        objects = bpy.data.objects

        for blend_path in r_glob_files(path, "blend", recursive=recursive):
            try:
                old_nodes = set(nodes)

                with libs.load(blend_path, link=True) as (data_from, data_to):
                    data_to.node_groups = data_from.node_groups

                names = []
                if markonly:
                    for node in set(nodes).difference(old_nodes):
                        if node.type == "GEOMETRY" and node.asset_data:
                            if filter_fx(node):
                                names.append(NameLibrary(node.name, FilepathVersion(blend_path, "")))
                        nodes.remove(node)
                else:
                    for node in set(nodes).difference(old_nodes):
                        if node.type == "GEOMETRY":
                            if filter_fx(node):
                                names.append(NameLibrary(node.name, FilepathVersion(blend_path, "")))
                        nodes.remove(node)

                names.sort(key=lambda x: x.name)
                gn_paths[blend_path] = names
            except:
                gn_paths[blend_path] = []

            try:
                old_objects = set(objects)

                with libs.load(blend_path, link=True) as (data_from, data_to):
                    data_to.objects = data_from.objects

                names_MESH = []
                names_CURVE = []
                names_SURFACE = []
                names_VOLUME = []
                names_LATTICE = []

                if markonly:
                    for ob in set(objects).difference(old_objects):
                        if hasattr(ob, "modifiers") and ob.modifiers and ob.asset_data:
                            # /* 0m_glob_blends_modifier
                            for modifier in ob.modifiers:
                                if filter_fx(ob):
                                    if ob.type == "MESH":
                                        names_MESH.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                                    elif ob.type == "CURVE":
                                        names_CURVE.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                                    elif ob.type == "SURFACE":
                                        names_SURFACE.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                                    elif ob.type == "VOLUME":
                                        names_VOLUME.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                                    elif ob.type == "LATTICE":
                                        names_LATTICE.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                            # */
                        objects.remove(ob)
                else:
                    for ob in set(objects).difference(old_objects):
                        if hasattr(ob, "modifiers") and ob.modifiers:
                            # <<< 1copy (0m_glob_blends_modifier,, $$)
                            for modifier in ob.modifiers:
                                if filter_fx(ob):
                                    if ob.type == "MESH":
                                        names_MESH.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                                    elif ob.type == "CURVE":
                                        names_CURVE.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                                    elif ob.type == "SURFACE":
                                        names_SURFACE.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                                    elif ob.type == "VOLUME":
                                        names_VOLUME.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                                    elif ob.type == "LATTICE":
                                        names_LATTICE.append(NameLibraryIdentifier(modifier.name, FilepathVersion(blend_path, ob.name), modifier.type))
                            # >>>
                        objects.remove(ob)

                names_MESH.sort(key=lambda x: x.name)
                names_CURVE.sort(key=lambda x: x.name)
                names_SURFACE.sort(key=lambda x: x.name)
                names_VOLUME.sort(key=lambda x: x.name)
                names_LATTICE.sort(key=lambda x: x.name)
                md_paths_MESH[blend_path] = names_MESH
                md_paths_CURVE[blend_path] = names_CURVE
                md_paths_SURFACE[blend_path] = names_SURFACE
                md_paths_VOLUME[blend_path] = names_VOLUME
                md_paths_LATTICE[blend_path] = names_LATTICE
            except:
                md_paths_MESH[blend_path] = []
                md_paths_CURVE[blend_path] = []
                md_paths_SURFACE[blend_path] = []
                md_paths_VOLUME[blend_path] = []
                md_paths_LATTICE[blend_path] = []

        for e in set(libs).difference(old_libs):
            libs.remove(e)
        #|

    @staticmethod
    def ui_edit_path(button0=None, box_block=None):

        if button0 is None: return
        else:
            L, R, B, T = button0.box_button.r_LRBT()

        def confirm_fn(s):
            P.md_lib_filepath = s
            save_pref()
            message = LibraryModifier.ui_refresh_path(False)
            if message: return message
            return False

        def r_default_value(): return P.bl_rna.properties["md_lib_filepath"].default

        def bufn_clear():
            a0 = ddw.areas[0]
            ss = a0.bl_text.as_string()
            i0 = ss.find("directories")
            if i0 == -1: return
            if i0 != 0:
                if ss[i0 - 1] not in {"\n", " "}: return
            if ss[i0 + 11] not in {" ", "="}: return

            open_index = r_py_end_bracket_index(ss, i0, open_sign="", close_sign="(")
            if open_index == -1: return
            end_index = r_py_end_bracket_index(ss, open_index)
            a0.evt_del_all(undo_push=False)
            a0.beam_input(ss[ : open_index + 1] + "# Folder, Recursive, Marked assets only\n" + ss[end_index : ])

        def bufn_append():
            a0 = ddw.areas[0]

            def end_fn(s):

                s = '\n    ("' + s.replace("\\", "\\\\") + '", True, True),\n'
                ss = a0.bl_text.as_string()
                i0 = ss.find("directories")

                is_good_format = True
                if i0 == -1: is_good_format = False
                elif i0 != 0:
                    if ss[i0 - 1] not in {"\n", " "}: is_good_format = False
                if ss[i0 + 11] not in {" ", "="}: is_good_format = False

                open_index = r_py_end_bracket_index(ss, i0, open_sign="", close_sign="(")
                if open_index == -1: is_good_format = False
                end_index = r_py_end_bracket_index(ss, open_index)

                if is_good_format is True:
                    new_text = ss[ : end_index - 1] + s + ss[end_index : ]
                else:
                    new_text = ss + s

                a0.evt_del_all(undo_push=False)
                a0.beam_input(new_text)

            OpScanFolder.end_fn = end_fn
            bpy.ops.wm.vmd_scan_folder("INVOKE_DEFAULT")

        title_buttons = (
            (RnaButton("clear_paths", name="Clear Paths", button_text="Clear", description="", size=-3), bufn_clear),
            (RnaButton("append_paths", name="Append Path", button_text="Append Path", description="", size=-5), bufn_append),
        )

        ddw = DropDownText(button0, (box_block.L, R, T), P.md_lib_filepath, confirm_fn, r_default_value,
            title_buttons=title_buttons)
        #|
    @staticmethod
    def ui_refresh_path(report_dialog=True):


        global LIBRARY_MODIFIER
        if LIBRARY_MODIFIER is None: LIBRARY_MODIFIER = LibraryModifier()

        glob_blends = LIBRARY_MODIFIER.glob_blends
        gn_paths = LIBRARY_MODIFIER.gn_paths
        md_paths_MESH = LIBRARY_MODIFIER.md_paths_MESH
        md_paths_CURVE = LIBRARY_MODIFIER.md_paths_CURVE
        md_paths_SURFACE = LIBRARY_MODIFIER.md_paths_SURFACE
        md_paths_VOLUME = LIBRARY_MODIFIER.md_paths_VOLUME
        md_paths_LATTICE = LIBRARY_MODIFIER.md_paths_LATTICE
        gn_paths.clear()
        md_paths_MESH.clear()
        md_paths_CURVE.clear()
        md_paths_SURFACE.clear()
        md_paths_VOLUME.clear()
        md_paths_LATTICE.clear()
        types_items = LIBRARY_MODIFIER.types_items
        for e in types_items.values(): e.clear()

        directories, message = eval_md_lib(P.md_lib_filepath)
        if message:
            if report_dialog: DropDownOk(None, MOUSE, input_text=message)
            return message

        if isinstance(directories, tuple) or isinstance(directories, list): pass
        else:
            if report_dialog: DropDownOk(None, MOUSE, input_text="directories must be a list or tuple")
            return message

        message = []

        for r, e in enumerate(directories):
            if isinstance(e, list) or isinstance(e, tuple): pass
            else:
                message.append(f'Item {r} must be a list or tuple')
                continue
            if len(e) != 3:
                message.append(f'Item {r} length must be equal to 3')
                continue

            path, recursive, markonly = e
            if isinstance(path, str) and isinstance(recursive, bool) and isinstance(markonly, bool): pass
            else:
                message.append(f'Item {r} context must be (string, bool, bool)')
                continue

            success, result = glob_blends(path, recursive, markonly)
            if result: message.append(result)

        if P.md_lib_use_essentials:
            blender_version = bpy.app.version
            lib_folder = Path(bpy.app.binary_path).parent.joinpath(
                f"{blender_version[0]}.{blender_version[1]}\\datafiles\\assets\\geometry_nodes")
            if lib_folder.exists():
                success, result = glob_blends(lib_folder, True, False)
                if result: message.append(result)

        items_gn = sum(gn_paths.values(), [])
        types_items["MESH"][:] = items_gn + sum(md_paths_MESH.values(), []) + md_rnas_MESH
        types_items["CURVE"][:] = items_gn + sum(md_paths_CURVE.values(), []) + md_rnas_CURVE
        types_items["SURFACE"][:] = sum(md_paths_SURFACE.values(), []) + md_rnas_SURFACE
        types_items["VOLUME"][:] = items_gn + sum(md_paths_VOLUME.values(), []) + md_rnas_VOLUME
        types_items["LATTICE"][:] = sum(md_paths_LATTICE.values(), []) + md_rnas_LATTICE

        if message:
            message = "\n".join(message)
            if report_dialog: DropDownOk(None, MOUSE, input_text=message)
            return message

        if report_dialog: report("Modifier Library updated")
        #|
    #|
    #|


#| Level 1
def _import_():
    #|
    from . handle import BL_INFO

    global P, P_temp, ADDON_VERSION, prefs, blg, subscribe_rna, clear_by_owner

    # <<< 1copy (assignP,, $$)
    P = bpy.context.preferences.addons[__package__].preferences
    # >>>
    ADDON_VERSION = BL_INFO["version"]

    from .  import prefs
    from . utilbl import blg
    subscribe_rna = bpy.msgbus.subscribe_rna
    clear_by_owner = bpy.msgbus.clear_by_owner
    P_temp = P.temp
    prefs.U_UPD_UNIT = UnitSystem.update
    #|
#| Level 3
def _import_size_():
    #|
    # //* 0m_import_size_
    # *// =|
    # <<< 1copy (0m_import_size_,, $$)
    global FONT0,D_SIZE,upd_font_size,GpuBox_box_tb,GpuBox_box_tb_multibar,GpuImg_tb_start,GpuImg_tb_active,GpuImg_tb_hover,SIZE_tb,SIZE_title,SIZE_border,SIZE_widget,r_blf_clipping_end,report,COL_win_title,COL_win_title_inactive
    # >>>
    # <<< 1copy (0m_import_size_,, ${'global': 'from . utilbl.blg import'}$)
    from . utilbl.blg import FONT0,D_SIZE,upd_font_size,GpuBox_box_tb,GpuBox_box_tb_multibar,GpuImg_tb_start,GpuImg_tb_active,GpuImg_tb_hover,SIZE_tb,SIZE_title,SIZE_border,SIZE_widget,r_blf_clipping_end,report,COL_win_title,COL_win_title_inactive
    # >>>
    #|
