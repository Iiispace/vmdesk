from . util.types import (
    RnaBool,
    RnaEnum,
    RnaButton,
    r_enum_items_create)


RNA_md_use_keyframe = RnaBool("md_use_keyframe", name="Keyframe")
RNA_md_use_driver = RnaBool("md_use_driver", name="Driver")
RNA_md_copy = RnaButton("md_copy", "Copy", "", "Copy")
RNA_md_move = RnaButton("md_move", "Move", "", "Move")
RNA_md_link = RnaButton("md_link", "Link", "", "Link")
RNA_md_deeplink = RnaButton("md_deeplink", "Deep Link", "", "Deep Link")
RNA_md_copy_operation = RnaEnum("md_copy_operation",
    r_enum_items_create((
        ("COPY", "Copy", ""),
        ("LINK", "Link", ""),
        ("DEEPLINK", "Deep Link", "")), default_key="COPY"),
    name="Operation", is_never_none=False)
RNA_md_use_mouse_index = RnaBool("md_use_mouse_index", name="Mouse Index")
RNA_md_use_selection = RnaBool("md_use_selection", name="Selection")
RNA_md_use_code = RnaBool("md_use_code", name="Override Code")
RNA_ob_use_self = RnaBool("ob_use_self", name="Self")

RNA_run = RnaButton("run", "Run", "", "Run")
RNA_cancel = RnaButton("cancel", "Cancel", "", "Cancel")


RNA_active_object = RnaButton("active_object",
    name = "Active Object",
    button_text = "",
    description = "Set active object.")
RNA_active_object_sync = RnaButton("active_object_sync",
    name = "Active Object Sync",
    button_text = "",
    description = "Sync active object.")
RNA_active_modifier = RnaButton("active_modifier",
    name = "Active Modifier",
    button_text = "",
    description = "Set active modifier.")
RNA_active_modifier_sync = RnaButton("active_modifier_sync",
    name = "Active Modifier Sync",
    button_text = "",
    description = "Sync active modifier.")
RNA_new_modifier = RnaButton("new_modiifer",
    name = "New Modifier",
    button_text = "",
    description = "Add a modifier.")
RNA_remove_modifier = RnaButton("remove_modifier",
    name = "Remove Modifier",
    button_text = "",
    description = "Remove active modifier.")
RNA_button_keyframe = RnaButton("button_keyframe",
    name = "Button Keyframe",
    button_text = "",
    description = "Keyframe Button.")
