import bpy

from bpy.types import Operator
from bpy.props import (
    StringProperty,
    EnumProperty,
    BoolProperty,
    IntVectorProperty,
    FloatProperty)

from . m import call_admin, kill_admin
from . utilbl import blg
from .  import m

# <<< 1forfile (_editor_,, $lambda _file_, _cls_: f'from . {_file_[1 : _file_.rfind(chr(92))].replace(".py", ""
#     ).replace(chr(92), ".")}.{_file_[_file_.rfind(chr(92)) + 1 :].replace(".py", "")} import {_cls_}\n'$)
from . apps.mdeditor.ed import ModifierEditor
from . apps.settingeditor.ed import SettingEditor
# >>>


D_EDITOR = {
    # <<< 1forfile (_editor_,, $lambda _file_, _cls_: f'"{_cls_}": {_cls_},\n'$)
    "ModifierEditor": ModifierEditor,
    "SettingEditor": SettingEditor,
    # >>>
}
EDITORS = [e for e in D_EDITOR]
EDITORS.sort()


def poll_reload_event():
    if m.RELOAD_STATE[0] is True: return "blender restart require after script reload event / re-enabling add-on"
    return ""
    #|


## _reg_ ##
class OpsEditor(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_editor"
    bl_label = "VMD Editor"
    bl_options = {"REGISTER"}
    bl_description = "Open Editor in 3D Viewport"

    id_class: EnumProperty(
        name = "Class",
        description = "Editor Type.",
        items = (
            # <<< 1forfile (_editor_,, $lambda _file_, _cls_: f'("{_cls_}", "{split_upper(_cls_)}", ""),\n'$)
            ("ModifierEditor", "Modifier Editor", ""),
            ("SettingEditor", "Setting Editor", ""),
            # >>>
        ),
        options = set())
    use_pos: BoolProperty(
        name = "Override Position",
        description = "Use cursor position instead of default position.",
        default = True,
        options = set())
    pos_offset: IntVectorProperty(
        name = "Offset",
        description = "Window offset when Override Position is enabled.",
        size = 2,
        default = (-150, 15),
        subtype = "TRANSLATION",
        options = set())
    use_fit: BoolProperty(
        name = "Auto Size",
        description = "Use Auto Size instead of default size.",
        default = True,
        options = set())


    def invoke(self, context, event):
        s = poll_reload_event()
        if s:
            self.report({'WARNING'}, s)
            return {'CANCELLED'}

        if call_admin(context): D_EDITOR[self.id_class](
            id_class = self.id_class,
            use_pos = self.use_pos,
            use_fit = self.use_fit,
            pos_offset = self.pos_offset,

            event = event)

        return {'FINISHED'}
        #|

## _reg_ ##
class OpsLoadFactory(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_addon_factory"
    bl_label = "VMD Load Addon Factory Setting"
    bl_options = {"REGISTER"}
    bl_description = "Load vmdesk Factory Setting"

    @classmethod
    def poll(cls, context):
        if m.P: return True
        return False

    def execute(self, context):
        s = poll_reload_event()
        if s:
            self.report({'WARNING'}, s)
            return {'CANCELLED'}

        if m.ADMIN: m.ADMIN.evt_sys_off(sleep=False)

        from . apps.settingeditor.areas import P_BL_RNA_PROPS

        def reset_prefs(pp):
            for identifier, rna in pp.bl_rna.properties.items():
                if identifier in {'bl_idname', 'name', 'rna_type'}: continue

                if rna.type == "POINTER":
                    reset_prefs(getattr(pp, identifier))
                    continue

                if hasattr(rna, "is_array") and rna.is_array:
                    setattr(pp, identifier, rna.default_array)
                else:
                    if rna.subtype == "BYTE_STRING":
                        setattr(pp, identifier, rna.default.encode('utf-8'))
                    else:
                        setattr(pp, identifier, rna.default)

        reset_prefs(m.P)

        return {'FINISHED'}
        #|
    #|
    #|


## _reg_ ##
class OpsReloadIcon(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_reload_icon"
    bl_label = "VMD Reload Icon"
    bl_options = {"REGISTER"}
    bl_description = "Reload icons after changing UI size"

    @classmethod
    def poll(cls, context):
        if m.P: return True
        return False

    def invoke(self, context, event):
        s = poll_reload_event()
        if s:
            self.report({'WARNING'}, s)
            return {'CANCELLED'}

        blg.reload_icon()
        return {'FINISHED'}
        #|
    #|
    #|
## _reg_ ##
class OpsReloadFont(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_reload_font"
    bl_label = "VMD Reload Font"
    bl_options = {"REGISTER"}
    bl_description = "Reload UI Fonts after changing blender Theme / Text Rendering settings (like Subpixel Anti-Aliasing)"

    @classmethod
    def poll(cls, context):
        if m.P: return True
        return False

    def invoke(self, context, event):
        s = poll_reload_event()
        if s:
            self.report({'WARNING'}, s)
            return {'CANCELLED'}

        blg.reload_font()
        return {'FINISHED'}
        #|
    #|
    #|
## _reg_ ##
class OpsUiScale(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_ui_scale"
    bl_label = "VMD UI Scale"
    bl_options = {"REGISTER"}
    bl_description = "Set add-on UI scale"

    factor: FloatProperty(default=1.0)

    @classmethod
    def poll(cls, context):
        if m.P: return True
        return False

    def execute(self, context):
        s = poll_reload_event()
        if s:
            self.report({'WARNING'}, s)
            return {'CANCELLED'}

        fac = self.factor
        P = m.P
        pp = P.size

        if fac < 1.32:
            pp.widget[:] = (18, 2, 6, 1)
            pp.title[:] = (27, 22)
            pp.border[:] = (4, 3, 1, 1)
            pp.dd_border[:] = (1, 1, 1)
            pp.filter[:] = (200, 2, 2, 2)
            pp.tb[:] = (27, 300, 3)
            pp.win_shadow_offset[:] = (-10, 20, -23, 6)
            pp.dd_shadow_offset[:] = (-6, 8, -11, 4)
            pp.shadow_softness[:] = (57, 20)
            pp.setting_list_border[:] = (8, 5, 1)
            pp.block[:] = (2, 2, 5, 5, 3, 15, 10, 1)
            pp.button[:] = (8, 1, 3, 256)

            P.ModifierEditor.area_list_inner = 8
        elif fac <= 1.34:
            pp.widget[:] = (24, 2, 8, 1)
            pp.title[:] = (36, 30)
            pp.border[:] = (5, 4, 1, 1)
            pp.dd_border[:] = (1, 1, 1)
            pp.filter[:] = (266, 2, 2, 2)
            pp.tb[:] = (36, 400, 4)
            pp.win_shadow_offset[:] = (-13, 27, -30, 8)
            pp.dd_shadow_offset[:] = (-8, 11, -15, 5)
            pp.shadow_softness[:] = (57, 20)
            pp.setting_list_border[:] = (11, 7, 1)
            pp.block[:] = (3, 3, 7, 7, 4, 20, 13, 1)
            pp.button[:] = (11, 1, 4, 340)

            P.ModifierEditor.area_list_inner = 11
        elif fac <= 1.67:
            pp.widget[:] = (30, 3, 10, 2)
            pp.title[:] = (45, 37)
            pp.border[:] = (7, 5, 2, 2)
            pp.dd_border[:] = (2, 2, 2)
            pp.filter[:] = (332, 3, 3, 3)
            pp.tb[:] = (45, 498, 5)
            pp.win_shadow_offset[:] = (-17, 33, -38, 10)
            pp.dd_shadow_offset[:] = (-10, 13, -18, 7)
            pp.shadow_softness[:] = (57, 20)
            pp.setting_list_border[:] = (13, 8, 2)
            pp.block[:] = (3, 3, 8, 8, 5, 25, 17, 2)
            pp.button[:] = (13, 2, 5, 425)

            P.ModifierEditor.area_list_inner = 13
        else:
            pp.widget[:] = (36, 4, 12, 2)
            pp.title[:] = (54, 44)
            pp.border[:] = (8, 6, 2, 2)
            pp.dd_border[:] = (2, 2, 2)
            pp.filter[:] = (400, 4, 4, 4)
            pp.tb[:] = (54, 600, 6)
            pp.win_shadow_offset[:] = (-20, 40, -46, 12)
            pp.dd_shadow_offset[:] = (-12, 16, -22, 8)
            pp.shadow_softness[:] = (57, 20)
            pp.setting_list_border[:] = (16, 10, 2)
            pp.block[:] = (4, 4, 10, 10, 6, 30, 20, 2)
            pp.button[:] = (16, 2, 6, 512)

            P.ModifierEditor.area_list_inner = 16

        blg.reload_icon()
        return {'FINISHED'}
    #|
    #|
