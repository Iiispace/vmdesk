

def successResult(fn):
    def wrapper(*k, **kw):
        try: return True, fn(*k, **kw)
        except Exception as e: return False, str(e)
    return wrapper
    #|
