from shutil import rmtree

def del_folder(s):
    try: rmtree(s)
    except: pass
    #|
