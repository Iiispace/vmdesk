from math import *
from . deco import successResult


def union(*s): return "union", s
def intersection(*s): return "intersection", s
def difference(*s): return "difference", s

@ successResult
def evalfiltexp(s): return eval(s)
