import decimal

from itertools import count, filterfalse

DECIMAL_CONTEXT = decimal.Context()
DECIMAL_CONTEXT.prec = 20

def float_to_str(f):
    #|
    return format(DECIMAL_CONTEXT.create_decimal(repr(f)), 'f')
    #|


def r_unsign32(n):
    #|
    return n + (1 << 32) & 0b11111111111111111111111111111111
    #|

def r_sign32(n):
    #|
    if n <= 0b1111111111111111111111111111111:
        return n
    return n - (1 << 32)
    #|

#| List --------------------------------------------------------------------------------------------------

def r_smallest_miss(set1, smallest):
    #| Iterate the first number not in set
    #| {1, 2}, 1 ==> 3
    return next(filterfalse(set1.__contains__, count(smallest)))
    #|

#|
#| String ------------------------------------------------------------------------------------------------

def split_uppers(s):
    #|
    li = []
    i = 0
    for r, ss in enumerate(s):
        if ss in UPPER:
            if s[i : r]:
                li.append(s[i : r])
                i = r

    if s[i :]:
        li.append(s[i :])
    return li
    #|
def split_upper(s):
    #|
    out = ""
    i = 0
    for r, ss in enumerate(s):
        if ss in UPPER:
            if s[i : r]:
                out += f' {s[i : r]}'  if out else s[i : r]
                i = r

    if s[i :]:
        out += f' {s[i :]}'  if out else s[i :]
    return out
    #|

#|
#| Color -------------------------------------------------------------------------------------------------
#|