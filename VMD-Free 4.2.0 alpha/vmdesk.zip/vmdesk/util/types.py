from collections import deque

class Xy:
    __slots__ = 'x', 'y'

    def __init__(self, x, y):
        self.x = x
        self.y = y
        #|
    #|
    #|


class Name:
    __slots__ = 'name'

    def __init__(self, name):
        self.name = name
        #|
    #|
    #|

class NameValue:
    __slots__ = 'name', 'value'

    def __init__(self, name, value):
        self.name = name
        self.value = value
        #|
    #|
    #|

class NameLibrary:
    __slots__ = 'name', 'library'

    def __init__(self, name, library):
        self.name = name
        self.library = library
        #|
    #|
    #|

class NameLibraryIdentifier:
    __slots__ = 'name', 'library', 'identifier'

    def __init__(self, name, library, identifier):
        self.name = name
        self.library = library
        self.identifier = identifier
        #|
    #|
    #|

class FilepathVersion:
    __slots__ = 'filepath', 'version'

    def __init__(self, filepath, version):
        self.filepath = filepath
        self.version = version
        #|
    #|
    #|

class IdentifierNameValue:
    __slots__ = 'identifier', 'name', 'value'

    def __init__(self, identifier, name, value):
        self.identifier = identifier
        self.name = name
        self.value = value
        #|
    #|
    #|

# class SettingItem:
#     __slots__ = 'identifier', 'icon', 'blf'

#     def __init__(self, identifier, blf, icon):
#         self.identifier = identifier
#         self.blf = blf
#         self.icon = icon
#         #|
#     #|
#     #|


class Lrbt:
    __slots__ = "L", "R", "B", "T"

    def __init__(self, L, R, B, T):
        self.L = L
        self.R = R
        self.B = B
        self.T = T
        #|
    #|
    #|

class BoxGroup:
    __slots__ = 'boxes', 'bind_draw'

    def __init__(self, boxes, bind_draw=None):
        self.boxes = boxes
        self.bind_draw = i_bind_draw  if bind_draw is None else bind_draw
        #|

    def i_bind_draw(self):
        for e in self.boxes: e.bind_draw()
        #|

    def dx(self, dx):
        for e in self.boxes: e.dx(dx)
        #|
    def dx_upd(self, dx):
        for e in self.boxes: e.dx_upd(dx)
        #|
    def dy(self, dy):
        for e in self.boxes: e.dy(dy)
        #|
    def dy_upd(self, dy):
        for e in self.boxes: e.dy_upd(dy)
        #|
    def dxy(self, dx, dy):
        for e in self.boxes: e.dxy(dx, dy)
        #|
    def dxy_upd(self, dx, dy):
        for e in self.boxes: e.dxy_upd(dx, dy)
        #|
    #|
    #|

class Udraw:
    __slots__ = 'u_draw'

    def __init__(self, u_draw):
        self.u_draw = u_draw
        #|
    #|
    #|

class LocalHistory:
    __slots__ = 'w', 'index', 'array', 'r_push_item', 'push_context'

    def __init__(self, w, array_len, r_push_item=None):
        self.w = w
        self.array = deque(maxlen=array_len)
        self.r_push_item = self.r_push_item_default  if r_push_item == None else r_push_item
        self.index = -1
        self.push_context = None
        self.push()
        #|
    def kill(self):
        self.array.clear()
        del self.array
        #|

    def push(self):
        if self.index != len(self.array) - 1:

            array = self.array
            new_array = deque([array[r]  for r in range(self.index + 1)], maxlen=array.maxlen)
            array.clear()
            del array
            self.array = new_array

        self.array.append(self.r_push_item())
        self.index = len(self.array) - 1

        #|

    def r_push_item_default(self):
        push_context = self.push_context
        self.push_context = None
        return push_context
        #|
    #|
    #|
class HistoryValue:
    __slots__ = 'set_value', 'value_from', 'value_to', 'info'

    def __init__(self, value_from, value_to, set_value, info):
        self.value_from = value_from
        self.value_to = value_to
        self.set_value = set_value
        self.info = info
        #|
    #|
    #|



class RegionData:
    __slots__ = "L", "R", "B", "T", "border"

    def __init__(self):
        #|
        self.border = Lrbt(0, 0, 0, 0)
        #|

    def upd(self, area, region):
        #|
        L = 0
        R = 0
        B = 0
        T = 0

        for r in area.regions:
            if r.type == 'TOOLS':
                if r.alignment == "LEFT":   L += r.width
                else:                       R -= r.width
            elif r.type == 'UI':
                if r.alignment == "LEFT":   L += r.width
                else:                       R -= r.width
            elif r.type == 'TOOL_HEADER':
                if r.alignment == "TOP":    T -= r.height
                else:                       B += r.height

        b       = self.border
        b.L     = L
        b.R     = R
        b.B     = B
        b.T     = T
        self.L  = L
        self.R  = region.width + R
        self.B  = B
        self.T  = region.height + T
        #|

    def outside(self, x, y):
        return x < self.L or x > self.R or y < self.B or y > self.T
        #|
    #|
    #|


class RnaSlots:
    __slots__ = (
        'identifier',
        'name',
        'description',
        'type')
    #|
    #|
class RnaSubtab(RnaSlots):
    __slots__ = 'icon_id'

    def __init__(self, identifier, name, description, icon_id=""):
        self.identifier = identifier
        self.name = name
        self.description = description
        self.type = "RNASUBTAB"
        self.icon_id = icon_id
        #|
    #|
    #|
class RnaButton(RnaSlots):
    __slots__ = (
        'is_repeat',
        'default',
        'size')

    def __init__(self, identifier, name, description, button_text, is_repeat=False, size=0):
        self.identifier = identifier
        self.name = name
        self.description = description
        self.default = button_text
        self.type = "RNABUTTON"
        self.is_repeat = is_repeat
        self.size = size
        #|
    #|
    #|
class RnaString(RnaSlots):
    __slots__ = (
        'default',
        'subtype',
        'is_readonly',
        'is_never_none')

    def __init__(self, identifier,
                name = "",
                description = "",
                default = "\"\"",
                subtype = "NONE",
                is_readonly = False,
                is_never_none = False):

        self.identifier = identifier
        self.name = name
        self.description = description
        self.default = default
        self.subtype = subtype
        self.is_readonly = is_readonly
        self.is_never_none = is_never_none
        self.type = "STRING"
        #|
    #|
    #|
class RnaEnum(RnaSlots):
    __slots__ = (
        'default',
        'enum_items',
        'is_readonly',
        'is_never_none',
        'is_enum_flag')

    def __init__(self, identifier, enum_items,
                name = "",
                description = "",
                default = "\"\"",
                is_readonly = False,
                is_never_none = True,
                is_enum_flag = False):

        self.identifier = identifier
        self.enum_items = enum_items
        self.name = name
        self.description = description
        self.default = default
        self.is_readonly = is_readonly
        self.is_never_none = is_never_none
        self.is_enum_flag = is_enum_flag
        self.type = "ENUM"
        #|
    #|
    #|
class RnaBool(RnaSlots):
    __slots__ = (
        'default',
        'is_array')

    def __init__(self, identifier,
                name = "",
                description = "",
                default = False):

        self.identifier = identifier
        self.name = name
        self.description = description
        self.default = default
        self.type = "BOOLEAN"
        self.is_array = False
        #|
    #|
    #|
class RnaBoolVector(RnaSlots):
    __slots__ = (
        'array_length',
        'default_array',
        'is_array')

    def __init__(self, identifier,
                name = "",
                description = "",
                default = False):

        self.identifier = identifier
        self.name = name
        self.description = description
        self.default_array = default
        self.type = "BOOLEAN"
        self.is_array = True
        self.array_length = len(default)
        #|
    #|
    #|
class RnaInt(RnaSlots):
    __slots__ = (
        'default',
        'hard_max',
        'hard_min',
        'is_array',
        'subtype',
        'unit',
        'step')

    def __init__(self, identifier,
                name = "",
                description = "",
                default = 0,
                hard_min = -2147483648,
                hard_max = 2147483647,
                subtype = "NONE",
                unit = "NONE",
                step = 1):

        self.identifier = identifier
        self.name = name
        self.description = description
        self.default = default
        self.type = "INT"
        self.is_array = False
        self.hard_min = hard_min
        self.hard_max = hard_max
        self.subtype = subtype
        self.unit = unit
        self.step = step
        #|
    #|
    #|
class RnaIntVector(RnaSlots):
    __slots__ = (
        'array_length',
        'default_array',
        'hard_max',
        'hard_min',
        'is_array',
        'subtype',
        'unit',
        'step')

    def __init__(self, identifier,
                name = "",
                description = "",
                default = 0,
                hard_min = -2147483648,
                hard_max = 2147483647,
                subtype = "NONE",
                unit = "NONE",
                step = 1):

        self.identifier = identifier
        self.name = name
        self.description = description
        self.default_array = default
        self.type = "INT"
        self.is_array = True
        self.hard_min = hard_min
        self.hard_max = hard_max
        self.subtype = subtype
        self.unit = unit
        self.step = step
        self.array_length = len(default)
        #|
    #|
    #|
class RnaFloat(RnaSlots):
    __slots__ = (
        'default',
        'hard_max',
        'hard_min',
        'is_array',
        'subtype',
        'unit',
        'step')

    def __init__(self, identifier,
                name = "",
                description = "",
                default = 0.0,
                hard_min = -3.402823e+38,
                hard_max = 3.402823e+38,
                subtype = "NONE",
                unit = "NONE",
                step = 1):

        self.identifier = identifier
        self.name = name
        self.description = description
        self.default = default
        self.type = "FLOAT"
        self.is_array = False
        self.hard_min = hard_min
        self.hard_max = hard_max
        self.subtype = subtype
        self.unit = unit
        self.step = step
        #|
    #|
    #|
class RnaFloatVector(RnaSlots):
    __slots__ = (
        'array_length',
        'default_array',
        'hard_max',
        'hard_min',
        'is_array',
        'subtype',
        'unit',
        'step')

    def __init__(self, identifier,
                name = "",
                description = "",
                default = 0.0,
                hard_min = -3.402823e+38,
                hard_max = 3.402823e+38,
                subtype = "NONE",
                unit = "NONE",
                step = 1):

        self.identifier = identifier
        self.name = name
        self.description = description
        self.default_array = default
        self.type = "FLOAT"
        self.is_array = True
        self.hard_min = hard_min
        self.hard_max = hard_max
        self.subtype = subtype
        self.unit = unit
        self.step = step
        self.array_length = len(default)
        #|
    #|
    #|

class EnumItem(RnaSlots):
    __slots__ = ()

    def __init__(self, identifier, name, description=""):
        self.identifier = identifier
        self.name = name
        self.description = description
        #|
    #|
    #|
class EnumItems(dict):
    __slots__ = 'D_index_key', 'D_key_index', 'default'

    def __contains__(self, k):
        return k in self.D_key_index
        #|
    def __iter__(self):
        for i in range(len(self.D_index_key)):
            yield self[i]
        #|

    def keys(self):
        D_index_key = self.D_index_key
        return tuple(D_index_key[r] for r in range(len(D_index_key)))
        #|
    def items(self):
        D_index_key = self.D_index_key
        return tuple((D_index_key[r], self[r]) for r in range(len(D_index_key)))
        #|
    def find(self, k):
        if k in self.D_key_index: return self.D_key_index[k]
        return -1
        #|
    #|
    #|
def r_enum_items_create(ls, default_key):
    items = EnumItems()
    dic = {l[0]: EnumItem(*l)  for l in ls}
    items.update(dic)

    items.D_index_key = {r: l[0]  for r, l in enumerate(ls)}
    items.D_key_index = {k: i  for i, k  in items.D_index_key.items()}

    D_key_index = items.D_key_index
    items.update({D_key_index[k]: e  for k, e in dic.items()})
    items.default = default_key
    return items
    #|
def r_collection_create(ls):
    items = EnumItems()
    dic = {l.identifier: l  for l in ls}
    items.update(dic)

    items.D_index_key = {r: l.identifier  for r, l in enumerate(ls)}
    items.D_key_index = {k: i  for i, k  in items.D_index_key.items()}

    D_key_index = items.D_key_index
    items.update({D_key_index[k]: e  for k, e in dic.items()})
    return items
    #|

class ArrayActive(dict):
    __slots__ = 'active_index', 'len', 'maxindex'

    def __init__(self, ls, active_index):
        self.active_index = active_index
        self.update({r: e  for r, e in enumerate(ls)})
        self.len = len(ls)
        self.maxindex = self.len - 1
        #|

    def __iter__(self):
        for r in range(self.len):
            yield self[r]
        #|

    def shiftactive(self, i):
        if i < 0:
            if self.active_index == 0: return
            old = self.active_index
            new = max(0, old + i)

            dic = {r + 1: self.pop(r)  for r in range(new, old)}
            self[new] = self.pop(old)
            self.update(dic)
            self.active_index = new
        else:
            if self.active_index == self.maxindex: return
            old = self.active_index
            new = min(self.maxindex, old + i)

            dic = {r - 1: self.pop(r)  for r in range(old + 1, new + 1)}
            self[new] = self.pop(old)
            self.update(dic)
            self.active_index = new
        #|
    #|
    #|
