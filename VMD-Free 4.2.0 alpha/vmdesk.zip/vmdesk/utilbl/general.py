import bpy
from bpy.types import CollectionProperty, BlendData

from . blg import report

ed_undo_push = bpy.ops.ed.undo_push


def format_exception(ex):
    ss = str(ex).split('poll()', 1)
    return ss if len(ss) == 1 else ss[1].lstrip()
    #|

def r_obj_path_by_full_path(path):
    try:
        names = {e.identifier for e in BlendData.bl_rna.properties  if isinstance(e, CollectionProperty)}

        ind_data = path.find("data.")

        ind_obj_start = ind_data + 5
        ind_obj_end = path.find("[", ind_obj_start)
        bpy_colls = getattr(bpy.data, path[ind_obj_start : ind_obj_end])

        ind_name_start = ind_obj_end + 1
        ind_name_end = path.find("]", ind_name_start)
        tar_obj = bpy_colls[path[ind_name_start + 1 : ind_name_end - 1]]
        dr_path = path[ind_name_end + 2 :]  if path[ind_name_end + 1] == "." else path[ind_name_end + 1 :]
        return tar_obj, dr_path
    except: return None, None
    #|

def r_add_to_keying_set(ob, dp, index=None, undo_push=True):
    try:
        keying_sets = bpy.context.scene.keying_sets
        act_ks = keying_sets.active
        if act_ks is None:
            act_ks = keying_sets.new(idname='Button Keying Set', name='Button Keying Set')
            # act_ks.use_insertkey_xyz_to_rgb = True # removed:4.1
            # act_ks.use_insertkey_override_xyz_to_rgb = True # removed:4.1

        kspath = act_ks.paths.add(ob, dp)
        if not kspath: return False, "Failed to add keying set, path may already exist"

        if index is not None:
            if index == "all":
                kspath.use_entire_array = True
            else:
                kspath.use_entire_array = False
                kspath.array_index = index
        keying_sets.active = keying_sets.active
        if undo_push:
            ed_undo_push(message="VMD Add to Keying Set")
        report(f'Property added to Keying Set: "{act_ks.bl_idname}"')
        return True, ""
    except Exception as ex:
        return False, str(ex)
    #|
def r_remove_from_keying_set(ob, dp, index=None, undo_push=True):
    try:
        keying_sets = bpy.context.scene.keying_sets
        act_ks = keying_sets.active
        if act_ks is None:
            return False, "Keying Set not find"

        paths = act_ks.paths
        tag = False
        if index is None:
            for p in paths:
                if p.id != ob: continue
                if p.data_path != dp: continue
                paths.remove(p)
                tag = True
        elif index == "all":
            for p in paths:
                if p.id != ob: continue
                if p.data_path != dp: continue
                if p.use_entire_array:
                    paths.remove(p)
                    tag = True
        else:
            for p in paths:
                if p.id != ob: continue
                if p.data_path != dp: continue
                if p.use_entire_array: continue
                if p.array_index == index:
                    paths.remove(p)
                    tag = True

        if tag:
            keying_sets.active = keying_sets.active
            if undo_push:
                ed_undo_push(message="VMD Remove from Keying Set")
            report(f'Property removed from Keying Set: "{act_ks.bl_idname}"')
            return True, ""
        else:
            return False, "Keying Set not find"
    except Exception as ex:
        return False, str(ex)
    #|

def r_library_or_override_message(ob):
    if hasattr(ob, "library") and ob.library:
        return "This operation cannot be performed\nfrom a linked data-block"
    if hasattr(ob, 'override_library') and ob.override_library and ob.override_library.is_system_override:
        return "This operation cannot be performed\nfrom a system override data-block"
    return ""
    #|
def r_library_editable(ob):
    if hasattr(ob, "library") and ob.library:
        return False
    if hasattr(ob, 'override_library') and ob.override_library and ob.override_library.is_system_override:
        return False
    return True
    #|

def update_scene():
    bpy.context.scene.update_tag()
    P.refresh = True
    Admin.REDRAW()
    update_data()
    #|
def update_scene_push(push_message=""):
    bpy.context.scene.update_tag()
    P.refresh = True
    Admin.REDRAW()
    update_data()
    ed_undo_push(message=push_message)
    #|


## _file_ ##
def _import_():
    #|
    # //* 0general_import_m
    # *// =|
    # <<< 1copy (0general_import_m,, $$)
    global P,Admin,update_data
    # >>>
    # <<< 1copy (0general_import_m,, ${'global': 'from .. m import'}$)
    from .. m import P,Admin,update_data
    # >>>
    #|
