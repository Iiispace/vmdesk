from gpu.types import GPUShaderCreateInfo, GPUStageInterfaceInfo
from gpu.shader import create_from_info



shader_info = GPUShaderCreateInfo()
shader_info.push_constant('MAT4', "viewProjectionMatrix")
shader_info.push_constant('VEC4', "color")
shader_info.vertex_in(0, 'VEC2', "position")
shader_info.fragment_out(0, 'VEC4', "FragColor")

shader_info.vertex_source('''
    void main() {
        gl_Position = viewProjectionMatrix * vec4(position, 1.0f, 1.0f);
    }
''')

shader_info.fragment_source('''
    void main() {
        FragColor = color;
    }
''')

GL_BOX = create_from_info(shader_info)
del shader_info
GL_BOX_bind = GL_BOX.bind
GL_BOX_uniform_float = GL_BOX.uniform_float

# -------------------------------------------------------------------------------------------------------------

vert_out = GPUStageInterfaceInfo("temp_interface")
vert_out.smooth('VEC2', "pos")
shader_info = GPUShaderCreateInfo()
shader_info.push_constant('MAT4', "viewProjectionMatrix")
shader_info.push_constant('IVEC4', "inner")
shader_info.push_constant('VEC4', "color")
shader_info.push_constant('VEC4', "color_rim")
shader_info.vertex_in(0, 'VEC2', "position")
shader_info.vertex_out(vert_out)
shader_info.fragment_out(0, 'VEC4', "FragColor")

shader_info.vertex_source('''
    void main() {
        pos = position;
        gl_Position = viewProjectionMatrix * vec4(position, 1.0f, 1.0f);
    }
''')

shader_info.fragment_source('''
    void main() {
        if (pos[0] >= inner[0] && pos[0] <= inner[1] && pos[1] >= inner[2] && pos[1] <= inner[3])
            FragColor = color;
        else
            FragColor = color_rim;
    }
''')

GL_RIM = create_from_info(shader_info)
del vert_out
del shader_info
GL_RIM_bind = GL_RIM.bind
GL_RIM_uniform_float = GL_RIM.uniform_float
GL_RIM_uniform_int = GL_RIM.uniform_int

# -------------------------------------------------------------------------------------------------------------

vert_out = GPUStageInterfaceInfo("temp_interface")
vert_out.smooth('VEC2', "pos")
shader_info = GPUShaderCreateInfo()
shader_info.push_constant('MAT4', "viewProjectionMatrix")
shader_info.push_constant('IVEC4', "T_T1_height_hideInd")
shader_info.push_constant('VEC4', "color")
shader_info.vertex_in(0, 'VEC2', "position")
shader_info.vertex_out(vert_out)
shader_info.fragment_out(0, 'VEC4', "FragColor")

shader_info.vertex_source('''
    void main() {
        pos = position;
        gl_Position = viewProjectionMatrix * vec4(position, 1.0f, 1.0f);
    }
''')

shader_info.fragment_source('''
    void main() {
        int yRelative = T_T1_height_hideInd[0] - int(pos[1]) ;
        int ind = yRelative / T_T1_height_hideInd[2] ;
        int y = T_T1_height_hideInd[0] + (yRelative - ind * T_T1_height_hideInd[2]) ;

        if (ind == T_T1_height_hideInd[3]) {
            FragColor = vec4(0.0f, 0.0f, 0.0f, 0.0f) ;
            return ;
        }

        if (y >= T_T1_height_hideInd[0] && y < T_T1_height_hideInd[1])
            FragColor = vec4(0.0f, 0.0f, 0.0f, 0.0f) ;
        else
            FragColor = color ;
    }
''')

GL_BOXES_Y = create_from_info(shader_info)
del vert_out
del shader_info
GL_BOXES_Y_bind = GL_BOXES_Y.bind
GL_BOXES_Y_uniform_float = GL_BOXES_Y.uniform_float
GL_BOXES_Y_uniform_int = GL_BOXES_Y.uniform_int

# -------------------------------------------------------------------------------------------------------------

vert_out = GPUStageInterfaceInfo("temp_interface")
vert_out.smooth('VEC2', "uvInterp")
shader_info = GPUShaderCreateInfo()
shader_info.push_constant('MAT4', "viewProjectionMatrix")
shader_info.sampler(0, 'FLOAT_2D', "image")
shader_info.vertex_in(0, 'VEC2', "position")
shader_info.vertex_in(1, 'VEC2', "uv")
shader_info.vertex_out(vert_out)
shader_info.fragment_out(0, 'VEC4', "FragColor")

shader_info.vertex_source('''
    void main() {
        uvInterp = uv;
        gl_Position = viewProjectionMatrix * vec4(position, 1.0f, 1.0f);
    }
''')

shader_info.fragment_source('''
    void main() {
        FragColor = texture(image, uvInterp);
    }
''')
GL_IMG = create_from_info(shader_info)
del vert_out
del shader_info
GL_IMG_bind = GL_IMG.bind
GL_IMG_uniform_float = GL_IMG.uniform_float
