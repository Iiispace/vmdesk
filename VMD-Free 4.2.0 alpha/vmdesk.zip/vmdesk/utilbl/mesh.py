import bpy

from .. util.algebra import r_compose
from .. util.const import (
    TUP_111,
    VEC_00M1,
    VEC_010,
    ROT_00M1_111U,
    ROT_00M1_111U_inv)


def add_light(loc, v0, v1, wi, nor, ty="AREA", shape="RECTANGLE"):
    vec_x = v1 - v0
    wi_y = vec_x.length
    vec_x.normalize()

    rot = VEC_00M1.rotation_difference(nor)
    rot2 = (rot @ VEC_010).rotation_difference(vec_x)

    if nor.to_tuple(4) != (rot2 @ rot @ VEC_00M1).to_tuple(4):
        nor = ROT_00M1_111U @ nor
        vec_x = ROT_00M1_111U @ vec_x
        rot = VEC_00M1.rotation_difference(nor)
        rot2 = (rot @ VEC_010).rotation_difference(vec_x)
        rot2 = ROT_00M1_111U_inv @ rot2

    bpy.ops.object.light_add(type=ty, align='WORLD')
    light = bpy.context.object
    light.matrix_world = r_compose(loc, rot2 @ rot, TUP_111)
    light.data.shape = shape
    light.data.size = wi
    light.data.size_y = wi_y
    return light
