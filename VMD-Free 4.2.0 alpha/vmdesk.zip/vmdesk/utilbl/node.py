import bpy

def new_img_to_mat(mat, size, is_32bit, space, file_format, filepath_raw):
    img = bpy.data.images.new("", *size, float_buffer=is_32bit)
    img.colorspace_settings.name = space
    img.file_format = file_format
    img.filepath_raw = filepath_raw
    nodes = mat.node_tree.nodes
    node = nodes.new("ShaderNodeTexImage")
    node.image = img
    nodes.active = node
    return img, node
