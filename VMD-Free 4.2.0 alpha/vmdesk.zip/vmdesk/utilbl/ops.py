import bpy

from bpy.types import Operator
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty

## _reg_ ##
class OpInternal(Operator):
    __slots__ = ()
    bl_idname = "wm.vmd_internal"
    bl_label = "VMD Internal"
    bl_options = {'INTERNAL'}

    MAIN = None

    def invoke(self, context, event):

        OpInternal.MAIN()
        return {'FINISHED'}
        #|
    #|
    #|
## _reg_ ##
class OpBevelProfile(Operator):
    bl_idname = "wm.vmd_bevel_profile"
    bl_label = "Custom Profile"
    bl_options = {'INTERNAL'}

    md = None

    def execute(self, context): return {'FINISHED'}
    def invoke(self, context, event): return context.window_manager.invoke_props_dialog(self)
    def draw(self, context): self.layout.template_curveprofile(OpBevelProfile.md, "custom_profile")
    #|
    #|
## _reg_ ##
class OpFalloffCurve(Operator):
    bl_idname = "wm.vmd_falloff_curve"
    bl_label = "Falloff Curve"
    bl_options = {'INTERNAL'}

    md = None
    attr = None

    def execute(self, context): return {'FINISHED'}
    def invoke(self, context, event): return context.window_manager.invoke_props_dialog(self)
    def draw(self, context): self.layout.template_curve_mapping(OpFalloffCurve.md, OpFalloffCurve.attr)
    #|
    #|
## _reg_ ##
class OpScanFile(Operator):
    bl_idname = "wm.vmd_scan_file"
    bl_label = "Accept"
    bl_options = {'INTERNAL'}
    filepath: StringProperty(subtype="FILE_PATH", default="")

    end_fn = None

    def execute(self, context):
        try:    self.fin(self.filepath)
        except: pass
        return {'FINISHED'}

    def invoke(self, context, event):
        self.fin = OpScanFile.end_fn
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    #|
    #|
## _reg_ ##
class OpScanFolder(Operator):
    bl_idname = "wm.vmd_scan_folder"
    bl_label = "Accept"
    bl_options = {'INTERNAL'}

    end_fn = None

    directory: StringProperty(name="Directory", description="Folder Directory")
    filter_folder: BoolProperty(default=True, options={"HIDDEN"})

    def execute(self, context):
        try:    self.fin(self.directory)
        except: pass
        return {'FINISHED'}

    def invoke(self, context, event):
        self.fin = OpScanFolder.end_fn
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    #|
    #|
