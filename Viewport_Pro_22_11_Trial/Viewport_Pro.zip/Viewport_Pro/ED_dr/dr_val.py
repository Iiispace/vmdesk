import bpy
from blf import size as blf_size

from .. import m
from .. m import NAME, bind_color_bu_1_rim
from .. bu import BURE, BUTI, BUDA_PAN
from .. dd import DDTX_FN, DDTX_RENAME
from .. filt import FIL
from .. link_data import is_target_path_valid, is_custom_path_valid
from .. fn import (
    R_path_value,
    R_driver_variable_value_TRANSFORMS,
    R_driver_variable_value_ROTATION_DIFF,
    R_driver_variable_value_LOC_DIFF)

P = None
F = None
N = None
font_0 = None

class BPY_TYPES:
    @classmethod
    def init(cls):
        prop                = cls.prop
        cls.enum_items      = prop.enum_items
        cls.dic_name_val    = {e.name : e.identifier for e in cls.enum_items}
        cls.dic_val_name    = {e.identifier : e.name for e in cls.enum_items}
        cls.default         = prop.default
class VAR_TYPES(BPY_TYPES):
    __slots__ = ()
    prop = bpy.types.DriverVariable.bl_rna.properties["type"]
class TAR_TYPES(BPY_TYPES):
    __slots__ = ()
    prop = bpy.types.DriverTarget.bl_rna.properties["id_type"]
    dic_val_coll = {
        "ACTION":           "actions",
        "ARMATURE":         "armatures",
        "BRUSH":            "brushes",
        "CAMERA":           "cameras",
        "CACHEFILE":        "cache_files",
        "CURVE":            "curves",
        "FONT":             "fonts",
        "GREASEPENCIL":     "grease_pencils",
        "COLLECTION":       "collections",
        "IMAGE":            "images",
        "KEY":              "shape_keys",
        "LIGHT":            "lights",
        "LIBRARY":          "libraries",
        "LINESTYLE":        "linestyles",
        "LATTICE":          "lattices",
        "MASK":             "masks",
        "MATERIAL":         "materials",
        "META":             "metaballs",
        "MESH":             "meshes",
        "MOVIECLIP":        "movieclips",
        "NODETREE":         "node_groups",
        "OBJECT":           "objects",
        "PAINTCURVE":       "paint_curves",
        "PALETTE":          "palettes",
        "PARTICLE":         "particles",
        "LIGHT_PROBE":      "lightprobes",
        "SCENE":            "scenes",
        # "SIMULATION":       "",
        "SOUND":            "sounds",
        "SPEAKER":          "speakers",
        "TEXT":             "texts",
        "TEXTURE":          "textures",
        # "CURVES":           "",
        "POINTCLOUD":       "pointclouds",
        "VOLUME":           "volumes",
        "WINDOWMANAGER":    "window_managers",
        "WORLD":            "worlds",
        "WORKSPACE":        "workspaces",
    }
class ROT_TYPES(BPY_TYPES):
    __slots__ = ()
    prop = bpy.types.DriverTarget.bl_rna.properties["rotation_mode"]
class TRANSPACE_TYPES(BPY_TYPES):
    __slots__ = ()
    prop = bpy.types.DriverTarget.bl_rna.properties["transform_space"]
class TRANTYPE_TYPES(BPY_TYPES):
    __slots__ = ()
    prop = bpy.types.DriverTarget.bl_rna.properties["transform_type"]

for cls in (VAR_TYPES, TAR_TYPES, ROT_TYPES, TRANSPACE_TYPES, TRANTYPE_TYPES):
    cls.init()


class DRVAL:
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'sci',
        'oo',
        'oo_sci',
        'oo_free',
        'oo_22',
        'oo_12',
        'oo_9',
    )
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        sci                 = w.sci
        self.sci            = sci
        f9                  = F[9]

        oo = {
            "ti_name":      BUTI(self, "ti_name", "VARIABLE", self.bu_fn_ti_name),
            "ti_info":      BUTI(self, "ti_info", "INFO", N),
            "ti_type":      BUTI(self, "ti_type", "Type", N),
            "ti_tar_type":  BUTI(self, "ti_tar_type", "Target Type", N),
            "ti_tar":       BUTI(self, "ti_tar", "Target", N),
            "ti_dp":        BUTI(self, "ti_dp", "Data Path", N),
            "ti_trantype":  BUTI(self, "ti_trantype", "Transform Type", N),
            "ti_transpace": BUTI(self, "ti_transpace", "Transform Space", N),
            "ti_rot":       BUTI(self, "ti_rot", "Rotation Mode", N),
            "ti_tar2":      BUTI(self, "ti_tar2", "Target 2", N),
            "ti_transpace2":BUTI(self, "ti_transpace2", "Transform Space", N),
            "ti_bone":      BUTI(self, "ti_bone", "Bone", N),
            "ti_bone2":     BUTI(self, "ti_bone2", "Bone", N),

            "bu_del":       BURE(self, "bu_del", "Delete Variable", self.bu_fn_del),
            "bu_del_tar":   BURE(self, "bu_del_tar", "Remove Target", self.bu_fn_del_tar),
            "bu_del_tar2":  BURE(self, "bu_del_tar2", "Remove Target", self.bu_fn_del_tar2),
            # "bu_add":       BURE(self, "bu_add", "Add Variable", self.bu_fn_add),

            "da_name":      BUDA_PAN(self, "da_name", self.bu_fn_da_name, f9, w_sci=sci),
            "da_info":      BUDA_PAN(self, "da_info", self.bu_fn_da_info, f9, w_sci=sci),
            "da_type":      BUDA_PAN(self, "da_type", self.bu_fn_da_type, f9),
            "da_tar_type":  BUDA_PAN(self, "da_tar_type", self.bu_fn_da_tar_type, f9),
            "da_tar":       BUDA_PAN(self, "da_tar", self.bu_fn_da_tar, f9, w_sci=sci),
            "da_dp":        BUDA_PAN(self, "da_dp", None, f9, w_sci=sci),
            "da_trantype":  BUDA_PAN(self, "da_trantype", None, f9),
            "da_transpace": BUDA_PAN(self, "da_transpace", None, f9),
            "da_rot":       BUDA_PAN(self, "da_rot", None, f9),
            "da_tar2":      BUDA_PAN(self, "da_tar2", self.bu_fn_da_tar2, f9, w_sci=sci),
            "da_transpace2":BUDA_PAN(self, "da_transpace2", None, f9),
            "da_bone":      BUDA_PAN(self, "da_bone", self.bu_fn_da_bone, f9, w_sci=sci),
            "da_bone2":     BUDA_PAN(self, "da_bone2", self.bu_fn_da_bone2, f9, w_sci=sci),
        }
        self.oo = oo

        self.oo_sci = {oo[k] for k in {
            "da_name",
            "da_info",
            "da_tar",
            "da_tar2",
            "da_dp",
            "da_bone",
            "da_bone2",
        }}
        self.oo_free = {oo[k] for k in {
            "da_type",
            "da_tar_type",
            "da_trantype",
            "da_transpace",
            "da_rot",
            "da_transpace2",
        }}
        self.oo_22 = {oo[k] for k in {

        }}
        self.oo_12 = {oo[k] for k in {
            "ti_name",
            "ti_info",
        }}
        self.oo_9 = {oo[k] for k in {
            "ti_type",
            "bu_del",
            "bu_del_tar",
            "ti_tar_type",
            "ti_tar",
            "ti_dp",
            "ti_trantype",
            "ti_transpace",
            "ti_rot",
            "ti_tar2",
            "ti_transpace2",
            "ti_bone",
            "ti_bone2",
            "bu_del_tar2",
            # "bu_add",
        }}

        oo["ti_name"].off()
        oo["ti_info"].off()
        oo["ti_type"].off()
        oo["ti_tar_type"].off()
        oo["ti_tar"].off()
        oo["ti_dp"].off()
        oo["ti_trantype"].off()
        oo["ti_transpace"].off()
        oo["ti_rot"].off()
        oo["ti_tar2"].off()
        oo["ti_transpace2"].off()
        oo["ti_bone"].off()
        oo["ti_bone2"].off()

        e = self.R_bu_fn_tar
        oo["da_dp"].fn = e(oo["da_dp"], "data_path", None, tx_clear=None)
        oo["da_trantype"].fn = e(oo["da_trantype"], "transform_type", TRANTYPE_TYPES)
        oo["da_transpace"].fn = e(oo["da_transpace"], "transform_space", TRANSPACE_TYPES)
        oo["da_rot"].fn = e(oo["da_rot"], "rotation_mode", ROT_TYPES)
        oo["da_transpace2"].fn = e(oo["da_transpace2"], "transform_space", TRANSPACE_TYPES, tar_ind=1)

    def get_bo(self):
        oo  = self.oo
        w   = self.w
        bo  = w.bo
        x   = bo["dr_var"].L
        y   = bo["dr_var"].T
        u   = P.scale[0]
        f15 = F[15]
        dR  = F[8]
        dB  = F[22]

        blf_size(font_0, F[12], 72)
        L0  = x + F[7]
        B   = y - dB
        oo["ti_name"].LBT(L0, B, B + f15, 4.5)
        rim = oo["ti_name"].rim
        L  = rim.L + F[82]
        R0 = bo["dr_var"].R - F[7]
        oo["da_name"].LRBT(L - F[1], R0, rim.B, rim.T)
        B   -= dB
        T   = B + f15
        oo["ti_info"].LBT(L0 + F[1], B, T, 4.5)
        oo["da_info"].LRBT(L - F[1], R0, B, T)

        blf_size(font_0, F[9], 72)
        B   -= dB
        T   = B + f15
        bu_wi = round(85 * u)
        oo["bu_del"].LRBT(R0 - bu_wi, R0, B, T)
        R   = oo["bu_del"].rim.L - F[7]
        L   = oo["da_name"].rim.L
        oo["da_type"].LRBT(L, R, B, T)
        oo["ti_type"].align_R_by_bu(oo["da_type"], dR)

        B   -= dB
        T   = B + f15
        oo["da_tar_type"].LRBT(L, R, B, T)
        oo["ti_tar_type"].align_R_by_bu(oo["da_tar_type"], dR)
        e = oo["bu_del_tar"]
        e.LRBT(oo["bu_del"].rim.L, R0, B, T)
        e.ti.x -= F[1]
        e.offset_x -= F[1]

        B   -= dB
        oo["da_tar"].LRBT(L, R0, B, B + f15)
        oo["ti_tar"].align_R_by_bu(oo["da_tar"], dR)

        B   -= dB
        oo["da_bone"].LRBT(L, R0, B, B + f15)
        oo["ti_bone"].align_R_by_bu(oo["da_bone"], dR)

        B   -= dB
        oo["da_dp"].LRBT(L, R0, B, B + f15)
        oo["ti_dp"].align_R_by_bu(oo["da_dp"], dR)

        for k in ("trantype", "transpace", "rot"):
            B   -= dB
            e   = oo["da_" + k]
            e.LRBT(L, R, B, B + f15)
            oo["ti_" + k].align_R_by_bu(e, dR)

        B   -= F[8] + dB
        oo["da_tar2"].LRBT(L, R0, B, B + f15)
        oo["ti_tar2"].align_R_by_bu(oo["da_tar2"], dR)

        B   -= dB
        oo["da_bone2"].LRBT(L, R0, B, B + f15)
        oo["ti_bone2"].align_R_by_bu(oo["da_bone2"], dR)

        B   -= dB
        e   = oo["da_transpace2"]
        e.LRBT(L, R, B, B + f15)
        oo["ti_transpace2"].align_R_by_bu(e, dR)

        e = oo["bu_del_tar2"]
        e.LRBT(oo["bu_del"].rim.L, R0, B, B + f15)
        e.ti.x -= F[1]
        e.offset_x -= F[1]

    def glopan_end(self):
        for e in self.oo_sci:   e.upd_tx_pos()
    def dxy_upd(self, x, y):
        for e in self.oo.values():  e.dxy_upd(x, y)

    def I_modal_main(self, evt):
        self.RET = False
        oo  = self.oo
        x   = evt.mouse_region_x
        y   = evt.mouse_region_y

        if y > oo["ti_name"].rim.T:     return self.RET
        if y >= oo["ti_name"].rim.B:
            if oo["ti_name"].rim.in_LR_x(x):    oo["ti_name"].inside(evt)
            elif oo["da_name"].rim.in_LR_x(x):  oo["da_name"].inside(evt)
            return self.RET
        if y > oo["da_info"].rim.T:     return self.RET
        if y >= oo["da_info"].rim.B:
            if oo["da_info"].rim.in_LR_x(x):    oo["da_info"].inside(evt)
            return self.RET
        if y >= oo["bu_del"].rim.B:
            if oo["da_type"].rim.in_LR_x(x):        oo["da_type"].inside(evt)
            elif oo["bu_del"].rim.in_LR_x(x):       oo["bu_del"].inside(evt)
            return self.RET
        if y >= oo["da_tar_type"].rim.B:
            if oo["da_tar_type"].rim.in_LR_x(x):    oo["da_tar_type"].inside(evt)
            elif oo["bu_del_tar"].rim.in_LR_x(x):   oo["bu_del_tar"].inside(evt)
            return self.RET
        if y >= oo["da_tar"].rim.B:
            if oo["da_tar"].rim.in_LR_x(x):         oo["da_tar"].inside(evt)
            return self.RET
        if y >= oo["da_bone"].rim.B:
            if oo["da_bone"].rim.in_LR_x(x):        oo["da_bone"].inside(evt)
            return self.RET
        if y >= oo["da_dp"].rim.B:
            if oo["da_dp"].rim.in_LR_x(x):          oo["da_dp"].inside(evt)
            return self.RET
        if y >= oo["da_trantype"].rim.B:
            if oo["da_trantype"].rim.in_LR_x(x):    oo["da_trantype"].inside(evt)
            return self.RET
        if y >= oo["da_transpace"].rim.B:
            if oo["da_transpace"].rim.in_LR_x(x):   oo["da_transpace"].inside(evt)
            return self.RET
        if y >= oo["da_rot"].rim.B:
            if oo["da_rot"].rim.in_LR_x(x):         oo["da_rot"].inside(evt)
            return self.RET
        if y >= oo["da_tar2"].rim.B:
            if oo["da_tar2"].rim.in_LR_x(x):        oo["da_tar2"].inside(evt)
            return self.RET
        if y >= oo["da_bone2"].rim.B:
            if oo["da_bone2"].rim.in_LR_x(x):       oo["da_bone2"].inside(evt)
            return self.RET
        if y >= oo["da_transpace2"].rim.B:
            if oo["da_transpace2"].rim.in_LR_x(x):  oo["da_transpace2"].inside(evt)
            elif oo["bu_del_tar2"].rim.in_LR_x(x):  oo["bu_del_tar2"].inside(evt)
            return self.RET
        return self.RET

    def bu_fn_ti_name(self):
        print(f"    dr_val  bu_fn_ti_name")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        variables = act_dr.driver.variables
        r = self.oo["da_name"].rim

        def confirm_fn(tx):
            print(f"    dr_val  bu_fn_ti_name  confirm fn")
            self.oo["da_name"].da.text = tx
            self.w.I_upd_data()

        DDTX_FN(
            m.EVT.evt,
            self.oo["da_name"].da.text,
            FIL(variables),
            (r.L, r.R, r.T - F[16], r.T),
            confirm_fn,
            tx_clear = True
        )
    def bu_fn_da_name(self):
        print(f"    dr_val  bu_fn_da_name")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return
        r = self.oo["da_name"].rim

        def confirm_fn(name):
            print(f"    dr_val  bu_fn_da_name  confirm fn")
            v = variables[tx]
            old_name = v.name
            v.name = name
            if v.name != old_name:
                self.oo["da_name"].da.text = v.name
                m.undo_str = f'[Modifier Editor] DriverVariable.name = "{v.name}"'
                m.undo_push()

        DDTX_RENAME(
            m.EVT.evt,
            tx,
            confirm_fn,
            FIL(variables),
            target          = f"animation_data.drivers.find('{act_dr.data_path}', index={act_dr.array_index}).driver.variables['{tx}'].name",
            full_path_head  = f'bpy.data.objects["{w.oj.name}"].',
        )
    def bu_fn_da_type(self):
        print(f"    dr_val  bu_fn_da_type")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return
        v = variables[tx]

        def confirm_fn(name):
            try:
                print(f"    dr_val  bu_fn_da_type  confirm fn")
                v.type = VAR_TYPES.dic_name_val[name]
                self.w.I_upd_data()
                m.redraw()
                m.undo_str = f'[Modifier Editor] DriverVariable.type = "{v.type}"'
                m.undo_push()
            except:
                pass

        r = self.oo["da_type"].rim
        DDTX_FN(
            m.EVT.evt,
            self.oo["da_type"].da.text,
            FIL(VAR_TYPES.enum_items),
            (r.L, r.R, r.T - F[16], r.T),
            confirm_fn,
            tx_clear = True
        )
    def bu_fn_da_tar_type(self):
        print(f"    dr_val  bu_fn_da_tar_type")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return
        v = variables[tx]

        def confirm_fn(name):
            try:
                print(f"    dr_val  bu_fn_da_tar_type  confirm fn")
                v.targets[0].id_type = TAR_TYPES.dic_name_val[name]
                self.w.I_upd_data()
                m.redraw()
                m.undo_str = f'[Modifier Editor] DriverTarget.id_type = "{v.targets[0].id_type}"'
                m.undo_push()
            except:
                pass

        r = self.oo["da_tar_type"].rim
        DDTX_FN(
            m.EVT.evt,
            self.oo["da_tar_type"].da.text,
            FIL(TAR_TYPES.enum_items),
            (r.L, r.R, r.T - F[16], r.T),
            confirm_fn,
            tx_clear = True
        )
    def bu_fn_da_tar(self):
        print(f"    dr_val  bu_fn_da_tar")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return
        tar = variables[tx].targets[0]
        if tar.id_type in TAR_TYPES.dic_val_coll:
            coll = getattr(bpy.data, TAR_TYPES.dic_val_coll[tar.id_type])
        else:
            coll = {}

        def confirm_fn(name):
            try:
                print(f"    dr_val  bu_fn_da_tar  confirm_fn")
                tar.id = coll[name]  if name else None
                self.w.I_upd_data()
                m.redraw()
                m.undo_str = f'[Modifier Editor] DriverTarget.id = {tar.id.name}'
                m.undo_push()
            except:
                pass

        r = self.oo["da_tar"].rim
        DDTX_FN(
            m.EVT.evt,
            self.oo["da_tar"].da.text,
            FIL((NAME(k)) for k in coll.keys()),
            (r.L, r.R, r.T - F[16], r.T),
            confirm_fn,
        )
    def bu_fn_da_tar2(self):
        print(f"    dr_val  bu_fn_da_tar2")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return
        if len(variables[tx].targets) < 2:  return
        tar = variables[tx].targets[1]
        if tar.id_type in TAR_TYPES.dic_val_coll:
            coll = getattr(bpy.data, TAR_TYPES.dic_val_coll[tar.id_type])
        else:
            coll = {}

        def confirm_fn(name):
            try:
                print(f"    dr_val  bu_fn_da_tar2  confirm fn")
                tar.id = coll[name]  if name else None
                self.w.I_upd_data()
                m.redraw()
                m.undo_str = f'[Modifier Editor] DriverTarget.id = {tar.id.name}'
                m.undo_push()
            except:
                pass

        r = self.oo["da_tar2"].rim
        DDTX_FN(
            m.EVT.evt,
            self.oo["da_tar2"].da.text,
            FIL((NAME(k)) for k in coll.keys()),
            (r.L, r.R, r.T - F[16], r.T),
            confirm_fn,
        )
    def bu_fn_da_bone(self):
        print(f"    dr_val  bu_fn_da_bone")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return
        tar = variables[tx].targets[0]
        if not tar.id:  return
        if tar.id.type != 'ARMATURE':   return

        def confirm_fn(name):
            try:
                print(f"    dr_val  bu_fn_da_bone  confirm_fn")
                tar.bone_target = name
    
                self.w.I_upd_data()
                m.redraw()
                m.undo_str = f'[Modifier Editor] DriverTarget.bone_target = "{name}"'
                m.undo_push()
            except:
                pass

        r = self.oo["da_bone"].rim
        DDTX_FN(
            m.EVT.evt,
            self.oo["da_bone"].da.text,
            FIL(tar.id.pose.bones),
            (r.L, r.R, r.T - F[16], r.T),
            confirm_fn,
        )
    def bu_fn_da_bone2(self):
        print(f"    dr_val  bu_fn_da_bone2")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return
        targets = variables[tx].targets
        if len(targets) != 2: return
        tar = targets[1]
        if not tar.id:  return
        if tar.id.type != 'ARMATURE':   return

        def confirm_fn(name):
            try:
                print(f"    dr_val  bu_fn_da_bone2  confirm_fn")
                tar.bone_target = name
    
                self.w.I_upd_data()
                m.redraw()
                m.undo_str = f'[Modifier Editor] DriverTarget.bone_target = "{name}"'
                m.undo_push()
            except:
                pass

        r = self.oo["da_bone"].rim
        DDTX_FN(
            m.EVT.evt,
            self.oo["da_bone"].da.text,
            FIL(tar.id.pose.bones),
            (r.L, r.R, r.T - F[16], r.T),
            confirm_fn,
        )
    def bu_fn_del(self):
        print(f"    dr_val  bu_fn_del")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return

        try:
            variables.remove(variables[tx])
            self.w.I_upd_data()
            m.redraw()
            m.undo_str = f"[Modifier Editor] Driver.remove(variables['{tx}'])"
            m.undo_push()
        except:
            pass
    def bu_fn_del_tar(self):
        print(f"    dr_val  bu_fn_del_tar")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return

        try:
            variables[tx].targets[0].id = None
            self.w.I_upd_data()
            m.redraw()
            m.undo_str = "[Modifier Editor] DriverTarget.id = None"
            m.undo_push()
        except:
            pass
    def bu_fn_del_tar2(self):
        print(f"    dr_val  bu_fn_del_tar2")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
        tx = self.oo["da_name"].da.text
        variables = act_dr.driver.variables
        if tx not in variables: return
        if len(variables[tx].targets) < 2:  return

        try:
            variables[tx].targets[1].id = None
            self.w.I_upd_data()
            m.redraw()
            m.undo_str = "[Modifier Editor] DriverTarget.id = None"
            m.undo_push()
        except:
            pass
    def bu_fn_add(self):
        print(f"    dr_val  bu_fn_add")
        w = self.w
        w.I_upd_data()
        act_dr = w.act_dr
        if act_dr is None:  return
    def bu_fn_da_info(self):
        print(f"    dr_val  bu_fn_da_info")
        w   = self.w
        w.I_upd_data()
        act_dr  = w.act_dr
        if act_dr is None:  return
        if self.oo["da_info"].state != 0:   return

        top_win = DDTX_RENAME(
            m.EVT.evt,
            self.oo["da_info"].da.text,
            None,
            None,
            target          = "",
            full_path_head  = "",
            read_only       = True,
            tx_clear        = False
        )
        top_win.oo["copy"].disable()
        top_win.oo["copy_full"].disable()
        top_win.ti["target"].text = "INFO"

    def R_bu_fn_tar(self, buda, attr, TYPES, end_upd=0, tar_ind=0, tx_clear=True):
        def bu_fn_tar():
            print(f"    dr_val  R_bu_fn_tar  bu_fn_tar")
            w = self.w
            w.I_upd_data()
            act_dr = w.act_dr
            if act_dr is None:  return
            tx = self.oo["da_name"].da.text
            variables = act_dr.driver.variables
            if tx not in variables: return
            if len(variables[tx].targets) - 1 < tar_ind:    return
            tar = variables[tx].targets[tar_ind]

            def confirm_fn(name):
                try:
                    val = name  if TYPES is None else TYPES.dic_name_val[name]
                    if getattr(tar, attr) == val:   return
                    print(f"    dr_val  R_bu_fn_tar  bu_fn_tar  confirm_fn")
                    setattr(tar, attr, val)
                    if end_upd == 1:    self.w.I_upd_data()
                    elif end_upd == 2:  m.refresh()
                    m.redraw()
                    m.undo_str = f'[Modifier Editor] DriverTarget.{attr} = "{getattr(tar, attr)}"'
                    m.undo_push()
                except:
                    pass

            r = buda.rim
            DDTX_FN(
                m.EVT.evt,
                buda.da.text,
                None if TYPES is None else FIL(TYPES.enum_items),
                (r.L, r.R, r.T - F[16], r.T),
                confirm_fn,
                tx_clear = tx_clear
            )
        return bu_fn_tar

    def I_draw(self):
        bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        blf_size(font_0, F[22], 72)
        for e in self.oo_22:    e.draw_ti()
        blf_size(font_0, F[12], 72)
        for e in self.oo_12:    e.draw_ti()
        blf_size(font_0, F[9], 72)
        for e in self.oo_9:     e.draw_ti()
        for e in self.oo_free:  e.draw_ti()
        for e in self.oo_sci:   e.draw_ti()

    def upd_data(self):
        oo      = self.oo
        act_dr  = self.w.act_dr

        if act_dr is None:  self.kill_data()
        else:
            variables = act_dr.driver.variables
            if variables:
                if oo["bu_del"].is_enable is False: oo["bu_del"].enable()
                if oo["da_name"].da.text not in variables:
                    oo["da_name"].da.text = variables[0].name

                v       = variables[oo["da_name"].da.text]
                if v.is_name_valid:
                    info_tx = ""
                    info_red = False
                else:
                    info_tx = "Invalid variable name, "
                    info_red = True
                v_type  = v.type
                oo["da_type"].da.text = VAR_TYPES.dic_val_name[v_type]

                tar = v.targets[0]
                oo["da_tar_type"].da.text = TAR_TYPES.dic_val_name[tar.id_type]

                if tar.id is None:
                    oo["da_tar"].da.text = ""
                    if oo["bu_del_tar"].is_enable:  oo["bu_del_tar"].disable()
                else:
                    oo["da_tar"].da.text = tar.id.name
                    if oo["bu_del_tar"].is_enable is False:  oo["bu_del_tar"].enable()

                oo["da_bone"].da.text = tar.bone_target
                oo["da_dp"].da.text = tar.data_path
                oo["da_trantype"].da.text = TRANTYPE_TYPES.dic_val_name[tar.transform_type]
                oo["da_transpace"].da.text = TRANSPACE_TYPES.dic_val_name[tar.transform_space]
                oo["da_rot"].da.text = ROT_TYPES.dic_val_name[tar.rotation_mode]

                for k in {"da_name", "da_info",
                    "ti_type",
                    "da_type",
                    "ti_tar",
                    "da_tar",
                }:
                    if oo[k].state != 0:    oo[k].enable()

                if v_type == 'SINGLE_PROP':
                    if oo["ti_tar_type"].state != 0:    oo["ti_tar_type"].enable()
                    if oo["da_tar_type"].state != 0:    oo["da_tar_type"].enable()
                    if oo["ti_dp"].state != 0:          oo["ti_dp"].enable()
                    if oo["da_dp"].state != 0:          oo["da_dp"].enable()
                    if oo["ti_trantype"].state == 0:    oo["ti_trantype"].disable()
                    if oo["da_trantype"].state == 0:    oo["da_trantype"].disable()
                    if oo["ti_transpace"].state == 0:   oo["ti_transpace"].disable()
                    if oo["da_transpace"].state == 0:   oo["da_transpace"].disable()
                    if oo["ti_rot"].state == 0:         oo["ti_rot"].disable()
                    if oo["da_rot"].state == 0:         oo["da_rot"].disable()
                    if oo["ti_bone"].state == 0:        oo["ti_bone"].disable()
                    if oo["da_bone"].state == 0:        oo["da_bone"].disable()

                    if tar.id:
                        path = tar.data_path
                        if path:
                            if path[0] == "[":
                                if is_custom_path_valid(tar.id, path) is False:
                                    info_tx += "Invalid data path, "
                                    info_red = True
                            else:
                                if is_target_path_valid(tar.id, path) is False:
                                    info_tx += "Invalid data path, "
                                    info_red = True
                        else:
                            info_tx += "no data path, "
                            info_red = True
                    else:
                        info_tx += "no Target, "
                        info_red = True
                    if info_red is False:
                        info_tx += f'Value:  {R_path_value(tar.id, tar.data_path)}, '
                elif v_type == 'TRANSFORMS':
                    if oo["ti_tar_type"].state == 0:    oo["ti_tar_type"].disable()
                    if oo["da_tar_type"].state == 0:    oo["da_tar_type"].disable()
                    if oo["ti_dp"].state == 0:          oo["ti_dp"].disable()
                    if oo["da_dp"].state == 0:          oo["da_dp"].disable()
                    if oo["ti_trantype"].state != 0:    oo["ti_trantype"].enable()
                    if oo["da_trantype"].state != 0:    oo["da_trantype"].enable()
                    if oo["ti_transpace"].state != 0:   oo["ti_transpace"].enable()
                    if oo["da_transpace"].state != 0:   oo["da_transpace"].enable()
                    if tar.transform_type in {'ROT_X', 'ROT_Y', 'ROT_Z', 'ROT_W'}:
                        if oo["ti_rot"].state != 0:         oo["ti_rot"].enable()
                        if oo["da_rot"].state != 0:         oo["da_rot"].enable()
                    else:
                        if oo["ti_rot"].state == 0:         oo["ti_rot"].disable()
                        if oo["da_rot"].state == 0:         oo["da_rot"].disable()

                    if tar.id:
                        if tar.id.type == 'ARMATURE':
                            if oo["ti_bone"].state != 0:    oo["ti_bone"].enable()
                            if oo["da_bone"].state != 0:    oo["da_bone"].enable()
                        else:
                            if oo["ti_bone"].state == 0:    oo["ti_bone"].disable()
                            if oo["da_bone"].state == 0:    oo["da_bone"].disable()
                    else:
                        if oo["ti_bone"].state == 0:    oo["ti_bone"].disable()
                        if oo["da_bone"].state == 0:    oo["da_bone"].disable()
                        info_tx += "no Target, "
                        info_red = True
                    if info_red is False:
                        info_tx += f'Value:  {R_driver_variable_value_TRANSFORMS(tar)}, '
                elif v_type == 'ROTATION_DIFF':
                    if oo["ti_tar_type"].state == 0:    oo["ti_tar_type"].disable()
                    if oo["da_tar_type"].state == 0:    oo["da_tar_type"].disable()
                    if oo["ti_dp"].state == 0:          oo["ti_dp"].disable()
                    if oo["da_dp"].state == 0:          oo["da_dp"].disable()
                    if oo["ti_trantype"].state == 0:    oo["ti_trantype"].disable()
                    if oo["da_trantype"].state == 0:    oo["da_trantype"].disable()
                    if oo["ti_transpace"].state == 0:   oo["ti_transpace"].disable()
                    if oo["da_transpace"].state == 0:   oo["da_transpace"].disable()
                    if oo["ti_rot"].state == 0:         oo["ti_rot"].disable()
                    if oo["da_rot"].state == 0:         oo["da_rot"].disable()

                    if tar.id:
                        if tar.id.type == 'ARMATURE':
                            if oo["ti_bone"].state != 0:    oo["ti_bone"].enable()
                            if oo["da_bone"].state != 0:    oo["da_bone"].enable()
                        else:
                            if oo["ti_bone"].state == 0:    oo["ti_bone"].disable()
                            if oo["da_bone"].state == 0:    oo["da_bone"].disable()
                    else:
                        if oo["ti_bone"].state == 0:    oo["ti_bone"].disable()
                        if oo["da_bone"].state == 0:    oo["da_bone"].disable()
                        info_tx += "no Target, "
                        info_red = True
                    tar1 = v.targets[1]
                    if tar1.id: pass
                    else:
                        info_tx += "no Target 2, "
                        info_red = True
                    if info_red is False:
                        info_tx += f'Value:  {R_driver_variable_value_ROTATION_DIFF(tar, tar1)}, '
                else:
                    if oo["ti_tar_type"].state == 0:    oo["ti_tar_type"].disable()
                    if oo["da_tar_type"].state == 0:    oo["da_tar_type"].disable()
                    if oo["ti_dp"].state == 0:          oo["ti_dp"].disable()
                    if oo["da_dp"].state == 0:          oo["da_dp"].disable()
                    if oo["ti_trantype"].state == 0:    oo["ti_trantype"].disable()
                    if oo["da_trantype"].state == 0:    oo["da_trantype"].disable()
                    if oo["ti_transpace"].state != 0:   oo["ti_transpace"].enable()
                    if oo["da_transpace"].state != 0:   oo["da_transpace"].enable()
                    if oo["ti_rot"].state == 0:         oo["ti_rot"].disable()
                    if oo["da_rot"].state == 0:         oo["da_rot"].disable()

                    if tar.id:
                        if tar.id.type == 'ARMATURE':
                            if oo["ti_bone"].state != 0:    oo["ti_bone"].enable()
                            if oo["da_bone"].state != 0:    oo["da_bone"].enable()
                        else:
                            if oo["ti_bone"].state == 0:    oo["ti_bone"].disable()
                            if oo["da_bone"].state == 0:    oo["da_bone"].disable()
                    else:
                        if oo["ti_bone"].state == 0:    oo["ti_bone"].disable()
                        if oo["da_bone"].state == 0:    oo["da_bone"].disable()
                        info_tx += "no Target, "
                        info_red = True
                    tar1 = v.targets[1]
                    if tar1.id: pass
                    else:
                        info_tx += "no Target 2, "
                        info_red = True
                    if info_red is False:
                        info_tx += f'Value:  {R_driver_variable_value_LOC_DIFF(tar, tar1)}, '

                if len(v.targets) == 2:
                    tar = v.targets[1]
                    if tar.id is None:
                        oo["da_tar2"].da.text = ""
                        if oo["bu_del_tar2"].is_enable: oo["bu_del_tar2"].disable()
                        if oo["ti_bone2"].state == 0:   oo["ti_bone2"].disable()
                        if oo["da_bone2"].state == 0:   oo["da_bone2"].disable()
                    else:
                        oo["da_tar2"].da.text = tar.id.name
                        if oo["bu_del_tar2"].is_enable is False:  oo["bu_del_tar"].enable()
                        if tar.id.type == 'ARMATURE':
                            if oo["ti_bone2"].state != 0:   oo["ti_bone2"].enable()
                            if oo["da_bone2"].state != 0:   oo["da_bone2"].enable()
                        else:
                            if oo["ti_bone2"].state == 0:   oo["ti_bone2"].disable()
                            if oo["da_bone2"].state == 0:   oo["da_bone2"].disable()
                    oo["da_bone2"].da.text = tar.bone_target
                    oo["da_transpace2"].da.text = TRANSPACE_TYPES.dic_val_name[tar.transform_space]

                    if oo["ti_tar2"].state != 0:        oo["ti_tar2"].enable()
                    if oo["da_tar2"].state != 0:        oo["da_tar2"].enable()
                    if v_type == 'ROTATION_DIFF':
                        if oo["ti_transpace2"].state == 0:  oo["ti_transpace2"].disable()
                        if oo["da_transpace2"].state == 0:  oo["da_transpace2"].disable()
                    else:
                        if oo["ti_transpace2"].state != 0:  oo["ti_transpace2"].enable()
                        if oo["da_transpace2"].state != 0:  oo["da_transpace2"].enable()
                else:
                    oo["da_tar2"].da.text = ""
                    oo["da_bone2"].da.text = ""
                    oo["da_transpace2"].da.text = ""
                    if oo["bu_del_tar2"].is_enable:  oo["bu_del_tar2"].disable()

                    if oo["ti_tar2"].state == 0:        oo["ti_tar2"].disable()
                    if oo["da_tar2"].state == 0:        oo["da_tar2"].disable()
                    if oo["ti_transpace2"].state == 0:  oo["ti_transpace2"].disable()
                    if oo["da_transpace2"].state == 0:  oo["da_transpace2"].disable()
                    if oo["ti_bone2"].state == 0:       oo["ti_bone2"].disable()
                    if oo["da_bone2"].state == 0:       oo["da_bone2"].disable()

                if act_dr in bpy.data.link_mds:
                    info_red = False
                    info_tx = "Reference Driver : "
                    tar_oj = tar.id
                    if tar_oj is None:
                        info_tx += "no Target, "
                        info_red = True
                    else:
                        if tar_oj.modifiers:
                            if v.name in tar_oj.modifiers:
                                pass
                            else:
                                info_tx += "Variable name and Target modifier must match, "
                                info_red = True
                        else:
                            info_tx += "Target object no modifier, "
                            info_red = True

                oo["da_info"].da.text = info_tx[:-2]
                oo["da_info"].da.color = P.color_font_red  if info_red else P.color_font
            else:
                self.kill_data()

        self.glopan_end()
    def kill_data(self):
        oo = self.oo
        for k in {
            "da_name",
            "da_info",
            "da_type",
            "da_tar_type",
            "da_tar",
            "da_dp",
            "da_trantype",
            "da_transpace",
            "da_rot",
            "da_tar2",
            "da_transpace2",
            "da_bone",
            "da_bone2",
        }: oo[k].da.text = ""

        for k in {"bu_del", "bu_del_tar", "bu_del_tar2"}:
            if oo[k].is_enable:     oo[k].disable()
        for k in {
            "da_name",
            "da_info",
            "ti_type",
            "da_type",
            "ti_tar_type",
            "da_tar_type",
            "ti_tar",
            "da_tar",
            "ti_dp",
            "da_dp",
            "ti_trantype",
            "da_trantype",
            "ti_transpace",
            "da_transpace",
            "ti_rot",
            "da_rot",
            "ti_tar2",
            "da_tar2",
            "ti_transpace2",
            "da_transpace2",
            "ti_bone",
            "da_bone",
            "ti_bone2",
            "da_bone2",
        }:
            if oo[k].state == 0:    oo[k].disable()
