import bpy
from blf import size as blf_size
from blf import color as blf_color
from math import degrees as math_deg
from math import radians as math_rad

from . menu_batch import MESS_BATCH_KF, MESS_BATCH_DR, MESS_BATCH_VAL

from .. import m
from .. rm import RM
from .. dd import DDTX, DDVAL
from .. fn import bin_search, TR_ind, TR_ind_ex, R_str_by_deg
from .. link_data import MOD_ATTR, R_md_driver_add, R_md_driver_remove
from .. calc import calc_vec

P = None
F = None
K = None
N = None
BOX = None
BLF = None
RECT = None
font_0 = None

def TR_fc_by_path(oj, path):
    try:    return oj.animation_data.action.fcurves.find(path)
    except: return None
def TR_dr_by_path(oj, path):
    try:    return oj.animation_data.drivers.find(path)
    except: return None


class BU:
    __slots__ = (
        'w',
        'name',
        'fn',
        'rim',
        'bg',
        'ti',
        'on',
        'off',
        'fo',
        'unfo',
        'draw_ti',
        'offset_y_key',
        'is_enable',
        'offset_x',
        'offset_y',
        'attr',
        'value',
        'color_bg',
    )
    def __init__(self, w, name, ti,
        fn              = None,
        offset_y_key    = 4.5,
        free_size       = False,
        attr            = None,
        value           = None,
        ):
        self.color_bg   = P.color_bu_1_off

        self.w      = w
        self.name   = name
        self.fn     = self.setter  if fn is None else fn
        self.attr   = attr
        self.value  = value
        self.rim    = BOX()
        self.bg     = BOX(self.color_bg)
        self.ti     = BLF(P.color_font, ti)

        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.unfo       = self.I_off
        self.draw_ti    = self.I_draw_ti_free  if free_size else self.I_draw_ti

        self.offset_y_key   = offset_y_key
        self.is_enable      = True

    def disable(self): #soft
        print(f"    bu_md  BU disable")
        self.color_bg   = P.color_bu_1_ignore
        if self.bg.color == P.color_bu_1_off:     self.bg.color = self.color_bg
        self.ti.color   = P.color_font_ignore
        self.is_enable  = False
        m.redraw()
    def enable(self):
        print(f"    bu_md  BU enable")
        self.color_bg   = P.color_bu_1_off
        if self.bg.color == P.color_bu_1_ignore:  self.bg.color = self.color_bg
        self.ti.color   = P.color_font
        self.is_enable  = True
        m.redraw()

    def LTwh(self, L, T, w, h): # must blf_size
        rim = self.rim
        bg  = self.bg
        ti  = self.ti

        rim.LTwh(L, T, w, h)
        rim.upd()

        if bg.color == P.color_bu_1_on:
            bg.LRBT(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        else:
            bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])

        bg.upd()
        ti.set_x_by_bo_float(bg)
        self.offset_x   = ti.x - bg.L
        self.offset_y   = F[self.offset_y_key]
        ti.y            = bg.B + self.offset_y
    def LRBT(self, L, R, B, T):
        rim = self.rim
        bg  = self.bg
        ti  = self.ti
        _1  = F[1]

        rim.LRBT(L, R, B, T)
        rim.upd()

        if bg.color == P.color_bu_1_on:
            bg.LRBT(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        else:
            bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])

        bg.upd()
        ti.set_x_by_bo_float(bg)
        self.offset_x   = ti.x - bg.L
        self.offset_y   = F[self.offset_y_key]
        ti.y            = bg.B + self.offset_y

    def next_bu(self, b, wi):
        rim = b.rim
        L = rim.R + F[2]
        self.LRBT(L, L + wi, rim.B, rim.T)
    def before_bu(self, b, wi):
        rim = b.rim
        R = rim.L - F[2]
        self.LRBT(R - wi, R, rim.B, rim.T)
    def below_bu(self, b, h):
        rim = b.rim
        T = rim.B - F[2]
        self.LRBT(rim.L, rim.R, T - h, T)

    def ti_align_L(self, e):
        self.offset_x = e.offset_x
        self.ti.x = self.bg.L + self.offset_x
    def ti_offset_x_set(self, x):
        self.offset_x = x
        self.ti.x = self.bg.L + self.offset_x

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bg.dxy_upd(x, y)
        self.ti.dxy(x, y)

    def setter(self):
        setattr(self.w.w.act_md, self.attr, self.value)
        m.undo_str = f'[Modifier Editor] md.{self.attr} = "{self.value}"'

    def I_on(self):
        rim = self.rim
        bg  = self.bg

        bg.color = P.color_bu_1_on
        bg.LRBT(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)

        self.on     = N
        self.off    = self.I_off
        self.fo     = N
        self.unfo   = self.I_on
    def I_off(self):
        rim = self.rim
        bg  = self.bg

        bg.color = self.color_bg
        bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = self.I_on
        self.off    = N
        self.fo     = self.I_fo
        self.unfo   = self.I_off
    def I_fo(self):
        rim = self.rim
        bg  = self.bg

        bg.color = P.color_bu_1_fo
        bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = self.I_on
        self.off    = self.I_off
        self.fo     = N

    def draw_rim(self):         self.rim.draw()
    def draw_bg(self):          self.bg.bind_draw()
    def I_draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()
    def I_draw_ti_free(self):
        self.ti.set_draw()

    def inside(self, evt):
        self.fo()
        self.w.U_modal = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.unfo()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return

        if K["batch0"].true() or K["batch1"].true():
            self.batch_init(evt)
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            if self.on is N:  return
            self.w.RET = True
            self.I_on()
            self.fn()
            m.undo_push()
            return True
        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True

    def rm_init(self, evt):
        self.w.oo_dr[self.attr].rm_init(evt, override={
            "title": self.ti.text
        })
    def batch_init(self, evt):
        self.w.oo_dr[self.attr].fn_Value_Batch()


class BUBL:
    __slots__ = (
        'w',
        'name',
        'attr',
        'da_color',
        'da_color_ignore',
        'offset_x_key',
        'offset_y_key',
        'rim',
        'da',
        'on',
        'off',
        'fo',
        'enable',
        'disable',
        'inside',
        'is_enable',
        'offset_x',
        'offset_y',
        'U_fn',
        'free_fn',
    )
    def __init__(self, w, name, attr, offset_x_key = 1.5, offset_y_key = 0, fn=None):
        self.w      = w
        self.name   = name
        self.attr   = attr

        self.da_color           = P.color_bu_2
        self.da_color_ignore    = P.color_bu_2_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.free_fn    = fn

    def LTwh(self, L, T, w, h):
        rim = self.rim
        rim.LTwh(L, T, w, h)
        rim.upd()
        self.offset_x   = F[self.offset_x_key]
        self.offset_y   = F[self.offset_y_key]
        self.da.LB(self.rim, self.offset_x, self.offset_y)
    def LRBT(self, L, R, B, T):
        rim = self.rim
        rim.LRBT(L, R, B, T)
        rim.upd()
        self.offset_x   = F[self.offset_x_key]
        self.offset_y   = F[self.offset_y_key]
        self.da.LB(rim, self.offset_x, self.offset_y)

    def right_dr(self, dr, w, d = 10):
        L = dr.rim.R + F[d] - F[4]
        self.LRBT(L, L + w, dr.rim.B, dr.rim.T)

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)

    def I_on(self):
        self.rim.color  = P.color_bu_3_on
        self.on         = N
        self.off        = self.I_off
        self.fo         = self.I_fo
    def I_off(self):
        self.rim.color  = P.color_bu_3_off
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
    def I_fo(self):
        self.rim.color  = P.color_bu_3_fo
        self.on         = self.I_on
        self.off        = self.I_off
        self.fo         = N

    def I_enable(self):
        self.is_enable  = True
        self.inside     = self.I_inside
        self.da.color   = self.da_color
        self.I_off()
        self.enable     = N
        self.disable    = self.I_disable
    def I_disable(self, soft=True):
        mN = N
        self.is_enable  = False
        if soft is False:   self.inside = mN
        self.rim.color  = P.color_bu_3_ignore
        self.da.color   = self.da_color_ignore
        self.enable     = self.I_enable
        self.disable    = mN
        self.on         = mN
        self.off        = mN
        self.fo         = mN

    def draw_rim(self): pass
    def draw_bg(self):  self.rim.bind_draw()
    def draw_ti(self):  self.da.set_color()  ;self.da.draw_pos()

    def set_da(self, boo):
        if self.da.name != boo:
            self.da.name = boo
            self.da.text = "■"  if boo else ""

    def fn(self):
        self.U_fn   = N
        if self.free_fn is not None:    self.free_fn() ;return

        act_md      = self.w.w.act_md

        if getattr(act_md, self.attr):
            self.da.text = ""
            self.da.name = False
            setattr(act_md, self.attr, False)
            m.undo_str = f'[Modifier Editor] md.{self.attr} = False'
        else:
            self.da.text = "■"
            self.da.name = True
            setattr(act_md, self.attr, True)
            m.undo_str = f'[Modifier Editor] md.{self.attr} = True'
        m.undo_push()

    def I_inside(self, evt):
        self.fo()
        self.U_fn       = self.fn
        self.w.U_modal  = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return

        if evt.value == 'RELEASE':  self.U_fn = self.fn
        if K["batch0"].true() or K["batch1"].true():
            self.batch_init(evt)
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.w.RET = True
            self.U_fn()
            return True
        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True

    def rm_init(self, evt):
        print(f"    bu_md  BU  rm_init")
        self.w.oo_dr[self.attr].rm_init(evt)
    def batch_init(self, evt):
        self.w.oo_dr[self.attr].fn_Value_Batch()
class BUTX(BUBL):
    __slots__ = (
        'fil',
        'is_str',
        'update_filter',
    )
    def __init__(self, w, name, attr, fil,
            offset_x_key    = 5.1,
            offset_y_key    = 5.1,
            is_str          = False,
            update_filter   = None,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.fil    = fil

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key
        self.is_str             = is_str
        self.update_filter      = update_filter

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True

    def set_da(self, s):
        if self.da.name != s:
            blf_size(font_0, F[9], 72)
            self.da.name = self.da.text = s
            self.da.fix_long_text(self.rim.R - F[12], F[8])
    def setter(self):
        attr = getattr(self.w.w.act_md, self.attr)
        if self.is_str: self.set_da(attr) ;return

        if attr == None:    self.set_da("")
        else:               self.set_da(attr.name)
    def bpy_setter(self, s):
        try:
            if self.is_str:
                setattr(self.w.w.act_md, self.attr, s)
                m.undo_str = f'[Modifier Editor] md.{self.attr} = "{s}"'
                m.undo_push()
                return

            if s == "":
                setattr(self.w.w.act_md, self.attr, None)
                m.undo_str = f'[Modifier Editor] md.{self.attr} = None'
            else:
                tar = self.fil.bpy_type[s]
                setattr(self.w.w.act_md, self.attr, tar)
                m.undo_str = f'[Modifier Editor] md.{self.attr} ▶ {getattr(tar, "name", tar)}'
            m.undo_push()
        except: pass

    def fn(self):
        if self.update_filter is not None:
            if isinstance(self.update_filter, str):
                self.fil.bpy_type = getattr(self.w.w.oj, self.update_filter)
            else:
                print("TODO")
                pass
                return

        DDTX(self, self.fil)
    def fn_copy(self):
        print(f"    bu_md  fn_copy")
        bpy.context.window_manager.clipboard = f"{self.da.name}"
    def fn_paste(self):
        print(f"    bu_md  fn_paste")
        self.bpy_setter(bpy.context.window_manager.clipboard)
    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return

        if evt.value == 'RELEASE':  self.U_fn = self.fn
        if K["batch0"].true() or K["batch1"].true():
            self.batch_init(evt)
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.w.RET = True
            self.U_fn()
            return True
        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.fn_paste()
            return True
    def R_bu_dr(self, evt):
        oo_dr = self.w.oo_dr
        if self.attr in oo_dr:
            bu_dr = oo_dr[self.attr]
        else:
            bu_dr = BUDR(self.w, "", f"{self.attr}".title(), self.attr, is_ref_driver=True)
            x = evt.mouse_region_x
            y = evt.mouse_region_y
            bu_dr.rim.LRBT(x, x, y, y)
            if f"bu_{self.attr}" in self.w.oo:
                bu_dr.ti.color = self.w.oo[f"bu_{self.attr}"].ti.color
        return bu_dr
    def rm_init(self, evt):
        print(f"    bu_md  BUTX  rm_init")
        self.R_bu_dr(evt).rm_init(evt)
    def batch_init(self, evt):
        self.R_bu_dr(evt).fn_Driver_Batch()
class BUFL(BUBL):
    __slots__ = (
        'ty',
        'tx_format',
        'bpy_setter',
        'key_end',
        'key_slow',
        'key_fast',
        'R_qe_dx',
        'qe_value',
        'qe_org',
        'qe_unit',
        'qe_unit_slow',
        'qe_unit_fast',
        'qe_fn',
        'unit',
    )
    def __init__(self,
            w,
            name,
            attr,
            offset_x_key    = 5.1,
            offset_y_key    = 4.9,
            ty              = "float [-∞,∞]"
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.ty     = ty

        if ty[0:3] == 'int':
            self.bpy_setter     = self.I_bpy_setter_int
            self.tx_format      = R_str_by_deg  if self.__class__ == BUFD else m.U_format_i
            self.unit = 0
        else:
            if self.__class__ == BUFD:
                self.tx_format = R_str_by_deg
                self.unit = 0
            else:
                u = w.props[attr].unit
                if u == "LENGTH":
                    self.tx_format = m.U_FORMAT_F
                    self.unit = 1
                elif u == "AREA":
                    self.tx_format = m.U_FORMAT_F2
                    self.unit = 2
                elif u == "VOLUME":
                    self.tx_format = m.U_FORMAT_F3
                    self.unit = 3
                else:
                    self.tx_format = m.U_format_f
                    self.unit = 0

            self.bpy_setter     = self.I_bpy_setter

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True

    def R_unit_fac(self):
        u = self.unit
        if u == 0:      return 1.0
        if u == 1:      return m.unit_length_fac
        elif u == 2:    return m.unit_length_fac2
        elif u == 3:    return m.unit_length_fac3
        return 1.0
    def set_da(self, flo):
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def setter(self):
        flo = getattr(self.w.w.act_md, self.attr)
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def I_bpy_setter(self, flo):
        setattr(self.w.w.act_md, self.attr, flo)
        m.undo_str = f'[Modifier Editor] md.{self.attr} = {flo}'
        m.undo_push()
    def I_bpy_setter_int(self, flo):
        v = round(flo)
        setattr(self.w.w.act_md, self.attr, v)
        m.undo_str = f'[Modifier Editor] md.{self.attr} = {v}'
        m.undo_push()

    def fn(self):   DDVAL(self, self.ty)
    def fn_copy(self):
        try:
            print(f"    bu_md  fn_copy")
            v = self.da.name
            fac = self.R_unit_fac()
            if fac != 1.0:  v /= fac
            bpy.context.window_manager.clipboard = m.R_str_by_float(v) if isinstance(v, float) else f"{v}"
        except: pass
    def fn_paste(self):
        try:
            print(f"    bu_md  fn_paste")
            vv = calc_vec(bpy.context.window_manager.clipboard)
            v = vv[0]
            fac = self.R_unit_fac()
            if fac != 1.0:  v *= fac
            self.bpy_setter(v)
        except: pass
    def fn_cut(self):
        self.fn_copy()
    def R_dp(self):
        return f'modifiers["{self.w.w.act_md.name}"].{self.attr}'
    def driver_add(self, exp = ""):
        dp = self.R_dp()
        oj = self.w.w.oj
        print(f"    bu_md  driver_add:  {oj.name}")
        dr = oj.animation_data.drivers.find(dp)  if oj.animation_data else None
        if dr is None:  dr = oj.driver_add(dp)
        else:           dr.driver.type = 'SCRIPTED'
        dr.driver.expression = exp
        P.refresh = True
        m.undo_str = f'[Modifier Editor] driver.expression = {exp}'
        m.undo_push()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return

        if K["batch0"].true() or K["batch1"].true():
            self.batch_init(evt)
            return True
        if K["bu_qe0"].true():
            print("    bu_md  I_modal_fo  -> I_modal_qe")
            self.key_end = K["bu_qe_E0"]
            self.to_modal_qe(evt)
            return True
        if K["bu_qe1"].true():
            print("    bu_md  I_modal_fo  -> I_modal_qe")
            self.key_end = K["bu_qe_E1"]
            self.to_modal_qe(evt)
            return True
        if K["bu_sel0"].true() or K["bu_sel1"].true():
            self.w.RET = True
            self.fn()
            return True
        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            self.fn_cut()
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            try:
                self.w.oo_dr[self.attr].fn_Reset_to_Default_Value()
                print("    reset success")
            except:
                print("    reset fail")
            return True
    def rm_init(self, evt):
        print(f"    bu_md  BUFL  rm_init")
        self.w.oo_dr[self.attr].rm_init(evt)

    def is_alt(self, evt):    return evt.alt
    def is_ctrl(self, evt):   return evt.ctrl
    def is_shift(self, evt):  return evt.shift
    def is_oskey(self, evt):  return evt.oskey
    def NF(self, evt):        return False
    def IR_dx(self):    return m.dx
    def IR_dy(self):    return m.dy
    def to_modal_qe(self, evt):
        print("    bu_md  to_modal_qe")
        self.w.RET = True
        self.key_end.true()
        m.head_modal.append(self.I_modal_qe)
        m.upd_disable()

        r = m.region_data
        m.get_loop_mou_info_region(evt, r.L, r.R, r.B, r.T)
        m.get_mou(evt)
        tm = m.tm
        tm["x"] = evt.mouse_x
        tm["y"] = evt.mouse_y
        try:    m.M.set_mou_ic(P.quick_edit_cursor)
        except: pass

        self.R_qe_dx = self.IR_dx if P.quick_edit_method == 'HORIZONTAL' else self.IR_dy
        dic = m.dic_hold_key
        slow0 = K["bu_qe_slow0"].type0
        self.key_slow = getattr(self, f"is_{dic[slow0]}") if slow0 in dic else self.NF
        fast0 = K["bu_qe_fast0"].type0
        self.key_fast = getattr(self, f"is_{dic[fast0]}") if fast0 in dic else self.NF

        if P.quick_edit_operation == 'REAL_TIME':
            if self.bpy_setter == self.I_bpy_setter:
                self.qe_fn = self.I_qe_real_time_float
            else:
                self.qe_fn = self.I_qe_real_time_int
        else:
            if self.bpy_setter == self.I_bpy_setter:
                self.qe_fn = self.I_qe_performance_float
            else:
                self.qe_fn = self.I_qe_performance_int

        self.qe_value   = self.da.name
        self.qe_org     = self.qe_value
        self.qe_unit = getattr(P, f'{m.R_calc_attr(self.ty)}qe')
        self.qe_unit_slow = P.quick_edit_fac_slow * self.qe_unit
        self.qe_unit_fast = P.quick_edit_fac_fast * self.qe_unit
    def modal_qe_end(self, cancel=False):
        print(f"    bu_md  modal_qe_end:  cancel={cancel}")
        del m.head_modal[-1]
        m.EVT.kill()
        m.I_end_pan_hide(self)

        if cancel:
            self.da.name = None
            m.upd_enable()
            setattr(self.w.w.act_md, self.attr, self.qe_org)
            return

        if P.quick_edit_operation != 'REAL_TIME':
            if self.bpy_setter == self.I_bpy_setter:
                setattr(self.w.w.act_md, self.attr, self.qe_value)
            else:
                setattr(self.w.w.act_md, self.attr, round(self.qe_value))

        m.undo_str = f'[Modifier Editor] md.{self.attr} = {getattr(self.w.w.act_md, self.attr)}'
        m.undo_push()
        self.da.name = None
        m.upd_enable()
        m.refresh()
    def I_modal_qe(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_qe_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_qe_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_qe_end()
                return

        m.I_pan(evt)
        if self.key_slow(evt):      self.qe_fn(self.R_qe_dx() * self.qe_unit_slow)
        elif self.key_fast(evt):    self.qe_fn(self.R_qe_dx() * self.qe_unit_fast)
        else:                       self.qe_fn(self.R_qe_dx() * self.qe_unit)
        m.loop_mou(evt)
    def I_qe_performance_float(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_performance_int(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(round(self.qe_value))
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        setattr(self.w.w.act_md, self.attr, self.qe_value)
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_real_time_int(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        setattr(self.w.w.act_md, self.attr, v)
        self.da.text = self.tx_format(v)
class BUFD(BUFL):
    __slots__ = ()
    def set_da(self, flo):
        if self.da.name != flo:
            deg = math_deg(flo)
            self.da.name = deg
            self.da.text = self.tx_format(deg)
    def I_bpy_setter(self, flo):
        flo = math_rad(flo)
        setattr(self.w.w.act_md, self.attr, flo)
        m.undo_str = f'[Modifier Editor] md.{self.attr} = {flo}'
        m.undo_push()

    def I_qe_performance_float(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_performance_int(self, dx):
        pass
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        setattr(self.w.w.act_md, self.attr, math_rad(self.qe_value))
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_real_time_int(self, dx):
        pass


class BUKF:
    __slots__ = (
        'w',
        'name',
        'attr',
        'rim',
        'ti',
        'U_set_last',
        'U_set_no_kf',
        'U_set_kf_fit',
        'U_set_kf_unfit',
        'U_set_nokf_fit',
        'U_set_nokf_unfit',
        'draw_ti',
        'upd_ti',
        'enum',
        'color_fo',
        'fc_event',
    )
    def __init__(self, w, name, attr, type_attr = True):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, "•")

        self.U_set_last         = self.IU_set_no_kf
        self.U_set_no_kf        = N
        self.U_set_kf_fit       = self.I_set_kf_fit
        self.U_set_kf_unfit     = self.I_set_kf_unfit
        self.U_set_nokf_fit     = self.I_set_nokf_fit
        self.U_set_nokf_unfit   = self.I_set_nokf_unfit
        self.draw_ti            = self.I_draw_ti

        w.oo_kf[attr] = self

        if type_attr is True:       self.upd_ti = self.upd_fc
        elif type_attr is False:    self.upd_ti = self.upd_fc_bool
        else:
            self.upd_ti = self.upd_fc_enum
            self.enum   = type_attr

    def above_L(self, e):
        rim = e.rim
        self.ti.xy(rim.L, rim.T + F[7.8])
        self.rim.LRBT(rim.L - F[5], rim.L + F[11], rim.T, rim.T + F[17])
    def above_L_with_dr(self, e, dr): #blf_size
        self.above_L(e)
        dr.next_kf(self)

    def LBT(self, L, B, T):
        self.ti.xy(L, B + F[5.1])
        self.rim.LRBT(L - F[5], L + F[11], B, T)
    def LBT_with_dr(self, L, B, T, dr):
        self.ti.xy(L, B + F[5.1])
        self.rim.LRBT(L - F[5], L + F[11], B, T)
        dr.next_kf(self)

    def dxy_upd(self, x, y):
        self.rim.dxy(x, y)
        self.ti.dxy(x, y)

    def draw_rim(self): pass
    def draw_bg(self):  pass
    def I_draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()
    def I_draw_ti_fo(self):
        blf_color(font_0, *self.color_fo)
        self.ti.draw_pos()

    def IU_set_no_kf(self):     self.U_set_no_kf = self.I_set_no_kf
    def IU_set_kf_fit(self):    self.U_set_kf_fit = self.I_set_kf_fit
    def IU_set_kf_unfit(self):  self.U_set_kf_unfit = self.I_set_kf_unfit
    def IU_set_nokf_fit(self):  self.U_set_nokf_fit = self.I_set_nokf_fit
    def IU_set_nokf_unfit(self):self.U_set_nokf_unfit = self.I_set_nokf_unfit

    def I_set_no_kf(self):
        print(f"    bu_md  I_set_no_kf")
        self.U_set_last()
        self.U_set_no_kf    = N
        self.U_set_last     = self.IU_set_no_kf
        self.ti.color_tx(P.color_font, "•")
    def I_set_kf_fit(self):
        print(f"    bu_md  I_set_kf_fit")
        self.U_set_last()
        self.U_set_kf_fit   = N
        self.U_set_last     = self.IU_set_kf_fit
        self.ti.color_tx(P.color_bu_kf_yellow, "◆")
    def I_set_kf_unfit(self):
        print(f"    bu_md  I_set_kf_unfit")
        self.U_set_last()
        self.U_set_kf_unfit = N
        self.U_set_last     = self.IU_set_kf_unfit
        self.ti.color_tx(P.color_bu_kf_orange, "◆")
    def I_set_nokf_fit(self):
        print(f"    bu_md  I_set_nokf_fit")
        self.U_set_last()
        self.U_set_nokf_fit = N
        self.U_set_last     = self.IU_set_nokf_fit
        self.ti.color_tx(P.color_bu_kf_green, "◇")
    def I_set_nokf_unfit(self):
        print(f"    bu_md  I_set_nokf_unfit")
        self.U_set_last()
        self.U_set_nokf_unfit   = N
        self.U_set_last         = self.IU_set_nokf_unfit
        self.ti.color_tx(P.color_bu_kf_orange, "◇")
    def upd_fc(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}')
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if fc.evaluate(r) == getattr(act_md, self.attr): self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if fc.evaluate(r) == getattr(act_md, self.attr): self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_enum(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}')
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if TR_ind_ex(self.enum, round(fc.evaluate(r))) == getattr(act_md, self.attr):
                            self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if TR_ind_ex(self.enum, round(fc.evaluate(r))) == getattr(act_md, self.attr):
                            self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_bool(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}')
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if TR_ind((False, True), round(fc.evaluate(r))) == getattr(act_md, self.attr):
                            self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if TR_ind((False, True), round(fc.evaluate(r))) == getattr(act_md, self.attr):
                            self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()

    def get_color_fo(self):
        if self.ti.color == P.color_font:           self.color_fo = P.color_bu_kf_fo
        elif self.ti.color == P.color_bu_kf_yellow:  self.color_fo = P.color_bu_kf_yellow_fo
        elif self.ti.color == P.color_bu_kf_green:   self.color_fo = P.color_bu_kf_green_fo
        else:   self.color_fo = P.color_bu_kf_orange_fo
    def inside(self, evt):
        self.get_color_fo()
        self.draw_ti = self.I_draw_ti_fo
        self.fc_event = self.I_fc_event

        self.w.U_modal = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.draw_ti = self.I_draw_ti
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return

        if evt.value == 'RELEASE':  self.fc_event = self.I_fc_event
        if K["batch0"].true() or K["batch1"].true():
            self.batch_init(evt)
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.w.RET = True
            self.fc_event()
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.rm_init(evt)
            return True
    def rm_init(self, evt):
        print(f"    bu_md  BUKF  rm_init")
        if self.attr is None:   return
        self.w.oo_dr[self.attr].rm_init(evt)
    def batch_init(self, evt):
        print(f"    bu_md  BUKF  batch_init")
        if self.attr is None:   return
        self.w.oo_dr[self.attr].batch_init(evt, 1 if self.ti.text == "◆" else 0)

    def I_fc_event(self, require=None):
        print(f"    bu_md  I_fc_event")
        self.fc_event = N
        oj          = self.w.w.oj
        an_data     = oj.animation_data
        act_md      = self.w.w.act_md
        self.upd_ti(an_data, act_md)
        path = f'modifiers["{act_md.name}"].{self.attr}'
        if require is None:
            if self.ti.text == "◆":
                self.w.w.oj.keyframe_delete(path)
                m.undo_str = f"[Modifier Editor] keyframe_delete('{path}')"
            else:
                self.w.w.oj.keyframe_insert(path)
                m.undo_str = f"[Modifier Editor] keyframe_insert('{path}')"
        elif require == "INSERT":
            self.w.w.oj.keyframe_insert(path)
            m.undo_str = f"[Modifier Editor] keyframe_insert('{path}')"
        else:
            self.w.w.oj.keyframe_delete(path)
            m.undo_str = f"[Modifier Editor] keyframe_delete('{path}')"

        P.refresh = True
        m.refresh()
        self.get_color_fo()
        m.redraw()
        m.undo_push()


class BUDR:
    __slots__ = (
        'w',
        'name',
        'attr',
        'rim',
        'ti',
        'U_set_ti_dr',
        'U_set_ti_nodr',
        'draw_ti',
        'color_fo',
        'dr_event',
        'array_index',
        'is_ref_driver',
    )
    def __init__(self, w, name, ti, attr,
            array_index     = 0,
            is_ref_driver   = False,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, ti)

        self.U_set_ti_dr    = self.I_set_ti_dr
        self.U_set_ti_nodr  = N
        self.draw_ti        = self.I_draw_ti
        self.array_index    = array_index
        self.is_ref_driver  = is_ref_driver

        w.oo_dr[attr] = self

    def next_kf(self, e): # must blf_size
        rim = e.rim
        ti  = e.ti
        self.ti.xy(ti.x + F[14], ti.y)
        self.rim.LRBT(rim.R, self.ti.R_end_x() + F[4], rim.B, rim.T)

    def left_bu_depth_with_kf(self, bu, kf, d = 10): # must blf_size
        rim = bu.rim
        self.ti.align_R_float(rim.L - F[d])
        self.ti.y   = rim.B + F[5.1]
        kf.ti.xy(self.ti.x - F[14], self.ti.y)
        self.rim.B  = kf.rim.B = rim.B
        self.rim.T  = kf.rim.T = rim.T
        kf.rim.L    = kf.ti.x - F[5]
        kf.rim.R    = kf.ti.x + F[11]
        self.rim.L  = kf.rim.R
        self.rim.R  = self.ti.R_end_x() + F[4]

    def dxy_upd(self, x, y):
        self.rim.dxy(x, y)
        self.ti.dxy(x, y)

    def draw_rim(self): pass
    def draw_bg(self):  pass
    def I_draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()
    def I_draw_ti_fo(self):
        blf_color(font_0, *self.color_fo)
        self.ti.draw_pos()

    def I_set_ti_dr(self):
        print(f"    bu_md  I_set_ti_dr")
        self.U_set_ti_dr    = N
        self.U_set_ti_nodr  = self.I_set_ti_nodr
        self.ti.color       = P.color_bu_dr
    def I_set_ti_nodr(self):
        print(f"    bu_md  I_set_ti_nodr")
        self.U_set_ti_dr    = self.I_set_ti_dr
        self.U_set_ti_nodr  = N
        self.ti.color       = P.color_font

    def upd_dr(self, an_data, act_md):
        if an_data:
            drivers = an_data.drivers
            if drivers:
                if self.is_ref_driver:
                    path = f'["modifiers[{act_md.name}].{self.attr}"]'
                else:
                    path = f'modifiers["{act_md.name}"].{self.attr}'
                if drivers.find(path) != None:
                    self.U_set_ti_dr()
                    return
        self.U_set_ti_nodr()

    def inside(self, evt):
        if self.ti.color == P.color_font:
            self.color_fo = P.color_font_fo
        else:
            self.color_fo = P.color_bu_dr_fo

        self.draw_ti    = self.I_draw_ti_fo
        self.dr_event   = self.I_dr_event
        self.w.U_modal  = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.draw_ti    = self.I_draw_ti
            m.redraw()
            self.w.U_modal  = self.w.default_modal
            return

        if evt.value == 'RELEASE':  self.dr_event = self.I_dr_event
        if K["batch0"].true() or K["batch1"].true():
            self.fn_Driver_Batch()
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.w.RET = True
            self.dr_event()
            return True
        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True
    def enforce_outside(self):
        if self.w.U_modal == self.I_modal_fo:
            self.draw_ti    = self.I_draw_ti
            self.w.U_modal  = self.w.default_modal

    def I_dr_event(self):
        self.draw_ti    = self.I_draw_ti
        self.w.U_modal  = self.w.default_modal
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()

    def R_data_path(self):
        return f'modifiers["{self.w.w.act_md.name}"].{self.attr}'
    def R_full_path(self):
        w = self.w.w
        return f'bpy.data.objects["{w.oj.name}"].modifiers["{w.act_md.name}"].{self.attr}'
    def driver_add(self, exp = "var"):
        print(f"    bu_md  BUDR  driver_add")
        w = self.w.w
        R_md_driver_add(w.oj, w.act_md.name, self.attr, exp=exp)
    def driver_remove(self):
        print(f"    bu_md  BUDR  driver_remove")
        w = self.w.w
        return R_md_driver_remove(w.oj, w.act_md.name, self.attr)

    def rm_init(self, evt, override=None):
        if self.attr is None:   return
        print(f"    bu_md  BUDR  rm_init")
        self.enforce_outside()
        bu_kf       = self.w.oo_kf[self.attr]  if self.attr in self.w.oo_kf else None

        if self.is_ref_driver:
            md_type = self.w.w.act_md.type
            attr_fn = getattr(MOD_ATTR, md_type, None)
            if attr_fn is not None:
                attr0, attr1 = attr_fn()
                if self.attr in attr1:
                    o = self.w.w.oj
                    try:
                        path = f'modifiers[{self.w.w.act_md.name}].{self.attr}'
                        dr = o.animation_data.drivers.find(f'["{path}"]')
                    except:
                        dr = None

                    if dr is None:
                        line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 0}
                    else:
                        line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 1}
                else:
                    attr_fn = None

            if attr_fn is None:
                line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver ", 1: 0}
                line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver ", 1: 0}
            line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe ", 1: 0}
            line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe ", 1: 0}
            line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe ", 1: 0}
        else:
            if bu_kf.ti.text == "◆":
                line0 = {9: "fn_Replace_Keyframe", 0: "Replace Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 1}
            else:
                line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 0}

            if bu_kf.ti.text == "•":
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 0}
            else:
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 1}

            if self.U_set_ti_dr == self.I_set_ti_dr:
                line3 = {9: "fn_Add_Driver", 0: "Add Driver"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 0}
            else:
                line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 1}

        if override is None:    override = {}
        if "title" in override:
            ti_tx = override["title"]
        else:
            ti_tx       = self.ti.text
            if ti_tx[-2:] == " :":  ti_tx = ti_tx[:-2]

        m.tm["bu_kf"] = bu_kf

        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y,
        override["li"]  if "li" in override else [
            line0,
            line1,
            line2,
            line3,
            line4,
            {9: "fn_Copy_Data_Path", 0: "Copy Data Path"},
            {9: "fn_Copy_Full_Path", 0: "Copy Full Path"},
            {9: "fn_Copy_as_New_Driver", 0: "Copy as New Driver"},
            {9: "fn_Add_to_Keying_Set", 0: "Add to Keying Set"},
            {9: "fn_Remove_from_Keying_Set", 0: "Remove from Keying Set"},
            {9: "fn_Reset_to_Default_Value", 0: "Reset to Default Value"},
            {9: "fn_Keyframe_Batch", 0: "Keyframe Batch"},
            {9: "fn_Driver_Batch", 0: "Driver Batch"},
            {9: "fn_Value_Batch", 0: "Value Batch"},
        ],
        fin_D1  = override["rm_end"]  if "rm_end" in override else None,
        title   = ti_tx,
        width   = F[150])

    def fn_Insert_Keyframe(self):
        m.tm["bu_kf"].I_fc_event("INSERT")
    def fn_Replace_Keyframe(self):
        m.tm["bu_kf"].I_fc_event("INSERT")
    def fn_Delete_Keyframe(self):
        try:    m.tm["bu_kf"].I_fc_event("DELETE")
        except: pass
    def fn_Clear_Keyframe(self):
        w       = self.w.w
        path = f'modifiers["{w.act_md.name}"].{self.attr}'
        fc = TR_fc_by_path(w.oj, path)
        if fc is None:  return
        w.oj.animation_data.action.fcurves.remove(fc)
        P.refresh = True
        m.refresh()
        m.redraw()
        m.undo_str = f"[Modifier Editor] Clear Keyframe {path}"
        m.undo_push()
    def fn_Add_Driver(self):
        print(f"    bu_md  fn_Add_Driver")
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()
    def fn_Open_Driver_Editor(self):
        print(f"    bu_md  fn_Open_Driver_Editor")
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()
    def fn_Delete_Driver(self):
        print(f"    bu_md  BUDR  fn_Delete_Driver")
        if self.driver_remove():
            P.refresh = True
            m.refresh()
            m.undo_str = "[Modifier Editor] Driver Delete"
            m.undo_push()
    def fn_Copy_Data_Path(self):
        print(f"    bu_md  fn_Copy_Data_Path")
        w = self.w.w
        bpy.context.window_manager.clipboard = f'modifiers["{w.act_md.name}"].{self.attr}'
    def fn_Copy_Full_Path(self):
        print(f"    bu_md  fn_Copy_Full_Path")
        w = self.w.w
        bpy.context.window_manager.clipboard = f'bpy.data.objects["{w.oj.name}"].modifiers["{w.act_md.name}"].{self.attr}'
    def fn_Copy_as_New_Driver(self):
        pass
        print(f"    bu_md  TODO")
    def fn_Add_to_Keying_Set(self):
        print(f"    bu_md  fn_Add_to_Keying_Set")
        w = self.w.w
        keying_sets = bpy.context.scene.keying_sets
        act_ks = keying_sets.active
        if act_ks is None:
            act_ks = keying_sets.new(idname='Button Keying Set', name='Button Keying Set')
            act_ks.use_insertkey_xyz_to_rgb = True
            act_ks.use_insertkey_override_xyz_to_rgb = True

        kspath = act_ks.paths.add(w.oj, f'modifiers["{w.act_md.name}"].{self.attr}')
        keying_sets.active = keying_sets.active
        m.undo_str = "[Modifier Editor] Add to Keying Set"
        m.undo_push()
        m.admin.report({'INFO'}, f"Property added to Keying Set: '{act_ks.bl_idname}'")
    def fn_Remove_from_Keying_Set(self):
        print(f"    bu_md  fn_Remove_from_Keying_Set")
        w = self.w.w
        keying_sets = bpy.context.scene.keying_sets
        act_ks = keying_sets.active
        if act_ks is None:  return

        w_oj = w.oj
        dp = f'modifiers["{w.act_md.name}"].{self.attr}'
        paths = act_ks.paths
        for p in paths:
            if p.id != w_oj:        continue
            if p.data_path != dp:   continue

            paths.remove(p)
            keying_sets.active = keying_sets.active
            m.undo_str = "[Modifier Editor] Remove from Keying Set"
            m.undo_push()
            m.admin.report({'INFO'}, f"Property removed from Keying Set: '{act_ks.bl_idname}'")
    def fn_Reset_to_Default_Value(self):
        try:
            print(f"    bu_md  fn_Reset_to_Default_Value")
            w = self.w.w
            act_md = w.act_md
            attr = self.attr
            prop = act_md.bl_rna.properties[attr]
            if getattr(prop, "is_array", False):
                getattr(act_md, attr)[:] = prop.default_array
            else:
                setattr(act_md, attr, prop.default)

            m.refresh()
            m.undo_str = "[Modifier Editor] Reset Value"
            m.undo_push()
        except:
            pass
    def fn_Add_Reference_Driver(self):
        print(f"    bu_md  fn_Add_Reference_Driver")
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()
    def fn_Delete_Reference_Driver(self):
        print(f"    bu_md  BUDR  fn_Delete_Reference_Driver")
        if self.driver_remove():
            P.refresh = True
            m.refresh()
            m.undo_str = "[Modifier Editor] Delete Reference Driver"
            m.undo_push()
    def fn_Keyframe_Batch(self):
        print(f"    bu_md  fn_Keyframe_Batch")
        if self.attr is None:   return

        self.batch_init(m.EVT.evt, 1 if self.w.oo_kf[self.attr].ti.text == "◆" else 0)
    def fn_Driver_Batch(self):
        print(f"    bu_md  BUDR  fn_Driver_Batch")
        if self.attr is None:   return

        self.batch_init(m.EVT.evt, 0 if self.ti.color == P.color_font else 1, 1)
    def fn_Value_Batch(self):
        print(f"    bu_md  BUDR  fn_Value_Batch")
        if self.attr is None:   return

        self.batch_init(m.EVT.evt, 0, 2)

    def batch_init(self, evt, ind=0, operation=0):
        print(f"    bu_md  BUDR  batch_init")
        if operation == 0:
            MESS_BATCH_KF(evt.mouse_region_x, evt.mouse_region_y, self, operation, ind)
        elif operation == 1:
            MESS_BATCH_DR(evt.mouse_region_x, evt.mouse_region_y, self, operation, ind)
        else:
            MESS_BATCH_VAL(evt.mouse_region_x, evt.mouse_region_y, self, operation, ind)