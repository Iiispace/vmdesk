import bpy
from bgl import glEnable, glDisable, GL_BLEND, GL_SCISSOR_TEST, glScissor
from blf import size as blf_size
from blf import color as blf_color

from .. import m

from .. win_mess import MESS
from .. link_data import MOD_ATTR, R_md_driver_add, R_md_driver_remove
from .. bu import BU, BU_BOOL, BURE, BU_ENUM

P = None
F = None
K = None
BLF = None
font_0 = None
font_1 = None

class MESS_BATCH_KF(MESS):
    __slots__ = (
        'w',
        'md_type',
        'attrs',
        'attrs_sorted',
        'attrs_sorted_ex',
        'attrs_sorted_ref',
        'oo_12',
        'oo_9',
        'oo_free',
        'is_confirm',
        'operation',
    )
    name = "Menu Batch"

    def __init__(self, x, y, bu_dr, operation=0, operation_ind=0):
        self.w = bu_dr
        self.md_type = bu_dr.w.w.act_md.type
        attrs = getattr(MOD_ATTR, self.md_type, None)
        if attrs is None:
            MESS(x, y, "Batch function unsupported in current version.", offset=False, hide_tb=False)
            return

        self.attrs = attrs()
        if operation == 0:
            tx = "Keyframe"
        elif operation == 1:
            tx = "Driver"
        else:
            tx = "Set Value"

        self.is_confirm = False
        self.operation = operation

        super().__init__(x, y, tx, height=1000, offset=False, hide_tb=False)

        self.default_modal = self.I_default_modal
        self.fit_win(F[2])
        if operation == 2:
            self.oo["OP_modifiers"].set_da(True)
        else:
            self.oo["bu_add_remove"].bu_on_by_ind(operation_ind)
        #
    def init_D1(self, evt):
        super().init_D1(evt)

        bo      = self.bo
        da      = self.da
        oo      = self.oo
        ma      = self.main_area
        bu_dr   = self.w
        props   = bu_dr.w.w.act_md.bl_rna.properties

        font_color      = P.color_font
        font_size_12    = F[12]
        operation       = self.operation

        attrs, attrs_ref = self.attrs
        attrs_sorted = [e for e in attrs if e not in {
            "show_on_cage", "show_in_editmode", "show_viewport", "show_render"}]
        attrs_sorted.sort()
        attrs_sorted_ex = []
        for attr in ["show_on_cage", "show_in_editmode", "show_viewport", "show_render"]:
            if attr in attrs:   attrs_sorted_ex.append(attr)
        self.attrs_sorted       = attrs_sorted
        self.attrs_sorted_ex    = attrs_sorted_ex

        for attr in attrs:
            oo[attr] = BU_BOOL(ma, attr, props[attr].name)

        if operation == 0:
            self.attrs_sorted_ref = []
        else:
            attrs_sorted_ref = [e for e in attrs_ref]
            attrs_sorted_ref.sort()
            self.attrs_sorted_ref = attrs_sorted_ref

            for attr in attrs_ref:
                oo[attr] = BU_BOOL(ma, attr, props[attr].name)

        if bu_dr.attr in oo:    oo[bu_dr.attr].set_da(True)

        da["tx_attributes"] = BLF(font_color, "Attributes :", font_size_12)
        da["tx_operation"] = BLF(font_color, "Operation :", font_size_12)
        oo["OP_modifiers"] = BU_BOOL(ma, "OP_modifiers", "All same type modifiers in object")
        oo["OP_selected"] = BU_BOOL(ma, "OP_selected", "All selected objects")

        oo["bu_modifiers"] = BURE(ma, "bu_modifiers", "All", self.bu_fn_modifiers)
        oo["bu_selected"] = BURE(ma, "bu_selected", "All", self.bu_fn_selected)
        if operation != 2:
            oo["bu_add_remove"] = BU_ENUM(ma, "bu_add_remove",
                [
                    BU(ma, "insert", "Insert"), BU(ma, "delete", "Delete"), BU(ma, "clear", "Clear")
                ] if operation == 0 else [
                    BU(ma, "add", "Add"), BU(ma, "remove", "Remove")
                ]
            )

        oo_free = {oo[k] for k in attrs}
        self.oo_free = oo_free
        for attr in ("OP_modifiers", "OP_selected"):    oo_free.add(oo[attr])
        if operation != 0:
            for attr in attrs_ref: oo_free.add(oo[attr])

        self.oo_12 = {oo[k] for k in {
            "bu_ok",
        }}
        oo_9 = {oo[k] for k in ("bu_modifiers", "bu_selected")}
        self.oo_9 = oo_9
        if operation != 2: oo_9.add(oo["bu_add_remove"])

        self.tit["ti"].text = "Batch Menu"
        oo["bu_ok"].ti.text = "Confirm"

        def bu_fn_ok():
            self.is_confirm = True
            self.bu_x_fn()
        oo["bu_ok"].fn = bu_fn_ok

        self.cv.R_w         = bo["bg"].R_w
        self.cv.R_h         = self.cv_R_h

    def fin_D1(self):
        print(f"    menu_batch  fin_D1:  self.is_confirm={self.is_confirm}")
        if self.is_confirm is False: return

        bu_dr   = self.w
        oo      = self.oo
        oj      = bu_dr.w.w.oj
        act_md  = bu_dr.w.w.act_md
        md_type = act_md.type
        attrs   = [attr for attr in self.attrs[0] if oo[attr].da.name is True]
        objs    = bpy.context.selected_objects if oo["OP_selected"].da.name is True else [oj]
        act_name = oo["bu_add_remove"].active.name
        if act_name == "insert":
            def md_fn(o, md, attr):    md.keyframe_insert(attr)
        elif act_name == "delete":
            def md_fn(o, md, attr):
                try:    md.keyframe_delete(attr)
                except: pass
        else:
            def md_fn(o, md, attr):
                try:
                    fcs = o.animation_data.action.fcurves
                    prop = md.bl_rna.properties[attr]
                    if getattr(prop, "is_array", False):
                        for r in range(prop.array_length):
                            fc = fcs.find(f'modifiers["{md.name}"].{attr}', index=r)
                            fcs.remove(fc)
                    else:
                        fcs.remove(fcs.find(f'modifiers["{md.name}"].{attr}'))
                except:
                    pass

        if oo["OP_modifiers"].da.name is True:
            def job_fn(o):
                modifiers = o.modifiers
                for md in modifiers:
                    if md.type == md_type:
                        for attr in attrs:  md_fn(o, md, attr)
        else:
            def job_fn(o):
                modifiers = o.modifiers
                if act_md.name in modifiers:
                    md = modifiers[act_md.name]
                    if md.type == md_type:
                        for attr in attrs:  md_fn(o, md, attr)

        for obj in objs:
            print("    menu_batch  fin_D1  for obj in objs:")
            print(f"        {obj.name}")
            if obj.type == 'MESH':  job_fn(obj)

        m.undo_str = f"[Modifier Editor] Batch {act_name.title()} keyframe"
        m.undo_push()
        P.refresh = True
        m.refresh()

    def get_bo_main(self):
        bo      = self.bo
        da      = self.da
        oo      = self.oo
        _2      = F[2]
        _16     = F[16]
        bu_w    = F[38]
        bu_w1   = F[52]

        x = self.box["main"].L + _2 - self.cv.x
        y = self.box["main"].T - _2 + self.cv.y

        bo["bg"].LRBT(x, x + F[300], 0, y)
        cx      = bo["bg"].R_center_x()

        da["tx"].LT(bo["bg"], F[12], F[20])
        da["tx_attributes"].xy(da["tx"].x, bo["bg"].T - F[46])

        blf_size(font_0, F[9], 72)

        L = x + F[76] - F[3]
        T = bo["bg"].T - F[8]

        if "bu_add_remove" in oo:
            e = oo["bu_add_remove"]
            e.oo[0].LTwh(L, T, bu_w1, _16)
            e.oo[1].LTwh(e.oo[0].rim.R + F[2], T, bu_w1, _16)
            if self.operation == 0: e.oo[2].LTwh(e.oo[1].rim.R + F[2], T, bu_w1, _16)
            e.get_rim()

        L = round(da["tx"].x)
        R = L + _16
        T0 = round(da["tx_attributes"].y - F[12])
        T = T0
        dy = F[22]
        for attr in self.attrs_sorted:
            oo[attr].LRBT_ti_right(L, R, T - _16, T)
            T -= dy

        if self.operation != 0:
            T -= dy // 2
            for attr in self.attrs_sorted_ref:
                oo[attr].LRBT_ti_right(L, R, T - _16, T)
                T -= dy

        L1 = L + F[150] + F[30]
        R1 = L1 + _16
        for attr in self.attrs_sorted_ex:
            oo[attr].LRBT_ti_right(L1, R1, T0 - _16, T0)
            T0 -= dy
        bu_L = L1 + F[46]
        oo["bu_modifiers"].LTwh(bu_L, T + dy, bu_w, _16)

        T -= F[20]
        da["tx_operation"].xy(da["tx"].x, T)
        T -= F[12]
        for attr in ("OP_modifiers", "OP_selected"):
            oo[attr].LRBT_ti_right(L, R, T - _16, T)
            T -= dy
        oo["bu_selected"].LTwh(bu_L, T + dy, bu_w, _16)

        blf_size(font_0, F[12], 72)
        T -= F[5]
        self.oo["bu_ok"].LRBT(cx - F[34], cx + F[34], T - F[20], T)
        T -= F[30]
        bo["bg"].B = T

    def I_draw(self):
        glEnable(GL_BLEND)
        box = self.box
        tit = self.tit

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()
        box["bu_fit"].bind_draw()

        self.sci.ENABLE()
        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in self.oo.values():      e.draw_rim()
        for e in self.oo.values():      e.draw_bg()

        for e in self.oo_free:  e.draw_ti()
        blf_size(font_0, F[12], 72)
        for e in self.oo_12:    e.draw_ti()
        blf_size(font_0, F[9], 72)
        for e in self.oo_9:     e.draw_ti()

        for e in self.da.values():  e.set_draw()

        glDisable(GL_SCISSOR_TEST)
        tit["bu_x"].set_draw_id(font_1)
        tit["bu_fit"].set_draw_id(font_1)
        tit["ti"].set_draw()
        m.FLASH_BOX.U_draw()

    # def dxy_upd_main(self, x, y):
    #     super().dxy_upd_main(x, y)

    def cv_R_h(self):
        return self.bo["bg"].R_h()
    def upd_cv_lim(self):
        border2 = F[2] * 2
        self.cv.lim_x = self.cv.R_w() + border2 - self.box["main"].R_w()
        self.cv.lim_y = self.cv.R_h() + border2 - self.box["main"].R_h()
        if self.cv.lim_x < 0:   self.cv.lim_x = 0
        if self.cv.lim_y < 0:   self.cv.lim_y = 0

    def I_default_modal(self, evt):
        m.M.set_mou_ic('DEFAULT')
        self.U_modal = self.I_modal_main
        self.I_modal_main(evt)
        m.redraw()
    def I_modal_main(self, evt):
        if K["cancel0"].true() or K["cancel1"].true():  self.bu_x_fn()  ;return
        if K["confirm0"].true() or K["confirm1"].true():
            self.is_confirm = True
            self.bu_x_fn()
            return

        self.main_area.U_modal(evt)
    def I_modal_main_area(self, evt):
        if self.box["ti"].inbox(evt):
            if self.box["bu_x"].inbox(evt):
                self.U_modal = self.I_modal_x
                self.modal_x(evt)
                self.box["bu_x"].color = P.color_ti_bu_x
                m.redraw()  ;return
            if self.box["bu_fit"].inbox(evt):
                self.U_modal = self.I_modal_fit
                self.modal_fit(evt)
                self.box["bu_fit"].color = P.color_ti_bu_fo
                m.redraw()  ;return
            if m.U_resize_evt(self, evt):   return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"] ;self.key_end.true()
                self.to_modal_mov(evt)      ;return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"] ;self.key_end.true()
                self.to_modal_mov(evt)      ;return
        elif self.box["main"].inbox(evt):
            if m.U_resize_evt(self, evt):   return
            for e in self.oo.values():
                if e.rim.inbox(evt):    e.inside(evt) ;return

            if K["glopan0"].true():
                self.key_end = K["glopan_E0"] ;self.key_end.true()
                self.to_glopan(evt)             ;return
            if K["glopan1"].true():
                self.key_end = K["glopan_E1"] ;self.key_end.true()
                self.to_glopan(evt)             ;return
            if K["pan0"].true():
                self.key_end = K["pan_E0"] ;self.key_end.true()
                self.to_glopan(evt)             ;return
            if K["pan1"].true():
                self.key_end = K["pan_E1"] ;self.key_end.true()
                self.to_glopan(evt)             ;return
        else:
            if evt.value == 'PRESS':
                if m.thread_isreg(m.flash_box_thread_fn):   return
                box = self.box
                m.FLASH_BOX.init(box["rim"].L, box["rim"].R, box["rim"].B, box["rim"].T)

    def bu_fn_modifiers(self):
        print(f"    menu_batch  bu_fn_modifiers")
        oo = self.oo

        boo = bool([e for e in self.attrs_sorted_ex if oo[e].da.name is not True]
            or [e for e in self.attrs_sorted if oo[e].da.name is not True]
            or [e for e in self.attrs_sorted_ref if oo[e].da.name is not True])

        for attr in self.attrs_sorted:      oo[attr].set_da(boo)
        for attr in self.attrs_sorted_ex:   oo[attr].set_da(boo)
        for attr in self.attrs_sorted_ref:   oo[attr].set_da(boo)
        m.redraw()
    def bu_fn_selected(self):
        print(f"    menu_batch  bu_fn_selected")
        oo = self.oo
        attrs = ("OP_modifiers", "OP_selected")

        boo = bool([e for e in attrs if oo[e].da.name is not True])
        for attr in attrs:  oo[attr].set_da(boo)
        m.redraw()

    def I_upd_data(self):
        pass
    #
    #
class MESS_BATCH_DR(MESS_BATCH_KF):
    __slots__ = ()
    def fin_D1(self):
        print("    menu_batch  MESS_BATCH_DR  fin_D1")
        if self.is_confirm is False: return

        bu_dr   = self.w
        oo      = self.oo
        oj      = bu_dr.w.w.oj
        act_md  = bu_dr.w.w.act_md
        md_type = act_md.type
        attrs   = [attr for attr in self.attrs[0] if oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs[1] if oo[attr].da.name is True]
        objs    = bpy.context.selected_objects if oo["OP_selected"].da.name is True else [oj]
        act_name = oo["bu_add_remove"].active.name
        if act_name == "add":
            def md_fn(o, md, attr):
                try:    R_md_driver_add(o, md.name, attr)
                except: pass
        else:
            def md_fn(o, md, attr):
                try:    R_md_driver_remove(o, md.name, attr)
                except: pass

        if oo["OP_modifiers"].da.name is True:
            def job_fn(o):
                modifiers = o.modifiers
                for md in modifiers:
                    if md.type == md_type:
                        for attr in attrs:  md_fn(o, md, attr)
        else:
            def job_fn(o):
                modifiers = o.modifiers
                if act_md.name in modifiers:
                    md = modifiers[act_md.name]
                    if md.type == md_type:
                        for attr in attrs:  md_fn(o, md, attr)

        for obj in objs:
            print("    menu_batch  fin_D1  for obj in objs:")
            print(f"        {obj.name}")
            if obj.type == 'MESH':  job_fn(obj)

        m.undo_str = f"[Modifier Editor] Batch {act_name.title()} Driver"
        m.undo_push()
        P.refresh = True
        m.refresh()
    #
    #
class MESS_BATCH_VAL(MESS_BATCH_KF):
    __slots__ = ()
    def fin_D1(self):
        print("    menu_batch  MESS_BATCH_VAL  fin_D1")
        if self.is_confirm is False: return

        bu_dr   = self.w
        oo      = self.oo
        oj      = bu_dr.w.w.oj
        act_md  = bu_dr.w.w.act_md
        md_type = act_md.type
        attrs   = [attr for attr in self.attrs[0] if oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs[1] if oo[attr].da.name is True]
        objs    = bpy.context.selected_objects if oo["OP_selected"].da.name is True else [oj]

        def md_fn(md, attr):
            try:    setattr(md, attr, getattr(act_md, attr))
            except: pass

        if oo["OP_modifiers"].da.name is True:
            def job_fn(o):
                modifiers = o.modifiers
                for md in modifiers:
                    if md.type == md_type:
                        for attr in attrs:  md_fn(md, attr)
        else:
            def job_fn(o):
                modifiers = o.modifiers
                if act_md.name in modifiers:
                    md = modifiers[act_md.name]
                    if md.type == md_type:
                        for attr in attrs:  md_fn(md, attr)

        for obj in objs:
            print("    menu_batch  fin_D1  for obj in objs:")
            print(f"        {obj.name}")
            if obj.type == 'MESH':  job_fn(obj)

        m.undo_str = f"[Modifier Editor] Batch Set Value"
        m.undo_push()
        P.refresh = True
        m.refresh()
    #
    #