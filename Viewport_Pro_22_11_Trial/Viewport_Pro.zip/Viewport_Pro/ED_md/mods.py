import bpy

from bgl import glEnable, glDisable, GL_BLEND, GL_SCISSOR_TEST
from blf import size as blf_size
from blf import color as blf_color
from blf import position as blf_pos
from blf import draw as blf_draw

from .. import m, ic

from .. m import BOX, BLF
from .. ll import LL, AN_color_0
from .. ic import UNKNOWN
from .. fn import R_str_by_num3

P = None
F = None
K = None
BIND = None
UNFL = None
font_0 = None
font_1 = None

def TR_drivers(oj):
    try:    return oj.animation_data.drivers
    except: return None
def TR_action_fcurves(oj):
    try:    return oj.animation_data.action.fcurves
    except: return None


class FAKE_FCURVES:
    __slots__ = ()
    def find(self, e): return None


class BU_FOCUS:
    __slots__ = ()
    U_draw = None
    bo = m.SHADE(None)
    ti = BLF()

    @classmethod
    def get_xy(cls, x, y):
        d = F[7]
        cls.bo.LRBTd(x - d, x + d, y - d, y + d, F[2])
        cls.bo.upd()
        cls.U_draw = cls.I_draw_bo
    @classmethod
    def get_ti(cls, x, y, tx):
        ti = cls.ti
        ti.x = x
        ti.y = y
        ti.text = tx
        cls.U_draw = cls.I_draw_ti

    @classmethod
    def I_draw_bo(cls):
        glEnable(GL_BLEND)
        cls.bo.draw()
    @classmethod
    def I_draw_ti(cls):
        blf_size(font_0, F[7], 72)
        cls.ti.set_color()
        cls.ti.draw_pos()


class MD_POP:
    __slots__ = (
        'x',
        'y',
        'bg',
        'rim',
        'ic',
        'name',
        'view',
        'rend',
        'color_cage',
        'color_edit',
        'color_view',
        'color_rend',
        'ind',
        'cage_x',
        'edit_x',
        'view_x',
        'rend_x',
        'U_draw'
    )
    def __init__(self, e, ref, bg_color, L, R, B, T):
        _1 = F[1]
        self.x          = L + F[8]
        self.y          = e.y
        self.view       = e.view
        self.rend       = e.rend
        self.color_cage = e.color_cage
        self.color_edit = e.color_edit
        self.color_view = e.color_view
        self.color_rend = e.color_rend
        self.bg         = e.bg
        self.bg.color   = bg_color
        self.bg.LRBT(L, R, B, T)
        self.rim        = BOX(P.color_bg_mod, L - _1, R + _1, B - _1, T + _1)
        self.rim.upd()
        self.ic         = e.ic
        self.name       = e.name
        self.name.x     = ref.name
        self.name.color = P.color_font_mod_name
        self.name.size  = self.name.text
        self.ind        = e.ind
        self.ind.x      = ref.ind
        self.ind.color  = P.color_font_mod_num
        self.cage_x, self.edit_x, self.view_x, self.rend_x = ref.cage, ref.edit, ref.view, ref.rend
        self.U_draw     = self.I_draw

    def dxy_upd(self, x, y):
        self.x += x
        self.y += y
        self.view += y
        self.rend += y
        self.bg.dxy_upd(x, y)
        self.rim.dxy_upd(x, y)
        self.name.dxy(x, y)
        self.ind.x += x
        self.ic.upd(self.x, self.y)
        self.cage_x += x
        self.edit_x += x
        self.view_x += x
        self.rend_x += x

    def I_draw(self):
        glEnable(GL_BLEND)
        self.rim.bind_draw()
        self.bg.bind_draw()
        self.ic.bind_draw()
        blf_size(font_0, F[12], 72)
        blf_pos(font_0, self.cage_x, self.rend, 0)
        blf_color(font_0, *self.color_cage)
        blf_draw(font_0, "©")
        blf_size(font_0, F[13], 72)
        blf_pos(font_0, self.edit_x, self.name.y, 0)
        blf_color(font_0, *self.color_edit)
        blf_draw(font_0, "∷")
        blf_pos(font_0, self.view_x, self.view, 0)
        blf_color(font_0, *self.color_view)
        blf_draw(font_0, "▃")
        blf_size(font_1, F[15], 72)
        blf_pos(font_1, self.rend_x, self.rend, 0)
        blf_color(font_1, *self.color_rend)
        blf_draw(font_1, "☉")
        blf_size(font_0, F[9], 72)
        self.name.set_color()
        self.name.draw_pos()
        blf_size(font_0, F[7], 72)
        blf_pos(font_0, self.ind.x, self.name.y, 0)
        self.ind.set_color()
        self.ind.draw()

    def thread_color(self, thread_li, speed):   # speed < 0
        self.rim.color      = [*self.rim.color]
        self.bg.color       = [*self.bg.color]
        self.ic.color       = [*self.ic.color]
        self.name.color     = [*self.name.color]
        self.color_cage     = [*self.color_cage]
        self.color_edit     = [*self.color_edit]
        self.color_view     = [*self.color_view]
        self.color_rend     = [*self.color_rend]
        self.ind.color      = [*self.ind.color]

        colors = [
            self.rim.color,
            self.bg.color,
            self.ic.color,
            self.name.color,
            self.color_cage,
            self.color_edit,
            self.color_view,
            self.color_rend,
            self.ind.color
        ]
        if hasattr(self.ic, "color2"):
            self.ic.color2  = [*self.ic.color2]
            colors.append(self.ic.color2)

        thread_li["pop_color"] = AN_color_0(colors, 0.0, speed * 0.05)


class REF:
    __slots__ = (
        'ic',
        'name',
        'cage',
        'edit',
        'view',
        'rend',
        'ind',
        'sub_modal_x',
        'txR',
    )
    def __init__(self, x):  self.get(x)
    def get(self, x):
        self.ic = x + F[8]
        self.name = self.ic + F[12]
        self.cage = self.name + F[82]
        self.edit = self.cage + F[13]
        self.view = self.edit + F[17]
        self.rend = self.view + F[13]
        self.ind = self.rend + F[15]

        self.sub_modal_x = self.cage - F[2]
        self.txR = self.cage - F[6]
    def dx(self, x):
        self.ic += x
        self.name += x
        self.cage += x
        self.edit += x
        self.view += x
        self.rend += x
        self.ind += x
    def upd(self):
        self.sub_modal_x = self.cage - F[2]
        self.txR = self.cage - F[6]


class MODS(LL):
    __slots__ = (
        'modifier_move_to_index',
        'modifier_remove',
        'modifier_apply',
        'modifier_copy_to_selected',
        'modifier_copy',
        'tm_fn',
    )
    def __init__(self, w, L, R, T, hi):
        print(f"    mods  MODS  __init__")

        super().__init__(w, L, R, T, hi)

        if w.U_upd_act_ob == w.I_upd_act_md_sync:
            self.set_act = self.I_set_act_sync
        else:
            self.set_act = self.I_set_act_unsync

        self.modifier_move_to_index     = bpy.ops.object.modifier_move_to_index
        self.modifier_remove            = bpy.ops.object.modifier_remove
        self.modifier_apply             = bpy.ops.object.modifier_apply
        self.modifier_copy_to_selected  = bpy.ops.object.modifier_copy_to_selected
        self.modifier_copy              = bpy.ops.object.modifier_copy

        cv          = self.cv
        actbox      = self.actbox
        ref         = REF(cv.L)
        self.ref    = ref
        actbox.init(ref.name - F[3], ref.cage - F[2])

# INS CLASS
        class MD:
            __slots__ = (
                'y',
                'bg',
                'ic',
                'name',
                'view',
                'rend',
                'color_cage',
                'color_edit',
                'color_view',
                'color_rend',
                'ind',
            )
            def __init__(self):
                self.y      = 0
                self.bg     = BOX(None, None, None, None, None)
                self.name   = BLF(P.color_font_mod_name, x=None)
                self.ind    = BLF(size=-1, x=None, y=None)

            def get_ic(self, bpy_md):   self.ic = getattr(ic, bpy_md.type, UNKNOWN)()
            def get_pos(self, L, R, B, T, cy, ref_ic):
                self.y      = cy
                self.name.y = cy - F[3]
                self.view   = self.name.y + F[3]
                self.rend   = self.name.y - F[1]
                self.bg.upd_bat(L, R, B, T)
                self.ic.upd(ref_ic, cy)
            def upd_blf_y(self, y):
                self.y      = y
                self.name.y = y - F[3]
                self.view   = self.name.y + F[3]
                self.rend   = self.name.y - F[1]
            def dy_blf(self, y):
                self.y += y
                self.name.y += y
                self.view += y
                self.rend += y
            def dy_upd(self, y):
                self.y += y
                self.name.y += y
                self.view += y
                self.rend += y
                T = self.y + F[-997]
                self.bg.upd_bat(cv.L, cv.R, T - F[-911], T)
                self.ic.upd(ref.ic, self.y)

            def get_name(self, bpy_md, ref_name, txR): # blf_size
                self.name.size = self.name.text = bpy_md.name
                self.name.fix_long_text_by_x(ref_name, txR, F[8])
            def get_ind(self, i):
                self.ind.size = i
                self.ind.text = R_str_by_num3(i + 1)
            def get_data(self, bpy_md, drivers, fcurves):
                self.ic.upd_mod_data(self, bpy_md, drivers, fcurves)
                self.ic.upd_ic_color(bpy_md)
            def init(self, L, R, B, T, cy, ref_ic, ref_name, txR, ind, md, drivers, fcurves): # blf_size
                new_ic      = getattr(ic, md.type, UNKNOWN)()
                self.ic     = new_ic

                self.y      = cy
                self.name.y = cy - F[3]
                self.view   = self.name.y + F[3]
                self.rend   = self.name.y - F[1]
                self.bg.upd_bat(L, R, B, T)
                new_ic.upd(ref_ic, cy)

                self.ind.size = ind
                self.ind.text = R_str_by_num3(ind + 1)

                self.name.size = self.name.text = md.name
                self.name.fix_long_text_by_x(ref_name, txR, F[8])

                new_ic.upd_mod_data(self, md, drivers, fcurves)
                new_ic.upd_ic_color(md)

# INS CLASS END
        self.li_type = MD
        oj = w.oj

        if oj is None:
            self.obs        = None
            self.ll_bpy     = 0
            self.ll_li      = 0
            self.li         = {}
            actbox.disable()
            self.headkey    = None
            self.endkey     = None
        else:
            obs             = oj.modifiers
            self.obs        = obs
            self.ll_bpy     = len(obs)
            self.ll_li      = min(self.max_ll, self.ll_bpy)
            self.ind_desel  = {r : None for r in range(self.ll_li)}
            li              = {k : MD() for k in self.ind_desel}
            self.li         = li

            blf_size(font_0, F[9], 72)
            hi  = self.md_hi
            L   = cv.L
            R   = cv.R
            T   = cv.T
            B   = T - self.md_h
            cy  = T - self.d_cy

            txR     = ref.txR
            ref_ic      = ref.ic
            ref_name    = ref.name
            drivers     = TR_drivers(oj)
            fcurves     = TR_action_fcurves(oj)
            if drivers is None:     drivers = FAKE_FCURVES()
            if fcurves is None:     fcurves = FAKE_FCURVES()

            for r in range(self.ll_li):
                li[r].init(L, R, B, T, cy, ref_ic, ref_name, txR, r, obs[r], drivers, fcurves)

                T -= hi
                B -= hi
                cy -= hi

            cv.B = cv.T - self.md_hi * self.ll_bpy
            i = self.R_act_ind()
            if i == -1:
                actbox.disable()
                self.headkey    = 0
                self.endkey     = None
            else:
                self.sel_range = {i: None}
                if i in li:
                    self.ind_sel[i] = self.ind_desel.pop(i)
                    actbox.get(cv, i)
                else:   actbox.disable()
                self.headkey    = 0
                self.endkey     = self.ll_li - 1
        cv.upd()

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_set_act_sync(self, i):    self.w.oj.modifiers.active = self.obs[i]
    def I_set_act_unsync(self, i):  self.w.act_md = self.obs[i]

    def R_bpy_obs(self):    return self.w.oj.modifiers
    def R_y_default(self):
        return self.w.bo["md_info"].T - F[21]

    def upd_li_data(self, i, e, drivers, fcurves): #blf_size, self.obs
        md = self.obs[i]
        if e.ic.R_name() != md.type:    e.get_ic(md) ;e.ic.upd(self.ref.ic, e.y)
        if e.ind.size != i:             e.get_ind(i)
        if e.name.size != md.name:      e.get_name(md, self.ref.name, self.ref.txR)
        e.get_data(md, drivers, fcurves)
    def upd_li_data_all(self, drivers, fcurves): #blf_size, self.obs
        obs = self.obs
        for i, e in self.li.items():
            md = obs[i]
            if e.ic.R_name() != md.type:    e.get_ic(md) ;e.ic.upd(self.ref.ic, e.y)
            if e.ind.size != i:             e.get_ind(i)
            if e.name.size != md.name:      e.get_name(md, self.ref.name, self.ref.txR)
            e.get_data(md, drivers, fcurves)
    def init_li_data(self, i, e, drivers, fcurves): #blf_size, self.obs
        md = self.obs[i]
        e.get_ic(md) ;e.ic.upd(self.ref.ic, e.y)
        e.get_ind(i)
        e.get_name(md, self.ref.name, self.ref.txR)
        e.get_data(md, drivers, fcurves)

    def dxy_upd(self, x, y):
        self.ref.dx(x)
        d_cy    = self.d_cy
        h       = self.md_h
        self.cv.dxy_upd(x, y)
        L       = self.cv.L
        R       = self.cv.R
        ref_ic  = self.ref.ic
        for e in self.li.values():
            e.y += y
            e.name.y += y
            e.view += y
            e.rend += y
            T = e.y + d_cy
            e.bg.upd_bat(L, R, T - h, T)
            e.ic.upd(ref_ic, e.y)
        self.y += y
        self.upd_sci()
        self.actbox.rim.dxy_upd(x, y)
        self.actbox.bg.dxy_upd(x, y)

    def R_tm_pop(self):     return MD_POP
    def R_new_active(self): return self.obs.active

    def bpy_move_to_ind(self, name, ind):
        try:    self.modifier_move_to_index(modifier=name, index=ind)
        except: pass
    def bpy_remove_by_name(self, name):
        oj      = bpy.context.object
        print(f"    mods  bpy_remove_by_name:  del modifier  oj.name={oj.name}, modifier={name}")
        dp      = f'modifiers["{name}"].'
        md      = oj.modifiers[name]
        drivers = TR_drivers(oj)
        fcurves = TR_action_fcurves(oj)

        for attr in dir(md):
            path    = dp + attr
            if drivers:
                fc  = drivers.find(path)
                if fc is not None:  drivers.remove(fc)
            if fcurves:
                fc  = fcurves.find(path)
                if fc is not None:  fcurves.remove(fc)

        self.modifier_remove(modifier=name)
    def bpy_apply_by_name(self, name):
        try:
            self.modifier_apply(modifier=name)
            return True
        except:
            self.modifier_remove(modifier=name)
            return False
    def bpy_copy_to(self, name):
        try:
            self.modifier_copy_to_selected(modifier=name)
            return True
        except:
            return False
    def bpy_copy(self, name):
        try:
            self.modifier_copy(modifier=name)
            return True
        except:
            return False

# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def upd_data(self): # modifiers != 0
        li          = self.li
        ref         = self.ref
        oj          = self.w.oj
        self.w_oj   = oj
        self.obs    = oj.modifiers
        cv          = self.cv
        act_ind     = self.R_act_ind()
        self.actbox.upd_check(self, cv, act_ind)
        blf_size(font_0, F[9], 72)
        ll          = len(self.obs)
        drivers     = TR_drivers(oj)
        fcurves     = TR_action_fcurves(oj)
        if drivers is None:     drivers = FAKE_FCURVES()
        if fcurves is None:     fcurves = FAKE_FCURVES()
        self.drivers = drivers
        self.fcurves = fcurves

        if ll < self.ll_bpy: # reget all
            cv.T        = self.y
            self.ll_li  = min(28, ll)
            MD          = self.li_type
            li          = {k : MD() for k in range(self.ll_li)}
            self.li     = li
            obs         = self.obs
            hi          = self.md_hi
            L           = cv.L
            R           = cv.R
            T           = cv.T
            B           = T - self.md_h
            cy          = T - self.d_cy
            txR         = ref.txR
            ref_ic      = ref.ic
            ref_name    = ref.name

            for r in range(self.ll_li):
                li[r].init(L, R, B, T, cy, ref_ic, ref_name, txR, r, obs[r], drivers, fcurves)

                T -= hi
                B -= hi
                cy -= hi

            cv.B = cv.T - self.md_hi * ll
            cv.upd()
            self.sel_range = {k : None  for k in self.sel_range if k < ll}
            self.get_draw_ind_by_sel_range()
            self.actbox.get(cv, act_ind)
            print("    mods  MODS  upd_data  reget")
            self.headkey    = 0
            self.endkey     = self.ll_li - 1
        else:
            if self.ll_li < 28:
                d = min(28, ll) - self.ll_li
                if d > 0:
                    obs         = self.obs
                    hi          = self.md_hi
                    L           = cv.L
                    R           = cv.R
                    T           = cv.T - self.ll_li * hi
                    B           = T - self.md_h
                    cy          = T - self.d_cy
                    txR         = ref.txR
                    ref_ic      = ref.ic
                    ref_name    = ref.name
                    MD          = self.li_type

                    for r in range(self.ll_li, self.ll_li + d):
                        e = MD()
                        e.init(L, R, B, T, cy, ref_ic, ref_name, txR, r, obs[r], drivers, fcurves)
                        li[r] = e

                        T -= hi
                        B -= hi
                        cy -= hi

                    self.ll_li = len(li)
                    cv.B = cv.T - self.md_hi * ll
                    cv.upd()
                    self.get_draw_ind_by_sel_range()
                    self.endkey = self.ll_li - 1
            elif self.ll_bpy != ll:
                cv.B = cv.T - self.md_hi * ll
                cv.upd()

            self.upd_li_data_all(drivers, fcurves)

        self.ll_bpy = ll
        cvh = cv.R_h()
        syslimdn = self.sci.R_T()
        syslimup = syslimdn + max(0, min(cvh, self.hi) - self.sci.h)
        print(f"    mods  MODS  upd_data:  y={self.y}, syslimup={syslimup}, syslimdn={syslimdn}")

        if self.y < syslimdn:
            print(f"    mods  MODS  upd_data  auto pon case 1")
            dy = syslimdn - self.y
            self.y += dy
        elif self.y > syslimup:
            print(f"    mods  MODS  upd_data  auto pon case 2")
            dy = syslimup - self.y
            self.y += dy
        else: return

        print(f"    mods  MODS  upd_data  auto pon case 5")
        d_cy    = self.d_cy
        h       = self.md_h
        cv.dy_upd(dy)
        L       = cv.L
        R       = cv.R
        ref_ic  = ref.ic
        for e in li.values():
            e.y += dy
            e.name.y += dy
            e.view += dy
            e.rend += dy
            T = e.y + d_cy
            e.bg.upd_bat(L, R, T - h, T)
            e.ic.upd(ref_ic, e.y)

        self.actbox.get(cv, act_ind)
        print(f"    mods  MODS  upd_data  after:  y={self.y}, syslimup={syslimup}, syslimdn={syslimdn}, cv.T={cv.T}")

    def kill_mods(self):
        print(f"    mods  kill_mods")
        self.obs = self.w.oj.modifiers  if self.w.oj else None
        self.cv.B = self.cv.T = self.y = self.R_y_default()
        self.cv.upd()
        self.ind_sel.clear()
        self.ind_desel.clear()
        self.sel_range.clear()
        self.w.da["amt"].text = "0 / 0"
        self.w.da["amt"].size = 0

        self.li.clear()
        self.ll_li = 0
        self.ll_bpy = 0

        self.actbox.disable()
        self.headkey = 0
        self.endkey = None

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def sub_modal(self, evt):
        ref = self.ref
        if evt.mouse_region_x >= ref.ind:
            if K["me_sort0"].true():
                self.is_draw_bu_focus = False
                self.key_end = K["me_sort_E0"]
                self.to_modal_sort(evt)
                return True
            if K["me_sort1"].true():
                self.is_draw_bu_focus = False
                self.key_end = K["me_sort_E1"]
                self.to_modal_sort(evt)
                return True

            i = self.R_ind_by_mou_safe(evt.mouse_region_y)
            if i in self.li:
                self.is_draw_bu_focus   = True
                e = self.li[i]
                BU_FOCUS.get_ti(ref.ind, e.name.y, e.ind.text)
                m.redraw()
            elif self.is_draw_bu_focus:
                self.is_draw_bu_focus = False
                m.redraw()
        elif evt.mouse_region_x >= ref.sub_modal_x:
            self.is_draw_bu_focus = False
            m.redraw()
            x = evt.mouse_region_x
            i = self.R_ind_by_mou_safe(evt.mouse_region_y)
            if i in self.li:
                if x < ref.view - F[4]:
                    if x < ref.edit:
                        if self.li[i].color_cage != m.color_empty:
                            self.is_draw_bu_focus   = True
                            BU_FOCUS.get_xy(ref.cage + F[6], self.li[i].y)
                    else:
                        if self.li[i].color_edit != m.color_empty:
                            self.is_draw_bu_focus   = True
                            BU_FOCUS.get_xy(ref.edit + F[7], self.li[i].y)
                elif x < ref.rend - F[3]:
                    if self.li[i].color_view != m.color_empty:
                        self.is_draw_bu_focus   = True
                        BU_FOCUS.get_xy(ref.view + F[4], self.li[i].y)
                else:
                    if self.li[i].color_rend != m.color_empty:
                        self.is_draw_bu_focus   = True
                        BU_FOCUS.get_xy(ref.rend + F[5], self.li[i].y)

            if K["sel_fast0"].true():
                self.key_end = K["sel0"]  ;self.to_modal_switch(evt)  ;return True
            if K["sel_fast1"].true():
                self.key_end = K["sel1"]  ;self.to_modal_switch(evt)  ;return True
        else:
            if self.is_draw_bu_focus:   self.is_draw_bu_focus = False  ;m.redraw()
        return False

    def to_modal_switch(self, evt):
        print(f"    mods  to_modal_switch")
        self.w.I_upd_data() ;m.redraw()
        if self.ll_bpy == 0:    return

        x = evt.mouse_region_x
        i = self.R_ind_by_mou_safe(evt.mouse_region_y)
        if i not in self.li:    return

        ref = self.ref

        if x < ref.view - F[4]:
            if x < ref.edit:
                print("    mods  to_modal_switch  CAGE")
                if self.li[i].color_cage == m.color_empty:    return
                if self.obs[i].show_on_cage:    self.tm_fn = False
                else:                           self.tm_fn = True
            else:
                print("    mods  to_modal_switch  EDIT")
                if self.li[i].color_edit == m.color_empty:    return
                if self.obs[i].show_in_editmode:    self.tm_fn = False
                else:                               self.tm_fn = True
        elif x < ref.rend - F[3]:
            print("    mods  to_modal_switch  VIEW")
            if self.li[i].color_view == m.color_empty:    return
            if self.obs[i].show_viewport:   self.tm_fn = False
            else:                           self.tm_fn = True
        else:
            print("    mods  to_modal_switch  REND")
            if self.li[i].color_rend == m.color_empty:    return
            if self.obs[i].show_render:     self.tm_fn = False
            else:                           self.tm_fn = True

        self.is_draw_bu_focus   = False
        self.get_auto_pan_data()
        self.fn_switch(i, x)
        m.head_modal.append(self.I_modal_switch)
        self.key_end.true()
    def I_modal_switch(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                print("    mods  I_modal_switch  END")
                del m.head_modal[-1]
                return

        mou_y = evt.mouse_region_y
        i = self.R_ind_by_mou_safe(mou_y)
        if i in self.li:    self.fn_switch(i, evt.mouse_region_x)

        if mou_y < self.tm_autoB:
            m.dy = max(1, int((self.tm_autoB - mou_y) * self.tm_pan_speed))
            old_T = self.cv.T
            y = old_T + m.dy
            if y < self.y:
                self.tm_dif = self.y - y
                m.dy += self.tm_dif
            elif y > self.tm_limyup:
                self.tm_dif = self.tm_limyup - y
                m.dy += self.tm_dif
            else:   self.tm_dif = 0
            self.pan_y()
        elif mou_y > self.tm_autoT:
            m.dy = -max(1, int((mou_y - self.tm_autoT) * self.tm_pan_speed))
            old_T = self.cv.T
            y = old_T + m.dy
            if y < self.y:
                self.tm_dif = self.y - y
                m.dy += self.tm_dif
            elif y > self.tm_limyup:
                self.tm_dif = self.tm_limyup - y
                m.dy += self.tm_dif
            else:   self.tm_dif = 0
            self.pan_y()
        m.redraw()
    def fn_switch(self, i, x):
        ref = self.ref
        if x >= ref.ind:            return
        elif x < ref.sub_modal_x:   return

        if x < ref.view - F[4]:
            if x < ref.edit:
                if self.li[i].color_cage != m.color_empty: self.obs[i].show_on_cage = self.tm_fn
            elif self.li[i].color_edit != m.color_empty:   self.obs[i].show_in_editmode = self.tm_fn
        elif x < ref.rend - F[3]:
            if self.li[i].color_view != m.color_empty:     self.obs[i].show_viewport = self.tm_fn
        elif self.li[i].color_rend != m.color_empty:       self.obs[i].show_render = self.tm_fn

# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        li  = self.li
        li_values = li.values()
        ref = self.ref

        self.cv.bind_draw()
        BIND()  ;UNFL("color", self.color_bg_desel)
        for k in self.ind_desel:    li[k].bg.draw()
        BIND()  ;UNFL("color", self.color_bg_sel)
        for k in self.ind_sel:      li[k].bg.draw()
        self.actbox.U_draw()
        for e in li_values:         e.ic.bind_draw()

        ref_cage    = ref.cage
        ref_edit    = ref.edit
        ref_view    = ref.view
        ref_rend    = ref.rend
        ref_name    = ref.name
        ref_ind     = ref.ind

        blf_size(font_0, F[12], 72)
        for e in li_values:
            blf_pos(font_0, ref_cage, e.rend, 0)
            blf_color(font_0, *e.color_cage)
            blf_draw(font_0, "©")
        blf_size(font_0, F[13], 72)
        for e in li_values:
            blf_pos(font_0, ref_edit, e.name.y, 0)
            blf_color(font_0, *e.color_edit)
            blf_draw(font_0, "∷")
            blf_pos(font_0, ref_view, e.view, 0)
            blf_color(font_0, *e.color_view)
            blf_draw(font_0, "▃")
        blf_size(font_1, F[15], 72)
        for e in li_values:
            blf_pos(font_1, ref_rend, e.rend, 0)
            blf_color(font_1, *e.color_rend)
            blf_draw(font_1, "☉")
        blf_size(font_0, F[9], 72)
        for e in li_values:
            blf_pos(font_0, ref_name, e.name.y, 0)
            e.name.set_color()
            e.name.draw()
        blf_size(font_0, F[7], 72)
        blf_color(font_0, *self.color_num)
        for e in li_values:
            blf_pos(font_0, ref_ind, e.name.y, 0)
            e.ind.draw()

        if self.is_draw_bu_focus:   BU_FOCUS.U_draw()

    def I_draw_modal_sort(self):
        li_values = self.li.values()
        ref = self.ref

        self.cv.bind_draw()
        BIND()  ;UNFL("color", self.color_bg_desel)
        for e in li_values:     e.bg.draw()
        for e in li_values:     e.ic.bind_draw()

        ref_cage    = ref.cage
        ref_edit    = ref.edit
        ref_view    = ref.view
        ref_rend    = ref.rend
        ref_name    = ref.name
        ref_ind     = ref.ind

        blf_size(font_0, F[12], 72)
        for e in li_values:
            blf_pos(font_0, ref_cage, e.rend, 0)
            blf_color(font_0, *e.color_cage)
            blf_draw(font_0, "©")
        blf_size(font_0, F[13], 72)
        for e in li_values:
            blf_pos(font_0, ref_edit, e.name.y, 0)
            blf_color(font_0, *e.color_edit)
            blf_draw(font_0, "∷")
            blf_pos(font_0, ref_view, e.view, 0)
            blf_color(font_0, *e.color_view)
            blf_draw(font_0, "▃")
        blf_size(font_1, F[15], 72)
        for e in li_values:
            blf_pos(font_1, ref_rend, e.rend, 0)
            blf_color(font_1, *e.color_rend)
            blf_draw(font_1, "☉")
        blf_size(font_0, F[9], 72)
        for e in li_values:
            blf_pos(font_0, ref_name, e.name.y, 0)
            e.name.set_color()
            e.name.draw()
        blf_size(font_0, F[7], 72)
        blf_color(font_0, *self.color_num)
        for e in li_values:
            blf_pos(font_0, ref_ind, e.name.y, 0)
            e.ind.draw()
