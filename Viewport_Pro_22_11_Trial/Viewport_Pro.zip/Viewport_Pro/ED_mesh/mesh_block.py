from mathutils import Vector
from mathutils.geometry import intersect_line_plane, area_tri
from math import sqrt, degrees, radians, tau, pi
from blf import color as blf_color
from numpy.linalg import matrix_rank

from .. import m

from .. fn import (
    math_split,
    bin_search_continue,
    R_nor_to_glo,
    R_face_normal,
    R_nor_to_local,
    R_bm_nor,
    R_face_area,
    R_median,
    R_normal_center,
    R_angle,
    R_str_by_deg,
    R_u_pos_by_angle,
    R_3vert_of_2edges,
)
from .. calc import calc_vec_3
from .. bu import VBOX, VBOX_SUB, VBOX_SET, TXBOX, BBOX, BURE2
from .. det import INFO

P = None
F = None
K = None
BOX = None
BLF = None
font_0 = None

class BL_CLS:
    __slots__ = (
        'w',
        'rim',
        'oo',
        'hi',
        'RET',
        'U_modal',
        'default_modal',
        'outside',
    )
    def init(self, w): pass
    def __init__(self, w):
        self.w = w
        self.U_modal = self.I_modal_main
        self.default_modal = self.I_modal_main
        self.outside = w.outside
        self.rim = BOX(P.color_mesh_ed_block)

        self.init(w)

    def get_bo(self, L, R, T, x, x1):
        self.rim.LRBT_upd(L, R, T - self.hi, T)

        bu_hi = F[16]
        d = F[3] + F[1]
        T -= F[3]
        B = T - bu_hi
        for e in self.oo.values():
            e.LRBT(x, x1, B, T)
            T = B - d
            B = T - bu_hi

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)

    def draw_bo(self):
        self.rim.bind_draw()
        for e in self.oo.values():  e.draw_bg()
    def draw_ti(self):
        for e in self.oo.values():  e.draw_ti()

    def upd_data(self): pass

    def I_modal_main(self, evt):
        self.RET = False

        if not self.rim.inbox(evt):
            self.w.U_modal = self.w.default_modal
            return self.w.U_modal(evt)

        self.modal_part(evt)
        return self.RET
    def modal_part(self, evt):
        for e in self.oo.values():
            if e.is_inside(evt):
                e.inside(evt)
                return

    def to_default_modal(self):
        self.U_modal = self.default_modal
        self.w.U_modal = self.default_modal
    def to_modal(self, e):
        self.U_modal = e
        self.w.U_modal = e

    def R_quick_edit_state(self):
        if "is_quick_edit" in m.tm:
            TEMP = m.tm["is_quick_edit"]
            if TEMP:
                state = TEMP["state"]
                if state == 0:
                    TEMP["state"] = 1
                    return 1, TEMP
                elif state == 1:
                    return 2, TEMP
                else:
                    return state, TEMP
        return 0, None
    def R_if_keep_act_co(self, data, props):
        try:
            if props["mesh_ed_face_nor_keep_act"] is False: return None

            act = data["bms"][data["oj"]].select_history.active
            if act == None: return None

            if hasattr(act, "edges"):   m_co = act.calc_center_median()
            elif hasattr(act, "verts"): m_co = (act.verts[0].co + act.verts[1].co) / 2
            else:                       m_co = act.co

            if not props["mesh_ed_local"]:
                m_co = data["oj"].matrix_world @ m_co
            return m_co
        except:
            return None
    def R_act_vert(self, data, props, use_prop=True):
        try:
            if use_prop:
                if props["mesh_ed_face_nor_keep_act"] is False: return None

            act = data["bms"][data["oj"]].select_history.active
            if act == None: return None

            if hasattr(act, "edges"):   return None
            elif hasattr(act, "verts"): return None
            return act
        except:
            return None
    def R_last_vert(self, data):
        try:
            his = data["bms"][data["oj"]].select_history
            if his:
                last = his[-1]
                if hasattr(last, "edges"):  return None
                if hasattr(last, "verts"):  return None
                return last
            else:
                return None
        except:
            return None
    def R_last_edge(self, data):
        try:
            his = data["bms"][data["oj"]].select_history
            if his:
                last = his[-1]
                if hasattr(last, "edges"):  return None
                if hasattr(last, "verts"):  return last
                return None
            else:
                return None
        except:
            return None
    def R_last_2vert(self, data):
        try:
            his = data["bms"][data["oj"]].select_history
            if his:
                last = his[-1]
                if hasattr(last, "edges"):  return None, None
                if hasattr(last, "verts"):  return None, None
                if len(his) == 1:   return last, None
                last2 = his[-2]
                if hasattr(last2, "edges"): return last, None
                if hasattr(last2, "verts"): return last, None
                return last, last2
            else:
                return None, None
        except:
            return None, None
    def R_all_verts(self, data):
        li = []
        try:
            for e in data["bm_verts"].values(): li += e
            return li
        except:
            return li
    def R_all_edges(self, data):
        li = []
        try:
            for e in data["bm_edges"].values(): li += e
            return li
        except:
            return li
    def R_all_faces(self, data):
        li = []
        try:
            for e in data["bm_faces"].values(): li += e
            return li
        except:
            return li
    #
    #

class BL_DIS(BL_CLS):
    __slots__ = ()
    def init(self, w):
        self.oo = {
            "dis":      VBOX(self, "dis", "Distance", self.bufn_dis, unit=1, details=INFO(
                "Distance", "Distance between 2 vertices."
            )),
            "invert":   BBOX(self, "invert", "Invert", self.bufn_invert, details=INFO(
                "Invert", "If true, move from the non-active vertex."
            )),
        }
        self.oo["invert"].set_da(w.props["mesh_ed_dis_invert"])
        self.hi = F[3]*2 + F[16]

    def get_bo(self, L, R, T, x, x1):
        self.rim.LRBT_upd(L, R, T - self.hi, T)

        oo = self.oo
        bu_hi = F[16]
        T -= F[3]
        oo["dis"].LRBT(x, x1, T - bu_hi, T)
        R -= F[3]
        oo["invert"].LRBT(R - bu_hi, R, T - bu_hi, T)

    def upd_data(self):
        data = self.w.mesh_data
        oo_dis = self.oo["dis"]
        oo_invert = self.oo["invert"]

        if "vec" in data:
            if not oo_dis.is_enable:
                oo_dis.enable()
                oo_invert.enable()
            oo_dis.set_da(data["vec"].length)
        else:
            if oo_dis.is_enable:
                oo_dis.disable()
                oo_invert.disable()

    def bufn_dis(self, v, undo_push=True):
        try:
            data = self.w.mesh_data
            u_vec = data["u_vec"]
            d_vec = u_vec * v
            vert0 = data["vert0"]
            vert1 = data["vert1"]
            if self.w.props["mesh_ed_local"]:
                vert0[0].co[:] = vert1[0].co + d_vec
            else:
                new_loc = vert1[1].matrix_world @ vert1[0].co + d_vec
                vert0[0].co[:] = vert0[1].matrix_world.inverted() @ new_loc
            for o in data["bms"]:   o.data.update()

            if undo_push:
                m.undo_str = f"[Mesh Editor] Distance = {v}"
                m.undo_push()
        except: pass
    def bufn_invert(self, v, undo_push=True):
        try:
            m.redraw()
            m.refresh()
            self.w.props["mesh_ed_dis_invert"] = bool(v)
            self.w.w.I_upd_data()
        except: pass
    #
    #
class BL_DIR(BL_CLS):
    __slots__ = ()
    def init(self, w):
        li_vec = []

        self.oo = {
            "vec":  VBOX_SET(self, "vec", "Direction", li_vec, 3)
        }
        details=INFO(
            "Direction", "Vector direction of 2 vertices, point to active vertex.\nProperties: Invert"
        )
        li_vec.append(VBOX_SUB(self, "x", ("X", "vec", 0), self.R_bufn_vec(0), offset_ti_key = 20, unit=1, details=details))
        li_vec.append(VBOX_SUB(self, "y", ("Y", "vec", 1), self.R_bufn_vec(1), unit=1, details=details))
        li_vec.append(VBOX_SUB(self, "z", ("Z", "vec", 2), self.R_bufn_vec(2), unit=1, details=details))

        self.hi = (F[3] + F[1])*2 + F[16]*3

    def upd_data(self):
        data = self.w.mesh_data
        oo_vec = self.oo["vec"]
        if "vec" in data:
            if not oo_vec.is_enable:    oo_vec.enable()
            oo_vec.set_da(data["vec"])
        else:
            if oo_vec.is_enable:    oo_vec.disable()

    def modal_part(self, evt):
        o = self.oo["vec"]
        for e in o.li:
            if e.is_inside(evt):
                e.inside(evt)
                return

    def R_bufn_vec(self, ind):
        def bufn_vec(v, bu_range=None, undo_push=True):
            try:
                data = self.w.mesh_data
                vec = data["vec"]

                if bu_range is None:
                    vec[ind] = v
                    if undo_push:
                        m.undo_str = f'[Mesh Editor] Direction[{ind}] = {v}'
                else:
                    i0 = bu_range[0]
                    i1 = bu_range[1]
                    vec[i0 : i1] = [v] * (i1 - i0)
                    if undo_push:
                        m.undo_str = f'[Mesh Editor] Direction[{bu_range[0]}:{bu_range[1]}] = {v}'

                vert0 = data["vert0"]
                vert1 = data["vert1"]
                if self.w.props["mesh_ed_local"]:
                    vert0[0].co[:] = vert1[0].co + vec
                else:
                    new_loc = vert1[1].matrix_world @ vert1[0].co + vec
                    vert0[0].co[:] = vert0[1].matrix_world.inverted() @ new_loc
                for o in data["bms"]:   o.data.update()

                if undo_push:   m.undo_push()
            except: pass
        return bufn_vec
    #
    #
class BL_VEC(BL_CLS):
    __slots__ = ()
    def init(self, w):
        self.oo = {
            "vec":  TXBOX(self, "vec", "Unit Vector", self.bufn_u_vec, details=INFO(
                "Unit Vector", "Unit vector direction of 2 vertices, point to active vertex.\nProperties: Invert"
            ))
        }
        self.oo["vec"].tx_format = m.U_format_vec
        self.hi = F[3]*2 + F[16]
    def get_bo(self, L, R, T, x, x1):
        self.rim.LRBT_upd(L, R, T - self.hi, T)

        oo = self.oo
        bu_hi = F[16]
        T -= F[3]
        oo["vec"].LRBT(x, R - F[3], T - bu_hi, T)

    def upd_data(self):
        data = self.w.mesh_data
        oo_vec = self.oo["vec"]
        if "u_vec" in data:
            if not oo_vec.is_enable:    oo_vec.enable()
            oo_vec.set_da(data["u_vec"])
        else:
            if oo_vec.is_enable:    oo_vec.disable()

    def bufn_u_vec(self, s, undo_push=True):
        try:
            inp = calc_vec_3(s)
            if isinstance(inp, str):
                if inp: m.admin.report({'INFO'}, inp)
                return

            inp = Vector(inp).normalized()

            data = self.w.mesh_data
            u_vec = data["u_vec"]
            u_vec[:] = inp[:]
            dis = data["vec"].length
            vec = u_vec * dis

            vert0 = data["vert0"]
            vert1 = data["vert1"]
            if self.w.props["mesh_ed_local"]:
                vert0[0].co[:] = vert1[0].co + vec
            else:
                new_loc = vert1[1].matrix_world @ vert1[0].co + vec
                vert0[0].co[:] = vert0[1].matrix_world.inverted() @ new_loc
            self.oo["vec"].da.name = None
            for o in data["bms"]:   o.data.update()

            if undo_push:
                undo_str = f'[Mesh Editor] Unit Vector = {inp}'
                m.undo_str = undo_str[: -2].replace("<Vector (", "")
                m.undo_push()
        except: pass

class BL_NOR(BL_CLS):
    __slots__ = ()
    def init(self, w):
        li_vec = []

        oo = {
            "vec":          TXBOX(self, "vec", "Face Normal", self.bufn_vec, details=INFO(
                "Face Normal", "Unit vector direction of Face Normal.\nProperties: Keep Normals to Other Faces, Lock Active Vertex"
            )),
            "keep_nor":     BBOX(self, "keep_nor", "Keep Normals to Other Faces", self.bufn_keep_nor, details=INFO(
                "Keep Normals to Other Faces", "Keep normals of unselected faces if possible."
            )),
            "lock_act":     BBOX(self, "lock_act", "Lock Active Vertex", self.bufn_lock_act, details=INFO(
                "Lock Active Vertex", "If true, keep active vertex location."
            )),
        }
        self.oo = oo
        oo["vec"].tx_format = m.U_format_vec
        oo["keep_nor"].set_da(w.props["mesh_ed_face_nor_keep_nor"])
        oo["lock_act"].set_da(w.props["mesh_ed_face_nor_keep_act"])
        self.hi = F[3]*4 + F[16]*3 + F[1]*2
    def get_bo(self, L, R, T, x, x1):
        self.rim.LRBT_upd(L, R, T - self.hi, T)

        oo = self.oo
        bu_hi = F[16]
        T -= F[3]
        B = T - bu_hi
        R1 = R - F[3]
        oo["vec"].LRBT(x, R1, B, T)
        d = F[3] + F[1]

        T = B - d
        B = T - bu_hi
        oo["keep_nor"].LRBT(R1 - bu_hi, R1, B, T)
        T = B - d
        B = T - bu_hi
        oo["lock_act"].LRBT(R1 - bu_hi, R1, B, T)

    def upd_data(self):
        data = self.w.w.A_data.mesh_data
        oo = self.oo
        oo_vec = oo["vec"]
        if "face_1" in data:
            if oo_vec.is_enable is False:           oo_vec.enable()
            if oo["lock_act"].is_enable is False:   oo["lock_act"].enable()
            if oo["keep_nor"].is_enable is False:   oo["keep_nor"].enable()

            if self.w.props["mesh_ed_local"] is True:
                vec = R_bm_nor(data["face_1"]).normalized()
            else:
                vec = R_nor_to_glo(R_bm_nor(data["face_1"]), data["oj"]).normalized()

            oo_vec.set_da(vec)
        else:
            if oo_vec.is_enable is True:            oo_vec.disable()
            if oo["lock_act"].is_enable is True:    oo["lock_act"].disable()
            if oo["keep_nor"].is_enable is True:    oo["keep_nor"].disable()

    def bufn_vec(self, s, undo_push=True):
        try:
            inp = calc_vec_3(s)
            if isinstance(inp, str):
                if inp: m.admin.report({'INFO'}, inp)
                return False

            props = self.w.props
            data = self.w.mesh_data
            oj = data["oj"]
            plane = data["face_1"]
            is_act = False
            if props["mesh_ed_face_nor_keep_act"]:
                act_vert = data["bms"][oj].select_history.active
                if act_vert in plane.verts: is_act = True

            plane_co = act_vert.co.copy() if is_act else plane.calc_center_median()
            inp = Vector(inp).normalized() if props["mesh_ed_local"] else R_nor_to_local(Vector(inp), oj).normalized()

            if props["mesh_ed_face_nor_keep_nor"]:
                plane_edges = plane.edges

                lines = {}
                for vert in plane.verts:
                    ll_faces = len(vert.link_faces)
                    if ll_faces > 3:
                        if undo_push:
                            m.admin.report({'INFO'}, "Some vertices in selected face have more than 3 linked faces, abort.")
                        return False

                    if ll_faces == 1:   continue
                    elif ll_faces == 2:
                        faces = vert.link_faces
                        face = faces[1 if faces[0] == plane else 0]
                        plane_edges = plane.edges
                        share_edge = set(plane_edges).intersection(face.edges)
                        if len(share_edge) != 1:
                            if undo_push:
                                m.admin.report({'INFO'}, "2 of the linked faces of the vertices in the selected face have no or more than one shared edge, abort.")
                            return False

                        share_edge, = share_edge
                        v0, v1 = share_edge.verts

                        for edge in face.edges:
                            if edge == share_edge: continue
                            if v0 in edge.verts:
                                lines[v0] = edge
                            elif v1 in edge.verts:
                                lines[v1] = edge

                    elif ll_faces == 3:
                        faces = vert.link_faces
                        if faces[0] == plane:
                            face1 = faces[1]
                            face2 = faces[2]
                        elif faces[1] == plane:
                            face1 = faces[0]
                            face2 = faces[2]
                        else:
                            face1 = faces[0]
                            face2 = faces[1]

                        check_connect_plane = False
                        check_connect_other = False

                        for e in face1.edges:
                            if plane in e.link_faces:
                                check_connect_plane = True
                            elif face2 in e.link_faces:
                                check_connect_other = True
                                line = e

                        if check_connect_plane is False or check_connect_other is False:
                            if undo_push:
                                m.admin.report({'INFO'}, "The 3 linked faces of a vertice in the selected face are not connected, abort.")
                            return False

                        lines[vert] = line

                new_pos = {}
                if lines:
                    for edge in lines.values():
                        if edge.verts[0] in plane.verts:
                            v0 = edge.verts[1]
                            v1 = edge.verts[0]
                        else:
                            v0 = edge.verts[0]
                            v1 = edge.verts[1]

                        fake_dir = (v0.co - v1.co).normalized()
                        break

                    for vert in plane.verts:
                        if vert in lines:
                            edge_verts = lines[vert].verts
                            v0 = edge_verts[0 if edge_verts[1] == vert else 1]
                            pos = intersect_line_plane(v0.co, vert.co, plane_co, inp)
                            if pos is None:
                                if undo_push:
                                    m.admin.report({'INFO'}, "The linked face of the selected face has the same normal as the selected face, abort.")
                                return False
                            new_pos[vert] = pos
                        else:
                            pos = intersect_line_plane(vert.co + fake_dir, vert.co, plane_co, inp)
                            if pos is None:
                                if undo_push:
                                    m.admin.report({'INFO'}, "The linked face of the selected face has the same normal as the selected face, abort.")
                                return False
                            new_pos[vert] = pos
                else:
                    old_vec = R_bm_nor(plane).normalized()

                    for vert in plane.verts:
                        pos = intersect_line_plane(vert.co + old_vec, vert.co, plane_co, inp)
                        if pos is None:
                            if undo_push:
                                m.admin.report({'INFO'}, "The linked face of the selected face has the same normal as the selected face, abort.")
                            return False
                        new_pos[vert] = pos

                for vert, pos in new_pos.items():
                    vert.co[:] = pos
            else:
                new_pos = {}
                old_vec = R_bm_nor(plane).normalized()

                for vert in plane.verts:
                    pos = intersect_line_plane(vert.co + old_vec, vert.co, plane_co, inp)
                    if pos is None:
                        if undo_push:
                            m.admin.report({'INFO'}, "The linked face of the selected face has the same normal as the selected face, abort.")
                        return False
                    new_pos[vert] = pos

                for vert, pos in new_pos.items():
                    vert.co[:] = pos


            new_nor = R_bm_nor(plane).normalized()
            if (inp[0] > 0.0 and new_nor[0] < 0.0) or (inp[0] < 0.0 and new_nor[0] > 0.0):  plane.normal_flip()
            self.oo["vec"].da.name = None
            for o in data["bms"]:   o.data.update()
            if undo_push:
                undo_str = f'[Mesh Editor] Face Normal = {inp}'
                m.undo_str = undo_str[: -2].replace("<Vector (", "")
                m.undo_push()
            return True
        except: return False
    def bufn_lock_act(self, v, undo_push=True):
        try:    self.w.props["mesh_ed_face_nor_keep_act"] = bool(v)
        except: pass
    def bufn_keep_nor(self, v, undo_push=True):
        try:    self.w.props["mesh_ed_face_nor_keep_nor"] = bool(v)
        except: pass
    #
    #
class BL_INFO(BL_CLS):
    __slots__= 'is_enable', 'color_tx'
    def init(self, w):
        self.oo = {
            "coplanar":     BLF(text="Coplanar Threshold"),
            "threshold":    BLF(),
            "make_flat":    BURE2(self, "make_flat", "Make Coplanar", fn=self.bufn_make_flat, details=INFO(
                "Make Coplanar", "Make vertices coplanar.\nProperties: Include Selected Vertices, Keep Normals to Other Faces, Lock Active Vertex"
            )),
            "is_vert":      BBOX(self, "is_vert", "Include Selected Vertices", self.bufn_is_vert, details=INFO(
                "Include Selected Vertices", "If false, only count selected faces."
            )),
        }
        self.oo["is_vert"].set_da(w.props["mesh_ed_cop_vert"])
        self.hi = F[3]*3 + F[16]*2 + F[1]
        self.enable()
    def get_bo(self, L, R, T, x, x1):
        self.rim.LRBT_upd(L, R, T - self.hi, T)

        oo = self.oo
        bu_hi = F[16]
        y = T - F[14]
        oo["coplanar"].xy(L + F[12], y)
        oo["threshold"].xy(x + F[8], y)
        R1 = R - F[3]
        T -= F[3]
        B = T - bu_hi
        oo["make_flat"].LRBT(R1 - F[82], R1, B, T)

        d = F[3] + F[1]
        T = B - d
        B = T - bu_hi
        oo["is_vert"].LRBT(R1 - bu_hi, R1, B, T)

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        oo = self.oo
        oo["coplanar"].dxy(x, y)
        oo["threshold"].dxy(x, y)
        oo["make_flat"].dxy_upd(x, y)
        oo["is_vert"].dxy_upd(x, y)
    def draw_bo(self):
        self.rim.bind_draw()
        self.oo["make_flat"].draw_bg()
        self.oo["is_vert"].draw_bg()
    def draw_ti(self):
        blf_color(font_0, *self.color_tx)
        oo = self.oo
        oo["coplanar"].draw_pos()
        oo["threshold"].draw_pos()
        oo["make_flat"].draw_ti()
        oo["is_vert"].draw_ti()
    def enable(self):
        self.color_tx = P.color_font
        self.is_enable = True
        if self.oo["make_flat"].is_enable is False:
            self.oo["make_flat"].enable()
            self.oo["is_vert"].enable()
    def disable(self):
        self.color_tx = P.color_font_ignore
        self.is_enable = False
        if self.oo["make_flat"].is_enable is True:
            self.oo["make_flat"].disable()
            self.oo["is_vert"].disable()

    def R_verts(self):
        data = self.w.mesh_data
        if self.w.props["mesh_ed_cop_vert"]:
            if "bm_verts" not in data:  return None
            bm_verts = data["bm_verts"]
            multi_object = (len(bm_verts) > 1)

            verts = bm_verts
        else:
            if "bm_faces" not in data:  return None
            bm_faces = data["bm_faces"]
            multi_object = (len(bm_faces) > 1)

            verts = {}
            for o, e in bm_faces.items():
                vs = set()
                for face in e:
                    vs = vs.union({v for v in face[0].verts})
                verts[o] = [(v, o) for v in vs]
        return verts, multi_object
    def upd_data(self):
        verts = self.R_verts()
        if verts is None:
            if self.is_enable:  self.disable()
            return

        verts, multi_object = verts
        if multi_object:
            verts_mix = []
            for o, vs in verts.items():
                mat = o.matrix_world
                verts_mix += [mat @ v[0].co for v in vs]

            if len(verts_mix) < 3:
                if self.is_enable:  self.disable()
                return

            v0_co = verts_mix.pop()
            vecs = [v - v0_co for v in verts_mix]
        else:
            for vs in verts.values():
                verts_mix = vs

            if len(verts_mix) < 3:
                if self.is_enable:  self.disable()
                return

            v0_co = verts_mix[-1][0].co
            vecs = [v[0].co - v0_co for v in verts_mix[: -1]]

        def rank_fn(v):
            return True if matrix_rank(vecs, v) < 3 else False

        th = bin_search_continue(rank_fn, 0, 1000)
        if th is None:  s = f'> {m.U_format_f(1000)}'
        else:           s = f'{m.U_format_f(th)}'
        self.oo["threshold"].text = s

        if self.is_enable is False: self.enable()

    def modal_part(self, evt):
        e = self.oo["make_flat"]
        if e.is_inside(evt):
            e.inside(evt)
            return
        e = self.oo["is_vert"]
        if e.is_inside(evt):
            e.inside(evt)
            return

    def bufn_make_flat(self):
        data = self.w.mesh_data
        if "face_1" in data:
            def overwrite():
                for e in self.w.oo.values():
                    if isinstance(e, BL_NOR):
                        tx = e.oo["vec"].da.name
                        if isinstance(tx, Vector):
                            s = ""
                            for v in tx:
                                s += f'{m.R_str_by_float(v)},'
                            s = s[:-1]

                            if e.bufn_vec(s, undo_push=False):
                                m.undo_str = '[Mesh Editor] Make Coplanar'
                                m.undo_push()
                                return True
                        break
                return False

            if self.w.props["mesh_ed_cop_vert"]:
                if len(data["face_1"].verts) == data["ll_verts"]:
                    print("    mesh_block  bufn_make_flat  overwrite case1")
                    if overwrite(): return
            else:
                print("    mesh_block  bufn_make_flat  overwrite case2")
                if overwrite(): return

        print("    mesh_block  bufn_make_flat")
        verts = self.R_verts()
        if verts is None: return

        verts, multi_object = verts
        verts_mix = []
        for o, vs in verts.items():
            mat = o.matrix_world
            verts_mix += [mat @ v[0].co for v in vs]

        nor = R_normal_center(data["bms"][data["oj"]], verts_mix)
        if nor is None or nor[0].length == 0:
            m.admin.report({'INFO'}, "Can't find the normal, abort.")
            m.undo_str = '[Mesh Editor] Make Coplanar'
            m.undo_push()
            return

        nor, co = nor
        self.w.w.I_upd_data()

        verts = self.R_verts()
        verts, multi_object = verts
        verts_mix = []
        for o, vs in verts.items():
            verts_mix += [v for v in vs]

        for v in verts_mix:
            vert_co = v[1].matrix_world @ v[0].co
            pos = intersect_line_plane(vert_co + nor, vert_co, co, nor)
            if pos is None: continue
            v[0].co[:] = v[1].matrix_world.inverted() @ pos

        for o in data["bms"]:   o.data.update()
        m.undo_str = '[Mesh Editor] Make Coplanar'
        m.undo_push()
    def bufn_is_vert(self, v, undo_push=True):
        try:
            self.w.props["mesh_ed_cop_vert"] = bool(v)
            self.w.w.I_upd_data()
        except: pass
    #
    #
class BL_AREA(BL_CLS):
    __slots__ = ()
    def init(self, w):
        self.oo = {
            "area":      VBOX(self, "area", "Faces Area", self.bufn_area, unit=2, details=INFO(
                "Faces Area", "Area of selected faces."
            )),
        }
        self.hi = F[3]*2 + F[16]

    def upd_data(self):
        data = self.w.mesh_data
        if "bm_faces" not in data or "ll_faces" not in data or data["ll_faces"] == 0:
            if self.oo["area"].is_enable is True:
                self.oo["area"].disable()
            bl_nor_oo = self.w.oo[0].oo
            if bl_nor_oo["lock_act"].is_enable is True:     bl_nor_oo["lock_act"].disable()
            if bl_nor_oo["keep_nor"].is_enable is True:     bl_nor_oo["keep_nor"].disable()
            return

        if self.oo["area"].is_enable is False:
            self.oo["area"].enable()
        bl_nor_oo = self.w.oo[0].oo
        if bl_nor_oo["lock_act"].is_enable is False:    bl_nor_oo["lock_act"].enable()
        if bl_nor_oo["keep_nor"].is_enable is False:    bl_nor_oo["keep_nor"].enable()

        a = 0.0
        faces = []
        for e in data["bm_faces"].values(): faces += e
        if self.w.props["mesh_ed_local"]:
            for e in faces:
                a += e[0].calc_area()
        else:
            for e in faces:
                mat = e[1].matrix_world
                verts = [mat @ loop.vert.co for loop in e[0].loops]

                a += R_face_area(verts)

        self.oo["area"].set_da(a)

    def bufn_area(self, v, undo_push=True):
        try:
            data = self.w.mesh_data
            props = self.w.props
            old_v = self.oo["area"].da.name

            if "bms" not in data: return
            v = max(0.0, v)
            quick_edit_state, TEMP = self.R_quick_edit_state()

            if quick_edit_state == 2:
                old_v = TEMP["old_v"]
                faces = TEMP["faces"]
                #
            elif quick_edit_state in {0, 1}:
                if old_v == 0:
                    if quick_edit_state == 1:   TEMP["state"] = 0
                    return

                fac = sqrt(v / old_v)
                faces = []
                for e in data["bm_faces"].values(): faces += e
                if not faces:
                    if quick_edit_state == 1:   TEMP["state"] = 0
                    return

                if quick_edit_state == 1:
                    TEMP["old_v"] = old_v
                    TEMP["faces"] = faces
                #
            else:
                if undo_push:
                    m.undo_str = f"[Mesh Editor] Faces Area = {v}"
                    m.undo_push()
                return

            if props["mesh_ed_local"]:
                if quick_edit_state in {0, 1}:
                    verts = {}
                    for e in faces:
                        o = e[1]
                        for vert in e[0].verts:
                            verts[vert] = o

                    m_co = self.R_if_keep_act_co(data, props)
                    if m_co is None:
                        m_co = R_median([vert.co for vert in verts])

                    if quick_edit_state == 1:
                        TEMP["m_co"] = m_co
                        TEMP["verts"] = verts
                        D_v_org_dir = {}
                        TEMP["D_v_org_dir"] = D_v_org_dir
                        for vert in verts:
                            vec_dir = vert.co - m_co
                            D_v_org_dir[vert] = vec_dir
                            vert.co[:] = vec_dir * fac + m_co
                    else:
                        for vert in verts:
                            vert.co[:] = (vert.co - m_co) * fac + m_co
                else:
                    m_co = TEMP["m_co"]
                    verts = TEMP["verts"]
                    D_v_org_dir = TEMP["D_v_org_dir"]
                    fac = sqrt(v / old_v)

                    for vert in verts:
                        vert.co[:] = D_v_org_dir[vert] * fac + m_co

                    self.oo["area"].da.name = v
            else:
                if quick_edit_state in {0, 1}:
                    verts = {}
                    for e in faces:
                        o = e[1]
                        for vert in e[0].verts:
                            verts[vert] = o

                    m_co = self.R_if_keep_act_co(data, props)
                    if m_co is None:
                        m_co = R_median([o.matrix_world @ vert.co for vert, o in verts.items()])

                    if quick_edit_state == 1:
                        TEMP["m_co"] = m_co
                        TEMP["verts"] = verts
                        D_v_org_dir = {}
                        TEMP["D_v_org_dir"] = D_v_org_dir
                        for vert, o in verts.items():
                            v_co = o.matrix_world @ vert.co
                            vec_dir = v_co - m_co
                            D_v_org_dir[vert] = vec_dir
                            pos = vec_dir * fac + m_co
                            vert.co[:] = o.matrix_world.inverted() @ pos
                    else:
                        for vert, o in verts.items():
                            v_co = o.matrix_world @ vert.co
                            pos = (v_co - m_co) * fac + m_co
                            vert.co[:] = o.matrix_world.inverted() @ pos

                else:
                    m_co = TEMP["m_co"]
                    verts = TEMP["verts"]
                    D_v_org_dir = TEMP["D_v_org_dir"]
                    fac = sqrt(v / old_v)

                    for vert, o in verts.items():
                        pos = D_v_org_dir[vert] * fac + m_co
                        vert.co[:] = o.matrix_world.inverted() @ pos

                    self.oo["area"].da.name = v


            for o in data["bms"]:   o.data.update()
            if undo_push:
                m.undo_str = f"[Mesh Editor] Faces Area = {v}"
                m.undo_push()
        except: pass
    #
    #
class BL_LEN(BL_CLS):
    __slots__ = ()
    def init(self, w):
        self.oo = {
            "len":      VBOX(self, "len", "Edges Length", self.bufn_len, unit=1, details=INFO(
                "Edges Length", "The total Length of selected edges."
            )),
        }
        self.hi = F[3]*2 + F[16]

    def upd_data(self):
        data = self.w.mesh_data
        if "bm_edges" not in data or "ll_edges" not in data or data["ll_edges"] == 0:
            if self.oo["len"].is_enable is True:
                self.oo["len"].disable()
            return

        if self.oo["len"].is_enable is False:
            self.oo["len"].enable()
        bl_nor_oo = self.w.oo[0].oo
        if bl_nor_oo["lock_act"].is_enable is False:    bl_nor_oo["lock_act"].enable()

        l = 0.0
        edges = []
        for e in data["bm_edges"].values(): edges += e
        if self.w.props["mesh_ed_local"]:
            for e in edges:
                verts = e[0].verts
                l += (verts[1].co - verts[0].co).length
        else:
            for e in edges:
                verts = e[0].verts
                mat = e[1].matrix_world
                l += ((mat @ verts[1].co) - (mat @ verts[0].co)).length

        self.oo["len"].set_da(l)

    def bufn_len(self, v, undo_push=True):
        try:
            data = self.w.mesh_data
            props = self.w.props
            old_v = self.oo["len"].da.name

            if "bms" not in data: return
            v = max(0.0, v)
            quick_edit_state, TEMP = self.R_quick_edit_state()

            if quick_edit_state == 2:
                old_v = TEMP["old_v"]
                edges = TEMP["edges"]
                #
            elif quick_edit_state in {0, 1}:
                if old_v == 0:
                    if quick_edit_state == 1:   TEMP["state"] = 0
                    return

                fac = v / old_v
                edges = []
                for e in data["bm_edges"].values(): edges += e
                if not edges:
                    if quick_edit_state == 1:   TEMP["state"] = 0
                    return

                if quick_edit_state == 1:
                    TEMP["old_v"] = old_v
                    TEMP["edges"] = edges
            else:
                if undo_push:
                    m.undo_str = f"[Mesh Editor] Edges Length = {v}"
                    m.undo_push()
                return

            if props["mesh_ed_local"]:
                if quick_edit_state in {0, 1}:
                    verts = {}
                    for e in edges:
                        o = e[1]
                        for vert in e[0].verts:
                            verts[vert] = o

                    m_co = self.R_if_keep_act_co(data, props)
                    if m_co is None:
                        m_co = R_median([vert.co for vert in verts])

                    if quick_edit_state == 1:
                        TEMP["m_co"] = m_co
                        TEMP["verts"] = verts
                        D_v_org_dir = {}
                        TEMP["D_v_org_dir"] = D_v_org_dir
                        for vert in verts:
                            vec_dir = vert.co - m_co
                            D_v_org_dir[vert] = vec_dir
                            vert.co[:] = vec_dir * fac + m_co
                    else:
                        for vert in verts:
                            vert.co[:] = (vert.co - m_co) * fac + m_co
                else:
                    m_co = TEMP["m_co"]
                    verts = TEMP["verts"]
                    D_v_org_dir = TEMP["D_v_org_dir"]
                    fac = v / old_v

                    for vert in verts:
                        vert.co[:] = D_v_org_dir[vert] * fac + m_co

                    self.oo["len"].da.name = v
            else:
                if quick_edit_state in {0, 1}:
                    verts = {}
                    for e in edges:
                        o = e[1]
                        for vert in e[0].verts:
                            verts[vert] = o

                    m_co = self.R_if_keep_act_co(data, props)
                    if m_co is None:
                        m_co = R_median([o.matrix_world @ vert.co for vert, o in verts.items()])

                    if quick_edit_state == 1:
                        TEMP["m_co"] = m_co
                        TEMP["verts"] = verts
                        D_v_org_dir = {}
                        TEMP["D_v_org_dir"] = D_v_org_dir
                        for vert, o in verts.items():
                            v_co = o.matrix_world @ vert.co
                            vec_dir = v_co - m_co
                            D_v_org_dir[vert] = vec_dir
                            pos = vec_dir * fac + m_co
                            vert.co[:] = o.matrix_world.inverted() @ pos
                    else:
                        for vert, o in verts.items():
                            v_co = o.matrix_world @ vert.co
                            pos = (v_co - m_co) * fac + m_co
                            vert.co[:] = o.matrix_world.inverted() @ pos
                else:
                    m_co = TEMP["m_co"]
                    verts = TEMP["verts"]
                    D_v_org_dir = TEMP["D_v_org_dir"]
                    fac = v / old_v

                    for vert, o in verts.items():
                        pos = D_v_org_dir[vert] * fac + m_co
                        vert.co[:] = o.matrix_world.inverted() @ pos

                    self.oo["len"].da.name = v


            for o in data["bms"]:   o.data.update()
            if undo_push:
                m.undo_str = f"[Mesh Editor] Edges Length = {v}"
                m.undo_push()
        except: pass
    #
    #

class BL_DIR3(BL_NOR):
    __slots__ = ()
    def init(self, w):
        self.oo = {
            "vec":          TXBOX(self, "vec", "Face Direction", self.bufn_u_vec, details=INFO(
                "Face Direction", "Unit vector direction of Face Normal, based on vertex selection order.\nProperties: Lock Active Vertex"
            )),
            "lock_act":     BBOX(self, "lock_act", "Lock Active Vertex", self.bufn_lock_act, details=INFO(
                "Lock Active Vertex", "If true, keep active vertex location."
            )),
        }
        self.oo["vec"].tx_format = m.U_format_vec
        self.oo["lock_act"].set_da(w.props["mesh_ed_face_nor_keep_act"])
        self.hi = F[3]*3 + F[16]*2 + F[1]
    def get_bo(self, L, R, T, x, x1):
        self.rim.LRBT_upd(L, R, T - self.hi, T)

        oo = self.oo
        bu_hi = F[16]
        T -= F[3]
        B = T - bu_hi
        R1 = R - F[3]
        oo["vec"].LRBT(x, R1, B, T)
        d = F[3] + F[1]

        T = B - d
        B = T - bu_hi
        oo["lock_act"].LRBT(R1 - bu_hi, R1, B, T)

    def upd_data(self):
        data = self.w.mesh_data
        oo_vec = self.oo["vec"]
        if "ll_verts" not in data or data["ll_verts"] != 3:
            if oo_vec.is_enable is True:    oo_vec.disable()
            return
        if oo_vec.is_enable is False:   oo_vec.enable()

        props = self.w.props
        verts = []
        for o, vs in data["bm_verts"].items():  verts += vs

        if props["mesh_ed_local"] is True:
            nor = R_face_normal([v.co for v, o in verts])
        else:
            nor = R_face_normal([o.matrix_world @ v.co for v, o in verts])

        oo_vec.set_da(nor.normalized())

    def bufn_u_vec(self, s, undo_push=True):
        try:
            inp = calc_vec_3(s)
            if isinstance(inp, str):
                if inp: m.admin.report({'INFO'}, inp)
                return

            inp = Vector(inp).normalized()
            data = self.w.mesh_data
            props = self.w.props
            verts = []
            m_co = self.R_if_keep_act_co(data, props)
            for o, vs in data["bm_verts"].items():  verts += vs

            if props["mesh_ed_local"] is True:
                co_s = [v.co for v, o in verts]
                nor = R_face_normal(co_s).normalized()
                if m_co is None:    m_co = R_median(co_s)
                rot = nor.rotation_difference(inp)
                for v, o in verts:
                    vec = rot @ (v.co - m_co)
                    v.co[:] = m_co + vec
            else:
                co_s = [o.matrix_world @ v.co for v, o in verts]
                nor = R_face_normal(co_s).normalized()
                if m_co is None:    m_co = R_median(co_s)
                rot = nor.rotation_difference(inp)
                for v, o in verts:
                    mat = o.matrix_world
                    vec = rot @ (mat @ v.co - m_co)
                    v.co[:] = mat.inverted() @ (m_co + vec)


            for o in data["bms"]:   o.data.update()
            if undo_push:
                undo_str = f'[Mesh Editor] Unit Vector = {inp}'
                m.undo_str = undo_str[: -2].replace("<Vector (", "")
                m.undo_push()
        except: pass
class BL_INFO3(BL_INFO):
    __slots__ = ()
    def init(self, w):
        self.oo = {
            "collinear":    BLF(text="Collinear Threshold"),
            "threshold":    BLF(),
            "make_flat":    BURE2(self, "make_flat", "Make Collinear", fn=self.bufn_make_flat, details=INFO(
                "Make Collinear", "Make vertices collinear.\nProperties: Lock Active Vertex"
            )),
        }
        self.hi = F[3]*2 + F[16]
        self.enable()
    def get_bo(self, L, R, T, x, x1):
        self.rim.LRBT_upd(L, R, T - self.hi, T)

        oo = self.oo
        bu_hi = F[16]
        y = T - F[14]
        oo["collinear"].xy(L + F[13], y)
        oo["threshold"].xy(x + F[8], y)
        R1 = R - F[3]
        T -= F[3]
        B = T - bu_hi
        oo["make_flat"].LRBT(R1 - F[82], R1, B, T)
    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        oo = self.oo
        oo["collinear"].dxy(x, y)
        oo["threshold"].dxy(x, y)
        oo["make_flat"].dxy_upd(x, y)
    def draw_bo(self):
        self.rim.bind_draw()
        self.oo["make_flat"].draw_bg()
    def draw_ti(self):
        blf_color(font_0, *self.color_tx)
        oo = self.oo
        oo["collinear"].draw_pos()
        oo["threshold"].draw_pos()
        oo["make_flat"].draw_ti()
    def enable(self):
        self.color_tx = P.color_font
        self.is_enable = True
        if self.oo["make_flat"].is_enable is False:
            self.oo["make_flat"].enable()
    def disable(self):
        self.color_tx = P.color_font_ignore
        self.is_enable = False
        if self.oo["make_flat"].is_enable is True:
            self.oo["make_flat"].disable()

    def R_verts(self):
        data = self.w.mesh_data
        if "bm_verts" not in data:  return None
        bm_verts = data["bm_verts"]
        multi_object = (len(bm_verts) > 1)

        return bm_verts, multi_object
    def upd_data(self):
        verts = self.R_verts()
        data = self.w.mesh_data
        if verts is None or "ll_verts" not in data or data["ll_verts"] != 3:
            if self.is_enable:  self.disable()
            return
        if self.is_enable is False: self.enable()

        verts, multi_object = verts
        if multi_object:
            verts_mix = []
            for o, vs in verts.items():
                mat = o.matrix_world
                verts_mix += [mat @ v[0].co for v in vs]

            v0_co = verts_mix.pop()
            vecs = [v - v0_co for v in verts_mix]
        else:
            for vs in verts.values():
                verts_mix = vs

            v0_co = verts_mix[-1][0].co
            vecs = [v[0].co - v0_co for v in verts_mix[: -1]]

        def rank_fn(v):
            return True if matrix_rank(vecs, v) < 2 else False

        th = bin_search_continue(rank_fn, 0, 1000)
        if th is None:  s = f'> {m.U_format_f(1000)}'
        else:           s = f'{m.U_format_f(th)}'
        self.oo["threshold"].text = s

    def modal_part(self, evt):
        e = self.oo["make_flat"]
        if e.is_inside(evt):
            e.inside(evt)
            return

    def bufn_make_flat(self):
        try:
            data = self.w.mesh_data
            if data["ll_verts"] != 3:   return
            ll_edges = data["ll_edges"]
            verts = []
            edges = []
            for e in data["bm_verts"].values(): verts += e
            for e in data["bm_edges"].values(): edges += e

            if ll_edges == 1:
                edge = edges[0]
                edge_oj = edge[1]
                edge_v0 = edge[0].verts[0]
                edge_v1 = edge[0].verts[1]

                for e in verts:
                    if e[0] not in {edge_v0, edge_v1}:
                        single_v = e
                        break

                mat = edge_oj.matrix_world
                v0 = mat @ edge_v0.co
                v1 = mat @ edge_v1.co
                #
            elif ll_edges == 2:
                e0, e1 = edges
                e0_verts = e0[0].verts
                e1_verts = e1[0].verts
                if e0_verts[0] in e1_verts:
                    v_common = e0_verts[0]
                    v0 = e0[1].matrix_world @ e0_verts[1].co
                else:
                    v_common = e0_verts[1]
                    v0 = e0[1].matrix_world @ e0_verts[0].co

                v1 = e1[1].matrix_world @ (e1_verts[0].co if e1_verts[1] == v_common else e1_verts[0])
                single_v = (v_common, e0[1])
            else:
                last_v = self.R_last_vert(data)
                if last_v is None:
                    single_v = verts[-1]
                    v0 = verts[0][1].matrix_world @ verts[0][0].co
                    v1 = verts[1][1].matrix_world @ verts[1][0].co
                else:
                    vs = []
                    for e in verts:
                        if e[0] == last_v:  single_v = e
                        else:               vs.append(e)

                    v0 = vs[0][1].matrix_world @ vs[0][0].co
                    v1 = vs[1][1].matrix_world @ vs[1][0].co

            act = self.R_act_vert(data, self.w.props)
            org_pos = None
            if act is not None and act == single_v[0]:  org_pos = act.co.copy()

            sv = single_v[1].matrix_world @ single_v[0].co
            nor = R_face_normal([sv, v0, v1]).normalized()
            if nor.length == 0.0: return
            vec_h = (v1 - v0).cross(nor)
            pos = intersect_line_plane(sv, sv + vec_h, v0, vec_h)
            if pos is None: return
            single_v[0].co[:] = single_v[1].matrix_world.inverted() @ pos

            if org_pos is not None:
                offset = org_pos - act.co
                for e in verts: e[0].co += offset

            for o in data["bms"]:   o.data.update()
            m.undo_str = '[Mesh Editor] Make Collinear'
            m.undo_push()
        except: pass
    #
    #
class BL_ANGLE(BL_CLS):
    __slots__ = ()
    def init(self, w):
        self.oo = {
            "rad":      VBOX(self, "rad", "Included Angle", self.bufn_rad, details=INFO(
                "Included Angle", "Included angle [0, π] in radians between 2 edges. If 3 vertices selected, the angle will be based on the second selected vertex.\nWhen modifying the angle, the last selected vertex will move and maintain the length from the second vertex."
            )),
            "deg":      VBOX(self, "deg", "", self.bufn_deg, offset_x_key=16, details=INFO(
                "Included Angle", "Included angle [0, 180] in degrees between 2 edges. If 3 vertices selected, the angle will be based on the second selected vertex.\nWhen modifying the angle, the last selected vertex will move and maintain the length from the second vertex."
            )),
        }
        self.oo["deg"].tx_format = R_str_by_deg
        self.hi = F[3]*2 + F[16]
        #
    def get_bo(self, L, R, T, x, x1):
        self.rim.LRBT_upd(L, R, T - self.hi, T)

        oo = self.oo
        bu_hi = F[16]
        T -= F[3]
        oo["rad"].LRBT(x, x1, T - bu_hi, T)
        x2 = x1 + F[2]
        oo["deg"].LRBT(x2, x2 + x1 - x, T - bu_hi, T)

    def R_angle_2_edges(self, is_local, all_edges):
        e0, e1 = all_edges
        e0_v0, e0_v1 = e0[0].verts
        e1_v0, e1_v1 = e1[0].verts

        if e0_v0 == e1_v0:
            v0 = e0_v1
            v1 = e0_v0
            v2 = e1_v1
        elif e0_v0 == e1_v1:
            v0 = e0_v1
            v1 = e0_v0
            v2 = e1_v0
        elif e0_v1 == e1_v0:
            v0 = e0_v0
            v1 = e0_v1
            v2 = e1_v1
        else:
            v0 = e0_v0
            v1 = e0_v1
            v2 = e1_v0

        if is_local:
            v0_co = v0.co
            v1_co = v1.co
            v2_co = v2.co
        else:
            mat = e0[1].matrix_world
            v0_co = mat @ v0.co
            v1_co = mat @ v1.co
            v2_co = mat @ v2.co

        return R_angle(v0_co, v1_co, v2_co)
        #
    def R_v012_2_edges(self, data, is_local, all_edges):
        e0, e1 = all_edges
        e0_v0, e0_v1 = e0[0].verts
        e1_v0, e1_v1 = e1[0].verts

        if e0_v0 == e1_v0:
            v0 = e0_v1
            v1 = e0_v0
            v2 = e1_v1
        elif e0_v0 == e1_v1:
            v0 = e0_v1
            v1 = e0_v0
            v2 = e1_v0
        elif e0_v1 == e1_v0:
            v0 = e0_v0
            v1 = e0_v1
            v2 = e1_v1
        else:
            v0 = e0_v0
            v1 = e0_v1
            v2 = e1_v0

        if self.R_last_vert(data) == v0:    v0, v2 = v2, v0

        if is_local:
            v0_co = v0.co.copy()
            v1_co = v1.co.copy()
            v2_co = v2.co.copy()
        else:
            mat = e0[1].matrix_world
            v0_co = mat @ v0.co
            v1_co = mat @ v1.co
            v2_co = mat @ v2.co

        return [v0, v1, v2], [v0_co, v1_co, v2_co], mat.inverted()
        #
    def R_angle_3_verts(self, data, is_local, verts):
        if is_local:
            v0_co = verts[0][0].co
            v1_co = verts[1][0].co
            v2_co = verts[2][0].co
        else:
            v0_co = verts[0][1].matrix_world @ verts[0][0].co
            v1_co = verts[1][1].matrix_world @ verts[1][0].co
            v2_co = verts[2][1].matrix_world @ verts[2][0].co

        last_v, last_v1 = self.R_last_2vert(data)
        if last_v == verts[0][0]:
            if last_v1 == verts[2][0]:
                v0_co, v1_co, v2_co = v1_co, v2_co, v0_co
            else:
                v0_co, v2_co = v2_co, v0_co
        elif last_v == verts[1][0]:
            if last_v1 == verts[0][0]:
                v0_co, v1_co, v2_co = v2_co, v0_co, v1_co
            else:
                v1_co, v2_co = v2_co, v1_co
        elif last_v1 == verts[0][0]:
            v0_co, v1_co = v1_co, v0_co

        return R_angle(v0_co, v1_co, v2_co)
        #
    def R_v012_3_verts(self, data, is_local, verts):
        v0, v1, v2 = verts

        last_v, last_v1 = self.R_last_2vert(data)
        if last_v == v0[0]:
            if last_v1 == v2[0]:    v0, v1, v2 = v1, v2, v0
            else:                   v0, v2 = v2, v0
        elif last_v == v1[0]:
            if last_v1 == v0[0]:    v0, v1, v2 = v2, v0, v1
            else:                   v1, v2 = v2, v1
        elif last_v1 == v0[0]:
            v0, v1 = v1, v0

        if is_local:
            v0_co = v0[0].co.copy()
            v1_co = v1[0].co.copy()
            v2_co = v2[0].co.copy()
        else:
            v0_co = v0[1].matrix_world @ v0[0].co
            v1_co = v1[1].matrix_world @ v1[0].co
            v2_co = v2[1].matrix_world @ v2[0].co

        return [v0[0], v1[0], v2[0]], [v0_co, v1_co, v2_co], v2[1].matrix_world.inverted()
        #
    def upd_data(self):
        data = self.w.mesh_data
        oo_deg = self.oo["deg"]
        oo_rad = self.oo["rad"]
        if "ll_verts" not in data or data["ll_verts"] != 3:
            if oo_rad.is_enable is True:
                oo_deg.disable()
                oo_rad.disable()
            return
        if oo_rad.is_enable is False:
            oo_deg.enable()
            oo_rad.enable()

        is_local = self.w.props["mesh_ed_local"]

        if data["ll_edges"] == 2:   an = self.R_angle_2_edges(is_local, self.R_all_edges(data))
        else:                       an = self.R_angle_3_verts(data, is_local, self.R_all_verts(data))

        oo_deg.set_da(degrees(an))
        oo_rad.set_da(an)
    def bufn_deg(self, v, undo_push=True):
        try:    v = radians(v)
        except: return
        self.bufn_rad(v, undo_push=undo_push)
    def bufn_rad(self, v, undo_push=True):
        try:
            data = self.w.mesh_data
            if "ll_verts" not in data or data["ll_verts"] != 3: return
            props = self.w.props
            is_local = props["mesh_ed_local"]
            quick_edit_state, TEMP = self.R_quick_edit_state()

            if quick_edit_state == 2:
                u_nor = TEMP["u_nor"]
                u_pos = TEMP["u_pos"]
                org_co_glo = TEMP["org_co_glo"]
                verts = TEMP["verts"]
                length = TEMP["length"]
                org_pos = TEMP["org_pos"]
                mat_inv = TEMP["mat_inv"]
                #
            elif quick_edit_state in {0, 1}:
                if data["ll_edges"] == 2:
                    verts, org_co_glo, mat_inv = self.R_v012_2_edges(data, is_local, self.R_all_edges(data))
                else:
                    verts, org_co_glo, mat_inv = self.R_v012_3_verts(data, is_local, self.R_all_verts(data))

                org_pos = [verts[0].co.copy(), verts[1].co.copy(), verts[2].co.copy()]
                u_nor = R_face_normal(org_co_glo).normalized()
                u_pos = (org_co_glo[0] - org_co_glo[1]).normalized()
                length = (org_co_glo[1] - org_co_glo[2]).length

                if u_nor == Vector():   u_nor = Vector((0.0, 0.0, 1.0))
                if TEMP is not None:
                    TEMP["u_nor"] = u_nor
                    TEMP["u_pos"] = u_pos
                    TEMP["org_co_glo"] = org_co_glo
                    TEMP["verts"] = verts
                    TEMP["length"] = length
                    TEMP["org_pos"] = org_pos
                    TEMP["mat_inv"] = mat_inv
            else:
                if undo_push:
                    m.undo_str = f'[Mesh Editor] Included Angle = {v}'
                    m.undo_push()
                return

            u_vec0, u_vec1 = R_u_pos_by_angle(u_pos, u_nor, v)
            pos0 = length * u_vec0 + org_co_glo[1]
            pos1 = length * u_vec1 + org_co_glo[1]
            an_0 = R_angle(org_co_glo[2], org_co_glo[1], pos0)
            an_1 = R_angle(org_co_glo[2], org_co_glo[1], pos1)

            if v % tau < pi:   new_pos = pos0 if an_0 < an_1 else pos1
            else:              new_pos = pos1 if an_0 < an_1 else pos0

            v2 = verts[2]
            if not is_local:    new_pos = mat_inv @ new_pos
            act_v = self.R_act_vert(data, props)
            if act_v == v2:
                offset = org_pos[2] - new_pos
                new_pos += offset
                verts[0].co[:] = org_pos[0] + offset
                verts[1].co[:] = org_pos[1] + offset
            else:
                v2.co[:] = new_pos

            for o in data["bms"]:   o.data.update()
            if undo_push:
                m.undo_str = f'[Mesh Editor] Included Angle = {v}'
                m.undo_push()
        except: pass