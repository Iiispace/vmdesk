from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP
from bgl import glEnable, glDisable, GL_BLEND, GL_SCISSOR_TEST, glScissor

from .. import m
from .. bu_block import get_block, TI_DATA, STRING_SET, KM, KM2, KM_SEL, STR_SIM

P = None
F = None
K = None
BOX = None
BLF = None
font_0 = None

class FOBOX:
    __slots__ = 'w', 'act_bo'
    def __init__(self, w):
        self.w = w
        self.act_bo = None
    def draw(self):
        m.bind_color_setting_bo_fo()
        self.act_bo.draw()


class SYSTEM:
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'key_end',
        'bo',
        'ti',
        'da',
        'sci',
        'color_ti',
        'color_da',
        'fobox',
        'tm_L',
        'tm_R',
        'tm_B',
        'tm_T',
        'bo_keys',
    )
    def R_name(self): return "System", SYSTEM
    def get_data(self):
        bo_keys = [
            "Display",
            "Control",
            "Menu",
            "Expression",
            "About",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Display":      BLF(text="Window position, Task bar, Enable function", size=DISPLAY),
            "Control":      BLF(text="Scroll speed, Drag threshold, Auto Pan speed", size=CONTROL),
            "Menu":         BLF(text="Drop Down Menu behavior, Format, Properties Box", size=MENU),
            "Expression":   BLF(text="Calculator expressions and button functions", size=EXPRESSION),
            "About":        BLF(text="Information, Support and help", size=ABOUT),
        }
    def __init__(self, w):
        self.w = w
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.U_draw         = self.I_draw
        self.color_ti       = P.color_font
        self.color_da       = P.color_font_darker
        self.sci            = m.SCISSOR()
        self.upd_sci()

        self.get_data()
        bo = self.bo
        ti = self.ti
        da = self.da
        self.fobox = FOBOX(self)

        d       = F[2]
        dT      = F[17]
        dB      = F[8]
        # dL      = F[8]
        bo_wi   = F[38]
        L0, R0, B0, T0  = w.bo["data"].R_LRBT()
        L1  = L0 + d
        R1  = R0 - d
        T   = T0 - d

        for k in self.bo_keys:
            e = bo[k]
            e.LRBT(L1, R1, T - bo_wi, T)
            e.upd()
            ti[k].LT(e, dB, dT)
            da[k].LB(e, dB, dB)
            T = e.B - d

        paths = w.paths
        paths.kill()
        if hasattr(self, "R_names"):
            for e in self.R_names():    paths.new(*e)
        else:
            paths.new(*self.R_name())

        self.upd_data()

    def dxy_upd(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)

        self.upd_sci()

    def upd_sci(self):
        sci         = self.sci
        wsci        = self.w.sci
        L, R, B, T  = self.w.bo["data"].R_LRBT()
        sci.x       = max(L, wsci.x)
        sci.w       = max(0, min(R, wsci.x + wsci.w) - sci.x)
        sci.y       = max(B, wsci.y)
        sci.h       = max(0, min(T, wsci.y + wsci.h) - sci.y)

    def unfocus(self):
        if self.fobox.act_bo != None:
            self.fobox.act_bo = None
            m.redraw()

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        if K["me_pan0"].true():
            self.key_end = K["me_pan_E0"]
            self.to_modal_pan(evt)
            return True
        if K["me_pan1"].true():
            self.key_end = K["me_pan_E1"]
            self.to_modal_pan(evt)
            return True

        for k, e in self.bo.items():
            if e.inbox_xy(x, y):
                if self.fobox.act_bo != e:
                    self.fobox.act_bo = e
                    m.redraw()
                if K["sel_fast0"].true() or K["sel_fast1"].true():
                    self.to_subtab(k)
                    return True
                return False

        self.unfocus()
        return False

    def to_subtab(self, name):
        print(f"    setting_data  to_subtab")
        m.EVT.kill()
        m.redraw()
        w = self.w
        w.A_data = self.da[name].size(w)
        w.A_data.upd_data()

    def to_modal_pan(self, evt):
        print(f"    setting_data  to_modal_pan")
        self.fobox.act_bo = None
        m.redraw()

        _2 = F[2]
        sci = self.sci
        bo = self.bo[self.bo_keys[0]]
        self.tm_L = sci.x + _2
        self.tm_R = sci.x + sci.w - _2 - bo.R_w()
        self.tm_T = sci.y + sci.h - _2
        self.tm_B = sci.y + len(self.bo) * (bo.R_h() + _2)
        if self.tm_B < self.tm_T:   self.tm_B = self.tm_T

        self.key_end.true()
        m.head_modal.append(self.I_modal_pan)
        m.U_pan_cursor(self, evt)
        rim = self.w.resize_rim
        m.get_loop_mou_info_region(evt, rim.L, rim.R, rim.B, rim.T)
        m.get_mou(evt)
    def I_modal_pan(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                print(f"    setting_data  I_modal_pan  END")
                del m.head_modal[-1]
                m.U_end_pan(self)
                m.init_wait_release()
                self.w.I_upd_data()
                m.redraw()
                return
        m.U_pan(evt)

        dx = m.dx
        dy = m.dy
        bo = self.bo[self.bo_keys[0]]

        L = bo.L + dx
        T = bo.T + dy
        if L > self.tm_L:   dx = self.tm_L - bo.L
        elif L < self.tm_R: dx = self.tm_R - bo.L

        if T > self.tm_B:   dy = self.tm_B - bo.T
        elif T < self.tm_T: dy = self.tm_T - bo.T

        for e in self.bo.values():  e.dxy_upd(dx, dy)
        for e in self.ti.values():  e.dxy(dx, dy)
        for e in self.da.values():  e.dxy(dx, dy)

        m.loop_mou(evt)
        m.redraw()

    def I_draw(self):
        glEnable(GL_BLEND)
        self.sci.use()
        m.bind_color_setting_bo()
        for e in self.bo.values():  e.draw()
        if self.fobox.act_bo is not None:   self.fobox.draw()

        blf_size(font_0, F[12], 72)
        blf_color(font_0, *self.color_ti)
        for e in self.ti.values():  e.draw_pos()
        blf_size(font_0, F[8], 72)
        blf_color(font_0, *self.color_da)
        for e in self.da.values():  e.draw_pos()

    def upd_data(self):
        _2 = F[2]
        sci = self.sci
        bo = self.bo[self.bo_keys[0]]
        self.tm_L = sci.x + _2
        self.tm_R = sci.x + sci.w - _2 - bo.R_w()
        self.tm_T = sci.y + sci.h - _2
        self.tm_B = sci.y + len(self.bo) * (bo.R_h() + _2)
        if self.tm_B < self.tm_T:   self.tm_B = self.tm_T

        dx = 0
        dy = 0
        L = bo.L
        T = bo.T
        if L > self.tm_L:   dx = self.tm_L - L
        elif L < self.tm_R: dx = self.tm_R - L

        if T > self.tm_B:   dy = self.tm_B - T
        elif T < self.tm_T: dy = self.tm_T - T

        if dx or dy:
            for e in self.bo.values():  e.dxy_upd(dx, dy)
            for e in self.ti.values():  e.dxy(dx, dy)
            for e in self.da.values():  e.dxy(dx, dy)
        #
class EXPRESSION(SYSTEM):
    __slots__ = ()
    def R_names(self): return ("System", SYSTEM), self.R_name()
    def R_name(self): return "Expression", EXPRESSION
    def get_data(self):
        bo_keys = [
            "Buttons",
            "Function",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Buttons":      BLF(text="Calculator button names and expressions", size=BUTTONS),
            "Function":     BLF(text="Definition and information", size=FUNCTION),
        }
class PERSONALIZATION(SYSTEM):
    __slots__ = ()
    def R_name(self): return "Personalization", PERSONALIZATION
    def get_data(self):
        bo_keys = [
            "Taskbar",
            "Windows",
            "Icon",
            "Font",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Taskbar":      BLF(text="Taskbar appearance and color", size=TASKBAR),
            "Windows":      BLF(text="Windows appearance and color", size=WINDOWS),
            "Icon":         BLF(text="Icon appearance and color", size=ICON),
            "Font":         BLF(text="Font appearance and color", size=FONT),
        }
class APPS(SYSTEM):
    __slots__ = ()
    def R_name(self): return "Apps", APPS
    def get_data(self):
        bo_keys = [
            "Modifier Editor",
            "Driver Editor",
            "Mesh Editor",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Modifier Editor":  BLF(text="Editor settings", size=MODIFIER_EDITOR),
            "Driver Editor":    BLF(text="Editor settings", size=DRIVER_EDITOR),
            "Mesh Editor":      BLF(text="Editor settings", size=MESH_EDITOR),
        }
class ADDON_KEYMAP(SYSTEM):
    __slots__ = ()
    def R_name(self): return "Addon Keymap", ADDON_KEYMAP
    def get_data(self):
        bo_keys = [
            "Global",
            "Modifier Editor",
            "Dropdown Menu",
            "Color Panel",
            "Context Menu",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Global":           BLF(text="Global keys", size=GLOBAL),
            "Modifier Editor":  BLF(text="Built-in application", size=MD_EDITOR),
            "Dropdown Menu":    BLF(text="Dropdown Menu and Text", size=DROPDOWN_MENU),
            "Color Panel":      BLF(text="Color Panel and Picker", size=COLOR_PANEL),
            "Context Menu":     BLF(text="Right click Menu", size=CONTEXT_MENU),
        }
class BLENDER_KEYMAP(SYSTEM):
    __slots__ = ()
    def R_name(self): return "Blender Keymap", BLENDER_KEYMAP
    def get_data(self):
        bo_keys = [
            "In development",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "In development":  BLF(text="In development", size=BLENDER_KEYMAP),
        }


class DISPLAY:
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'sci',
        'oo',
        'max_ind',
        'li',
        'key_end',
        'tm_L',
        'tm_R',
        'tm_B',
        'tm_T',
        'tm_pan_h',
        'tm_1',
        'pref_keys',
        'dic_key_ind',
        'props',
        'ref_L',
        'ref_R',
        'headkey',
        'endkey',
        'color_ti',
        'color_da',
        'color_bool',
        'tx_wi',
        'hi',
        'li_h',
        'last_fo',
        'custom_subtype',
    )
    def R_names(self): return ("System", SYSTEM), self.R_name()
    def R_name(self): return "Display", DISPLAY
    def get_data(self):
        self.pref_keys = [
            "win_pos_init",
            "win_size_init",
            "win_size_init_DE",
            "win_size_init_ME",
            "scale",
            "scale_ti_bu",
            "ti_font_size",
            "win_border",
            "win_border_inner",
            "win_offset_init",
            "win_offset_top",
            "win_shade_on",
            "win_shade_offset",
            "win_shade_softness",
            "win_shade_color",
            "dd_shade_offset",
            "dd_shade_softness",
            "dd_shade_color",
            "anim_tb_task",
            "anim_win_min",
            "anim_win_fit",
            "anim_win_x",
            "cursor_thickness",
            "cursor_flash_rate",
            "quick_edit_cursor",
            "dd_num_type",
            "dd_width",
            "anim_frame_time",
            "anim_speed",
            "auto_pan_speed",
        ]
        self.custom_subtype = {
            "scale": ("Global", "Title"),
            "win_shade_offset": ("Left", "Right", "Bottom", "Top"),
            "dd_shade_offset": ("Left", "Right", "Bottom", "Top"),
            "cursor_flash_rate": ("2 sec",),
        }
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.color_ti       = P.color_font
        self.color_da       = P.color_font_darker
        self.color_bool     = P.color_bu_2
        self.sci            = m.SCISSOR()
        self.upd_sci()
        props               = P.bl_rna.properties
        self.props          = props
        self.tx_wi          = F[110]*2

        self.get_data()
        pref_keys = self.pref_keys
        dic_key_ind = {k : i  for i, k in enumerate(pref_keys)}
        self.dic_key_ind = dic_key_ind
        blf_size(font_0, F[8], 72)
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.tx_wi)

        oo = {r: get_block(self, props[name])  if isinstance(name, str) else name
            for r, name in enumerate(pref_keys)}
        self.oo = oo
        for k, e in self.custom_subtype.items():    oo[dic_key_ind[k]].get_custom_subtype(e)
        blf_disable(font_0, WORD_WRAP)

        li = {}
        self.li = li

        bo_data = w.bo["data"]
        _1 = F[1]

        L = bo_data.L + _1
        R = bo_data.R - _1
        T = bo_data.T - _1
        self.ref_L = L
        self.ref_R = R

        hi_max = bo_data.R_h()
        self.hi = hi_max
        hi = _1
        for r in range(len(oo)):
            e = oo[r]
            e.get_bo(L, R, T)
            li[r] = e
            hi += e.hi + _1
            if hi >= hi_max:    break
            T = e.rim.B - _1

        self.li_h = hi - _1 - _1
        self.max_ind = len(oo) - 1
        self.headkey = 0
        self.endkey = len(li) - 1
        self.last_fo = None
        print(f"    setting_data  DISPLAY  __init__:  last key={li[self.endkey].ti.text}")
        paths = w.paths
        paths.kill()
        if hasattr(self, "R_names"):
            for e in self.R_names():    paths.new(*e)
        else:
            paths.new(*self.R_name())

        self.upd_data()

    def R_li_hi(self):
        hi = 0
        _1 = F[1]
        for e in self.li.values():
            hi += e.hi + _1
        return hi - _1
    def dxy_upd(self, x, y):
        for e in self.li.values():  e.dxy(x, y)

        self.upd_sci()
    def upd_sci(self):
        sci         = self.sci
        wsci        = self.w.sci
        L, R, B, T  = self.w.bo["data"].R_LRBT()
        sci.x       = max(L, wsci.x)
        sci.w       = max(0, min(R, wsci.x + wsci.w) - sci.x)
        sci.y       = max(B, wsci.y)
        sci.h       = max(0, min(T, wsci.y + wsci.h) - sci.y)
    def unfocus(self):
        if self.last_fo is not None:
            self.last_fo.unfocus()
            self.last_fo = None

    def I_modal_main(self, evt):
        y = evt.mouse_region_y

        if K["me_pan0"].true():
            self.key_end = K["me_pan_E0"]
            self.to_modal_pan(evt)
            return True
        if K["me_pan1"].true():
            self.key_end = K["me_pan_E1"]
            self.to_modal_pan(evt)
            return True

        for e in self.li.values():
            if e.rim.in_BT_y(y):
                if self.last_fo != e:
                    if self.last_fo is not None:    self.last_fo.unfocus()
                    self.last_fo = e
                return e.I_modal_main(evt)
        self.unfocus()
        return False

    def to_modal_pan(self, evt):
        print(f"    setting_data  to_modal_pan")
        m.redraw()

        _1 = F[1]
        sci = self.sci
        self.tm_L = sci.x + _1
        self.tm_R = sci.x + sci.w - _1
        self.tm_T = sci.y + sci.h - _1
        self.tm_B = sci.y + _1
        self.tm_pan_h = self.li_h > self.tm_T - self.tm_B
        self.tm_1 = _1

        self.key_end.true()
        m.head_modal.append(self.I_modal_pan)
        m.U_pan_cursor(self, evt)
        rim = self.w.resize_rim
        m.get_loop_mou_info_region(evt, rim.L, rim.R, rim.B, rim.T)
        m.get_mou(evt)
    def modal_pan_end(self):
        print(f"    setting_data  modal_pan_end")
        del m.head_modal[-1]
        m.U_end_pan(self)
        m.init_wait_release()
        self.w.I_upd_data()
        m.redraw()
    def I_modal_pan(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_pan_end()
                return
        m.U_pan(evt)

        dx = m.dx
        dy = m.dy
        li = self.li
        bo0 = li[self.headkey].rim

        if dx < 0:
            R = bo0.R + dx
            if R < self.tm_R:   dx -= R - self.tm_R
        else:
            L = bo0.L + dx
            if L > self.tm_L:   dx -= L - self.tm_L

        if dy < 0:
            headkey = self.headkey
            T = bo0.T + dy
            if headkey == 0:
                if T < self.tm_T:   dy -= T - self.tm_T
            else:
                tm_T = self.tm_T
                if T < tm_T:
                    oo = self.oo
                    endkey = self.endkey
                    L = bo0.L
                    R = bo0.R
                    _1 = self.tm_1

                    while headkey != 0:
                        print("    setting_data  I_modal_pan  while headkey != 0:")
                        print("        add top")
                        blf_size(font_0, F[8], 72)
                        B = li[headkey].rim.T + _1
                        headkey -= 1
                        e = oo[headkey]
                        e.get_bo(L, R, B + e.hi)
                        for o in e.oo:  o.setter()
                        li[headkey] = e
                        T += e.hi + _1
                        if T >= tm_T:   break

                    if headkey == 0:
                        T = li[headkey].rim.T + dy
                        if T < tm_T:    dy -= T - tm_T

                    T0 = li[endkey].rim.T + dy
                    while T0 < self.tm_B:
                        print("    setting_data  I_modal_pan  while T0 < self.tm_B:")
                        print("        remove bottom")
                        del li[endkey]
                        endkey -= 1
                        T0 = li[endkey].rim.T + dy

                    self.headkey = headkey
                    self.endkey = endkey
                    print(f"    setting_data  I_modal_pan:  headkey={headkey}, endkey={endkey}")
        elif self.tm_pan_h:
            endkey = self.endkey
            bo1 = li[endkey].rim
            B = bo1.B + dy
            if endkey == self.max_ind:
                if B > self.tm_B:   dy -= B - self.tm_B
            else:
                tm_B = self.tm_B
                if B > tm_B:
                    oo = self.oo
                    headkey = self.headkey
                    max_ind = self.max_ind
                    L = bo1.L
                    R = bo1.R
                    _1 = self.tm_1

                    while endkey != max_ind:
                        print("    setting_data  I_modal_pan  while endkey != max_ind:")
                        print("        add bottom..")
                        blf_size(font_0, F[8], 72)
                        T = li[endkey].rim.B - _1
                        endkey += 1
                        e = oo[endkey]
                        e.get_bo(L, R, T)
                        for o in e.oo:  o.setter()
                        li[endkey] = e
                        B -= e.hi + _1
                        if B <= tm_B:   break

                    if endkey == max_ind:
                        B = li[endkey].rim.B + dy
                        if B > tm_B:    dy -= B - tm_B

                    B0 = bo0.B + dy
                    while B0 > self.tm_T:
                        print("    setting_data  I_modal_pan  while B0 > self.tm_T:")
                        print("        remove top..")
                        del li[headkey]
                        headkey += 1
                        B0 = li[headkey].rim.B + dy

                    self.headkey = headkey
                    self.endkey = endkey
                    print(f"    setting_data  I_modal_pan:  headkey={headkey}, endkey={endkey}")
        else:
            dy = 0

        for e in li.values():  e.dxy(dx, dy)

        m.loop_mou(evt)
        m.redraw()

    def I_draw(self):
        glEnable(GL_BLEND)
        self.sci.use()
        li_values = self.li.values()

        m.bind_color_setting_bo()
        for e in li_values:     e.draw_bo()

        for e in li_values:     e.draw_oo_bo()

        blf_size(font_0, F[12], 72)
        blf_color(font_0, *self.color_ti)
        for e in li_values:     e.draw_ti()

        blf_size(font_0, F[9], 72)
        for e in li_values:     e.draw_oo_da()

        blf_size(font_0, F[8], 72)
        blf_color(font_0, *self.color_da)
        for e in li_values:     e.draw_da()
        for e in li_values:     e.draw_oo_ti()

        blf_color(font_0, *self.color_bool)
        blf_size(font_0, F[22], 72)
        for e in li_values:     e.draw_oo_bool()

    def upd_data(self):
        print(f"    setting_data  upd_data  A_data update")
        li = self.li
        sci = self.sci
        _1 = F[1]
        dx = 0
        dy = 0
        rim = li[self.headkey].rim
        if rim.T < sci.R_T() - _1:
            tm_T = sci.R_T() - _1
            oo = self.oo
            headkey = self.headkey
            L = rim.L
            R = rim.R
            while headkey != 0:
                B = li[headkey].rim.T + _1
                headkey -= 1
                e = oo[headkey]
                e.get_bo(L, R, B + e.hi)
                li[headkey] = e
                if e.rim.T >= tm_T: break

            if li[headkey].rim.T < tm_T:
                dy = tm_T - li[headkey].rim.T

            B = li[self.endkey].rim.B + dy
            if B > sci.y + _1:
                tm_B = sci.y + _1
                endkey = self.endkey
                max_ind = self.max_ind
                while endkey != max_ind:
                    T = li[endkey].rim.B - _1
                    endkey += 1
                    e = oo[endkey]
                    e.get_bo(L, R, T)
                    li[endkey] = e
                    B -= e.hi + _1
                    if B <= tm_B: break
                self.endkey = endkey

            self.headkey = headkey
            print(f"    setting_data  upd_data  auto pan:  len={len(li)}")
        elif li[self.endkey].rim.B > sci.y + _1:
            tm_B = sci.y + _1
            oo = self.oo
            endkey = self.endkey
            L = rim.L
            R = rim.R
            max_ind = self.max_ind
            while endkey != max_ind:
                T = li[endkey].rim.B - _1
                endkey += 1
                e = oo[endkey]
                e.get_bo(L, R, T)
                li[endkey] = e
                if e.rim.B <= tm_B: break

            B = li[endkey].rim.B
            if B > tm_B:
                dy = tm_B - B
                headkey = self.headkey
                T = rim.T + dy
                if T < sci.R_T() - _1:
                    tm_T = sci.R_T() - _1
                    while headkey != 0:
                        T += e.hi + _1
                        headkey -= 1
                        e = oo[headkey]
                        e.get_bo(L, R, T)
                        if T >= tm_T:   break

                    self.headkey = headkey

                    if T < tm_T:    dy += tm_T - T

            self.endkey = endkey
            print(f"    setting_data  upd_data  auto pan:  len={len(li)}")

        if rim.L > sci.x + _1:          dx = sci.x + 1 - rim.L
        elif rim.R < sci.R_R() - _1:    dx = sci.R_R() - _1 - rim.R

        if dx or dy:
            for e in li.values():   e.dxy(dx, dy)

        self.upd_oo()
    def upd_oo(self):
        for e in self.li.values():
            for o in e.oo:  o.setter()
        #
class CONTROL(DISPLAY):
    __slots__ = ()
    def R_name(self): return "Control", CONTROL
    def get_data(self):
        self.pref_keys = [
            "lock_win_size",
            "sys_auto_off",
            "sync_act_oj",
            "sync_act_md",
            "auto_sel_text",
            "auto_del_text",
            "confirm_rename",
            "confirm_del",
            "confirm_apply",
            "pan_method",
            "win_pos_protect",
            "quick_edit_method",
            "quick_edit_operation",
            "quick_edit_fac_slow",
            "quick_edit_fac_fast",
            "calc_13iqe",
            "calc_01fqe",
            "calc_0ifqe",
            "calc_0pfqe",
            "calc_0dfqe",
            "quick_edit_fac_slow_hue",
            "quick_edit_fac_fast_hue",
            "filter_algorithm",
            "th_drag",
            "th_multi_drag",
            "scroll_fac",
            "bu_auto_speed",
            "bu_auto_time",
        ]
        self.custom_subtype = {
            "th_drag": ("px",),
            "th_multi_drag": ("px",),
            "scroll_fac": ("px",),
            "bu_auto_speed": ("sec",),
            "bu_auto_time": ("sec",),
        }
        #
class MENU(DISPLAY):
    __slots__ = ()
    def R_name(self): return "Menu", MENU
    def get_data(self):
        self.pref_keys = [
            "dd_shade_offset",
            "dd_shade_softness",
            "dd_shade_color",
            "auto_sel_text",
            "auto_del_text",
            "cursor_thickness",
            "cursor_flash_rate",
            "dd_num_type",
            "dd_width",
            "quick_edit_method",
            "quick_edit_operation",
            "quick_edit_cursor",
            "quick_edit_fac_slow",
            "quick_edit_fac_fast",
            "calc_13iqe",
            "calc_01fqe",
            "calc_0ifqe",
            "calc_0pfqe",
            "calc_0dfqe",
            "quick_edit_fac_slow_hue",
            "quick_edit_fac_fast_hue",
            "filter_algorithm",
            "format_tx_f",
            "format_tx_i",
            "format_tx_h",
            "format_tx_vec",
            "vbox_precise_mode",
        ]
        self.custom_subtype = {
            "dd_shade_offset": ("Left", "Right", "Bottom", "Top"),
            "cursor_flash_rate": ("2 sec",),
        }
class ABOUT(DISPLAY):
    __slots__ = ()
    def R_name(self): return "About", ABOUT
    def get_data(self):
        hi = F[38]
        self.pref_keys = [
            TI_DATA(self, hi, "Addon Version", "22.11 Trial"),
            STR_SIM(self, "Bug Report", "E-mail", "oorcer.gmail.com"),
            STR_SIM(self, "Donations", "PayPal", "paypal.me/oorc"),
        ]
        self.custom_subtype = {}
class BUTTONS(DISPLAY):
    __slots__ = ()
    def R_names(self): return ("System", SYSTEM), ("Expression", EXPRESSION), self.R_name()
    def R_name(self): return "Buttons", BUTTONS
    def get_data(self):
        props = self.props
        hi = F[38]
        hi2 = F[52]
        hi3 = F[16]
        wi = F[110] + F[150]
        depth = F[2]
        e = ("Name", "Expression")

        self.pref_keys = [
            TI_DATA(self, hi, "Calculator Buttons : int", "Button function, Integer"),
            STRING_SET(self, props, ("calc_13i1", "calc_13i1ex"), e, wi, hi2, depth, da="1"),
            STRING_SET(self, props, ("calc_13i2", "calc_13i2ex"), e, wi, hi2, depth, da="2"),
            STRING_SET(self, props, ("calc_13i3", "calc_13i3ex"), e, wi, hi2, depth, da="3"),
            STRING_SET(self, props, ("calc_13i4", "calc_13i4ex"), e, wi, hi2, depth, da="4"),
            STRING_SET(self, props, ("calc_13i5", "calc_13i5ex"), e, wi, hi2, depth, da="5"),
            STRING_SET(self, props, ("calc_13i6", "calc_13i6ex"), e, wi, hi2, depth, da="6"),
            STRING_SET(self, props, ("calc_13i7", "calc_13i7ex"), e, wi, hi2, depth, da="7"),
            STRING_SET(self, props, ("calc_13i8", "calc_13i8ex"), e, wi, hi2, depth, da="8"),
            STRING_SET(self, props, ("calc_13i9", "calc_13i9ex"), e, wi, hi2, depth, da="9"),
            STRING_SET(self, props, ("calc_13i10", "calc_13i10ex"), e, wi, hi2, depth, da="10"),
            STRING_SET(self, props, ("calc_13i11", "calc_13i11ex"), e, wi, hi2, depth, da="11"),
            STRING_SET(self, props, ("calc_13i12", "calc_13i12ex"), e, wi, hi2, depth, da="12"),
            TI_DATA(self, hi3, "", ""),

            TI_DATA(self, hi, "Calculator Buttons : float [0, 1]", "Button function, 0 ≦ value ≦ 1"),
            STRING_SET(self, props, ("calc_01f1", "calc_01f1ex"), e, wi, hi2, depth, da="1"),
            STRING_SET(self, props, ("calc_01f2", "calc_01f2ex"), e, wi, hi2, depth, da="2"),
            STRING_SET(self, props, ("calc_01f3", "calc_01f3ex"), e, wi, hi2, depth, da="3"),
            STRING_SET(self, props, ("calc_01f4", "calc_01f4ex"), e, wi, hi2, depth, da="4"),
            STRING_SET(self, props, ("calc_01f5", "calc_01f5ex"), e, wi, hi2, depth, da="5"),
            STRING_SET(self, props, ("calc_01f6", "calc_01f6ex"), e, wi, hi2, depth, da="6"),
            STRING_SET(self, props, ("calc_01f7", "calc_01f7ex"), e, wi, hi2, depth, da="7"),
            STRING_SET(self, props, ("calc_01f8", "calc_01f8ex"), e, wi, hi2, depth, da="8"),
            STRING_SET(self, props, ("calc_01f9", "calc_01f9ex"), e, wi, hi2, depth, da="9"),
            STRING_SET(self, props, ("calc_01f10", "calc_01f10ex"), e, wi, hi2, depth, da="10"),
            STRING_SET(self, props, ("calc_01f11", "calc_01f11ex"), e, wi, hi2, depth, da="11"),
            STRING_SET(self, props, ("calc_01f12", "calc_01f12ex"), e, wi, hi2, depth, da="12"),
            TI_DATA(self, hi3, "", ""),

            TI_DATA(self, hi, "Calculator Buttons : float", "Button function, -3.402823 ╳ 10^38 ≦ value ≦ 3.402823 ╳ 10^38"),
            STRING_SET(self, props, ("calc_0if1", "calc_0if1ex"), e, wi, hi2, depth, da="1"),
            STRING_SET(self, props, ("calc_0if2", "calc_0if2ex"), e, wi, hi2, depth, da="2"),
            STRING_SET(self, props, ("calc_0if3", "calc_0if3ex"), e, wi, hi2, depth, da="3"),
            STRING_SET(self, props, ("calc_0if4", "calc_0if4ex"), e, wi, hi2, depth, da="4"),
            STRING_SET(self, props, ("calc_0if5", "calc_0if5ex"), e, wi, hi2, depth, da="5"),
            STRING_SET(self, props, ("calc_0if6", "calc_0if6ex"), e, wi, hi2, depth, da="6"),
            STRING_SET(self, props, ("calc_0if7", "calc_0if7ex"), e, wi, hi2, depth, da="7"),
            STRING_SET(self, props, ("calc_0if8", "calc_0if8ex"), e, wi, hi2, depth, da="8"),
            STRING_SET(self, props, ("calc_0if9", "calc_0if9ex"), e, wi, hi2, depth, da="9"),
            STRING_SET(self, props, ("calc_0if10", "calc_0if10ex"), e, wi, hi2, depth, da="10"),
            STRING_SET(self, props, ("calc_0if11", "calc_0if11ex"), e, wi, hi2, depth, da="11"),
            STRING_SET(self, props, ("calc_0if12", "calc_0if12ex"), e, wi, hi2, depth, da="12"),
            TI_DATA(self, hi3, "", ""),

            TI_DATA(self, hi, "Calculator Buttons : float [0, π]", "Button function, 0 ≦ value ≦ π"),
            STRING_SET(self, props, ("calc_0pf1", "calc_0pf1ex"), e, wi, hi2, depth, da="1"),
            STRING_SET(self, props, ("calc_0pf2", "calc_0pf2ex"), e, wi, hi2, depth, da="2"),
            STRING_SET(self, props, ("calc_0pf3", "calc_0pf3ex"), e, wi, hi2, depth, da="3"),
            STRING_SET(self, props, ("calc_0pf4", "calc_0pf4ex"), e, wi, hi2, depth, da="4"),
            STRING_SET(self, props, ("calc_0pf5", "calc_0pf5ex"), e, wi, hi2, depth, da="5"),
            STRING_SET(self, props, ("calc_0pf6", "calc_0pf6ex"), e, wi, hi2, depth, da="6"),
            STRING_SET(self, props, ("calc_0pf7", "calc_0pf7ex"), e, wi, hi2, depth, da="7"),
            STRING_SET(self, props, ("calc_0pf8", "calc_0pf8ex"), e, wi, hi2, depth, da="8"),
            STRING_SET(self, props, ("calc_0pf9", "calc_0pf9ex"), e, wi, hi2, depth, da="9"),
            STRING_SET(self, props, ("calc_0pf10", "calc_0pf10ex"), e, wi, hi2, depth, da="10"),
            STRING_SET(self, props, ("calc_0pf11", "calc_0pf11ex"), e, wi, hi2, depth, da="11"),
            STRING_SET(self, props, ("calc_0pf12", "calc_0pf12ex"), e, wi, hi2, depth, da="12"),
            TI_DATA(self, hi3, "", ""),

            TI_DATA(self, hi, "Calculator Buttons : float [0, 360]", "Button function, 0 ≦ value ≦ 360"),
            STRING_SET(self, props, ("calc_0df1", "calc_0df1ex"), e, wi, hi2, depth, da="1"),
            STRING_SET(self, props, ("calc_0df2", "calc_0df2ex"), e, wi, hi2, depth, da="2"),
            STRING_SET(self, props, ("calc_0df3", "calc_0df3ex"), e, wi, hi2, depth, da="3"),
            STRING_SET(self, props, ("calc_0df4", "calc_0df4ex"), e, wi, hi2, depth, da="4"),
            STRING_SET(self, props, ("calc_0df5", "calc_0df5ex"), e, wi, hi2, depth, da="5"),
            STRING_SET(self, props, ("calc_0df6", "calc_0df6ex"), e, wi, hi2, depth, da="6"),
            STRING_SET(self, props, ("calc_0df7", "calc_0df7ex"), e, wi, hi2, depth, da="7"),
            STRING_SET(self, props, ("calc_0df8", "calc_0df8ex"), e, wi, hi2, depth, da="8"),
            STRING_SET(self, props, ("calc_0df9", "calc_0df9ex"), e, wi, hi2, depth, da="9"),
            STRING_SET(self, props, ("calc_0df10", "calc_0df10ex"), e, wi, hi2, depth, da="10"),
            STRING_SET(self, props, ("calc_0df11", "calc_0df11ex"), e, wi, hi2, depth, da="11"),
            STRING_SET(self, props, ("calc_0df12", "calc_0df12ex"), e, wi, hi2, depth, da="12"),
        ]
        self.custom_subtype = {}
class FUNCTION(BUTTONS):
    __slots__ = ()
    def R_name(self): return "Function", FUNCTION
    def get_data(self):
        self.pref_keys = [
            TI_DATA(self, F[46], "In development", ""),
        ]
        self.custom_subtype = {}
class TASKBAR(DISPLAY):
    __slots__ = ()
    def R_names(self): return ("Personalization", PERSONALIZATION), self.R_name()
    def R_name(self): return "Taskbar", TASKBAR
    def get_data(self):
        self.pref_keys = [
            "color_tb_bg",
            "color_menu_start_bg",
            "color_mi_act",
            "color_mi_bg",
            "color_mi_bg_fo",
            "color_mi_ti",
            "color_mi_ti_off",
            "color_icon_start",
            "color_icon_start_fo",
        ]
        self.custom_subtype = {}
class WINDOWS(TASKBAR):
    __slots__= ()
    def R_name(self): return "Windows", WINDOWS
    def get_data(self):
        self.pref_keys = [
            "color_win_rim",
            "color_win",
            "color_win_unfo",
            "color_bg_fo",
            "color_ti_bar",
            "color_ti_bar_warn",
            "color_ti_bar_unfo",
            "color_ti_bu",
            "color_ti_bu_fo",
            "color_ti_bu_sh",
            "color_ti_bu_sh_hold",
            "color_ti_bu_x",
            "color_oj_info",
            "color_bg_mod",
            "color_box_mod",
            "color_box_mod_sel",
            "color_box_mod_act",
            "color_box_mod_act_rim",
            "color_mod_bu_fo",
            "color_selbox",
            "color_selbox_rim",
            "color_bu_bg",
            "color_bu_1_off",
            "color_bu_1_on",
            "color_bu_1_rim",
            "color_bu_1_fo",
            "color_bu_1_ignore",
            "color_bu_2",
            "color_bu_2_ignore",
            "color_bu_3_off",
            "color_bu_3_on",
            "color_bu_3_fo",
            "color_bu_3_ignore",
            "color_bu_4_off",
            "color_bu_4_on",
            "color_bu_4_rim",
            "color_bu_4_fo",
            "color_bu_4_ignore",
            "color_bu_media",
            "color_bu_media_fo",
            "color_bu_media_on",
            "color_bu_media_ignore",
            "color_setting_act",
            "color_setting_bo",
            "color_setting_bo_fo",
            "color_picker_bg",
            "color_picker_bg_hue",
            "color_picker_bg_hue_fo",
            "color_picker_bu",
            "color_ddmenu",
            "color_dd_actbox",
            "color_filter",
            "color_calc_bu",
            "color_scroll_rim",
            "color_scroll_rim_fo",
            "color_scroll_bar_rim",
            "color_scroll_bar_bg",
            "color_scroll_bar_fo",
            "color_tx_cursor",
            "color_tx_sel",
            "color_tx_copy",
            "color_r_menu_bg",
            "color_r_menu",
            "color_flash_box",
            "color_rm_bg",
            "color_rm_fobox",
            "color_tex_bg",
            "color_tex_main",
            "color_mesh_ed_block",
        ]
        self.custom_subtype = {}
class ICON(TASKBAR):
    __slots__= ()
    def R_name(self): return "Icon", ICON
    def get_data(self):
        self.pref_keys = [
            "color_icon_1",
            "color_icon_2",
            "color_icon_3",
            "color_icon_4",
            "color_icon_5",
            "color_icon_6",
            "color_icon_7",
            "color_icon_8",
            "color_icon_ignore",
            "color_icon_ignore2",
            "color_icon_light",
            "color_icon_start",
            "color_icon_start_fo",

            "color_bu_kf_fo",
            "color_bu_kf_yellow",
            "color_bu_kf_yellow_fo",
            "color_bu_kf_green",
            "color_bu_kf_green_fo",
            "color_bu_kf_orange",
            "color_bu_kf_orange_fo",
            "color_bu_dr",
            "color_bu_dr_fo",
            "color_mdicon_kf_off",
            "color_mdicon_dr_off",
            "color_font_rm",
            "color_font_rm_ignore",
        ]
        self.custom_subtype = {}
class FONT(TASKBAR):
    __slots__= ()
    def R_name(self): return "Font", FONT
    def get_data(self):
        self.pref_keys = [
            "color_font",
            "color_font_red",
            "color_font_fo",
            "color_font_ti",
            "color_font_sub_ti",
            "color_font_sub_ti_fo",
            "color_font_sub_ti_2",
            "color_font_sub_ti_2_fo",
            "color_font_mod_num",
            "color_font_mod_num_fo",
            "color_font_mod_name",
            "color_font_darker",
            "color_font_ignore",

            "color_bu_kf_fo",
            "color_bu_kf_yellow",
            "color_bu_kf_yellow_fo",
            "color_bu_kf_green",
            "color_bu_kf_green_fo",
            "color_bu_kf_orange",
            "color_bu_kf_orange_fo",
            "color_bu_dr",
            "color_bu_dr_fo",
            "color_mdicon_kf_off",
            "color_mdicon_dr_off",
            "color_font_rm",
            "color_font_rm_ignore",
        ]
        self.custom_subtype = {}
class MODIFIER_EDITOR(DISPLAY):
    __slots__ = ()
    def R_names(self): return ("Apps", APPS), self.R_name()
    def R_name(self): return "Modifier Editor", MODIFIER_EDITOR
    def get_data(self):
        self.pref_keys = [
            "win_size_init",
            "sync_act_oj",
            "sync_act_md",
            "confirm_apply",
            "color_box_mod",
            "color_box_mod_sel",
            "color_box_mod_act",
            "color_box_mod_act_rim",
            "color_mod_bu_fo",
            "color_icon_1",
            "color_icon_2",
            "color_icon_3",
            "color_icon_4",
            "color_icon_5",
            "color_icon_6",
            "color_icon_7",
            "color_icon_8",
            "color_icon_ignore",
            "color_icon_ignore2",
            "color_icon_light",
            "color_bu_kf_fo",
            "color_bu_kf_yellow",
            "color_bu_kf_yellow_fo",
            "color_bu_kf_green",
            "color_bu_kf_green_fo",
            "color_bu_kf_orange",
            "color_bu_kf_orange_fo",
            "color_bu_dr",
            "color_bu_dr_fo",
        ]
        self.custom_subtype = {}
class DRIVER_EDITOR(MODIFIER_EDITOR):
    __slots__ = ()
    def R_name(self): return "Driver Editor", DRIVER_EDITOR
    def get_data(self):
        self.pref_keys = [
            "win_size_init_DE",
        ]
        self.custom_subtype = {}
    #
    #
class MESH_EDITOR(MODIFIER_EDITOR):
    __slots__ = ()
    def R_name(self): return "Mesh Editor", MESH_EDITOR
    def get_data(self):
        self.pref_keys = [
            "mesh_ed_local",
            "mesh_ed_dis_invert",
            "mesh_ed_face_nor_keep_act",
            "mesh_ed_face_nor_keep_nor",
            "mesh_ed_cop_vert",
        ]
        self.custom_subtype = {}
    #
    #
class GLOBAL(DISPLAY):
    __slots__ = ()
    def R_names(self): return ("Addon Keymap", ADDON_KEYMAP), self.R_name()
    def R_name(self): return "Global", GLOBAL
    def get_data(self):
        props = self.props

        self.pref_keys = [
            KM_SEL(self, props["keys_sel_fast"], props["keys_sel"]),
            KM(self, props["keys_sel_ext"]),
            KM(self, props["keys_bu_sel"]),
            KM2(self, props["keys_bu_qe"], props["keys_bu_qe_E"]),
            KM(self, props["keys_bu_qe_cancel"]),
            KM(self, props["keys_bu_qe_slow"]),
            KM(self, props["keys_bu_qe_fast"]),
            KM(self, props["keys_bu_reset"]),
            KM(self, props["keys_rm"]),
            KM(self, props["keys_cancel"]),
            KM(self, props["keys_confirm"]),
            KM2(self, props["keys_pan"], props["keys_pan_E"]),
            KM2(self, props["keys_glopan"], props["keys_glopan_E"]),
            KM2(self, props["keys_ti_bu"], props["keys_ti_bu_E"]),
            KM2(self, props["keys_ti_mov"], props["keys_ti_mov_E"]),
            KM2(self, props["keys_resize"], props["keys_resize_E"]),
            KM(self, props["keys_undo"]),
            KM(self, props["keys_redo"]),
            KM(self, props["keys_batch"]),
        ]
        self.custom_subtype = {}
    def upd_oo(self):
        for e in self.oo.values():  e.upd_oo()
class MD_EDITOR(GLOBAL):
    __slots__ = ()
    def R_name(self): return "Modifier Editor", MD_EDITOR
    def get_data(self):
        props = self.props

        self.pref_keys = [
            KM(self, props["keys_me_all"]),
            KM(self, props["keys_me_act_up"]),
            KM(self, props["keys_me_act_dn"]),
            KM(self, props["keys_me_act_up_ext"]),
            KM(self, props["keys_me_act_dn_ext"]),
            KM(self, props["keys_me_mod_up"]),
            KM(self, props["keys_me_mod_dn"]),
            KM(self, props["keys_me_del"]),
            KM(self, props["keys_me_apply"]),
            KM2(self, props["keys_me_pan"], props["keys_me_pan_E"]),
            KM2(self, props["keys_me_sort"], props["keys_me_sort_E"]),
            KM(self, props["keys_me_rename"]),
            KM(self, props["keys_me_sel_ext"]),
            KM(self, props["keys_me_sel"]),
            KM2(self, props["keys_me_box_ext"], props["keys_me_box_ext_E"]),
            KM2(self, props["keys_me_box"], props["keys_me_box_E"]),
        ]
        self.custom_subtype = {}
class DROPDOWN_MENU(GLOBAL):
    __slots__ = ()
    def R_name(self): return "Dropdown Menu", DROPDOWN_MENU
    def get_data(self):
        props = self.props

        self.pref_keys = [
            KM2(self, props["keys_dd_bar"], props["keys_dd_bar_E"]),
            KM(self, props["keys_dd_cancel"]),
            KM(self, props["keys_dd_confirm"]),
            KM(self, props["keys_dd_del_all"]),
            KM(self, props["keys_dd_del_word"]),
            KM(self, props["keys_dd_del_alp"]),
            KM(self, props["keys_dd_shift_left"]),
            KM(self, props["keys_dd_shift_right"]),
            KM(self, props["keys_dd_shift_up"]),
            KM(self, props["keys_dd_shift_down"]),
            KM(self, props["keys_dd_left"]),
            KM(self, props["keys_dd_right"]),
            KM(self, props["keys_dd_up"]),
            KM(self, props["keys_dd_down"]),
            KM2(self, props["keys_dd_box"], props["keys_dd_box_E"]),
            KM2(self, props["keys_dd_pan"], props["keys_dd_pan_E"]),
            KM(self, props["keys_dd_copy"]),
            KM(self, props["keys_dd_paste"]),
            KM(self, props["keys_dd_cut"]),
            KM(self, props["keys_dd_sel_all"]),
            KM(self, props["keys_dd_sel"]),
            KM(self, props["keys_dd_tab"]),
            KM(self, props["keys_dd_scroll_up"]),
            KM(self, props["keys_dd_scroll_down"]),
        ]
        self.custom_subtype = {}
class COLOR_PANEL(GLOBAL):
    __slots__ = ()
    def R_name(self): return "Color Panel", COLOR_PANEL
    def get_data(self):
        props = self.props

        self.pref_keys = [
            KM(self, props["keys_cp_hue_sel"]),
            KM2(self, props["keys_cp_hue"], props["keys_cp_hue_E"]),
            KM(self, props["keys_pk_cancel"]),
            KM(self, props["keys_pk_confirm"]),
        ]
        self.custom_subtype = {}
class CONTEXT_MENU(GLOBAL):
    __slots__ = ()
    def R_name(self): return "Context Menu", CONTEXT_MENU
    def get_data(self):
        props = self.props

        self.pref_keys = [
            KM(self, props["keys_rm_1"]),
            KM(self, props["keys_rm_2"]),
            KM(self, props["keys_rm_3"]),
            KM(self, props["keys_rm_4"]),
            KM(self, props["keys_rm_5"]),
            KM(self, props["keys_rm_6"]),
            KM(self, props["keys_rm_7"]),
            KM(self, props["keys_rm_8"]),
            KM(self, props["keys_rm_9"]),
            KM(self, props["keys_rm_0"]),
            KM(self, props["keys_rm_back"]),
            KM(self, props["keys_rm_next"]),
        ]
        self.custom_subtype = {}