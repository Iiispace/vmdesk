import bpy
from bgl import glEnable, GL_BLEND
from blf import size as blf_size
from blf import color as blf_color

from . setting_data import SYSTEM, PERSONALIZATION, APPS, ADDON_KEYMAP, BLENDER_KEYMAP

from .. import m
from .. win import WIN

P = None
F = None
K = None
BOX = None
BLF = None
font_0 = None

class OP_SETTING(bpy.types.Operator):
    __slots__ = ()
# ▅▅▅  HEAD                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    bl_idname = "wm.setting_editor_operator"
    bl_label = "Setting Editor"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        print("    setting_ed  bpyOperator  OP_SETTING  invoke")
        if m.op_poll(context):  return {'CANCELLED'}

        SETTING_ED(init_fit=True)
        # if len(m.W_A) == 1:
        #     print("debug ...")
        #     e = m.W_A[0]
        #     fo_k = "Addon Keymap"
        #     print("    click,", fo_k)
        #     e.actbox.ind = fo_k
        #     e.actbox.upd()
        #     e.A_data = e.ti[fo_k].size(e)
        #     e.A_data.upd_data()

        #     m.W_A[0].A_data.to_subtab("Global")
        #     A = m.W_A[0].A_data
        #     block = A.oo[0]
        #     block_bu = block.oo[0]
        #     from . setting_key_edit import KEY_ED
            # KEY_ED(block_bu, event)
            # block.fn(block_bu)

        return {'FINISHED'}


class SETTING_ED(WIN):
    __slots__ = (
        'oo',
        'actbox',
        'fobox',
        'A_data',
        'paths',
        'signs',
        'tab_keys',
    )
    name = "Settings"
    W = []
    IND = []

    def init_D1(self):
        c = self.color
        c.font = P.color_font

        class BOX_FIND(BOX):
            __slots__ = 'is_fo'
            def focus(self):
                if self.is_fo:  return
                self.is_fo = True
                self.color = P.color_bu_4_fo
                m.redraw()
            def unfocus(self):
                if self.is_fo:
                    self.is_fo = False
                    self.color = P.color_bu_4_off
                    m.redraw()

        self.tab_keys = [
            "System",
            "Personalization",
            "Apps",
            "Addon Keymap",
            "Blender Keymap",
            "",
            "Save Preferences",
        ]
        self.bo = {
            "find":             BOX_FIND(P.color_bu_4_off),
            "data":             BOX(P.color_oj_info),
        }
        self.ti = {
            "System":           BLF(text="System", size=SYSTEM),
            "Personalization":  BLF(text="Personalization", size=PERSONALIZATION),
            "Apps":             BLF(text="Apps", size=APPS),
            "Addon Keymap":     BLF(text="Addon Keymap", size=ADDON_KEYMAP),
            "Blender Keymap":   BLF(text="Blender Keymap", size=BLENDER_KEYMAP),
            "":                 BLF(text="", size=None),
            "Save Preferences": BLF(text="Save Preferences", size=None),
        }
        self.da = {
            "find":             BLF(P.color_font_darker ,"Find a setting"),
        }

        self.bo["find"].is_fo = False
        self.signs = []
        w = self
# class PATHS, ACTBOX, FOBOX
        class PATHS(list):
            __slots__ = 'x', 'y', 'color', 'color_fo', 'signs', 'fo_ind', 'L', 'R', 'B', 'T'
            def __init__(self):
                super().__init__()
                self.color = P.color_font
                self.color_fo = P.color_font_fo
                self.signs = w.signs
                self.fo_ind = None
                self.x = 0
                self.y = 0
            def kill(self):
                self.signs.clear()
                self.fo_ind = None
                self.clear()

            def xy(self, x, y):
                self.x = x
                self.y = y
                self.L = x - F[4]
                self.B = y - F[6]
                self.T = self.B + F[22]
                d = F[16]
                blf_size(font_0, d, 72)

                if self.signs:
                    e = self[0]
                    e.xy(x, y)
                    x = e.R_end_x() + d

                    for i, o in enumerate(self.signs):
                        _1 = F[1]
                        e = self[i + 1]
                        e.xy(x, y)
                        o.xy(x - F[12], y + _1)
                        x = e.R_end_x() + d
                else:
                    for e in self:
                        e.xy(x, y)
                        x = e.R_end_x() + d

                self.R = x - F[12]

            def dxy(self, x, y):
                self.x += x
                self.y += y
                self.L += x
                self.R += x
                self.B += y
                self.T += y
                for e in self:  e.dxy(x, y)

            def new(self, name, cl):
                blf_size(font_0, F[16], 72)
                if self:
                    self.signs.append(BLF(text="▶", x=self.R, y=self.y + F[1]))
                    e = BLF(self.color, name, x=self.R + F[12], y=self.y)
                    self.append(e)
                else:
                    e = BLF(self.color, name, x=self.x, y=self.y)
                    self.append(e)

                e.name = cl
                self.R = e.R_end_x() + F[16] - F[12]

            def unfocus(self):
                if self.fo_ind != None:
                    self[self.fo_ind].color = self.color
                    self.fo_ind = None
                    m.redraw()
            def focus(self, i):
                if self.fo_ind != i:
                    if self.fo_ind != None: self[self.fo_ind].color = self.color
                    self.fo_ind = i
                    self[i].color = self.color_fo
                    m.redraw()
            def inbox_xy(self, x, y):
                return self.L <= x <= self.R and self.B <= y <= self.T
        class ACTBOX:
            __slots__ = 'ind', 'rim'
            def __init__(self):
                self.rim = BOX(P.color_setting_act)
                self.ind = 'System'
            def upd(self):
                ti = w.ti[self.ind]
                L = ti.x - F[6]
                B = ti.y - F[7]
                self.rim.LRBT(L, w.bo["find"].R, B, B + F[20])
                self.rim.upd()
            def draw(self):
                self.rim.bind_draw()
        class FOBOX:
            __slots__ = 'ind', 'rim'
            def __init__(self):
                self.ind = None
                self.rim = BOX()
            def focus(self, k):
                if k == self.ind:   return
                self.ind = k
                ti = w.ti[k]
                L = ti.x - F[6]
                B = ti.y - F[7]
                self.rim.LRBT(L, w.bo["find"].R, B, B + F[20])
                self.rim.upd()
                m.redraw()
            def unfocus(self):
                if self.ind is not None:
                    self.ind = None
                    m.redraw()
            def draw(self):
                m.bind_color_setting_bo_fo()
                self.rim.draw()

        self.paths = PATHS()

        blf_title = self.tit["ti"]
        ind = blf_title.name
        if ind == 1:
            blf_title.text = "Settings"
        else:
            blf_title.text = f"Settings {ind}"

        self.actbox     = ACTBOX()
        self.fobox      = FOBOX()
        self.cv.R_w     = self.cv_R_w
        self.cv.R_h     = self.cv_R_h
        self.upd_data   = self.I_upd_data

        self.A_data     = SYSTEM(self)

    def get_bo_main(self):
        inn = P.win_border_inner
        win_border = P.win_border
        bo  = self.bo
        ti  = self.ti
        da  = self.da
        x   = self.box["main"].L + win_border - self.cv.x
        y   = self.box["main"].T - win_border + self.cv.y
        u   = P.scale[0]

        L0 = x + F[6]
        T0 = y - F[6]
        R0 = L0 + F[110]
        B0 = T0 - F[17]

        L1 = L0 + F[3]
        bo["find"].LRBT(L0, R0, B0, T0)
        da["find"].LB(bo["find"], F[5], F[5])

        d = F[24]
        T = B0 - d
        for k in self.tab_keys:
            ti[k].xy(L1, T)
            T -= d

        L2 = R0 + F[7]
        T1 = y - F[31]
        depth = inn - 3
        bo["data"].LRBT(L2, L2 + round(358*u) + depth, T1 - F[500], T1)
        self.paths.xy(L2 + F[6], T1 + F[11])

        T = y - F[101] *2
        B = T - F[20]

        self.actbox.upd()
        self.A_data.__init__(self)
# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd_main(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        self.paths.dxy(x, y)
        for e in self.signs:        e.dxy(x, y)

        self.actbox.rim.dxy_upd(x, y)
        if self.fobox.ind is not None:  self.fobox.rim.dxy_upd(x, y)
        self.A_data.dxy_upd(x, y)

    def glopan_upd(self):
        self.A_data.upd_sci()
    def I_modal_glopan_end_D1(self):
        print(f"    setting_ed  I_modal_glopan_end_D1")
        self.I_upd_data()
    def modal_mov_end_D1(self):
        print(f"    setting_ed  modal_mov_end_D1")
        pass

    def cv_R_h(self):
        return self.bo["find"].T + F[6] - self.bo["data"].B
    def cv_R_w(self):
        return self.bo["data"].R + F[6] - self.bo["find"].L
# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def modal_main_area(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        paths = self.paths

        if paths.inbox_xy(x, y):
            self.A_data.unfocus()
            self.fobox.unfocus()
            self.bo["find"].unfocus()
            signs = self.signs
            is_outside = True
            for i, e in enumerate(paths):
                try:    R = signs[i].x
                except: R = paths.R
                if e.x - F[4] <= x <= R:
                    paths.focus(i)
                    if K["sel_fast0"].true() or K["sel_fast1"].true():
                        self.evt_path(i)
                        return True
                    is_outside = False
                    break

            if is_outside:  paths.unfocus()
        else:
            paths.unfocus()

            if self.actbox.rim.in_LR_x(x):
                self.A_data.unfocus()

                _7 = F[7]
                _20 = F[20]
                fo_k = None
                for k in self.tab_keys:
                    e = self.ti[k]
                    B = e.y - _7
                    if B <= y <= B + _20:
                        fo_k = k
                        break

                if fo_k == "": fo_k = None

                if fo_k is None:
                    self.fobox.unfocus()
                    if self.bo["find"].inbox_xy(x, y):
                        self.bo["find"].focus()
                        if K["sel_fast0"].true() or K["sel_fast1"].true():
                            m.EVT.kill()
                            print("TODO find")
                            return True
                    else:
                        self.bo["find"].unfocus()
                else:
                    self.bo["find"].unfocus()
                    self.fobox.focus(fo_k)
                    if K["sel_fast0"].true() or K["sel_fast1"].true():
                        m.EVT.kill()
                        print(f"    setting_data  modal_main_area  sel_fast0:  bu={fo_k}")

                        cl = self.ti[fo_k].size
                        if cl is None:
                            try:    getattr(self, f"fn_{fo_k.replace(' ', '_')}")()
                            except: pass
                        else:
                            self.actbox.ind = fo_k
                            self.actbox.upd()
                            self.A_data = cl(self)

                        m.redraw()
                        return True
            else:
                self.fobox.unfocus()
                self.bo["find"].unfocus()

                if self.bo["data"].inbox_xy(x, y):
                    self.fobox.unfocus()
                    if self.A_data.U_modal(evt): return True
                else:
                    self.fobox.unfocus()
                    self.A_data.unfocus()

        if K["undo0"].true() or K["undo1"].true():
            m.undo()
            m.EVT.kill_except(evt)
            return True
        if K["redo0"].true() or K["redo1"].true():
            m.redo()
            m.EVT.kill_except(evt)
            return True

        return False

    def outside_evt(self, evt):
        self.A_data.unfocus()
        self.paths.unfocus()
        self.fobox.unfocus()
        self.bo["find"].unfocus()

    def title_evt(self, evt):
        self.A_data.unfocus()
        self.paths.unfocus()
        self.fobox.unfocus()
        self.bo["find"].unfocus()

    def evt_path(self, i):
        print(f"    setting_ed  evt_path")
        m.EVT.kill()
        m.redraw()

        self.A_data = self.paths[i].name(self)
        self.A_data.upd_data()

    def fn_Save_Preferences(self):
        print("    setting_ed  fn_Save_Preferences")
        bpy.ops.wm.save_userpref()
        m.admin.report({'INFO'}, "Preferences saved")
        #
# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def draw_main(self):
        da = self.da
        self.actbox.draw()
        if self.fobox.ind is not None:  self.fobox.draw()

        for e in self.bo.values():  e.bind_draw()

        self.sci.use()
        blf_size(font_0, F[9], 72)
        blf_color(font_0, *self.color.font)
        for e in self.ti.values():  e.draw_pos()
        da["find"].draw_color_pos()

        blf_size(font_0, F[12], 72)
        blf_color(font_0, *P.color_font_darker)
        for e in self.signs:    e.draw_pos()
        blf_size(font_0, F[16], 72)
        for e in self.paths:    e.draw_color_pos()

        self.A_data.U_draw()
# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_upd_data(self):
        print("    setting_ed  I_upd_data")
        self.A_data.upd_data()

    def kill_data(self): pass