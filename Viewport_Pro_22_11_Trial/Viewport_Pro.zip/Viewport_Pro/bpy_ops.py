import bpy
from bpy.types import Operator

from . import m

class VPP_FACTORY(Operator):
    bl_idname = "wm.vpp_factory"
    bl_label = "Restore to Factory settings"
    bl_options = {'REGISTER',}

    @staticmethod
    def main(reset_keymap=True):
        P = m.P
        props = P.bl_rna.properties

        for at in props:
            if hasattr(at, "default"):
                if at.identifier == "bl_idname": continue
                if getattr(at, "is_array", False):
                    getattr(P, at.identifier)[:] = at.default_array
                else:
                    setattr(P, at.identifier, at.default)

        if reset_keymap:
            try:
                wm = bpy.context.window_manager
                kc = wm.keyconfigs.addon
                if kc:
                    kms = kc.keymaps
                    if "Screen" in kms:
                        print("in")
                        kms["Screen"].restore_to_default()
                    else:
                        print("not in")
                        km = kms.new(name="Screen")
                        kmi = km.keymap_items
                        cls_ops_kms = getattr(m, "cls_ops_kms", None)

                        if cls_ops_kms:
                            r = 3
                            for cls in cls_ops_kms:
                                kmi.new(cls.bl_idname, type=f'F1{r}', value='PRESS')
                                r += 1
            except: pass

        try:
            m.get_K()
            m.refresh()
            m.redraw()
            m.P.scale[0] = m.P.scale[0]
        except: pass

    def execute(self, context):
        self.__class__.main()
        return {'FINISHED'}
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)