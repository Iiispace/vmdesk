import bpy, gpu
from bpy.types import Operator

from . import m, win
from bgl import glEnable, GL_BLEND

D_null = {
    1:0,
    2:0,
    3:0,
    4:0,
    5:0,
    7:6,
    8:6,
    10:9,
    14:13,
    146:145,
    150:149,
    153:152,
    155:154,
    161:160,
    163:162,
    165:164,
    168:167,
    171:170,
    177:176,
    182:181,
    184:183,
    186:185,
    188:187,
    190:189,
    193:192,
    195:194,
    232:231,
    243:242,
    251:250}

LL = {
    0: 0.0,
    1: 0.0002633,
    2: 0.0005267,
    3: 0.00079,
    4: 0.0010533,
    5: 0.0013167,
    6: 0.0015771483886055648,
    7: 0.0028967,
    8: 0.0042133,
    9: 0.005520019447430968,
    10: 0.0075,
    11: 0.009462890680879354,
    12: 0.013405761215835811,
    13: 0.017348631285130978,
    14: 0.019325,
    15: 0.02129150275141001,
    16: 0.025234374217689037,
    17: 0.029177243821322918,
    18: 0.0370629858225584,
    19: 0.04099433310329915,
    20: 0.04546292312443257,
    21: 0.04898468963801861,
    22: 0.05300186388194561,
    23: 0.061055721715092666,
    24: 0.06452127173542978,
    25: 0.06893400475382805,
    26: 0.07262223586440086,
    27: 0.07616695389151573,
    28: 0.08006047829985619,
    29: 0.08829088881611825,
    30: 0.09216826036572458,
    31: 0.0959075875580311,
    32: 0.0999157913029194,
    33: 0.10378383472561838,
    34: 0.10752426460385324,
    35: 0.11604240164160728,
    36: 0.11942188814282419,
    37: 0.12335999682545663,
    38: 0.12780576199293137,
    39: 0.13149937242269516,
    40: 0.1350933536887169,
    41: 0.1391696259379387,
    42: 0.14312943071126938,
    43: 0.15073328465223312,
    44: 0.15490704029798508,
    45: 0.15896772593259811,
    46: 0.16292332857847214,
    47: 0.16678082197904587,
    48: 0.17054661363363266,
    49: 0.17422639578580856,
    50: 0.17871292680501938,
    51: 0.18221714347600937,
    52: 0.18984784930944443,
    53: 0.19394680112600327,
    54: 0.19795342534780502,
    55: 0.20187317579984665,
    56: 0.20571088045835495,
    57: 0.20947109907865524,
    58: 0.21388676017522812,
    59: 0.21749045699834824,
    60: 0.2217286452651024,
    61: 0.22519230097532272,
    62: 0.23326962441205978,
    63: 0.23719196766614914,
    64: 0.2410418912768364,
    65: 0.24482300132513046,
    66: 0.2491515800356865,
    67: 0.2527943104505539,
    68: 0.25696931779384613,
    69: 0.2604866474866867,
    70: 0.26509262621402746,
    71: 0.26848720014095306,
    72: 0.2729371637105942,
    73: 0.27621997892856603,
    74: 0.28052739799022675,
    75: 0.2878845483064652,
    76: 0.2919911295175553,
    77: 0.2960308641195297,
    78: 0.3000065237283707,
    79: 0.3039207607507706,
    80: 0.3077761381864548,
    81: 0.31157501041889196,
    82: 0.3153195530176163,
    83: 0.31992693245410925,
    84: 0.32355655729770666,
    85: 0.32713808119297033,
    86: 0.33155001699924475,
    87: 0.33502940833568573,
    88: 0.33931849896907806,
    89: 0.3431235700845719,
    90: 0.3468784242868424,
    91: 0.3550512939691544,
    92: 0.3590535074472428,
    93: 0.3630023151636124,
    94: 0.36689950525760656,
    95: 0.37074701488018036,
    96: 0.37454645335674286,
    97: 0.37829931080341345,
    98: 0.38274364173412323,
    99: 0.38639952242374426,
    100: 0.3900134414434433,
    101: 0.3942967206239701,
    102: 0.39782290160655975,
    103: 0.4020042270421982,
    104: 0.40613268315792084,
    105: 0.40953396260738373,
    106: 0.4135699421167374,
    107: 0.41755788028240204,
    108: 0.4214992970228195,
    109: 0.4253955036401749,
    110: 0.42924802005290985,
    111: 0.43305812776088715,
    112: 0.43745122849941254,
    113: 0.4454674571752548,
    114: 0.4491072744131088,
    115: 0.45271067321300507,
    116: 0.4568699449300766,
    117: 0.4609823673963547,
    118: 0.46447114646434784,
    119: 0.46850042045116425,
    120: 0.4724867194890976,
    121: 0.47643129527568817,
    122: 0.48033522069454193,
    123: 0.48419974744319916,
    124: 0.4880258589982987,
    125: 0.49235282838344574,
    126: 0.49610008299350744,
    127: 0.49981193244457245,
    128: 0.504012018442154,
    129: 0.5081683099269867,
    130: 0.511770099401474,
    131: 0.5153402388095857,
    132: 0.5193823873996736,
    133: 0.5233851373195648,
    134: 0.5273495018482209,
    135: 0.5312764942646028,
    136: 0.5351668894290925,
    137: 0.5390217006206512,
    138: 0.5428418219089509,
    139: 0.5470990836620331,
    140: 0.5513145625591278,
    141: 0.5550274550914764,
    142: 0.5587090551853181,
    143: 0.5623598992824554,
    144: 0.5668815076351166,
    145: 0.5704658329486848,
    146: 0.57445,
    147: 0.5784274041652679,
    148: 0.5823560655117035,
    149: 0.586251050233841,
    150: 0.590105,
    151: 0.5939435064792634,
    152: 0.5981624424457551,
    153: 0.60192,
    154: 0.6056618392467499,
    155: 0.609765,
    156: 0.6138570606708528,
    157: 0.6179024875164032,
    158: 0.6219141185283661,
    159: 0.6250996291637421,
    160: 0.6329734027385712,
    161: 0.634925,
    162: 0.6368633806705476,
    163: 0.641095,
    164: 0.6453152596950531,
    165: 0.6491,
    166: 0.652876764535904,
    167: 0.6610659658908845,
    168: 0.66291,
    169: 0.6647453010082245,
    170: 0.6683984696865082,
    171: 0.672375,
    172: 0.676345854997635,
    173: 0.6806304156780243,
    174: 0.6883957087993622,
    175: 0.6918881237506868,
    176: 0.6960491836071014,
    177: 0.698115,
    178: 0.7001781165599823,
    179: 0.7035949528217317,
    180: 0.7076669037342073,
    181: 0.7117086350917816,
    182: 0.71571,
    183: 0.719703882932663,
    184: 0.72365,
    185: 0.7275852262973787,
    186: 0.731475,
    187: 0.7353568971157074,
    188: 0.739115,
    189: 0.7428644001483918,
    190: 0.746965,
    191: 0.7510570585727693,
    192: 0.7547992765903474,
    193: 0.758815,
    194: 0.7628252804279329,
    195: 0.76679,
    196: 0.770742565393448,
    197: 0.7743611037731171,
    198: 0.7785550057888031,
    199: 0.782126396894455,
    200: 0.7862661778926849,
    201: 0.7903777062892914,
    202: 0.7938797175884247,
    203: 0.7979399859905243,
    204: 0.801973432302475,
    205: 0.8059804737567903,
    206: 0.8099614083766937,
    207: 0.8133535087108612,
    208: 0.8178474605083466,
    209: 0.8211969435214997,
    210: 0.82563516497612,
    211: 0.8294930160045624,
    212: 0.8333274424076081,
    213: 0.8371388614177704,
    214: 0.8409275710582733,
    215: 0.8452303111553192,
    216: 0.8489717543125154,
    217: 0.852691560983658,
    218: 0.8569168746471405,
    219: 0.8611148893833162,
    220: 0.8647662699222566,
    221: 0.868397444486618,
    222: 0.8725230395793915,
    223: 0.8766230642795564,
    224: 0.8806980550289154,
    225: 0.884243279695511,
    226: 0.8882721960544587,
    227: 0.8917779624462128,
    228: 0.8957622945308685,
    229: 0.8997233808040619,
    230: 0.9036616384983064,
    231: 0.9075773656368256,
    232: 0.90953,
    233: 0.9114709198474885,
    234: 0.9153425991535188,
    235: 0.9196726381778718,
    236: 0.9234990179538728,
    237: 0.9277788698673249,
    238: 0.9315613806247712,
    239: 0.9353236258029939,
    240: 0.9427888095378876,
    241: 0.9474151432514192,
    242: 0.9510947763919831,
    243: 0.95293,
    244: 0.9547555744647981,
    245: 0.9588519632816316,
    246: 0.9629253447055818,
    247: 0.9665270149707795,
    248: 0.9705578386783601,
    249: 0.9745666086673738,
    250: 0.9825190603733064,
    251: 0.984275,
    252: 0.9860263168811799,
    253: 0.9903871715068817,
    254: 0.9938577711582185,
    255: 0.9981732666492463,
}












class TEST(win.WIN):
    def __init__(self):
        self.RET = {'PASS_THROUGH'}
        self.U_modal = self.I_modal
        self.U_draw = self.I_draw

        P   = m.P
        unit = m.P.scale[0]
        F   = {i : round(i * unit) for i in range(500)}
        BOX = m.BOX
        BLF = m.BLF

        bo = {}
        ti = {}
        self.bo = bo
        self.ti = ti

        x = 800
        y = 500

        bo["main"] = BOX(P.color_font)
        L = x
        R = x + F[100]
        T = y
        B = y - F[100]
        bo["main"].LRBT(L, R, B, T)

        for e in bo.values(): e.upd()
        m.call_admin()
        m.W_D.append(self)
        m.W_M.append(self)
        m.redraw()

    def I_modal(self, evt):
        pass

    def I_draw(self):
        m.glEnable(m.GL_BLEND)
        bo = self.bo
        ti = self.ti

        bo["main"].bind_draw()

    def upd_data(self):
        pass

U_main = None
mou_dx = None
mou_dy = None
li = []
class DEBUG_MODAL(bpy.types.Operator):
    bl_idname = "xx.operator"
    bl_label = "Test Modal"

    def fin(self):
        bpy.types.SpaceView3D.draw_handler_remove(self.handle0, 'WINDOW')
        wm = bpy.context.window_manager
        wm.event_timer_remove(self._timer)
        print("DEBUG_MODAL END")
    def invoke(self, context, event):
        print("invoke DEBUG_MODAL")
        wm = context.window_manager
        wm.modal_handler_add(self)
        self.U_draw = self.I_draw

        self.handle0 = bpy.types.SpaceView3D.draw_handler_add(self.U_draw, (), 'WINDOW', 'POST_PIXEL')

        context.area.tag_redraw()
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.03, window=context.window)
        global U_main, mou_dx, mou_dy
        U_main = I_main
        mou_dx = event.mouse_x - event.mouse_region_x
        mou_dy = event.mouse_y - event.mouse_region_y
        # if len(LL) != 226:
        #     print("Error")
        #     return {'FINISHED'}
        return {'RUNNING_MODAL'}
        #
    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type == 'ESC':
            for k, e in LL.items():
                print(f'{k}: {e},')
            self.fin()
            return {'FINISHED'}
        U_main()
        return {'RUNNING_MODAL'}
    def I_draw(self):
        glEnable(GL_BLEND)
        for e in li:    e.bind_draw()


CON = 0.01
ind = 6

def I_main():
    global U_main
    li.clear()
    BOX = m.BOX

    L = 0
    R = 10
    B = 0
    T = 10

    v = LL[ind]
    # len_v = len(str(v)) - 3
    # dis = "0."+"0"*len_v + "1"
    # dis = float(dis)*10000000
    dis = CON

    for r in range(50):
        for _ in range(100):
            c0 = v
            v -= dis
            c1 = v
            v -= dis
            c2 = v
            v -= dis

            e = BOX((c0, c1, c2, 1.0))
            e.LRBT(L, R, B, T)
            e.upd()
            li.append(e)

            L += 10
            R += 10

        L = 0
        R = 10
        B += 10
        T += 10

    U_main = wait0

def wait0():
    global U_main
    U_main = wait1
def wait1():
    global U_main
    U_main = get_data

def get_data():
    global U_main, ind

    fb = gpu.state.active_framebuffer_get()
    def get_color(x, y):
        screen_buffer = fb.read_color(x + mou_dx, y + mou_dy, 1, 1, 3, 0, 'FLOAT')
        return screen_buffer.to_list()[0][0]

    is_break = False

    for r, e in enumerate(li):
        x = e.R_center_x()
        y = e.R_center_y()
        color = get_color(x, y)

        if round(color[0]*255) != ind:
            if r == 0: BUG
            tm = li[r-1].color[2]
            # print(f'{ind}: {tm},')
            is_break=True;break
        if round(color[1]*255) != ind:
            tm = e.color[0]
            # print(f'{ind}: {tm},')
            is_break=True;break
        if round(color[2]*255) != ind:
            tm = e.color[1]
            # print(f'{ind}: {tm},')
            is_break=True;break

    if is_break != True:
        tm = li[-1].color[2]
        # print(f'{ind}: {tm},  #')

    LL[ind] = tm

    if ind == 255:
        U_main = I_main
        ind = 6
        global CON
        CON /= 2.0
        print("finish", CON)
        return


    while True:
        ind += 1
        if ind not in D_null: break

    U_main = I_main
    # print("#", CON)

def end(): pass

def get_boxes(self):
    boxes = []
    self.boxes = boxes
    BOX = m.BOX

    L = 0
    R = 10
    B = 0
    T = 10
    c = self.START
    for r in range(5000):
        bo = BOX([c,c,c, 1.0])
        boxes.append(bo)
        bo.LRBT(L, R, B, T)
        bo.upd()

        c += CON
        L += 10
        R += 10

        if R >= 1000:
            L = 0
            R = 10
            B += 10
            T += 10

def print_data(self):
    boxes = self.boxes
    fb = gpu.state.active_framebuffer_get()
    mdx = self.mou_dx
    mdy = self.mou_dy
    def get_color(x, y):
        screen_buffer = fb.read_color(x + mdx, y + mdy, 1, 1, 3, 0, 'FLOAT')
        return screen_buffer.to_list()[0][0]

    c = self.START

    for e in boxes:
        x = e.R_center_x()
        y = e.R_center_y()
        color = get_color(x, y)
        if color != self.old_color:
            cc = round(color[0] *255)
            if cc > self.last_ind:
                self.last_ind = cc
                self.old_color = color
                print(f"({c},{cc}),")

        c += CON


# def get_boxes(self):
#     boxes = []
#     self.boxes = boxes
#     BOX = m.BOX_GAMMA

#     L = 0
#     R = 10
#     B = 0
#     T = 10
#     c = D_COLOR_GLSL_CUSTOM[81]

#     bo = BOX([c,c,c, 1.0])
#     boxes.append(bo)
#     bo.LRBT(L, R, B, T)
#     bo.upd()

# def print_data(self):
#     boxes = self.boxes
#     fb = gpu.state.active_framebuffer_get()
#     mdx = self.mou_dx
#     mdy = self.mou_dy
#     def get_color(x, y):
#         screen_buffer = fb.read_color(x + mdx, y + mdy, 1, 1, 3, 0, 'FLOAT')
#         return screen_buffer.to_list()[0][0]


#     b = boxes[0]

#     print(get_color(b.R_center_x(), b.R_center_y()))

class DEBUG_fn_0(Operator):
    bl_idname = "wm.debug_fn_0"
    bl_label = "Unit to feet"

    def invoke(self, context, event):
        print("fn 0")
        bpy.context.scene.unit_settings.system = "IMPERIAL"
        bpy.context.scene.unit_settings.length_unit = "FEET"
        bpy.context.scene.unit_settings.scale_length = 1.5
        return {'FINISHED'}

class DEBUG_fn_1(Operator):
    bl_idname = "wm.debug_fn_1"
    bl_label = "Scale 2.4"

    def invoke(self, context, event):
        P = m.P
        P.scale[0] = 2.4
        P.win_pos_init[:] = (724, 746)
        P.win_border = 6
        P.win_border_inner = 6
        P.win_shade_softness = 60
        P.dd_shade_softness = 40
        P.dd_shade_color[:] = [0.014, 0.014, 0.014, 0.9]
        return {'FINISHED'}

class DEBUG_fn_2(Operator):
    bl_idname = "wm.debug_fn_2"
    bl_label = "Scale 1.2"

    def invoke(self, context, event):
        P = m.P
        P.win_pos_init[:] = (724, 746)
        P.scale[0] = 1.2
        P.win_border = 3
        P.win_border_inner = 3
        P.win_shade_softness = 25
        P.dd_shade_softness = 25
        P.dd_shade_color[:] = [0.014, 0.014, 0.014, 0.5]
        return {'FINISHED'}

class DEBUG_fn_3(Operator):
    bl_idname = "wm.debug_fn_3"
    bl_label = "debug fn 3"

    def invoke(self, context, event):
        P = m.bugexample
        return {'FINISHED'}