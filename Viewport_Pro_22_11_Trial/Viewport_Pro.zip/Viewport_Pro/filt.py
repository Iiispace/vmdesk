
P = None

class NAME_FAKE:
    __slots__ = "name", "type"
    def __init__(self):
        self.name = " "
        self.type = "null"

class FIL_TYPE_EXC:
    __slots__ = (
        'bpy_type',
        'type_allow',
        'exc',
        'li_full',
        'ind0',
        'ind1',
        'll',
        'algor',
        'get_li_full_sort',
        'attr',
    )
    def __init__(self, bpy_type, type_allow=None, exc=None, attr="name"):
        self.bpy_type   = bpy_type  if bpy_type else (NAME_FAKE(),)
        self.type_allow = type_allow
        self.exc        = exc
        self.li_full    = []
        self.ind0       = None
        self.ind1       = 0
        self.ll         = 0
        self.algor      = getattr(self, P.filter_algorithm)
        self.attr       = attr

        if type_allow is None:
            self.get_li_full_sort = self.I_get_li_full_sort
        elif type(type_allow) is set:
            self.get_li_full_sort = self.I_get_li_full_sort_allow_set
        else:
            self.get_li_full_sort = self.I_get_li_full_sort_allow

    def I_get_li_full_sort(self):
        exc = self.exc
        if exc is not None:     exc = getattr(exc[0], exc[1], None)

        li = self.li_full
        li.clear()

        for e in self.bpy_type:
            if e != exc:    li.append(e)
        li.sort(key = lambda s: getattr(s, self.attr))
        self.ll = len(li)
    def I_get_li_full_sort_allow(self):
        exc         = self.exc
        type_allow  = self.type_allow

        if exc is not None:     exc = getattr(exc[0], exc[1], None)

        li = self.li_full
        li.clear()

        for e in self.bpy_type:
            if e.type == type_allow:
                if e != exc:    li.append(e)
        li.sort(key = lambda s: getattr(s, self.attr))
        self.ll = len(li)
    def I_get_li_full_sort_allow_set(self):
        exc         = self.exc
        type_allow  = self.type_allow

        if exc is not None:     exc = getattr(exc[0], exc[1], None)

        li = self.li_full
        li.clear()

        for e in self.bpy_type:
            if e.type in type_allow:
                if e != exc:    li.append(e)
        li.sort(key = lambda s: getattr(s, self.attr))
        self.ll = len(li)

    def R_ind(self, s):
        low = 0
        high = self.ll - 1
        i = 0
        li = self.li_full
        attr = self.attr

        while low <= high:
            i = (low + high) // 2
            e = getattr(li[i], attr)
            if e < s:   low = i + 1
            elif e >s:  high = i - 1
            else:   return i
        return None
    def find_ind(self, s):
        try:
            self.ind0, self.ind1 = self.algor(s)
            if self.ind0 > self.ind1:   self.ind0 = None
        except:
            self.ind0 = None

    def clear(self):
        self.li_full.clear()

    def DISABLE(self, *e):  pass
    def BIN_MATCH(self, s):
        if s == "": return 0, self.ll - 1
        max_ind = self.ll - 1
        li      = self.li_full
        lls     = len(s)
        low     = 0
        high    = max_ind
        attr    = self.attr

        i = 0
        while low <= high:
            i = (low + high) // 2
            e = getattr(li[i], attr)
            if e == s:  low = i  ;break
            elif e < s: low = i + 1
            else:   high = i - 1
        R0 = low

        while True:
            lls -= 1
            r = ord(s[lls])
            if r != 0x10ffff:
                s = s[ : lls] + chr(r + 1)
                break
            if lls == 0:
                return low, max_ind

        while low <= max_ind:
            i = (low + max_ind) // 2
            e = getattr(li[i], attr)
            if e <= s:  low = i + 1
            else:   max_ind = i - 1
        if getattr(li[max_ind], attr) < s:  return R0, max_ind
        return R0, max_ind - 1
    def BIN_CASE(self, s):
        pass

class FIL(FIL_TYPE_EXC):
    __slots__ = ()
    def __init__(self, bpy_type, attr="name"):
        self.bpy_type   = bpy_type
        self.li_full    = []
        self.ind0       = None
        self.ind1       = 0
        self.ll         = 0
        self.algor      = getattr(self, P.filter_algorithm)
        self.attr       = attr

    def get_li_full_sort(self):
        self.li_full = [e for e in self.bpy_type]
        self.ll = len(self.li_full)
        self.li_full.sort(key = lambda s: getattr(s, self.attr))

