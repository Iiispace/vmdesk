import bpy
from bpy.props import(StringProperty,EnumProperty,BoolProperty,
    IntProperty,IntVectorProperty,FloatProperty,FloatVectorProperty
)

from . import m

cursors = (
    ('DEFAULT', 'Default', ''),
    ('NONE', 'None', ''),
    ('WAIT', 'Wait', ''),
    ('CROSSHAIR', 'Crosshair', ''),
    ('MOVE_X', 'Move X', ''),
    ('MOVE_Y', 'Move Y', ''),
    ('KNIFE', 'Knife', ''),
    ('TEXT', 'Text', ''),
    ('PAINT_BRUSH', 'Paint Brush', ''),
    ('PAINT_CROSS', 'Paint Cross', ''),
    ('DOT', 'Dot', ''),
    ('ERASER', 'Eraser', ''),
    ('HAND', 'Hand', ''),
    ('SCROLL_X', 'Scroll X', ''),
    ('SCROLL_Y', 'Scroll Y', ''),
    ('SCROLL_XY', 'Scroll XY', ''),
    ('EYEDROPPER', 'Eyedropper', ''),
    ('PICK_AREA', 'Pick Area', ''),
    ('STOP', 'Stop', ''),
    ('COPY', 'Copy', ''),
    ('CROSS', 'Cross', ''),
    ('MUTE', 'Mute', ''),
    ('ZOOM_IN', 'Zoom In', ''),
    ('ZOOM_OUT', 'Zoom Out', '')
)

U_upd_F     = m.get_F
U_upd_pos   = m.N
U_upd_cv    = m.N

def I_upd_F():
    m.get_F()
    F1 = m.F[1]
    for e in m.W_A:
        rim = e.box["rim"]
        rim.L2 = rim.L + F1           ;rim.R2 = rim.R - F1
        rim.B2 = rim.B + F1           ;rim.T2 = rim.T - F1
        e.get_bo()
        m.admin.tb.get_bo()
def I_upd_pos():
    P = bpy.context.workspace.tm_pref
    m.W_act.box["rim"].LRBTd(P.win_pos[0], P.win_pos[0] + P.win_size[0],
        P.win_pos[1] - P.win_size[1], P.win_pos[1], m.F[1])
    m.W_act.get_bo()
def I_upd_cv():
    P = bpy.context.workspace.tm_pref
    m.W_act.cv.x, m.W_act.cv.y = P.win_canvas_pos[0], P.win_canvas_pos[1]
    m.W_act.get_bo()

class ModEd_Prefs(bpy.types.AddonPreferences):
    __slots__ = ()
    bl_idname = __package__

    def upd_refresh(self, context):     pass
    def upd_F(self, context):           U_upd_F()
    def upd_pos(self, context):         U_upd_pos()
    def upd_canvas(self, context):      U_upd_cv()
    def upd_P(self, context):           m.get_P()
    def upd_pos_protect(self, context): m.get_win_protect_fn()
    def upd_shade(self, context):
        if m.P is None: return
        P = m.P
        if P.win_shade_on:
            for w in m.W_A:
                if hasattr(w, "box"):
                    box = w.box
                    if "shade" in box:
                        rim = box["rim"]
                        shade = m.SHADE(P.win_shade_color)
                        box["shade"] = shade
                        shade.get_by_rim(
                            rim.L, rim.R, rim.B, rim.T,
                            P.win_shade_softness, P.win_shade_offset, P.scale[0])
                        shade.upd()
        else:
            for w in m.W_A:
                if hasattr(w, "box"):
                    if "shade" in w.box:
                        w.box["shade"] = m.BOX_FAKE()
        #
    def upd_format_tx_i(self, context):
        if m.P is None: return
        m.get_format_i()
        #
    def upd_format_tx_h(self, context):
        if m.P is None: return
        m.get_format_h()
        #

    refresh: BoolProperty(name = "", default = True, update = upd_refresh)

    # Global
    keys_sel_fast: IntVectorProperty    (name = "Select Button",
        description = "Left mouse button",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_sel: IntVectorProperty         (name = "Select Button",
        description = "Left mouse button",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000001000000010))
    keys_sel_ext: IntVectorProperty     (name = "Select Extend",
        description = "Extend Select",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000100111011, 0b111110100110011001100110011010, #Lctrl mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000010))
    keys_bu_sel: IntVectorProperty      (name = "Button Execute",
        description = "Execute the button function",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000010))
    keys_bu_qe: IntVectorProperty       (name = "Quick Edit",
        description = "Quick edit button values",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000011011, 0b111110100110011001100110011010, #E
        0b00000000000000000000000100000101))
    keys_bu_qe_E: IntVectorProperty     (name = "Quick Edit End",
        description = "Quick edit button values End",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000011011, 0b111110100110011001100110011010, #E
        0b00000000000000000000000100000010))
    keys_bu_qe_cancel: IntVectorProperty(name = "Quick Edit Cancel",
        description = "Cancel Quick Edit and restore the value",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000100, 0b111110100110011001100110011010, #esc
        0b00000000000000000000000000000011, 0b111110100110011001100110011010, #mouR
        0b00000000000000000000001000000001))
    keys_bu_qe_slow: IntVectorProperty  (name = "Quick Edit Slow",
        description = "Decrease the unit in Quick Edit while holding the key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000111011, 0b111110100110011001100110011010, #ctrl
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000001000000001))
    keys_bu_qe_fast: IntVectorProperty  (name = "Quick Edit Fast",
        description = "Increase the unit in Quick Edit while holding the key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000111101, 0b111110100110011001100110011010, #shift
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000001000000001))
    keys_bu_reset: IntVectorProperty    (name = "Reset",
        description = "Reset value",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001001001, 0b111110100110011001100110011010, #BS
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_rm: IntVectorProperty          (name = "Context Menu",
        description = "Open context menu",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000011, 0b111110100110011001100110011010, #mouR
        0b00000000000000000000000001000010, 0b111110100110011001100110011010, #App
        0b00000000000011000000000100000010))
    keys_cancel: IntVectorProperty      (name = "Cancel",
        description = "Cancel key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000100, 0b111110100110011001100110011010, #esc
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_confirm: IntVectorProperty     (name = "Confirm",
        description = "Confirm key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000110, 0b111110100110011001100110011010, #enter
        0b00000000000000000000000001101001, 0b111110100110011001100110011010, #Nenter
        0b00000000000011000000000100000001))
    keys_pan: IntVectorProperty         (name = "Pan",
        description = "Pan key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000010, 0b111110100110011001100110011010, #mid
        0b00000000000000000000000001000111, 0b111110100110011001100110011010, #space
        0b00000000000011000000000100000101))
    keys_pan_E: IntVectorProperty       (name = "Pan End",
        description = "Pan key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000010, 0b111110100110011001100110011010, #mid
        0b00000000000000000000000001000111, 0b111110100110011001100110011010, #space
        0b00000000000011000000000100000010))
    keys_glopan: IntVectorProperty      (name = "Pan Global",
        description = "Global pan",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000011, 0b111110100110011001100110011010, #mouR
        0b00000000000000000000000001000111, 0b111110100110011001100110011010, #space
        0b00000000000011000000000100000101))
    keys_glopan_E: IntVectorProperty    (name = "Pan Global End",
        description = "Global pan",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000011, 0b111110100110011001100110011010, #mouR
        0b00000000000000000000000001000111, 0b111110100110011001100110011010, #space
        0b00000000000011000000000100000010))
    keys_ti_bu: IntVectorProperty       (name = "Title Bar Button",
        description = "Button in title bar",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouseL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_ti_bu_E: IntVectorProperty     (name = "Title Bar Button End",
        description = "Button in title bar",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouseL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_ti_mov: IntVectorProperty      (name = "Title Bar Move",
        description = "Move the window",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouseL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_ti_mov_E: IntVectorProperty    (name = "Title Bar Move End",
        description = "Move the window",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouseL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_resize: IntVectorProperty      (name = "Window Resize",
        description = "Resize the window",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouseL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_resize_E: IntVectorProperty    (name = "Window Resize End",
        description = "Resize the window",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouseL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_undo: IntVectorProperty        (name = "Undo",
        description = "Global undo",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000011000000111011, 0b111110100110011001100110011010, #ctrl Z
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_redo: IntVectorProperty        (name = "Redo",
        description = "Global redo",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000001100000011110100111011, 0b111110100110011001100110011010, #ctrl shift Z
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_batch: IntVectorProperty       (name = "Batch",
        description = "Batch funtion",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000100111100, 0b111110100110011001100110011010, #alt mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))

    # Modifier Editor
    keys_me_sel: IntVectorProperty          (name = "Select (Modifier Editor)",
        description = "Left mouse button",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_me_sel_ext: IntVectorProperty      (name = "Select Extend (Modifier Editor)",
        description = "Select the modifiers (Extend)",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000100111011, 0b111110100110011001100110011010, #Lctrl mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000010000000000100000010))
    keys_me_pan: IntVectorProperty          (name = "Pan (Modifier Editor)",
        description = "Pan key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000010, 0b111110100110011001100110011010, #mid
        0b00000000000000000000000001000111, 0b111110100110011001100110011010, #space
        0b00000000000011000000000100000101))
    keys_me_pan_E: IntVectorProperty        (name = "Pan (Modifier Editor) End",
        description = "Pan key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000010, 0b111110100110011001100110011010, #mid
        0b00000000000000000000000001000111, 0b111110100110011001100110011010, #space
        0b00000000000011000000000100000010))
    keys_me_box: IntVectorProperty          (name = "Select Box",
        description = "Use the selection box to select modifiers",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000101))
    keys_me_box_E: IntVectorProperty        (name = "Select Box End",
        description = "Use the selection box to select modifiers",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_me_box_ext: IntVectorProperty      (name = "Select Box Extend",
        description = "Use the selection box to select modifiers (Extend)",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000100111011, 0b111110100110011001100110011010, #Lctrl, mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000101))
    keys_me_box_ext_E: IntVectorProperty    (name = "Select Box Extend End",
        description = "Use the selection box to select modifiers (Extend)",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_me_sort: IntVectorProperty         (name = "Sorting",
        description = "Change the order of modifiers",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000001111001, 0b111110100110011001100110011010, #F15
        0b00000000000011000000000100000010))
    keys_me_sort_E: IntVectorProperty       (name = "Sorting End",
        description = "Change the order of modifiers",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000001111001, 0b111110100110011001100110011010, #F15
        0b00000000000011000000000100000001))
    keys_me_rename: IntVectorProperty       (name = "Rename",
        description = "Rename key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000001101100, 0b111110100110011001100110011010, #F2
        0b00000000000011000000000100000011))
    keys_me_all: IntVectorProperty          (name = "Select All",
        description = "Select all modifiers, deselect all inactive modifiers when all modifiers are selected",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000010111, 0b111110100110011001100110011010, #A
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_me_act_up: IntVectorProperty       (name = "Set Active Up",
        description = "Activate top modifier",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000010000, 0b111110100110011001100110011010, #mouUp
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_me_act_dn: IntVectorProperty       (name = "Set Active Down",
        description = "Activate bottom modifier",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000010001, 0b111110100110011001100110011010, #mouDn
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_me_act_up_ext: IntVectorProperty   (name = "Set Active Up Extend",
        description = "Activate top modifier (Extend)",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000001000000111011, 0b111110100110011001100110011010, #Lctrl mouUp
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_me_act_dn_ext: IntVectorProperty   (name = "Set Active Down Extend",
        description = "Activate bottom modifier (Extend)",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000001000100111011, 0b111110100110011001100110011010, #Lctrl mouDn
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_me_mod_up: IntVectorProperty       (name = "Modifier Move Up",
        description = "move modifiers up",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000001000000111101, 0b111110100110011001100110011010, #Lshift mouUp
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_me_mod_dn: IntVectorProperty       (name = "Modifier Move Down",
        description = "move modifiers down",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000001000100111101, 0b111110100110011001100110011010, #Lshift mouDn
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_me_del: IntVectorProperty          (name = "Modifier Delete",
        description = "Delete all selected modifiers",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000101110, 0b111110100110011001100110011010, #X
        0b00000000000000000000000001001010, 0b111110100110011001100110011010, #Del
        0b00000000000011000000000100000001))
    keys_me_apply: IntVectorProperty        (name = "Modifier Apply",
        description = "Apply all selected modifiers",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000001011100111011, 0b111110100110011001100110011010, #Lctrl A
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))

    keys_dd_del_alp: IntVectorProperty      (name = "Backspace",
        description = "Delete character from the text cursor",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001001001, 0b111110100110011001100110011010, #BS
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_del_word: IntVectorProperty     (name = "Delete Word",
        description = "Delete word from the text cursor",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000100100100111011, 0b111110100110011001100110011010, #LCtrl BS
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_del_all: IntVectorProperty      (name = "Delete All",
        description = "Delete all character",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001001010, 0b111110100110011001100110011010, #DEL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_left: IntVectorProperty         (name = "Cursor Left",
        description = "Move the text cursor left",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001010111, 0b111110100110011001100110011010, #LEFT
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_right: IntVectorProperty        (name = "Cursor Right",
        description = "Move the text cursor right",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001011001, 0b111110100110011001100110011010, #RIGHT
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_up: IntVectorProperty           (name = "Cursor Up",
        description = "Move the text cursor up",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001011010, 0b111110100110011001100110011010, #UP
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_down: IntVectorProperty         (name = "Cursor Down",
        description = "Move the text cursor down",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001011000, 0b111110100110011001100110011010, #DOWN
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_shift_left: IntVectorProperty   (name = "Cursor Select Left",
        description = "Move the text cursor left and select",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000101011100111101, 0b111110100110011001100110011010, #LSHIFT LEFT
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_shift_right: IntVectorProperty  (name = "Cursor Select Right",
        description = "Move the text cursor right and select",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000101100100111101, 0b111110100110011001100110011010, #LSHIFT RIGHT
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_shift_up: IntVectorProperty     (name = "Cursor Select Up",
        description = "Move the text cursor up and select",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000101101000111101, 0b111110100110011001100110011010, #LSHIFT UP
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_shift_down: IntVectorProperty   (name = "Cursor Select Down",
        description = "Move the text cursor down and select",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000101100000111101, 0b111110100110011001100110011010, #LSHIFT DOWN
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_pan: IntVectorProperty          (name = "Pan (Drop Down Menu)",
        description = "Pan key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000010, 0b111110100110011001100110011010, #mid
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000101))
    keys_dd_pan_E: IntVectorProperty        (name = "Pan (Drop Down Menu) End",
        description = "Pan key",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000010, 0b111110100110011001100110011010, #mid
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_dd_box: IntVectorProperty          (name = "Select Box (Drop Down Menu)",
        description = "Use the selection box to select text",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000101))
    keys_dd_box_E: IntVectorProperty        (name = "Select Box (Drop Down Menu) End",
        description = "Use the selection box to select text",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_dd_sel: IntVectorProperty          (name = "Select (Drop Down Menu)",
        description = "Left click to move the text cursor",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_dd_sel_all: IntVectorProperty      (name = "Select All (Drop Down Menu)",
        description = "Select all characters",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000001011100111011, 0b111110100110011001100110011010, #LCtrl A
        0b00000000000011000000000100000011))
    keys_dd_copy: IntVectorProperty         (name = "Copy",
        description = "Copy text",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000001100100111011, 0b111110100110011001100110011010, #LCtrl C
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_dd_paste: IntVectorProperty        (name = "Paste",
        description = "Paste text",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000010110000111011, 0b111110100110011001100110011010, #LCtrl V
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_dd_cut: IntVectorProperty          (name = "Cut",
        description = "Cut text",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000010111000111011, 0b111110100110011001100110011010, #LCtrl X
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_dd_cancel: IntVectorProperty       (name = "Cancel (Drop Down Menu)",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000100, 0b111110100110011001100110011010, #esc
        0b00000000000000000000000000000011, 0b111110100110011001100110011010, #mouR
        0b00000000000000000000001000000001))
    keys_dd_confirm: IntVectorProperty      (name = "Confirm (Drop Down Menu)",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000110, 0b111110100110011001100110011010, #enter
        0b00000000000000000000000001101001, 0b111110100110011001100110011010, #Nenter
        0b00000000000011000000000100000001))
    keys_dd_bar: IntVectorProperty          (name = "Scroll Bar",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_dd_bar_E: IntVectorProperty        (name = "Scroll Bar End",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000010))
    keys_dd_tab: IntVectorProperty          (name = "Tab",
        description = "Paste text from the filter",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000101, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_dd_scroll_up: IntVectorProperty    (name = "Scroll Up",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000010000, 0b111110100110011001100110011010, #wheel up
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_dd_scroll_down: IntVectorProperty  (name = "Scroll Down",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000010001, 0b111110100110011001100110011010, #wheel down
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))

    keys_cp_hue_sel: IntVectorProperty      (name = "Hue Select",
        description = "Hue in Color Panel",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000000000, 0b111110100110011001100110011010,
        0b00000000000000000000000100000001))
    keys_cp_hue: IntVectorProperty          (name = "Hue Select Continue",
        description = "Hue in Color Panel",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000011011, 0b111110100110011001100110011010, #E
        0b00000000000000000000000100000101))
    keys_cp_hue_E: IntVectorProperty        (name = "Hue Select Continue End",
        description = "Hue in Color Panel",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000000011011, 0b111110100110011001100110011010, #E
        0b00000000000000000000000100000010))

    keys_pk_cancel: IntVectorProperty       (name = "Picker Cancel",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000100, 0b111110100110011001100110011010, #esc
        0b00000000000000000000000000000011, 0b111110100110011001100110011010, #mouR
        0b00000000000000000000000100000001))
    keys_pk_confirm: IntVectorProperty      (name = "Picker Confirm",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000110, 0b111110100110011001100110011010, #enter
        0b00000000000000000000000000000001, 0b111110100110011001100110011010, #mouL
        0b00000000000000000000000100000001))

    keys_tex_cancel: IntVectorProperty      (name = "Cancel (Text Editor)",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001000100, 0b111110100110011001100110011010, #esc
        0b00000000000000000000000000000011, 0b111110100110011001100110011010, #mouR
        0b00000000000000000000000100000001))


    keys_rm_1: IntVectorProperty            (name = "Button 1",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000110010, 0b111110100110011001100110011010,
        0b00000000000000000000000001011111, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_2: IntVectorProperty            (name = "Button 2",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000110011, 0b111110100110011001100110011010,
        0b00000000000000000000000001011011, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_3: IntVectorProperty            (name = "Button 3",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000110100, 0b111110100110011001100110011010,
        0b00000000000000000000000001100000, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_4: IntVectorProperty            (name = "Button 4",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000110101, 0b111110100110011001100110011010,
        0b00000000000000000000000001011100, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_5: IntVectorProperty            (name = "Button 5",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000110110, 0b111110100110011001100110011010,
        0b00000000000000000000000001100001, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_6: IntVectorProperty            (name = "Button 6",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000110111, 0b111110100110011001100110011010,
        0b00000000000000000000000001011101, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_7: IntVectorProperty            (name = "Button 7",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000111000, 0b111110100110011001100110011010,
        0b00000000000000000000000001100010, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_8: IntVectorProperty            (name = "Button 8",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000111001, 0b111110100110011001100110011010,
        0b00000000000000000000000001011110, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_9: IntVectorProperty            (name = "Button 9",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000111010, 0b111110100110011001100110011010,
        0b00000000000000000000000001100011, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_0: IntVectorProperty            (name = "Button 10",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000000110001, 0b111110100110011001100110011010,
        0b00000000000000000000000001100111, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_back: IntVectorProperty         (name = "Previous Page",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001010111, 0b111110100110011001100110011010,
        0b00000000000000000000000010000110, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))
    keys_rm_next: IntVectorProperty         (name = "Next Page",
        description = "",
        options = {'HIDDEN'}, size = 5, default = (
        0b00000000000000000000000001011001, 0b111110100110011001100110011010,
        0b00000000000000000000000010000111, 0b111110100110011001100110011010,
        0b00000000000011000000000100000001))


    calc_13iqe:     FloatProperty(name = "Quick Edit factor :  int",
        min = 0.000001, max = 65535.0, default = 1.0,
        description = "Value type: int")
    calc_13i1:      StringProperty(name = "", options = {'HIDDEN'}, default = "- 1 ")
    calc_13i1ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x-1")
    calc_13i2:      StringProperty(name = "", options = {'HIDDEN'}, default = "+ 1")
    calc_13i2ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x+1")
    calc_13i3:      StringProperty(name = "", options = {'HIDDEN'}, default = "Ran [0,100]")
    calc_13i3ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "round(100*random())")
    calc_13i4:      StringProperty(name = "", options = {'HIDDEN'}, default = "- 10 ")
    calc_13i4ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x-10")
    calc_13i5:      StringProperty(name = "", options = {'HIDDEN'}, default = "+ 10")
    calc_13i5ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x+10")
    calc_13i6:      StringProperty(name = "", options = {'HIDDEN'}, default = "= 0")
    calc_13i6ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "0")
    calc_13i7:      StringProperty(name = "", options = {'HIDDEN'}, default = "／2 ")
    calc_13i7ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x/2")
    calc_13i8:      StringProperty(name = "", options = {'HIDDEN'}, default = "╳ 2")
    calc_13i8ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x*2")
    calc_13i9:      StringProperty(name = "", options = {'HIDDEN'}, default = "Init")
    calc_13i9ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "o")
    calc_13i10:     StringProperty(name = "", options = {'HIDDEN'}, default = "√x")
    calc_13i10ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "rt(x)")
    calc_13i11:     StringProperty(name = "", options = {'HIDDEN'}, default = "x ²")
    calc_13i11ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "xx")
    calc_13i12:     StringProperty(name = "", options = {'HIDDEN'}, default = "Ans")
    calc_13i12ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "x")

    calc_01fqe:     FloatProperty(name = "Quick Edit factor :  float [0, 1]",
        min = 0.000001, max = 65535.0, default = 0.001,
        description = "Value type: float, 0 ≦ value ≦ 1")
    calc_01f1:      StringProperty(name = "", options = {'HIDDEN'}, default = "- 0.1 ")
    calc_01f1ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x-0.1")
    calc_01f2:      StringProperty(name = "", options = {'HIDDEN'}, default = "+ 0.1")
    calc_01f2ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x+0.1")
    calc_01f3:      StringProperty(name = "", options = {'HIDDEN'}, default = "Ran [0,1]")
    calc_01f3ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "random()")
    calc_01f4:      StringProperty(name = "", options = {'HIDDEN'}, default = "- 0.01 ")
    calc_01f4ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x-0.01")
    calc_01f5:      StringProperty(name = "", options = {'HIDDEN'}, default = "+ 0.01")
    calc_01f5ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x+0.01")
    calc_01f6:      StringProperty(name = "", options = {'HIDDEN'}, default = "Round 2")
    calc_01f6ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "round(x,2)")
    calc_01f7:      StringProperty(name = "", options = {'HIDDEN'}, default = "／2 ")
    calc_01f7ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x/2")
    calc_01f8:      StringProperty(name = "", options = {'HIDDEN'}, default = "╳ 2")
    calc_01f8ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x*2")
    calc_01f9:      StringProperty(name = "", options = {'HIDDEN'}, default = "Init")
    calc_01f9ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "o")
    calc_01f10:     StringProperty(name = "", options = {'HIDDEN'}, default = "√x")
    calc_01f10ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "rt(x)")
    calc_01f11:     StringProperty(name = "", options = {'HIDDEN'}, default = "x ²")
    calc_01f11ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "xx")
    calc_01f12:     StringProperty(name = "", options = {'HIDDEN'}, default = "Ans")
    calc_01f12ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "x")

    calc_0ifqe:     FloatProperty(name = "Quick Edit factor :  float",
        min = 0.000001, max = 65535.0, default = 0.1,
        description = "Value type: float\n-3.402823 ╳ 10^38 ≦ value ≦ 3.402823 ╳ 10^38")
    calc_0if1:      StringProperty(name = "", options = {'HIDDEN'}, default = "- 0.1 ")
    calc_0if1ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x-0.1")
    calc_0if2:      StringProperty(name = "", options = {'HIDDEN'}, default = "+ 0.1")
    calc_0if2ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x+0.1")
    calc_0if3:      StringProperty(name = "", options = {'HIDDEN'}, default = "Ran [0,1]")
    calc_0if3ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "random()")
    calc_0if4:      StringProperty(name = "", options = {'HIDDEN'}, default = "- 0.01 ")
    calc_0if4ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x-0.01")
    calc_0if5:      StringProperty(name = "", options = {'HIDDEN'}, default = "+ 0.01")
    calc_0if5ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x+0.01")
    calc_0if6:      StringProperty(name = "", options = {'HIDDEN'}, default = "Round 2")
    calc_0if6ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "round(x,2)")
    calc_0if7:      StringProperty(name = "", options = {'HIDDEN'}, default = "／2 ")
    calc_0if7ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x/2")
    calc_0if8:      StringProperty(name = "", options = {'HIDDEN'}, default = "╳ 2")
    calc_0if8ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x*2")
    calc_0if9:      StringProperty(name = "", options = {'HIDDEN'}, default = "Init")
    calc_0if9ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "o")
    calc_0if10:     StringProperty(name = "", options = {'HIDDEN'}, default = "√x")
    calc_0if10ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "rt(x)")
    calc_0if11:     StringProperty(name = "", options = {'HIDDEN'}, default = "x ²")
    calc_0if11ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "xx")
    calc_0if12:     StringProperty(name = "", options = {'HIDDEN'}, default = "Ans")
    calc_0if12ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "x")

    calc_0pfqe:     FloatProperty(name = "Quick Edit factor :  float [0, π]",
        min = 0.000001, max = 65535.0, default = 0.01745329251,
        description = "Value type: float, 0 ≦ value ≦ π")
    calc_0pf1:      StringProperty(name = "", options = {'HIDDEN'}, default = "-  π/180")
    calc_0pf1ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x-pi/180")
    calc_0pf2:      StringProperty(name = "", options = {'HIDDEN'}, default = "+ π/180")
    calc_0pf2ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x+pi/180")
    calc_0pf3:      StringProperty(name = "", options = {'HIDDEN'}, default = "＝π/4")
    calc_0pf3ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "pi/4")
    calc_0pf4:      StringProperty(name = "", options = {'HIDDEN'}, default = "＝π/6 ")
    calc_0pf4ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "pi/6")
    calc_0pf5:      StringProperty(name = "", options = {'HIDDEN'}, default = "＝π/3")
    calc_0pf5ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "pi/3")
    calc_0pf6:      StringProperty(name = "", options = {'HIDDEN'}, default = "＝π")
    calc_0pf6ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "pi")
    calc_0pf7:      StringProperty(name = "", options = {'HIDDEN'}, default = "／2 ")
    calc_0pf7ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x/2")
    calc_0pf8:      StringProperty(name = "", options = {'HIDDEN'}, default = "╳ 2")
    calc_0pf8ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x*2")
    calc_0pf9:      StringProperty(name = "", options = {'HIDDEN'}, default = "Init")
    calc_0pf9ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "o")
    calc_0pf10:     StringProperty(name = "", options = {'HIDDEN'}, default = "√x")
    calc_0pf10ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "rt(x)")
    calc_0pf11:     StringProperty(name = "", options = {'HIDDEN'}, default = "x ²")
    calc_0pf11ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "xx")
    calc_0pf12:     StringProperty(name = "", options = {'HIDDEN'}, default = "Ans")
    calc_0pf12ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "x")

    calc_0dfqe:     FloatProperty(name = "Quick Edit factor :  float [0, 360]",
        min = 0.000001, max = 65535.0, default = 1.0,
        description = "Value type: float, 0 ≦ value ≦ 360")
    calc_0df1:      StringProperty(name = "", options = {'HIDDEN'}, default = "- 1 ")
    calc_0df1ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x-1")
    calc_0df2:      StringProperty(name = "", options = {'HIDDEN'}, default = "+ 1")
    calc_0df2ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x+1")
    calc_0df3:      StringProperty(name = "", options = {'HIDDEN'}, default = "＝45")
    calc_0df3ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "45")
    calc_0df4:      StringProperty(name = "", options = {'HIDDEN'}, default = "＝30 ")
    calc_0df4ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "30")
    calc_0df5:      StringProperty(name = "", options = {'HIDDEN'}, default = "＝60")
    calc_0df5ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "60")
    calc_0df6:      StringProperty(name = "", options = {'HIDDEN'}, default = "＝90")
    calc_0df6ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "90")
    calc_0df7:      StringProperty(name = "", options = {'HIDDEN'}, default = "／2 ")
    calc_0df7ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x/2")
    calc_0df8:      StringProperty(name = "", options = {'HIDDEN'}, default = "╳ 2")
    calc_0df8ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "x*2")
    calc_0df9:      StringProperty(name = "", options = {'HIDDEN'}, default = "Init")
    calc_0df9ex:    StringProperty(name = "", options = {'HIDDEN'}, default = "o")
    calc_0df10:     StringProperty(name = "", options = {'HIDDEN'}, default = "√x")
    calc_0df10ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "rt(x)")
    calc_0df11:     StringProperty(name = "", options = {'HIDDEN'}, default = "x ²")
    calc_0df11ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "xx")
    calc_0df12:     StringProperty(name = "", options = {'HIDDEN'}, default = "Ans")
    calc_0df12ex:   StringProperty(name = "", options = {'HIDDEN'}, default = "x")


    de: IntVectorProperty(
        name = "Debug int", min = -65535, max = 65535, size = 2, update = upd_F)
    test: FloatVectorProperty(
        name = "Test", subtype = "COLOR", size = 3, min = 0.0, max = 1.0,
        default = (0.28, 0.28, 0.28),
        description = "")

    win_pos_init: IntVectorProperty(
        name = "Position: Initial window", subtype = "TRANSLATION", min = -65535, max = 65535,
        size = 2, default = (50, 739),
        description = "Window position （Pixels） when called")
    win_size_init: IntVectorProperty(
        name = "Size: Initial window (Modifier Editor)", subtype = "TRANSLATION", min = 24, max = 65535,
        size = 2, default = (584, 713),
        description = "Modifier Editor size （Pixels） when called")
    win_size_init_DE: IntVectorProperty(
        name = "Size: Initial window (Driver Editor)", subtype = "TRANSLATION", min = 24, max = 65535,
        size = 2, default = (584, 564),
        description = "Driver Editor size （Pixels） when called")
    win_size_init_ME: IntVectorProperty(
        name = "Size: Initial window (Mesh Editor)", subtype = "TRANSLATION", min = 24, max = 65535,
        size = 2, default = (378, 422),
        description = "Mesh Editor size （Pixels） when called")
    scale: FloatVectorProperty(
        name = "Scale: Global / Title", subtype = "NONE", min = 0.0, max = 65535.0,
        size = 2, default = (1.2, 1.0),
        update = upd_F,
        description = "Window scale and Title bar scale")
    scale_ti_bu: FloatProperty(
        name = "Scale: Title button", min = 0.0, max = 1.0,
        default = 0.85,
        update = upd_F,
        description = "Title bar button scale")
    ti_font_size: FloatProperty(
        name = "Size: Title bar text", min = 0.0, max = 26.0,
        default = 13.0,
        update = upd_F,
        description = "Title bar text size")
    win_border: IntProperty(
        name = "Border: Window", min = 0, max = 65535,
        default = 3,
        update = upd_F,
        description = "Window border in pixels, Ignore global scale")
    win_border_inner: IntProperty(
        name = "Border: Window (Inner)", min = 0, max = 65535,
        default = 3,
        update = upd_F,
        description = "Window inner border in pixels, Ignore global scale")
    win_offset_init: IntVectorProperty(
        name = "Window offset", subtype = "TRANSLATION", min = -65535, max = 65535,
        size = 2, default = (100, 100),
        description = "Offsets the window when opening if a window of the same type already exists. In pixels, Ignore global scale")
    win_offset_top: IntVectorProperty(
        name = "Top Window offset", subtype = "TRANSLATION", min = -65535, max = 65535,
        size = 2, default = (30, -30),
        description = "Offsets the window from cursor position. For opening from a window. In pixels, Ignore global scale")
    win_shade_offset: FloatVectorProperty(
        name = "Shadow offset", subtype = "NONE", min = -65535.0, max = 65535.0,
        size = 4, default = (-10.0, 20.0, -23.0, -3.0),
        update = upd_pos,
        description = "Window drop shadow offset")
    win_shade_softness: FloatProperty(
        name = "Shadow softness", min = 0.0, max = 65535.0,
        default = 25.0,
        update = upd_pos,
        description = "Window drop shadow softness, 0 is the hardest, Ignore global scale")
    win_shade_color: FloatVectorProperty(
        name = "Shadow color", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -2.2,
        default = (0.014, 0.014, 0.014, 0.74),
        description = "Window drop shadow color")
    dd_shade_offset: FloatVectorProperty(
        name = "Shadow offset (Drop Down Menu)", subtype = "NONE", min = -65535.0, max = 65535.0,
        size = 4, default = (-10.0, 12.0, -16.0, 5.0),
        description = "Drop Down Menu drop shadow offset")
    dd_shade_softness: FloatProperty(
        name = "Shadow softness (Drop Down Menu)", min = 0.0, max = 65535.0,
        default = 25.0,
        description = "Drop Down Menu drop shadow softness, 0 is the hardest, Ignore global scale")
    dd_shade_color: FloatVectorProperty(
        name = "Shadow color (Drop Down Menu)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -2.2,
        default = (0.014, 0.014, 0.014, 0.5),
        description = "Drop Down Menu drop shadow color")


    win_shade_on: BoolProperty(
        name = "Enable Shadow", default = True,
        update = upd_shade,
        description = "Enable drop shadow")
    lock_win_size: BoolProperty(
        name = "Lock: Window size",  default = False,
        update = upd_P,
        description = "Not allow resize window when mouse is focused on window corner")
    sys_auto_off: BoolProperty(
        name = "Auto off system",  default = True,
        description = "Automatically close Addon system when there is no window")
    sync_act_oj: BoolProperty(
        name = "Sync active object",  default = True,
        description = "Modifier Editor active object follows blender active object when first Modifier Editor invocation")
    sync_act_md: BoolProperty(
        name = "Sync active modifier",  default = True,
        description = "Modifier Editor active modifier follows blender active modifier when first Modifier Editor invocation")
    auto_sel_text: BoolProperty(
        name = "Auto select text", default = True,
        description = "Select all text when dropdown is opened")
    auto_del_text: BoolProperty(
        name = "Auto delete text", default = False,
        description = "Delete all text when dropdown is opened")
    confirm_rename: BoolProperty(
        name = "Confirm rename", default = True,
        description = "Invokes a confirmation dialog if the name already exists when renaming")
    confirm_del: BoolProperty(
        name = "Confirm delete", default = True,
        description = "Invokes a confirmation dialog when deleting")
    confirm_apply: BoolProperty(
        name = "Confirm apply", default = True,
        description = "Invokes a confirmation dialog when applying")
    anim_tb_task: BoolProperty(
        name = "Animation: Taskbar Task", default = True,
        description = "Enable task animations in the taskbar")
    anim_win_min: BoolProperty(
        name = "Animation: minimize", default = True,
        description = "Enable window minimize animation")
    anim_win_fit: BoolProperty(
        name = "Animation: fit", default = True,
        description = "In development")
    anim_win_x: BoolProperty(
        name = "Animation: close", default = True,
        description = "In development")
    vbox_precise_mode: BoolProperty(
        name = "Value Box: Precise mode", default = False,
        description = "Get more digits of float value when inputting in value box")
    mesh_ed_local: BoolProperty(
        name = "Mesh Editor: Local space", default = False,
        description = "Local / Global space (Editor invoke)")
    mesh_ed_dis_invert: BoolProperty(
        name = "Mesh Editor: Invert vertex", default = False,
        description = "If true, move from the non-active vertex (Editor invoke)")
    mesh_ed_face_nor_keep_act: BoolProperty(
        name = "Mesh Editor: Lock active vertex", default = False,
        description = "If true, keep active vertex location (Editor invoke)")
    mesh_ed_face_nor_keep_nor: BoolProperty(
        name = "Mesh Editor: Keep normals to other faces", default = False,
        description = "Keep normals of unselected faces if possible (Editor invoke)")
    mesh_ed_cop_vert: BoolProperty(
        name = "Mesh Editor: Include selected vertices", default = False,
        description = "If false, only count selected faces (Editor invoke)")
    cursor_thickness: IntProperty(
        name = "Text cursor thickness", default = 1, min = 1, max = 6,
        description = "Text cursor thickness in unit")
    cursor_flash_rate: FloatProperty(name = "Text cursor flash period", default = 0.4, min = 0.0001,
        description = "How long the text cursor blinks once\nUnit in 2 seconds")
    pan_method: EnumProperty(
        name = "Pan method",
        items = (
            ("I_pan", "Default", ""), ("I_pan_invert", "Invert", ""),
            ("I_pan_hide", "Hide cursor", ""),
            ("I_pan_hide_invert", "Hide cursor (Invert)", "")
        ),
        default = "I_pan",
        update = upd_P,
        description = "Pan method")
    win_pos_protect: EnumProperty(
        name = "Protect window position",
        items = (("DISABLE", "Disable", ""), ("TITLE_HEIGHT", "Title", "")),
        default = "TITLE_HEIGHT",
        update = upd_pos_protect,
        description = "Avoid the whole windows outside the region when move the window")
    quick_edit_method: EnumProperty(
        name = "Quick Edit method",
        items = (("HORIZONTAL", "Horizontal", ""), ("VERTICAL", "Vertical", "")),
        default = "HORIZONTAL",
        description = "Mouse cursor offset method when dragging the value box")
    quick_edit_operation: EnumProperty(
        name = "Quick Edit operation",
        items = (("REAL_TIME", "Real Time", ""), ("PERFORMANCE", "Performance", "")),
        default = "REAL_TIME",
        description = "Value update method when dragging the value box.\nReal Time : Live update \nPerformance : Update when done")
    quick_edit_cursor: EnumProperty(
        name = "Quick Edit cursor",
        items = cursors,
        default = "NONE",
        description = "Cursor appearance when dragging the value box")
    quick_edit_fac_slow: FloatProperty(
        name = "Quick Edit factor (slow)", min = 0.000001, max = 65535.0,
        default = 0.1,
        description = "Numeric factor while holding down the Slow-Key while dragging the value box")
    quick_edit_fac_fast: FloatProperty(
        name = "Quick Edit factor (fast)", min = 0.000001, max = 65535.0,
        default = 10.0,
        description = "Numeric factor while holding down the Fast-Key while dragging the value box")
    quick_edit_fac_slow_hue: FloatProperty(
        name = "Color Panel hue speed factor (slow)", min = 0.000001, max = 65535.0,
        default = 0.1,
        description = "Numeric factor while holding down the Slow-Key while dragging the Hue of Color Panel")
    quick_edit_fac_fast_hue: FloatProperty(
        name = "Color Panel hue speed fator (fast)", min = 0.000001, max = 65535.0,
        default = 2.0,
        description = "Numeric factor while holding down the Fast-Key while dragging the Hue of Color Panel")
    filter_algorithm: EnumProperty(
        name = "Filter algorithm",
        items = (
            ("DISABLE", "Disable Filter", ""),
            ("BIN_MATCH", "Binary search (Match)", ""),
        ),
        default = "BIN_MATCH",
        description = "Filtering Algorithms for Searching Text")
    dd_num_type: EnumProperty(
        name = "Value Box Style",
        items = (
            ("SIMPLE", "Simple", ""),
            ("COMPLEX", "Complex", ""),
        ),
        default = "COMPLEX",
        description = "Dropdown menu style for value box\nSimple : Show only the currently edited value\nComplex : Show the calculator")
    dd_width: IntProperty(
        name = "Drop Down Menu width", min = 100, max = 65535,
        default = 208,
        description = "Modifier Editor dropdown menu width of Change object function")
    anim_frame_time: FloatProperty(
        name = "Animation frame time", min = 0.0001, max = 1.0,
        default = 0.005,
        description = "Minimum animation frame time in seconds")
    anim_speed: IntProperty(
        name = "Animation speed", min = 1, max = 65535,
        default = 2,
        description = "Movement distance of animation\nPixels per frame, Ignore global scale")
    auto_pan_speed: FloatProperty(
        name = "Auto pan speed", min = 0.00001, max = 65535.0, default = 0.001,
        description = "Speed Factor, bigger is faster, automatically pan when the mouse moves out of the area, for move the modifiers in Modifier Editor")
    th_drag: IntProperty(
        name = "Drag threshold", min = 0, max = 10, default = 3,
        description = "The drag distance that triggers the drag type keymap\n（Pixels, Ignore global scale）")
    th_multi_drag: IntProperty(
        name = "Multi Drag threshold", min = 1, max = 65535, default = 20,
        description = "The drag distance that triggers the multi drag\n（Pixels, Ignore global scale）")
    bu_auto_speed: FloatProperty(
        name = "Button repeat period", min = 0.0001, max = 10, default = 0.05,
        description = "Time in seconds. Trigger tempo repeatedly while holding keymap in special button")
    bu_auto_time: FloatProperty(
        name = "Button start repeat time", min = 0.0, max = 10, default = 0.5,
        description = "Time in seconds. How long from the first press to trigger the repeat function")
    scroll_fac: IntProperty(
        name = "Scroll speed", min = 1, max = 65535, default = 20,
        description = "Panning distance of the scroll button\n（Pixels, Ignore global scale）")
    format_tx_f: EnumProperty(
        name = "Float value display format",
        items = (("R_str_by_inter_6", "Align Spacing 3 float 6", ""),),
        default = "R_str_by_inter_6",

        description = "Float value display format of value box\nRestart Required")
    format_tx_i: EnumProperty(
        name = "Integer value display format",
        items = (
            ("R_str_by_inter_int", "Align Spacing 3 int", ""),
            ("R_str_by_inter_6", "Align Spacing 3 float 6", "")),
        default = "R_str_by_inter_int",
        update = upd_format_tx_i,
        description = "Integer value display format of value box\nRestart Required")
    format_tx_h: EnumProperty(
        name = "Hexadecimal color value display format",
        items = (
            ("R_space_HEX", "Upper Spacing 2", ""),
            ("R_space_hex", "Lower Spacing 2", ""),
            ("R_HEX", "Uppercase", ""),
            ("R_hex", "Lowercase", "")),
        default = "R_space_HEX",
        update = upd_format_tx_h,
        description = "Hexadecimal color value display format in color panel\nRestart Required")
    format_tx_vec: EnumProperty(
        name = "Vector display format",
        items = (("R_str_by_inter_6_vec", "Align Spacing 3 float 6", ""),),
        default = "R_str_by_inter_6_vec",

        description = "Vector display format of value box\nRestart Required")


    color_win_rim: FloatVectorProperty(
        name = "Color: Window rim", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.28, 0.28, 0.28, 0.5),
        description = "1 unit window rim color")
    color_win: FloatVectorProperty(
        name = "Color: Window", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.21, 0.21, 1.0),
        description = "Window background color")
    color_win_unfo: FloatVectorProperty(
        name = "Color: Window (Not focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.21, 0.21, 0.9),
        description = "Window background color when the window is inactive")
    color_bg_fo: FloatVectorProperty(
        name = "Color: Background (Message Window)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.5, 0.5, 0.5, 0.03),
        description = "Dialog window background color")
    color_ti_bar: FloatVectorProperty(
        name = "Color: Title bar", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.15, 0.15, 0.15, 0.97),
        description = "Title bar color")
    color_ti_bar_warn: FloatVectorProperty(
        name = "Color: Title bar (Warn)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.4, 0.4, 0.2, 0.97),
        description = "Warning title bar color")
    color_ti_bar_unfo: FloatVectorProperty(
        name = "Color: Title bar (Not focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.175, 0.175, 0.175, 1.0),
        description = "Inactive title bar color")
    color_ti_bu: FloatVectorProperty(
        name = "Color: Title button", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.197, 0.197, 0.197, 1.0),
        description = "Minimize / Fit / Close Button background color in title bar")
    color_ti_bu_fo: FloatVectorProperty(
        name = "Color: Title button (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.25, 0.25, 0.25, 1.0),
        description = "Minimize / Fit / Button background color in title bar when button is focused")
    color_ti_bu_sh: FloatVectorProperty(
        name = "Color: Title button (Icon)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (1.0, 1.0, 1.0, 0.7),
        description = "Minimize / Fit / Close Button icon color in title bar")
    color_ti_bu_sh_hold: FloatVectorProperty(
        name = "Color: Title button (Icon hold)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.0, 0.0, 0.0, 0.75),
        description = "Minimize / Fit / Close Button icon color in title bar when held")
    color_ti_bu_x: FloatVectorProperty(
        name = "Color: Close button (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.75, 0.15, 0.25, 1.0),
        description = "Close Button background color in title bar when button is focused")
    color_oj_info: FloatVectorProperty(
        name = "Color: Object information block", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.175, 0.175, 0.175, 1.0),
        description = "Object information area background color in Modifier/Driver/.. Editor")
    color_bg_mod: FloatVectorProperty(
        name = "Color: Modifier Area", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.21, 0.21, 1.0),
        description = "Modifier list background color in Modifier Editor")
    color_box_mod: FloatVectorProperty(
        name = "Color: Modifier Block (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.17, 0.17, 0.17, 1.0),
        description = "Modifier element background color in the Modifier list of the Modifier Editor")
    color_box_mod_sel: FloatVectorProperty(
        name = "Color: Modifier Block (BG Select)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.12, 0.12, 0.12, 1.0),
        description = "Modifier element background color in the Modifier list of the Modifier Editor if element is selected")
    color_box_mod_act: FloatVectorProperty(
        name = "Color: Modifier Active Block (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.168, 0.18, 0.188, 0.93),
        description = "Modifier Acitve Block background color in Modifier element")
    color_box_mod_act_rim: FloatVectorProperty(
        name = "Color: Modifier Active Block (Rim)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.6, 0.495, 0.148, 1.0),
        description = "Modifier Acitve Block rim color in Modifier element")
    color_mod_bu_fo: FloatVectorProperty(
        name = "Color: Modifier button (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.04, 0.06, 0.06, 0.5),
        description = "Modifier button color in Modifier element")
    color_selbox: FloatVectorProperty(
        name = "Color: Select box", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.3, 0.7, 0.7, 0.04),
        description = "Select box background color")
    color_selbox_rim: FloatVectorProperty(
        name = "Color: Select box rim", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.6, 0.9, 0.9, 0.8),
        description = "Select box rim color")
    color_bu_bg: FloatVectorProperty(
        name = "Color: Button area background", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.19, 0.19, 0.19, 1.0),
        description = "Button area background in Rename Panel")
    color_bu_1_off: FloatVectorProperty(
        name = "Color: Function Button (Off)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.23, 0.23, 0.23, 1.0),
        description = "Function button background color")
    color_bu_1_on: FloatVectorProperty(
        name = "Color: Function Button (On)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.15, 0.15, 0.15, 1.0),
        description = "Function button background color when held")
    color_bu_1_rim: FloatVectorProperty(
        name = "Color: Function Button (Rim)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.29, 0.29, 0.29, 1.0),
        description = "Function button rim color")
    color_bu_1_fo: FloatVectorProperty(
        name = "Color: Function Button (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.25, 0.25, 0.25, 1.0),
        description = "Function button background color when in focus")
    color_bu_1_ignore: FloatVectorProperty(
        name = "Color: Function Button (Disable)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.25, 0.25, 0.25, 1.0),
        description = "Function button background color when the button is disabled")
    color_bu_2: FloatVectorProperty(
        name = "Color: Checkbox icon", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "Checkbox icon color")
    color_bu_2_ignore: FloatVectorProperty(
        name = "Color: Checkbox icon (Disable)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.21, 0.21, 1.0),
        description = "Checkbox icon color when the button is disabled")
    color_bu_3_off: FloatVectorProperty(
        name = "Color: Text box (Off)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.21, 0.21, 1.0),
        description = "Text box background color")
    color_bu_3_on: FloatVectorProperty(
        name = "Color: Text box (On)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.15, 0.15, 0.15, 1.0),
        description = "Text box background color when held")
    color_bu_3_fo: FloatVectorProperty(
        name = "Color: Text box (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.25, 0.25, 0.25, 1.0),
        description = "Text box background color when in focus")
    color_bu_3_ignore: FloatVectorProperty(
        name = "Color: Text box (Disable)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.18, 0.18, 0.18, 1.0),
        description = "Text box background color when the button is disabled")
    color_bu_4_off: FloatVectorProperty(
        name = "Color: Button (Off)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.25, 0.25, 0.25, 1.0),
        description = "Button background color, not in Area Block")
    color_bu_4_on: FloatVectorProperty(
        name = "Color: Button (On)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.15, 0.15, 0.15, 1.0),
        description = "Button background color when held, not in Area Block")
    color_bu_4_rim: FloatVectorProperty(
        name = "Color: Button (Rim)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.33, 0.33, 0.33, 1.0),
        description = "Button rim color, not in Area Block")
    color_bu_4_fo: FloatVectorProperty(
        name = "Color: Button (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.29, 0.29, 0.29, 1.0),
        description = "Button background color when in focus, not in Area Block")
    color_bu_4_ignore: FloatVectorProperty(
        name = "Color: Button (Disable)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.25, 0.25, 0.25, 1.0),
        description = "Button background color when the button is disabled, not in Area Block")
    color_bu_media: FloatVectorProperty(
        name = "Color: Button Media", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.4, 0.4, 0.4, 1),
        description = "Next / Back Icon color")
    color_bu_media_fo: FloatVectorProperty(
        name = "Color: Button Media (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.6, 0.6, 0.6, 1),
        description = "Next / Back Icon color when in focus")
    color_bu_media_on: FloatVectorProperty(
        name = "Color: Button Media (On)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.3, 0.5, 0.6, 1),
        description = "Next / Back Icon color when held")
    color_bu_media_ignore: FloatVectorProperty(
        name = "Color: Button Media (Disable)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.25, 0.25, 0.25, 1),
        description = "Next / Back Icon color when the button is disabled")
    color_tb_bg: FloatVectorProperty(
        name = "Color: Taskbar background", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.1, 0.1, 0.1, 0.9),
        description = "Bottom Taskbar background color")
    color_menu_start_bg: FloatVectorProperty(
        name = "Color: Start Menu background", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.16, 0.16, 0.16, 0.9),
        description = "Bottom Taskbar background color")
    color_mi_act: FloatVectorProperty(
        name = "Color: Task active box", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.114, 0.266, 0.311, 0.5),
        description = "Active box color of the Task in Taskbar")
    color_mi_bg: FloatVectorProperty(
        name = "Color: Task background", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.16, 0.16, 0.16, 1.0),
        description = "Task background color in Taskbar")
    color_mi_bg_fo: FloatVectorProperty(
        name = "Color: Task background (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.19, 0.19, 0.19, 1.0),
        description = "Task background color in Taskbar when in focus")
    color_mi_ti: FloatVectorProperty(
        name = "Color: Task Title", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "Font color of the Task in Taskbar")
    color_mi_ti_off: FloatVectorProperty(
        name = "Color: Task Title (Off)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.3, 0.3, 0.3, 1.0),
        description = "Font color of the Task in Taskbar when inactive")
    color_setting_act: FloatVectorProperty(
        name = "Color: Settings active box", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.18, 0.3, 0.31, 1.0),
        description = "Active Box color in Settings")
    color_setting_bo: FloatVectorProperty(
        name = "Color: Settings Tab", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.185, 0.185, 0.185, 1.0),
        description = "Tabs color in Settings")
    color_setting_bo_fo: FloatVectorProperty(
        name = "Color: Settings Tab (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.05, 0.05, 0.05, 0.2),
        description = "Tabs color in Settings when in focus")
    color_picker_bg: FloatVectorProperty(
        name = "Color: Color Panel BG", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.21, 0.21, 1.0),
        description = "Color Panel background color")
    color_picker_bg_hue: FloatVectorProperty(
        name = "Color: Color Panel Hue BG", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.19, 0.19, 0.19, 1.0),
        description = "Color Panel Hue background color")
    color_picker_bg_hue_fo: FloatVectorProperty(
        name = "Color: Color Panel Hue BG (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.17, 0.17, 0.17, 1.0),
        description = "Color Panel Hue background focus color")
    color_picker_bu: FloatVectorProperty(
        name = "Color: Color Panel Hue button", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (1.0, 1.0, 1.0, 1.0),
        description = "Color Panel Hue button color")


    color_mesh_ed_block: FloatVectorProperty(
        name = "Color: Mesh Editor Block", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.185, 0.185, 0.185, 1.0),
        description = "Block background color in Mesh Editor")


    color_ddmenu: FloatVectorProperty(
        name = "Color: Drop down menu (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.21, 0.21, 1.0),
        description = "Drop down menu background color")
    color_dd_actbox: FloatVectorProperty(
        name = "Color: Drop down menu (Active Box)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.185, 0.185, 0.185, 1.0),
        description = "Drop down menu Active Box color")
    color_filter: FloatVectorProperty(
        name = "Color: Filter/Calculator display (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.2, 0.2, 0.2, 1.0),
        description = "Area Block background color in Filter/Calculator")
    color_calc_bu: FloatVectorProperty(
        name = "Color: Calculator area", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.185, 0.185, 0.185, 1.0),
        description = "Area Block background color in Calculator button")
    color_scroll_rim: FloatVectorProperty(
        name = "Color: Scroll bar (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.17, 0.17, 0.17, 1.0),
        description = "Scroll bar background color")
    color_scroll_rim_fo: FloatVectorProperty(
        name = "Color: Scroll bar (BG Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.175, 0.175, 0.175, 1.0),
        description = "Scroll bar background color when in focus")
    color_scroll_bar_rim: FloatVectorProperty(
        name = "Color: Scroll button (Rim)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.29, 0.29, 0.29, 1.0),
        description = "Scroll bar rim color")
    color_scroll_bar_bg: FloatVectorProperty(
        name = "Color: Scroll button (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.23, 0.23, 0.23, 1.0),
        description = "Scroll button color")
    color_scroll_bar_fo: FloatVectorProperty(
        name = "Color: Scroll button (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.24, 0.24, 0.24, 1.0),
        description = "Scroll button color when in focus")
    color_tx_cursor: FloatVectorProperty(
        name = "Color: Text cursor", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.9, 0.9, 0.9, 0.9),
        description = "Text cursor color")
    color_tx_sel: FloatVectorProperty(
        name = "Color: Highlight text", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.3, 0.5, 0.8, 0.4),
        description = "Highlight block color in Text area")
    color_tx_copy: FloatVectorProperty(
        name = "Color: Highlight text copy", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.3, 0.5, 0.8, 0.05),
        description = "Highlight block color while holding down copy shortcut")
    color_r_menu_bg: FloatVectorProperty(
        name = "Color: Context menu (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.18, 0.18, 0.18, 1.0),
        description = "Right click menu background color")
    color_r_menu: FloatVectorProperty(
        name = "Color: Context menu", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.16, 0.16, 0.16, 1.0),
        description = "Right click menu area color")
    color_flash_box: FloatVectorProperty(
        name = "Color: Flash box", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.0, 0.0, 0.0, 0.2),
        description = "Flash box color")
    color_rm_bg: FloatVectorProperty(
        name = "Color: Text Context menu (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.15, 0.15, 0.15, 1.0),
        description = "Text Context menu background color")
    color_rm_fobox: FloatVectorProperty(
        name = "Color: Text Context menu Focus Box", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.35, 0.38, 1.0),
        description = "Text Context menu Focus Box color")
    color_tex_bg: FloatVectorProperty(
        name = "Color: Text Editor (BG)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.21, 0.21, 0.21, 1.0),
        description = "In development")
    color_tex_main: FloatVectorProperty(
        name = "Color: Text Editor (Main)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.18, 0.18, 0.18, 1.0),
        description = "In development")


    color_icon_1: FloatVectorProperty(
        name = "Icon color: 1", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.574, 0.293, 1.0),
        description = "")
    color_icon_2: FloatVectorProperty(
        name = "Icon color: 2", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.107, 0.555, 0.65, 1.0),
        description = "")
    color_icon_3: FloatVectorProperty(
        name = "Icon color: 3", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.141, 0.65, 0.458, 1.0),
        description = "")
    color_icon_4: FloatVectorProperty(
        name = "Icon color: 4", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.262, 0.527, 1.0),
        description = "")
    color_icon_5: FloatVectorProperty(
        name = "Icon color: 5", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.375, 0.472, 0.155, 1.0),
        description = "")
    color_icon_6: FloatVectorProperty(
        name = "Icon color: 6", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "")
    color_icon_7: FloatVectorProperty(
        name = "Icon color: 7", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.633, 0.243, 0.313, 1.0),
        description = "")
    color_icon_8: FloatVectorProperty(
        name = "Icon color: 8", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.56, 0.55, 0.44, 1.0),
        description = "")
    color_icon_ignore: FloatVectorProperty(
        name = "Icon color: Ignore", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.3, 0.3, 0.3, 0.3),
        description = "")
    color_icon_ignore2: FloatVectorProperty(
        name = "Icon color: Ignore2", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.23, 0.23, 0.23, 0.2),
        description = "")
    color_icon_light: FloatVectorProperty(
        name = "Icon color: Light", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.9, 0.9, 0.9, 1.0),
        description = "")
    color_icon_start: FloatVectorProperty(
        name = "Icon color: Start", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "Start icon color in Task bar")
    color_icon_start_fo: FloatVectorProperty(
        name = "Icon color: Start (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (1.0, 1.0, 1.0, 1.0),
        description = "Start icon color in Task bar when in focus")


    color_font: FloatVectorProperty(
        name = "Font color: Main", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "Common font color")
    color_font_red: FloatVectorProperty(
        name = "Font color: Warning", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.9, 0.193, 0.311, 1.0),
        description = "Warning font color")
    color_font_fo: FloatVectorProperty(
        name = "Font color: Main (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.8, 0.8, 0.8, 1.0),
        description = "Common font color when in focus")
    color_font_ti: FloatVectorProperty(
        name = "Font color: Title bar", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "Title font color in Title bar")
    color_font_sub_ti: FloatVectorProperty(
        name = "Font color: Sub-title", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.0, 0.48, 0.57, 1.0),
        description = "Sub-title font color")
    color_font_sub_ti_fo: FloatVectorProperty(
        name = "Font color: Sub-title (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.05, 0.61, 0.75, 1.0),
        description = "Sub-title font color when in focus")
    color_font_sub_ti_2: FloatVectorProperty(
        name = "Font color: Sub-title 2", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "Sub-title 2 font color")
    color_font_sub_ti_2_fo: FloatVectorProperty(
        name = "Font color: Sub-title 2 (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.8, 0.8, 0.8, 1.0),
        description = "Sub-title 2 font color when in focus")
    color_font_mod_num: FloatVectorProperty(
        name = "Font color: Modifier no.", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.242, 0.449, 0.427, 1.0),
        description = "Modifier no. font color in Modifier Editor")
    color_font_mod_num_fo: FloatVectorProperty(
        name = "Font color: Modifier no. (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.45, 0.65, 0.65, 1.0),
        description = "Modifier no. font color in Modifier Editor when in focus")
    color_font_mod_name: FloatVectorProperty(
        name = "Font color: Modifier name", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "Modifier element font color in Modifier Editor")
    color_font_darker: FloatVectorProperty(
        name = "Font color: Darker", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 0.5),
        description = "Darker font color")
    color_font_ignore: FloatVectorProperty(
        name = "Font color: Ignore", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 0.15),
        description = "Font color when disabled")


    color_bu_kf_fo: FloatVectorProperty(
        name = "Icon color: Keyframe (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (1.0, 1.0, 1.0, 1.0),
        description = "Keyframe button color when in focus")
    color_bu_kf_yellow: FloatVectorProperty(
        name = "Icon color: Match Keyframe", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.2, 1.0),
        description = "Keyframe button color that match current frame")
    color_bu_kf_yellow_fo: FloatVectorProperty(
        name = "Icon color: Match Keyframe (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.8, 0.8, 0.2, 1.0),
        description = "Keyframe button color that match current frame when in focus")
    color_bu_kf_green: FloatVectorProperty(
        name = "Icon color: No keyframe", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.3, 0.65, 0.3, 1.0),
        description = "Keyframe button color that no keyframe in current frame")
    color_bu_kf_green_fo: FloatVectorProperty(
        name = "Icon color: No keyframe (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.3, 0.8, 0.3, 1.0),
        description = "Keyframe button color that no keyframe in current frame when in focus")
    color_bu_kf_orange: FloatVectorProperty(
        name = "Icon color: Not match Keyframe", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.35, 0.2, 1.0),
        description = "Keyframe button color that keyframe is not match in current frame")
    color_bu_kf_orange_fo: FloatVectorProperty(
        name = "Icon color: Not match Keyframe (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.8, 0.4, 0.2, 1.0),
        description = "Keyframe button color that keyframe is not match in current frame when in focus")
    color_bu_dr: FloatVectorProperty(
        name = "Font color: Driver", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.85, 0.42, 0.66, 1.0),
        description = "Font color if it has a driver")
    color_bu_dr_fo: FloatVectorProperty(
        name = "Font color: Driver (Focus)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.8, 0.6, 0.7, 1.0),
        description = "Font color if it has a driver when in focus")
    color_mdicon_kf_off: FloatVectorProperty(
        name = "Icon color: Keyframe (Off)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.24, 0.24, 0.06, 1.0),
        description = "Off Icon color in Modifier element when it has keyframe")
    color_mdicon_dr_off: FloatVectorProperty(
        name = "Icon color: Driver (Off)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.321, 0.202, 0.259, 1.0),
        description = "Off Icon color in Modifier element when it has driver")
    color_font_rm: FloatVectorProperty(
        name = "Font color: Context Menu", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.65, 0.65, 0.65, 1.0),
        description = "Context Menu font color")
    color_font_rm_ignore: FloatVectorProperty(
        name = "Font color: Context Menu (Disable)", subtype = "COLOR", size = 4, min = 0.0, max = 1.0, step = -1.0,
        default = (0.35, 0.35, 0.35, 1.0),
        description = "Context Menu font color when disabled")