import bpy
from bgl import glEnable, GL_BLEND
from blf import size as blf_size
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP
from bpy.app.timers import register as thread_reg
from bpy.app.timers import unregister as thread_unreg
from bpy.app.timers import is_registered

from . import m, win, bu
from . fn import R_str_by_num3

P = None
F = None
K = None
N = None
BOX = None
BLF = None
font_0 = None
font_1 = None

TM = {}

class MESS(win.WIN):
    __slots__ = (
        'bg_fo',
        'hide_tb',
        'main_area',
        'oo',
        'default_modal',
        'tx_wi',
        'width',
        'height',
    )
    name = "Message Box"

    def __init__(self, x, y, tx,
            offset      = True,
            hide_tb     = True,
            width       = None,
            height      = None,
            bu_x_fn     = None,
        ):
        self.hide_tb    = hide_tb
        self.width      = width
        self.height     = height

        if offset:
            o = P.win_offset_top
            x += o[0]
            y += o[1]

        super().__init__((x, y, tx), region = False, bu_x_fn = bu_x_fn)
        if hide_tb:     m.admin.tb.disable()
        m.admin.tb.U_modal = m.NF
        self.da["tx"].set_size()
        self.tx_wi      = round(self.box["main"].R_w() - F[20])
    def fin(self):
        print(f"    win_mess  MESS  fin")
        m.M.restore_mou_ic()
        m.W_A.remove(self)
        m.W_D.remove(self)
        m.W_M.remove(self)
        m.FLASH_BOX.kill()
        self.U_kill_thread()

        self.fin_D1()

        m.EVT.kill()
        if self.hide_tb:    m.admin.tb.enable()
        m.admin.tb.U_modal = m.admin.tb.I_modal_outside
        m.redraw()
    def fin_D1(self):   pass
    def init_D1(self, evt):
        rd  = m.region_data

        self.bg_fo  = BOX(P.color_bg_fo, 0, rd.R - rd.border.R, 0, rd.T - rd.border.T)
        self.bg_fo.upd()
        self.bo     = {"bg": BOX(P.color_oj_info)}
        self.ti     = {}
        self.da     = {"tx": BLF(P.color_font, size = F[12])}

        x, y, self.da["tx"].text    = evt
        dx = F[150]  if self.width is None else self.width // 2
        dy = F[61]  if self.height is None else self.height // 2
        self.width  = dx * 2
        self.height = dy * 2

        self.box["rim"].LRBTd(x - dx, x + dx, y - dy, y + dy, F[1])
        x, y = m.IR_protect_pos(self.box["rim"], F[-1])
        self.box["rim"].LRBTd(x, x + self.width, y - self.height, y, F[1])

        self.default_modal  = self.I_modal_main
        self.U_init_thread  = self.I_init_thread
        self.U_kill_thread  = N
        self.tit["ti"].text = "Message"
        ma                  = m.EMPTY()
        self.main_area      = ma
        ma.U_modal          = self.I_modal_main_area
        ma.default_modal    = self.I_modal_main_area
        ma.sci              = self.sci
        ma.fin              = self.bu_x_fn
        self.oo = {"bu_ok": bu.BURE(ma, "bu_ok", "OK", self.bu_x_fn, -5.6)}

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd_main(self, x, y):
        super().dxy_upd_main(x, y)
        for e in self.oo.values():   e.dxy_upd(x, y)
# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo_main(self):
        bo      = self.bo
        da      = self.da

        bo["bg"].inset_with_depth(self.box["main"], F[2])
        cx      = bo["bg"].R_center_x()
        y       = bo["bg"].B + F[10]
        blf_size(font_0, F[12], 72)
        self.oo["bu_ok"].LRBT(cx - F[24], cx + F[24], y, y + F[20])

        da["tx"].LT(bo["bg"], F[12], F[19.1])

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_modal_main(self, evt):
        if K["cancel0"].true():   self.bu_x_fn()  ;return
        if K["cancel1"].true():   self.bu_x_fn()  ;return
        if K["confirm0"].true():  self.bu_x_fn()  ;return
        if K["confirm1"].true():  self.bu_x_fn()  ;return
        self.main_area.U_modal(evt)

    def I_modal_main_area(self, evt):
        if self.box["ti"].inbox(evt):
            if self.box["bu_x"].inbox(evt):
                self.U_modal = self.I_modal_x
                self.modal_x(evt)
                self.box["bu_x"].color = P.color_ti_bu_x
                m.redraw()  ;return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"] ;self.key_end.true()
                self.to_modal_mov(evt)      ;return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"] ;self.key_end.true()
                self.to_modal_mov(evt)      ;return
        elif self.box["main"].inbox(evt):
            for e in self.oo.values():
                if e.rim.inbox(evt):    e.inside(evt) ;return
        else:
            if evt.value == 'PRESS':
                if m.thread_isreg(m.flash_box_thread_fn):   return
                r = self.box["rim"]
                m.FLASH_BOX.init(r.L, r.R, r.B, r.T)

    def modal_mov_end(self):
        dx, dy = m.R_protect_dxy_LT(self.box["rim"], F[-1])
        if dx != 0 or dy != 0:  self.dxy_upd(dx, dy)
        del m.head_modal[-1]

        m.EVT.kill()
        m.EVT.U_ENABLE_evt()
        m.redraw()

    def evt_x(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.box["bu_x"].color = self.color.ti_bu
                self.tit["bu_x"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.EVT.kill()
                if self.box["bu_x"].inbox(evt):  self.bu_x_fn()
                return
        m.tm["fn"](evt)
    def evt_fit(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                if self.box["bu_fit"].inbox(evt):
                    self.fit_win(F[2])
                self.box["bu_fit"].color = self.color.ti_bu
                self.tit["bu_fit"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.init_wait_release()
                return
        m.tm["fn"](evt)
# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        glEnable(GL_BLEND)
        box = self.box

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()

        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        self.tit["bu_x"].set_draw_id(font_1)
        self.tit["ti"].set_draw()
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.tx_wi)
        self.da["tx"].set_draw()
        blf_disable(font_0, WORD_WRAP)

        blf_size(font_0, F[12], 72)
        for e in self.oo.values():   e.draw_ti()

        m.FLASH_BOX.U_draw()

class MESS_BOOL(MESS):
    __slots__ = ()
    name = "Confirm Box"

    def __init__(self, x, y, tx, fn_yes, fn_no,
            offset      = True,
            hide_tb     = True,
            width       = None,
            height      = None,
        ):
        super().__init__(x, y, tx, offset=offset, hide_tb=hide_tb, width=width, height=height)
        oo      = self.oo
        bu_ok   = oo["bu_ok"]

        def bu_fn_yes():
            self.fin()
            fn_yes()
        def bu_fn_no():
            self.fin()
            fn_no()

        self.bu_x_fn = bu_fn_no
        oo["bu_no"] = bu.BURE(self.main_area, "bu_no", "No", self.bu_x_fn, -5.6)

        blf_size(font_0, F[12], 72)
        rim             = bu_ok.rim
        bu_ok.ti.text   = "Yes"
        bu_ok.fn        = bu_fn_yes
        L   = rim.L - F[52]
        B   = rim.B
        T   = rim.T
        wi  = rim.R - rim.L
        bu_ok.LRBT(L, L + wi, B, T)

        L   += F[110]
        oo["bu_no"].LRBT(L, L + wi, B, T)

    def I_modal_main(self, evt):
        if K["cancel0"].true() or K["cancel1"].true():
            self.bu_x_fn()
            return
        if K["confirm0"].true() or K["confirm1"].true():
            self.oo["bu_ok"].fn()
            return
        self.main_area.U_modal(evt)


class PROGRESS(MESS):
    __slots__ = (
        'w',
        'U_thread',
        'da_tx',
        'gen',
        'job_amt',
        'end_fn',
        'abort_fn',
        'undo_fn',
        'job_done',
        'fin_D2',
    )
    name = "Progress"

    def __init__(self, x, y, w, amt, gen, end_fn, abort_fn, undo_fn, fin_D2,
            offset      = True,
            hide_tb     = True
        ):
        print(f"    win_mess  PROGRESS(MESS)  __init__")

        super().__init__(x, y, "", offset = offset, hide_tb = hide_tb)

        m.upd_disable()

        bo  = self.bo
        da  = self.da
        bg  = bo["bg"]

        self.tit["ti"].text = f"Progress"

        self.w          = w
        bu_ok           = self.oo["bu_ok"]
        bu_ok.ti.text   = "Abort "
        bu_ok.fn        = self.when_abort
        _d              = F[10]
        R               = bg.R - _d
        B               = bg.B + _d
        bu_ok.LRBT(R - F[61], R, B, B + F[20])

        da["tx"].text   = f"Completed :  {R_str_by_num3(0)} %    ( 0 / {amt} )"

        self.U_thread   = self.I_thread

        self.da_tx      = da["tx"]
        self.gen        = gen
        self.job_amt    = amt
        self.job_done   = False
        self.end_fn     = end_fn
        self.abort_fn   = abort_fn
        self.undo_fn    = undo_fn
        self.bu_x_fn    = self.when_abort
        self.fin_D2     = fin_D2

        m.admin.U_modal = m.admin.I_modal_progress
        m.M.set_mou_ic('DEFAULT')
        m.M.U_add_timer()

    def fin_D1(self):
        self.fin_D2()
        m.upd_enable()
        m.M.U_kill_timer()
        m.admin.U_modal = m.admin.I_modal
        m.M.set_mou_ic('DEFAULT')
        TM.clear()

    def I_modal_main(self, evt):
        if K["cancel0"].true() or K["cancel1"].true():
            m.EVT.kill()
            self.bu_x_fn()
            return

        if evt.type == 'TIMER': self.U_thread()
        else: self.main_area.U_modal(evt)

    def I_thread(self):
        try:
            i = next(self.gen)
            self.da_tx.text = f"Completed :  {R_str_by_num3(i * 100 // self.job_amt)} %    ( {i} / {self.job_amt} )"
        except StopIteration:
            self.end_fn()

    def when_job_done(self):
        self.job_done   = True
        self.U_thread   = N
        bu_ok           = self.oo["bu_ok"]

        bu_ok.ti.text   = "Undo"
        bu_ok.ti.x      += F[1]
        bu_ok.offset_x  = bu_ok.ti.x - bu_ok.bg.L
        bu_ok.fn        = self.undo_fn
        bu_ok.off()
        self.bu_x_fn    = self.fin
    def when_abort(self):
        def fn_yes():
            self.abort_fn()
            self.job_done   = True
            self.U_thread   = N
            self.da_tx.text = "Cancelled"
            self.oo["bu_ok"].disable()
            self.bu_x_fn    = self.fin
            m.undo()
            m.M.set_mou_ic('DEFAULT')

        box = self.box["main"]
        MESS_BOOL(
            box.R_center_x(),
            box.R_center_y(),
            "It will undo the operation.",
            fn_yes,
            N,
            hide_tb = False
        )
    def when_undo(self):
        self.oo["bu_ok"].disable()
        m.undo()


class MENU(MESS):
    __slots__ = (
        'line',
        'bu_hi',
        'bu_border',
        'bu_tx_si',
        'bu_dist',
    )
    name = "Menu"

    def __init__(self, x, y, lis_bu, bu_x_fn,
            title       = "Menu",
            offset      = True,
            hide_tb     = True,
            width       = None,
            bu_hi       = None,
            bu_border   = None,
            bu_tx_si    = None,
            bu_dist     = None,
        ):
        TM["title"]     = title
        TM["lis_bu"]    = lis_bu
        TM["bu_x_fn"]   = bu_x_fn
        TM["job"]       = False
        self.bu_hi      = F[20]     if bu_hi is None else bu_hi
        self.bu_border  = F[8]      if bu_border is None else bu_border
        self.bu_tx_si   = F[10]     if bu_tx_si is None else bu_tx_si
        self.bu_dist    = F[6]      if bu_dist is None else bu_dist

        super().__init__(x, y, "",
            offset      = offset,
            hide_tb     = hide_tb,
            width       = width,
            height      = len(lis_bu) * (self.bu_hi + self.bu_dist) + (
                self.bu_border + F[2] + F[1]) * 2 + F[-1] - self.bu_dist
        )
    def init_D1(self, evt):
        super().init_D1(evt)

        end_fn = TM["bu_x_fn"]

        def bu_x_fn():
            self.fin()
            end_fn()

        self.bu_x_fn    = bu_x_fn

        ma      = self.main_area

        BURE        = bu.BURE
        oo          = self.oo
        oo.clear()
        line        = []
        self.line   = line
        R_bu_fn     = self.R_bu_fn

        self.tit["ti"].text = TM["title"]
        for e in TM["lis_bu"]:
            name = e[0]
            o = BURE(ma, name, e[1], R_bu_fn(end_fn, name), -5.6, is_fin = True)
            oo[name] = o
            line.append(o)

    def get_bo_main(self):
        bg      = self.bo["bg"]
        d       = self.bu_border
        h       = self.bu_hi
        dist    = self.bu_dist

        bg.inset_with_depth(self.box["main"], F[2])
        L   = bg.L + d
        R   = bg.R - d
        T   = bg.T - d
        B   = T - h

        blf_size(font_0, self.bu_tx_si, 72)
        for o in self.line:
            o.LRBT(L, R, B, T)
            T = B - dist
            B = T - h

    def R_bu_fn(self, func, name):
        def bu_fn():
            TM["job"] = name
            func()
        return bu_fn

    def I_draw(self):
        glEnable(GL_BLEND)
        box = self.box

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()

        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        self.tit["bu_x"].set_draw_id(font_1)
        self.tit["ti"].set_draw()

        blf_size(font_0, self.bu_tx_si, 72)
        for e in self.oo.values():   e.draw_ti()

        m.FLASH_BOX.U_draw()


class MENU_MOD_LINK(MESS):
    __slots__ = (
        'line',
        'bu_hi',
        'bu_border',
        'bu_tx_si',
        'bu_dist',
    )
    name = "Menu Mod Link"

    def __init__(self, x, y, lis_bu, bu_x_fn):
        TM["lis_bu"]    = lis_bu
        TM["bu_x_fn"]   = bu_x_fn
        TM["job"]       = False
        self.bu_hi      = F[20]
        self.bu_border  = F[8]
        self.bu_tx_si   = F[10]
        self.bu_dist    = F[6]

        super().__init__(x, y, "",
            offset      = True,
            hide_tb     = True,
            width       = P.scale[0] * 250,
            height      = 6 * (self.bu_hi + self.bu_dist) + (
                self.bu_border + F[2] + F[1]) * 2 + F[-1] - self.bu_dist
        )
    def init_D1(self, evt):
        super().init_D1(evt)

        end_fn = TM["bu_x_fn"]

        def bu_x_fn():
            self.fin()
            end_fn()

        self.bu_x_fn    = bu_x_fn

        ma      = self.main_area

        BURE        = bu.BURE
        BU_BOOL     = bu.BU_BOOL
        oo          = self.oo
        oo.clear()
        line        = []
        self.line   = line
        R_bu_fn     = self.R_bu_fn

        self.tit["ti"].text = "Menu"
        for e in TM["lis_bu"]:
            name = e[0]
            o = BURE(ma, name, e[1], R_bu_fn(end_fn, name), -5.6, is_fin = True)
            oo[name] = o
            line.append(o)

        o = BU_BOOL(ma, "bu_kf", "Keep Keyframe")
        o.set_da(True)
        oo["bu_kf"] = o

        o = BU_BOOL(ma, "bu_dr", "Keep Driver")
        o.set_da(True)
        oo["bu_dr"] = o

    def get_bo_main(self):
        bg      = self.bo["bg"]
        d       = self.bu_border
        h       = self.bu_hi
        dist    = self.bu_dist

        bg.inset_with_depth(self.box["main"], F[2])
        L   = bg.L + d
        R   = bg.R - d
        T   = bg.T - d
        B   = T - h

        blf_size(font_0, self.bu_tx_si, 72)
        for o in self.line:
            o.LRBT(L, R, B, T)
            T = B - dist
            B = T - h
        
        o = self.oo["bu_kf"]
        o.ti.set_size()
        R = self.line[0].rim.R
        B -= F[2]
        o.RB(R, B)

        B -= h
        o = self.oo["bu_dr"]
        o.RB(R, B)

    def R_bu_fn(self, func, name):
        def bu_fn():
            TM["job"] = name
            func()
        return bu_fn

    def I_draw(self):
        glEnable(GL_BLEND)
        box = self.box
        oo = self.oo

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()

        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in oo.values():   e.draw_rim()
        for e in oo.values():   e.draw_bg()

        self.tit["bu_x"].set_draw_id(font_1)
        self.tit["ti"].set_draw()

        blf_size(font_0, self.bu_tx_si, 72)
        oo["bu_move"].draw_ti()
        oo["bu_copy"].draw_ti()
        oo["bu_link"].draw_ti()
        oo["bu_dlink"].draw_ti()
        oo["bu_kf"].draw_ti()
        oo["bu_dr"].draw_ti()

        m.FLASH_BOX.U_draw()