import bpy
# from bgl import glEnable, GL_BLEND
from blf import size as blf_size
# from blf import color as blf_color
from mathutils import Vector

from .. import m
from .. m import NAME, bind_color_bu_1_rim
from .. ED_md.oj_data import OJ
from .. bu import BU, BUTI, BUDA, BUDA_RENAME, BUDA_PAN, TI_TYPE, BURE
from .. ED_md.bu_md import BUBL
from .. dd import DDTX_FN, DDTX_RENAME
from .. filt import FIL

P = None
F = None
N = None
font_0 = None


class DR_TYPES:
    __slots__ = ()
    enum_items = bpy.types.Driver.bl_rna.properties["type"].enum_items
    dic_name_val = {e.name : e.identifier for e in enum_items}
    dic_val_name = {e.identifier : e.name for e in enum_items}

class DR(OJ):
    __slots__ = (
        'oo_22',
        'oo_sci',
    )
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        sci                 = w.sci
        self.sci            = sci
        f9                  = F[9]

        oo = {
            "ti_oj":        BUTI(self, "ti_oj", "OBJECT", self.bu_fn_ti_oj),
            "ti_dr":        BUTI(self, "ti_dr", "DRIVER", self.bu_fn_ti_dr),
            "ti_dr_type":   BUTI(self, "ti_dr_type", "Driver Type", N),
            "ti_dr_val":    BUTI(self, "ti_dr_val", "Path Value", N),
            "ti_dr_exp":    BUTI(self, "ti_dr_exp", "Expression", N),
            "ti_dr_self":   BUTI(self, "ti_dr_self", "Use self", N),
            "ti_type":      TI_TYPE(self, "ti_type", "OBJ TYPE    "),
            "ti_sync":      TI_TYPE(self, "ti_sync", "Sync Active"),
            "da_oj":        BUDA_RENAME(self, "da_oj", self.bu_fn_da_oj),
            "da_dr":        BUDA_PAN(self, "da_dr", self.bu_fn_da_dr, f9, w_sci=sci),
            "bu_sync_oj":   BU(self, "bu_sync_oj", "Object", self.bu_fn_sync_oj),
            "da_dr_type":   BUDA_PAN(self, "da_dr_type", self.bu_fn_da_dr_type, f9),
            "da_dr_val":    BUDA_PAN(self, "da_dr_val", self.bu_fn_da_dr_val, f9),
            "da_dr_exp":    BUDA_PAN(self, "da_dr_exp", self.bu_fn_da_dr_exp, f9, w_sci=sci),
            "da_dr_self":   BUBL(self, "bl_self", "use_self", fn=self.bu_fn_da_dr_self, offset_x_key=2),
            "bu_del_dr":    BURE(self, "bu_del_dr", "Delete Driver", self.bu_fn_del_dr),
            "bu_upd":       BURE(self, "bu_upd", "Update Dependencies", self.bu_fn_upd),
        }
        self.oo = oo
        oo["da_oj"].enable_half_size_method()

        self.oo_sci = {oo[k] for k in {
            "da_dr",
            "da_dr_type",
            "da_dr_val",
            "da_dr_exp",
        }}
        self.oo_free = {oo[k] for k in {
            "da_oj",
        }}
        self.oo_22 = {oo[k] for k in {
            "da_dr_self",
        }}
        self.oo_12 = {oo[k] for k in {
            "ti_oj",
            "ti_dr",
        }}
        self.oo_9 = {oo[k] for k in {
            "ti_type",
            "ti_sync",
            "bu_sync_oj",
            "ti_dr_type",
            "ti_dr_val",
            "ti_dr_exp",
            "ti_dr_self",
            "bu_del_dr",
            "bu_upd",
        }}

        oo["ti_dr"].off()
        oo["ti_dr_val"].off()
        oo["ti_dr_type"].off()
        oo["ti_dr_exp"].off()
        oo["ti_dr_self"].off()

    def get_bo(self):
        oo  = self.oo
        w   = self.w
        bo  = w.bo
        x   = bo["dr_info"].L
        y   = bo["dr_info"].T
        u   = P.scale[0]
        f15 = F[15]
        dR  = F[8]

        blf_size(font_0, F[12], 72)
        L   = x + F[7]
        B   = y - F[19.1]
        oo["ti_oj"].LBT(L, B, B + f15, 3.8)
        B0  = oo["ti_oj"].rim.B - F[18.1]
        oo["ti_dr"].LBT(L, B0, B0 + f15, 3.8)
        rim = oo["ti_oj"].rim
        L0  = rim.L + F[82]
        R   = bo["dr_info"].R - F[7]
        oo["da_oj"].LRBT(L0, R, rim.B, rim.T, 3.8)
        oo["da_oj"].upd_half_size(R)
        rim = oo["ti_dr"].rim
        oo["da_dr"].LRBT(L0 - F[1], R, rim.B, rim.T)

        blf_size(font_0, F[9], 72)
        da_dr_rim   = oo["da_dr"].rim
        L           = da_dr_rim.L
        R           = da_dr_rim.R
        wi          = round(140 * u)
        dy  = F[22]
        B   = y - round(87 * u)
        T   = B + f15
        oo["da_dr_type"].LRBT(L, L + wi, B, T)
        oo["ti_dr_type"].align_R_by_bu(oo["da_dr_type"], dR)
        oo["da_dr_val"].LRBT(R - wi, R, B, T)
        oo["ti_dr_val"].align_R_by_bu(oo["da_dr_val"], dR)
        B   -= dy
        T   -= dy
        oo["da_dr_exp"].LRBT(L, R, B, T)
        oo["ti_dr_exp"].align_R_by_bu(oo["da_dr_exp"], dR)
        B   -= dy
        T   -= dy
        oo["da_dr_self"].LRBT(L, L + F[16], B, T)
        oo["ti_dr_self"].align_R_by_rim(oo["da_dr_self"].rim, dR)
        L = R - round(76 * u)
        oo["bu_del_dr"].LRBT(L, R, B, T)
        R = L - F[8]
        oo["bu_upd"].LRBT(R - round(110 * u), R, B, T)

        oo["ti_type"].xy(rim.L + F[1], B0 - f15)
        B   = oo["ti_type"].ti.y - F[4.9]
        R   = bo["dr_info"].R - round(189 * u)
        oo["bu_sync_oj"].LRBT(R - F[46], R, B, B + F[16])
        oo["ti_sync"].before_bu(oo["bu_sync_oj"])

        if w.I_upd_data == w.I_upd_data_follow:   oo["bu_sync_oj"].on()

    def glopan_end(self):
        self.oo["da_dr"].upd_tx_pos()
        self.oo["da_dr_exp"].upd_tx_pos()

    def I_modal_main(self, evt):
        self.RET = False
        oo  = self.oo
        x   = evt.mouse_region_x
        y   = evt.mouse_region_y

        if y > oo["ti_oj"].rim.T:       return self.RET
        if y >= oo["ti_oj"].rim.B:
            if oo["ti_oj"].rim.in_LR_x(x):      oo["ti_oj"].inside(evt)
            elif oo["da_oj"].rim.in_LR_x(x):    oo["da_oj"].inside(evt)
            return self.RET

        if y > oo["ti_dr"].rim.T:       return self.RET
        if y >= oo["ti_dr"].rim.B:
            if oo["ti_dr"].rim.in_LR_x(x):      oo["ti_dr"].inside(evt)
            elif oo["da_dr"].rim.in_LR_x(x):    oo["da_dr"].inside(evt)
            return self.RET

        if y > oo["bu_sync_oj"].rim.T:  return self.RET
        if y >= oo["bu_sync_oj"].rim.B:
            if oo["bu_sync_oj"].rim.in_LR_x(x):     oo["bu_sync_oj"].inside(evt)
            return self.RET

        if y > oo["da_dr_type"].rim.T:  return self.RET
        if y > oo["da_dr_type"].rim.B:
            if oo["da_dr_type"].rim.in_LR_x(x):     oo["da_dr_type"].inside(evt)
            elif oo["da_dr_val"].rim.in_LR_x(x):    oo["da_dr_val"].inside(evt)
            return self.RET

        if y > oo["da_dr_exp"].rim.T:   return self.RET
        if y >= oo["da_dr_exp"].rim.B:
            if oo["da_dr_exp"].rim.in_LR_x(x):      oo["da_dr_exp"].inside(evt)
            return self.RET

        if y > oo["da_dr_self"].rim.T:  return self.RET
        if y >= oo["da_dr_self"].rim.B:
            if oo["da_dr_self"].rim.in_LR_x(x):     oo["da_dr_self"].inside(evt)
            elif oo["bu_del_dr"].rim.in_LR_x(x):    oo["bu_del_dr"].inside(evt)
            elif oo["bu_upd"].rim.in_LR_x(x):       oo["bu_upd"].inside(evt)
            return self.RET
        return self.RET

    def bu_fn_ti_dr(self):
        print(f"    dr_data  bu_fn_ti_dr")
        w = self.w
        w.I_upd_data()
        r = self.oo["da_dr"].rim
        L = round(r.L)
        R = L + round(P.dd_width * P.scale[0])
        T = round(r.T)

        def confirm_fn(tx):
            print(f"    dr_data  bu_fn_ti_dr  confirm_fn")
            self.oo["da_dr"].da.text = tx
            self.w.I_upd_data()

        DDTX_FN(
            m.EVT.evt,
            self.oo["da_dr"].da.text,
            FIL([NAME(f'{e.data_path}, index={e.array_index}') for e in w.drs]  if w.drs else ()),
            (L, R, T - F[16], T),
            confirm_fn,
            tx_clear = True
        )
    def bu_fn_da_dr(self):
        print(f"    dr_data  bu_fn_da_dr")
        w   = self.w
        w.I_upd_data()
        dr  = w.act_dr
        if dr is None:  return

        DDTX_RENAME(
            m.EVT.evt,
            self.oo["da_dr"].da.text,
            (dr, "data_path"),
            FIL([NAME(f'{e.data_path}, index={e.array_index}') for e in w.drs]  if w.drs else ()),
            target          = f"animation_data.drivers.find('{dr.data_path}', index={dr.array_index}).data_path",
            full_path_head  = f'bpy.data.objects["{w.oj.name}"].',
            read_only       = True,
            tx_clear        = False
        )
    def bu_fn_da_dr_type(self):
        print(f"    dr_data  bu_fn_da_dr_type")
        w = self.w
        w.I_upd_data()
        r = self.oo["da_dr_type"].rim
        L = round(r.L)
        R = round(r.R)
        T = round(r.T)

        def confirm_fn(tx):
            try:
                print(f"    dr_data  bu_fn_da_dr_type  confirm_fn")
                val = DR_TYPES.dic_name_val[tx]
                w.act_dr.driver.type = val
                m.undo_str = f'Driver.type = "{val}"'
                m.undo_push()
            except:
                pass

        DDTX_FN(
            m.EVT.evt,
            self.oo["da_dr_type"].da.text,
            FIL(DR_TYPES.enum_items),
            (L, R, T - F[16], T),
            confirm_fn,
            tx_clear = True
        )
    def bu_fn_da_dr_val(self):
        print(f"    dr_data  bu_fn_da_dr_val")
        w   = self.w
        w.I_upd_data()
        dr  = w.act_dr
        if dr is None:  return

        tx = self.oo["da_dr_val"].da.text
        try:
            prop    = f'{w.oj.path_resolve(dr.data_path, False)}'
            ind     = prop.rfind(".")
            attr0   = prop[prop.find(" ") + 1 : ind]
            attr1   = prop[ind + 1 : -1]
            enum_items = getattr(bpy.types, attr0).bl_rna.properties[attr1].enum_items
            lis = [NAME(e.identifier) for e in enum_items]
        except:
            lis = [NAME(tx)]

        DDTX_RENAME(
            m.EVT.evt,
            tx,
            (dr, ""),
            FIL(lis),
            target          = f"",
            full_path_head  = f'',
            read_only       = True,
            tx_clear        = False
        )
    def bu_fn_da_dr_exp(self):
        print(f"    dr_data  bu_fn_da_dr_exp")
        w = self.w
        w.I_upd_data()
        dr  = w.act_dr
        if dr is None:  return
        o = self.oo["da_dr_exp"]
        r = o.rim
        L = round(r.L)
        R = round(r.R)
        T = round(r.T)

        def confirm_fn(tx):
            print(f"    dr_data  bu_fn_da_dr_exp  confirm_fn")
            w.act_dr.driver.expression = tx
            m.undo_str = f'Driver.expression = "{tx}"'

        DDTX_FN(
            m.EVT.evt,
            o.da.text,
            None,
            (L, R, T - F[16], T),
            confirm_fn,
        )
    def bu_fn_da_dr_self(self):
        print(f"    dr_data  bu_fn_da_dr_self")
        dr = self.w.act_dr
        if dr is None:  return

        if dr.driver.use_self:
            dr.driver.use_self = False
            m.undo_str = 'Driver.use_self = False'
        else:
            dr.driver.use_self = True
            m.undo_str = 'Driver.use_self = True'
        m.refresh()
        m.redraw()
        m.undo_push()
    def bu_fn_del_dr(self):
        print(f"    dr_data  bu_fn_del_dr")
        w   = self.w
        w.I_upd_data()
        dr  = w.act_dr
        if dr is None:  return
        if not w.drs:   return

        oj_attr = dr.data_path[2:-2]
        if dr in bpy.data.link_mds:
            del bpy.data.link_mds[dr]

        if oj_attr in w.oj:
            del w.oj[oj_attr]

        w.drs.remove(dr)
        P.refresh = True
        m.refresh()
        m.undo_str = "[Driver Editor] Driver Delete"
        m.undo_push()
    def bu_fn_upd(self):
        print(f"    dr_data  bu_fn_upd")
        w   = self.w
        w.I_upd_data()
        dr  = w.act_dr
        if dr is None:  return

        dr.driver.expression = dr.driver.expression
        m.upd_link_data()

    def I_draw(self):
        bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        blf_size(font_0, F[21], 72)
        for e in self.oo_22:    e.draw_ti()
        blf_size(font_0, F[12], 72)
        for e in self.oo_12:    e.draw_ti()
        blf_size(font_0, F[9], 72)
        for e in self.oo_9:     e.draw_ti()
        for e in self.oo_free:  e.draw_ti()
        for e in self.oo_sci:   e.draw_ti()

    def upd_data(self):
        w       = self.w
        oo      = self.oo
        oj      = w.oj
        act_dr  = w.act_dr
        R       = w.bo["dr_info"].R - F[7]
        oo["da_oj"].upd_da_half_size(oj.name  if oj != None else "", R)
        oo["ti_type"].upd_val(oj.type  if oj != None else "")
        if act_dr is None:
            oo["da_dr"].da.text = ""
            oo["da_dr_type"].da.text = ""
            oo["da_dr_val"].da.text = ""
            oo["da_dr_exp"].da.text = ""
            oo["da_dr_self"].set_da(False)
            oo["ti_dr_exp"].off()
            oo["ti_dr_self"].off()
        else:
            driver = act_dr.driver
            # driver.expression = driver.expression
            oo["da_dr"].da.text = f'{act_dr.data_path}, index={act_dr.array_index}'
            oo["da_dr_type"].da.text = DR_TYPES.dic_val_name[driver.type]
            try:
                vals = oj.path_resolve(act_dr.data_path)
            except:
                vals = None
            if isinstance(vals, Vector):
                oo["da_dr_val"].da.text = f'{vals[act_dr.array_index]}'
            else:
                oo["da_dr_val"].da.text = f'{vals}'
            oo["da_dr_exp"].da.text = driver.expression
            oo["da_dr_self"].set_da(driver.use_self)
            if driver.type == "SCRIPTED":
                if oo["da_dr_exp"].state != 0:
                    oo["da_dr_exp"].enable()
                    oo["da_dr_self"].enable()
                    oo["ti_dr_exp"].off()
                    oo["ti_dr_self"].off()
                if driver.is_valid:
                    oo["da_dr_exp"].da.color = P.color_font
                else:
                    oo["da_dr_exp"].da.color = P.color_font_red
            else:
                if oo["da_dr_exp"].state != 1:
                    oo["da_dr_exp"].disable()
                    oo["da_dr_self"].disable()
                    oo["ti_dr_exp"].ti.color = P.color_font_ignore
                    oo["ti_dr_self"].ti.color = P.color_font_ignore
                oo["da_dr_exp"].da.color = P.color_font

        self.glopan_end()
