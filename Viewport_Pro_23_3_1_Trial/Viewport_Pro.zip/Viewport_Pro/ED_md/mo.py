import bpy
from bgl import glEnable, GL_BLEND
from blf import size as blf_size
from blf import color as blf_color

from . import cl_md

from . mods import MODS
from . oj_data import OJ
from .. import m, win
from .. m import bind_color_bu_4_rim, NAME
from .. bu import BU4
from .. dd import DDTX_FN
from .. filt import FIL
from .. link_data import is_dead
# from .. rm import RM

P = None
F = None
K = None
BOX = None
BLF = None
font_0 = None

all_modifiers = (
    NAME('Armature'),
    NAME('Array'),
    NAME('Bevel'),
    NAME('Boolean'),
    NAME('Build'),
    NAME('Cast'),
    NAME('Cloth'),
    NAME('Collision'),
    NAME('Curve'),
    NAME('Data Transfer'),
    NAME('Decimate'),
    NAME('Displace'),
    NAME('Dynamic Paint'),
    NAME('Edge Split'),
    NAME('Explode'),
    NAME('Fluid'),
    NAME('Hook'),
    NAME('Laplacian Deform'),
    NAME('Lattice'),
    NAME('Mask'),
    NAME('Mesh Cache'),
    NAME('Mesh Deform'),
    NAME('Mesh Sequence Cache'),
    NAME('Mesh to Volume'),
    NAME('Mirror'),
    NAME('Multires'),
    NAME('Nodes'),
    NAME('Normal Edit'),
    NAME('Ocean'),
    NAME('Particle Instance'),
    NAME('Particle System'),
    NAME('Remesh'),
    NAME('Screw'),
    NAME('Shrinkwrap'),
    NAME('Simple Deform'),
    NAME('Skin'),
    NAME('Smooth'),
    NAME('Smooth Corrective'),
    NAME('Smooth Laplacian'),
    NAME('Soft Body'),
    NAME('Solidify'),
    NAME('Subsurf'),
    NAME('Surface'),
    NAME('Surface Deform'),
    NAME('Triangulate'),
    NAME('UV Project'),
    NAME('UV Warp'),
    NAME('Vertex Weight Edit'),
    NAME('Vertex Weight Mix'),
    NAME('Vertex Weight Proximity'),
    NAME('Volume Displace'),
    NAME('Volume to Mesh'),
    NAME('Warp'),
    NAME('Wave'),
    NAME('Weighted Normal'),
    NAME('Weld'),
    NAME('Wireframe'),
)
dic_md_name_type = {
    'Armature': 'ARMATURE',
    'Array': 'ARRAY',
    'Bevel': 'BEVEL',
    'Boolean': 'BOOLEAN',
    'Build': 'BUILD',
    'Cast': 'CAST',
    'Cloth': 'CLOTH',
    'Collision': 'COLLISION',
    'Curve': 'CURVE',
    'Data Transfer': 'DATA_TRANSFER',
    'Decimate': 'DECIMATE',
    'Displace': 'DISPLACE',
    'Dynamic Paint': 'DYNAMIC_PAINT',
    'Edge Split': 'EDGE_SPLIT',
    'Explode': 'EXPLODE',
    'Fluid': 'FLUID',
    'Hook': 'HOOK',
    'Laplacian Deform': 'LAPLACIANDEFORM',
    'Lattice': 'LATTICE',
    'Mask': 'MASK',
    'Mesh Cache': 'MESH_CACHE',
    'Mesh Deform': 'MESH_DEFORM',
    'Mesh Sequence Cache': 'MESH_SEQUENCE_CACHE',
    'Mesh to Volume': 'MESH_TO_VOLUME',
    'Mirror': 'MIRROR',
    'Multires': 'MULTIRES',
    'Nodes': 'NODES',
    'Normal Edit': 'NORMAL_EDIT',
    'Ocean': 'OCEAN',
    'Particle Instance': 'PARTICLE_INSTANCE',
    'Particle System': 'PARTICLE_SYSTEM',
    'Remesh': 'REMESH',
    'Screw': 'SCREW',
    'Shrinkwrap': 'SHRINKWRAP',
    'Simple Deform': 'SIMPLE_DEFORM',
    'Skin': 'SKIN',
    'Smooth': 'SMOOTH',
    'Smooth Corrective': 'CORRECTIVE_SMOOTH',
    'Smooth Laplacian': 'LAPLACIANSMOOTH',
    'Soft Body': 'SOFT_BODY',
    'Solidify': 'SOLIDIFY',
    'Subsurf': 'SUBSURF',
    'Surface': 'SURFACE',
    'Surface Deform': 'SURFACE_DEFORM',
    'Triangulate': 'TRIANGULATE',
    'UV Project': 'UV_PROJECT',
    'UV Warp': 'UV_WARP',
    'Vertex Weight Edit': 'VERTEX_WEIGHT_EDIT',
    'Vertex Weight Mix': 'VERTEX_WEIGHT_MIX',
    'Vertex Weight Proximity': 'VERTEX_WEIGHT_PROXIMITY',    
    'Volume Displace': 'VOLUME_DISPLACE',
    'Volume to Mesh': 'VOLUME_TO_MESH',
    'Warp': 'WARP',
    'Wave': 'WAVE',
    'Weighted Normal': 'WEIGHTED_NORMAL',
    'Weld': 'WELD',
    'Wireframe': 'WIREFRAME',
}


class OP_MO(bpy.types.Operator):
    __slots__ = ()
    bl_idname = "wm.md_editor_operator"
    bl_label = "Modifier Editor"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        # bpy.ops.xx.operator("INVOKE_DEFAULT")
        # return {'FINISHED'}
        print("    mo  bpyOperator  OP_MO  inovke")
        if m.op_poll(context):  return {'CANCELLED'}

        MO()

        W_A = m.W_A
        if len(W_A) == 1:
            # print("debug")
            # w = W_A[0]
            # A_md = w.A_md
            # bu_kf = A_md.oo["kf_affect"]
            # bu_kf.batch_init(event)
            pass

        return {'FINISHED'}


class MO(win.WIN):
    __slots__ = (
        'oo',
        'A_obj',
        'A_md',
        'A_mods',
        'oj',
        'act_md',
        'I_upd_data',
        'U_upd_act_ob',
        'is_mods_area',
        'is_link_area',
    )
    name = "Modifier Editor"
    W = []
    IND = []

    def init_D1(self):
        c           = self.color
        c.font      = P.color_font
        c.oj_info   = P.color_oj_info

        self.bo = {
            "oj_info":      BOX(c.oj_info),
            "md_info":      BOX(P.color_mded_data_rim),
        }
        self.ti = {
            "amt":          BLF(text = "AMT"),
        }
        self.da = {
            "amt":          BLF(size = 0, text = "  0"),
        }
        self.oo = {
            "new_md":       BU4(self, "new_md", "Add"),
        }

        obj             = OJ(self)
        self.A_obj      = obj
        self.act_md     = None

        blf_title = self.tit["ti"]
        ind = blf_title.name
        if ind == 1:
            blf_title.text  = "Modifier Editor"
            self.oj = bpy.context.object  if bpy.context.object else None

            if P.sync_act_oj:
                self.I_upd_data     = self.I_upd_data_follow
                obj.oo["ti_oj"].on()
            else:
                self.I_upd_data     = self.I_upd_data_lock
                obj.oo["ti_oj"].off()

            if self.oj is not None and self.oj.library:
                self.U_upd_act_ob   = self.I_upd_act_md_unsync
                obj.oo["ti_md"].off()
            else:
                if P.sync_act_md:
                    self.U_upd_act_ob   = self.I_upd_act_md_sync
                    obj.oo["ti_md"].on()
                else:
                    self.U_upd_act_ob   = self.I_upd_act_md_unsync
                    obj.oo["ti_md"].off()
        else:
            blf_title.text      = f"Modifier Editor {ind}"
            self.I_upd_data     = self.I_upd_data_lock
            self.U_upd_act_ob   = self.I_upd_act_md_unsync
            obj.oo["ti_oj"].off()
            obj.oo["ti_md"].off()

            oj      = None
            sel_oj  = bpy.context.selected_objects
            if bpy.context.object:
                for e in reversed(sel_oj):
                    if e != bpy.context.object:     oj = e  ;break
                self.oj = oj  if oj != None  else bpy.context.object
            else:
                self.oj = sel_oj[-1]  if sel_oj else None

        if self.oj is not None:
            obj.oo["da_oj"].da.text = self.oj.name
            ll_mds = len(self.oj.modifiers)

            if self.oj.modifiers:
                self.da["amt"].size = ll_mds
                self.da["amt"].text = f"1 / {ll_mds}"
                self.U_upd_act_ob()
            else:
                self.da["amt"].size = 0
                self.da["amt"].text = "0 / 0"

        self.cv.R_w     = self.bo["oj_info"].R_w
        self.cv.R_h     = self.cv_R_h
        self.upd_data   = self.I_upd_data
        self.A_md       = cl_md.NONE(self)

# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo_main(self):
        inn = P.win_border_inner
        bo  = self.bo
        ti  = self.ti
        da  = self.da

        x = self.box["main"].L + P.win_border - self.cv.x
        y = self.box["main"].T - P.win_border + self.cv.y

        depth = inn - 3
        oj_info = bo["oj_info"]
        md_info = bo["md_info"]
        oj_info.depth_L(x, F[480] + depth)
        oj_info.T = y

        md_info.depth_L(x, F[300])
        self.A_obj.get_bo()
        md_info.depth_T(oj_info.B - inn, F[21] + F[-998])

        ti["amt"].x = md_info.R + F[7] + depth
        ti["amt"].y = md_info.T - F[13]
        da["amt"].x = ti["amt"].x + F[31]
        da["amt"].y = ti["amt"].y

        self.A_mods = MODS(
            self,
            md_info.R + inn,
            oj_info.R,
            md_info.T - F[21], F[-998]
        )
        self.is_mods_area = self.A_mods.is_inside
        self.is_link_area = self.A_mods.is_link_area
        self.A_md.__init__(self)

        R = oj_info.R - F[1]
        T = md_info.T - F[3]
        blf_size(font_0, F[9], 72)
        self.oo["new_md"].LRBT(R - F[34], R, T - F[15], T)

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd_main(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        self.oo["new_md"].dxy_upd(x, y)

        self.A_mods.dxy_upd(x, y)
        self.A_md.dxy_upd(x, y)
        self.A_md.upd_sci()
        self.A_obj.dxy_upd(x, y)

    def glopan_upd(self):
        self.A_mods.upd_sci()

    def cv_R_h(self):
        return self.bo["oj_info"].R_h() + P.win_border_inner + self.bo["md_info"].R_h()

    def R_A_ll(self):       return self.A_mods
    def R_bo_info_B(self):  return self.bo["oj_info"].B

    def I_upd_act_md_sync(self):
        self.act_md = self.oj.modifiers.active
        if self.act_md is None:
            self.A_obj.do_unsync_md()
            self.I_upd_act_md_unsync()
    def I_upd_act_md_unsync(self):
        try:    self.act_md = self.oj.modifiers[self.act_md.name]
        except:
            if is_dead(self.oj): return
            if self.oj.modifiers:
                self.act_md = self.oj.modifiers[0]

    def I_modal_glopan_end_D1(self):
        print(f"    mo  I_modal_glopan_end_D1")
        self.A_mods.glopan_end_fn()
    def modal_mov_end_D1(self):
        self.A_mods.glopan_end_fn()

    def bu_fn_new_md(self, evt):
        print(f"    mo  bu_fn_new_md")
        if self.oj is None: return
        if self.oj.type != 'MESH':  return

        def confirm_fn(tx):
            try:
                print(f"    mo  bu_fn_new_md  confirm_fn")
                self.oj.modifiers.new(tx, dic_md_name_type[tx])
                m.undo_str = f'[Modifier Editor] modifier add: {tx}'
                m.undo_push()
            except:
                print("    mo  bu_fn_new_md  except")
        def fin_fn():
            self.oo["new_md"].off()

        L = self.bo["md_info"].R + F[3]
        R = self.bo["oj_info"].R
        T = self.bo["md_info"].T
        DDTX_FN(evt, "", FIL(all_modifiers),
            LRBT        = (L, R, T - F[16], T),
            confirm_fn  = confirm_fn,
            fin_D1      = fin_fn)
# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def modal_main_area(self, evt):
        if self.oo["new_md"].rim.inbox(evt):
            self.oo["new_md"].fo()
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.oo["new_md"].on()
                self.bu_fn_new_md(evt)
                m.init_wait_release()
                return True
        else:
            self.oo["new_md"].off()

        if K["me_all0"].true():   self.A_mods.modal_all(evt)  ;return True
        if K["me_all1"].true():   self.A_mods.modal_all(evt)  ;return True
        if K["me_act_up0"].true():    self.A_mods.modal_act_up(evt)  ;return True
        if K["me_act_up1"].true():    self.A_mods.modal_act_up(evt)  ;return True
        if K["me_act_dn0"].true():    self.A_mods.modal_act_down(evt)  ;return True
        if K["me_act_dn1"].true():    self.A_mods.modal_act_down(evt)  ;return True
        if K["me_act_up_ext0"].true():    self.A_mods.modal_act_up_ext(evt)  ;return True
        if K["me_act_up_ext1"].true():    self.A_mods.modal_act_up_ext(evt)  ;return True
        if K["me_act_dn_ext0"].true():    self.A_mods.modal_act_down_ext(evt)  ;return True
        if K["me_act_dn_ext1"].true():    self.A_mods.modal_act_down_ext(evt)  ;return True
        if K["me_mod_up0"].true():    self.A_mods.modal_li_up(evt)  ;return True
        if K["me_mod_up1"].true():    self.A_mods.modal_li_up(evt)  ;return True
        if K["me_mod_dn0"].true():    self.A_mods.modal_li_down(evt)  ;return True
        if K["me_mod_dn1"].true():    self.A_mods.modal_li_down(evt)  ;return True
        if K["undo0"].true() or K["undo1"].true():
            m.undo()
            m.EVT.kill_except(evt)
            return True
        if K["redo0"].true() or K["redo1"].true():
            m.redo()
            m.EVT.kill_except(evt)
            return True
        if K["me_del0"].true() or K["me_del1"].true():
            self.A_mods.modal_del(evt)
            return True
        if K["me_apply0"].true() or K["me_apply1"].true():
            self.A_mods.modal_apply(evt)
            return True

        if self.A_obj.U_modal(evt):       return True

        if self.A_md.sci.inbox(evt):
            if K["me_pan0"].true():
                A_md = self.A_md
                A_md.key_end = K["me_pan_E0"]  ;A_md.to_modal_pan(evt)  ;return True
            if K["me_pan1"].true():
                A_md = self.A_md
                A_md.key_end = K["me_pan_E1"]  ;A_md.to_modal_pan(evt)  ;return True
        if self.A_md.U_modal(evt):        return True

        if self.is_mods_area(evt):
            if self.A_mods.U_modal(evt):  return True
        elif self.A_mods.is_draw_bu_focus:    self.A_mods.is_draw_bu_focus = False ;m.redraw()

        if K["rm0"].true() or K["rm1"].true():
            pass
        return False

    def outside_evt(self, evt):
        if self.A_obj.U_modal != self.A_obj.default_modal:  self.A_obj.U_modal(evt)
        if self.A_md.U_modal != self.A_md.default_modal:    self.A_md.U_modal(evt)
        if self.A_mods.is_draw_bu_focus:    self.A_mods.is_draw_bu_focus = False ;m.redraw()
        self.oo["new_md"].off()
    def title_evt(self, evt):
        if self.A_obj.U_modal != self.A_obj.default_modal:  self.A_obj.U_modal(evt)
        if self.A_md.U_modal != self.A_md.default_modal:    self.A_md.U_modal(evt)
        if self.A_mods.is_draw_bu_focus:    self.A_mods.is_draw_bu_focus = False ;m.redraw()
        self.oo["new_md"].off()

# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def draw_main(self):
        self.bo["oj_info"].bind_draw()      ;self.bo["md_info"].bind_draw()

        bind_color_bu_4_rim()
        o = self.oo["new_md"]
        o.rim.draw()
        o.bg.bind_draw()

        self.A_md.U_draw()

        glEnable(GL_BLEND)
        self.A_mods.sci.use()
        self.A_mods.U_draw()
        self.sci.use()

        glEnable(GL_BLEND)
        self.A_obj.U_draw()

        blf_size(font_0, F[9], 72)
        blf_color(font_0, *self.color.font)
        self.ti["amt"].draw_pos()
        self.da["amt"].draw_pos()

        o.ti.draw_pos()

# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_upd_data_follow(self):
        print(f'    mo  I_upd_data_follow:  {self.tit["ti"].text}')
        self.oj = bpy.context.object
        if not self.oj:     self.kill_data() ;return

        if not self.oj.modifiers:
            self.act_md = None
            self.A_mods.kill_mods()
            self.A_md = cl_md.NONE(self)
            self.A_obj.upd_data()
            return

        self.U_upd_act_ob()
        self.A_obj.upd_data()
        self.A_mods.upd_data()

        if self.A_md.R_type() != self.act_md.type:
            self.A_md = getattr(cl_md, self.act_md.type, cl_md.NONE)(self)
        self.A_md.upd_data()

        ll_mds = self.A_mods.ll_bpy
        self.da["amt"].size = ll_mds
        self.da["amt"].text = f"{len(self.A_mods.sel_range)} / {ll_mds}"
    def I_upd_data_lock(self):
        print(f'    mo  I_upd_data_lock:  {self.tit["ti"].text}')
        if self.oj is not None:
            if self.upd_oj():   self.kill_data() ;return

        if not self.oj:     self.kill_data() ;return

        if not self.oj.modifiers:
            self.act_md = None
            self.A_mods.kill_mods()
            self.A_md = cl_md.NONE(self)
            self.A_obj.upd_data()
            return

        self.U_upd_act_ob()
        self.A_obj.upd_data()
        self.A_mods.upd_data()

        if self.A_md.R_type() != self.act_md.type:
            self.A_md = getattr(cl_md, self.act_md.type, cl_md.NONE)(self)
        self.A_md.upd_data()

        ll_mds = self.A_mods.ll_bpy
        self.da["amt"].size = ll_mds
        self.da["amt"].text = f"{len(self.A_mods.sel_range)} / {ll_mds}"

    def upd_oj(self):
        try:
            self.oj = bpy.data.objects[self.A_obj.oo["da_oj"].da.text]
            return False
        except:
            self.oj = None
            return True

    def kill_data(self):
        self.oj = None
        self.act_md = None
        self.da["amt"].text = "0 / 0"
        self.da["amt"].size = 0
        self.A_mods.kill_mods()
        self.A_md = cl_md.NONE(self)
        self.A_obj.upd_data()
