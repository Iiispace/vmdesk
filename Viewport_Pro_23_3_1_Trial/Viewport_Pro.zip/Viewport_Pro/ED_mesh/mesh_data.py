import bpy, bmesh
from blf import size as blf_size

from .. import m
from .. m import BOX, BLF

from . mesh_block import BL_DIS, BL_DIR, BL_VEC, BL_NOR, BL_INFO, BL_AREA, BL_LEN, BL_DIR3, BL_INFO3, BL_ANGLE

P = None
F = None
font_0 = None

class DATA_VERT:
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'sci',
        'oo',
        'max_ind',
        'li',
        'key_end',
        'tm_L',
        'tm_R',
        'tm_B',
        'tm_T',
        'tm_pan_h',
        'tm_1',
        # 'ref_L',
        # 'ref_R',
        'headkey',
        'endkey',
        'color_ti',
        'color_da',
        'color_bool',
        'tx_wi',
        'hi',
        'li_h',
        'custom_subtype',
        'outside',
        'mesh_data',
        'props',
    )
    def get_data(self):
        self.oo = {
            0: BL_DIS(self),
            1: BL_DIR(self),
            2: BL_VEC(self),
        }
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.color_ti       = P.color_font
        self.color_da       = P.color_font_darker
        self.color_bool     = P.color_bu_2
        self.sci            = m.SCISSOR()
        self.upd_sci()
        self.tx_wi          = F[110]*2
        self.outside        = [None]
        self.props          = w.props

        self.get_data()

        li = {}
        self.li = li
        oo = self.oo
        ll_oo = len(oo)

        me_info = w.bo["me_info"]
        _1 = F[1]

        L = me_info.L + _1
        R = me_info.R - _1
        T = me_info.T - _1

        bu_wi = F[101]
        x1 = R - F[3] - bu_wi - F[2]
        x = x1 - bu_wi

        hi_max = me_info.R_h()
        self.hi = hi_max
        hi = _1
        blf_size(font_0, F[9], 72)
        for r in range(ll_oo):
            e = oo[r]
            e.get_bo(L, R, T, x, x1)
            li[r] = e
            hi += e.hi + _1
            if hi >= hi_max:    break
            T = e.rim.B - _1

        self.li_h = hi - _1 - _1
        self.max_ind = ll_oo - 1
        self.headkey = 0
        self.endkey = len(li) - 1
        self.mesh_data = {}

    def dxy_upd(self, x, y):
        for e in self.li.values():  e.dxy_upd(x, y)
    def upd_sci(self):
        sci         = self.sci
        wsci        = self.w.sci
        L, R, B, T  = self.w.bo["me_info"].R_LRBT()
        sci.x       = max(L, wsci.x)
        sci.w       = max(0, min(R, wsci.x + wsci.w) - sci.x)
        sci.y       = max(B, wsci.y)
        sci.h       = max(0, min(T, wsci.y + wsci.h) - sci.y)

    def I_draw(self):
        oo_v = self.oo.values()
        for e in oo_v:  e.draw_bo()
        blf_size(font_0, F[9], 72)
        for e in oo_v:  e.draw_ti()

    def I_modal_main(self, evt):
        for e in self.li.values():
            if e.rim.inbox(evt):
                self.U_modal = e.U_modal
                return e.U_modal(evt)

        return False

    def outside_evt(self, evt):
        if self.U_modal != self.default_modal:
            self.outside[0] = True
            self.U_modal(evt)

    def upd_data(self):
        if self.w.ti["info"].text != "Edit Mode":
            self.kill_data()
            for e in self.oo.values():  e.upd_data()
            return

        data = self.mesh_data
        data.clear()

        oj = bpy.context.object
        bms = {}
        bm_verts = {}
        bm_edges = {}
        bm_faces = {}
        ll_verts = 0
        ll_edges = 0
        ll_faces = 0
        is_act_oj_selected = False
        for o in bpy.context.selected_objects:
            if o == oj: is_act_oj_selected = True
            bm = bmesh.from_edit_mesh(o.data)
            bms[o] = bm
            e = [(v, o) for v in bm.verts if v.select]
            bm_verts[o] = e
            ll_verts += len(e)

            e = [(v, o) for v in bm.edges if v.select]
            bm_edges[o] = e
            ll_edges += len(e)

            e = [(v, o) for v in bm.faces if v.select]
            bm_faces[o] = e
            ll_faces += len(e)

        if is_act_oj_selected is False:
            o = oj
            bm = bmesh.from_edit_mesh(o.data)
            bms[o] = bm
            e = [(v, o) for v in bm.verts if v.select]
            bm_verts[o] = e
            ll_verts += len(e)

            e = [(v, o) for v in bm.edges if v.select]
            bm_edges[o] = e
            ll_edges += len(e)

            e = [(v, o) for v in bm.faces if v.select]
            bm_faces[o] = e
            ll_faces += len(e)

        if ll_verts == 0:
            pass
        elif ll_verts == 1:
            self.to_A_data(DATA_VERT)
            self.w.ti["info"].text += " (1 Vertice)"
        elif ll_verts == 2:
            self.to_A_data(DATA_VERT)
            self.w.ti["info"].text += " (2 Vertices)"
            verts = []
            for e in bm_verts.values():
                verts += e

            v_act = bms[oj].select_history.active

            if verts[0][0] == v_act:
                v0 = verts[0]
                v1 = verts[1]
            else:
                v0 = verts[1]
                v1 = verts[0]

            if self.props["mesh_ed_dis_invert"]:    v0, v1 = v1, v0

            if self.props["mesh_ed_local"]:
                vec = v0[0].co - v1[0].co
            else:
                vec = (v0[1].matrix_world @ v0[0].co) - (v1[1].matrix_world @ v1[0].co)

            data["vert0"] = v0
            data["vert1"] = v1
            data["vec"] = vec
            data["u_vec"] = vec.normalized()

        if ll_faces == 0:
            if ll_verts == 3:
                self.w.ti["info"].text += " (3 Vertices)"
                self.to_A_data(DATA_VERT_3)
        elif ll_faces == 1:
            self.to_A_data(DATA_FACE)
            self.w.ti["info"].text += " (1 Face)"
            faces = []
            for e in bm_faces.values(): faces += e

            data["face_1"] = faces[0][0]
        else:
            self.to_A_data(DATA_FACE)
            self.w.ti["info"].text += " (Faces)"

        if oj:          data["oj"] = oj
        if bms:         data["bms"] = bms
        if bm_verts:    data["bm_verts"] = bm_verts
        if bm_edges:    data["bm_edges"] = bm_edges
        if bm_faces:    data["bm_faces"] = bm_faces
        data["ll_verts"] = ll_verts
        data["ll_edges"] = ll_edges
        data["ll_faces"] = ll_faces
        for e in self.w.A_data.oo.values():  e.upd_data()

    def to_A_data(self, clas):
        if self.__class__ != clas:
            print(f"    mesh_data  to_A_data : {clas}")
            self.w.A_data = clas(self.w)
            self.w.A_data.mesh_data = self.mesh_data
    def kill_data(self):
        self.mesh_data.clear()

class DATA_VERT_3(DATA_VERT):
    __slots__ = ()
    def get_data(self):
        self.oo = {
            0: BL_DIR3(self),
            1: BL_INFO3(self),
            2: BL_ANGLE(self),
        }
    #
    #
class DATA_FACE(DATA_VERT):
    __slots__ = ()
    def get_data(self):
        self.oo = {
            0: BL_NOR(self),
            1: BL_INFO(self),
            2: BL_AREA(self),
            3: BL_LEN(self),
            4: BL_ANGLE(self),
        }
    #
    #