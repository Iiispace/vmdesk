import bpy
from bgl import glEnable, GL_BLEND
from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP

from . import m, win

P = None
F = None
K = None
N = None
BOX = None
BLF = None
font_0 = None




class INFO:
    __slots__ = 'title', 'body'
    def __init__(self, title, body):
        self.title = title
        self.body = body

class DETAILS(win.WIN):
    __slots__ = (
        'oo',
        'A_data',
        'details',
        'size_xy',
        'pos_xy',
    )
    name = "Details"
    W = []
    IND = []

    def __init__(self, size_xy, pos_xy, details):
        self.details = details
        self.size_xy = size_xy
        self.pos_xy = pos_xy

        super().__init__(size_xy=size_xy, pos_xy=pos_xy, init_fit=True)

    def init_D1(self):
        c = self.color
        c.font = P.color_font
        c.dr_info = P.color_oj_info

        self.bo = {
            "me_info":  BOX(c.dr_info),
        }
        self.ti = {
            "info":     BLF(text=self.details.title),
        }
        self.da = {

        }

        self.oo = {
        }

        blf_title = self.tit["ti"]
        ind = blf_title.name
        blf_title.text = "Details" if ind == 1 else f"Details {ind}"

        self.cv.R_w = self.bo["me_info"].R_w
        self.cv.R_h = self.cv_R_h
        self.upd_data = self.I_upd_data

        self.A_data = DET_BODY(self)


# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo_main(self):
        inn = P.win_border_inner
        bo  = self.bo
        ti  = self.ti
        da  = self.da
        x   = self.box["main"].L + P.win_border - self.cv.x
        y   = self.box["main"].T - P.win_border + self.cv.y
        u   = P.scale[0]
        depth = 2 * (P.win_border + F[1])

        bo_info = bo["me_info"]
        bo_info.depth_L(x, self.size_xy[0] - depth)
        bo_info.depth_T(y - F[21], self.size_xy[1] - F[21] - self.box["ti"].R_h() - depth)

        ti["info"].xy(bo_info.L + F[5], y - F[13])

        blf_size(font_0, F[9], 72)

        self.A_data.__init__(self)

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd_main(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)

        self.A_data.dxy_upd(x, y)

    def glopan_upd(self):
        self.A_data.upd_sci()
    def I_modal_glopan_end_D1(self):
        print(f"    mesh_ed  I_modal_glopan_end_D1")
        self.I_upd_data()
    def modal_mov_end_D1(self):
        print(f"    mesh_ed  modal_mov_end_D1")
        pass

    def cv_R_h(self):
        return self.bo["me_info"].R_h() + F[21]

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def modal_main_area(self, evt):
        if self.bo["me_info"].inbox(evt):
            if self.A_data.U_modal(evt):    return True
        else:
            self.A_data.outside_evt(evt)

        if K["undo0"].true() or K["undo1"].true():
            m.undo()
            m.EVT.kill_except(evt)
            return True
        if K["redo0"].true() or K["redo1"].true():
            m.redo()
            m.EVT.kill_except(evt)
            return True

        return False

    def outside_evt(self, evt):
        self.A_data.outside_evt(evt)
    def title_evt(self, evt):
        self.A_data.outside_evt(evt)

# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def draw_main(self):
        bo = self.bo
        ti = self.ti
        bo["me_info"].bind_draw()

        # for e in self.oo.values():  e.draw_bo()
        # blf_size(font_0, F[9], 72)
        # for e in self.oo.values():  e.draw_ti()

        glEnable(GL_BLEND)
        self.A_data.U_draw()

        blf_size(font_0, F[11], 72)
        blf_color(font_0, *self.color.font)
        ti["info"].draw_pos()

# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_upd_data(self): pass

    def kill_data(self): pass

class DET_BODY:
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'outside',
        'da',
        'tx_wi',
    )
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main

        self.da = {
            "body":     BLF(P.color_font, w.details.body, F[9])
        }

        me_info = w.bo["me_info"]
        self.da["body"].xy(me_info.L + F[6], me_info.T - F[14])
        self.tx_wi = me_info.R_w() - F[6] * 2

    def dxy_upd(self, x, y):
        for e in self.da.values():  e.dxy(x, y)
    def upd_sci(self): pass

    def I_draw(self):
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.tx_wi)
        self.da["body"].set_draw()
        blf_disable(font_0, WORD_WRAP)

    def I_modal_main(self, evt):
        return False

    def outside_evt(self, evt): pass
    def upd_data(self): pass
    def kill_data(self): pass