import bpy
from bpy.app.handlers import persistent

undo_evt = None
P = None
undo_steps = None

@persistent
def after_undo(self, dummy):
    i = bpy.context.scene["undo_ind"]
    print("undo detected, ind = ", i)

    history = undo_evt.history
    if i in history:
        redo_lis = []
        for li in history[i][0]:
            if li[2] is None:
                attr = li[0]
                redo_lis.append((attr, getattr(P, attr), None))
                setattr(P, attr, li[1])
            else:
                attr = li[0]
                prop = getattr(P, attr)
                ind = li[2]
                if isinstance(ind, tuple):
                    i0, i1 = ind
                    redo_lis.append((attr, prop[i0 : i1], ind))
                    prop[i0 : i1] = li[1]
                else:
                    redo_lis.append((attr, prop[ind], ind))
                    prop[ind] = li[1]
        print("Undo succeeded")
        fx = history[i][1]
        undo_evt.push(tuple(redo_lis), fx)
        if fx is not None: fx()

    undo_evt.ind = i
    bpy.context.scene["undo_ind"] = i

@persistent
def after_redo(self, dummy):
    i = bpy.context.scene["undo_ind"]
    print("redo detected, ind = ", i)

    history = undo_evt.history
    if i in history:
        for li in history[i][0]:
            ind = li[2]
            if ind is None:
                setattr(P, li[0], li[1])
            else:
                prop = getattr(P, li[0])
                if isinstance(ind, tuple):
                    prop[ind[0] : ind[1]] = li[1]
                else:
                    prop[ind] = li[1]
        print("Redo succeeded")
        if history[i][1] is not None: history[i][1]()

    undo_evt.ind = i
    bpy.context.scene["undo_ind"] = i


class UNDO_EVT:
    __slots__ = (
        'ind',
        'history',
        'ind_min',
    )
    def __init__(self):
        self.ind = 0
        self.history = {}
        self.ind_min = 0
        #

    def push(self, lis, end_fn):
        i = self.ind
        history = self.history
        history[i] = lis, end_fn
        if i < self.ind_min:    self.ind_min = i

        if len(history) > undo_steps:
            n = self.ind_min
            while True:
                if n in history:
                    del history[n]
                    break
                n += 1
            self.ind_min = n + 1

        self.ind += 1
        bpy.context.scene["undo_ind"] = self.ind