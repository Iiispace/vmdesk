import bpy, gpu
from blf import size as blf_size
from blf import color as blf_color
from blf import position as blf_pos
from blf import draw as blf_draw
from bpy.app.timers import register as thread_reg
from bpy.app.timers import unregister as thread_unreg
from bgl import glEnable, GL_BLEND
from gpu_extras.batch import batch_for_shader

from . import m, dd, filt
from . ll import AN
from . fn import R_str_by_num3
from . ED_setting.setting_ed import SETTING_ED
from . bu import BURE_FA

P = None
F = None
K = None
N = None
BOX = None
BLF = None
shader2D    = None
BIND        = None
UNFL        = None
font_0      = None

indices_box = ((0,1,2),(0,2,3))


class MI: # Task
    __slots__ = (
        "type",
        "ws",
        "ind",
        "U_modal",
        "bo",
        "ti"
    )
    def __init__(self, ty):
        self.type       = ty
        self.ws         = m.TABLE()
        self.U_modal    = self.I_modal_main

        self.bo = {
            "bg":       BOX(P.color_mi_bg),
        }
        self.ti = {
            "ti":       BLF(P.color_mi_ti, ty),
            "amt":      BLF(size = 0),
        }

    def upd_color(self):
        self.bo["bg"].color = P.color_mi_bg
        all_min = True
        for w in self.ws:
            if w.is_min is False:
                all_min = False
                break

        self.ti["ti"].color = P.color_mi_ti_off  if all_min else P.color_mi_ti

    def dx_upd(self, x):
        self.bo["bg"].dx_upd(x)
        self.ti["ti"].x += x
        self.ti["amt"].x += x

    def evt_min(self, w):
        if w.is_min:
            if m.W_act == w:
                pass
                print("TODO")
            w.unmin_action()
            self.ti["ti"].color = P.color_mi_ti
            self.bo["bg"].color = P.color_mi_bg
        else:
            if m.W_act == w:
                w.min_action()
                for e in m.admin.tb.mis:
                    if self in e.ws:    e.upd_color()
            else:
                w.react(m.EVT.evt)
                m.M.set_mou_ic('DEFAULT')
            m.redraw()

    def I_modal_main(self, evt):
        bo_bg   = self.bo["bg"]
        if bo_bg.inbox(evt) is False:
            if bo_bg.color != P.color_mi_bg:
                bo_bg.color = P.color_mi_bg
                m.redraw()
            return False

        if bo_bg.color != P.color_mi_bg_fo:
            bo_bg.color = P.color_mi_bg_fo
            m.redraw()

        if K["sel_fast0"].true() or K["sel_fast1"].true():
            m.EVT.kill()
            if self.ti["amt"].size == 1:    self.evt_min(self.ws[0])
            else:
                def confirm_fn(name):
                    for w in self.ws:
                        if w.tit["ti"].text == name:
                            self.evt_min(w)
                            break

                bo = self.bo["bg"]
                dd.DDTX_FN(
                    evt,
                    m.W_act.tit["ti"].text if m.W_act in self.ws else "",
                    filt.FIL_TYPE_EXC((m.NAME(w.tit["ti"].text) for w in self.ws)),
                    (bo.L, bo.R, bo.T, bo.T + F[16]),
                    confirm_fn,
                    tx_clear = True
                )

            return True

        return True


class TB:
    __slots__ = (
        "RET",
        "U_draw",
        "U_modal",
        "draw_back",
        "draw_top",
        "bo",
        "mis",
        "actbox",
        "is_out_region",
        "x",
        "y",
        "thread_task",
        "thread_task_li",
        "frame_time",
    )
    def __init__(self):
        tb  = self
# INS CLASS
        class MIS(list):
            __slots__ = "find", "active"
            def __init__(self):
                self.find       = {}
                self.active     = None
            def new(self, e):
                self.append(e)
                self.find[e.type] = len(self) - 1
            def delete(self, ty):
                find = self.find
                del self[find[ty]]
                find.clear()
                for i, e in enumerate(self):    find[e.type] = i
            def kill(self):
                self.clear()
                self.find.clear()

            def get_bo(self):
                tb_bo   = tb.bo
                L       = tb_bo["start"].R + F[8]
                B       = tb_bo["bg"].B
                T       = tb_bo["bg"].T - F[2]
                wi      = F[110]
                dL      = wi + F[2]
                for i, e in enumerate(self):
                    bo  = e.bo
                    ti  = e.ti
                    bo["bg"].LRBT(L, L + wi, B, T)
                    bo["bg"].upd()

                    ti["ti"].LB(bo["bg"], F[6], F[6])
                    ti["amt"].y = ti["ti"].y
                    ti["amt"].x = bo["bg"].R - F[20]
                    L += dL
                if m.W_act is None:
                    actbox      = tb.actbox
                    actbox.R    = actbox.L
                    actbox.upd()
                else:
                    tb.actbox.upd_by_mi(m.W_act.task)
        class MI_ACTBOX:
            __slots__ = "color", "L", "R", "B", "T", "bat"
            def __init__(self):
                self.L      = 0
                self.R      = 0
                self.B      = 0
                self.T      = 0
                self.bat    = batch_for_shader(shader2D, 'TRIS', {"pos": (
                    (0,0), (0,0), (0,0), (0,0))}, indices=indices_box
                )
                self.color  = P.color_mi_act

            def bind_draw(self):
                BIND()
                UNFL("color", self.color)
                self.bat.draw(shader2D)

            def upd(self):
                self.bat    = batch_for_shader(shader2D, 'TRIS', {"pos": (
                    (self.L,self.B),(self.L,self.T),
                    (self.R,self.T),(self.R,self.B))}, indices=indices_box
                )
            def upd_by_mi(self, mi):
                if mi in tb.thread_task_li:
                    self.R = self.L
                else:
                    d           = F[2]
                    bo          = mi.bo["bg"]
                    self.L      = bo.L + d
                    self.R      = bo.R - F[24]
                    self.B      = bo.B + d
                    self.T      = bo.T - d
                self.bat    = batch_for_shader(shader2D, 'TRIS', {"pos": (
                    (self.L,self.B),(self.L,self.T),
                    (self.R,self.T),(self.R,self.B))}, indices=indices_box
                )
# INS CLASS END

        self.RET            = None
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_outside
        self.draw_back      = []
        self.draw_top       = []

        self.thread_task    = None
        self.thread_task_li = {}

        self.bo = {
            "bg":       BOX(P.color_tb_bg),
            "start":    BOX(P.color_icon_start),
        }
        self.bo["bg"].R = 65535

        self.mis        = MIS()
        self.actbox     = MI_ACTBOX()
        self.get_bo()
        self.is_out_region      = m.region_data.outside
# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo(self):
        bo          = self.bo
        region_data = m.region_data
        self.x      = region_data.L
        self.y      = region_data.B

        bo["bg"].B      = self.y
        bo["bg"].T      = bo["bg"].B + F[21]

        bo["start"].B   = bo["bg"].B + F[4]
        bo["start"].T   = bo["bg"].T - F[5]
        bo["start"].L   = self.x + F[5]
        bo["start"].R   = bo["start"].L + bo["start"].R_h()

        for e in bo:        bo[e].upd()
        self.mis.get_bo()

    def task_init(self, w):
        name    = w.__class__.name
        mis     = self.mis
        if name in mis.find:
            mi = mis[mis.find[name]]
            mi.ws.new(w)
            amt = mi.ti["amt"]
            amt.size += 1
            amt.text = R_str_by_num3(amt.size)
            mi.upd_color()
        else:
            blf_size(font_0, F[10], 72)
            len_mis = len(mis)
            mi = MI(name)
            mis.new(mi)
            mi.ws.new(w)
            mi.ti["amt"].size = 1

            tb_bo   = self.bo
            B       = tb_bo["bg"].B
            T       = tb_bo["bg"].T - F[2]
            wi      = F[110]
            L       = tb_bo["start"].R + F[8] + len_mis * (wi + F[2])

            bo  = mi.bo
            ti  = mi.ti
            bo["bg"].LRBT(L, L + wi, B, T)
            bo["bg"].upd()

            ti["ti"].LB(bo["bg"], F[6], F[6])
            ti["amt"].y = ti["ti"].y
            ti["amt"].x = bo["bg"].R - F[20]

            ti["ti"].fix_long_text(bo["bg"].R - F[30], F[8])
        self.actbox.upd_by_mi(mi)
        return mi

    def task_end(self, w):
        name        = w.__class__.name
        mis         = self.mis
        mi          = mis[mis.find[name]]
        mi.ws.delete(w)
        amt         = mi.ti["amt"]
        amt.size    -= 1
        if amt.size == 0:
            amt.text = ""
            mis.delete(name)
            self.do_anim_task_end()
        elif amt.size == 1: amt.text = ""
        else:               amt.text = R_str_by_num3(amt.size)

    def is_inside(self, y):
        bo = self.bo["bg"]
        if bo.B <= y <= bo.T:   return True
        return False

    def disable(self):
        self.U_draw     = N
        self.U_modal    = N
    def enable(self):
        self.U_draw     = self.I_draw
        self.U_modal    = self.I_modal_outside

    def do_anim_task_end(self):
        tb_bo   = self.bo
        L       = tb_bo["start"].R + F[8]
        B       = tb_bo["bg"].B
        T       = tb_bo["bg"].T - F[2]
        wi      = F[110]
        dL      = wi + F[2]

        if P.anim_tb_task:
            if self.thread_task is None:
                self.frame_time     = P.anim_frame_time
                self.thread_task    = self.I_modal_thread
                thread_reg(self.thread_task)
                print("-- tb.TB().thread_reg --")

            li      = self.thread_task_li
            v       = P.anim_speed * 8
            for e in self.mis:
                if e in li:
                    an      = li[e]
                    an.des  = L
                    an.v    = v if L > e.bo["bg"].L else -v
                else:   li[e] = AN(L, v if L > e.bo["bg"].L else -v)

                L += wi

            self.actbox.R = self.actbox.L
            self.actbox.upd()
        else:
            if self.thread_task is not None:
                thread_unreg(self.thread_task)
                self.thread_task = None
                print("    tb thread killed ..")
                self.thread_task_li.clear()

            self.mis.get_bo()
            if m.W_act is not None: self.actbox.upd_by_mi(m.W_act.task)

    def invoke_menu_start(self, evt):
        self.RET = {'RUNNING_MODAL'}
        tb = m.admin.tb

        def confirm_fn(tx):
            print("    tb  menu_start  confirm_fn")
            try:
                eval(MENU_START.search_list[tx])
            except:
                pass
                print("        fail")

        L = tb.x + F[3]
        R = L + F[101]*2
        B = tb.bo["bg"].T
        T = B + F[300]

        NAME = m.NAME

        MENU_START(evt, "", filt.FIL([NAME(e) for e in MENU_START.search_list]),
            LRBT        = (L, R, T - F[16], T),
            confirm_fn  = confirm_fn)
# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_modal_inside(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.is_inside(y) is False or self.is_out_region(x, y):
            self.U_modal = self.I_modal_outside
            self.RET = None
            m.M.restore_mou_ic()

            for e in self.mis:  e.upd_color()
            self.bo["start"].color = P.color_icon_start
            m.redraw()
            return

        if x <= self.bo["start"].R + F[3]:
            if self.bo["start"].color != P.color_icon_start_fo:
                self.bo["start"].color = P.color_icon_start_fo
                m.redraw()

            if K["sel0"].true() or K["sel1"].true(): self.invoke_menu_start(evt) ;return
        else:
            if self.bo["start"].color != P.color_icon_start:
                self.bo["start"].color = P.color_icon_start
                m.redraw()

        for e in self.mis:
            if e.U_modal(evt):  break
    def I_modal_outside(self, evt):
        y = evt.mouse_region_y
        if self.is_inside(y):
            region_data = m.region_data
            region_data.upd()
            if self.x != region_data.L or self.y != region_data.B:
                self.get_bo()
                m.redraw()
            if self.is_out_region(evt.mouse_region_x, y) is False:
                self.U_modal = self.I_modal_inside
                self.RET = {'RUNNING_MODAL'}
                m.M.set_mou_ic('DEFAULT')
                if m.W_act != None:     m.W_act.U_modal = m.W_act.default_modal

    def I_modal_thread(self):
        for e, an in self.thread_task_li.copy().items():
            v       = an.v
            des     = e.bo["bg"].L + v

            if v > 0:
                if des >= an.des:
                    v = an.des - e.bo["bg"].L
                    del self.thread_task_li[e]
            elif des <= an.des:
                v = an.des - e.bo["bg"].L
                del self.thread_task_li[e]

            e.dx_upd(v)

        if not self.thread_task_li:
            thread_unreg(self.thread_task)
            self.thread_task = None
            if m.W_act is not None: self.actbox.upd_by_mi(m.W_act.task)
            m.redraw()
            print("    tb thread killed ..")
            return

        m.redraw()
        return self.frame_time

# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        if self.draw_back:
            for e in self.draw_back:    e.U_draw()

        glEnable(GL_BLEND)
        self.bo["bg"].bind_draw()
        self.bo["start"].bind_draw()
        for e in self.mis:              e.bo["bg"].bind_draw()
        self.actbox.bind_draw()

        F10 = F[10]
        F8  = F[8]
        for e in self.mis:
            blf_size(font_0, F10, 72)
            e.ti["ti"].set_color()
            e.ti["ti"].draw_pos()

            blf_size(font_0, F8, 72)
            e.ti["amt"].draw_pos()

        if self.draw_top:
            for e in self.draw_top:     e.U_draw()

# ▅▅▅  CLS                         ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    @classmethod
    def R_h(cls):   return F[21]


class MENU_START(dd.DDTX):
    __slots__ = ('confirm_fn', 'fin_D1', 'oo', 'RET')
    search_list = {
        "Modifier Editor":      'bpy.ops.wm.md_editor_operator("INVOKE_DEFAULT")',
        "Driver Editor":        'bpy.ops.wm.dr_editor_operator("INVOKE_DEFAULT")',
        "Setting Editor":       'bpy.ops.wm.setting_editor_operator("INVOKE_DEFAULT")',
        "Mesh Editor":          'bpy.ops.wm.mesh_editor_operator("INVOKE_DEFAULT")',
    }
    def __init__(self,
        evt,
        name,
        fil,
        LRBT        = None,
        confirm_fn  = None,
        tx_clear    = None,
        fin_D1      = None,
    ):
        self.confirm_fn = confirm_fn

        super().__init__({"name": name, "LRBT": LRBT}, fil, tx_clear=tx_clear, enable_filter=True)

        if not self.bo["tx"].inbox(evt):    m.M.set_mou_ic('DEFAULT')

        self.fin_D1 = fin_D1
        bo = self.bo
        bo_bg = bo["bg"]
        u = P.scale[0]
        _2 = F[2]
        L = bo_bg.L - _2
        R = bo_bg.R + _2
        T = bo_bg.T + _2
        B = m.admin.tb.bo["bg"].T + F[1]
        bo["main"] = BOX(P.color_menu_start_bg, L, R, B, T)
        bo["main"].upd()

        if P.win_shade_on:
            bo["shade"].get_by_rim(L, R, B, T, P.dd_shade_softness, P.dd_shade_offset, u)
            bo["shade"].upd()

        base_evt        = self.base_evt
        oo = {
            "off":      BURE_FA(self, "off", "Off", self.bu_fn_off,
                base_evt    = base_evt,
                auto        = False),
            "restart":  BURE_FA(self, "restart", "Restart", self.bu_fn_restart,
                base_evt    = base_evt,
                auto        = False),
        }
        self.oo = oo

        bu_hi = F[16]
        bu_wi = F[82]
        bu_d = F[3]
        R1 = R - F[4]
        L1 = R1 - bu_wi
        B1 = B + F[4]
        T1 = B1 + bu_hi
        oo["off"].LRBT(L1, R1, B1, T1)
        B2 = T1 + bu_d
        T2 = B2 + bu_hi
        oo["restart"].LRBT(L1, R1, B2, T2)

    def fin(self, *e):
        print(f"    dd  DDTX_FN(DDTX)  fin")
        del m.head_modal[-1]
        m.admin.tb.draw_top.remove(self)
        if self.fil is not None:    self.fil.clear()
        self.U_kill_thread_cursor()

        m.M.set_mou_ic('DEFAULT')
        m.EVT.kill()
        m.redraw()

        if self.fin_D1 is not None: self.fin_D1()

    def evt_confirm(self, *e):
        print(f"    dd  DDTX_FN(DDTX)  evt_confirm")
        self.confirm_fn(self.da["tx"].text)
        self.fin()

    def I_draw(self):
        bo = self.bo
        oo_values = self.oo.values()
        glEnable(GL_BLEND)
        bo["shade"].draw()
        bo["main"].bind_draw()
        bo["bg"].bind_draw()                ;bo["tx"].bind_draw()
        bo["fil"].bind_draw()

        self.bu_scrollY.U_draw()

        self.sci_tx.ENABLE()
        bo["highlight"].bind_draw()         ;self.U_draw_cursor()

        blf_size(font_0, F[9], 72)
        self.da["tx"].set_color()           ;self.da["tx"].draw_pos()

        self.sci_fil.use()
        glEnable(GL_BLEND)
        self.actbox.bind_draw()
        li  = self.li
        x   = self.fil_x
        blf_color(font_0, *P.color_font)
        for i in self.draw_ot:  li[i].draw_pos_by_x(x)
        blf_color(font_0, *P.color_font_fo)
        for i in self.draw_act: li[i].draw_pos_by_x(x)

        self.sci_fil.DISABLE()

        glEnable(GL_BLEND)
        m.bind_color_bu_1_rim()
        for e in oo_values:   e.draw_rim()
        for e in oo_values:   e.draw_bg()
        for e in oo_values:   e.draw_ti()

    def I_modal_main(self, evt):
        if self.bo["main"].inbox(evt) == False:
            if K["dd_sel0"].true(): self.evt_confirm(evt)  ;return
            if K["dd_sel1"].true(): self.evt_confirm(evt)  ;return

        bu_RET = self.bu_scrollY.evt(evt)
        if bu_RET is not None:
            if K["dd_bar0"].true():
                self.key_end = K["dd_bar_E0"]
                if bu_RET:  self.to_modal_bar_bu(evt)
                else:       self.to_modal_bar_bg(evt)
                return
            if K["dd_bar1"].true():
                self.key_end = K["dd_bar_E1"]
                if bu_RET:  self.to_modal_bar_bu(evt)
                else:       self.to_modal_bar_bg(evt)
                return

        if self.bo["tx"].inbox(evt):
            self.clear_draw_act()
            m.M.set_mou_ic('TEXT')
            self.U_modal = self.I_modal_tx
            self.I_modal_tx(evt)
            return

        if self.bo["fil"].inbox(evt):
            self.upd_draw_act_by_y(evt.mouse_region_y)
            if K["dd_pan0"].true():
                self.key_end = K["dd_pan_E0"]  ;self.to_modal_pan_fil(evt)  ;return
            if K["dd_pan1"].true():
                self.key_end = K["dd_pan_E1"]  ;self.to_modal_pan_fil(evt)  ;return
            if K["dd_sel0"].true():     self.evt_fil_sel(evt)  ;return
            if K["dd_sel1"].true():     self.evt_fil_sel(evt)  ;return
        else:   self.clear_draw_act()

        if K["dd_cancel0"].true():  self.fin(evt)   ;return
        if K["dd_cancel1"].true():  self.fin(evt)   ;return
        if K["dd_confirm0"].true(): self.evt_confirm(evt)  ;return
        if K["dd_confirm1"].true(): self.evt_confirm(evt)  ;return

        if self.oo["off"].rim.in_LR(evt):
            for e in self.oo.values():
                if e.rim.in_BT(evt):    e.inside(evt)  ;return

        self.unicode_evt(evt)

    def base_evt(self, evt):
        if K["dd_cancel0"].true() or K["dd_cancel1"].true():
            self.fin()
            if self.fil is not None:    self.fil.clear()
            return True
        if K["dd_confirm0"].true() or K["dd_confirm1"].true():
            self.evt_confirm()
            return True
        return False

    def bu_fn_off(self):
        self.fin()
        m.sys_off()
    def bu_fn_restart(self):
        self.fin()
        m.sys_restart()