from . import m

P = None
F = None
K = None

class MOVE_FULL_PROTECT:
    __slots__ = ()
    def to_modal_mov(self, evt):
        self.key_end.true()
        m.head_modal.append(self.I_modal_mov)
        m.get_mou(evt)
    def modal_mov_end_D1(self): pass
    def modal_mov_end(self):
        print(f"    win_cls  MOVE_FULL_PROTECT  modal_mov_end")
        del m.head_modal[-1]
        r = self.bo["rim"]
        dx, dy = m.R_full_protect_dxy(r.L, r.R, r.B, r.T)
        if dx or dy:    self.dxy_upd(dx, dy)

        m.EVT.kill()
        m.redraw()
        self.modal_mov_end_D1()
    def I_modal_mov(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_mov_end()
                return
        if K["cancel0"].true() or K["cancel1"].true():
            self.modal_mov_end()
            return

        m.dx    = evt.mouse_x - m.mou_x
        m.dy    = evt.mouse_y - m.mou_y
        self.dxy_upd(m.dx, m.dy)
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()

class FLASH:
    __slots__ = ()
    def do_flash(self):
        if m.thread_isreg(m.flash_box_thread_fn):   return
        r = self.bo["rim"]
        m.FLASH_BOX.init(r.L, r.R, r.B, r.T)

class OO_FO:
    __slots__ = 'oo_fo'
    def unfocus(self):
        if self.oo_fo is not None:
            self.oo_fo.unfocus()
            self.oo_fo = None
            m.redraw()
    def focus_check(self, evt, fo):
        if self.oo_fo is None:
            fo.focus()
            self.oo_fo = fo
            m.redraw()
        elif self.oo_fo != fo:
            self.oo_fo.unfocus()
            fo.focus()
            self.oo_fo = fo
            m.redraw()
        elif evt.value == 'RELEASE':
            if hasattr(fo, "is_allow"): fo.is_allow = True