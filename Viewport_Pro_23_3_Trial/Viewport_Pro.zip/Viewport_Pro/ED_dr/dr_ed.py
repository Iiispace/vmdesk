import bpy
from bgl import glEnable, GL_BLEND
from blf import size as blf_size
from blf import color as blf_color

from . import dr_vars
from . dr_data import DR
from . dr_val import DRVAL

from .. import m, win

from .. link_data import TR_driver
from .. m import BOX, BLF, bind_color_bu_4_rim
from .. bu import BU4

P = None
F = None
K = None
N = None
font_0 = None

class OP_DR(bpy.types.Operator):
    __slots__ = ()
# ▅▅▅  HEAD                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    bl_idname = "wm.dr_editor_operator"
    bl_label = "Driver Editor"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        print("    dr_ed  bpyOperator    OP_DR invoke")
        if m.op_poll(context):  return {'CANCELLED'}

        DR_ED()
        return {'FINISHED'}


class DR_ED(win.WIN):
    __slots__ = (
        'oo',
        'A_dr',
        'A_var',
        'A_vars',
        'oj',
        'I_upd_data',
        'U_upd_act_ob',
        'act_dr',
        'drs',
        'is_drs_area',
        'is_link_area',
    )
    name = "Driver Editor"
    W = []
    IND = []

    def __init__(self, bu=None):
        self.U_upd_act_ob = N

        if bu is None:
            super().__init__(size_xy=P.win_size_init_DE)
        else:
            super().__init__(size_xy=P.win_size_init_DE, pos_xy=(int(bu.rim.L), int(bu.rim.B)))

            self.I_upd_data = self.I_upd_data_lock
            self.upd_data = self.I_upd_data
            A_dr_oo = self.A_dr.oo
            A_dr_oo["ti_oj"].off()
            A_dr_oo["bu_sync_oj"].off()

            self.oj = bu.w.w.oj
            A_dr_oo["da_oj"].da.text = self.oj.name

            path    = bu.R_data_path()
            index   = bu.array_index
            driver  = TR_driver(self.oj, path, index)
            if driver is None:
                bu.driver_add()
                m.undo_str = "[Modifier Editor] Driver Add"
                m.undo_push()

            A_dr_oo["da_dr"].da.text = f'{path}, index={index}'
            m.refresh()
    def init_D1(self):
        c = self.color
        c.font = P.color_font
        c.dr_info = P.color_oj_info

        self.bo = {
            "dr_info":  BOX(c.dr_info),
            "dr_var":   BOX(),
        }
        self.ti = {
            "amt":          BLF(text = "AMT"),
        }
        self.da = {
            "amt":          BLF(size = 0, text = "  0"),
        }
        self.oo = {
            "new_var":      BU4(self, "new_var", "Add"),
        }

        self.A_dr   = DR(self)
        self.A_var  = DRVAL(self)

        blf_title = self.tit["ti"]
        ind = blf_title.name
        if ind == 1:
            blf_title.text = "Driver Editor"
            if P.sync_act_oj:
                self.I_upd_data = self.I_upd_data_follow
                self.A_dr.oo["ti_oj"].on()
            else:
                self.I_upd_data = self.I_upd_data_lock
                self.A_dr.oo["ti_oj"].off()

            self.oj = bpy.context.object  if bpy.context.object else None
        else:
            blf_title.text = f"Driver Editor {ind}"
            self.I_upd_data = self.I_upd_data_lock
            self.A_dr.oo["ti_oj"].off()

            oj = None
            sel_oj = bpy.context.selected_objects
            if bpy.context.object:
                for e in reversed(sel_oj):
                    if e != bpy.context.object:     oj = e  ;break
                self.oj = oj  if oj != None  else bpy.context.object
            else:
                self.oj = sel_oj[-1]  if sel_oj else None

        self.cv.R_w = self.bo["dr_info"].R_w
        self.cv.R_h = self.cv_R_h
        self.upd_data = self.I_upd_data
        self.act_dr = None

# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo_main(self):
        inn = P.win_border_inner
        bo  = self.bo
        ti  = self.ti
        da  = self.da
        x   = self.box["main"].L + P.win_border - self.cv.x
        y   = self.box["main"].T - P.win_border + self.cv.y
        u   = P.scale[0]
        depth = inn - 3

        bo["dr_info"].depth_L(x, F[480] + depth)
        bo["dr_info"].depth_T(y, round(138 * u))
        bo["dr_var"].depth_L(x, F[300])
        bo["dr_var"].depth_T(bo["dr_info"].B - inn, round(298 * u))

        self.A_dr.get_bo()
        self.A_var.get_bo()

        R = bo["dr_info"].R - F[1]
        T = bo["dr_var"].T - F[3]
        blf_size(font_0, F[9], 72)
        self.oo["new_var"].LRBT(R - F[34], R, T - F[15], T)

        self.A_vars = dr_vars.VARS(
            self,
            bo["dr_var"].R + inn,
            bo["dr_info"].R,
            bo["dr_var"].T - F[21]
        )
        self.is_link_area = self.A_vars.is_link_area

        ti["amt"].x = bo["dr_var"].R + F[7]     ;ti["amt"].y = bo["dr_var"].T - F[13]
        da["amt"].x = ti["amt"].x + F[24]       ;da["amt"].y = ti["amt"].y

        # self.is_drs_area = self.drs.is_inside

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd_main(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        self.oo["new_var"].dxy_upd(x, y)

        self.A_dr.dxy_upd(x, y)
        self.A_var.dxy_upd(x, y)
        self.A_vars.dxy_upd(x, y)

    def glopan_upd(self): pass
    def I_modal_glopan_end_D1(self):
        print(f"    dr_ed  I_modal_glopan_end_D1")
        self.A_dr.glopan_end()
        self.A_var.glopan_end()
        self.A_vars.glopan_end()

    def cv_R_h(self):
        return self.bo["dr_info"].R_h() + self.bo["dr_var"].R_h() + P.win_border_inner

    def R_A_ll(self):       return self.A_vars
    def R_bo_info_B(self):  return self.box["rim"].T + 999

    def bu_fn_new_var(self):
        print(f"    dr_ed  bu_fn_new_var")
        self.act_dr.driver.variables.new()
        P.refresh = True
        m.refresh()
        m.undo_str = "[Driver Editor] Variable Add"
        m.undo_push()

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def modal_main_area(self, evt):
        if self.oo["new_var"].rim.inbox(evt):
            self.oo["new_var"].fo()
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.oo["new_var"].on()
                self.bu_fn_new_var()
                m.init_wait_release()
                return True
        else:
            self.oo["new_var"].off()

        if K["me_all0"].true():   self.A_vars.modal_all(evt)  ;return True
        if K["me_all1"].true():   self.A_vars.modal_all(evt)  ;return True
        if K["me_act_up0"].true():    self.A_vars.modal_act_up(evt)  ;return True
        if K["me_act_up1"].true():    self.A_vars.modal_act_up(evt)  ;return True
        if K["me_act_dn0"].true():    self.A_vars.modal_act_down(evt)  ;return True
        if K["me_act_dn1"].true():    self.A_vars.modal_act_down(evt)  ;return True
        if K["me_act_up_ext0"].true():    self.A_vars.modal_act_up_ext(evt)  ;return True
        if K["me_act_up_ext1"].true():    self.A_vars.modal_act_up_ext(evt)  ;return True
        if K["me_act_dn_ext0"].true():    self.A_vars.modal_act_down_ext(evt)  ;return True
        if K["me_act_dn_ext1"].true():    self.A_vars.modal_act_down_ext(evt)  ;return True
        if K["me_mod_up0"].true():    self.A_vars.modal_li_up(evt)  ;return True
        if K["me_mod_up1"].true():    self.A_vars.modal_li_up(evt)  ;return True
        if K["me_mod_dn0"].true():    self.A_vars.modal_li_down(evt)  ;return True
        if K["me_mod_dn1"].true():    self.A_vars.modal_li_down(evt)  ;return True
        if K["undo0"].true() or K["undo1"].true():
            m.undo()
            m.EVT.kill_except(evt)
            return True
        if K["redo0"].true() or K["redo1"].true():
            m.redo()
            m.EVT.kill_except(evt)
            return True
        if K["me_del0"].true() or K["me_del1"].true():
            self.A_vars.modal_del(evt)
            return True

        if self.A_dr.U_modal(evt):      return True
        if self.A_var.U_modal(evt):     return True
        if self.A_vars.U_modal(evt):    return True

        return False

    def outside_evt(self, evt):
        if self.A_dr.U_modal != self.A_dr.default_modal:    self.A_dr.U_modal(evt)
        if self.A_var.U_modal != self.A_var.default_modal:  self.A_var.U_modal(evt)
        self.oo["new_var"].off()
    def title_evt(self, evt):
        if self.A_dr.U_modal != self.A_dr.default_modal:    self.A_dr.U_modal(evt)
        if self.A_var.U_modal != self.A_var.default_modal:  self.A_var.U_modal(evt)
        self.oo["new_var"].off()

# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def draw_main(self):
        self.bo["dr_info"].bind_draw()
        self.bo["dr_var"].draw()

        bind_color_bu_4_rim()
        o = self.oo["new_var"]
        o.rim.draw()
        o.bg.bind_draw()

        self.sci.use()
        self.A_dr.U_draw()

        glEnable(GL_BLEND)
        self.sci.use()
        self.A_var.U_draw()

        glEnable(GL_BLEND)
        self.A_vars.sci.use()
        self.A_vars.U_draw()

        self.sci.use()
        blf_size(font_0, F[9], 72)
        blf_color(font_0, *self.color.font)
        self.ti["amt"].draw_pos()
        self.da["amt"].draw_pos()

        o.ti.draw_pos()

# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_upd_data_follow(self):
        print(f'    dr_ed  I_upd_data_follow:  {self.tit["ti"].text}')
        self.oj = bpy.context.object

        self.drs    = self.TR_drs()
        tx          = self.A_dr.oo["da_dr"].da.text
        self.act_dr = self.TR_dr_by_drs(tx[: tx.rfind(",")], tx[tx.rfind("=")+1 :])

        if self.act_dr is None:
            if self.drs:    self.act_dr = self.drs[0]
        self.A_dr.upd_data()
        self.A_var.upd_data()
        self.A_vars.upd_data()

        ll_mds = self.A_vars.ll_bpy
        self.da["amt"].size = ll_mds
        self.da["amt"].text = f"{len(self.A_vars.sel_range)} / {ll_mds}"
    def I_upd_data_lock(self):
        print(f'    dr_ed  I_upd_data_lock:  {self.tit["ti"].text}')
        self.check_oj()

        self.drs    = self.TR_drs()
        tx          = self.A_dr.oo["da_dr"].da.text
        self.act_dr = self.TR_dr_by_drs(tx[: tx.rfind(",")], tx[tx.rfind("=")+1 :])

        if self.act_dr is None:
            if self.drs:    self.act_dr = self.drs[0]
        self.A_dr.upd_data()
        self.A_var.upd_data()
        self.A_vars.upd_data()

        ll_mds = self.A_vars.ll_bpy
        self.da["amt"].size = ll_mds
        self.da["amt"].text = f"{len(self.A_vars.sel_range)} / {ll_mds}"

    def check_oj(self):
        try:    self.oj.name
        except:
            oj_name = self.A_dr.oo["da_oj"].da.text
            print(f"    dr_ed  check_oj  except:  {oj_name}")
            self.oj = bpy.data.objects[oj_name]  if oj_name in bpy.data.objects else None

    def TR_drs(self):
        try:    return self.oj.animation_data.drivers
        except: return None
    def TR_dr_by_drs(self, path, index=0):
        try:    return self.drs.find(path, index=int(index))
        except: return None

    def kill_data(self):    pass
