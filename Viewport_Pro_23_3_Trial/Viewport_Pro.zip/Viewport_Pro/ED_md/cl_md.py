from . bu_md import *

from .. filt import FIL, FIL_TYPE_EXC
from .. bu import BURE
from .. bpy_ops import VPP_BEVEL_PROFILE

P = None
F = None
K = None
BLF = None
font_0 = None

def R_md_dp(name, attr):    return f'modifiers["{name}"].{attr}'
def R_driver(ob, full_path):
    if ob.animation_data:   return ob.animation_data.drivers.find(full_path)
    return None


class BU_SET:
    __slots__ = 'li', 'enum', 'amt', 'dic_val_bu', 'attr'
    def __init__(self, li_bu, enum):
        self.li = li_bu
        self.enum = enum
        self.amt = len(li_bu)
        self.dic_val_bu = {b.value : b  for b in li_bu}
        self.attr = li_bu[0].attr

class MD:
    __slots__ = (
        'w',
        'RET',
        'sci',
        'U_draw',
        'U_modal',
        'default_modal',
        'oo',
        'line',
        'oo_22',
        'oo_12',
        'oo_9',
        'oo_free',
        'oo_kf',
        'oo_dr',
        'bu_sets',
        'props',
        'pick_data',
    )
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.sci            = w.sci
        self.oo_kf          = {}
        self.oo_dr          = {}
        self.props          = w.act_md.bl_rna.properties
        self.init()

    def to_default_modal(self):
        self.U_modal = self.I_modal_main
    def get_oo(self, line):
        oo      = {}
        self.oo = oo

        for e in line:
            for o in e:     oo[o.name] = o

    def change_kfdr_attr(self, old_attr, new_attr, ti):
        oo_kf = self.oo_kf
        oo_dr = self.oo_dr
        kf = oo_kf.pop(old_attr)
        dr = oo_dr.pop(old_attr)
        kf.attr = new_attr
        dr.attr = new_attr
        dr.ti.text = ti
        oo_kf[new_attr] = kf
        oo_dr[new_attr] = dr
        return kf, dr
    def replace_oo_9(self, oo, old, new, k, l0, l1):
        self.oo_9.remove(old)
        self.oo_9.add(new)
        oo[k] = new
        self.line[l0][l1] = new
    def replace_oo_9_22(self, oo, old, new, k, l0, l1):
        self.oo_9.remove(old)
        self.oo_22.add(new)
        oo[k] = new
        self.line[l0][l1] = new
    def replace_oo_22_9(self, oo, old, new, k, l0, l1):
        self.oo_22.remove(old)
        self.oo_9.add(new)
        oo[k] = new
        self.line[l0][l1] = new
    def add_oo_free(self, oo, new, k, l0):
        self.oo_free.add(new)
        self.oo[k] = new
        self.line[l0].append(new)
    def del_oo_free(self, oo, new, k, l0, l1):
        self.oo_free.remove(new)
        del self.oo[k]
        del self.line[l0][l1]
    def add_oo_9(self, oo, new, k, l0):
        self.oo_9.add(new)
        self.oo[k] = new
        self.line[l0].append(new)
    def del_oo_9(self, oo, new, k, l0, l1):
        self.oo_9.remove(new)
        del self.oo[k]
        del self.line[l0][l1]

    def upd_color(self, an_data, act_md):
        for bu_set in self.bu_sets:
            v = getattr(act_md, bu_set.attr)
            for e in bu_set.li:
                e.on()  if e.value == v else e.off()

        for e in self.oo_kf.values():   e.upd_ti(an_data, act_md)
        for e in self.oo_dr.values():   e.upd_dr(an_data, act_md)
    def upd_ref_color(self, an_data, act_md, oo, l):
        if an_data:
            drivers = an_data.drivers
            if drivers:
                name = act_md.name
                for k_bu, attr in l:
                    if drivers.find(f'["modifiers[{name}].{attr}"]') is None:
                        oo[k_bu].ti.color = P.color_font
                    else:
                        oo[k_bu].ti.color = P.color_bu_dr
                return

        for k_bu, attr in l: oo[k_bu].ti.color = P.color_font

    def dxy_upd(self, x, y):
        for e in self.oo.values():  e.dxy_upd(x, y)

    def I_modal_main(self, evt):
        self.RET = False
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        for ee in self.line:
            if ee[0].rim.T < y: break
            if ee[0].rim.B <= y:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        break
                break

        return self.RET

    def I_draw(self):
        m.bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        blf_size(font_0, F[22], 72)
        for e in self.oo_22:    e.draw_ti()
        blf_size(font_0, F[12], 72)
        for e in self.oo_12:    e.draw_ti()
        blf_size(font_0, F[9], 72)
        for e in self.oo_9:     e.draw_ti()

        for e in self.oo_free:  e.draw_ti()
    #
    #
class MD_TEMP(MD):
    __slots__ = ()
    def init(self):
        w = self.w
        oo = {
            "mess0": BLF(P.color_font, size= F[12], text="The trial version only provides Armature, Array, Bevel and Boolean categories for testing. Please purchase the official version."),
        }
        self.oo = oo

        x   = w.bo["md_info"].L
        y   = w.bo["md_info"].T
        dy  = F[18]
        e = oo["mess0"]
        blf_size(font_0, F[12], 72)
        L = x + F[10]
        B = y - F[22]
        e.xy(L, B)
    def I_draw(self):
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.w.bo["md_info"].R_w() - F[14])
        self.oo["mess0"].set_draw()
        blf_disable(font_0, WORD_WRAP)
    def dxy_upd(self, x, y):
        self.oo["mess0"].dxy(x, y)
    def upd_data(self): pass
    def I_modal_main(self, evt):
        return False
class PICK_OBJ:
    __slots__ = ()
    def init_pick_data(self, tx_object="tx_object", allow_type=None, exc_name=None):
        self.pick_data = {
            "tx_object":    tx_object,
            "allow_type":   allow_type,
            "exc_name":     exc_name,
        }
    def modal_pick_end(self):
        print(f"    cl_md  PICK_OBJ  modal_pick_end")
        m.R_pick_obj_end(bpy.context)
        del m.head_modal[-1]
        m.M.set_mou_ic('DEFAULT')
        m.draw_enable()
        #
    def modal_pick_confirm(self):
        print(f"    cl_md  PICK_OBJ  modal_pick_confirm")
        self.modal_pick_end()
        da = self.pick_data["blf"]
        if da.text != self.w.oj.name:
            o = self.oo[self.pick_data["tx_object"]]
            o.bpy_setter(da.text)
            o.setter()
        #
    def I_modal_pick(self, evt):
        m.redraw()
        if K["pk_cancel0"].true():  self.modal_pick_end()   ;return
        if K["pk_cancel1"].true():  self.modal_pick_end()   ;return
        if K["pk_confirm0"].true(): self.modal_pick_confirm()   ;return
        if K["pk_confirm1"].true(): self.modal_pick_confirm()   ;return

        ob = m.R_pick_obj(bpy.context)
        da = self.pick_data["blf"]
        da.x = evt.mouse_region_x + 25
        da.y = evt.mouse_region_y + 10
        if ob is None:
            da.text = ""
        else:
            da.text = ob.name
            if self.pick_data["allow_type"] is None:
                da.color = P.color_font
            else:
                da.color = P.color_font  if ob.type in self.pick_data["allow_type"] else P.color_font_red

            if self.pick_data["exc_name"] is True:
                if da.text == self.w.oj.name:
                    da.color = P.color_font_red
        #
    def bu_fn_pick(self):
        print(f"    cl_md  PICK_OBJ  bu_fn_pick")
        m.M.set_mou_ic('EYEDROPPER')
        m.draw_disable(self.I_draw_pick)
        m.head_modal.append(self.I_modal_pick)
        m.R_pick_obj_init(bpy.context)
        self.pick_data["blf"] = BLF(P.color_font, "", F[12])
        #
    def I_draw_pick(self):
        self.pick_data["blf"].set_draw()


class NONE:
    __slots__ = 'w', 'U_draw', 'U_modal', 'default_modal'
    def __init__(self, w):
        self.w              = w
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
    def init(self): pass
    def dxy_upd(self, x, y): pass
    def I_draw(self): pass
    def upd_data(self): pass
    def I_modal_main(self, evt): pass
    def R_type(self):   return "None"

class ARMATURE(MD, PICK_OBJ):
    __slots__ = ()
    def init(self):
        w = self.w
        line = [
            [
                BUDR(self, "dr_object", "Object", "object", is_ref_driver=True),
                BUTX(self, "tx_object", "object", FIL_TYPE_EXC(bpy.data.objects, 'ARMATURE')),
                BURE(self, "bu_pick", "⊕", self.bu_fn_pick),
                BURE(self, "bu_x", "✕", self.bu_fn_x, offset_y_key=2.5, free_size=True)],
            [
                BUDR(self, "dr_vertex_group", "Vertex Group", "vertex_group", is_ref_driver=True),
                BUTX(self, "tx_vertex_group", "vertex_group", FIL(None), is_str=True, update_filter="vertex_groups"),
                BURE(self, "bu_x_vg", "✕", self.bu_fn_x_vg, offset_y_key=2.5, free_size=True)],
            [
                BUKF(self, "kf_invert_vertex_group", "invert_vertex_group", False),
                BUDR(self, "dr_invert_vertex_group", "Invert Vertex Group", "invert_vertex_group"),
                BUBL(self, "bl_invert_vertex_group", "invert_vertex_group")],
            [
                BUKF(self, "kf_use_deform_preserve_volume", "use_deform_preserve_volume"),
                BUDR(self, "dr_use_deform_preserve_volume", "Preserve Volume", "use_deform_preserve_volume"),
                BUBL(self, "bl_use_deform_preserve_volume", "use_deform_preserve_volume")],
            [
                BUKF(self, "kf_use_multi_modifier", "use_multi_modifier"),
                BUDR(self, "dr_use_multi_modifier", "Multi Modifier", "use_multi_modifier"),
                BUBL(self, "bl_use_multi_modifier", "use_multi_modifier")],
            [
                BUDR(self, "dr_use_vertex_groups", "Vertex Groups", "use_vertex_groups", is_ref_driver=True),
                BUBL(self, "bl_use_vertex_groups", "use_vertex_groups")],
            [
                BUDR(self, "dr_use_bone_envelopes", "Bone Envelopes", "use_bone_envelopes", is_ref_driver=True),
                BUBL(self, "bl_use_bone_envelopes", "use_bone_envelopes")],
        ]
        self.line = line
        self.get_oo(line)
        oo = self.oo

        oo["ti_blend_to"] = BLFTI(m.P.color_font_darker, "Blend To", F[9])

        self.oo_free = {oo[k] for k in {
            "bu_x",
            "bu_x_vg",
            "ti_blend_to",
        }}
        self.oo_22 = {oo[k] for k in {
            "bl_invert_vertex_group",
            "bl_use_deform_preserve_volume",
            "bl_use_multi_modifier",
            "bl_use_vertex_groups",
            "bl_use_bone_envelopes",
        }}
        self.oo_12 = set()
        self.oo_9 = {oo[k] for k in {
            "dr_object",
            "tx_object",
            "bu_pick",
            "dr_vertex_group",
            "tx_vertex_group",
            "kf_invert_vertex_group",
            "dr_invert_vertex_group",
            "kf_use_deform_preserve_volume",
            "dr_use_deform_preserve_volume",
            "kf_use_multi_modifier",
            "dr_use_multi_modifier",
            "dr_use_vertex_groups",
            "dr_use_bone_envelopes",
        }}

        bu_sets = []
        self.bu_sets = bu_sets
        bo_md_info = w.bo["md_info"]

        x   = bo_md_info.L
        y   = bo_md_info.T
        _2  = F[2]
        _4  = F[4]
        _16 = F[16]
        R   = bo_md_info.R - F[8]
        L   = x + F[101]
        T   = y - F[8]
        B   = T - _16

        blf_size(font_0, F[9], 72)
        L0 = R - F[17]
        oo["bu_pick"].LRBT(L0, R, B, T)
        oo["tx_object"].LRBT(L, L0 - _2*2 - F[17], B, T)
        oo["dr_object"].left_bu_depth(oo["tx_object"])

        T = B - _2
        B = T - _16
        oo["tx_vertex_group"].LRBT(L, oo["tx_object"].rim.R, B, T)
        oo["dr_vertex_group"].left_bu_depth(oo["tx_vertex_group"])

        T = B - _16
        B = T - _16
        L1 = R - _16
        oo["bl_invert_vertex_group"].LRBT(L1, R, B, T)
        oo["dr_invert_vertex_group"].left_bu_depth_with_kf(oo["bl_invert_vertex_group"], oo["kf_invert_vertex_group"])

        T = B - _4
        B = T - _16
        oo["bl_use_deform_preserve_volume"].LRBT(L1, R, B, T)
        oo["dr_use_deform_preserve_volume"].left_bu_depth_with_kf(oo["bl_use_deform_preserve_volume"], oo["kf_use_deform_preserve_volume"])

        T = B - _4
        B = T - _16
        oo["bl_use_multi_modifier"].LRBT(L1, R, B, T)
        oo["dr_use_multi_modifier"].left_bu_depth_with_kf(oo["bl_use_multi_modifier"], oo["kf_use_multi_modifier"])

        T = B - _16
        B = T - _16
        oo["ti_blend_to"].xy(L + F[30], B + F[6])
        oo["bl_use_vertex_groups"].LRBT(L1, R, B, T)
        oo["dr_use_vertex_groups"].left_bu_depth(oo["bl_use_vertex_groups"])

        T = B - _4
        B = T - _16
        oo["bl_use_bone_envelopes"].LRBT(L1, R, B, T)
        oo["dr_use_bone_envelopes"].left_bu_depth(oo["bl_use_bone_envelopes"])

        oo["bu_x"].ti.size = F[15]
        oo["bu_x"].ti.set_size()
        oo["bu_x"].before_bu(oo["bu_pick"], F[17])
        oo["bu_x_vg"].ti.size = F[15]
        oo["bu_x_vg"].next_bu(oo["tx_vertex_group"], F[17])

        bo_md_info.B = B - F[8]
        bo_md_info.upd()
        self.init_pick_data(allow_type={"ARMATURE"})
        self.upd_data()

    def upd_data(self):
        an_data = self.w.oj.animation_data
        act_md  = self.w.act_md
        oo      = self.oo
        obj     = act_md.object

        oo["tx_object"].set_da(""  if obj == None else obj.name)
        oo["tx_vertex_group"].set_da(act_md.vertex_group)
        oo["bl_invert_vertex_group"].set_da(act_md.invert_vertex_group)
        oo["bl_use_deform_preserve_volume"].set_da(act_md.use_deform_preserve_volume)
        oo["bl_use_multi_modifier"].set_da(act_md.use_multi_modifier)
        oo["bl_use_vertex_groups"].set_da(act_md.use_vertex_groups)
        oo["bl_use_bone_envelopes"].set_da(act_md.use_bone_envelopes)

        self.upd_color(an_data, act_md)
        self.upd_ref_color(an_data, act_md, oo, (
            ("dr_object", "object"),
            ("dr_vertex_group", "vertex_group"),
            ("dr_use_vertex_groups", "use_vertex_groups"),
            ("dr_use_bone_envelopes", "use_bone_envelopes"),
        ))

    def bu_fn_x(self):
        print(f"    cl_md  ARMATURE  bu_fn_x")
        self.oo["tx_object"].bpy_setter("")
        self.oo["tx_object"].setter()
        #
    def bu_fn_x_vg(self):
        print(f"    cl_md  ARMATURE  bu_fn_x_vg")
        self.oo["tx_vertex_group"].bpy_setter("")
        self.oo["tx_vertex_group"].setter()

    def R_type(self): return "ARMATURE"
    #
    #
class ARRAY(MD, PICK_OBJ):
    __slots__ = ()
    def init(self):
        w = self.w
        objects = bpy.data.objects
        line = [
            [
                BUKF(self, "kf_fit_type", "fit_type", {0:"FIXED_COUNT", 1:"FIT_LENGTH", 2:"FIT_CURVE"}),
                BUDR(self, "dr_fit_type", "Fit Type :", "fit_type")],
            [
                BU(self, "bu_fixed_count", "Fixed Count", attr="fit_type", value="FIXED_COUNT", offset_y_key=-5.6),
                BU(self, "bu_fit_length", "Fit Length", attr="fit_type", value="FIT_LENGTH", offset_y_key=-5.6),
                BU(self, "bu_fit_curve", "Fit Curve", attr="fit_type", value="FIT_CURVE", offset_y_key=-5.6)],
            [
                BUKF(self, "kf_count", "count"),
                BUDR(self, "dr_count", "Count", "count"),
                BUFL(self, "fl_count", "count", offset_x_key=15, ty="int [1,∞]")],
            [
                BUKF(self, "kf_fit_length", "fit_length"),
                BUDR(self, "dr_fit_length", "Length", "fit_length"),
                BUFL(self, "fl_fit_length", "fit_length", offset_x_key=15, ty="float [0,∞]")],
            [
                BUDR(self, "dr_curve", "Curve", "curve", is_ref_driver=True),
                BUTX(self, "tx_curve", "curve", FIL_TYPE_EXC(objects, "CURVE")),
                BURE(self, "bu_pick_curve", "⊕", self.bu_fn_pick_curve),
                BURE(self, "bu_x_curve", "✕", self.bu_fn_x_curve, offset_y_key=2.5, free_size=True)],
            [
                BUKF(self, "kf_use_relative_offset", "use_relative_offset"),
                BUDR(self, "dr_use_relative_offset", "Relative Offset", "use_relative_offset"),
                BUBL(self, "bl_use_relative_offset", "use_relative_offset")],
            [
                BUKFS(self, "kf_relative_offset_displace0", "relative_offset_displace", 0),
                BUDRS(self, "dr_relative_offset_displace0", "X", "relative_offset_displace", 0),
                BUFLS(self, "fl_relative_offset_displace0", "relative_offset_displace", offset_x_key=15)],
            [
                BUKFS(self, "kf_relative_offset_displace1", "relative_offset_displace", 1),
                BUDRS(self, "dr_relative_offset_displace1", "Y", "relative_offset_displace", 1),
                BUFLS(self, "fl_relative_offset_displace1", "relative_offset_displace", offset_x_key=15)],
            [
                BUKFS(self, "kf_relative_offset_displace2", "relative_offset_displace", 2),
                BUDRS(self, "dr_relative_offset_displace2", "Z", "relative_offset_displace", 2),
                BUFLS(self, "fl_relative_offset_displace2", "relative_offset_displace", offset_x_key=15)],
            [
                BUKF(self, "kf_use_constant_offset", "use_constant_offset"),
                BUDR(self, "dr_use_constant_offset", "Constant Offset", "use_constant_offset"),
                BUBL(self, "bl_use_constant_offset", "use_constant_offset")],
            [
                BUKFS(self, "kf_constant_offset_displace0", "constant_offset_displace", 0),
                BUDRS(self, "dr_constant_offset_displace0", "X", "constant_offset_displace", 0),
                BUFLS(self, "fl_constant_offset_displace0", "constant_offset_displace", offset_x_key=15)],
            [
                BUKFS(self, "kf_constant_offset_displace1", "constant_offset_displace", 1),
                BUDRS(self, "dr_constant_offset_displace1", "Y", "constant_offset_displace", 1),
                BUFLS(self, "fl_constant_offset_displace1", "constant_offset_displace", offset_x_key=15)],
            [
                BUKFS(self, "kf_constant_offset_displace2", "constant_offset_displace", 2),
                BUDRS(self, "dr_constant_offset_displace2", "Z", "constant_offset_displace", 2),
                BUFLS(self, "fl_constant_offset_displace2", "constant_offset_displace", offset_x_key=15)],
            [
                BUKF(self, "kf_use_object_offset", "use_object_offset"),
                BUDR(self, "dr_use_object_offset", "Object Offset", "use_object_offset"),
                BUBL(self, "bl_use_object_offset", "use_object_offset")],
            [
                BUDR(self, "dr_offset_object", "Object", "offset_object", is_ref_driver=True),
                BUTX(self, "tx_offset_object", "offset_object", FIL_TYPE_EXC(objects, exc=(w, "oj"))),
                BURE(self, "bu_pick_offset_object", "⊕", self.bu_fn_pick_offset_object),
                BURE(self, "bu_x_offset_object", "✕", self.bu_fn_x_offset_object, offset_y_key=2.5, free_size=True)],
            [
                BUKF(self, "kf_use_merge_vertices", "use_merge_vertices"),
                BUDR(self, "dr_use_merge_vertices", "Merge", "use_merge_vertices"),
                BUBL(self, "bl_use_merge_vertices", "use_merge_vertices")],
            [
                BUKF(self, "kf_merge_threshold", "merge_threshold"),
                BUDR(self, "dr_merge_threshold", "Distance", "merge_threshold"),
                BUFL(self, "fl_merge_threshold", "merge_threshold", offset_x_key=15, ty="float [0,∞]")],
            [
                BUKF(self, "kf_use_merge_vertices_cap", "use_merge_vertices_cap"),
                BUDR(self, "dr_use_merge_vertices_cap", "First and Last Copies", "use_merge_vertices_cap"),
                BUBL(self, "bl_use_merge_vertices_cap", "use_merge_vertices_cap")],
            [
                BUKF(self, "kf_offset_u", "offset_u"),
                BUDR(self, "dr_offset_u", "Offset U", "offset_u"),
                BUFL(self, "fl_offset_u", "offset_u", offset_x_key=15, ty="float [-1,1]")],
            [
                BUKF(self, "kf_offset_v", "offset_v"),
                BUDR(self, "dr_offset_v", "Offset V", "offset_v"),
                BUFL(self, "fl_offset_v", "offset_v", offset_x_key=15, ty="float [-1,1]")],
            [
                BUDR(self, "dr_start_cap", "Cap Start", "start_cap", is_ref_driver=True),
                BUTX(self, "tx_start_cap", "start_cap", FIL_TYPE_EXC(objects, "MESH", (w, "oj"))),
                BURE(self, "bu_pick_start_cap", "⊕", self.bu_fn_pick_start_cap),
                BURE(self, "bu_x_start_cap", "✕", self.bu_fn_x_start_cap, offset_y_key=2.5, free_size=True)],
            [
                BUDR(self, "dr_end_cap", "Cap End", "end_cap", is_ref_driver=True),
                BUTX(self, "tx_end_cap", "end_cap", FIL_TYPE_EXC(objects, "MESH", (w, "oj"))),
                BURE(self, "bu_pick_end_cap", "⊕", self.bu_fn_pick_end_cap),
                BURE(self, "bu_x_end_cap", "✕", self.bu_fn_x_end_cap, offset_y_key=2.5, free_size=True)],
        ]
        self.line = line
        self.get_oo(line)
        oo = self.oo

        oo["ti_factor"] = BLFTI(m.P.color_font_darker, "Factor", F[9])
        oo["ti_distance"] = BLFTI(m.P.color_font_darker, "Distance", F[9])

        e0 = oo["fl_relative_offset_displace0"]  ;e0.index = 0
        e1 = oo["fl_relative_offset_displace1"]  ;e1.index = 1
        e2 = oo["fl_relative_offset_displace2"]  ;e2.index = 2
        array_relative_offset_displace = [e0, e1, e2]
        e0.array = array_relative_offset_displace
        e1.array = array_relative_offset_displace
        e2.array = array_relative_offset_displace
        e0 = oo["fl_constant_offset_displace0"]  ;e0.index = 0
        e1 = oo["fl_constant_offset_displace1"]  ;e1.index = 1
        e2 = oo["fl_constant_offset_displace2"]  ;e2.index = 2
        array_constant_offset_displace = [e0, e1, e2]
        e0.array = array_constant_offset_displace
        e1.array = array_constant_offset_displace
        e2.array = array_constant_offset_displace

        self.oo_free = {oo[k] for k in {
            "bu_x_curve",
            "ti_factor",
            "ti_distance",
            "bu_x_offset_object",
            "bu_x_start_cap",
            "bu_x_end_cap",
        }}
        self.oo_22 = {oo[k] for k in {
            "bl_use_relative_offset",
            "bl_use_constant_offset",
            "bl_use_object_offset",
            "bl_use_merge_vertices",
            "bl_use_merge_vertices_cap",
        }}
        self.oo_12 = {oo[k] for k in {
            "bu_fixed_count",
            "bu_fit_length",
            "bu_fit_curve",
        }}
        self.oo_9 = {oo[k] for k in {
            "kf_fit_type",
            "dr_fit_type",
            "kf_count",
            "dr_count",
            "fl_count",
            "kf_fit_length",
            "dr_fit_length",
            "fl_fit_length",
            "dr_curve",
            "tx_curve",
            "bu_pick_curve",
            "kf_use_relative_offset",
            "dr_use_relative_offset",
            "kf_relative_offset_displace0",
            "dr_relative_offset_displace0",
            "fl_relative_offset_displace0",
            "kf_relative_offset_displace1",
            "dr_relative_offset_displace1",
            "fl_relative_offset_displace1",
            "kf_relative_offset_displace2",
            "dr_relative_offset_displace2",
            "fl_relative_offset_displace2",
            "kf_use_constant_offset",
            "dr_use_constant_offset",
            "kf_constant_offset_displace0",
            "dr_constant_offset_displace0",
            "fl_constant_offset_displace0",
            "kf_constant_offset_displace1",
            "dr_constant_offset_displace1",
            "fl_constant_offset_displace1",
            "kf_constant_offset_displace2",
            "dr_constant_offset_displace2",
            "fl_constant_offset_displace2",
            "kf_use_object_offset",
            "dr_use_object_offset",
            "dr_offset_object",
            "tx_offset_object",
            "bu_pick_offset_object",
            "kf_use_merge_vertices",
            "dr_use_merge_vertices",
            "kf_merge_threshold",
            "dr_merge_threshold",
            "fl_merge_threshold",
            "kf_use_merge_vertices_cap",
            "dr_use_merge_vertices_cap",
            "kf_offset_u",
            "dr_offset_u",
            "fl_offset_u",
            "kf_offset_v",
            "dr_offset_v",
            "fl_offset_v",
            "dr_start_cap",
            "tx_start_cap",
            "bu_pick_start_cap",
            "dr_end_cap",
            "tx_end_cap",
            "bu_pick_end_cap",
        }}

        self.bu_sets = [BU_SET(line[1], line[0][0].enum)]
        bo_md_info = w.bo["md_info"]

        x   = bo_md_info.L
        y   = bo_md_info.T
        _1  = F[1]
        _2  = F[2]
        _3  = F[3]
        _6  = F[6]
        _12 = F[12]
        _15 = F[15]
        _16 = F[16]
        _17 = F[17]
        _93 = F[93]
        _110 = F[110]
        d = _17
        RR  = bo_md_info.R - F[8]
        LL   = x + F[8]

        R = LL + _93
        T = y - F[22]
        B = T - F[20]
        blf_size(font_0, _12, 72)
        oo["bu_fixed_count"].LRBT(LL, R, B, T)
        L1 = R + _2
        R = R + _93
        oo["bu_fit_length"].LRBT(L1, R, B, T)
        L = R + _2
        oo["bu_fit_curve"].LRBT(L, RR, B, T)
        oo["kf_fit_type"].above_L_with_dr(oo["bu_fixed_count"], oo["dr_fit_type"])

        blf_size(font_0, F[9], 72)
        T = B - _6
        B = T - _16
        R = L1 + _110
        oo["fl_count"].LRBT(L1, R, B, T)
        oo["dr_count"].left_bu_depth_with_kf(oo["fl_count"], oo["kf_count"])
        T = B - _3
        B = T - _16
        oo["fl_fit_length"].LRBT(L1, R, B, T)
        oo["dr_fit_length"].left_bu_depth_with_kf(oo["fl_fit_length"], oo["kf_fit_length"])
        T = B - _3
        B = T - _16
        L0 = RR - _17
        oo["bu_pick_curve"].LRBT(L0, RR, B, T)
        R1 = L0 - _2*2 - _17
        oo["tx_curve"].LRBT(L1, R1, B, T)
        oo["dr_curve"].left_bu_depth(oo["tx_curve"])
        T = B - d
        B = T - _16
        L2 = RR - _16
        oo["bl_use_relative_offset"].LRBT(L2, RR, B, T)
        oo["dr_use_relative_offset"].left_bu_depth_with_kf(oo["bl_use_relative_offset"], oo["kf_use_relative_offset"])
        L = RR - _110
        T = B - _6
        B = T - _16
        oo["fl_relative_offset_displace0"].LRBT(L, RR, B, T)
        oo["dr_relative_offset_displace0"].left_bu_depth_with_kf(oo["fl_relative_offset_displace0"], oo["kf_relative_offset_displace0"])
        oo["ti_factor"].y = B + F[6]
        oo["ti_factor"].align_R_float(oo["kf_relative_offset_displace0"].rim.L - _12)
        T = B - _1
        B = T - _16
        oo["fl_relative_offset_displace1"].LRBT(L, RR, B, T)
        oo["dr_relative_offset_displace1"].left_bu_depth_with_kf(oo["fl_relative_offset_displace1"], oo["kf_relative_offset_displace1"])
        T = B - _1
        B = T - _16
        oo["fl_relative_offset_displace2"].LRBT(L, RR, B, T)
        oo["dr_relative_offset_displace2"].left_bu_depth_with_kf(oo["fl_relative_offset_displace2"], oo["kf_relative_offset_displace2"])
        T = B - d
        B = T - _16
        oo["bl_use_constant_offset"].LRBT(L2, RR, B, T)
        oo["dr_use_constant_offset"].left_bu_depth_with_kf(oo["bl_use_constant_offset"], oo["kf_use_constant_offset"])
        T = B - _6
        B = T - _16
        oo["fl_constant_offset_displace0"].LRBT(L, RR, B, T)
        oo["dr_constant_offset_displace0"].left_bu_depth_with_kf(oo["fl_constant_offset_displace0"], oo["kf_constant_offset_displace0"])
        oo["ti_distance"].y = B + F[6]
        oo["ti_distance"].align_R_float(oo["kf_constant_offset_displace0"].rim.L - _12)
        T = B - _1
        B = T - _16
        oo["fl_constant_offset_displace1"].LRBT(L, RR, B, T)
        oo["dr_constant_offset_displace1"].left_bu_depth_with_kf(oo["fl_constant_offset_displace1"], oo["kf_constant_offset_displace1"])
        T = B - _1
        B = T - _16
        oo["fl_constant_offset_displace2"].LRBT(L, RR, B, T)
        oo["dr_constant_offset_displace2"].left_bu_depth_with_kf(oo["fl_constant_offset_displace2"], oo["kf_constant_offset_displace2"])
        T = B - d
        B = T - _16
        oo["bl_use_object_offset"].LRBT(L2, RR, B, T)
        oo["dr_use_object_offset"].left_bu_depth_with_kf(oo["bl_use_object_offset"], oo["kf_use_object_offset"])
        T = B - _3
        B = T - _16
        oo["bu_pick_offset_object"].LRBT(L0, RR, B, T)
        oo["tx_offset_object"].LRBT(L - F[38], R1, B, T)
        oo["dr_offset_object"].left_bu_depth(oo["tx_offset_object"])
        T = B - d
        B = T - _16
        oo["bl_use_merge_vertices"].LRBT(L2, RR, B, T)
        oo["dr_use_merge_vertices"].left_bu_depth_with_kf(oo["bl_use_merge_vertices"], oo["kf_use_merge_vertices"])
        T = B - _3
        B = T - _16
        oo["fl_merge_threshold"].LRBT(L, RR, B, T)
        oo["dr_merge_threshold"].left_bu_depth_with_kf(oo["fl_merge_threshold"], oo["kf_merge_threshold"])
        T = B - _3
        B = T - _16
        oo["bl_use_merge_vertices_cap"].LRBT(L2, RR, B, T)
        oo["dr_use_merge_vertices_cap"].left_bu_depth_with_kf(oo["bl_use_merge_vertices_cap"], oo["kf_use_merge_vertices_cap"])
        T = B - d
        B = T - _16
        oo["fl_offset_u"].LRBT(L, RR, B, T)
        oo["dr_offset_u"].left_bu_depth_with_kf(oo["fl_offset_u"], oo["kf_offset_u"])
        T = B - _3
        B = T - _16
        oo["fl_offset_v"].LRBT(L, RR, B, T)
        oo["dr_offset_v"].left_bu_depth_with_kf(oo["fl_offset_v"], oo["kf_offset_v"])
        T = B - _3
        B = T - _16
        oo["bu_pick_start_cap"].LRBT(L0, RR, B, T)
        oo["tx_start_cap"].LRBT(L1, R1, B, T)
        oo["dr_start_cap"].left_bu_depth(oo["tx_start_cap"])
        T = B - _3
        B = T - _16
        oo["bu_pick_end_cap"].LRBT(L0, RR, B, T)
        oo["tx_end_cap"].LRBT(L1, R1, B, T)
        oo["dr_end_cap"].left_bu_depth(oo["tx_end_cap"])

        oo["bu_x_curve"].ti.size = _15
        oo["bu_x_curve"].ti.set_size()
        oo["bu_x_curve"].before_bu(oo["bu_pick_curve"], _17)
        oo["bu_x_offset_object"].ti.size = _15
        oo["bu_x_offset_object"].before_bu(oo["bu_pick_offset_object"], _17)
        oo["bu_x_start_cap"].ti.size = _15
        oo["bu_x_start_cap"].before_bu(oo["bu_pick_start_cap"], _17)
        oo["bu_x_end_cap"].ti.size = _15
        oo["bu_x_end_cap"].before_bu(oo["bu_pick_end_cap"], _17)

        bo_md_info.B = B - F[8]
        bo_md_info.upd()
        self.upd_data()

    def upd_data(self):
        an_data = self.w.oj.animation_data
        act_md  = self.w.act_md
        oo      = self.oo

        fit_type = act_md.fit_type
        if fit_type == 'FIT_CURVE':
            oo["fl_count"].disable()
            oo["fl_fit_length"].disable()
            oo["tx_curve"].enable()
        elif fit_type == 'FIT_LENGTH':
            oo["fl_count"].disable()
            oo["fl_fit_length"].enable()
            oo["tx_curve"].disable()
        else:
            oo["fl_count"].enable()
            oo["fl_fit_length"].disable()
            oo["tx_curve"].disable()

        if act_md.use_relative_offset:
            oo["fl_relative_offset_displace0"].enable()
            oo["fl_relative_offset_displace1"].enable()
            oo["fl_relative_offset_displace2"].enable()
            oo["ti_factor"].enable()
        else:
            oo["fl_relative_offset_displace0"].disable()
            oo["fl_relative_offset_displace1"].disable()
            oo["fl_relative_offset_displace2"].disable()
            oo["ti_factor"].disable()

        if act_md.use_constant_offset:
            oo["fl_constant_offset_displace0"].enable()
            oo["fl_constant_offset_displace1"].enable()
            oo["fl_constant_offset_displace2"].enable()
            oo["ti_distance"].enable()
        else:
            oo["fl_constant_offset_displace0"].disable()
            oo["fl_constant_offset_displace1"].disable()
            oo["fl_constant_offset_displace2"].disable()
            oo["ti_distance"].disable()

        if act_md.use_object_offset:
            oo["tx_offset_object"].enable()
        else:
            oo["tx_offset_object"].disable()

        if act_md.use_merge_vertices:
            oo["fl_merge_threshold"].enable()
            oo["bl_use_merge_vertices_cap"].enable()
        else:
            oo["fl_merge_threshold"].disable()
            oo["bl_use_merge_vertices_cap"].disable()

        oo["fl_count"].set_da(act_md.count)
        oo["fl_fit_length"].set_da(act_md.fit_length)
        oo["tx_curve"].set_da(""  if act_md.curve == None else act_md.curve.name)
        oo["bl_use_relative_offset"].set_da(act_md.use_relative_offset)
        e = act_md.relative_offset_displace
        oo["fl_relative_offset_displace0"].set_da(e[0])
        oo["fl_relative_offset_displace1"].set_da(e[1])
        oo["fl_relative_offset_displace2"].set_da(e[2])
        oo["bl_use_constant_offset"].set_da(act_md.use_constant_offset)
        e = act_md.constant_offset_displace
        oo["fl_constant_offset_displace0"].set_da(e[0])
        oo["fl_constant_offset_displace1"].set_da(e[1])
        oo["fl_constant_offset_displace2"].set_da(e[2])
        oo["bl_use_object_offset"].set_da(act_md.use_object_offset)
        oo["tx_offset_object"].set_da(""  if act_md.offset_object == None else act_md.offset_object.name)
        oo["bl_use_merge_vertices"].set_da(act_md.use_merge_vertices)
        oo["fl_merge_threshold"].set_da(act_md.merge_threshold)
        oo["bl_use_merge_vertices_cap"].set_da(act_md.use_merge_vertices_cap)
        oo["fl_offset_u"].set_da(act_md.offset_u)
        oo["fl_offset_v"].set_da(act_md.offset_v)
        oo["tx_start_cap"].set_da(""  if act_md.start_cap == None else act_md.start_cap.name)
        oo["tx_end_cap"].set_da(""  if act_md.end_cap == None else act_md.end_cap.name)

        self.upd_color(an_data, act_md)

    def bu_fn_x_curve(self):
        print(f"    cl_md  ARRAY  bu_fn_x_curve")
        self.oo["tx_curve"].bpy_setter("")
        self.oo["tx_curve"].setter()
        #
    def bu_fn_x_offset_object(self):
        print(f"    cl_md  ARRAY  bu_fn_x_offset_object")
        self.oo["tx_offset_object"].bpy_setter("")
        self.oo["tx_offset_object"].setter()
        #
    def bu_fn_x_start_cap(self):
        print(f"    cl_md  ARRAY  bu_fn_x_start_cap")
        self.oo["tx_start_cap"].bpy_setter("")
        self.oo["tx_start_cap"].setter()
        #
    def bu_fn_x_end_cap(self):
        print(f"    cl_md  ARRAY  bu_fn_x_end_cap")
        self.oo["tx_end_cap"].bpy_setter("")
        self.oo["tx_end_cap"].setter()
        #
    def bu_fn_pick_curve(self):
        print(f"    cl_md  ARRAY  bu_fn_pick_curve")
        self.init_pick_data("tx_curve", allow_type={"CURVE"})
        super().bu_fn_pick()
        #
    def bu_fn_pick_offset_object(self):
        print(f"    cl_md  ARRAY  bu_fn_pick_offset_object")
        self.init_pick_data("tx_offset_object", exc_name=True)
        super().bu_fn_pick()
        #
    def bu_fn_pick_start_cap(self):
        print(f"    cl_md  ARRAY  bu_fn_pick_start_cap")
        self.init_pick_data("tx_start_cap", allow_type={"MESH"}, exc_name=True)
        super().bu_fn_pick()
        #
    def bu_fn_pick_end_cap(self):
        print(f"    cl_md  ARRAY  bu_fn_pick_end_cap")
        self.init_pick_data("tx_end_cap", allow_type={"MESH"}, exc_name=True)
        super().bu_fn_pick()
        #

    def R_type(self): return "ARRAY"
    #
    #
class BEVEL(MD):
    __slots__ = 'oo_alt'
    def init(self):
        w = self.w
        line = [
            [
                BUKF(self, "kf_affect", "affect", {0:"VERTICES", 1:"EDGES"}),
                BUDR(self, "dr_affect", "Affect :", "affect")],
            [
                BU(
                    self, "bu_vertices", "Vertices",
                    offset_y_key=-5.6, attr="affect", value="VERTICES"),
                BU(
                    self, "bu_edges", "Edges",
                    offset_y_key=-5.6, attr="affect", value="EDGES")],
            [
                BUKF(self, "kf_offset_type", "offset_type", {0:"OFFSET", 1:"WIDTH", 2:"DEPTH", 3:"PERCENT", 4:"ABSOLUTE"}),
                BUDR(self, "dr_offset_type", "Width Type :", "offset_type")],
            [
                BU(self, "bu_offset", "Offset", attr="offset_type", value="OFFSET"),
                BU(self, "bu_width", "Width", attr="offset_type", value="WIDTH"),
                BU(self, "bu_depth", "Depth", attr="offset_type", value="DEPTH"),
                BU(self, "bu_percent", "Percent", attr="offset_type", value="PERCENT"),
                BU(self, "bu_absolute", "Absolute", attr="offset_type", value="ABSOLUTE")],
            [
                BUKF(self, "kf_width", "width"),
                BUDR(self, "dr_width", "Amount", "width"),
                BUFL(self, "fl_width", "width", offset_x_key=18, ty="float [0,∞]")],
            [
                BUKF(self, "kf_segments", "segments"),
                BUDR(self, "dr_segments", "Segments", "segments"),
                BUFL(self, "fl_segments", "segments", offset_x_key=18, ty="int [1,1000]")],
            [
                BUKF(self, "kf_limit_method", "limit_method", {0:"NONE", 8:"ANGLE", 16:"WEIGHT", 32:"VGROUP"}),
                BUDR(self, "dr_limit_method", "Limit Method :", "limit_method")],
            [
                BU(self, "bu_none", "None", attr="limit_method", value="NONE"),
                BU(self, "bu_angle", "Angle", attr="limit_method", value="ANGLE"),
                BU(self, "bu_weight", "Weight", attr="limit_method", value="WEIGHT"),
                BU(self, "bu_vertex_group", "Vertex Group", attr="limit_method", value="VGROUP")],
            [
                BUKF(self, "kf_angle_limit", "angle_limit"),
                BUDR(self, "dr_angle_limit", "Angle", "angle_limit"),
                BUFL(self, "fl_angle_limit", "angle_limit", offset_x_key=18, ty="float [0,π]"),
                BUFD(self, "fd_angle_limit", "angle_limit", offset_x_key=12, ty="float [0,180]")],
            [
                BUKF(self, "kf_profile_type", "profile_type", {0:"SUPERELLIPSE", 1:"CUSTOM"}),
                BUDR(self, "dr_profile_type", "Profile Type :", "profile_type")],
            [
                BU(self, "bu_superellipse", "Superellipse", attr="profile_type", value="SUPERELLIPSE"),
                BU(self, "bu_custom", "Custom", attr="profile_type", value="CUSTOM")],
            [
                BUKF(self, "kf_profile", "profile"),
                BUDR(self, "dr_profile", "Shape", "profile"),
                BUFL(self, "fl_profile", "profile", offset_x_key=18, ty="float [0,1]"),
                BURE(self, "bu_profile", "Edit Profile", self.bu_fn_profile)],
            [
                BUKF(self, "kf_miter_outer", "miter_outer", {0:"MITER_SHARP", 1:"MITER_PATCH", 2:"MITER_ARC"}),
                BUDR(self, "dr_miter_outer", "Miter Outer", "miter_outer"),
                BU(self, "bu_sharp", "Sharp", attr="miter_outer", value="MITER_SHARP"),
                BU(self, "bu_patch", "Patch", attr="miter_outer", value="MITER_PATCH"),
                BU(self, "bu_arc", "Arc", attr="miter_outer", value="MITER_ARC")],
            [
                BUKF(self, "kf_miter_inner", "miter_inner", {0:"MITER_SHARP", 2:"MITER_ARC"}),
                BUDR(self, "dr_miter_inner", "Miter Inner", "miter_inner"),
                BU(self, "bu_sharp2", "Sharp", attr="miter_inner", value="MITER_SHARP"),
                BU(self, "bu_arc2", "Arc", attr="miter_inner", value="MITER_ARC")],
            [
                BUKF(self, "kf_spread", "spread"),
                BUDR(self, "dr_spread", "Spread", "spread"),
                BUFL(self, "fl_spread", "spread", offset_x_key=18, offset_y_key=4.9, ty="float [0,∞]")],
            [
                BUKF(self, "kf_vmesh_method", "vmesh_method", {0:"ADJ", 1:"CUTOFF"}),
                BUDR(self, "dr_vmesh_method", "Intersections :", "vmesh_method"),
                BUKF(self, "kf_use_clamp_overlap", "use_clamp_overlap"),
                BUDR(self, "dr_use_clamp_overlap", "Clamp Overlap", "use_clamp_overlap"),
                BUBL(self, "bl_use_clamp_overlap", "use_clamp_overlap")],
            [
                BU(self, "bu_grid_fill", "Grid Fill", attr="vmesh_method", value="ADJ"),
                BU(self, "bu_cutoff", "Cutoff", attr="vmesh_method", value="CUTOFF")],
            [
                BUKF(self, "kf_face_strength_mode", "face_strength_mode", {0:"FSTR_NONE", 1:"FSTR_NEW", 2:"FSTR_AFFECTED", 3:"FSTR_ALL"}),
                BUDR(self, "dr_face_strength_mode", "Face Strength :", "face_strength_mode")],
            [
                BU(self, "bu_none2", "None", attr="face_strength_mode", value="FSTR_NONE"),
                BU(self, "bu_new", "New", attr="face_strength_mode", value="FSTR_NEW"),
                BU(self, "bu_affected", "Affected", attr="face_strength_mode", value="FSTR_AFFECTED"),
                BU(self, "bu_all", "All", attr="face_strength_mode", value="FSTR_ALL")],
            [
                BUKF(self, "kf_material", "material"),
                BUDR(self, "dr_material", "Material Index", "material"),
                BUFL(self, "fl_material", "material", offset_x_key=18, offset_y_key=4.9, ty="int [-1,32767]")],
            [
                BUKF(self, "kf_mark_seam", "mark_seam"),
                BUDR(self, "dr_mark_seam", "Mark Seam", "mark_seam"),
                BUBL(self, "bl_mark_seam", "mark_seam"),
                BUKF(self, "kf_mark_sharp", "mark_sharp"),
                BUDR(self, "dr_mark_sharp", "Mark Sharp", "mark_sharp"),
                BUBL(self, "bl_mark_sharp", "mark_sharp")],
            [
                BUKF(self, "kf_harden_normals", "harden_normals"),
                BUDR(self, "dr_harden_normals", "Harden Normal", "harden_normals"),
                BUBL(self, "bl_harden_normals", "harden_normals")],
        ]
        self.line = line
        self.get_oo(line)
        oo_alt = {}
        self.oo_alt = oo_alt
        oo  = self.oo

        oo["kf_loop_slide"] = BUKF(self, "kf_loop_slide", "loop_slide")
        oo["dr_loop_slide"] = BUDR(self, "dr_loop_slide", "Loop Slide", "loop_slide")
        oo["bl_loop_slide"] = BUBL(self, "bl_loop_slide", "loop_slide")

        oo_alt["tx_vertex_group"] = BUTX(self, "tx_vertex_group", "vertex_group", FIL(None), is_str=True, update_filter="vertex_groups")

        oo_alt["fd_angle_limit"] = oo["fd_angle_limit"]
        oo_alt["fl_angle_limit"] = oo["fl_angle_limit"]

        oo_alt["bl_invert_vertex_group"] = BUBL(self, "bl_invert_vertex_group", "invert_vertex_group")
        oo_alt["kf_invert_vertex_group"] = BUKF(self, "kf_invert_vertex_group", "invert_vertex_group", False)
        oo_alt["dr_invert_vertex_group"] = BUDR(self, "dr_invert_vertex_group", "Invert", "invert_vertex_group")
        oo_alt["bu_x"] = BURE(self, "bu_x", "✕", self.bu_fn_x, offset_y_key=2.5, free_size=True)

        self.oo_free = set()
        self.oo_22 = {oo[k] for k in {
            "bl_use_clamp_overlap",
            "bl_loop_slide",
            "bl_mark_seam",
            "bl_mark_sharp",
            "bl_harden_normals",
        }}
        self.oo_12 = {oo[k] for k in {
            "bu_vertices",
            "bu_edges",
        }}
        self.oo_9 = {oo[k] for k in {
            "kf_affect",
            "dr_affect",
            "kf_offset_type",
            "dr_offset_type",
            "bu_offset",
            "bu_width",
            "bu_depth",
            "bu_percent",
            "bu_absolute",
            "kf_width",
            "dr_width",
            "fl_width",
            "kf_segments",
            "dr_segments",
            "fl_segments",
            "kf_limit_method",
            "dr_limit_method",
            "bu_none",
            "bu_angle",
            "bu_weight",
            "bu_vertex_group",
            "kf_angle_limit",
            "dr_angle_limit",
            "fl_angle_limit",
            "fd_angle_limit",
            "kf_profile_type",
            "dr_profile_type",
            "bu_superellipse",
            "bu_custom",
            "kf_profile",
            "dr_profile",
            "fl_profile",
            "bu_profile",
            "kf_miter_outer",
            "dr_miter_outer",
            "bu_sharp",
            "bu_patch",
            "bu_arc",
            "kf_miter_inner",
            "dr_miter_inner",
            "bu_sharp2",
            "bu_arc2",
            "kf_spread",
            "dr_spread",
            "fl_spread",
            "kf_vmesh_method",
            "dr_vmesh_method",
            "bu_grid_fill",
            "bu_cutoff",
            "kf_use_clamp_overlap",
            "dr_use_clamp_overlap",
            "kf_loop_slide",
            "dr_loop_slide",
            "kf_face_strength_mode",
            "dr_face_strength_mode",
            "bu_none2",
            "bu_new",
            "bu_affected",
            "bu_all",
            "kf_material",
            "dr_material",
            "fl_material",
            "kf_mark_seam",
            "dr_mark_seam",
            "kf_mark_sharp",
            "dr_mark_sharp",
            "kf_harden_normals",
            "dr_harden_normals",
        }}

        bu_sets = [BU_SET(line[r], line[r-1][0].enum) for r in (1,3,7,10)]
        self.bu_sets = bu_sets
        e = line[12]
        bu_sets.append(BU_SET([e[2], e[3], e[4]], e[0].enum))
        e = line[13]
        bu_sets.append(BU_SET([e[2], e[3]], e[0].enum))
        e = line[16]
        bu_sets.append(BU_SET([e[0], e[1]], line[15][0].enum))
        e = line[18]
        bu_sets.append(BU_SET([e[0], e[1], e[2], e[3]], line[17][0].enum))

        bo_md_info = w.bo["md_info"]
        x   = bo_md_info.L
        y   = bo_md_info.T
        _3  = F[3]
        _76 = F[76]
        _93 = F[93]
        R   = bo_md_info.R - F[8]
        L   = x + F[8]

        blf_size(font_0, F[12], 72)
        oo["bu_vertices"].LTwh(L, y - F[22], _93, F[20])
        oo["bu_edges"].next_bu(oo["bu_vertices"], _93)

        blf_size(font_0, F[9], 72)
        oo["kf_affect"].above_L_with_dr(oo["bu_vertices"], oo["dr_affect"])

        bu_w = round(55 * P.scale[0])
        bu_h = F[16]
        oo["bu_offset"].LTwh(L, oo["bu_vertices"].rim.B - F[31], bu_w, bu_h)
        oo["bu_width"].next_bu(oo["bu_offset"], bu_w)
        oo["bu_depth"].next_bu(oo["bu_width"], bu_w)
        oo["bu_percent"].next_bu(oo["bu_depth"], bu_w)
        oo["bu_absolute"].next_bu(oo["bu_percent"], R - oo["bu_percent"].rim.R - F[2])

        oo["kf_offset_type"].above_L_with_dr(oo["bu_offset"], oo["dr_offset_type"])

        T = oo["bu_offset"].rim.B - _3
        B = T - bu_h
        oo["fl_width"].LRBT(oo["bu_depth"].rim.L, oo["bu_percent"].rim.R, B, T)
        oo["dr_width"].left_bu_depth_with_kf(oo["fl_width"], oo["kf_width"])

        T = B - _3
        B = T - bu_h
        oo["fl_segments"].LRBT(oo["bu_depth"].rim.L, oo["bu_percent"].rim.R, B, T)
        oo["dr_segments"].left_bu_depth_with_kf(oo["fl_segments"], oo["kf_segments"])

        oo["bu_none"].LTwh(L, oo["fl_segments"].rim.B - F[31], bu_w, bu_h)
        oo["bu_angle"].next_bu(oo["bu_none"], bu_w)
        oo["bu_weight"].next_bu(oo["bu_angle"], bu_w)
        oo_VG = oo["bu_vertex_group"]
        oo_VG.next_bu(oo["bu_weight"], _76)

        oo["kf_limit_method"].above_L_with_dr(oo["bu_none"], oo["dr_limit_method"])

        T = oo["bu_none"].rim.B - _3
        B = T - bu_h
        oo["fl_angle_limit"].LRBT(oo["bu_angle"].rim.L, oo["bu_weight"].rim.R, B, T)
        oo["fd_angle_limit"].LRBT(oo_VG.rim.L, oo_VG.rim.R, B, T)
        oo["dr_angle_limit"].left_bu_depth_with_kf(oo["fl_angle_limit"], oo["kf_angle_limit"])

        T = oo["dr_angle_limit"].rim.B - F[31]
        B = T - bu_h
        oo["bu_superellipse"].LRBT(L, L + _76, B, T)
        oo["bu_custom"].next_bu(oo["bu_superellipse"], _76)

        oo["kf_profile_type"].above_L_with_dr(oo["bu_superellipse"], oo["dr_profile_type"])

        T = oo["bu_superellipse"].rim.B - _3
        B = T - bu_h
        L_cus = oo["bu_custom"].rim.L
        oo["fl_profile"].LRBT(L_cus, L_cus + oo["fl_width"].rim.R_w(), B, T)
        oo["dr_profile"].left_bu_depth_with_kf(oo["fl_profile"], oo["kf_profile"])
        oo["bu_profile"].LRBT(R - F[61], R, B, T)

        oo["bu_sharp"].LTwh(L_cus, oo["bu_profile"].rim.B - F[31], bu_w, bu_h)
        oo["bu_patch"].next_bu(oo["bu_sharp"], bu_w)
        oo["bu_arc"].next_bu(oo["bu_patch"], bu_w)
        oo["dr_miter_outer"].left_bu_depth_with_kf(oo["bu_sharp"], oo["kf_miter_outer"])

        oo["bu_sharp2"].LTwh(L_cus, oo["bu_sharp"].rim.B - _3, bu_w, bu_h)
        oo["bu_arc2"].next_bu(oo["bu_sharp2"], bu_w)
        oo["dr_miter_inner"].left_bu_depth_with_kf(oo["bu_sharp2"], oo["kf_miter_inner"])

        T = oo["bu_arc2"].rim.B - _3
        oo["fl_spread"].LRBT(L_cus, oo["bu_arc2"].rim.R, T - bu_h, T)
        oo["dr_spread"].left_bu_depth_with_kf(oo["fl_spread"], oo["kf_spread"])

        oo["bu_grid_fill"].LTwh(L, oo["fl_spread"].rim.B - F[31], bu_w, bu_h)
        oo["bu_cutoff"].next_bu(oo["bu_grid_fill"], bu_w)

        oo["kf_vmesh_method"].above_L_with_dr(oo["bu_grid_fill"], oo["dr_vmesh_method"])

        rim = oo["kf_vmesh_method"].rim
        L0 = R - bu_h
        oo["bl_use_clamp_overlap"].LRBT(L0, R, rim.B, rim.T)
        oo["dr_use_clamp_overlap"].left_bu_depth_with_kf(oo["bl_use_clamp_overlap"], oo["kf_use_clamp_overlap"])

        T = oo["bl_use_clamp_overlap"].rim.B - _3
        oo["bl_loop_slide"].LRBT(L0, R, T - bu_h, T)
        oo["dr_loop_slide"].left_bu_depth_with_kf(oo["bl_loop_slide"], oo["kf_loop_slide"])

        oo["bu_none2"].LTwh(L, oo["bu_grid_fill"].rim.B - F[31], bu_w, bu_h)
        oo["bu_new"].next_bu(oo["bu_none2"], bu_w)
        oo["bu_affected"].next_bu(oo["bu_new"], bu_w)
        oo["bu_all"].next_bu(oo["bu_affected"], bu_w)

        oo["kf_face_strength_mode"].above_L_with_dr(oo["bu_none2"], oo["dr_face_strength_mode"])

        T = oo["bu_all"].rim.B - _3
        oo["fl_material"].LRBT(oo["bu_affected"].rim.L, oo["bu_all"].rim.R, T - bu_h, T)
        oo["dr_material"].left_bu_depth_with_kf(oo["fl_material"], oo["kf_material"])

        T = oo["fl_material"].rim.B - _3
        B = T - bu_h
        oo["bl_mark_sharp"].LRBT(L0, R, B, T)
        oo["dr_mark_sharp"].left_bu_depth_with_kf(oo["bl_mark_sharp"], oo["kf_mark_sharp"])

        L = oo["fl_material"].rim.L
        oo["bl_mark_seam"].LRBT(L, L + bu_h, B, T)
        oo["dr_mark_seam"].left_bu_depth_with_kf(oo["bl_mark_seam"], oo["kf_mark_seam"])

        T = B - _3
        B = T - bu_h
        oo["bl_harden_normals"].LRBT(L0, R, B, T)
        oo["dr_harden_normals"].left_bu_depth_with_kf(oo["bl_harden_normals"], oo["kf_harden_normals"])

        oo_alt["bu_x"].ti.size = F[15]

        bo_md_info.B = B - F[8]
        bo_md_info.upd()
        self.upd_data()

    def upd_data(self):
        an_data = self.w.oj.animation_data
        act_md  = self.w.act_md
        oo      = self.oo

        b       = oo["fl_width"]
        if act_md.offset_type == "PERCENT":
            attr    = "width_pct"
            if b.attr != attr:
                b.attr = attr
                oo["kf_width"].attr = attr
                oo["dr_width"].attr = attr
                oo["dr_width"].ti.text = "Width (%)"
                blf_size(font_0, F[9], 72)
                oo["dr_width"].left_bu_depth_with_kf(b, oo["kf_width"])

            b.set_da(act_md.width_pct)
        else:
            attr    = "width"
            if b.attr != attr:
                b.attr = attr
                oo["kf_width"].attr = attr
                oo["dr_width"].attr = attr
                oo["dr_width"].ti.text = "Amount"
                blf_size(font_0, F[9], 72)
                oo["dr_width"].left_bu_depth_with_kf(b, oo["kf_width"])

            b.set_da(act_md.width)

        b = oo["fl_angle_limit"]
        if act_md.limit_method == "VGROUP":
            if b.attr != "vertex_group":
                oo_alt = self.oo_alt
                blf_size(font_0, F[9], 72)

                kf_angle, dr_angle = self.change_kfdr_attr("angle_limit", "vertex_group", "Vertex Group")
                dr_angle.is_ref_driver = True
                B = kf_angle.rim.B
                T = kf_angle.rim.T
                kf_angle.LBT_with_dr(oo["kf_affect"].ti.x, B, T, dr_angle)
                self.line[8].remove(kf_angle)
                self.oo_9.remove(kf_angle)

                e2 = oo_alt["tx_vertex_group"]
                self.replace_oo_9(oo, b, e2, "fl_angle_limit", 8, 1)
                e2.LRBT(oo["dr_angle_limit"].rim.R + F[6], oo["bu_weight"].rim.R, B, T)

                R = oo["bu_absolute"].rim.R
                e = oo_alt["bl_invert_vertex_group"]
                self.replace_oo_9_22(oo, oo["fd_angle_limit"], e, "fd_angle_limit", 8, 2)
                e.LRBT(R - F[16], R, B, T)

                e_kf = oo_alt["kf_invert_vertex_group"]
                e_dr = oo_alt["dr_invert_vertex_group"]
                self.add_oo_9(oo, e_kf, "kf_invert_vertex_group", 8)
                self.add_oo_9(oo, e_dr, "dr_invert_vertex_group", 8)
                e_dr.left_bu_depth_with_kf(e, e_kf)

                e = oo_alt["bu_x"]
                self.add_oo_free(oo, e, "bu_x", 8)
                e.ti.set_size()
                e.next_bu(e2, F[17])

            oo["fl_angle_limit"].set_da(act_md.vertex_group)
            oo["fd_angle_limit"].set_da(act_md.invert_vertex_group)
        else:
            if b.attr != "angle_limit":
                oo_alt = self.oo_alt
                blf_size(font_0, F[9], 72)

                kf_angle, dr_angle = self.change_kfdr_attr("vertex_group", "angle_limit", "Angle")
                dr_angle.is_ref_driver = False
                B = kf_angle.rim.B
                T = kf_angle.rim.T

                self.del_oo_free(oo, oo_alt["bu_x"], "bu_x", 8, -1)
                e_kf = oo_alt["kf_invert_vertex_group"]
                e_dr = oo_alt["dr_invert_vertex_group"]
                self.del_oo_9(oo, e_dr, "dr_invert_vertex_group", 8, -1)
                self.del_oo_9(oo, e_kf, "kf_invert_vertex_group", 8, -1)

                e2 = oo_alt["fl_angle_limit"]
                self.replace_oo_9(oo, oo_alt["tx_vertex_group"], e2, "fl_angle_limit", 8, 1)
                self.oo_9.add(kf_angle)
                self.line[8].insert(0, kf_angle)

                e2.LRBT(oo["bu_angle"].rim.L, oo["bu_weight"].rim.R, B, T)
                dr_angle.left_bu_depth_with_kf(e2, kf_angle)

                e = oo_alt["fd_angle_limit"]
                self.replace_oo_22_9(oo, oo_alt["bl_invert_vertex_group"], e, "fd_angle_limit", 8, 3)
                e.LRBT(oo["bu_vertex_group"].rim.L, oo["bu_vertex_group"].rim.R, B, T)

            if act_md.limit_method == "ANGLE":
                oo["fl_angle_limit"].enable()
                oo["fd_angle_limit"].enable()
            else:
                oo["fl_angle_limit"].disable()
                oo["fd_angle_limit"].disable()

            oo["fl_angle_limit"].set_da(act_md.angle_limit)
            oo["fd_angle_limit"].set_da(act_md.angle_limit)

        if act_md.profile_type == "CUSTOM":
            oo["fl_profile"].disable()
            oo["bu_profile"].enable()
        else:
            oo["fl_profile"].enable()
            oo["bu_profile"].disable()

        if act_md.affect == "VERTICES":
            if oo["bu_sharp"].is_enable:
                oo["bu_sharp"].disable()
                oo["bu_patch"].disable()
                oo["bu_arc"].disable()
                oo["bu_sharp2"].disable()
                oo["bu_arc2"].disable()
                oo["fl_spread"].disable()
                oo["bu_grid_fill"].disable()
                oo["bu_cutoff"].disable()
                oo["bl_loop_slide"].disable()
                oo["bl_mark_seam"].disable()
                oo["bl_mark_sharp"].disable()
        else:
            if oo["bu_sharp"].is_enable is False:
                oo["bu_sharp"].enable()
                oo["bu_patch"].enable()
                oo["bu_arc"].enable()
                oo["bu_sharp2"].enable()
                oo["bu_arc2"].enable()
                oo["bu_grid_fill"].enable()
                oo["bu_cutoff"].enable()
                oo["bl_loop_slide"].enable()
                oo["bl_mark_seam"].enable()
                oo["bl_mark_sharp"].enable()
            if act_md.miter_inner == "MITER_ARC":
                oo["fl_spread"].enable()
            else:
                oo["fl_spread"].disable()

        oo["fl_segments"].set_da(act_md.segments)
        oo["fl_profile"].set_da(act_md.profile)
        oo["fl_spread"].set_da(act_md.spread)
        oo["bl_use_clamp_overlap"].set_da(act_md.use_clamp_overlap)
        oo["bl_loop_slide"].set_da(act_md.loop_slide)
        oo["fl_material"].set_da(act_md.material)
        oo["bl_mark_seam"].set_da(act_md.mark_seam)
        oo["bl_mark_sharp"].set_da(act_md.mark_sharp)
        oo["bl_harden_normals"].set_da(act_md.harden_normals)

        self.upd_color(an_data, act_md)

    def I_modal_main(self, evt):
        self.RET = False
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        oo = self.oo

        if oo["kf_loop_slide"].rim.B <= y <= oo["kf_loop_slide"].rim.T:
            if oo["kf_loop_slide"].rim.L <= x <= oo["kf_loop_slide"].rim.R:
                oo["kf_loop_slide"].inside(evt)
                return self.RET
            if oo["dr_loop_slide"].rim.L <= x <= oo["dr_loop_slide"].rim.R:
                oo["dr_loop_slide"].inside(evt)
                return self.RET
            if oo["bl_loop_slide"].rim.L <= x <= oo["bl_loop_slide"].rim.R:
                oo["bl_loop_slide"].inside(evt)
                return self.RET

        for ee in self.line:
            if ee[0].rim.T < y: break
            if ee[0].rim.B <= y:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        break
                break

        return self.RET

    def bu_fn_x(self):
        try:
            print(f"    cl_md  bu_fn_x")
            self.w.act_md.vertex_group = ""
            m.undo_str = '[Modifier Editor] md.vertex_group = ""'
            m.undo_push()
        except: pass
    def bu_fn_profile(self):
        print(f"    cl_md  bu_fn_profile")
        VPP_BEVEL_PROFILE.md = self.w.act_md
        bpy.ops.wm.vpp_bevel_profile("INVOKE_DEFAULT")

    def R_type(self): return "BEVEL"
    #
    #
class BOOLEAN(MD, PICK_OBJ):
    __slots__ = ()
    def init(self):
        w = self.w
        line = [
            [
                BUKF(self, "kf_operation", "operation", {0:"INTERSECT", 1:"UNION", 2:"DIFFERENCE"}),
                BUDR(self, "dr_operation", "Operation :", "operation")],
            [
                BU(
                    self, "bu_intersect", "Intersect",
                    offset_y_key=-5.6, attr="operation", value="INTERSECT"),
                BU(
                    self, "bu_union", "Union",
                    offset_y_key=-5.6, attr="operation", value="UNION"),
                BU(
                    self, "bu_difference", "Difference",
                    offset_y_key=-5.6, attr="operation", value="DIFFERENCE")],
            [
                BUKF(self, "kf_operand_type", "operand_type", {2:"OBJECT", 4:"COLLECTION"}),
                BUDR(self, "dr_operand_type", "Operand Type :", "operand_type")],
            [
                BU(self, "bu_object", "Object", attr="operand_type", value='OBJECT'),
                BUTX(self, "tx_object", "object", FIL_TYPE_EXC(bpy.data.objects, "MESH", (w, "oj")))],
            [
                BU(self, "bu_collection", "Collection", attr="operand_type", value="COLLECTION"),
                BUTX(self, "tx_collection", "collection", FIL(bpy.data.collections))],
            [
                BUKF(self, "kf_solver", "solver", {0:"FAST", 1:"EXACT"}),
                BUDR(self, "dr_solver", "Solver", "solver"),
                BU(self, "bu_fast", "Fast", attr="solver", value="FAST"),
                BU(self, "bu_exact", "Exact", attr="solver", value="EXACT")],
            [
                BUKF(self, "kf_overlap", "double_threshold"),
                BUDR(self, "dr_overlap", "Overlap Threshold", "double_threshold"),
                BUFL(self, "fl_overlap", "double_threshold", ty="float [0,1]"),
                BUKF(self, "kf_self", "use_self", False), BUDR(self, "dr_self", "Self", "use_self"),
                BUBL(self, "bl_self", "use_self")],
            [
                BUKF(self, "kf_hole", "use_hole_tolerant", False),
                BUDR(self, "dr_hole", "Hole Tolerant", "use_hole_tolerant"),
                BUBL(self, "bl_hole", "use_hole_tolerant")],
        ]
        self.line = line
        self.get_oo(line)
        oo  = self.oo
        oo["bu_pick"] = BURE(self, "bu_pick", "⊕", self.bu_fn_pick)
        oo["bu_x"] = BURE(self, "bu_x", "✕", self.bu_fn_x, offset_y_key=2.5, free_size=True)

        self.oo_22 = {oo[k] for k in {
            "bl_self",
            "bl_hole"
        }}
        self.oo_12 = {oo[k] for k in {
            "bu_intersect",
            "bu_union",
            "bu_difference",
        }}
        self.oo_9 = {oo[k] for k in {
            "kf_operation",
            "dr_operation",
            "kf_operand_type",
            "dr_operand_type",
            "bu_object",
            "tx_object",
            "bu_collection",
            "tx_collection",
            "kf_solver",
            "dr_solver",
            "bu_fast",
            "bu_exact",
            "kf_overlap",
            "dr_overlap",
            "fl_overlap",
            "kf_self",
            "dr_self",
            "kf_hole",
            "dr_hole",
            "bu_pick",
        }}

        self.bu_sets = [BU_SET(line[1], line[0][0].enum)]
        bo_md_info = w.bo["md_info"]

        x   = bo_md_info.L
        y   = bo_md_info.T
        L   = x + F[8]
        R   = L + F[93]
        T   = y - F[22]
        B   = T - F[20]
        _16 = F[16]

        blf_size(font_0, F[12], 72)
        oo["bu_intersect"].LRBT(L, R, B, T)
        L = R + F[2]
        R = L + F[93]
        oo["bu_union"].LRBT(L, R, B, T)
        L = R + F[2]
        R = bo_md_info.R - F[8]
        oo["bu_difference"].LRBT(L, R, B, T)

        blf_size(font_0, F[9], 72)
        oo["kf_operation"].above_L_with_dr(oo["bu_intersect"], oo["dr_operation"])

        oo["bu_object"].LTwh(oo["bu_intersect"].rim.L, oo["bu_intersect"].rim.B - F[31], F[76], _16)
        oo["bu_collection"].below_bu(oo["bu_object"], _16)
        L = oo["bu_object"].rim.R + F[2]
        oo["tx_object"].LRBT(L, R, oo["bu_object"].rim.B, oo["bu_object"].rim.T)
        oo["tx_collection"].LRBT(L, R, oo["bu_collection"].rim.B, oo["bu_collection"].rim.T)

        oo["bu_object"].ti_offset_x_set(oo["bu_collection"].offset_x + F[1])
        oo["kf_operand_type"].above_L_with_dr(oo["bu_object"], oo["dr_operand_type"])

        B = oo["bu_object"].rim.T + F[2]
        T = B + _16
        oo["bu_pick"].LRBT(R - F[17], R, B, T)

        T_fast = oo["bu_collection"].rim.B - F[13]
        B_fast = T_fast - _16
        T_overlap = B_fast - F[3]
        B_overlap = T_overlap - _16
        oo["kf_overlap"].LBT_with_dr(oo["bu_object"].rim.L, B_overlap, T_overlap, oo["dr_overlap"])
        oo["fl_overlap"].right_dr(oo["dr_overlap"], F[46] + F[46] + F[2], 11)
        oo["bu_fast"].LRBT(oo["fl_overlap"].rim.L, oo["fl_overlap"].rim.L + F[46], B_fast, T_fast)
        oo["bu_exact"].next_bu(oo["bu_fast"], F[46])
        oo["dr_solver"].left_bu_depth_with_kf(oo["bu_fast"], oo["kf_solver"], 11)

        oo["bl_self"].LRBT(R - _16, R, oo["fl_overlap"].rim.B, oo["fl_overlap"].rim.T)
        oo["dr_self"].left_bu_depth_with_kf(oo["bl_self"], oo["kf_self"])
        T = oo["bl_self"].rim.B - F[4]
        B = T - _16
        oo["bl_hole"].LRBT(oo["bl_self"].rim.L, R, B, T)
        oo["dr_hole"].left_bu_depth_with_kf(oo["bl_hole"], oo["kf_hole"])

        oo["bu_x"].ti.size = F[15]
        oo["bu_x"].ti.set_size()
        oo["bu_x"].before_bu(oo["bu_pick"], F[17])

        bo_md_info.B = B - F[8]
        bo_md_info.upd()
        self.init_pick_data(allow_type={"MESH"}, exc_name=True)
        self.upd_data()

    def upd_data(self):
        an_data = self.w.oj.animation_data
        act_md  = self.w.act_md
        oo      = self.oo
        obj     = act_md.object
        coll    = act_md.collection

        if act_md.operand_type == 'OBJECT':
            oo["bu_object"].on()        ;oo["bu_collection"].off()
            oo["tx_object"].enable()    ;oo["tx_collection"].disable()

            if act_md.solver == 'FAST':
                oo["bu_fast"].on()          ;oo["bu_exact"].off()
                oo["fl_overlap"].enable()   ;oo["bl_self"].disable()    ;oo["bl_hole"].disable()
            elif act_md.solver == 'EXACT':
                oo["bu_fast"].off()         ;oo["bu_exact"].on()
                oo["fl_overlap"].disable()  ;oo["bl_self"].enable()     ;oo["bl_hole"].enable()
            else:
                oo["bu_fast"].off()         ;oo["bu_exact"].off()
                oo["fl_overlap"].enable()   ;oo["bl_self"].disable()    ;oo["bl_hole"].disable()
        elif act_md.operand_type == 'COLLECTION':
            oo["bu_object"].off()       ;oo["bu_collection"].on()
            oo["tx_object"].disable()   ;oo["tx_collection"].enable()
            if coll != None:
                md_coll_obs = coll.objects
                if md_coll_obs:
                    is_mesh = True
                    for e in md_coll_obs:
                        if e.type != "MESH":    is_mesh = False ; break
                    oo["tx_collection"].da.color = P.color_font  if is_mesh else P.color_font_red
                else: oo["tx_collection"].da.color = P.color_font_red

            if act_md.solver == 'FAST':
                oo["bu_fast"].on()          ;oo["bu_exact"].off()
                oo["fl_overlap"].enable()   ;oo["bl_self"].disable()    ;oo["bl_hole"].disable()
            elif act_md.solver == 'EXACT':
                oo["bu_fast"].off()         ;oo["bu_exact"].on()
                oo["fl_overlap"].disable()  ;oo["bl_self"].disable()    ;oo["bl_hole"].enable()
            else:
                oo["bu_fast"].off()         ;oo["bu_exact"].off()
                oo["fl_overlap"].enable()   ;oo["bl_self"].disable()    ;oo["bl_hole"].disable()
        else:
            oo["bu_object"].off()       ;oo["bu_collection"].off()
            oo["tx_object"].disable()   ;oo["tx_collection"].disable()

        oo["tx_object"].set_da(""  if obj == None else obj.name)
        oo["tx_collection"].set_da(""  if coll == None else coll.name)
        oo["fl_overlap"].set_da(act_md.double_threshold)
        oo["bl_self"].set_da(act_md.use_self)
        oo["bl_hole"].set_da(act_md.use_hole_tolerant)

        self.upd_color(an_data, act_md)
        self.upd_ref_color(an_data, act_md, oo, (
            ("bu_object", "object"),
        ))

    def I_modal_main(self, evt):
        self.RET = False
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        for ee in self.line:
            if ee[0].rim.B <= y <= ee[0].rim.T:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        break
                break

        if self.oo["bu_pick"].rim.in_BT(evt):
            if self.oo["bu_pick"].rim.in_LR(evt):   self.oo["bu_pick"].inside(evt)
            elif self.oo["bu_x"].rim.in_LR(evt):    self.oo["bu_x"].inside(evt)
        return self.RET

    def I_draw(self):
        m.bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        blf_size(font_0, F[22], 72)
        for e in self.oo_22:    e.draw_ti()
        blf_size(font_0, F[12], 72)
        for e in self.oo_12:    e.draw_ti()
        blf_size(font_0, F[9], 72)
        for e in self.oo_9:     e.draw_ti()

        self.oo["bu_x"].draw_ti()

    def bu_fn_pick(self):
        print(f"    cl_md  BOOLEAN  bu_fn_pick")
        if self.w.act_md.operand_type == 'OBJECT':
            super().bu_fn_pick()
            return

        act_collection = bpy.context.view_layer.active_layer_collection.name
        if act_collection != 'Master Collection':
            self.oo["tx_collection"].bpy_setter(act_collection)
            self.oo["tx_collection"].setter()
        #
    def bu_fn_x(self):
        print(f"    cl_md  BOOLEAN  bu_fn_x")
        if self.w.act_md.operand_type == 'OBJECT':
            self.oo["tx_object"].bpy_setter("")
            self.oo["tx_object"].setter()
        else:
            self.oo["tx_collection"].bpy_setter("")
            self.oo["tx_collection"].setter()

    def R_type(self): return "BOOLEAN"
    #
    #
class BUILD(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "BUILD"
    #
    #
class CAST(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "CAST"
    #
    #
class CLOTH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "CLOTH"
    #
    #
class COLLISION(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "COLLISION"
    #
    #
class CORRECTIVE_SMOOTH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "CORRECTIVE_SMOOTH"
    #
    #
class CURVE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "CURVE"
    #
    #
class DATA_TRANSFER(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "DATA_TRANSFER"
    #
    #
class DECIMATE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "DECIMATE"
    #
    #
class DISPLACE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "DISPLACE"
    #
    #
class DYNAMIC_PAINT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "DYNAMIC_PAINT"
    #
    #
class EDGE_SPLIT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "EDGE_SPLIT"
    #
    #
class EXPLODE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "EXPLODE"
    #
    #
class FLUID(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "FLUID"
    #
    #
class HOOK(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "HOOK"
    #
    #
class LAPLACIANDEFORM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "LAPLACIANDEFORM"
    #
    #
class LAPLACIANSMOOTH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "LAPLACIANSMOOTH"
    #
    #
class LATTICE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "LATTICE"
    #
    #
class MASK(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MASK"
    #
    #
class MESH_CACHE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MESH_CACHE"
    #
    #
class MESH_DEFORM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MESH_DEFORM"
    #
    #
class MESH_SEQUENCE_CACHE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MESH_SEQUENCE_CACHE"
    #
    #
class MESH_TO_VOLUME(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MESH_TO_VOLUME"
    #
    #
class MIRROR(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MIRROR"
    #
    #
class MULTIRES(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MULTIRES"
    #
    #
class NODES(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "NODES"
    #
    #
class NORMAL_EDIT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "NORMAL_EDIT"
    #
    #
class OCEAN(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "OCEAN"
    #
    #
class PARTICLE_INSTANCE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "PARTICLE_INSTANCE"
    #
    #
class PARTICLE_SYSTEM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "PARTICLE_SYSTEM"
    #
    #
class REMESH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "REMESH"
    #
    #
class SCREW(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SCREW"
    #
    #
class SHRINKWRAP(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SHRINKWRAP"
    #
    #
class SIMPLE_DEFORM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SIMPLE_DEFORM"
    #
    #
class SKIN(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SKIN"
    #
    #
class SMOOTH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SMOOTH"
    #
    #
class SOFT_BODY(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SOFT_BODY"
    #
    #
class SOLIDIFY(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SOLIDIFY"
    #
    #
class SUBSURF(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SUBSURF"
    #
    #
class SURFACE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SURFACE"
    #
    #
class SURFACE_DEFORM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SURFACE_DEFORM"
    #
    #
class TRIANGULATE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "TRIANGULATE"
    #
    #
class UV_PROJECT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "UV_PROJECT"
    #
    #
class UV_WARP(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "UV_WARP"
    #
    #
class VERTEX_WEIGHT_EDIT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VERTEX_WEIGHT_EDIT"
    #
    #
class VERTEX_WEIGHT_MIX(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VERTEX_WEIGHT_MIX"
    #
    #
class VERTEX_WEIGHT_PROXIMITY(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VERTEX_WEIGHT_PROXIMITY"
    #
    #
class VOLUME_DISPLACE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VOLUME_DISPLACE"
    #
    #
class VOLUME_TO_MESH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VOLUME_TO_MESH"
    #
    #
class WARP(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WARP"
    #
    #
class WAVE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WAVE"
    #
    #
class WEIGHTED_NORMAL(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WEIGHTED_NORMAL"
    #
    #
class WELD(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WELD"
    #
    #
class WIREFRAME(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WIREFRAME"
    #
    #