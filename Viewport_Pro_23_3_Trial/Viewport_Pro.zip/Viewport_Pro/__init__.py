bl_info = {
    "name" : "Viewport Pro",
    "author" : "Iiispace",
    "version" : (23, 3),
    "blender" : (2, 92, 0),
    "location" : "View3d > Tool",
    "warning" : "",
    "description" : "This is the first experimental version of this Add-on, it may be unstable and is for testing only.",
    "wiki_url" : "",
    "category" : "3D View",
}

if "bpy" in locals():
    if 'm' in locals():

        print(f'    {bl_info["name"]}: detected reload event.')
        import importlib

import bpy
from os.path import realpath, dirname
from blf import load as blf_load
from blf import unload as blf_unload
from bpy.utils import register_class, unregister_class
from bpy.app.handlers import persistent
from bpy import types
from bpy.path import abspath

from . import(
    prefs, npanel, m, tex, local_undo,
    bu_block, bu, dd, filt, ic, ll, rm, tb, win_cls, win_mess, win, det
)

from . ED_md import mo, bu_md, cl_md, menu_batch, mods, oj_data
from . ED_dr import dr_ed, dr_data, dr_val, dr_vars
from . ED_setting import setting_ed, setting_data
from . ED_mesh import mesh_ed, mesh_data, mesh_block

from . bpy_ops import *

import time
sec = 0
def empty_fn():pass

is_subscribe = False
font_dir = "\\".join((dirname(realpath(__file__)), "Fonts"))
path_font_0 = abspath("\\".join((font_dir, "droidsans.ttf")))
path_font_1 = abspath("\\".join((font_dir, "bmonofont-i18n.ttf")))

@persistent
def bl_new_file_after(dummy):
    print("-- new file after --")
    context = bpy.context

    font_0 = blf_load(path_font_0)
    font_1 = blf_load(path_font_1)
    m.font_0 = font_0
    m.font_1 = font_1

    m.get_P()
    m.get_F()
    m.get_K()
    m.get_win_protect_fn()
    m.undo_evt = local_undo.undo_evt = local_undo.UNDO_EVT()

    m.bus_unit_system()
    m.bus_unit_length()

    P = m.P
    F = m.F
    K = m.K
    N = m.N
    NF = m.NF
    BOX = m.BOX
    BLF = m.BLF
    RECT = m.RECT
    BOX_C = m.BOX_C
    shader2D = m.shader2D
    BIND = m.BIND
    UNFL = m.UNFL

    local_undo.P = P
    local_undo.undo_steps = context.preferences.edit.undo_steps
    context.scene["undo_ind"] = 0

# IMPORT
    dr_data.P = P
    dr_data.F = F
    dr_data.N = N
    dr_data.font_0 = font_0

    dr_ed.P = P
    dr_ed.F = F
    dr_ed.K = K
    dr_ed.N = N
    dr_ed.font_0 = font_0

    dr_val.P = P
    dr_val.F = F
    dr_val.N = N
    dr_val.font_0 = font_0

    dr_vars.P = P
    dr_vars.F = F
    dr_vars.K = K
    dr_vars.N = N
    dr_vars.BIND = BIND
    dr_vars.UNFL = UNFL
    dr_vars.font_0 = font_0

    bu_md.P = P
    bu_md.F = F
    bu_md.K = K
    bu_md.N = N
    bu_md.BOX = BOX
    bu_md.BLF = BLF
    bu_md.RECT = RECT
    bu_md.font_0 = font_0

    cl_md.P = P
    cl_md.F = F
    cl_md.K = K
    cl_md.BLF = BLF
    cl_md.font_0 = font_0

    menu_batch.P = P
    menu_batch.F = F
    menu_batch.K = K
    menu_batch.BOX = BOX
    menu_batch.BLF = BLF
    menu_batch.font_0 = font_0
    menu_batch.font_1 = font_1

    mo.P = P
    mo.F = F
    mo.K = K
    mo.BOX = BOX
    mo.BLF = BLF
    mo.font_0 = font_0

    mods.P = P
    mods.F = F
    mods.K = K
    mods.BIND = BIND
    mods.UNFL = UNFL
    mods.font_0 = font_0
    mods.font_1 = font_1

    oj_data.P = P
    oj_data.F = F
    oj_data.N = N
    oj_data.font_0 = font_0

    setting_data.P = P
    setting_data.F = F
    setting_data.K = K
    setting_data.BOX = BOX
    setting_data.BLF = BLF
    setting_data.font_0 = font_0

    setting_ed.P = P
    setting_ed.F = F
    setting_ed.K = K
    setting_ed.BOX = BOX
    setting_ed.BLF = BLF
    setting_ed.font_0 = font_0

    bu_block.P = P
    bu_block.F = F
    bu_block.K = K
    bu_block.BOX = BOX
    bu_block.BLF = BLF
    bu_block.BOX_C = BOX_C
    bu_block.font_0 = font_0

    bu.P = P
    bu.F = F
    bu.K = K
    bu.N = N
    bu.NF = NF
    bu.BOX = BOX
    bu.BLF = BLF
    bu.RECT = RECT
    bu.font_0 = font_0

    dd.P = P
    dd.F = F
    dd.K = K
    dd.N = N
    dd.BOX = BOX
    dd.BLF = BLF
    dd.shader2D = shader2D
    dd.BIND = BIND
    dd.UNFL = UNFL
    dd.font_0 = font_0

    filt.P = P

    ic.P = P
    ic.F = F
    ic.shader2D = shader2D
    ic.BIND = BIND
    ic.UNFL = UNFL

    ll.P = P
    ll.F = F
    ll.K = K
    ll.N = N
    ll.BOX = BOX
    ll.BLF = BLF
    ll.font_0 = font_0

    rm.P = P
    rm.F = F
    rm.K = K
    rm.BOX = BOX
    rm.BLF = BLF
    rm.font_0 = font_0

    tb.P = P
    tb.F = F
    tb.K = K
    tb.N = N
    tb.BOX = BOX
    tb.BLF = BLF
    tb.shader2D = shader2D
    tb.BIND = BIND
    tb.UNFL = UNFL
    tb.font_0 = font_0

    tex.P = P
    tex.F = F
    tex.K = K
    tex.N = N
    tex.BOX = BOX
    tex.BLF = BLF
    tex.font_0 = font_0

    win_cls.P = P
    win_cls.F = F
    win_cls.K = K

    win_mess.P = P
    win_mess.F = F
    win_mess.K = K
    win_mess.N = N
    win_mess.BOX = BOX
    win_mess.BLF = BLF
    win_mess.font_0 = font_0
    win_mess.font_1 = font_1

    win.P = P
    win.F = F
    win.K = K
    win.N = N
    win.BOX = BOX
    win.BLF = BLF
    win.font_1 = font_1

    mesh_ed.P = P
    mesh_ed.F = F
    mesh_ed.K = K
    mesh_ed.N = N
    mesh_ed.font_0 = font_0

    mesh_data.P = P
    mesh_data.F = F
    mesh_data.font_0 = font_0

    mesh_block.P = P
    mesh_block.F = F
    mesh_block.K = K
    mesh_block.BOX = BOX
    mesh_block.BLF = BLF
    mesh_block.font_0 = font_0

    det.P = P
    det.F = F
    det.K = K
    det.N = N
    det.BOX = BOX
    det.BLF = BLF
    det.font_0 = font_0

    link_mds    = bpy.data.link_mds
    objs        = bpy.data.objects
    for obj in objs:
        if obj.animation_data:
            for fc in obj.animation_data.drivers:
                path = fc.data_path
                if path[: 12] == '["modifiers[':    link_mds[fc] = obj

    subscribe()
    upd_link_data()
    #
    #
@persistent
def bl_new_file_before(dummy):
    print("-- new file before --")
    if m.admin is not None:     m.admin.modal_end()
    unsubscribe()
    blf_unload(path_font_0)
    blf_unload(path_font_1)
m.bl_new_file_after = bl_new_file_after


is_upding = False
@persistent
def upd_link_data():
    global is_upding
    if is_upding:   return
    is_upding = True
    print("[[[[ update_link_data ]]]]")
    link_mds = bpy.data.link_mds
    for fc, obj in link_mds.copy().items(): T_upd_md(fc, obj)

    is_upding = False

def T_upd_md(fc, obj):
    try:
        dr          = fc.driver
        path        = fc.data_path
        i           = path.rfind(".")
        attr        = path[i + 1 : -2]
        md_name     = path[12 : i - 1]
        mds         = obj.modifiers
        v           = dr.variables[0]
        tar         = v.targets[0]

        setattr(mds[md_name], attr, getattr(tar.id.modifiers[v.name], attr))
        return False
    except: return True
def T_del_fc(obj, fc):
    try:    obj.animation_data.drivers.remove(fc)
    except: pass


classes = (
    prefs.ModEd_Prefs,
    npanel.ModEd_Panel,
    npanel.ModEd_Pref_Panel,
    m.M,
    m.PREF,
    mo.OP_MO,
    tex.OP_TEX,
    dr_ed.OP_DR,
    setting_ed.OP_SETTING,
    mesh_ed.OP_MESH,
    VPP_FACTORY,
    VPP_BEVEL_PROFILE,
    VPP_R_PREF,
)
subscribe_attr = (
    (types.BooleanModifier, 'object'),
    (types.BevelModifier, 'vertex_group'),
    (types.ArmatureModifier, 'object'),
    (types.ArmatureModifier, 'vertex_group'),
    (types.ArmatureModifier, 'use_vertex_groups'),
    (types.ArmatureModifier, 'use_bone_envelopes'),
    (types.ArrayModifier, 'curve'),
    (types.ArrayModifier, 'end_cap'),
    (types.ArrayModifier, 'offset_object'),
    (types.ArrayModifier, 'start_cap'),
)
m.subscribe_attr = subscribe_attr
m.upd_link_data = upd_link_data

msgbus_attrs = (
    ((bpy.types.UnitSettings, "system"), m.bus_unit_system),
    ((bpy.types.UnitSettings, "length_unit"), m.bus_unit_length),
    ((bpy.types.UnitSettings, "scale_length"), m.bus_unit_length),
)
m.msgbus_attrs = msgbus_attrs

def subscribe():
    global is_subscribe
    if is_subscribe is True: return
    is_subscribe = True
    subscribe_rna = bpy.msgbus.subscribe_rna

    for attr in subscribe_attr:
        subscribe_rna(
            key     = attr,
            owner   = attr,
            args    = (),
            notify  = upd_link_data)

    for attr, e in msgbus_attrs:
        subscribe_rna(
            key     = attr,
            owner   = attr,
            args    = (),
            notify  = e)
    print("-- subscribe --")
    #
def unsubscribe():
    global is_subscribe
    if is_subscribe is False: return
    is_subscribe = False
    bpy.data.link_mds.clear()
    clear_by_owner = bpy.msgbus.clear_by_owner

    for attr in subscribe_attr:     clear_by_owner(attr)
    for attr, e in msgbus_attrs:    clear_by_owner(attr)

    print("-- unsubscribe --")
    #

def register():
    print("-- reg --")
    if m.is_publish is False:
        from . import debug_draw
        for r in range(6): register_class(getattr(debug_draw, f"DEBUG_fn_{r}"))

    for cls in classes: register_class(cls)

    bpy.app.handlers.load_post.append(bl_new_file_after)
    bpy.app.handlers.load_pre.append(bl_new_file_before)
    bpy.app.handlers.undo_post.append(local_undo.after_undo)
    bpy.app.handlers.redo_post.append(local_undo.after_redo)
    types.BlendData.link_mds = {}
    types.WorkSpace.tm_pref = bpy.props.PointerProperty(type=m.PREF)

    reg_keymap()
    #
def unregister():
    print("-- unreg --")
    for cls in classes: unregister_class(cls)

    bpy.app.handlers.load_post.remove(bl_new_file_after)
    bpy.app.handlers.load_pre.remove(bl_new_file_before)
    bpy.app.handlers.undo_post.remove(local_undo.after_undo)
    bpy.app.handlers.redo_post.remove(local_undo.after_redo)

    bl_new_file_before(None)
    unreg_keymap()
    m.P = None

addon_keymaps = []
def reg_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        m.cls_ops_kms = [
            mo.OP_MO,
            dr_ed.OP_DR,
            mesh_ed.OP_MESH,
            setting_ed.OP_SETTING,
        ]
        r = 3
        for cls in m.cls_ops_kms:
            km = wm.keyconfigs.addon.keymaps.new(name='Screen')
            kmi = km.keymap_items.new(cls.bl_idname, type=f'F1{r}', value='PRESS')
            addon_keymaps.append((km, kmi))
            r += 1
def unreg_keymap():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

if __name__ == "__main__":  register()