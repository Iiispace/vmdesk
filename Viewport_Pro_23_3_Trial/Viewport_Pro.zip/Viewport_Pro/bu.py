import bpy
from blf import size as blf_size
from blf import color as blf_color
from bpy.app.timers import register as thread_reg
from bpy.app.timers import unregister as thread_unreg
from mathutils import Vector

from . import m, dd
from . rm import RM
from . det import DETAILS
from . calc import calc_vec

P = None
F = None
K = None
N = None
NF = None
BOX = None
BLF = None
RECT = None
font_0 = None

class ENUM_RIM:
    __slots__ = 'w', 'L', 'R', 'B', 'T', 'oo',
    def __init__(self, w, oo):
        self.w = w
        self.oo = oo
    def draw(self): pass
    def bind_draw(self): pass
    def inbox(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        if y > self.T:  return False
        if y < self.B:  return False
        for e in self.oo:
            if e.rim.in_LR_x(x):
                self.w.tm_focus = e
                return True
        return False
    def inbox_xy(self, x, y):
        if y > self.T:  return False
        if y < self.B:  return False
        for e in self.oo:
            if e.rim.in_LR_x(x):
                self.w.tm_focus = e
                return True
        return False

class BU_FAKE:
    __slots__ = 'rim'
    def __init__(self):
        self.rim    = m.BOX_FAKE()
    def draw_rim(self): pass
    def draw_bg(self): pass
    def draw_ti(self): pass

class BU:
    __slots__ = (
        'w',
        'name',
        'fn',
        'rim',
        'bg',
        'ti',
        'on',
        'off',
        'fo',
        'fo_ti',
        'unfo_ti',
        'draw_ti',
        'offset_y_key',
        'color_ti',
        'color_ti_fo',
        'is_on',
        'is_enable',
        'base_evt',
        'offset_x',
        'offset_y',
        'key_end',
        'attr',
        'is_fin',
        'is_RET',
        'details',
    )
# BU slots END
    def __init__(self, w, name, ti,
            fn              = None,
            offset_y_key    = 4.5,
            free_size       = False,
            base_evt        = None,
            is_fin          = False,
            attr            = None,
            details         = None,
        ):
        self.w      = w
        self.name   = name
        self.fn     = N  if fn is None else fn

        self.rim    = BOX()
        self.bg     = BOX(P.color_bu_1_off)
        self.ti     = BLF(P.color_font, ti)
        self.on     = self.I_on
        self.off    = N

        self.fo         = self.I_fo
        self.fo_ti      = self.I_fo_ti
        self.unfo_ti    = N
        self.draw_ti    = self.I_draw_ti_free  if free_size else self.I_draw_ti

        self.offset_y_key   = offset_y_key
        self.color_ti       = P.color_font
        self.color_ti_fo    = P.color_font_fo
        self.is_on          = False
        self.is_enable      = True
        self.base_evt       = NF  if base_evt is None else base_evt
        self.is_fin         = is_fin
        self.attr           = attr
        self.details        = details

    def disable(self):
        print("TODO BU disable")

    def LTwh(self, L, T, w, h): # blf_size
        rim = self.rim
        bg  = self.bg
        ti  = self.ti
        rim.LTwh(L, T, w, h)
        rim.upd()

        if bg.color == P.color_bu_1_on:
            bg.LRBT(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        else: bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])

        bg.upd()
        ti.set_x_by_bo_float(bg)
        self.offset_x   = ti.x - bg.L
        self.offset_y   = F[self.offset_y_key]
        ti.y            = bg.B + self.offset_y
    def LRBT(self, L, R, B, T): # blf_size
        rim = self.rim
        bg  = self.bg
        ti  = self.ti
        _1  = F[1]
        rim.LRBT_upd(L, R, B, T)

        if bg.color == P.color_bu_1_on:
            bg.LRBT(rim.L, rim.R - _1, rim.B + _1, rim.T)
        else: bg.LRBT(rim.L + _1, rim.R, rim.B, rim.T - _1)

        bg.upd()
        ti.set_x_by_bo_float(bg)
        self.offset_x   = ti.x - bg.L
        self.offset_y   = F[self.offset_y_key]
        ti.y            = bg.B + self.offset_y
    def LRBT_align_L(self, L, R, B, T, dx):
        rim = self.rim
        bg  = self.bg
        ti  = self.ti
        _1  = F[1]
        rim.LRBT(L, R, B, T)
        rim.upd()

        if bg.color == P.color_bu_1_on:
            bg.LRBT(rim.L, rim.R - _1, rim.B + _1, rim.T)
        else: bg.LRBT(rim.L + _1, rim.R, rim.B, rim.T - _1)

        bg.upd()
        ti.x            = bg.L + dx
        self.offset_x   = ti.x - bg.L
        self.offset_y   = F[self.offset_y_key]
        ti.y            = bg.B + self.offset_y

    def next_bu(self, b, wi):
        rim = b.rim
        L = rim.R + F[2]
        self.LRBT(L, L + wi, rim.B, rim.T)
    def before_bu(self, b, wi):
        rim = b.rim
        R = rim.L - F[2]
        self.LRBT(R - wi, R, rim.B, rim.T)
    def next_ti(self, e, wi, d = 4.5):
        rim = e.rim
        L = rim.R + F[d]
        self.LRBT(L, L + wi, rim.B, rim.T)

    def below_bu(self, b, h):
        rim = b.rim
        T = rim.B - F[2]
        self.LRBT(rim.L, rim.R, T - h, T)

    def ti_align_L(self, e):
        self.offset_x = e.offset_x
        self.ti.x = self.bg.L + self.offset_x

    def ti_offset_x_set(self, x):
        self.offset_x = x
        self.ti.x = self.bg.L + self.offset_x

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bg.dxy_upd(x, y)
        self.ti.dxy(x, y)

    def I_on(self):
        rim         = self.rim
        bg          = self.bg
        bg.color    = P.color_bu_1_on

        bg.LRBT(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = N
        self.off    = self.I_off
        self.fo     = self.I_fo
        self.is_on  = True
    def I_off(self):
        rim         = self.rim
        bg          = self.bg
        bg.color    = P.color_bu_1_off
        bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = self.I_on
        self.off    = N
        self.fo     = self.I_fo
        self.is_on  = False
    def I_fo(self):
        rim         = self.rim
        bg          = self.bg
        bg.color    = P.color_bu_1_fo
        bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = self.I_on
        self.off    = self.I_off
        self.fo     = N
    def I_fo_ti(self):
        self.fo_ti      = N
        self.unfo_ti    = self.I_unfo_ti
        self.ti.color   = self.color_ti_fo
    def I_unfo_ti(self):
        self.fo_ti      = self.I_fo_ti
        self.unfo_ti    = N
        self.ti.color   = self.color_ti

    def draw_rim(self):     self.rim.draw()
    def draw_bg(self):      self.bg.bind_draw()
    def I_draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()
    def I_draw_ti_free(self):
        self.ti.set_draw()

    def inside(self, evt):
        if self.is_on:  self.fo_ti()
        else:           self.fo()
        m.redraw()
        self.w.U_modal = self.I_modal_fo
        self.I_modal_fo(evt)

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            if self.is_on:  self.on()
            else:           self.off()

            self.unfo_ti()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if K["sel_fast0"].true():
            if self.is_on:
                self.fo()
                self.unfo_ti()
                self.is_on = False
            else:
                self.on()
                self.fo_ti()
                self.is_on = True

            m.redraw()
            self.w.U_modal = self.I_modal_press
            self.fn()
            self.key_end = K["sel0"]
            self.key_end.true()
            self.w.RET = True
            return True
        if K["sel_fast1"].true():
            if self.is_on:
                self.fo()
                self.unfo_ti()
                self.is_on = False
            else:
                self.on()
                self.fo_ti()
                self.is_on = True

            m.redraw()
            self.w.U_modal = self.I_modal_press
            self.fn()
            self.key_end = K["sel1"]
            self.key_end.true()
            self.w.RET = True
            return True
        return self.base_evt(evt)
    def I_modal_press(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            if self.is_on:  self.on()
            else:           self.off()

            self.unfo_ti()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if self.key_end.true():  self.w.U_modal = self.I_modal_fo
        return False
class BURE(BU):
    __slots__ = ()
    def inside(self, evt):
        if self.is_enable:
            self.fo()
            m.redraw()
            self.w.U_modal = self.I_modal_fo
            self.I_modal_fo(evt)

    def disable(self):
        print(f"    bu  BURE(BU)  disable")
        self.I_off()
        self.w.U_modal  = self.w.default_modal
        self.bg.color   = P.color_bu_1_ignore
        self.ti.color   = P.color_font_ignore
        self.is_enable  = False
        m.redraw()
    def enable(self):
        print(f"    bu  BURE(BU)  enable")
        self.I_off()
        self.ti.color   = P.color_font
        self.is_enable  = True
        m.redraw()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if K["sel_fast0"].true():
            self.on()
            m.redraw()
            self.w.U_modal = self.I_modal_press
            self.key_end = K["sel0"]
            self.key_end.true()
            self.w.RET = True
            return True
        if K["sel_fast1"].true():
            self.on()
            m.redraw()
            self.w.U_modal = self.I_modal_press
            self.key_end = K["sel0"]
            self.key_end.true()
            self.w.RET = True
            return True
        return self.base_evt(evt)
    def I_modal_press(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if self.key_end.true():
            self.w.U_modal = self.I_modal_fo
            self.fo()
            m.redraw()

            if self.is_fin: self.w.fin()
            self.fn()
            return True
class BURE_FA(BURE):
    __slots__ = (
        'U_add_auto_timer',
        'U_kill_auto_timer',
        'auto_timer',
        'timer_speed',
    )
    def __init__(self,
            w,
            name,
            ti,
            fn,
            offset_y_key    = 4.5,
            free_size       = False,
            auto            = True,
            base_evt        = None,
            is_RET          = True,
        ):
        self.w      = w
        self.name   = name
        self.fn     = fn
        self.rim    = BOX()
        self.bg     = BOX(P.color_bu_1_off)
        self.ti     = BLF(P.color_font, ti)

        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.fo_ti      = self.I_fo_ti
        self.unfo_ti    = N
        self.draw_ti    = self.I_draw_ti_free  if free_size else self.I_draw_ti

        self.offset_y_key   = offset_y_key
        self.color_ti       = P.color_font
        self.color_ti_fo    = P.color_font_fo
        self.is_on          = False
        self.is_enable      = True
        self.is_RET         = is_RET

        if P.bu_auto_time == 0 or auto is not True:
            self.U_add_auto_timer   = N
            self.U_kill_auto_timer  = N
        else:
            self.U_add_auto_timer   = self.I_add_auto_timer
            self.U_kill_auto_timer  = self.I_kill_auto_timer
            self.auto_timer         = self.thread_timer
            self.timer_speed        = P.bu_auto_speed

        self.base_evt = NF  if base_evt is None else base_evt

    def I_add_auto_timer(self):
        print(f"    bu  BURE(BU)  I_add_auto_timer")
        thread_reg(self.auto_timer, first_interval=P.bu_auto_time)
    def I_kill_auto_timer(self):
        print(f"    bu  BURE(BU)  I_kill_auto_timer")
        thread_unreg(self.auto_timer)
    def thread_timer(self):
        self.fn()
        m.redraw()
        return self.timer_speed

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if K["sel_fast0"].true():
            self.on()
            m.redraw()
            self.w.U_modal = self.I_modal_press
            self.fn()
            self.U_add_auto_timer()
            if self.is_RET: self.w.RET = True
            return True
        if K["sel_fast1"].true():
            self.on()
            m.redraw()
            self.w.U_modal = self.I_modal_press
            self.fn()
            self.U_add_auto_timer()
            if self.is_RET: self.w.RET = True
            return True
        return self.base_evt(evt)

    def I_modal_press(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False or evt.value == "RELEASE":
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            self.U_kill_auto_timer()
            return False
class BU_ENUM:
    __slots__ = (
        'w',
        'name',
        'rim',
        'is_enable',
        'oo',
        'active',
        'tm_focus',
    )
    def __init__(self, w, name, lis_bu):
        self.w = w
        self.oo = lis_bu
        self.active = None
        self.name = name
        self.rim = ENUM_RIM(self, lis_bu)
        for e in lis_bu:    e.fn = self.fn

    def get_rim(self):
        oo = self.oo
        rim = self.rim
        rim0 = oo[0].rim
        rim.L = rim0.L
        rim.R = oo[-1].rim.R
        rim.B = rim0.B
        rim.T = rim0.T
    def dxy_upd(self, x, y):
        for e in self.oo:   e.dxy_upd(x, y)
        self.get_rim()

    def draw_rim(self):
        for e in self.oo:   e.draw_rim()
    def draw_bg(self):
        for e in self.oo:   e.draw_bg()
    def draw_ti(self):
        for e in self.oo:   e.draw_ti()
    def inside(self, evt):
        self.tm_focus.inside(evt)
    def fn(self):
        print(f"    bu  BU_ENUM  fn")
        if self.tm_focus.is_on is False:
            self.tm_focus.on()
            return

        try:    self.active.off()
        except: pass
        self.active = self.tm_focus
    def bu_on_by_ind(self, i):
        e = self.oo[i]
        self.tm_focus = e
        self.active = e
        e.on()

class BU_BOOL:
    __slots__ = (
        'w',
        'name',
        'fn',
        'base_evt',
        'ti',
        'rim',
        'da',
        'is_enable',
        'inside',
        'on',
        'off',
        'fo',
        'is_allow',
        'upd_fn',
    )
    def __init__(self,
            w,
            name,
            ti,
            fn          = None,
            base_evt    = None,
            is_enable   = True,
            upd_fn      = None,
        ):
        self.w          = w
        self.name       = name
        self.fn         = self.fn_switch  if fn is None else fn
        self.upd_fn     = upd_fn
        self.base_evt   = NF  if base_evt is None else base_evt
        self.ti         = BLF(text = ti, size = F[9])
        self.rim        = BOX()
        self.da         = BLF(size = F[22])
        self.da.name    = None

        if is_enable:   self.enable()
        else:           self.disable()

    def enable(self):
        self.is_enable  = True
        self.inside     = self.I_inside
        self.da.color   = P.color_bu_2
        self.ti.color   = P.color_font
        self.I_off()
    def disable(self):
        self.is_enable  = False
        self.inside     = N
        self.da.color   = P.color_bu_2_ignore
        self.ti.color   = P.color_font_ignore
        self.rim.color  = P.color_bu_3_ignore
        self.on         = N
        self.off        = N
        self.fo         = N

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)
        self.ti.dxy(x, y)

    def LRBT(self, L, R, B, T): # blf_size
        self.rim.LRBT(L, R, B, T)
        self.rim.upd()
        self.da.LB(self.rim, F[1.5], 0)
        self.ti.y = B + F[4]
        self.ti.x = L - self.ti.R_dimen() - F[4]
    def LRBT_ti_right(self, L, R, B, T, dR=7):
        self.rim.LRBT(L, R, B, T)
        self.rim.upd()
        self.da.LB(self.rim, F[1.5], 0)
        self.ti.y = B + F[4]
        self.ti.x = R + F[dR]
    def RB(self, R, B): # blf_size
        h = F[16]
        L = R - h
        self.rim.LRBT(L, R, B, B + h)
        self.rim.upd()
        self.da.LB(self.rim, F[1.5], 0)
        self.ti.y = B + F[4]
        self.ti.x = L - self.ti.R_dimen() - F[4]

    def I_on(self):
        self.rim.color  = P.color_bu_3_on
        self.on         = N
        self.off        = self.I_off
        self.fo         = self.I_fo
    def I_off(self):
        self.rim.color  = P.color_bu_3_off
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
    def I_fo(self):
        self.rim.color  = P.color_bu_3_fo
        self.on         = self.I_on
        self.off        = self.I_off
        self.fo         = N

    def draw_rim(self): pass
    def draw_bg(self):
        self.rim.bind_draw()
    def draw_ti(self):
        self.ti.set_draw()
        self.da.set_draw()

    def I_inside(self, evt):
        self.fo()
        self.is_allow   = True
        self.w.U_modal  = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()
    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) is False or self.w.sci.inbox(evt) is False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return

        if evt.value == 'RELEASE':  self.is_allow = True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            if self.is_allow:
                self.w.RET      = True
                self.is_allow   = False
                self.fn()
                m.redraw()
                return True
        return self.base_evt(evt)

    def set_da(self, boo):
        if self.da.name != boo:
            self.da.name = boo
            self.da.text = "■"  if boo else ""

    def fn_switch(self):
        if self.da.name is True:
            self.da.name = False
            self.da.text = ""
        else:
            self.da.name = True
            self.da.text = "■"
        if self.upd_fn is not None: self.upd_fn()


class BUTI:
    __slots__ = (
        'w',
        'name',
        'fn',
        'rim',
        'ti',
        'draw_ti',
        'fo',
        'unfo',
        'color_fo',
        'state',
    )
    def __init__(self, w, name, ti, fn):
        self.w          = w
        self.name       = name
        self.fn         = fn
        self.rim        = RECT()
        self.ti         = BLF(text=ti)
        self.draw_ti    = self.I_draw_ti
        self.fo         = self.I_fo
        self.unfo       = N
        self.state      = 0

    def enable(self):
        self.state = 0
        self.ti.color = P.color_font
        m.redraw()
    def disable(self, soft=True):
        self.state = 1  if soft else 2
        self.ti.color = P.color_font_ignore
        m.redraw()

    def LBT(self, L, B, T, dy = 3.8): # blf_size
        self.ti.xy(L, B + dy)
        self.rim.LRBT(L, self.ti.R_end_x() + F[2], B, T)
    def align_R_by_bu(self, e, d): # blf_size
        r = e.rim
        self.ti.x += r.L - d - self.ti.R_end_x()
        self.ti.y = e.da.y
        self.rim.LRBT(self.ti.x, self.ti.R_end_x() + F[2], r.B, r.T)
    def align_R_by_rim(self, rim, d): # blf_size
        self.ti.x += rim.L - d - self.ti.R_end_x()
        self.ti.y = rim.B + F[4]
        self.rim.LRBT(self.ti.x, self.ti.R_end_x() + F[2], rim.B, rim.T)

    def dxy_upd(self, x, y):
        self.rim.dxy(x, y)
        self.ti.dxy(x, y)
    def draw_rim(self): pass
    def draw_bg(self):  pass
    def I_draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()
    def I_draw_ti_fo(self):
        blf_color(font_0, *self.color_fo)
        self.ti.draw_pos()

    def on(self):
        self.ti.color = P.color_font_sub_ti
        self.color_fo = P.color_font_sub_ti_fo
    def off(self):
        self.ti.color = P.color_font_sub_ti_2
        self.color_fo = P.color_font_sub_ti_2_fo
    def I_fo(self):
        self.fo         = N
        self.unfo       = self.I_unfo
        self.draw_ti    = self.I_draw_ti_fo
    def I_unfo(self):
        self.fo         = self.I_fo
        self.unfo       = N
        self.draw_ti    = self.I_draw_ti

    def inside(self, evt):
        if self.state == 2: return
        if self.state == 0: self.fo()
        self.w.U_modal = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.unfo()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if K["sel_fast0"].true():
            self.fn()
            self.w.RET = True
            return True
        if K["sel_fast1"].true():
            self.fn()
            self.w.RET = True
            return True

class BUDA:
    __slots__ = (
        'w',
        'name',
        'fn',
        'rim',
        'draw_ti',
        'da',
        'fo',
        'unfo',
        'color_fo',
        'draw_ti_color',
        'z0',
        'z1',
    )
# BUDA slots END
    def __init__(self, w, name, fn):
        self.w          = w
        self.name       = name
        self.fn         = fn
        self.rim        = RECT()
        self.draw_ti    = self.I_draw_ti
        self.da         = BLF(P.color_font)
        self.da.name    = ""
        self.fo         = self.I_fo
        self.unfo       = N
        self.color_fo   = P.color_font_fo
        self.draw_ti_color = self.I_draw_ti_color

    def LRBT(self, L, R, B, T, dy = 3.8):
        self.da.xy(L, B + dy)
        self.rim.LRBT(L, R, B, T)

    def dxy_upd(self, x, y):
        self.rim.dxy(x, y)
        self.da.dxy(x, y)
    def draw_rim(self): pass
    def draw_bg(self):  pass
    def I_draw_ti(self):
        self.draw_ti_color()
        self.da.draw_pos()
    def I_draw_ti_size(self):
        self.draw_ti_color()
        self.da.set_size()
        self.da.draw_pos()
    def enable_half_size_method(self, z0 = 12, z1 = 6):
        self.z0 = z0
        self.z1 = z1
        self.draw_ti = self.I_draw_ti_size
        self.da.size = F[z0]
    def I_draw_ti_color(self):      self.da.set_color()
    def I_draw_ti_color_fo(self):   blf_color(font_0, *self.color_fo)

    def upd_da_half_size(self, s, critical):
        if self.da.name != s:
            self.da.name = self.da.text = s
            blf_size(font_0, F[self.z0], 72)
            self.da.size = F[self.z1]  if self.da.R_end_x() > critical else F[self.z0]
    def upd_half_size(self, critical): # must blf_size
        self.da.size = F[self.z1]  if self.da.R_end_x() > critical else F[self.z0]

    def I_fo(self):
        self.fo     = N
        self.unfo   = self.I_unfo
        self.draw_ti_color = self.I_draw_ti_color_fo
    def I_unfo(self):
        self.fo     = self.I_fo
        self.unfo   = N
        self.draw_ti_color = self.I_draw_ti_color

    def inside(self, evt):
        self.fo()
        self.w.U_modal = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.unfo()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.fn()
            self.w.RET = True
            return True
class BUDA_RENAME(BUDA):
    __slots__ = ()
    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.unfo()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if K["me_rename0"].true() or K["me_rename1"].true():
            self.fn()
            self.w.RET = True
            return True
class BUDA_PAN(BUDA):
    __slots__ = (
        'key_end',
        'w_sci',
        'sci',
        'limL',
        'limR',
        'dxy_upd',
        'state',
    )
    def __init__(self, w, name, fn, tx_size, w_sci=None):
        self.w      = w
        self.name   = name
        self.fn     = fn
        self.w_sci  = w_sci
        if w_sci is None:
            self.sci        = None
            self.draw_ti    = self.I_draw_ti
            self.dxy_upd    = self.I_dxy_upd
        else:
            self.sci        = m.SCISSOR()
            self.draw_ti    = self.I_draw_ti_sci
            self.dxy_upd    = self.I_dxy_upd_sci
        self.rim    = BOX(P.color_bu_3_off)
        self.da     = BLF(P.color_font, "", tx_size)
        self.fo     = self.I_fo
        self.unfo   = N
        self.state  = 0

    def enable(self):
        self.state = 0
        self.da.color = P.color_font
        self.rim.color = P.color_bu_3_off
        m.redraw()
    def disable(self, soft=True):
        self.state = 1  if soft else 2
        self.da.color = P.color_font_ignore
        self.rim.color = P.color_bu_3_ignore
        m.redraw()

    def upd_sci(self):
        sci     = self.sci
        w_sci   = self.w_sci
        rim     = self.rim

        sci.x   = max(rim.L, w_sci.x)
        sci.w   = min(rim.R, w_sci.x + w_sci.w) - sci.x
        sci.y   = w_sci.y
        sci.h   = w_sci.h
    def upd_tx_pos(self):
        da      = self.da
        sci     = self.sci
        L       = sci.x
        R       = L + sci.w
        f4      = F[4]
        da.set_size()
        da.x    = min(max(da.x, R - f4 - da.R_dimen()), L + f4)

    def LRBT(self, L, R, B, T):
        self.da.xy(L + F[4], B + F[4])
        self.rim.LRBT(L, R, B, T)
        self.rim.upd()
        if self.sci is not None:    self.upd_sci()

    def I_dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)
    def I_dxy_upd_sci(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)
        self.upd_sci()

    def draw_rim(self): pass
    def draw_bg(self):          self.rim.bind_draw()
    def I_draw_ti(self):        self.da.set_draw()
    def I_draw_ti_sci(self):    self.sci.use() ;self.da.set_draw()

    def I_fo(self):
        self.fo         = N
        self.unfo       = self.I_unfo
        self.rim.color  = P.color_bu_3_fo
    def I_unfo(self):
        self.fo         = self.I_fo
        self.unfo       = N
        self.rim.color  = P.color_bu_3_off

    def inside(self, evt):
        if self.state == 2: return
        if self.state == 0: self.fo()
        self.w.U_modal = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.unfo()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return False

        if K["pan0"].true():
            self.key_end = K["pan_E0"]
            self.to_modal_pan(evt)
            return True
        if K["pan1"].true():
            self.key_end = K["pan_E1"]
            self.to_modal_pan(evt)
            return True

        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.fn()
            self.w.RET = True
            return True

    def to_modal_pan(self, evt):
        print(f"    bu  BUDA_PAN(BUDA)  to_modal_pan")
        self.key_end.true()
        self.w.RET = True
        sci     = self.sci
        if sci is None: return
        if self.da.text:
            da      = self.da
            w_sci   = self.w_sci
            L       = sci.x
            R       = L + sci.w
            f4      = F[4]

            m.head_modal.append(self.modal_pan)
            m.U_pan_cursor(self, evt)
            x       = w_sci.x
            y       = w_sci.y
            m.get_loop_mou_info_region(evt, x, x + w_sci.w, y, y + w_sci.h)
            m.get_mou(evt)

            da.set_size()
            self.limR   = L + f4
            self.limL   = R - f4 - da.R_dimen()
            m.redraw()
    def modal_pan(self, evt):
        if self.key_end.true():
            print(f"    bu  BUDA_PAN(BUDA)  modal_pan  END")
            del m.head_modal[-1]
            m.U_end_pan(self)
            m.init_wait_release()
            m.redraw()
            return

        m.U_pan(evt)
        self.da.x = min(max(self.da.x + m.dx, self.limL), self.limR)
        m.loop_mou(evt)
        m.redraw()


class BUSCROLLY:
    __slots__ = (
        'w',
        'name',
        'rim',
        'bar_rim',
        'bar_bg',
        'off',
        'fo',
        'is_enable',
        'U_draw',
        'max_T',
        'min_B',
        'max_h',
        'min_h',
        'dif_h',
        'lim_h',
    )
    def __init__(self, w, name):
        self.w          = w
        self.name       = name
        self.rim        = BOX(P.color_scroll_rim)
        self.bar_rim    = BOX(P.color_scroll_bar_rim)
        self.bar_bg     = BOX(P.color_scroll_bar_bg)

        self.off        = N
        self.fo         = self.I_fo
        self.is_enable  = True
        self.U_draw     = self.I_draw

    def LRBT(self, L, R, B, T):
        _1          = F[1]
        rim         = self.rim
        bar_rim     = self.bar_rim
        bar_bg      = self.bar_bg
        rim.LRBT(L, R, B, T)
        rim.upd()
        bar_rim.inset_with_depth(rim, _1)
        bar_rim.upd()
        bar_bg.LRBT(bar_rim.L + _1, bar_rim.R, bar_rim.B, bar_rim.T - _1)
        bar_bg.upd()
        self.max_T = bar_rim.T
        self.min_B = bar_rim.B
        self.max_h = bar_rim.R_h()
        self.min_h = bar_rim.R_w()
        self.dif_h = self.max_h - self.min_h
        self.lim_h = self.max_h - F[10]

    def I_off(self):
        self.off        = N
        self.fo         = self.I_fo
        self.rim.color  = P.color_scroll_rim
        self.bar_bg.color = P.color_scroll_bar_bg
        m.redraw()
    def I_fo(self):
        self.off        = self.I_off
        self.fo         = N
        self.rim.color  = P.color_scroll_rim_fo
        self.bar_bg.color = P.color_scroll_bar_fo
        m.redraw()

    def upd_scroll(self, limT, limB, y, amt_10):
        _1          = F[1]
        bar_rim     = self.bar_rim
        bar_bg      = self.bar_bg
        tot         = limT - limB

        if tot == 0 or amt_10 <= 0:
            bar_rim.B, bar_rim.T = self.min_B, self.max_T
            bar_rim.upd()
            bar_bg.LRBT(bar_rim.L + _1, bar_rim.R, bar_rim.B, bar_rim.T - _1)
            bar_bg.upd()
            return

        h = self.min_h  if amt_10 > 100 else self.min_h + (100 - amt_10)/100 * self.dif_h
        h = min(round(h), self.lim_h)

        bar_rim.T = self.max_T - (limT - y) * (self.max_h - h)//tot
        bar_rim.B = bar_rim.T - h
        bar_rim.upd()
        bar_bg.LRBT(bar_rim.L + _1, bar_rim.R, bar_rim.B, bar_rim.T - _1)
        bar_bg.upd()

    def I_draw(self):
        self.rim.bind_draw()
        self.bar_rim.bind_draw()
        self.bar_bg.bind_draw()

    def evt(self, evt):
        if self.rim.inbox(evt):
            self.fo()
            if self.bar_rim.inbox(evt): return True
            return False
        self.off()
        return None

    def bar_mov(self, dy):
        if dy < 0:
            new_B   = self.bar_rim.B + dy
            dif     = self.min_B - new_B
            if dif > 0: dy += dif
        else:
            new_T   = self.bar_rim.T + dy
            dif     = new_T - self.max_T
            if dif > 0: dy -= dif

        self.bar_rim.dy_upd(dy)
        self.bar_bg.dy_upd(dy)

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bar_rim.dxy_upd(x, y)
        self.bar_bg.dxy_upd(x, y)

    def mov_end_upd(self):
        self.max_T = self.rim.T - F[1]
        self.min_B = self.rim.B + F[1]
class BUSCROLLX(BUSCROLLY):
    pass


class BU_LR:
    __slots__ = (
        'w',
        'is_enable_back',
        'is_enable_next',
        'rim',
        'ti_back',
        'ti_next',
        'is_RET',
        'base_evt',
        'fn_back',
        'fn_next',
        'in_left',
        'key_end',
    )
    def __init__(self, w, fn_back, fn_next,
        base_evt        = None,
        enable_back     = False,
        enable_next     = False,
        is_RET          = True,
        ):
        self.w          = w
        self.rim        = BOX(None)
        self.is_RET     = is_RET
        self.fn_back    = fn_back
        self.fn_next    = fn_next
        self.base_evt   = NF  if base_evt is None else base_evt
        self.ti_back    = BLF(text="◀")
        self.ti_next    = BLF(text="▶")

        self.enable_back()  if enable_back else self.disable_back()
        self.enable_next()  if enable_next else self.disable_next()
        self.is_enable_back = enable_back
        self.is_enable_next = enable_next

    def RB(self, R, B):
        wi      = round(35 * P.scale[0])
        L       = R - wi
        self.rim.LRBT(L, R, B, B + F[16])
        e       = self.ti_back
        e.x     = L + F[4]
        e.y     = B + F[1]
        e.size  = F[18]
        o       = self.ti_next
        o.x     = L + F[20]
        o.y     = e.y
        o.size  = e.size

    def dxy_upd(self, x, y):
        self.rim.dxy(x, y)
        self.ti_back.dxy(x, y)
        self.ti_next.dxy(x, y)

    def enable_back(self):
        self.ti_back.color  = P.color_bu_media
        self.is_enable_back = True
    def enable_next(self):
        self.ti_next.color  = P.color_bu_media
        self.is_enable_next = True
    def disable_back(self):
        self.ti_back.color  = P.color_bu_media_ignore
        self.is_enable_back = False
    def disable_next(self):
        self.ti_next.color  = P.color_bu_media_ignore
        self.is_enable_next = False

    def draw(self):
        self.ti_back.set_draw()
        self.ti_next.set_draw()

    def inside(self, evt):
        m.redraw()
        if evt.mouse_region_x <= self.rim.R_center_x():
            self.in_left = True
            if self.is_enable_back: self.ti_back.color = P.color_bu_media_fo
        else:
            self.in_left = False
            if self.is_enable_next: self.ti_next.color = P.color_bu_media_fo

        self.w.U_modal  = self.I_modal_fo
        self.I_modal_fo(evt)

    def I_modal_fo(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            if self.is_enable_back: self.ti_back.color = P.color_bu_media
            if self.is_enable_next: self.ti_next.color = P.color_bu_media

            self.w.U_modal = self.w.default_modal
            m.redraw()
            m.EVT.kill()
            return False

        if self.in_left:
            if evt.mouse_region_x <= self.rim.R_center_x(): pass
            else:
                m.redraw()
                self.in_left = False
                if self.is_enable_back: self.ti_back.color = P.color_bu_media
                if self.is_enable_next: self.ti_next.color = P.color_bu_media_fo
        else:
            if evt.mouse_region_x <= self.rim.R_center_x():
                m.redraw()
                self.in_left = True
                if self.is_enable_back: self.ti_back.color = P.color_bu_media_fo
                if self.is_enable_next: self.ti_next.color = P.color_bu_media
            else: pass

        if K["sel_fast0"].true():
            self.w.U_modal  = self.I_modal_press
            self.key_end    = K["sel0"]
            self.key_end.true()
            self.evt_back(color=True)  if self.in_left else self.evt_next(color=True)
            return True
        if K["sel_fast1"].true():
            self.w.U_modal  = self.I_modal_press
            self.key_end    = K["sel1"]
            self.key_end.true()
            self.evt_back(color=True)  if self.in_left else self.evt_next(color=True)
            return True
        return self.base_evt(evt)

    def I_modal_press(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            if self.is_enable_back: self.ti_back.color = P.color_bu_media
            if self.is_enable_next: self.ti_next.color = P.color_bu_media

            self.w.U_modal = self.w.default_modal
            m.redraw()
            m.EVT.kill()
            return False

        if self.key_end.true():
            self.w.U_modal = self.I_modal_fo
            if self.in_left:
                if self.is_enable_back:
                    self.ti_back.color = P.color_bu_media_fo
                    m.redraw()
            else:
                if self.is_enable_next:
                    self.ti_next.color = P.color_bu_media_fo
                    m.redraw()
        return False

    def evt_back(self, color=False):
        if self.is_enable_back:
            m.redraw()
            if color:   self.ti_back.color = P.color_bu_media_on
            self.fn_back()
    def evt_next(self, color=False):
        if self.is_enable_next:
            m.redraw()
            if color:   self.ti_next.color = P.color_bu_media_on
            self.fn_next()


class TI_TYPE:
    __slots__ = "w", "name", "ti", "default_ti"
    def __init__(self, w, name, ti):
        self.w          = w
        self.name       = name
        self.ti         = BLF(P.color_font_darker, ti)
        self.default_ti = ti

    def xy(self, x, y): self.ti.xy(x, y)
    def before_bu(self, b, dx = 7.8, dy = 4.9): # must blf_size
        self.ti.align_R_float(b.rim.L - F[dx])
        self.ti.y = b.rim.B + F[dy]

    def dxy_upd(self, x, y):    self.ti.dxy(x, y)
    def draw_rim(self): pass
    def draw_bg(self):  pass
    def draw_ti(self):  self.ti.set_color()  ;self.ti.draw_pos()

    def upd_val(self, v):
        if self.ti.size != v:
            self.ti.size = v
            self.ti.text = f"{self.default_ti}{v}"

class BU4:
    __slots__ = (
        'w',
        'name',
        'rim',
        'bg',
        'ti',
        'on',
        'off',
        'fo',
        'offset_x',
        'offset_y',
        'offset_y_key',
        'key_end',
        'is_enable',
        'is_inside',
        'enum_set',
        'fn',
        'details',
    )
    def __init__(self, w, name, ti,
            offset_y_key    = 4.5,
            fn              = None,
            details         = None,
        ):
        self.w      = w
        self.name   = name

        self.rim    = BOX()
        self.bg     = BOX(P.color_bu_4_off)
        self.ti     = BLF(P.color_font, ti)
        self.on     = self.I_on
        self.off    = N
        self.fo     = self.I_fo

        self.offset_y_key   = offset_y_key
        self.is_enable      = True
        self.is_inside      = self.I_is_inside
        self.fn             = fn
        self.details        = details

    def LRBT(self, L, R, B, T): # blf_size, is_enable=True
        rim = self.rim
        bg  = self.bg
        ti  = self.ti
        _1  = F[1]
        rim.LRBT(L, R, B, T)
        rim.upd()

        bg.LRBT(rim.L + _1, rim.R, rim.B, rim.T - _1)
        bg.upd()
        ti.set_x_by_bo_float(bg)
        self.offset_x   = ti.x - bg.L
        self.offset_y   = F[self.offset_y_key]
        ti.y            = bg.B + self.offset_y

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bg.dxy_upd(x, y)
        self.ti.dxy(x, y)

    def I_on(self):
        rim         = self.rim
        bg          = self.bg
        bg.color    = P.color_bu_4_on

        bg.LRBT(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = N
        self.off    = self.I_off
        self.fo     = self.I_fo
        m.redraw()
    def I_off(self):
        rim         = self.rim
        bg          = self.bg
        bg.color    = P.color_bu_4_off
        bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = self.I_on
        self.off    = N
        self.fo     = self.I_fo
        m.redraw()
    def I_fo(self):
        rim         = self.rim
        bg          = self.bg
        bg.color    = P.color_bu_4_fo
        bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        bg.upd()
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = self.I_on
        self.off    = self.I_off
        self.fo     = N
        m.redraw()

    def draw_bo(self):
        m.bind_color_bu_4_rim()
        self.rim.draw()
        self.bg.bind_draw()

    def draw_rim(self):     self.rim.draw()
    def draw_bg(self):      self.bg.bind_draw()
    def draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()

    def I_is_inside(self, evt):
        if self.rim.inbox(evt):
            if self.off == N:
                self.fo()
            self.w.U_modal = self.I_modal_fo
            return True
        return False
    def I_modal_fo(self, evt):
        if self.w.outside[0] is True:
            self.w.outside[0] = None
            if self.fo == N:  self.off()
            m.redraw()
            self.w.to_default_modal()
            return

        if self.rim.inbox(evt) == False:
            if self.fo == N:  self.off()

            m.redraw()
            self.w.to_default_modal()
            return False

        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            if self.on == N:    return False
            self.on()
            if hasattr(self, "enum_set"):
                li = self.enum_set.li
                ind = li.index(self)
                for e in li[: ind]:     e.off()
                for e in li[ind + 1 :]: e.off()
                m.tm["ind"] = ind
                self.enum_set.fn()
            else:
                if self.fn is not None: self.fn()
            return True

    def rm_init(self, evt):
        print(f"    bu  BU4  rm_init")
        rm_li = [
        ]
        if self.details is not None:    rm_li.append({9: "fn_Details", 0: "Details"})
        if not rm_li: return
        RM(self, evt.mouse_region_x, evt.mouse_region_y, rm_li)
        #
    def fn_Details(self):
        print("    bu  BU4  fn_Details")
        evt = m.EVT.evt
        hi = F[150]
        wi = F[480]
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), self.details)
        #


class BU_SIM_9:
    __slots__ = (
        'w',
        'name',
        'rim',
        'bg',
        'ti',
        'color_off',
        'color_fo',
        'color_on',
        'inbox_xy',
        'offset_x',
    )
    def __init__(self, w, name, ti, color_type=0):
        if color_type == 0:
            self.color_off = P.color_bu_1_off
            self.color_fo = P.color_bu_1_fo
            self.color_on = P.color_bu_1_on
        else:
            self.color_off = P.color_bu_4_off
            self.color_fo = P.color_bu_4_fo
            self.color_on = P.color_bu_4_on

        self.w = w
        self.name = name
        self.rim = BOX()
        self.bg = BOX(self.color_off)
        self.ti = BLF(text=ti)
        self.inbox_xy = self.rim.inbox_xy

    def LRBT(self, L, R, B, T, _1): # blf_size
        self.rim.LRBT_upd(L, R, B, T)
        L += _1
        self.bg.LRBT_upd(L, R, B, T - _1)
        ti = self.ti
        ti.set_x_by_bo_float(self.bg)
        self.offset_x = ti.x - L
        ti.y = B + F[4]

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bg.dxy_upd(x, y)
        self.ti.dxy(x, y)
    def unfocus(self):
        if self.bg.color == self.color_on:
            r = self.rim
            L = r.L + F[1]
            self.bg.LRBT_upd(L, r.R, r.B, r.T - F[1])
            self.ti.xy(L + self.offset_x, r.B + F[4])

        self.bg.color = self.color_off
    def focus(self):
        if self.bg.color == self.color_on:
            r = self.rim
            L = r.L + F[1]
            self.bg.LRBT_upd(L, r.R, r.B, r.T - F[1])
            self.ti.xy(L + self.offset_x, r.B + F[4])

        self.bg.color = self.color_fo
    def on(self):
        if self.bg.color != self.color_on:
            self.bg.color = self.color_on
            r = self.rim
            B = r.B + F[1]
            self.bg.LRBT_upd(r.L, r.R - F[1], B, r.T)
            self.ti.xy(r.L + self.offset_x, B + F[4])

    def modal(self, evt):
        if K["sel0"].true() or K["sel1"].true():
            m.redraw()
            self.focus()
            print(f"    bu  BU_SIM_9  modal  K['sel0']")
            getattr(self.w, f"bufn_{self.name}")()
            return True
        elif K["sel_fast0"].true() or K["sel_fast1"].true():
            m.redraw()
            self.on()
        return False

class VBOX: # From ED_md.bu_md.BUFL
    __slots__ = (
        'w',
        'name',
        # 'attr',
        'da_color',
        'da_color_ignore',
        'offset_x_key',
        'offset_y_key',
        'offset_ti_key',
        'rim',
        'ti',
        'da',
        'on',
        'off',
        'fo',
        'enable',
        'disable',
        'inside',
        'is_enable',
        'offset_x',
        'offset_y',
        'U_fn',
        'free_fn',
        'ty',
        'tx_format',
        'bpy_setter',
        'key_end',
        'key_slow',
        'key_fast',
        'R_qe_dx',
        'qe_value',
        'qe_org',
        'qe_unit',
        'qe_unit_slow',
        'qe_unit_fast',
        'qe_fn',
        'qe_bu',
        'subtype_info',
        'details',
        'unit',
    )
    def __init__(self,
            w,
            name,
            ti_tx,
            fn_confirm,
            offset_x_key    = 5.1,
            offset_y_key    = 4.9,
            offset_ti_key   = 8,
            ty              = "float [-∞,∞]",
            details         = None,
            unit            = 0,
        ):
        self.w          = w
        self.name       = name
        self.ty         = ty
        self.details    = details
        self.unit       = unit

        if ty[0:3] == 'int':
            self.tx_format      = m.U_format_i
        else:
            if unit == 0:   self.tx_format = m.U_format_f
            elif unit == 1: self.tx_format = m.U_FORMAT_F
            elif unit == 2: self.tx_format = m.U_FORMAT_F2
            elif unit == 3: self.tx_format = m.U_FORMAT_F3

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key
        self.offset_ti_key      = offset_ti_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.bpy_setter = fn_confirm

        if isinstance(ti_tx, str):
            self.ti = BLF(text=ti_tx)
        else:
            group = w.oo[ti_tx[1]]
            ind = ti_tx[2]
            self.ti = BLF(text=group.ti_tx if ind == 0 else "")
            group.li_subtype[ind].text = ti_tx[0]
            self.subtype_info = ti_tx

        self.init_end()
    def init_end(self): pass

    def LRBT(self, L, R, B, T): # blf_size
        rim = self.rim
        rim.LRBT(L, R, B, T)
        rim.upd()
        self.offset_x   = F[self.offset_x_key]
        self.offset_y   = F[self.offset_y_key]
        self.da.LB(rim, self.offset_x, self.offset_y)
        self.ti.xy(L - F[self.offset_ti_key] - self.ti.R_dimen(), self.da.y)

    def right_dr(self, dr, w, d = 10):
        L = dr.rim.R + F[d] - F[4]
        self.LRBT(L, L + w, dr.rim.B, dr.rim.T)

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)
        self.ti.dxy(x, y)

    def I_on(self):
        self.rim.color  = P.color_bu_3_on
        self.on         = N
        self.off        = self.I_off
        self.fo         = self.I_fo
    def I_off(self):
        self.rim.color  = P.color_bu_3_off
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
    def I_fo(self):
        self.rim.color  = P.color_bu_3_fo
        self.on         = self.I_on
        self.off        = self.I_off
        self.fo         = N

    def I_enable(self):
        self.is_enable  = True
        self.inside     = self.I_inside
        self.da.color   = self.da_color
        self.I_off()
        self.enable     = N
        self.disable    = self.I_disable
    def I_disable(self, soft=True):
        mN = N
        self.is_enable  = False
        if soft is False:   self.inside = mN
        self.rim.color  = P.color_bu_3_ignore
        self.da.color   = self.da_color_ignore
        self.enable     = self.I_enable
        self.disable    = mN
        self.on         = mN
        self.off        = mN
        self.fo         = mN

    def draw_rim(self): pass
    def draw_bg(self):  self.rim.bind_draw()
    def draw_ti(self):
        self.da.set_color()
        self.da.draw_pos()
        self.ti.draw_pos()

    def set_da(self, flo):
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)

    def setter(self): pass
    def I_bpy_setter(self, flo):
        setattr(self.w.w.act_md, self.attr, flo)
        m.undo_str = f'[Modifier Editor] md.{self.attr} = {flo}'
        m.undo_push()
    def I_bpy_setter_int(self, flo):
        v = round(flo)
        setattr(self.w.w.act_md, self.attr, v)
        m.undo_str = f'[Modifier Editor] md.{self.attr} = {v}'
        m.undo_push()
    def R_unit_fac(self):
        u = self.unit
        if u == 0:      return 1.0
        if u == 1:      return m.unit_length_fac
        elif u == 2:    return m.unit_length_fac2
        elif u == 3:    return m.unit_length_fac3
        return 1.0

    def fn(self, multi_edit=None):
        if self.da.name is None: return
        dd.DDVAL(self, self.ty, multi_edit=multi_edit, end_fn=m.refresh)
    def fn_copy(self):
        print(f"    bu  VBOX  fn_copy")
        try:
            fac = self.R_unit_fac()
            bpy.context.window_manager.clipboard = m.R_str_by_float(self.da.name if fac == 1 else self.da.name / fac)
        except: pass
    def fn_cut(self):
        self.fn_copy()
    def fn_paste(self):
        print(f"    bu  VBOX  fn_paste")
        try:
            fac = self.R_unit_fac()
            v = calc_vec(bpy.context.window_manager.clipboard)[0]
            self.bpy_setter(v if fac == 1 else v * fac)
        except: pass

    def is_inside(self, evt):
        if self.is_enable is False: return False
        return self.rim.inbox(evt)
    def I_inside(self, evt):
        self.fo()
        self.w.to_modal(self.I_modal_fo)
        self.I_modal_fo(evt)
        m.redraw()

    def I_modal_fo(self, evt):
        if self.w.outside[0] is True:
            self.w.outside[0] = None
            self.off()
            m.redraw()
            self.w.to_default_modal()
            return

        if self.rim.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.to_default_modal()
            return self.w.U_modal(evt)

        if K["bu_qe0"].true():
            if self.is_enable is False: return False
            self.key_end = K["bu_qe_E0"]
            self.to_modal_qe(evt, K["bu_qe0"])
            return True
        if K["bu_qe1"].true():
            if self.is_enable is False: return False
            self.key_end = K["bu_qe_E1"]
            self.to_modal_qe(evt, K["bu_qe1"])
            return True
        if K["bu_sel0"].true() or K["bu_sel1"].true():
            self.w.RET = True
            self.fn()
            return True
        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.w.RET = True
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.w.RET = True
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            self.w.RET = True
            self.fn_cut()
            return True

    def rm_init(self, evt, override=None):
        print(f"    bu  VBOX  rm_init")
        self.w.RET = True
        rm_li = [
            {9: "fn_Copy", 0: "Copy"},
            {9: "fn_Paste", 0: "Paste"},
        ] if override is None else override

        if self.details is not None:    rm_li.append({9: "fn_Details", 0: "Details"})
        RM(self, evt.mouse_region_x, evt.mouse_region_y, rm_li)
        #
    def fn_Copy(self):
        print("    bu  VBOX  fn_Copy")
        self.fn_copy()
        #
    def fn_Paste(self):
        print("    bu  VBOX  fn_Paste")
        self.fn_paste()
        #
    def fn_Details(self):
        print("    bu  VBOX  fn_Details")
        evt = m.EVT.evt
        hi = F[150]
        wi = F[480]
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), self.details)
        #

    def is_alt(self, evt):    return evt.alt
    def is_ctrl(self, evt):   return evt.ctrl
    def is_shift(self, evt):  return evt.shift
    def is_oskey(self, evt):  return evt.oskey
    def NF(self, evt):        return False
    def IR_dx(self):    return m.dx
    def IR_dy(self):    return m.dy
    def to_modal_qe(self, evt, mk=None):
        print("    bu  VBOX  to_modal_qe")
        if self.da.name is None: return
        self.w.RET = True
        self.key_end.true()
        m.upd_disable()

        r = m.region_data
        m.get_loop_mou_info_region(evt, r.L, r.R, r.B, r.T)
        m.get_mou(evt)
        tm = m.tm
        tm["x"] = evt.mouse_x
        tm["y"] = evt.mouse_y
        tm["bu"] = self
        try:    m.M.set_mou_ic(P.quick_edit_cursor)
        except: pass

        self.R_qe_dx = self.IR_dx if P.quick_edit_method == 'HORIZONTAL' else self.IR_dy
        dic = m.dic_hold_key
        slow0 = K["bu_qe_slow0"].type0
        self.key_slow = getattr(self, f"is_{dic[slow0]}") if slow0 in dic else self.NF
        fast0 = K["bu_qe_fast0"].type0
        self.key_fast = getattr(self, f"is_{dic[fast0]}") if fast0 in dic else self.NF

        if P.quick_edit_operation == 'REAL_TIME':
            if self.ty[:3] == "flo":
                self.qe_fn = self.I_qe_real_time_float
            else:
                self.qe_fn = self.I_qe_real_time_int
        else:
            if self.ty[:3] == "flo":
                self.qe_fn = self.I_qe_performance_float
            else:
                self.qe_fn = self.I_qe_performance_int

        self.qe_value   = self.da.name
        self.qe_org     = self.qe_value
        self.qe_unit = getattr(P, f'{m.R_calc_attr(self.ty)}qe')
        self.qe_unit_slow = P.quick_edit_fac_slow * self.qe_unit
        self.qe_unit_fast = P.quick_edit_fac_fast * self.qe_unit
        self.qe_bu = self

        tm["is_quick_edit"] = {"state": 0}
        if self.is_to_modal_multi(evt, mk): return

        m.head_modal.append(self.I_modal_qe)
    def is_to_modal_multi(self, evt, mk): return False
    def modal_qe_end(self, cancel=False):
        print(f"    bu  VBOX  modal_qe_end:  cancel={cancel}")
        del m.head_modal[-1]
        tm = m.tm
        tm["is_quick_edit"].clear()
        tm["is_quick_edit"]["state"] = -1
        m.EVT.kill()
        m.I_end_pan_hide(self)

        self.w.to_default_modal()

        if cancel:
            m.upd_enable()
            if isinstance(self.qe_org, list):
                oo = self.w.oo[self.subtype_info[1]].li
                for e in oo:    e.I_off()

                ind = tm["bu_range"][0]
                for e in self.qe_org:
                    o = oo[ind]
                    o.da.name = None
                    o.bpy_setter(e, undo_push=False)
                    ind += 1
            else:
                self.I_off()
                self.da.name = None
                self.bpy_setter(self.qe_org, undo_push=False)
            m.refresh()
            del tm["is_quick_edit"]
            return

        if isinstance(self.qe_org, list):
            oo = self.w.oo[self.subtype_info[1]].li
            for e in oo:    e.I_off()
            self.bpy_setter(self.qe_value, tm["bu_range"])
        else:
            self.I_off()
            self.bpy_setter(self.qe_value)

        self.da.name = None
        m.upd_enable()
        m.refresh()
        del tm["is_quick_edit"]
    def I_modal_qe(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_qe_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_qe_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_qe_end()
                return

        m.I_pan(evt)
        if self.key_slow(evt):      self.qe_fn(self.R_qe_dx() * self.qe_unit_slow)
        elif self.key_fast(evt):    self.qe_fn(self.R_qe_dx() * self.qe_unit_fast)
        else:                       self.qe_fn(self.R_qe_dx() * self.qe_unit)
        m.loop_mou(evt)
    def I_qe_performance_float(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_performance_int(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(round(self.qe_value))
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        self.bpy_setter(self.qe_value, undo_push=False)
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_real_time_int(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.bpy_setter(v, undo_push=False)
        self.da.text = self.tx_format(v)
    #
    #
class VBOX_SUB(VBOX):
    __slots__ = (
        'multi_oo',
    )
    def R_array(self):
        return self.w.oo[self.subtype_info[1]].li
    def is_to_modal_multi(self, evt, mk):
        try:
            org_y = mk.org_y
            dx = evt.mouse_x - mk.org_x
            dy = evt.mouse_y - org_y
            if abs(dy) > abs(dx):
                org_y += evt.mouse_region_y - evt.mouse_y
                multi_oo = tuple((i, e) for i, e in enumerate(self.R_array()))
                self.multi_oo = multi_oo

                for i, e in multi_oo:
                    if org_y >= e.rim.B:
                        self.qe_bu = e
                        self.qe_value   = e.da.name
                        self.qe_org     = self.qe_value
                        break

                ind = self.qe_bu.subtype_info[2]

                m.tm["ind"] = [ind, multi_oo[-1][1].rim.B, multi_oo[0][1].rim.T, evt.mouse_region_y, ind]
                m.head_modal.append(self.I_modal_multi)
                return True
            return False
        except:
            return False
        #
    def modal_multi_end(self, cancel=False):
        print(f"    bu  VAL  modal_multi_end")
        del m.head_modal[-1]
        m.upd_enable()
        oo = self.R_array()

        if cancel:
            m.EVT.kill()
            m.I_end_pan_hide(self)
        else:
            tm_ind = m.tm["ind"]
            ind_org = tm_ind[0]
            i = tm_ind[4]
            if ind_org > i: ind_org, i = i, ind_org
            tm_ind.clear()
            m.tm["ind"] = [oo[r] for r in range(ind_org, i)]
            tm_ind = m.tm["ind"]
            qe_bu = oo[i]
            self.qe_bu = qe_bu
            self.qe_org = [e.da.name for e in tm_ind]
            self.qe_value = qe_bu.da.name
            self.qe_org.append(self.qe_value)
            for e in tm_ind:
                e.da.name = None
                e.da.text = "     Multiple Editing"

            m.tm["bu_range"] = (ind_org, i + 1)
            qe_bu.fn(multi_edit="custom")

        for e in oo:    e.I_off()
        self.w.to_default_modal()
        #
    def I_modal_multi(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_multi_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_multi_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_multi_end()
                return

        m.I_pan(evt)
        tm_ind = m.tm["ind"]

        if abs(evt.mouse_region_x - m.tm["x"]) >= P.th_multi_drag:
            print("    bu  I_modal_multi  -> multi drag")
            m.loop_mou(evt)
            oo = self.R_array()
            ind_org = tm_ind[0]
            i = tm_ind[4]
            if ind_org > i: ind_org, i = i, ind_org
            tm_ind.clear()
            m.tm["ind"] = [oo[r] for r in range(ind_org, i)]
            self.qe_bu = oo[i]
            self.qe_org = [e.da.name for e in m.tm["ind"]]
            self.qe_value = self.qe_bu.da.name
            self.qe_org.append(self.qe_value)
            m.tm["bu_range"] = (ind_org, i + 1)

            if P.quick_edit_operation == 'REAL_TIME':
                if self.ty[:3] == "flo":
                    self.qe_fn = self.I_qe_real_time_float_multi
                else:
                    self.qe_fn = self.I_qe_real_time_int_multi
            else:
                if self.ty[:3] == "flo":
                    self.qe_fn = self.I_qe_performance_float_multi
                else:
                    self.qe_fn = self.I_qe_performance_int_multi

            del m.head_modal[-1]
            m.tm["bu"] = self.qe_bu
            m.head_modal.append(self.I_modal_qe_multi if m.tm["ind"] else self.I_modal_qe)
            return

        ind_org, B, T, old_y, ind = tm_ind
        tm_ind[3] = min(max(B, old_y + m.dy), T)
        y = tm_ind[3]

        for i, e, in self.multi_oo:
            if y >= e.rim.B:
                tm_ind[4] = i
                if ind_org > i: ind_org, i = i, ind_org
                color_off = P.color_bu_3_off
                color_fo = P.color_bu_3_fo
                for i0, e0 in self.multi_oo:
                    e0.rim.color = color_fo if ind_org <= i0 <= i else color_off
                break

        m.loop_mou(evt)

    def I_qe_performance_float_multi(self, dx):
        self.qe_value += dx
        tx = self.qe_bu.tx_format(self.qe_value)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.da.text = tx
        #
    def I_qe_performance_int_multi(self, dx):
        self.qe_value += dx
        tx = self.qe_bu.tx_format(round(self.qe_value))
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.da.text = tx
        #
    def I_qe_real_time_float_multi(self, dx):
        self.qe_value += dx
        v = self.qe_value
        self.qe_bu.bpy_setter(v, undo_push=False)
        tx = self.qe_bu.tx_format(v)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.bpy_setter(v, undo_push=False)
            e.da.text = tx
        #
    def I_qe_real_time_int_multi(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.qe_bu.bpy_setter(v, undo_push=False)
        tx = self.qe_bu.tx_format(v)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.bpy_setter(v, undo_push=False)
            e.da.text = tx
        #

    def I_modal_qe_multi(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_qe_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_qe_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_qe_end()
                return

        m.I_pan(evt)
        if self.key_slow(evt):      self.qe_fn(self.R_qe_dx() * self.qe_unit_slow)
        elif self.key_fast(evt):    self.qe_fn(self.R_qe_dx() * self.qe_unit_fast)
        else:                       self.qe_fn(self.R_qe_dx() * self.qe_unit)
        m.loop_mou(evt)
        #

    def fn_paste(self):
        print(f"    bu  VBOX_SUB  fn_paste")
        ans = calc_vec(bpy.context.window_manager.clipboard)
        fac = self.R_unit_fac()

        if len(ans) > 1:
            for i, e in enumerate(self.R_array()):
                try:    e.bpy_setter(ans[i] * fac  if fac != 1 else ans[i])
                except: pass
            return
        try:    self.bpy_setter(ans[0] * fac  if fac != 1 else ans[0])
        except: pass
    def fn_cut(self):
        print(f"    bu  VBOX_SUB  fn_cut")
        try:
            fac = self.R_unit_fac()
            s = ""
            for e in self.R_array():
                s += f'{m.R_str_by_float(e.da.name if fac == 1 else e.da.name / fac)}, '

            bpy.context.window_manager.clipboard = s[: -2]
        except: pass

    def rm_init(self, evt):
        super().rm_init(evt, override=[
            {9: "fn_Copy", 0: "Copy"},
            {9: "fn_Copy_Array", 0: "Copy Array"},
            {9: "fn_Paste", 0: "Paste"},
        ])
        #
    def fn_Copy_Array(self):
        self.fn_cut()
    #
    #
class VBOX_SET:
    __slots__ = (
        'w',
        'name',
        'ti_tx',
        'li',
        'li_subtype',
        'is_enable',
        'll',
        'offset_subtype_key',
        'color_subtype',
    )
    def __init__(self,
            w,
            name,
            ti_tx,
            li,
            ll,
            offset_subtype_key  = 10,
        ):
        self.w = w
        self.name = name
        self.ti_tx = ti_tx
        self.li = li
        self.ll = ll
        self.li_subtype = [BLF() for r in range(ll)]
        self.offset_subtype_key = offset_subtype_key

        self.is_enable  = True
        self.color_subtype = P.color_font_darker

    def LRBT(self, L, R, B, T):
        hi = T - B
        _1 = F[1]
        for e, o in zip(self.li, self.li_subtype):
            e.LRBT(L, R, B, T)
            o.xy(L - F[self.offset_subtype_key], e.ti.y)
            T = B - _1
            B = T - hi

    def dxy_upd(self, x, y):
        for e in self.li: e.dxy_upd(x, y)
        for e in self.li_subtype: e.dxy(x, y)
    def set_da(self, vs):
        for e, v in zip(self.li, vs):   e.set_da(v)

    def on(self):
        for e in self.li: e.on()
    def off(self):
        for e in self.li: e.off()
    def fo(self):
        for e in self.li: e.fo()

    def enable(self):
        for e in self.li: e.enable()
        self.color_subtype = P.color_font_darker
        self.is_enable = True
    def disable(self, soft=True):
        for e in self.li: e.disable(soft=soft)
        self.color_subtype = P.color_font_ignore
        self.is_enable = False

    def draw_rim(self): pass
    def draw_bg(self):
        for e in self.li: e.draw_bg()
    def draw_ti(self):
        for e in self.li: e.draw_ti()
        blf_size(font_0, F[8], 72)
        blf_color(font_0, *self.color_subtype)
        for e in self.li_subtype: e.draw_pos()
        blf_size(font_0, F[9], 72)
    #
    #
class TXBOX(VBOX):
    __slots__ = ()
    def set_da(self, s):
        if self.da.name != s:
            blf_size(font_0, F[9], 72)
            self.da.name = s
            self.da.text = self.tx_format(s)
            self.da.fix_long_text(self.rim.R - F[12], F[8])
    def to_modal_qe(self, evt, mk=None): pass
    def fn(self, multi_edit=None):
        tx = self.da.name
        if isinstance(tx, Vector):
            s = ""
            for v in tx:
                s += f'{m.R_str_by_float(v)}, '
            self.da.name = s[:-2]
            dd.DDTX(self)
            self.da.name = tx
            return

        if not isinstance(tx, str):
            self.da.name = f'{tx}'
        dd.DDTX(self)

    def fn_copy(self):
        print(f"    bu  TXBOX  fn_copy")
        tx = self.da.name
        if isinstance(tx, Vector):
            tx = [v for v in tx]
            s = ""
            for v in tx:
                s += f'{m.R_str_by_float(v)}, '
            tx = s[: -2]
        bpy.context.window_manager.clipboard = f"{tx}"
    def fn_paste(self):
        print(f"    bu  TXBOX  fn_paste")
        try:
            if isinstance(self.da.name, Vector):
                self.bpy_setter(bpy.context.window_manager.clipboard)
            else:
                self.bpy_setter(float(bpy.context.window_manager.clipboard))
        except: pass
    #
    #
class BBOX(VBOX):
    __slots__ = 'is_allow'
    def init_end(self):
        self.da_color           = P.color_bu_2
        self.da_color_ignore    = P.color_bu_2_ignore
        self.da.color           = P.color_bu_2
        self.ti.color           = P.color_font
        self.is_allow           = True
    def I_enable(self):
        self.is_enable  = True
        self.inside     = self.I_inside
        self.da.color   = self.da_color
        self.ti.color   = P.color_font
        self.I_off()
        self.enable     = N
        self.disable    = self.I_disable
    def I_disable(self, soft=True):
        mN = N
        self.is_enable  = False
        if soft is False:   self.inside = mN
        self.rim.color  = P.color_bu_3_ignore
        self.da.color   = self.da_color_ignore
        self.ti.color   = P.color_font_ignore
        self.enable     = self.I_enable
        self.disable    = mN
        self.on         = mN
        self.off        = mN
        self.fo         = mN
    def LRBT(self, L, R, B, T): # blf_size
        rim = self.rim
        rim.LRBT(L, R, B, T)
        rim.upd()
        self.offset_x   = F[1.5]
        self.offset_y   = F[self.offset_y_key]
        self.ti.xy(L - F[self.offset_ti_key] - self.ti.R_dimen(), rim.B + self.offset_y)
        self.da.LB(rim, self.offset_x, 0)
    def set_da(self, boo):
        if self.da.name != boo:
            self.da.name = boo
            self.da.text = "■"  if boo else ""

    def I_inside(self, evt):
        self.fo()
        self.is_allow   = True
        self.w.to_modal(self.I_modal_fo)
        self.I_modal_fo(evt)
        m.redraw()
    def I_modal_fo(self, evt):
        if self.w.outside[0] is True:
            self.w.outside[0] = None
            self.off()
            m.redraw()
            self.w.to_default_modal()
            return

        if self.rim.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.to_default_modal()
            return self.w.U_modal(evt)

        if evt.value == 'RELEASE':  self.is_allow = True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            if self.is_allow:
                self.w.RET      = True
                self.is_allow   = False
                self.fn()
                m.redraw()
                return True

        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.w.RET = True
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.w.RET = True
            self.fn_paste()
            return True

    def draw_ti(self):
        self.da.set_color()
        blf_size(font_0, F[22], 72)
        self.da.draw_pos()
        blf_size(font_0, F[9], 72)
        self.ti.draw_color_pos()

    def fn(self):
        if self.da.name is True:
            self.da.name = False
            self.da.text = ""
            self.bpy_setter(False)
        else:
            self.da.name = True
            self.da.text = "■"
            self.bpy_setter(True)
    def fn_copy(self):
        print(f"    bu  BBOX  fn_copy")
        bpy.context.window_manager.clipboard = f"{self.da.name}"
    def fn_paste(self):
        print(f"    bu  BBOX  fn_paste")
        try:    self.bpy_setter(bool(bpy.context.window_manager.clipboard))
        except: pass
    #
    #
class ENUM_SET:
    __slots__ = (
        'w',
        'name',
        'ti',
        'ti_tx',
        'li',
        'is_enable',
        'll',
        'offset_ti_key',
        'ind',
        'is_inside',
        'fn',
    )
    def __init__(self,
            w,
            name,
            ti_tx,
            li,
            ll,
            fn,
            offset_ti_key   = 8,
        ):
        self.w = w
        self.name = name
        self.ti_tx = ti_tx
        self.li = li
        self.ll = ll
        self.is_enable = True
        self.ti = BLF(P.color_font, ti_tx)
        self.offset_ti_key = offset_ti_key
        self.ind = None
        self.is_inside = self.I_is_inside
        self.fn = fn

        for e in li:    e.enum_set = self

    def LRBT(self, L, R, B, T): # blf_size
        d = F[2]
        ll = self.ll
        ti = self.ti
        ti.x = L - F[self.offset_ti_key] - ti.R_dimen()
        bu_wi = (R - L - d * (ll - 1)) // ll

        for e in self.li:
            R1 = L + bu_wi
            e.LRBT(L, R1, B, T)
            L = R1 + d

        ti.y = self.li[0].ti.y

    def dxy_upd(self, x, y):
        self.ti.dxy(x, y)
        for e in self.li:   e.dxy_upd(x, y)

    def draw_bo(self):
        for e in self.li:   e.draw_bo()
    def draw_ti(self):
        self.ti.draw_color_pos()
        for e in self.li:   e.draw_ti()

    def set_da(self, ind):
        if self.ind != ind:
            if ind is None:
                for e in self.li:   e.I_off()
            else:
                li = self.li
                for e in li[: ind]:     e.I_off()
                for e in li[ind + 1 :]: e.I_off()
                li[ind].I_on()

    def I_is_inside(self, evt):
        for e in self.li:
            if e.is_inside(evt):    return True
        return False
    #
    #
class BURE2(BU):
    __slots__ = ()
    def draw_bg(self):
        m.bind_color_bu_1_rim()
        self.rim.draw()
        self.bg.bind_draw()

    def inside(self, evt):
        if self.is_enable:
            self.fo()
            m.redraw()
            self.w.to_modal(self.I_modal_fo)
            self.I_modal_fo(evt)

    def is_inside(self, evt):
        if self.is_enable is False: return False
        return self.rim.inbox(evt)

    def disable(self):
        print(f"    bu  BURE(BU)  disable")
        self.I_off()
        self.w.to_default_modal()
        self.bg.color   = P.color_bu_1_ignore
        self.ti.color   = P.color_font_ignore
        self.is_enable  = False
        m.redraw()
    def enable(self):
        print(f"    bu  BURE(BU)  enable")
        self.I_off()
        self.ti.color   = P.color_font
        self.is_enable  = True
        m.redraw()

    def I_modal_fo(self, evt):
        if self.w.outside[0] is True:
            self.w.outside[0] = None
            self.off()
            m.redraw()
            self.w.to_default_modal()
            return

        if self.rim.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.to_default_modal()
            return False

        if K["rm0"].true() or K["rm1"].true():  self.rm_init(evt) ;return True
        if K["sel_fast0"].true():
            self.on()
            m.redraw()
            self.w.to_modal(self.I_modal_press)
            self.key_end = K["sel0"]
            self.key_end.true()
            self.w.RET = True
            return True
        if K["sel_fast1"].true():
            self.on()
            m.redraw()
            self.w.to_modal(self.I_modal_press)
            self.key_end = K["sel0"]
            self.key_end.true()
            self.w.RET = True
            return True
        return self.base_evt(evt)
    def I_modal_press(self, evt):
        if self.w.outside[0] is True:
            self.w.outside[0] = None
            self.off()
            m.redraw()
            self.w.to_default_modal()
            m.EVT.kill()
            return

        if self.rim.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.to_default_modal()
            return False

        if self.key_end.true():
            self.w.to_modal(self.I_modal_fo)
            self.fo()
            m.redraw()

            if self.is_fin: self.w.fin()
            self.fn()
            return True

    def rm_init(self, evt):
        print(f"    bu  BURE2  rm_init")
        self.w.RET = True
        rm_li = [
        ]
        if self.details is not None:    rm_li.append({9: "fn_Details", 0: "Details"})
        if not rm_li: return
        RM(self, evt.mouse_region_x, evt.mouse_region_y, rm_li)
        #
    def fn_Details(self):
        print("    bu  BURE2  fn_Details")
        evt = m.EVT.evt
        hi = F[150]
        wi = F[480]
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), self.details)
        #