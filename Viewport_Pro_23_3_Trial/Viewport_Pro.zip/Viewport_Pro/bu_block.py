import bpy
from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP
from colorsys import rgb_to_hsv, hsv_to_rgb
from struct import pack as struct_pack

from . import m
from . keys import (
    key_value_to_title,
    key_title_to_value,
    time_keys,
    R_tx_comb,
    value_enums,
    dict_value,
    value_dict,
    key_value_set,
    key_title_set,
    dict_type,
    non_release,
)
from . fn import bin_search, TR_ind, TR_ind_ex, R_str_by_deg, rgb_to_hex, hex_to_rgb, R_rgb_by_str, is_ind_0, R_sign32, R_unsign32
from . dd import DDTX, DDVAL, DD_COLOR
from . filt import FIL
from . rm import RM
from . color_list import L_rgb_to_glc, L_rgb_to_glb, D_null
from . ED_setting.setting_key_edit import KEY_ED
from . calc import calc_vec

P = None
F = None
K = None
BOX = None
BLF = None
BOX_C = None
font_0 = None

color_black = (0.0, 0.0, 0.0, 1.0)
color_white = (1.0, 1.0, 1.0, 1.0)

class SUBTYPE:
    @staticmethod
    def TRANSLATION(ind):
        if ind == 0:    return "X"
        elif ind == 1:  return "Y"
        elif ind == 2:  return "Z"
        else:           return ""
        #


class BU_INT:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'ind',
        'tx_format',
        'attr',
        'setter',
        'bpy_setter',
    )
    def __init__(self, w, prop, ind, is_sub_ti):
        self.w = w
        self.ind = ind
        self.rim = BOX(P.color_bu_3_off)
        self.attr = prop.identifier
        v = getattr(P, self.attr)
        if ind is not None: v = v[ind]
        self.da = BLF(text=m.U_format_i(v))
        self.da.name = v
        if is_sub_ti:  self.ti = BLF(text=getattr(SUBTYPE, prop.subtype)(ind))
        self.tx_format = m.U_format_i
        if prop.is_array:
            self.setter = self.I_setter_array
            self.bpy_setter = self.I_bpy_setter_array
        else:
            self.setter = self.I_setter
            self.bpy_setter = self.I_bpy_setter
        #

    def set_da(self, v): # int
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
        #
    def I_setter(self):
        v = getattr(P, self.attr)
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
        #
    def I_setter_array(self):
        v = getattr(P, self.attr)[self.ind]
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
        #
    def I_bpy_setter(self, v, undo_push=True):
        old_v = getattr(P, self.attr)
        v = round(v)
        setattr(P, self.attr, v)
        if undo_push:
            m.undo_str = f'[Settings] preferences.{self.attr} = {v}'
            m.undo_push(((self.attr, old_v, None),))
        #
    def I_bpy_setter_array(self, v, undo_push=True):
        ind = self.ind
        prop = getattr(P, self.attr)
        old_v = prop[ind]
        v = round(v)
        prop[ind] = v
        if undo_push:
            m.undo_str = f'[Settings] preferences.{self.attr}[{ind}] = {v}'
            m.undo_push(((self.attr, old_v, ind),))
        #
class BU_FLOAT:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'ind',
        'tx_format',
        'attr',
        'setter',
        'bpy_setter',
    )
    def __init__(self, w, prop, ind, is_sub_ti):
        self.w = w
        self.ind = ind
        self.rim = BOX(P.color_bu_3_off)
        self.attr = prop.identifier
        v = getattr(P, self.attr)
        if ind is not None: v = v[ind]
        self.da = BLF(text=m.U_format_f(v))
        self.da.name = v
        if is_sub_ti:   self.ti = BLF(text=getattr(SUBTYPE, prop.subtype)(ind))
        self.tx_format = m.U_format_f
        if prop.is_array:
            self.setter = self.I_setter_array
            self.bpy_setter = self.I_bpy_setter_array
        else:
            self.setter = self.I_setter
            self.bpy_setter = self.I_bpy_setter
        #

    def set_da(self, v):
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
        #
    def I_setter(self):
        v = getattr(P, self.attr)
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
        #
    def I_setter_array(self):
        v = getattr(P, self.attr)[self.ind]
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
        #
    def I_bpy_setter(self, v, undo_push=True):
        old_v = getattr(P, self.attr)
        setattr(P, self.attr, v)
        if undo_push:
            m.undo_str = f'[Settings] preferences.{self.attr} = {v}'
            m.undo_push(((self.attr, old_v, None),))
        #
    def I_bpy_setter_array(self, v, undo_push=True):
        ind = self.ind
        prop = getattr(P, self.attr)
        old_v = prop[ind]
        prop[self.ind] = v
        if undo_push:
            m.undo_str = f'[Settings] preferences.{self.attr}[{ind}] = {v}'
            m.undo_push(((self.attr, old_v, ind),))
        #
class BU_COLOR:
    __slots__ = (
        'w',
        'rim',
        'ind',
        'bo_0',
        'bo_1',
        'bg_black',
        'bg_white',
        # 'da',
    )
    def __init__(self, w, prop, BOX_ty, ind=None):
        self.w = w
        self.rim = BOX(P.color_bu_3_off)
        self.ind = ind
        # self.da = BLF()
        # self.da.name = None

        self.bo_0 = BOX_ty()
        self.bo_1 = BOX_ty()
        self.bg_black = BOX(color_black)
        self.bg_white = BOX(color_white)
        #

    def set_da(self, v):
        pass
        #
    def setter(self):
        pass
        #
    def bpy_setter(self, v, undo_push=True):
        pass
        #
class BU_STR:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'ind',
        'attr',
    )
    def __init__(self, w, prop, ind=None):
        self.w = w
        self.rim = BOX(P.color_bu_3_off)
        self.attr = prop.identifier
        self.ind = ind
        v = getattr(P, self.attr)

        self.da = BLF(text=v)
        self.da.name = v
        #

    def set_da(self, v): # str
        if self.da.name != v:
            self.da.name = v
            self.da.text = v
        #
    def setter(self):
        v = getattr(P, self.attr)
        if self.da.name != v:
            self.da.name = v
            self.da.text = v
        #
    def bpy_setter(self, v, undo_push=True):
        old_v = getattr(P, self.attr)
        setattr(P, self.attr, v)
        if undo_push:
            m.undo_str = f'[Settings] preferences.{self.attr} = {v}'
            m.undo_push(((self.attr, old_v, None),))
        #
class BU_BOOL:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'ind',
        'attr',
        'setter',
        'bpy_setter',
    )
    def __init__(self, w, prop, ind):
        self.w = w
        self.ind = ind
        self.rim = BOX(P.color_bu_3_off)
        self.attr = prop.identifier
        v = getattr(P, self.attr)
        if ind is not None: v = v[ind]
        self.da = BLF(text="■"  if v else "")
        self.da.name = v

        if prop.is_array:
            self.setter = self.I_setter_array
            self.bpy_setter = self.I_bpy_setter_array
        else:
            self.setter = self.I_setter
            self.bpy_setter = self.I_bpy_setter
        #
    def set_da(self, boo):
        if self.da.name != boo:
            self.da.name = boo
            self.da.text = "■"  if boo else ""
        #
    def I_setter(self):
        v = getattr(P, self.attr)
        if self.da.name != v:
            self.da.name = v
            self.da.text = "■"  if v else ""
        #
    def I_setter_array(self):
        v = getattr(P, self.attr)[self.ind]
        if self.da.name != v:
            self.da.name = v
            self.da.text = "■"  if v else ""
        #
    def I_bpy_setter(self, v, undo_push=True):
        old_v = getattr(P, self.attr)
        setattr(P, self.attr, v)
        if undo_push:
            m.undo_str = f'[Settings] preferences.{self.attr} = {v}'
            m.undo_push(((self.attr, old_v, None),))
        #
    def I_bpy_setter_array(self, v, undo_push=True):
        ind = self.ind
        prop = getattr(P, self.attr)
        old_v = prop[ind]
        prop[ind] = v
        if undo_push:
            m.undo_str = f'[Settings] preferences.{self.attr}[{ind}] = {v}'
            m.undo_push(((self.attr, old_v, ind),))
        #
class BU_ENUM:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'ind',
        'attr',
        'enums',
    )
    def __init__(self, w, prop):
        self.w = w
        self.ind = None
        self.rim = BOX(P.color_bu_3_off)
        self.attr = prop.identifier
        self.enums = prop.enum_items

        self.da = BLF()
        self.da.name = None
        #
    def set_da(self, v):
        if self.da.name != v:
            blf_size(font_0, F[9], 72)
            self.da.name = v
            self.da.text = self.enums[v].name
            self.da.fix_long_text(self.rim.R - F[12], F[8])
        #
    def setter(self):
        v = getattr(P, self.attr)
        if self.da.name != v:
            blf_size(font_0, F[9], 72)
            self.da.name = v
            self.da.text = self.enums[v].name
            self.da.fix_long_text(self.rim.R - F[12], F[8])
        #
    def bpy_setter(self, v, undo_push=True):
        old_v = getattr(P, self.attr)

        dic_name_ind = {e.name : e.identifier  for e in self.enums}
        if v in dic_name_ind:   v = dic_name_ind[v]

        try:
            setattr(P, self.attr, v)
            if undo_push:
                m.undo_str = f'[Settings] preferences.{self.attr} = {v}'
                m.undo_push(((self.attr, old_v, None),))
        except: pass
        #

class BU_FLOAT_SIM:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'ind',
        'tx_format',
        'prop',
        'dxy',
        'setter',
    )
    def __init__(self, w, prop, ind, is_sub_ti, setter=None):
        self.w = w
        self.ind = ind
        self.rim = BOX(P.color_bu_3_off)

        if ind is None:
            self.prop = None
            v = prop
        else:
            self.prop = prop
            v = prop[ind]

        self.da = BLF(text=m.U_format_f(v))
        self.da.name = v
        if is_sub_ti:
            self.ti = BLF(text=is_sub_ti)
            self.dxy = self.I_dxy_2
        else:
            self.dxy = self.I_dxy
        self.tx_format = m.U_format_f
        self.setter = self.I_setter  if setter is None else setter
        #

    def I_dxy_2(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)
    def I_dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)
    def unfocus(self):
        self.rim.color = P.color_bu_3_off
    def focus(self):
        self.rim.color = P.color_bu_3_fo

    def set_da(self, v):
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
    def I_setter(self):
        if self.prop is None: return
        v = self.prop[self.ind]
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
    def bpy_setter(self, v, undo_push=None):
        if self.prop is None:
            self.set_da(v)
            return
        # v_min, v_max = self.w.min_max
        # v = min(max(v, v_min), v_max)
        self.prop[self.ind] = v
        self.da.name = v
        self.da.text = self.tx_format(v)
class BU_STR_SIM:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'ind',
        'dxy',
        'is_read_only',
    )
    def __init__(self, w, prop, ind, is_sub_ti, is_read_only=False):
        self.w = w
        self.ind = ind
        self.rim = BOX(P.color_bu_3_off)
        self.is_read_only = is_read_only

        v = prop  if ind is None else prop[ind]
        self.da = BLF(text=v)
        if is_sub_ti:
            self.ti = BLF(text=is_sub_ti)
            self.dxy = self.I_dxy_2
        else:
            self.dxy = self.I_dxy
        #

    def I_dxy_2(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)
    def I_dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)
    def unfocus(self):
        self.rim.color = P.color_bu_3_off
    def focus(self):
        self.rim.color = P.color_bu_3_fo

    def set_da(self, v):
        if self.is_read_only: return
        self.da.text = v
    def setter(self): pass
    def bpy_setter(self, v, undo_push=None):
        if self.is_read_only: return
        self.da.text = v
class BU_BOOL_SIM:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'ind',
        'dxy',
        'is_allow',
    )
    def __init__(self, w, prop, ind, is_sub_ti):
        self.w = w
        self.ind = ind
        self.rim = BOX(P.color_bu_3_off)
        self.is_allow = True

        v = prop  if ind is None else prop[ind]
        self.da = BLF(text="■"  if v else "")
        self.da.name = v
        if is_sub_ti:
            self.ti = BLF(text=is_sub_ti)
            self.dxy = self.I_dxy_2
        else:
            self.dxy = self.I_dxy
        #

    def I_dxy_2(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)
    def I_dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)
    def unfocus(self):
        self.rim.color = P.color_bu_3_off
        self.is_allow = True
    def focus(self):
        self.rim.color = P.color_bu_3_fo

    def set_da(self, boo):
        if self.da.name != boo:
            self.da.name = boo
            self.da.text = "■"  if boo else ""
    def setter(self): pass
    def bpy_setter(self, boo, undo_push=None):
        if self.da.name != boo:
            self.da.name = boo
            self.da.text = "■"  if boo else ""
class BU_HEX:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'tx_format',
    )
    def __init__(self, w, is_sub_ti):
        self.w = w
        self.rim = BOX(P.color_bu_3_off)
        self.tx_format = m.U_format_h

        self.da = BLF()
        self.da.name = None
        if is_sub_ti:   self.ti = BLF(text=is_sub_ti)
        #

    def set_da(self, v):
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
    def setter(self): pass
    def bpy_setter(self, v, undo_push=None):
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)

class BU_FLOAT_SIM_HSV(BU_FLOAT_SIM):
    __slots__ = ()
    def I_setter(self):
        v = self.prop[self.ind]
        if self.da.name != v:
            self.da.name = v
            self.da.text = self.tx_format(v)
    def bpy_setter(self, v, undo_push=None):
        v = min(max(v, 0.0), 1.0)
        prop = self.prop
        prop[self.ind] = v
        self.da.name = v
        self.da.text = self.tx_format(v)
        self.w.w.color[:-1] = hsv_to_rgb(*prop)
class BU_PICK_COLOR:
    __slots__ = (
        'w',
        'rim',
        'bo',
        'ti',
        'draw_rim',
        'draw_bo',
        'draw_ti',
    )
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        self.bo = BOX(P.color_bu_1_off)
        self.ti = BLF(P.color_font, "⊕")

        self.draw_rim = self.rim.draw
        self.draw_bo = self.bo.bind_draw
        self.draw_ti = self.ti.draw_pos

    def get_unfocus(self):
        e = self.rim
        L = e.L + F[1]
        B = e.B
        self.bo.LRBT_upd(L, e.R, B, e.T - F[1])
        self.ti.xy(L + F[3], B + F[4.5])
    def get_on(self):
        e = self.rim
        L = e.L
        B = e.B + F[1]
        self.bo.LRBT_upd(L, e.R - F[1], B, e.T)
        self.ti.xy(L + F[3], B + F[4.5])
class BU_FNDA:
    __slots__ = (
        'w',
        'rim',
        'bo',
        'ti',
        'da',
        'draw_rim',
        'draw_bo',
        'fn',
    )
    def __init__(self, w, ti, ti_name=None, fn=None):
        self.w = w
        self.rim = BOX()
        self.bo = BOX(P.color_bu_1_off)
        self.ti = BLF(text=ti)
        self.ti.name = ti_name
        self.da = BLF()
        self.fn = fn

        self.draw_rim = self.rim.draw
        self.draw_bo = self.bo.bind_draw

    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bo.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)
    def unfocus(self):
        if self.bo.color != P.color_bu_1_off:
            self.bo.color = P.color_bu_1_off
            dx = self.ti.x - self.bo.L
            dy = self.ti.y - self.bo.B
            r = self.rim
            L = r.L + F[1]
            B = r.B
            self.bo.LRBT_upd(L, r.R, B, r.T - F[1])
            self.ti.xy(L + dx, B + dy)
    def focus(self):
        if self.bo.color != P.color_bu_1_fo:
            self.bo.color = P.color_bu_1_fo
            dx = self.ti.x - self.bo.L
            dy = self.ti.y - self.bo.B
            r = self.rim
            L = r.L + F[1]
            B = r.B
            self.bo.LRBT_upd(L, r.R, B, r.T - F[1])
            self.ti.xy(L + dx, B + dy)
    def on(self):
        if self.bo.color != P.color_bu_1_on:
            self.bo.color = P.color_bu_1_on
            dx = self.ti.x - self.bo.L
            dy = self.ti.y - self.bo.B
            r = self.rim
            L = r.L
            B = r.B + F[1]
            self.bo.LRBT_upd(L, r.R - F[1], B, r.T)
            self.ti.xy(L + dx, B + dy)

    def setter(self): pass
    def draw_ti(self):
        self.ti.draw_pos()
        self.da.draw_pos()


# ▅▅▅  BLOCK                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
class VAL:
    __slots__ = (
        'w',
        'prop',
        'ty',
        'rim',
        'ti',
        'da',
        'oo',
        'hi',
        'draw_da',
        'draw_oo_ti',
        'tx_wi',
        'dxy',
        'get_bo',
        'oo_fo',
        'key_end',
        'key_slow',
        'key_fast',
        'R_qe_dx',
        'qe_value',
        'qe_org',
        'qe_unit',
        'qe_unit_slow',
        'qe_unit_fast',
        'qe_fn',
        'qe_bu',
        'multi_oo',
    )
    #
    def __init__(self, w, prop, cls_ty, subtype): # blf_size(font_0, F[8], 72), blf_wrap
        self.w = w
        self.prop = prop
        self.oo_fo = None
        hard_min = prop.hard_min
        hard_max = prop.hard_max
        if hard_min == 0.0: hard_min = "0"
        if hard_max == 1.0: hard_max = "1"
        self.ty = f'{prop.type.lower()} [{hard_min},{hard_max}]'

        self.rim = BOX()
        self.ti = BLF(text=prop.name)
        self.da = BLF(text=prop.description)
        if subtype == "NONE":
            is_sub_ti = False
            self.dxy = self.I_dxy
            self.get_bo = self.I_get_bo
            self.draw_oo_ti = self.I_draw_oo_noti
        else:
            is_sub_ti = True
            self.dxy = self.I_dxy_sub_ti
            self.get_bo = self.I_get_bo_sub_ti
            self.draw_oo_ti = self.I_draw_oo_ti

        if prop.is_array:
            ll = prop.array_length
            self.oo = [cls_ty(self, prop, i, is_sub_ti) for i in range(ll)]
            self.hi = F[7] + (F[16] + F[1]) * ll + F[6]
        else:
            self.oo = [cls_ty(self, prop, None, is_sub_ti)]
            self.hi = F[38]

        dimen_y = self.da.R_dimen_y()
        if dimen_y > F[8]:
            self.draw_da = self.I_draw_da_wrap
            self.hi = max(F[38] + dimen_y - F[7], self.hi)
            self.tx_wi = w.tx_wi
        else:
            self.draw_da = self.I_draw_da
        #

    def get_custom_subtype(self, lis):
        self.dxy = self.I_dxy_sub_ti
        self.get_bo = self.I_get_bo_sub_ti
        self.draw_oo_ti = self.I_draw_oo_ti

        for o, tx in zip(self.oo, lis):
            o.ti = BLF(text=tx)
        #

    def I_get_bo(self, L, R, T): # blf_size(font_0, F[8], 72)
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])

        _1 = F[1]
        hi = F[16]
        R -= F[6]
        T -= F[7]
        B = T - hi
        L = R - F[101]

        for e in self.oo:
            rim = e.rim
            rim.LRBT_upd(L, R, B, T)
            e.da.LB(rim, F[12], F[4.9])

            T = B - _1
            B = T - hi
        #
    def I_get_bo_sub_ti(self, L, R, T): # blf_size(font_0, F[8], 72)
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])

        _1 = F[1]
        hi = F[16]
        R -= F[6]
        T -= F[7]
        B = T - hi
        L = R - F[101]
        L0 = L - F[4]
        for e in self.oo:
            rim = e.rim
            rim.LRBT_upd(L, R, B, T)

            e.da.LB(rim, F[12], F[4.9])

            ti = e.ti
            ti.y = e.da.y
            ti.align_R_float(L0)

            T = B - _1
            B = T - hi
        #

    def I_dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

        for e in self.oo:
            e.rim.dxy_upd(x, y)
            e.da.dxy(x, y)
        #
    def I_dxy_sub_ti(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

        for e in self.oo:
            e.rim.dxy_upd(x, y)
            e.da.dxy(x, y)
            e.ti.dxy(x, y)
        #

    def draw_oo_bool(self): pass
    def draw_bo(self):
        self.rim.draw()
        #
    def draw_oo_bo(self):
        for e in self.oo:   e.rim.bind_draw()
        #
    def draw_ti(self):
        self.ti.draw_pos()
        #
    def I_draw_da(self):
        self.da.draw_pos()
        #
    def I_draw_da_wrap(self):
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.tx_wi)
        self.da.draw_pos()
        blf_disable(font_0, WORD_WRAP)
        #
    def draw_oo_da(self):
        for e in self.oo:   e.da.draw_pos()
        #
    def I_draw_oo_ti(self):
        for e in self.oo:   e.ti.draw_pos()
        #
    def I_draw_oo_noti(self): pass
    def unfocus(self):
        if self.oo_fo is not None:
            print(f"    bu_block  VAL  unfocus")
            self.oo_fo.rim.color = P.color_bu_3_off
            self.oo_fo = None
            m.redraw()
        #
    def focus_oo(self, x, y):
        color_off = P.color_bu_3_off
        color_fo = P.color_bu_3_fo
        for e in self.oo:
            if e.rim.inbox_xy(x, y):
                e.rim.color = color_fo
                self.oo_fo = e
            else:
                e.rim.color = color_off
    def unfocus_all(self):
        color_off = P.color_bu_3_off
        for e in self.oo:   e.rim.color = color_off
        self.oo_fo = None

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.rim.in_BT_y(y) is False:
            self.unfocus()
            return False

        fo = None
        if self.oo[0].rim.in_LR_x(x):
            for e in self.oo:
                if e.rim.in_BT_y(y):
                    fo = e
                    if self.oo_fo is None:
                        self.oo_fo = e
                        e.rim.color = P.color_bu_3_fo
                        m.redraw()
                    elif self.oo_fo != e:
                        self.oo_fo.rim.color = P.color_bu_3_off
                        self.oo_fo = e
                        e.rim.color = P.color_bu_3_fo
                        m.redraw()
                    break
        if fo is not None:
            if K["bu_qe0"].true():
                self.key_end = K["bu_qe_E0"]
                self.to_modal_qe(evt, fo, K["bu_qe0"])
                return True
            if K["bu_qe1"].true():
                self.key_end = K["bu_qe_E1"]
                self.to_modal_qe(evt, fo, K["bu_qe1"])
                return True
            if K["bu_sel0"].true() or K["bu_sel1"].true():
                self.fn(fo)
                return True
            if K["rm0"].true() or K["rm1"].true():
                self.fn_rm(evt, fo)
                return True
            if K["dd_copy0"].true() or K["dd_copy1"].true():
                self.fn_copy(fo)
                return True
            if K["dd_paste0"].true() or K["dd_paste1"].true():
                self.fn_paste(fo)
                return True
            if K["dd_cut0"].true() or K["dd_cut1"].true():
                self.fn_cut(fo)
                return True
            if K["bu_reset0"].true() or K["bu_reset1"].true():
                self.fn_reset(fo)
                return True
        else:
            self.unfocus()
        return False
        #

    def R_attr(self): # tm["o"]
        prop = self.prop
        if "o" in m.tm:
            ind = m.tm["o"].ind
            is_group = isinstance(prop, tuple)
            if is_group: prop = prop[ind]
        return prop.identifier

    def fn(self, o, multi_edit=None, local_undo=None):

        def end_fn():
            m.refresh()
            self.unfocus_all()
            m.admin.push_modal()
            if multi_edit is not None:
                for e in multi_edit:    e.setter()
            self.dd_end_upd(o)

        DDVAL(o, self.ty,
            end_fn      = end_fn,
            multi_edit  = multi_edit,
            local_undo  = local_undo)
        #
    def fn_rm(self, evt, o):
        print(f"    bu_block  VAL  fn_rm")
        global tm
        tm = m.tm

        if o is None:
            print("TODO")
            return
        else:
            if hasattr(self, "prop") and self.prop is not None:
                prop = self.prop
                ind = o.ind
                is_group = isinstance(prop, tuple)
                if is_group: prop = prop[ind]
                v = getattr(P, prop.identifier)
                if is_ind_0(v) and not isinstance(v, str):
                    li = [
                        {9: "rm_Copy_Value", 0: "Copy Value"},
                        {9: "rm_Copy_Array", 0: "Copy Array"},
                        {9: "rm_Paste_Value", 0: "Paste Value"},
                        {9: "rm_Reset_to_Default_Value", 0: "Reset to Default Value"},
                    ]
                else:
                    li = [
                        {9: "rm_Copy_Value", 0: "Copy Value"},
                        {9: "rm_Paste_Value", 0: "Paste Value"},
                        {9: "rm_Reset_to_Default_Value", 0: "Reset to Default Value"},
                    ]
            else:
                li = [
                    {9: "rm_Copy_Value", 0: "Copy Value"},
                ]

        tm["o"] = o
        tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y, li)
        #
    def fn_copy(self, o):
        print(f"    bu_block  VAL  fn_copy")
        global tm
        tm = m.tm
        tm["o"] = o
        self.rm_Copy_Value()
    def fn_cut(self, o):
        print(f"    bu_block  VAL  fn_cut")
        global tm
        tm = m.tm
        tm["o"] = o
        self.rm_Copy_Array()
    def fn_paste(self, o):
        print(f"    bu_block  VAL  fn_paste")
        global tm
        tm = m.tm
        tm["o"] = o
        self.rm_Paste_Value()
        m.redraw()
    def fn_reset(self, o):
        print(f"    bu_block  VAL  fn_reset")
        global tm
        tm = m.tm
        tm["o"] = o
        self.rm_Reset_to_Default_Value()
        m.redraw()

    def rm_Copy_Value(self):
        try:
            print(f"    bu_block  VAL  rm_Copy_Value")

            v = getattr(P, self.R_attr())
            if is_ind_0(v): v = v[m.tm["o"].ind]

            bpy.context.window_manager.clipboard = m.R_str_by_float(v) if isinstance(v, float) else f"{v}"
        except: pass
    def rm_Copy_Array(self):
        try:
            print(f"    bu_block  VAL  rm_Copy_Array")

            v = getattr(P, self.R_attr())
            if is_ind_0(v):
                s = ""
                for e in v: s += f'{m.R_str_by_float(e)}, ' if isinstance(e, float) else f"{e}, "
                bpy.context.window_manager.clipboard = s[: -2]
            else:
                bpy.context.window_manager.clipboard = m.R_str_by_float(v) if isinstance(v, float) else f"{v}"
        except: pass
    def rm_Paste_Value(self):
        try:
            print(f"    bu_block  VAL  rm_Paste_Value")
            ind = tm["o"].ind
            prop = self.prop
            is_group = isinstance(prop, tuple)
            if is_group: prop = prop[ind]
            attr = prop.identifier
            ty = prop.type
            v = calc_vec(bpy.context.window_manager.clipboard)
            if isinstance(v, str):  return

            old_v = getattr(P, attr)
            if is_ind_0(old_v):
                array = old_v
                ll_v = len(v)

                if ll_v > 1:
                    ll = len(array)
                    old_v = tuple(array)
                    if ty == "INT": v = [round(e) for e in v]

                    for r in range(ll):
                        if r >= ll_v:   break
                        array[r] = v[r]

                    ind = (0, ll)
                    m.undo_str = f'[Settings] preferences.{attr}[:] = {[e for e in array]}'
                else:
                    old_v = array[ind]
                    v = round(v[0]) if ty == "INT" else v[0]
                    array[ind] = v
                    m.undo_str = f'[Settings] preferences.{attr}[{ind}] = {v}'
            else:
                v = round(v[0]) if ty == "INT" else v[0]
                setattr(P, attr, v)
                m.undo_str = f'[Settings] preferences.{attr} = {v}'
                ind = None

            m.refresh()
            m.undo_push(((attr, old_v, ind),))
        except: pass
    def rm_Reset_to_Default_Value(self):
        print(f"    bu_block  VAL  rm_Reset_to_Default_Value")
        ind = tm["o"].ind
        prop = self.prop
        is_group = isinstance(prop, tuple)
        if is_group: prop = prop[ind]
        attr = prop.identifier

        if ind is None or is_group:
            if hasattr(prop, "is_array") and prop.is_array:
                v = prop.default_array
                array = getattr(P, attr)
                old_v = tuple(array)
                array[:] = v
                m.undo_str = f'[Settings] preferences.{attr}[:] = {tuple(v)}'
                m.refresh()
                m.undo_push(((attr, old_v, (0, len(old_v))),))
                return

            v = prop.default
            old_v = getattr(P, attr)
            setattr(P, attr, v)
            m.undo_str = f'[Settings] preferences.{attr} = {v}'
            ind = None
        else:
            v = prop.default_array[ind]
            array = getattr(P, attr)
            old_v = array[ind]
            array[ind] = v
            m.undo_str = f'[Settings] preferences.{attr}[{ind}] = {v}'

        m.refresh()
        m.undo_push(((attr, old_v, ind),))

    def is_alt(self, evt):    return evt.alt
    def is_ctrl(self, evt):   return evt.ctrl
    def is_shift(self, evt):  return evt.shift
    def is_oskey(self, evt):  return evt.oskey
    def NF(self, evt):        return False
    def IR_dx(self):    return m.dx
    def IR_dy(self):    return m.dy
    def R_multi_oo(self, qe_bu):
        return tuple((i, e) for i, e in enumerate(self.oo))

    def is_to_modal_multi(self, evt, mk):
        try:
            org_y = mk.org_y
            dx = evt.mouse_x - mk.org_x
            dy = evt.mouse_y - org_y
            if abs(dy) > abs(dx):
                oo = self.oo
                org_y += evt.mouse_region_y - evt.mouse_y
                multi_oo = self.R_multi_oo(self.qe_bu)
                self.multi_oo = multi_oo

                for i, e in multi_oo:
                    if org_y >= e.rim.B:
                        self.qe_bu = e
                        self.qe_value   = e.da.name
                        self.qe_org     = self.qe_value
                        break

                ind = oo.index(self.qe_bu)

                m.tm["ind"] = [ind, multi_oo[-1][1].rim.B, multi_oo[0][1].rim.T, evt.mouse_region_y, ind]
                m.head_modal.append(self.I_modal_multi)
                return True
            return False
        except:
            return False
        #
    def modal_multi_end(self, cancel=False):
        print(f"    bu_block  VAL  modal_multi_end")
        del m.head_modal[-1]
        m.upd_enable()

        if cancel:
            m.EVT.kill()
            m.I_end_pan_hide(self)
        else:
            oo = self.oo
            tm_ind = m.tm["ind"]
            ind_org = tm_ind[0]
            i = tm_ind[4]
            if ind_org > i: ind_org, i = i, ind_org
            tm_ind.clear()
            m.tm["ind"] = [oo[r] for r in range(ind_org, i)]
            tm_ind = m.tm["ind"]
            qe_bu = oo[i]
            self.qe_bu = qe_bu
            self.qe_org = [e.da.name for e in tm_ind]
            self.qe_value = qe_bu.da.name
            self.qe_org.append(self.qe_value)
            for e in tm_ind:
                e.da.name = None
                e.da.text = "  Multiple Editing"
            print("    bu_block  modal_multi_end:  ind_org={ind_org}")

            if hasattr(qe_bu, "attr"):
                attr = qe_bu.attr
                m.undo_str = f'[Settings] preferences.{attr} Multi Edit'
                lis = [oo[r] for r in range(ind_org, i + 1)]
                li_push = [(attr, o, oo.index(e)) for e, o in zip(lis, self.qe_org)]
                self.fn(qe_bu, tm_ind, tuple(li_push))
            else:
                self.fn(qe_bu, tm_ind)

        self.unfocus_all()
        m.admin.push_modal()
        #
    def I_modal_multi(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_multi_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_multi_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_multi_end()
                return

        m.I_pan(evt)
        tm_ind = m.tm["ind"]

        if abs(evt.mouse_region_x - m.tm["x"]) >= P.th_multi_drag:
            print("    bu_block  I_modal_multi  -> multi drag")
            m.loop_mou(evt)
            ind_org = tm_ind[0]
            i = tm_ind[4]
            if ind_org > i: ind_org, i = i, ind_org
            tm_ind.clear()
            m.tm["ind"] = [self.oo[r] for r in range(ind_org, i)]
            self.qe_bu = self.oo[i]
            self.qe_org = [e.da.name for e in m.tm["ind"]]
            self.qe_value = self.qe_bu.da.name
            self.qe_org.append(self.qe_value)

            if P.quick_edit_operation == 'REAL_TIME':
                if isinstance(self.qe_bu, BU_INT):
                    self.qe_fn = self.I_qe_real_time_int_multi
                else:
                    self.qe_fn = self.I_qe_real_time_float_multi
            else:
                if isinstance(self.qe_bu, BU_INT):
                    self.qe_fn = self.I_qe_performance_int_multi
                else:
                    self.qe_fn = self.I_qe_performance_float_multi

            del m.head_modal[-1]
            m.head_modal.append(self.I_modal_qe_multi if m.tm["ind"] else self.I_modal_qe)
            return

        ind_org, B, T, old_y, ind = tm_ind
        tm_ind[3] = min(max(B, old_y + m.dy), T)
        y = tm_ind[3]

        for i, e, in self.multi_oo:
            if y >= e.rim.B:
                tm_ind[4] = i
                if ind_org > i: ind_org, i = i, ind_org
                color_off = P.color_bu_3_off
                color_fo = P.color_bu_3_fo
                for i0, e0 in self.multi_oo:
                    e0.rim.color = color_fo if ind_org <= i0 <= i else color_off
                break

        m.loop_mou(evt)
        #
    def to_modal_qe(self, evt, bu, mk):
        print(f"    bu_block  VAL  to_modal_qe")
        self.key_end.true()
        m.upd_disable()

        r = m.region_data
        m.get_loop_mou_info_region(evt, r.L, r.R, r.B, r.T)
        m.get_mou(evt)
        tm = m.tm
        tm["x"] = evt.mouse_x
        tm["y"] = evt.mouse_y
        try:    m.M.set_mou_ic(P.quick_edit_cursor)
        except: pass

        self.R_qe_dx = self.IR_dx if P.quick_edit_method == 'HORIZONTAL' else self.IR_dy
        dic = m.dic_hold_key
        slow0 = K["bu_qe_slow0"].type0
        self.key_slow = getattr(self, f"is_{dic[slow0]}") if slow0 in dic else self.NF
        fast0 = K["bu_qe_fast0"].type0
        self.key_fast = getattr(self, f"is_{dic[fast0]}") if fast0 in dic else self.NF

        if P.quick_edit_operation == 'REAL_TIME':
            if isinstance(bu, BU_INT):
                self.qe_fn = self.I_qe_real_time_int
            else:
                self.qe_fn = self.I_qe_real_time_float
        else:
            if isinstance(bu, BU_INT):
                self.qe_fn = self.I_qe_performance_int
            else:
                self.qe_fn = self.I_qe_performance_float

        self.qe_value   = bu.da.name
        self.qe_org     = self.qe_value
        prop = self.prop

        self.qe_unit = getattr(P, f'{m.R_calc_attr(self.ty)}qe')
        self.qe_unit_slow = P.quick_edit_fac_slow * self.qe_unit
        self.qe_unit_fast = P.quick_edit_fac_fast * self.qe_unit
        self.qe_bu = bu

        if len(self.oo) != 1:
            if self.is_to_modal_multi(evt, mk): return

        m.head_modal.append(self.I_modal_qe)
        #
    def modal_qe_end(self, cancel=False):
        print(f"    bu_block  modal_qe_end:  cancel={cancel}")
        m.tm["is_dd_confirm"] = not cancel
        v = self.qe_value
        is_multi_edit = m.head_modal[-1] == self.I_modal_qe_multi

        del m.head_modal[-1]
        m.EVT.kill()
        m.I_end_pan_hide(self)
        self.unfocus_all()
        m.admin.push_modal()

        bu = self.qe_bu
        if cancel:
            m.upd_enable()
            if is_multi_edit:
                print("    bu_block  modal_qe_end  restore multi")
                m.tm["ind"].append(bu)
                for e, o in zip(m.tm["ind"], self.qe_org):
                    e.da.name = None
                    e.bpy_setter(o, undo_push=False)
            else:
                bu.da.name = None
                bu.bpy_setter(self.qe_org, undo_push=False)
            m.refresh()
            self.dd_end_upd(bu)
            return

        if P.quick_edit_operation != 'REAL_TIME':
            bu.bpy_setter(round(v)  if isinstance(bu, BU_INT) else v, undo_push=False)

        if hasattr(bu, "attr") is False:
            print("    bu_block  modal_qe_end  no attr")
            bu.da.name = None
            bu.setter()
            if is_multi_edit:
                for e in m.tm["ind"]:
                    e.da.name = None
                    e.setter()

            m.upd_enable()
            self.dd_end_upd(bu)
            return

        if is_multi_edit:
            print("    bu_block  modal_qe_end  Multi qe End")
            oo = self.oo
            tm_ind = m.tm["ind"]
            ind_a = oo.index(tm_ind[0])
            ind_b = oo.index(tm_ind[-1])
            m.undo_str = f'[Settings] preferences.{bu.attr}[{ind_a} : {ind_b + 1}] Multi Edit'

            if P.quick_edit_operation != 'REAL_TIME':
                if isinstance(bu, BU_INT):
                    for e in tm_ind:
                        e.bpy_setter(round(v), undo_push=False)
                else:
                    for e in tm_ind:
                        e.bpy_setter(v, undo_push=False)
        else:
            if bu.ind is None:
                m.undo_str = f'[Settings] preferences.{bu.attr} = {v}'
            else:
                m.undo_str = f'[Settings] preferences.{bu.attr}[{bu.ind}] = {v}'

        bu.da.name = None
        m.upd_enable()
        m.refresh()
        if is_multi_edit:
            m.tm["ind"].append(bu)
            attr = bu.attr
            oo = self.oo
            m.undo_push(tuple((attr, o, oo.index(e)) for e, o in zip(m.tm["ind"], self.qe_org)))
        else:
            m.undo_push(((bu.attr, self.qe_org, self.oo.index(bu)),))
        self.dd_end_upd(bu)
        #
    def I_modal_qe(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_qe_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_qe_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_qe_end()
                return

        m.I_pan(evt)
        if self.key_slow(evt):      self.qe_fn(self.R_qe_dx() * self.qe_unit_slow)
        elif self.key_fast(evt):    self.qe_fn(self.R_qe_dx() * self.qe_unit_fast)
        else:                       self.qe_fn(self.R_qe_dx() * self.qe_unit)
        m.loop_mou(evt)
        #
    def I_modal_qe_multi(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_qe_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_qe_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_qe_end()
                return

        m.I_pan(evt)
        if self.key_slow(evt):      self.qe_fn(self.R_qe_dx() * self.qe_unit_slow)
        elif self.key_fast(evt):    self.qe_fn(self.R_qe_dx() * self.qe_unit_fast)
        else:                       self.qe_fn(self.R_qe_dx() * self.qe_unit)
        m.loop_mou(evt)
        #
    def I_qe_performance_float(self, dx):
        self.qe_value += dx
        self.qe_bu.da.text = self.qe_bu.tx_format(self.qe_value)
        #
    def I_qe_performance_int(self, dx):
        self.qe_value += dx
        self.qe_bu.da.text = self.qe_bu.tx_format(round(self.qe_value))
        #
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        self.qe_bu.bpy_setter(self.qe_value, undo_push=False)
        self.qe_bu.da.text = self.qe_bu.tx_format(self.qe_value)
        #
    def I_qe_real_time_int(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.qe_bu.bpy_setter(v, undo_push=False)
        self.qe_bu.da.text = self.qe_bu.tx_format(v)
        #

    def I_qe_performance_float_multi(self, dx):
        self.qe_value += dx
        tx = self.qe_bu.tx_format(self.qe_value)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.da.text = tx
        #
    def I_qe_performance_int_multi(self, dx):
        self.qe_value += dx
        tx = self.qe_bu.tx_format(round(self.qe_value))
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.da.text = tx
        #
    def I_qe_real_time_float_multi(self, dx):
        self.qe_value += dx
        v = self.qe_value
        self.qe_bu.bpy_setter(v, undo_push=False)
        tx = self.qe_bu.tx_format(v)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.bpy_setter(v, undo_push=False)
            e.da.text = tx
        #
    def I_qe_real_time_int_multi(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.qe_bu.bpy_setter(v, undo_push=False)
        tx = self.qe_bu.tx_format(v)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.bpy_setter(v, undo_push=False)
            e.da.text = tx
        #

    def dd_end_upd(self, e): pass
class COLOR(VAL):
    __slots__ = 'color', 'draw_oo_bo', 'space'
    #
    def __init__(self, w, prop): # blf_size(font_0, F[8], 72), blf_wrap
        self.w = w
        self.prop = prop
        self.oo_fo = None
        self.color = getattr(P, prop.identifier)
        step = prop.step
        if step == -2.200000047683716:
            self.space = "GLSL-C"
            BOX_ty = BOX_C
        elif step == -1.0:
            self.space = "GLSL-B"
            BOX_ty = BOX
        else:
            self.space = "DEFAULT"

        print(f"    bu_block  COLOR  __init__:  space={self.space}, step={step}")
        self.draw_oo_bo = self.I_draw_oo_bo_3 if prop.array_length == 3 else self.I_draw_oo_bo_4
        hard_min = prop.hard_min
        hard_max = prop.hard_max
        if hard_min == 0.0: hard_min = "0"
        if hard_max == 1.0: hard_max = "1"
        self.ty = f'float [{hard_min},{hard_max}]'

        self.rim = BOX()
        self.ti = BLF(text=prop.name)
        self.da = BLF(text=prop.description)

        self.oo = [BU_COLOR(self, prop, BOX_ty)]
        self.hi = F[38]

        dimen_y = self.da.R_dimen_y()
        if dimen_y > F[8]:
            self.draw_da = self.I_draw_da_wrap
            self.hi = max(self.hi + dimen_y - F[7], self.hi)
            self.tx_wi = w.tx_wi
        else:
            self.draw_da = self.I_draw_da
        #

    def get_bo(self, L, R, T): # blf_size(font_0, F[8], 72)
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])

        _1 = F[1]
        hi = F[16]
        h = hi - _1 - _1
        R -= F[6]
        T -= F[7]
        B = T - hi
        L = R - F[101]
        L0 = L + _1
        R1 = R - _1
        L2 = R1 - hi
        L1 = L2 - hi
        B0 = B + _1
        T0 = T - _1

        e = self.oo[0]
        rim = e.rim
        rim.LRBT_upd(L, R, B, T)

        # e.da.LB(rim, F[12], F[4.9])
        e.bo_0.LRBT_upd(L0, L1, B0, T0)
        e.bo_1.LRBT_upd(L1, R1, B0, T0)
        e.bg_black.LRBT_upd(L1, L2, B0, T0)
        e.bg_white.LRBT_upd(L2, R1, B0, T0)
        #

    def I_draw_oo_bo_3(self):
        v = self.color
        e = self.oo[0]

        e.rim.bind_draw()
        e.bo_0.bind_color((v[0], v[1], v[2], 1.0))
        e.bo_0.draw()
        e.bo_1.draw()
        #
    def I_draw_oo_bo_4(self):
        v = self.color
        e = self.oo[0]

        e.rim.bind_draw()
        e.bg_black.bind_draw()
        e.bg_white.bind_draw()

        e.bo_0.bind_color((v[0], v[1], v[2], 1.0))
        e.bo_0.draw()
        e.bo_1.bind_color(v)
        e.bo_1.draw()
        #
    def draw_oo_ti(self): pass
    def draw_oo_da(self): pass
        #
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

        e = self.oo[0]
        e.rim.dxy_upd(x, y)
        # e.da.dxy(x, y)
        e.bo_0.dxy_upd(x, y)
        e.bo_1.dxy_upd(x, y)
        e.bg_black.dxy_upd(x, y)
        e.bg_white.dxy_upd(x, y)
        #

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.rim.in_BT_y(y) is False:
            self.unfocus()
            return False

        e = self.oo[0]
        if e.rim.inbox_xy(x, y):
            if self.oo_fo is None:
                self.oo_fo = e
                e.rim.color = P.color_bu_3_fo
                m.redraw()
            elif self.oo_fo != e:
                self.oo_fo.rim.color = P.color_bu_3_off
                self.oo_fo = e
                e.rim.color = P.color_bu_3_fo
                m.redraw()

            if K["bu_sel0"].true() or K["bu_sel1"].true():
                self.fn(e)
                return True
            if K["rm0"].true() or K["rm1"].true():
                self.fn_rm(evt, e)
                return True
            if K["dd_copy0"].true() or K["dd_copy1"].true():
                self.fn_copy(e)
                return True
            if K["dd_paste0"].true() or K["dd_paste1"].true():
                self.fn_paste(e)
                return True
            if K["dd_cut0"].true() or K["dd_cut1"].true():
                self.fn_cut(fo)
                return True
            if K["bu_reset0"].true() or K["bu_reset1"].true():
                self.fn_reset(e)
                return True
        else:
            self.unfocus()
        #

    def fn(self, o):
        print(f"    bu_block  COLOR  fn")
        attr = self.prop.identifier
        m.undo_str = f'[Settings] preferences.{attr}[:] = '
        DD_COLOR(o, self.color, local_undo=((attr, tuple(self.color), (0, len(self.color))),))
        #
    def fn_rm(self, evt, o):
        print(f"    bu_block  COLOR  fn_rm")
        global tm
        tm = m.tm

        if o is None:
            print("TODO")
            return
        else:
            li = [
                {9: "rm_Copy_Array", 0: "Copy Array"},
                {9: "rm_Paste_Value", 0: "Paste Value"},
                {9: "rm_Reset_to_Default_Value", 0: "Reset to Default Value"},
            ]

        tm["o"] = o
        tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y, li)
        #
    def rm_Copy_Value(self):
        print(f"    bu_block  COLOR  rm_Copy_Value")
        self.rm_Copy_Array()
    #
    #
class BOOL(VAL):
    __slots__ = 'draw_oo_bool', 'last_trigger',
    #
    def __init__(self, w, prop):
        self.w = w
        self.prop = prop
        self.oo_fo = None
        self.last_trigger = None

        self.rim = BOX()
        self.ti = BLF(text=prop.name)
        self.da = BLF(text=prop.description)

        self.dxy = self.I_dxy
        self.draw_oo_ti = self.I_draw_oo_noti

        if prop.is_array:
            ll = prop.array_length
            self.oo = [BU_BOOL(self, prop, i) for i in range(ll)]
            self.hi = F[7] + (F[16] + F[1]) * ll + F[6]
            self.draw_oo_bool = self.I_draw_oo_bool_array
        else:
            self.oo = [BU_BOOL(self, prop, None)]
            self.hi = F[38]
            self.draw_oo_bool = self.I_draw_oo_bool_1

        dimen_y = self.da.R_dimen_y()
        if dimen_y > F[8]:
            self.draw_da = self.I_draw_da_wrap
            self.hi = max(F[38] + dimen_y - F[7], self.hi)
            self.tx_wi = w.tx_wi
        else:
            self.draw_da = self.I_draw_da
        #

    def get_bo(self, L, R, T):
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])

        _1 = F[1]
        hi = F[16]
        R -= F[6]
        T -= F[7]
        B = T - hi
        L = R - hi

        for e in self.oo:
            rim = e.rim
            rim.LRBT_upd(L, R, B, T)

            e.da.LB(rim, F[1.5], 0)

            T = B - _1
            B = T - hi
        #

    def fn(self, o, multi_edit=None, local_undo=None):
        v = getattr(P, o.attr)
        if o.ind is not None:   v = v[o.ind]
        o.bpy_setter(not v)
        m.refresh()
        m.redraw()
        self.last_trigger = o
    def unfocus(self):
        if self.oo_fo is not None:
            print(f"    bu_block  BOOL(VAL)  unfocus")
            if self.oo_fo == self.last_trigger: self.last_trigger = None
            self.oo_fo.rim.color = P.color_bu_3_off
            self.oo_fo = None
            m.redraw()
        #
    def focus_oo(self, x, y):
        color_off = P.color_bu_3_off
        color_fo = P.color_bu_3_fo
        for e in self.oo:
            if e.rim.inbox_xy(x, y):
                e.rim.color = color_fo
                self.oo_fo = e
            else:
                e.rim.color = color_off
    def unfocus_all(self):
        color_off = P.color_bu_3_off
        for e in self.oo:   e.rim.color = color_off
        self.oo_fo = None
        self.last_trigger = None

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.rim.in_BT_y(y) is False:
            self.unfocus()
            return False
        if evt.value == 'RELEASE':  self.last_trigger = None

        fo = None
        if self.oo[0].rim.in_LR_x(x):
            for e in self.oo:
                if e.rim.in_BT_y(y):
                    fo = e
                    if self.oo_fo is None:
                        self.oo_fo = e
                        e.rim.color = P.color_bu_3_fo
                        m.redraw()
                    elif self.oo_fo != e:
                        if self.oo_fo == self.last_trigger: self.last_trigger = None
                        self.oo_fo.rim.color = P.color_bu_3_off
                        self.oo_fo = e
                        e.rim.color = P.color_bu_3_fo
                        m.redraw()
                    break
        if fo is not None:
            if self.last_trigger != fo:
                if K["sel_fast0"].true() or K["sel_fast1"].true():
                    self.fn(fo)
                    return True
                if K["rm0"].true() or K["rm1"].true():
                    self.fn_rm(evt, fo)
                    return True
                if K["dd_copy0"].true() or K["dd_copy1"].true():
                    self.fn_copy(fo)
                    return True
                if K["dd_paste0"].true() or K["dd_paste1"].true():
                    self.fn_paste(fo)
                    return True
                if K["dd_cut0"].true() or K["dd_cut1"].true():
                    self.fn_cut(fo)
                    return True
                if K["bu_reset0"].true() or K["bu_reset1"].true():
                    self.fn_reset(fo)
                    return True
        else:
            self.unfocus()
        return False
        #

    def draw_oo_da(self): pass
    def I_draw_oo_bool_1(self):
        self.oo[0].da.draw_pos()
        #
    def I_draw_oo_bool_array(self):
        for e in self.oo:   e.da.draw_pos()

    def rm_Copy_Value(self):
        try:
            print(f"    bu_block  BOOL  rm_Copy_Value")

            v = getattr(P, self.R_attr())
            if is_ind_0(v): v = v[m.tm["o"].ind]

            bpy.context.window_manager.clipboard = f"{v}"
        except: pass
    def rm_Copy_Array(self):
        self.rm_Copy_Value()
    def rm_Paste_Value(self):
        try:
            print(f"    bu_block  BOOL  rm_Paste_Value")
            ind = tm["o"].ind
            prop = self.prop
            is_group = isinstance(prop, tuple)
            if is_group: prop = prop[ind]
            attr = prop.identifier
            v = bpy.context.window_manager.clipboard
            if v in {"True", "TRUE", "true"}:       v = True
            elif v in {"False", "FALSE", "false"}:  v = False
            else:
                v = calc_vec(v)
                if isinstance(v, str):  return
                v = round(v[0])
                if v == 0.0:    v = True
                elif v == 1.0:  v = False
                else: return

            old_v = getattr(P, attr)
            setattr(P, attr, v)
            m.undo_str = f'[Settings] preferences.{attr} = {v}'
            ind = None

            m.refresh()
            m.undo_push(((attr, old_v, ind),))
        except: pass
    #
    #
class ENUM(VAL):
    __slots__ = ()
    #
    def __init__(self, w, prop):
        self.w = w
        self.prop = prop
        self.oo_fo = None

        self.rim = BOX()
        self.ti = BLF(text=prop.name)
        self.da = BLF(text=prop.description)

        self.dxy = self.I_dxy
        self.draw_oo_ti = self.I_draw_oo_noti

        self.oo = [BU_ENUM(self, prop)]
        self.hi = F[38]

        dimen_y = self.da.R_dimen_y()
        if dimen_y > F[8]:
            self.draw_da = self.I_draw_da_wrap
            self.hi = max(F[38] + dimen_y - F[7], self.hi)
            self.tx_wi = w.tx_wi
        else:
            self.draw_da = self.I_draw_da
        #

    def get_bo(self, L, R, T):
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])

        _1 = F[1]
        hi = F[16]
        R -= F[6]
        T -= F[7]
        B = T - hi
        L = R - F[101]

        e = self.oo[0]
        rim = e.rim
        rim.LRBT_upd(L, R, B, T)

        e.da.LB(rim, F[5], F[4.9])
        #

    def fn(self, o, multi_edit=None, local_undo=None):
        o.da.name = o.da.text

        def end_fn():
            m.refresh()
            self.unfocus_all()

        DDTX(o, FIL(o.enums), tx_clear=True, end_fn=end_fn)
        #

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.rim.in_BT_y(y) is False:
            self.unfocus()
            return False

        fo = None
        if self.oo[0].rim.in_LR_x(x):
            for e in self.oo:
                if e.rim.in_BT_y(y):
                    fo = e
                    if self.oo_fo is None:
                        self.oo_fo = e
                        e.rim.color = P.color_bu_3_fo
                        m.redraw()
                    elif self.oo_fo != e:
                        self.oo_fo.rim.color = P.color_bu_3_off
                        self.oo_fo = e
                        e.rim.color = P.color_bu_3_fo
                        m.redraw()
                    break
        if fo is not None:
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.fn(fo)
                return True
            if K["rm0"].true() or K["rm1"].true():
                self.fn_rm(evt, fo)
                return True
            if K["dd_copy0"].true() or K["dd_copy1"].true():
                self.fn_copy(fo)
                return True
            if K["dd_paste0"].true() or K["dd_paste1"].true():
                self.fn_paste(fo)
                return True
            if K["dd_cut0"].true() or K["dd_cut1"].true():
                self.fn_cut(fo)
                return True
            if K["bu_reset0"].true() or K["bu_reset1"].true():
                self.fn_reset(fo)
                return True
        else:
            self.unfocus()
        return False
        #
    def rm_Copy_Value(self):
        try:
            print(f"    bu_block  ENUM  rm_Copy_Value")

            v = getattr(P, self.R_attr())
            bpy.context.window_manager.clipboard = f"{v}"
        except: pass
    def rm_Copy_Array(self):
        self.rm_Copy_Value()
    def rm_Paste_Value(self):
        try:
            print(f"    bu_block  ENUM  rm_Paste_Value")
            ind = tm["o"].ind
            prop = self.prop
            is_group = isinstance(prop, tuple)
            if is_group: prop = prop[ind]
            attr = prop.identifier
            v = bpy.context.window_manager.clipboard

            old_v = getattr(P, attr)
            setattr(P, attr, v)
            m.undo_str = f'[Settings] preferences.{attr} = {v}'
            ind = None

            m.refresh()
            m.undo_push(((attr, old_v, ind),))
        except: pass
    #
    #
class STRING(VAL):
    __slots__ = ()
    #
    def __init__(self, w, prop):
        self.w = w
        self.prop = prop
        self.oo_fo = None

        self.rim = BOX()
        self.ti = BLF(text=prop.name)
        self.da = BLF(text=prop.description)

        self.dxy = self.I_dxy
        self.draw_oo_ti = self.I_draw_oo_noti

        self.oo = [BU_STR(self, prop)]
        self.hi = F[38]

        dimen_y = self.da.R_dimen_y()
        if dimen_y > F[8]:
            self.draw_da = self.I_draw_da_wrap
            self.hi = max(F[38] + dimen_y - F[7], self.hi)
            self.tx_wi = w.tx_wi
        else:
            self.draw_da = self.I_draw_da
        #

    def get_bo(self, L, R, T):
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])

        _1 = F[1]
        hi = F[16]
        R -= F[6]
        T -= F[7]
        B = T - hi
        L = R - F[101]

        e = self.oo[0]
        rim = e.rim
        rim.LRBT_upd(L, R, B, T)
        e.da.LB(rim, F[5], F[4.9])
        #

    def fn(self, o, multi_edit=None, local_undo=None):

        def end_fn():
            m.refresh()
            self.unfocus_all()

        DDTX(o, None, tx_clear=False, end_fn=end_fn)
        #

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.rim.in_BT_y(y) is False:
            self.unfocus()
            return False

        fo = None
        if self.oo[0].rim.in_LR_x(x):
            for e in self.oo:
                if e.rim.in_BT_y(y):
                    fo = e
                    if self.oo_fo is None:
                        self.oo_fo = e
                        e.rim.color = P.color_bu_3_fo
                        m.redraw()
                    elif self.oo_fo != e:
                        self.oo_fo.rim.color = P.color_bu_3_off
                        self.oo_fo = e
                        e.rim.color = P.color_bu_3_fo
                        m.redraw()
                    break
        if fo is not None:
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.fn(fo)
                return True
            if K["rm0"].true() or K["rm1"].true():
                self.fn_rm(evt, fo)
                return True
            if K["dd_copy0"].true() or K["dd_copy1"].true():
                self.fn_copy(fo)
                return True
            if K["dd_paste0"].true() or K["dd_paste1"].true():
                self.fn_paste(fo)
                return True
            if K["dd_cut0"].true() or K["dd_cut1"].true():
                self.fn_cut(fo)
                return True
            if K["bu_reset0"].true() or K["bu_reset1"].true():
                self.fn_reset(fo)
                return True
        else:
            self.unfocus()
        return False
        #

    def rm_Copy_Value(self):
        try:
            print(f"    bu_block  STRING  rm_Copy_Value")

            v = getattr(P, self.R_attr())
            if not isinstance(v, str):  v = v[m.tm["o"].ind]

            bpy.context.window_manager.clipboard = f"{v}"
        except: pass
    def rm_Copy_Array(self):
        self.rm_Copy_Value()
    def rm_Paste_Value(self):
        try:
            print(f"    bu_block  STRING  rm_Paste_Value")
            ind = tm["o"].ind
            prop = self.prop
            is_group = isinstance(prop, tuple)
            if is_group: prop = prop[ind]
            attr = prop.identifier
            v = bpy.context.window_manager.clipboard

            old_v = getattr(P, attr)
            setattr(P, attr, v)
            m.undo_str = f'[Settings] preferences.{attr} = {v}'
            ind = None

            m.refresh()
            m.undo_push(((attr, old_v, ind),))
        except: pass
    #
    #
class STRING_SET(STRING):
    __slots__ = 'oo_wi', 'depth'
    def __init__(self, w, props, li_prop, subtype, oo_wi, rim_hi, depth, ti="", da=""):
        self.w = w
        prop = tuple(props[e] for e in li_prop)
        self.prop = prop
        self.oo_fo = None
        self.oo_wi = oo_wi

        self.rim = BOX()
        self.ti = BLF(text=ti)
        self.da = BLF(text=da)

        self.dxy = self.I_dxy_sub_ti
        self.draw_oo_ti = self.I_draw_oo_ti
        oo = []
        self.oo = oo

        for ind, bpy_prop, tx in zip(range(len(prop)), prop, subtype):
            e = BU_STR(self, bpy_prop, ind=ind)
            e.ti = BLF(text=tx)
            oo.append(e)

        self.hi = rim_hi
        self.depth = depth
        self.draw_da = self.I_draw_da

    def get_bo(self, L, R, T): # blf_size(font_0, F[8], 72)
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])

        _1 = F[1]
        hi = F[16]
        R -= F[6]
        T -= F[7]
        B = T - hi
        L = R - self.oo_wi
        L0 = L - F[4]
        d = self.depth

        for e in self.oo:
            rim = e.rim
            rim.LRBT_upd(L, R, B, T)
            e.da.LB(rim, F[5], F[4.9])
            ti = e.ti
            ti.y = e.da.y
            ti.align_R_float(L0)

            T = B - d
            B = T - hi
        #
class STR_SIM(STRING):
    __slots__ = ()
    def __init__(self, w, title, description, text, sub_ti=False, is_read_only=True):
        self.w = w
        self.oo_fo = None

        self.rim = BOX()
        self.ti = BLF(text=title)
        self.da = BLF(text=description)

        self.dxy = self.I_dxy
        self.draw_oo_ti = self.I_draw_oo_noti

        self.oo = [BU_STR_SIM(self, text, None, sub_ti, is_read_only=is_read_only)]
        self.oo[0].da.name = text
        self.hi = F[38]

        dimen_y = self.da.R_dimen_y()
        if dimen_y > F[8]:
            self.draw_da = self.I_draw_da_wrap
            self.hi = max(F[38] + dimen_y - F[7], self.hi)
            self.tx_wi = w.tx_wi
        else:
            self.draw_da = self.I_draw_da
        #

    def rm_Copy_Value(self):
        try:
            print(f"    bu_block  STR_SIM  rm_Copy_Value")

            bpy.context.window_manager.clipboard = f"{self.oo[0].da.name}"
        except: pass


class VAL_COLOR(VAL): # ["rgba"] array
    __slots__ = 'hsv', 'min_max', 'bu_pick', 'bu_hex', 'ind_rgb', 'ind_hsv', 'tm_upd',
    #
    def __init__(self, w, array, min_max=(0,1)): # blf_size(font_0, F[8], 72)
        self.w = w
        self.prop = array
        self.min_max = min_max
        self.ty = f"float [{min_max[0]},{min_max[1]}]"
        hsv = list(rgb_to_hsv(array[0], array[1], array[2]))
        self.hsv = hsv
        self.oo_fo = None

        self.rim = BOX()
        self.draw_oo_ti = self.I_draw_oo_ti
        self.hi = F[7] + (F[16] + F[1]) * 5 + F[6]

        if len(array) == 4:
            subtype = ("R", "G", "B", "A")
            self.ind_rgb = (0, 1, 2, 3)
            self.ind_hsv = (4, 5, 6)
        else:
            subtype = ("R", "G", "B")
            self.ind_rgb = (0, 1, 2)
            self.ind_hsv = (3, 4, 5)

        oo = [BU_FLOAT_SIM(self, array, i, e) for i, e in enumerate(subtype)]
        self.oo = oo
        oo.append(BU_FLOAT_SIM_HSV(self, hsv, 0, "H"))
        oo.append(BU_FLOAT_SIM_HSV(self, hsv, 1, "S"))
        oo.append(BU_FLOAT_SIM_HSV(self, hsv, 2, "V"))
        e = BU_HEX(self, "#")
        self.bu_hex = e
        oo.append(e)
        self.bu_pick = BU_PICK_COLOR(self)
        #

    def get_bo(self, L, R, T): # blf_size(font_0, F[8], 72)
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        dx = F[6]
        dy = F[4.9]
        _1 = F[1]
        hi = F[16]
        R -= dx
        T -= F[7]
        B = T - hi
        bu_wi = F[101] - dx - _1 - _1
        L1 = L + F[12] + dx
        L = R - bu_wi
        L0 = L - F[4]

        R1 = L1 + bu_wi
        L2 = L1 - F[4]
        oo = self.oo
        for ind_rgb, ind_hsv in zip(self.ind_rgb, self.ind_hsv):
            e = oo[ind_rgb]
            rim = e.rim
            rim.LRBT_upd(L, R, B, T)
            e.da.LB(rim, dx, dy)

            ti = e.ti
            ti.y = e.da.y
            ti.align_R_float(L0)

            e = oo[ind_hsv]
            rim = e.rim
            rim.LRBT_upd(L1, R1, B, T)
            e.da.LB(rim, dx, dy)

            ti = e.ti
            ti.y = e.da.y
            ti.align_R_float(L2)

            T = B - _1
            B = T - hi

        if len(self.ind_rgb) == 4:
            e = oo[3]
            rim = e.rim
            rim.LRBT_upd(L, R, B, T)
            e.da.LB(rim, dx, dy)

            ti = e.ti
            ti.y = e.da.y
            ti.align_R_float(L0)

        T = B - _1
        B = T - hi
        e = self.bu_hex
        rim = e.rim
        rim.LRBT_upd(L1, R1, B, T)
        e.da.LB(rim, dx + F[22], dy)

        ti = e.ti
        ti.y = e.da.y
        ti.align_R_float(L2)

        e = self.bu_pick
        L3 = R1 + F[2]
        R2 = L3 + hi + _1
        e.rim.LRBT_upd(L3, R2, B, T)
        e.get_unfocus()
        #

    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)

        for e in self.oo:
            e.rim.dxy_upd(x, y)
            e.da.dxy(x, y)
            e.ti.dxy(x, y)

        e = self.bu_pick
        e.rim.dxy_upd(x, y)
        e.bo.dxy_upd(x, y)
        e.ti.dxy(x, y)
        #

    def fn(self, o, multi_edit=None, local_undo=None):
        prop = self.prop
        if o == self.bu_hex:
            def end_fn():
                print(f"    bu_block  VAL_COLOR  fn  end_fn:  is_dd_confirm={m.tm['is_dd_confirm']}")
                self.unfocus_all()
                m.admin.push_modal()
                if m.tm["is_dd_confirm"]:
                    self.dd_end_upd(o)
                    m.refresh()

            m.tm["dd"] = DDTX(o, tx_clear=False, end_fn=end_fn)
            return

        def end_fn():
            print(f"    bu_block  VAL_COLOR  fn  end_fn:  is_dd_confirm={m.tm['is_dd_confirm']}")
            self.unfocus_all()
            m.admin.push_modal()
            if multi_edit is not None:
                for e in multi_edit:    e.setter()
            if m.tm["is_dd_confirm"]:
                self.dd_end_upd(o)
                m.refresh()

        m.tm["dd"] = DDVAL(o, self.ty,
            end_fn      = end_fn,
            multi_edit  = multi_edit,
            local_undo  = local_undo)
    def dd_end_upd(self, e, override=False):
        print(f"    bu_block  VAL_COLOR(VAL)  dd_end_upd")
        w = self.w
        if override is False and not m.tm["is_dd_confirm"]:
            w.upd_by_rgb()
            return

        ti_text = e.ti.text

        if ti_text in {"H", "S", "V"}:
            hsv = self.hsv
            for i, e in enumerate(hsv):
                if e < 0.0:     hsv[i] = 0.0
                elif e > 1.0:   hsv[i] = 1.0

            w.upd_by_hsv()
            #
        elif ti_text == '#':
            rgb = R_rgb_by_str(e.da.text)
            if rgb is not None:
                r, g, b = rgb
                is_null = False
                if w.space == "GLSL-C":
                    if r in D_null or g in D_null or b in D_null:   is_null = (r, g, b)
                    r = L_rgb_to_glc[r]
                    g = L_rgb_to_glc[g]
                    b = L_rgb_to_glc[b]
                elif w.space == "GLSL-B":
                    if r in D_null or g in D_null or b in D_null:   is_null = (r, g, b)
                    r = L_rgb_to_glb[r]
                    g = L_rgb_to_glb[g]
                    b = L_rgb_to_glb[b]
                else:
                    TODO

                w.color[:-1] = r + 0.00001, g + 0.00001, b + 0.00001

                if is_null:
                    tx = '%02X%02X%02X' % is_null
                    w.ti["info"].text = f"#{tx} invalid in {w.space}"

            w.upd_by_rgb()
        else: w.upd_by_rgb()
        #

    def R_multi_oo(self, qe_bu):
        oo = self.oo
        if qe_bu.ti.text in {"H", "S", "V"}:
            return tuple((r, oo[r]) for r in self.ind_hsv)
        else:
            return tuple((r, oo[r]) for r in self.ind_rgb)
        #
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        self.qe_bu.bpy_setter(self.qe_value, undo_push=False)
        self.qe_bu.da.text = self.qe_bu.tx_format(self.qe_value)
        self.tm_upd()
        #
    def I_qe_real_time_float_multi(self, dx):
        self.qe_value += dx
        v = self.qe_value
        self.qe_bu.bpy_setter(v, undo_push=False)
        tx = self.qe_bu.tx_format(v)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.bpy_setter(v, undo_push=False)
            e.da.text = tx
        self.tm_upd()
        #
    def to_modal_qe(self, evt, bu, mk):
        self.tm_upd = self.w.upd_by_hsv  if bu.ti.text in {"H", "S", "V"} else self.w.upd_by_rgb
        super().to_modal_qe(evt, bu, mk)
class TI_DATA:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'oo',
        'hi',
    )
    def __init__(self, w, hi, name="", description=""):
        self.w = w
        self.rim = BOX()
        self.ti = BLF(text=name)
        self.da = BLF(text=description)
        self.oo = ()
        self.hi = hi

    def get_bo(self, L, R, T): # blf_size(font_0, F[8], 72)
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

    def draw_oo_bool(self): pass
    def draw_bo(self):
        self.rim.draw()
    def draw_oo_bo(self): pass
    def draw_ti(self):
        self.ti.draw_pos()
    def draw_da(self):
        self.da.draw_pos()
    def draw_oo_da(self): pass
    def draw_oo_ti(self): pass
    def unfocus(self): pass
    def focus_oo(self): pass
    def unfocus_all(self): pass

    def I_modal_main(self, evt):
        return False
    #
    #
class BUTTON(TI_DATA):
    __slots__ = 'oo_fo', 'draw_da', 'tx_wi', 'bu_wi'
    def __init__(self, w, name, fns, bu_wi, description=""): # blf_size(font_0, F[8], 72), blf_wrap
        self.w = w
        self.oo_fo = None
        self.rim = BOX()
        self.ti = BLF(text=name)
        self.da = BLF(text=description)
        self.bu_wi = bu_wi
        self.hi = F[7] + (F[16] + F[1]) * len(fns) + F[6]
        self.oo = [BU_FNDA(self, s, fn=e) for s, e in fns]

        dimen_y = self.da.R_dimen_y()
        if dimen_y > F[8]:
            self.draw_da = self.I_draw_da_wrap
            self.hi = max(F[38] + dimen_y - F[7], self.hi)
            self.tx_wi = w.tx_wi
        else:
            self.draw_da = self.I_draw_da

    def get_bo(self, L, R, T): # blf_size(font_0, F[8], 72)
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])
        _1 = F[1]
        _16 = F[16]
        R -= F[6]
        L = R - self.bu_wi
        T -= F[7]
        B = T - _16
        L1 = L + _1
        ti_dy = F[4]

        blf_size(font_0, F[9], 72)
        for e in self.oo:
            e.rim.LRBT_upd(L, R, B, T)
            e.bo.LRBT_upd(L1, R, B, T - _1)
            e.ti.y = B + ti_dy
            e.ti.set_x_by_bo(e.bo)
            T = B - _1
            B = T - _16
        blf_size(font_0, F[8], 72)

    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)
        for e in self.oo: e.dxy(x, y)

    def I_draw_da_wrap(self):
        pass
        #
    def I_draw_da(self):
        pass
        #
    def draw_oo_bo(self):
        m.bind_color_bu_1_rim()
        for o in self.oo:   o.draw_rim()
        for o in self.oo:   o.draw_bo()
        #
    def draw_oo_da(self):
        for o in self.oo:   o.ti.draw_pos()

    def unfocus(self):
        if self.oo_fo is not None:
            print(f"    bu_block  BUTTON  unfocus")
            self.oo_fo.unfocus()
            self.oo_fo = None
            m.redraw()
        #
    def focus_oo(self, x, y):
        for e in self.oo:
            e.focus()  if e.rim.inbox_xy(x, y) else e.unfocus()
        #
    def unfocus_all(self):
        for e in self.oo:   e.unfocus()

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.rim.in_BT_y(y) is False:
            self.unfocus()
            return False

        oo = self.oo
        fo = None

        if oo[0].rim.in_LR_x(x):
            for e in oo:
                if e.rim.in_BT_y(y):
                    fo = e
                    break

        if fo is None:  self.unfocus()
        else:
            if self.oo_fo is None:
                fo.focus()
                self.oo_fo = fo
                m.redraw()
            elif self.oo_fo != fo:
                self.oo_fo.unfocus()
                fo.focus()
                self.oo_fo = fo
                m.redraw()
            elif evt.value == 'RELEASE':
                if hasattr(fo, "is_allow"): fo.is_allow = True

            if K["sel0"].true() or K["sel1"].true():
                fo.fn()
                return True
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                fo.on()
                m.redraw()
                return True
            else:
                fo.focus()
                m.redraw()

class KM(VAL):
    __slots__ = 'attr', 'sub_ti', 'is_oo_2_dark', 'is_oo_7_dark', 'last_data', 'bo_end'
    def __init__(self, w, prop):
        self.w = w
        self.prop = prop
        self.attr = getattr(P, prop.identifier)
        self.last_data = [None]
        self.oo_fo = None

        self.rim = BOX()
        self.ti = BLF(text=prop.name)
        self.hi = F[150] + F[16]

        oo = [
            BU_FNDA(self, "Edit Combination 1", 0),
            BU_STR_SIM(self, "", None, False),
            BU_FLOAT_SIM(self, 0, None, "sec"),
            BU_BOOL_SIM(self, False, None, False),
            BU_BOOL_SIM(self, False, None, False),
            BU_FNDA(self, "Edit Combination 2", 2),
            BU_STR_SIM(self, "", None, False),
            BU_FLOAT_SIM(self, 0, None, "sec"),
            BU_BOOL_SIM(self, False, None, False),
            BU_BOOL_SIM(self, False, None, False),
        ]
        self.oo = oo
        self.sub_ti = [
            BLF(text="Value"),
            BLF(text="Duration"),
            BLF(text="Exact"),
            BLF(text="Repeat"),
            BLF(text="Value"),
            BLF(text="Duration"),
            BLF(text="Exact"),
            BLF(text="Repeat"),
        ]
        self.bo_end = BOX(P.color_oj_info)

    def get_bo(self, L, R, T):
        rim = self.rim
        B = T - self.hi
        rim.LRBT_upd(L, R, B, T)
        self.bo_end.LRBT_upd(L, R, B, B + F[14])

        ti = self.ti
        ti.LT(rim, F[8], F[17])

        _1 = F[1]
        hi = F[16]
        R5 = R - F[6]
        R4 = R5 - hi
        x0 = R4 - F[34] + F[2]
        x1 = R4 - F[38]
        L = ti.x
        R = L + F[93]
        T -= F[24]
        B = T - hi
        L0 = L + F[6]
        L1 = L + _1
        L2 = R + F[10]
        ti_dy = F[4]

        oo = self.oo
        sub_ti = self.sub_ti
        e = oo[0]
        e.rim.LRBT_upd(L, R, B, T)
        e.bo.LRBT_upd(L1, R, B, T - _1)
        e.ti.xy(L0, B + ti_dy)
        e.da.xy(L2, e.ti.y)

        dB = F[22]
        T -= dB
        B -= dB
        L3 = R + F[6]
        L4 = L0 + F[31]
        R0 = L3 + F[93]
        R6 = R4 + F[1.5]
        y = B + ti_dy
        e = oo[1]
        e.rim.LRBT_upd(L3, R0, B, T)
        e.da.xy(L2, y)
        sub_ti[0].xy(L4, y)
        e = oo[3]
        e.rim.LRBT_upd(R4, R5, B, T)
        e.da.xy(R6, B)
        sub_ti[2].xy(x0, y)

        T = B - F[2]
        B = T - hi
        y = B + ti_dy
        x_sec = R - F[12]
        e = oo[2]
        e.rim.LRBT_upd(L3, R0, B, T)
        e.da.xy(L2, y)
        e.ti.xy(x_sec, y)
        sub_ti[1].xy(L4, y)
        e = oo[4]
        e.rim.LRBT_upd(R4, R5, B, T)
        e.da.xy(R6, B)
        sub_ti[3].xy(x1, y)
        #
        T = B - F[8]
        B = T - hi
        y = B + ti_dy
        e = oo[5]
        e.rim.LRBT_upd(L, R, B, T)
        e.bo.LRBT_upd(L1, R, B, T - _1)
        e.ti.xy(L0, B + ti_dy)
        e.da.xy(L2, e.ti.y)

        T -= dB
        B -= dB
        y = B + ti_dy
        e = oo[6]
        e.rim.LRBT_upd(L3, R0, B, T)
        e.da.xy(L2, y)
        sub_ti[4].xy(L4, y)
        e = oo[8]
        e.rim.LRBT_upd(R4, R5, B, T)
        e.da.xy(R6, B)
        sub_ti[6].xy(x0, y)

        T = B - F[2]
        B = T - hi
        y = B + ti_dy
        e = oo[7]
        e.rim.LRBT_upd(L3, R0, B, T)
        e.da.xy(L2, y)
        e.ti.xy(x_sec, y)
        sub_ti[5].xy(L4, y)
        e = oo[9]
        e.rim.LRBT_upd(R4, R5, B, T)
        e.da.xy(R6, B)
        sub_ti[7].xy(x1, y)

    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bo_end.dxy_upd(x, y)
        self.ti.dxy(x, y)

        for e in self.oo:       e.dxy(x, y)
        for e in self.sub_ti:   e.dxy(x, y)

    def draw_bo(self):
        self.rim.draw()
        #
    def draw_oo_bo(self):
        oo = self.oo
        m.bind_color_bu_1_rim()
        oo_0 = oo[0]
        oo_5 = oo[5]
        oo_0.draw_rim()
        oo_5.draw_rim()

        oo_0.draw_bo()
        oo_5.draw_bo()
        for r in range(1, 5):   oo[r].rim.bind_draw()
        for r in range(6, 10):  oo[r].rim.bind_draw()
        self.bo_end.bind_draw()
        #
    def draw_ti(self):
        self.ti.draw_pos()
        #
    def draw_da(self): pass
    def draw_oo_da(self):
        oo = self.oo
        oo[0].draw_ti()
        oo[1].da.draw_pos()
        if self.is_oo_2_dark:
            blf_color(font_0, *P.color_font_ignore)
            oo[2].da.draw_pos()
            blf_color(font_0, *P.color_font)
        else: oo[2].da.draw_pos()

        oo[5].draw_ti()
        oo[6].da.draw_pos()
        if self.is_oo_7_dark:
            blf_color(font_0, *P.color_font_ignore)
            oo[7].da.draw_pos()
            blf_color(font_0, *P.color_font)
        else: oo[7].da.draw_pos()

        for e in self.sub_ti:   e.draw_pos()
        #
    def draw_oo_ti(self):
        self.oo[2].ti.draw_pos()
        self.oo[7].ti.draw_pos()
        #
    def draw_oo_bool(self):
        oo = self.oo
        oo[3].da.draw_pos()
        oo[4].da.draw_pos()
        oo[8].da.draw_pos()
        oo[9].da.draw_pos()
    def unfocus(self):
        if self.oo_fo is not None:
            print(f"    bu_block  KM(VAL)  unfocus")
            self.oo_fo.unfocus()
            self.oo_fo = None
            m.redraw()
        #
    def focus_oo(self, x, y):
        for e in self.oo:
            e.focus()  if e.rim.inbox_xy(x, y) else e.unfocus()
        #
    def unfocus_all(self):
        for e in self.oo:   e.unfocus()

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.rim.in_BT_y(y) is False:
            self.unfocus()
            return False

        oo = self.oo
        fo = None

        if oo[0].rim.in_LR_x(x):
            if oo[0].rim.in_BT_y(y):    fo = oo[0]
            elif oo[5].rim.in_BT_y(y):  fo = oo[5]
        elif oo[1].rim.in_LR_x(x):
            if oo[1].rim.in_BT_y(y):    fo = oo[1]
            elif oo[2].rim.in_BT_y(y):  fo = oo[2]
            elif oo[6].rim.in_BT_y(y):  fo = oo[6]
            elif oo[7].rim.in_BT_y(y):  fo = oo[7]
        elif oo[3].rim.in_LR_x(x):
            if oo[3].rim.in_BT_y(y):    fo = oo[3]
            elif oo[4].rim.in_BT_y(y):  fo = oo[4]
            elif oo[8].rim.in_BT_y(y):  fo = oo[8]
            elif oo[9].rim.in_BT_y(y):  fo = oo[9]

        if fo is None:  self.unfocus()
        else:
            if self.oo_fo is None:
                fo.focus()
                self.oo_fo = fo
                m.redraw()
            elif self.oo_fo != fo:
                self.oo_fo.unfocus()
                fo.focus()
                self.oo_fo = fo
                m.redraw()
            elif evt.value == 'RELEASE':
                if hasattr(fo, "is_allow"): fo.is_allow = True

            if K["bu_qe0"].true():
                self.key_end = K["bu_qe_E0"]
                self.to_modal_qe(evt, fo, K["bu_qe0"])
                return True
            if K["bu_qe1"].true():
                self.key_end = K["bu_qe_E1"]
                self.to_modal_qe(evt, fo, K["bu_qe1"])
                return True
            if K["sel0"].true() or K["sel1"].true():
                self.fn(fo)
                return True
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.fn_bool(fo)
                return True
            if K["rm0"].true() or K["rm1"].true():
                self.fn_rm(evt, fo)
                return True
            if K["dd_copy0"].true() or K["dd_copy1"].true():
                self.fn_copy(fo)
                return True
            if K["dd_paste0"].true() or K["dd_paste1"].true():
                self.fn_paste(fo)
                return True
            if K["bu_reset0"].true() or K["bu_reset1"].true():
                self.fn_reset(fo)
                return True
        return False

    def to_modal_qe(self, evt, fo, ke):
        if type(fo) != BU_FLOAT_SIM:    return
        self.ty = "float [0,9]"
        super().to_modal_qe(evt, fo, ke)

    def fn(self, fo):
        print(f"    bu_block  KM(VAL)  fn")
        ty = type(fo)
        if ty == BU_FNDA:   KEY_ED(fo, m.EVT.evt)
        elif ty == BU_STR_SIM:
            def end_fn():
                print("    bu_block  KM  fn  end_fn  dd end")
                if m.tm["is_dd_confirm"]:
                    v = fo.da.text

                    if v in key_title_set:
                        self.write_value(key_title_to_value[v], self.oo.index(fo))
                        m.refresh()
                    elif v in key_value_set:
                        self.write_value(v, self.oo.index(fo))
                        m.refresh()
                    else:
                        fo.da.text = fo.da.name
                self.unfocus()

            fo.da.name = fo.da.text
            DDTX(fo, FIL(value_enums), tx_clear=True, end_fn=end_fn)
        elif ty == BU_FLOAT_SIM:
            def end_fn():
                print("    bu_block  KM  fn  end_fn  dd end")
                if m.tm["is_dd_confirm"]:
                    self.write_duration(fo.da.name, self.oo.index(fo))
                    m.refresh()

                self.unfocus()
                m.admin.push_modal()

            DDVAL(fo, "float [0,9]",
                end_fn      = end_fn,
                local_undo  = None)
    def fn_bool(self, fo):
        ty = type(fo)
        if ty == BU_FNDA:
            fo.on()
            m.redraw()
        elif ty == BU_BOOL_SIM:
            if fo.is_allow is False: return

            bu_ind = self.oo.index(fo)

            if bu_ind in {3, 8}:    self.write_exact(0 if fo.da.name else 1, bu_ind)
            else:                   self.write_repeat(0 if fo.da.name else 1, bu_ind)

            m.refresh()
            m.redraw()
            fo.is_allow = False
    def fn_copy(self, fo):
        print(f"    bu_block  KM(VAL)  fn_copy")
        ty = type(fo)
        if ty == BU_STR_SIM:
            bpy.context.window_manager.clipboard = f"{fo.da.text}"
        elif ty in {BU_FLOAT_SIM, BU_BOOL_SIM}:
            bpy.context.window_manager.clipboard = f"{fo.da.name}"
    def fn_paste(self, fo):
        print(f"    bu_block  KM(VAL)  fn_paste")
        ind = self.oo.index(fo)
        print(f"    bu_block  KM  fn_paste:  ind={ind}")
        s = bpy.context.window_manager.clipboard

        if ind in {2, 7, 12, 13}:
            try:    v = float(s)
            except: return

            self.write_duration(v, ind)
        elif ind in {1, 6, 10, 11}:
            if s in key_title_set:      self.write_value(key_title_to_value[s], ind)
            elif s in key_value_set:    self.write_value(s, ind)
            else:   return
        elif ind in {3, 8, 4, 9}:
            if s in {"TRUE", "true", "True", "1"}:      v = 1
            elif s in {"FALSE", "false", "False", "0"}: v = 0
            else:   return

            if ind in {3, 8}:   self.write_exact(v, ind)
            else:               self.write_repeat(v, ind)
        else:
            return

        m.refresh()
        m.redraw()
    def fn_reset(self, fo):
        print(f"    bu_block  KM(VAL)  fn_reset")
        prop = self.prop
        attr = self.attr
        bu_ind = self.oo.index(fo)
        print(f"    bu_block  KM  fn_reset:  bu_ind={bu_ind}")

        if bu_ind in {0, 5}:
            ind = 0  if bu_ind == 0 else 2
            v = prop.default_array[ind]
            old_v = attr[ind]
            attr[ind] = v
            self.last_data = [None]
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Combination {1 if ind == 0 else 2}'

            if hasattr(self, "attr2"):
                attr2 = self.attr2
                old_v2 = attr2[ind]
                attr2[ind] = v
                m.get_K()
                m.undo_push(
                    (
                        (prop.identifier, old_v, ind),
                        (self.prop2.identifier, old_v2, ind)),
                    m.get_K)
            else:
                m.get_K()
                m.undo_push(((prop.identifier, old_v, ind),), m.get_K)
        elif bu_ind in {1, 6, 10, 11}:
            v = (prop if bu_ind in {1, 6} else self.prop2).default_array[4]
            if bu_ind in {1, 10}:
                self.write_value(value_dict[v & 0b11111111], bu_ind)
            else:
                self.write_value(value_dict[v >> 8 & 0b11111111], bu_ind)
        elif bu_ind in {2, 7}:
            ind = 1  if bu_ind == 2 else 3
            v = prop.default_array[ind]
            old_v = attr[ind]
            attr[ind] = v
            self.last_data = [None]
            m.get_K()
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Duration {1 if ind == 1 else 2}'
            m.undo_push(((prop.identifier, old_v, ind),), m.get_K)
        elif bu_ind in {12, 13}:
            ind = 1  if bu_ind == 12 else 3
            v = self.prop2.default_array[ind]
            attr2 = self.attr2
            old_v = attr2[ind]
            attr2[ind] = v
            self.last_data = [None]
            m.get_K()
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Duration {1 if ind == 12 else 2}'
            m.undo_push(((self.prop2.identifier, old_v, ind),), m.get_K)
        elif bu_ind in {3, 4, 8, 9}:
            array = prop.default_array[4]
            k = R_unsign32(array)
            value0 = value_dict[k & 0b11111111]
            k >>= 0b1000
            value_0 = value_dict[k & 0b11111111]
            k >>= 0b1000
            repeat0 = 1 if k & 0b1 else 0
            k >>= 0b1
            repeat_0 = 1 if k & 0b1 else 0
            k >>= 0b1
            match0 = 1 if k & 0b1 else 0
            k >>= 0b1
            match_0 = 1 if k & 0b1 else 0

            if bu_ind == 3:
                self.write_exact(match0, bu_ind)
            elif bu_ind == 8:
                self.write_exact(match_0, bu_ind)
            elif bu_ind == 4:
                self.write_repeat(repeat0, bu_ind)
            else:
                self.write_repeat(repeat_0, bu_ind)

        m.refresh()
        m.redraw()

    def fn_rm(self, evt, o):
        print(f"    bu_block  KM  fn_rm")
        global tm
        tm = m.tm
        ty = type(o)

        if ty in {BU_STR_SIM, BU_FLOAT_SIM, BU_BOOL_SIM}:
            li = [
                {9: "rm_Copy_Value", 0: "Copy Value"},
                {9: "rm_Paste_Value", 0: "Paste Value"},
                {9: "rm_Reset_to_Default_Value", 0: "Reset to Default Value"},
            ]
        else:
            li = [
                {9: "rm_Reset_to_Default_Value", 0: "Reset to Default Value"},
            ]

        tm["o"] = o
        tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y, li)
        #
    def rm_Copy_Value(self):                self.fn_copy(tm["o"])
    def rm_Paste_Value(self):               self.fn_paste(tm["o"])
    def rm_Reset_to_Default_Value(self):    self.fn_reset(tm["o"])

    def upd_oo(self):
        is_dirty = False
        for e, o in zip(self.attr, self.last_data):
            if e != o:
                is_dirty = True
                break

        if is_dirty is False: return
        self.last_data = [e for e in self.attr]

        oo = self.oo
        s = self.prop.identifier[5:]
        print(f"    bu_block  KM  upd_oo:  key={s}, is_dirty=True")
        km0 = K[f'{s}0']
        km1 = K[f'{s}1']

        oo[0].da.text = R_tx_comb(km0)
        oo[5].da.text = R_tx_comb(km1)
        oo[1].da.text = key_value_to_title[km0.value]
        oo[6].da.text = key_value_to_title[km1.value]
        oo[2].set_da(km0.hold)
        oo[7].set_da(km1.hold)
        oo[3].set_da(km0.ll is not None)
        oo[8].set_da(km1.ll is not None)
        oo[4].set_da(km0.repeat)
        oo[9].set_da(km1.repeat)
        self.is_oo_2_dark = oo[1].da.text not in time_keys
        self.is_oo_7_dark = oo[6].da.text not in time_keys
    def dd_end_upd(self, b):
        print("    bu_block  KM  dd_end_upd")
        ty = type(b)
        if ty == BU_FLOAT_SIM:
            if b.da.name is None:   self.write_duration(self.qe_value, self.oo.index(b))

        m.refresh()
        self.unfocus()
        m.admin.push_modal()
    def is_to_modal_multi(self, evt, mk): return False
    def write_duration(self, v, bu_ind):
        if bu_ind == 2:
            attr = self.attr
            prop = self.prop
            ind = 1
        elif bu_ind == 7:
            attr = self.attr
            prop = self.prop
            ind = 3
        elif bu_ind == 12:
            attr = self.attr2
            prop = self.prop2
            ind = 1
        else:
            attr = self.attr2
            prop = self.prop2
            ind = 3

        e = struct_pack('!f', min(max(0.0, v), 9.0))
        v = e[3] | e[2] << 8 | e[1] << 16 | e[0] << 24
        old_v = attr[ind]
        attr[ind] = R_sign32(v)
        self.last_data = [None]
        m.get_K()
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Duration {1 if ind == 1 else 2}'
        m.undo_push(((prop.identifier, old_v, ind),), m.get_K)
    def write_value(self, v, bu_ind): # v in value
        if bu_ind == 1:
            old_v = self.attr[4]
            prop = self.prop
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111111111111111100000000 | dict_value[v])
        elif bu_ind == 6:
            old_v = self.attr[4]
            prop = self.prop
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111111110000000011111111 | dict_value[v] << 8)
        elif bu_ind == 10:
            old_v = self.attr2[4]
            prop = self.prop2
            self.attr2[4] = R_sign32(R_unsign32(old_v) & 0b11111111111111111111111100000000 | dict_value[v])
        else:
            old_v = self.attr2[4]
            prop = self.prop2
            self.attr2[4] = R_sign32(R_unsign32(old_v) & 0b11111111111111110000000011111111 | dict_value[v] << 8)

        self.last_data = [None]
        m.get_K()
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Value {1 if bu_ind in {1, 10} else 2}'
        m.undo_push(((prop.identifier, old_v, 4),), m.get_K)
    def write_exact(self, v, bu_ind): # v = 0 or 1
        old_v = self.attr[4]
        if bu_ind == 3:
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111110111111111111111111 | v << 18)
        else:
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111101111111111111111111 | v << 19)

        self.last_data = [None]
        m.get_K()
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Exact'
        m.undo_push(((self.prop.identifier, old_v, 4),), m.get_K)
    def write_repeat(self, v, bu_ind):
        old_v = self.attr[4]
        if bu_ind == 4:
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111111101111111111111111 | v << 16)
        else:
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111111011111111111111111 | v << 17)

        self.last_data = [None]
        m.get_K()
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Repeat'
        m.undo_push(((self.prop.identifier, old_v, 4),), m.get_K)
    def write_type(self, lis, bu_oo):
        ind = bu_oo.ti.name
        old_v = self.attr[ind]
        for r in range(len(lis), 4):    lis.append(False)

        k1, k2, k3, k4 = lis
        v = dict_type[k1]  if k1 in dict_type else non_release[k1]
        v |= (dict_type[k2]  if k2 in dict_type else non_release[k2]) << 8
        v |= (dict_type[k3]  if k3 in dict_type else non_release[k3]) << 16
        v |= (dict_type[k4]  if k4 in dict_type else non_release[k4]) << 24

        self.attr[ind] = R_sign32(v)
        self.last_data = [None]
        m.get_K()
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Combination {1 if ind == 0 else 2}'
        m.undo_push(((self.prop.identifier, old_v, ind),), m.get_K)
    #
    #
class KM2(KM):
    __slots__ = 'prop2', 'attr2', 'is_oo_12_dark', 'is_oo_13_dark', 'last_data2'
    def __init__(self, w, prop, prop2):
        self.w = w
        self.prop = prop
        self.prop2 = prop2
        self.attr = getattr(P, prop.identifier)
        self.attr2 = getattr(P, prop2.identifier)
        self.last_data = [None]
        self.last_data2 = [None]
        self.oo_fo = None

        self.rim = BOX()
        self.ti = BLF(text=prop.name)
        self.hi = F[150] + F[16]

        oo = [
            BU_FNDA(self, "Edit Combination 1", 0),
            BU_STR_SIM(self, "", None, False),
            BU_FLOAT_SIM(self, 0, None, "sec"),
            BU_BOOL_SIM(self, False, None, False),
            BU_BOOL_SIM(self, False, None, False),
            BU_FNDA(self, "Edit Combination 2", 2),
            BU_STR_SIM(self, "", None, False),
            BU_FLOAT_SIM(self, 0, None, "sec"),
            BU_BOOL_SIM(self, False, None, False),
            BU_BOOL_SIM(self, False, None, False),
            BU_STR_SIM(self, "", None, False),
            BU_STR_SIM(self, "", None, False),
            BU_FLOAT_SIM(self, 0, None, False),
            BU_FLOAT_SIM(self, 0, None, False),
        ]
        self.oo = oo
        self.sub_ti = [
            BLF(text="Start / End Value"),
            BLF(text="Duration"),
            BLF(text="Exact"),
            BLF(text="Repeat"),
            BLF(text="Start / End Value"),
            BLF(text="Duration"),
            BLF(text="Exact"),
            BLF(text="Repeat"),
        ]
        self.bo_end = BOX(P.color_oj_info)

    def get_bo(self, L, R, T):
        rim = self.rim
        B = T - self.hi
        rim.LRBT_upd(L, R, B, T)
        self.bo_end.LRBT_upd(L, R, B, B + F[14])

        ti = self.ti
        ti.LT(rim, F[8], F[17])

        _1 = F[1]
        _2 = F[2]
        hi = F[16]
        wi = F[93]
        R5 = R - F[6]
        R4 = R5 - hi
        x0 = R4 - F[34] + _2
        x1 = R4 - F[38]
        L = ti.x
        R = L + wi
        T -= F[24]
        B = T - hi
        L0 = L + F[6]
        L1 = L + _1
        L2 = R + F[10]
        ti_dy = F[4]

        oo = self.oo
        sub_ti = self.sub_ti
        e = oo[0]
        e.rim.LRBT_upd(L, R, B, T)
        e.bo.LRBT_upd(L1, R, B, T - _1)
        e.ti.xy(L0, B + ti_dy)
        e.da.xy(L2, e.ti.y)

        dB = F[22]
        T -= dB
        B -= dB
        L3 = R - F[10]
        x_value = L3 + ti_dy
        R0 = L3 + wi
        R6 = R4 + F[1.5]
        y = B + ti_dy
        e = oo[1]
        e.rim.LRBT_upd(L3, R0, B, T)
        e.da.xy(x_value, y)
        sub_ti[0].xy(L0, y)
        e = oo[3]
        e.rim.LRBT_upd(R4, R5, B, T)
        e.da.xy(R6, B)
        sub_ti[2].xy(x0, y)

        T = B - _2
        B = T - hi
        y = B + ti_dy
        x_sec = L3 - F[18]
        e = oo[2]
        e.rim.LRBT_upd(L3, R0, B, T)
        e.da.xy(x_value, y)
        e.ti.xy(x_sec, y)
        sub_ti[1].xy(L0, y)
        e = oo[4]
        e.rim.LRBT_upd(R4, R5, B, T)
        e.da.xy(R6, B)
        sub_ti[3].xy(x1, y)
        #
        T = B - F[8]
        B = T - hi
        y = B + ti_dy
        e = oo[5]
        e.rim.LRBT_upd(L, R, B, T)
        e.bo.LRBT_upd(L1, R, B, T - _1)
        e.ti.xy(L0, B + ti_dy)
        e.da.xy(L2, e.ti.y)

        T -= dB
        B -= dB
        y = B + ti_dy
        e = oo[6]
        e.rim.LRBT_upd(L3, R0, B, T)
        e.da.xy(x_value, y)
        sub_ti[4].xy(L0, y)
        e = oo[8]
        e.rim.LRBT_upd(R4, R5, B, T)
        e.da.xy(R6, B)
        sub_ti[6].xy(x0, y)

        T = B - _2
        B = T - hi
        y = B + ti_dy
        e = oo[7]
        e.rim.LRBT_upd(L3, R0, B, T)
        e.da.xy(x_value, y)
        e.ti.xy(x_sec, y)
        sub_ti[5].xy(L0, y)
        e = oo[9]
        e.rim.LRBT_upd(R4, R5, B, T)
        e.da.xy(R6, B)
        sub_ti[7].xy(x1, y)

        R0 += _2
        R = R0 + wi
        x_da = R0 + ti_dy
        r = oo[1].rim
        B = r.B
        e = oo[10]
        e.rim.LRBT_upd(R0, R, B, r.T)
        e.da.xy(x_da, B + ti_dy)
        r = oo[6].rim
        B = r.B
        e = oo[11]
        e.rim.LRBT_upd(R0, R, B, r.T)
        e.da.xy(x_da, B + ti_dy)

        r = oo[2].rim
        B = r.B
        e = oo[12]
        e.rim.LRBT_upd(R0, R, B, r.T)
        e.da.xy(x_da, B + ti_dy)
        r = oo[7].rim
        B = r.B
        e = oo[13]
        e.rim.LRBT_upd(R0, R, B, r.T)
        e.da.xy(x_da, B + ti_dy)

    def draw_oo_bo(self):
        oo = self.oo
        m.bind_color_bu_1_rim()
        oo_0 = oo[0]
        oo_5 = oo[5]
        oo_0.draw_rim()
        oo_5.draw_rim()

        oo_0.draw_bo()
        oo_5.draw_bo()
        for r in range(1, 5):   oo[r].rim.bind_draw()
        for r in range(6, 14):  oo[r].rim.bind_draw()
        self.bo_end.bind_draw()
        #
    def draw_oo_da(self):
        oo = self.oo
        oo[0].draw_ti()
        oo[1].da.draw_pos()
        oo[10].da.draw_pos()

        if self.is_oo_2_dark:
            blf_color(font_0, *P.color_font_ignore)
            oo[2].da.draw_pos()
            blf_color(font_0, *P.color_font)
        else: oo[2].da.draw_pos()
        if self.is_oo_12_dark:
            blf_color(font_0, *P.color_font_ignore)
            oo[12].da.draw_pos()
            blf_color(font_0, *P.color_font)
        else: oo[12].da.draw_pos()

        oo[5].draw_ti()
        oo[6].da.draw_pos()
        oo[11].da.draw_pos()

        if self.is_oo_7_dark:
            blf_color(font_0, *P.color_font_ignore)
            oo[7].da.draw_pos()
            blf_color(font_0, *P.color_font)
        else: oo[7].da.draw_pos()
        if self.is_oo_13_dark:
            blf_color(font_0, *P.color_font_ignore)
            oo[13].da.draw_pos()
            blf_color(font_0, *P.color_font)
        else: oo[13].da.draw_pos()

        for e in self.sub_ti:   e.draw_pos()

    def upd_oo(self):
        is_dirty = False
        for e, o in zip(self.attr, self.last_data):
            if e != o:
                is_dirty = True
                break

        if is_dirty is False:
            for e, o in zip(self.attr2, self.last_data2):
                if e != o:
                    is_dirty = True
                    break

        if is_dirty is False: return
        self.last_data = [e for e in self.attr]
        self.last_data2 = [e for e in self.attr2]

        oo = self.oo
        s = self.prop.identifier[5:]
        print(f"    bu_block  KM2  upd_oo:  key={s}, is_dirty=True")
        km0 = K[f'{s}0']
        km1 = K[f'{s}1']

        oo[0].da.text = R_tx_comb(km0)
        oo[5].da.text = R_tx_comb(km1)
        oo[1].da.text = key_value_to_title[km0.value]
        oo[6].da.text = key_value_to_title[km1.value]
        oo[2].set_da(km0.hold)
        oo[7].set_da(km1.hold)
        oo[3].set_da(km0.ll is not None)
        oo[8].set_da(km1.ll is not None)
        oo[4].set_da(km0.repeat)
        oo[9].set_da(km1.repeat)
        self.is_oo_2_dark = oo[1].da.text not in time_keys
        self.is_oo_7_dark = oo[6].da.text not in time_keys

        s = self.prop2.identifier[5:]
        km0 = K[f'{s}0']
        km1 = K[f'{s}1']
        oo[10].da.text = key_value_to_title[km0.value]
        oo[11].da.text = key_value_to_title[km1.value]
        oo[12].set_da(km0.hold)
        oo[13].set_da(km1.hold)
        self.is_oo_12_dark = oo[10].da.text not in time_keys
        self.is_oo_13_dark = oo[11].da.text not in time_keys

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.rim.in_BT_y(y) is False:
            self.unfocus()
            return False

        oo = self.oo
        fo = None

        if oo[0].rim.in_LR_x(x):
            if oo[0].rim.in_BT_y(y):    fo = oo[0]
            elif oo[5].rim.in_BT_y(y):  fo = oo[5]
        elif oo[1].rim.in_LR_x(x):
            if oo[1].rim.in_BT_y(y):    fo = oo[1]
            elif oo[2].rim.in_BT_y(y):  fo = oo[2]
            elif oo[6].rim.in_BT_y(y):  fo = oo[6]
            elif oo[7].rim.in_BT_y(y):  fo = oo[7]
        elif oo[3].rim.in_LR_x(x):
            if oo[3].rim.in_BT_y(y):    fo = oo[3]
            elif oo[4].rim.in_BT_y(y):  fo = oo[4]
            elif oo[8].rim.in_BT_y(y):  fo = oo[8]
            elif oo[9].rim.in_BT_y(y):  fo = oo[9]
        elif oo[10].rim.in_LR_x(x):
            if oo[10].rim.in_BT_y(y):   fo = oo[10]
            elif oo[11].rim.in_BT_y(y): fo = oo[11]
            elif oo[12].rim.in_BT_y(y): fo = oo[12]
            elif oo[13].rim.in_BT_y(y): fo = oo[13]

        if fo is None:  self.unfocus()
        else:
            if self.oo_fo is None:
                fo.focus()
                self.oo_fo = fo
                m.redraw()
            elif self.oo_fo != fo:
                self.oo_fo.unfocus()
                fo.focus()
                self.oo_fo = fo
                m.redraw()
            elif evt.value == 'RELEASE':
                if hasattr(fo, "is_allow"): fo.is_allow = True

            if K["bu_qe0"].true():
                self.key_end = K["bu_qe_E0"]
                self.to_modal_qe(evt, fo, K["bu_qe0"])
                return True
            if K["bu_qe1"].true():
                self.key_end = K["bu_qe_E1"]
                self.to_modal_qe(evt, fo, K["bu_qe1"])
                return True
            if K["sel0"].true() or K["sel1"].true():
                self.fn(fo)
                return True
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.fn_bool(fo)
                return True
            if K["rm0"].true() or K["rm1"].true():
                self.fn_rm(evt, fo)
                return True
            if K["dd_copy0"].true() or K["dd_copy1"].true():
                self.fn_copy(fo)
                return True
            if K["dd_paste0"].true() or K["dd_paste1"].true():
                self.fn_paste(fo)
                return True
            if K["bu_reset0"].true() or K["bu_reset1"].true():
                self.fn_reset(fo)
                return True
        return False

    def write_exact(self, v, bu_ind): # v = 0 or 1
        old_v = self.attr[4]
        old_v2 = self.attr2[4]
        if bu_ind == 3:
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111110111111111111111111 | v << 18)
            self.attr2[4] = R_sign32(R_unsign32(old_v2) & 0b11111111111110111111111111111111 | v << 18)
        else:
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111101111111111111111111 | v << 19)
            self.attr2[4] = R_sign32(R_unsign32(old_v2) & 0b11111111111101111111111111111111 | v << 19)

        self.last_data = [None]
        m.get_K()
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Exact'
        m.undo_push(
            (
                (self.prop.identifier, old_v, 4),
                (self.prop2.identifier, old_v2, 4)),
            m.get_K)
    def write_repeat(self, v, bu_ind):
        old_v = self.attr[4]
        old_v2 = self.attr2[4]
        if bu_ind == 4:
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111111101111111111111111 | v << 16)
            self.attr2[4] = R_sign32(R_unsign32(old_v2) & 0b11111111111111101111111111111111 | v << 16)
        else:
            self.attr[4] = R_sign32(R_unsign32(old_v) & 0b11111111111111011111111111111111 | v << 17)
            self.attr2[4] = R_sign32(R_unsign32(old_v2) & 0b11111111111111011111111111111111 | v << 17)

        self.last_data = [None]
        m.get_K()
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Repeat'
        m.undo_push(
            (
                (self.prop.identifier, old_v, 4),
                (self.prop2.identifier, old_v2, 4)),
            m.get_K)
    def write_type(self, lis, bu_oo):
        ind = bu_oo.ti.name
        old_v = self.attr[ind]
        old_v2 = self.attr2[ind]
        for r in range(len(lis), 4):    lis.append(False)

        k1, k2, k3, k4 = lis
        v = dict_type[k1]  if k1 in dict_type else non_release[k1]
        v |= (dict_type[k2]  if k2 in dict_type else non_release[k2]) << 8
        v |= (dict_type[k3]  if k3 in dict_type else non_release[k3]) << 16
        v |= (dict_type[k4]  if k4 in dict_type else non_release[k4]) << 24

        self.attr[ind] = R_sign32(v)
        self.attr2[ind] = R_sign32(v)
        self.last_data = [None]
        m.get_K()
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Combination {1 if ind == 0 else 2}'
        m.undo_push(
            (
                (self.prop.identifier, old_v, ind),
                (self.prop2.identifier, old_v2, ind)),
            m.get_K)
    #
    #
class KM_SEL(KM2):
    __slots__ = ()
    def write_value(self, v, bu_ind): pass
    def fn(self, fo):
        print(f"    bu_block  KM_SEL(VAL)  fn")
        ty = type(fo)
        if ty == BU_FNDA:   KEY_ED(fo, m.EVT.evt)
        elif ty == BU_STR_SIM:
            bu_ind = self.oo.index(fo)

            def end_fn():
                print("    bu_block  KM_SEL  fn  end_fn  dd end")
                fo.da.text = fo.da.name
                self.unfocus()

            fo.da.name = fo.da.text
            enums = (m.NAME_VAL('Press', 'PRESS'),) if bu_ind in {1, 6} else (m.NAME_VAL('Release', 'RELEASE'),)

            DDTX(fo, FIL(enums), tx_clear=True, end_fn=end_fn)
        elif ty == BU_FLOAT_SIM:

            def end_fn():
                print("    bu_block  KM_SEL  fn  end_fn  dd end")
                if m.tm["is_dd_confirm"]:
                    self.write_duration(fo.da.name, self.oo.index(fo))
                    m.refresh()

                self.unfocus()
                m.admin.push_modal()

            DDVAL(fo, "float [0,9]",
                end_fn      = end_fn,
                local_undo  = None)
    #
    #


def get_block(w, prop): # blf_size(font_0, F[8], 72), blf_wrap
    subtype = prop.subtype
    ty = prop.type
    if subtype == "COLOR":  return COLOR(w, prop)
    else:
        if ty == "INT":         return VAL(w, prop, BU_INT, subtype)
        elif ty == "FLOAT":     return VAL(w, prop, BU_FLOAT, subtype)
        elif ty == "BOOLEAN":   return BOOL(w, prop)
        elif ty == "ENUM":      return ENUM(w, prop)
        elif ty == "STRING":    return STRING(w, prop)
        else:
            print("TODO ........", ty)
    #