import bpy

def R_drfc_add(tar, tar_dp, index):
    try:    return tar.driver_add(tar_dp, index)
    except: return tar.driver_add(tar_dp)
def R_kffc_add(tar_fcs, tar_dp, index, action_group):
    try:    return tar_fcs.new(tar_dp, index, action_group)
    except: pass
    try:    return tar_fcs.new(tar_dp, index)
    except: return tar_fcs.new(tar_dp)

def TR_drivers(oj):
    try:    return oj.animation_data.drivers
    except: return None
def TR_driver(oj, data_path, index=0):
    try:    return oj.animation_data.drivers.find(data_path, index=index)
    except: return None
def TR_action_fcurves(oj):
    try:    return oj.animation_data.action.fcurves
    except: return None

def TR_dr_add(oj, dp):
    try:    return oj.driver_add(dp)
    except: return None
def TR_dr_add_index(oj, dp, index):
    try:    return oj.driver_add(dp, index=index)
    except: return None

def is_target_path_valid(obj, path):
    try:
        eval(f'obj.{path}')
        return True
    except:
        return False

def is_custom_path_valid(obj, path):
    try:
        eval(f'obj{path}')
        return True
    except:
        return False

def copyFcAttr(fc_from, dr_to):
    dr_to.auto_smoothing    = fc_from.auto_smoothing
    dr_to.color             = fc_from.color
    dr_to.color_mode        = fc_from.color_mode
    dr_to.extrapolation     = fc_from.extrapolation
    dr_to.hide              = fc_from.hide
    dr_to.is_valid          = fc_from.is_valid
    dr_to.lock              = fc_from.lock
    dr_to.mute              = fc_from.mute

def copyVariable(v_from, v_to):
    v_to.type   = v_from.type
    v_to.name   = v_from.name
    tar_to      = v_to.targets[0]
    tar_from    = v_from.targets[0]

    try:
        tar_to.id_type          = tar_from.id_type
    except: pass
    tar_to.id               = tar_from.id
    tar_to.data_path        = tar_from.data_path
    tar_to.rotation_mode    = tar_from.rotation_mode
    tar_to.transform_type   = tar_from.transform_type
    tar_to.transform_space  = tar_from.transform_space
    tar_to.bone_target      = tar_from.bone_target

    if len(v_from.targets) == 2:
        tar_to      = v_to.targets[1]
        tar_from    = v_from.targets[1]

        try:
            tar_to.id_type          = tar_from.id_type
        except: pass
        tar_to.id               = tar_from.id
        tar_to.data_path        = tar_from.data_path
        tar_to.rotation_mode    = tar_from.rotation_mode
        tar_to.transform_type   = tar_from.transform_type
        tar_to.transform_space  = tar_from.transform_space
        tar_to.bone_target      = tar_from.bone_target

def copy_md_driver(fc_from, tar, tar_dp):
    fc = R_drfc_add(tar, tar_dp, fc_from.array_index)
    if type(fc) == list:    fc = fc[fc_from.array_index]
    fc.data_path = tar_dp
    copyFcAttr(fc_from, fc)

    dr_to   = fc.driver
    dr_from = fc_from.driver
    dr_to.type          = dr_from.type
    dr_to.expression    = dr_from.expression
    dr_to.is_valid      = dr_from.is_valid
    dr_to.use_self      = dr_from.use_self

    variables = dr_to.variables
    for v in dr_from.variables:
        var = variables.new()
        copyVariable(v, var)

def copy_md_kf(fc_from, tar, tar_dp): # fc must not exist
    is_empty = False
    if tar.animation_data:
        if tar.animation_data.action is None:           is_empty = True
        elif tar.animation_data.action.fcurves is None: is_empty = True
    else: is_empty = True

    if is_empty:
        if tar.keyframe_insert(data_path = tar_dp) == False: return
        fcs     = tar.animation_data.action.fcurves
        fc      = fcs.find(tar_dp)
        fcs.remove(fc)
    else:
        fcs     = tar.animation_data.action.fcurves

    fc = R_kffc_add(fcs, tar_dp, fc_from.array_index, fc_from.group)
    fc.data_path = tar_dp
    copyFcAttr(fc_from, fc)

    kps = fc.keyframe_points
    for kp in fc_from.keyframe_points:
        kp_new = kps.insert(*kp.co, keyframe_type = kp.type)
        kp_new.amplitude            = kp.amplitude
        kp_new.back                 = kp.back
        kp_new.easing               = kp.easing
        kp_new.handle_left_type     = kp.handle_left_type
        kp_new.handle_left[0]       = kp.handle_left[0]
        kp_new.handle_left[1]       = kp.handle_left[1]
        kp_new.handle_right_type    = kp.handle_right_type
        kp_new.handle_right[0]      = kp.handle_right[0]
        kp_new.handle_right[1]      = kp.handle_right[1]
        kp_new.interpolation        = kp.interpolation
        kp_new.period               = kp.period
        kp_new.select_control_point = kp.select_control_point
        kp_new.select_left_handle   = kp.select_left_handle
        kp_new.select_right_handle  = kp.select_right_handle

def is_dead(obj):
    try:    obj.name; return False
    except: return True

def link_modifier(obj_from, obj_to, md_from, md_to): # md_to must clean
    link_mds    = bpy.data.link_mds
    attrs       = getattr(MOD_ATTR, md_to.type, None)
    if attrs is None:   attr0, attr1 = dir(md_to), {}
    else:
        attr0 = [e for e in attrs] + [e for e in getattr(MOD_EX_ATTR, md_to.type)]
        attr1 = getattr(MOD_REF_ATTR, md_to.type)

    for attr in attr0:
        fc              = TR_dr_add(md_to, attr)
        if fc is None:  continue
        if isinstance(fc, list):
            for ind, fc in enumerate(fc):
                dr              = fc.driver
                if dr.variables:
                    obj_to.animation_data.drivers.remove(fc)
                    fc = TR_dr_add_index(md_to, attr, ind)
                    dr = fc.driver
                v               = dr.variables.new()
                tar             = v.targets[0]
                tar.id          = obj_from
                tar.data_path   = f'modifiers["{md_from.name}"].{attr}'
                dr.expression   = f"var[{ind}]"
        else:
            dr              = fc.driver
            if dr.variables:
                obj_to.animation_data.drivers.remove(fc)
                fc = TR_dr_add(md_to, attr)
                dr = fc.driver
            v               = dr.variables.new()
            tar             = v.targets[0]
            tar.id          = obj_from
            tar.data_path   = f'modifiers["{md_from.name}"].{attr}'
            dr.expression   = "var"

    s0 = f'modifiers[{md_to.name}].'
    for attr in attr1:
        path            = s0 + attr
        obj_to[path]    = True
        fc              = obj_to.driver_add(f'["{path}"]')
        dr              = fc.driver
        if dr.variables:
            obj_to.animation_data.drivers.remove(fc)
            fc = obj_to.driver_add(f'["{path}"]')
            dr = fc.driver
        v               = dr.variables.new()
        tar             = v.targets[0]
        tar.id          = obj_from
        v.name          = md_from.name

        link_mds[fc] = obj_to

def deep_link_modifier(obj_from, obj_to, md_from, md_to): # md_to must clean
    link_mds    = bpy.data.link_mds
    attrs       = getattr(MOD_ATTR, md_to.type, None)
    if attrs is None:     attr0, attr1 = dir(md_to), {}
    else:
        attr0 = [e for e in attrs] + [e for e in getattr(MOD_EX_ATTR, md_to.type)]
        attr1 = getattr(MOD_REF_ATTR, md_to.type)

    for attr in attr0:
        fc              = TR_dr_add(md_to, attr)
        if fc is None:  continue
        if isinstance(fc, list):
            for ind, fc in enumerate(fc):
                dr              = fc.driver
                if dr.variables:
                    obj_to.animation_data.drivers.remove(fc)
                    fc = TR_dr_add_index(md_to, attr, ind)
                    dr = fc.driver
                v               = dr.variables.new()
                tar             = v.targets[0]

                obj             = obj_from
                path_link       = f'modifiers["{md_from.name}"].{attr}'

                for r in range(999):
                    fc_next     = TR_driver(obj, path_link, ind)
                    if fc_next is not None:
                        if fc_next.driver.type == 'SCRIPTED':
                            vs  = fc_next.driver.variables
                            if len(vs) == 1:
                                v0      = vs[0]
                                if fc_next.driver.expression == f'{v0.name}[{ind}]':
                                    tar0        = v0.targets[0]
                                    if tar0.id_type == 'OBJECT':
                                        if is_target_path_valid(tar0.id, tar0.data_path):
                                            obj         = tar0.id
                                            path_link   = tar0.data_path
                                            continue

                    break

                tar.id          = obj
                tar.data_path   = path_link
                dr.expression   = f"var[{ind}]"
        else:
            dr              = fc.driver
            if dr.variables:
                obj_to.animation_data.drivers.remove(fc)
                fc = TR_dr_add(md_to, attr)
                dr = fc.driver
            v               = dr.variables.new()
            tar             = v.targets[0]

            obj             = obj_from
            path_link       = f'modifiers["{md_from.name}"].{attr}'

            for r in range(999):
                fc_next     = TR_driver(obj, path_link)
                if fc_next is not None:
                    if fc_next.driver.type == 'SCRIPTED':
                        vs  = fc_next.driver.variables
                        if len(vs) == 1:
                            v0      = vs[0]
                            if fc_next.driver.expression == v0.name:
                                tar0        = v0.targets[0]
                                if tar0.id_type == 'OBJECT':
                                    if is_target_path_valid(tar0.id, tar0.data_path):
                                        obj         = tar0.id
                                        path_link   = tar0.data_path
                                        continue

                break

            tar.id          = obj
            tar.data_path   = path_link
            dr.expression   = "var"

    s0 = f'modifiers[{md_to.name}].'
    for attr in attr1:
        path            = s0 + attr
        obj_to[path]    = True
        fc              = obj_to.driver_add(f'["{path}"]')
        dr              = fc.driver
        if dr.variables:
            obj_to.animation_data.drivers.remove(fc)
            fc = obj_to.driver_add(f'["{path}"]')
            dr = fc.driver
        v               = dr.variables.new()
        tar             = v.targets[0]

        obj             = obj_from
        md_name         = md_from.name

        for r in range(999):
            fc_next     = TR_driver(obj, f'["modifiers[{md_name}].{attr}"]')
            print(f"    link_data  deep_link_modifier:  fc_next={fc_next}")
            if fc_next is not None:
                if fc_next.driver.type == 'SCRIPTED':
                    vs  = fc_next.driver.variables
                    if len(vs) == 1:
                        v0      = vs[0]
                        tar0    = v0.targets[0]
                        if tar0.id_type == 'OBJECT':
                            obj     = tar0.id
                            md_name = v0.name
                            continue
            break

        tar.id          = obj
        v.name          = md_name

        link_mds[fc] = obj_to

def R_md_driver_add(oj, md_name, attr, exp="var", index=None):
    try:
        if index is None:
            old_dr = TR_driver(oj, f'modifiers["{md_name}"].{attr}')
            if old_dr is not None: return old_dr
            dr = oj.modifiers[md_name].driver_add(attr)
        else:
            old_dr = TR_driver(oj, f'modifiers["{md_name}"].{attr}', index)
            if old_dr is not None: return old_dr
            dr = oj.modifiers[md_name].driver_add(attr, index)
        driver = dr.driver
        v = driver.variables.new()
        driver.expression = exp
        return dr
    except: # not animatable
        path = f'modifiers[{md_name}].{attr}'
        old_fc = TR_driver(oj, f'["{path}"]')
        if old_fc is not None: return old_fc

        oj[path]  = True
        fc = oj.driver_add(f'["{path}"]')
        bpy.data.link_mds[fc] = oj
        v = fc.driver.variables.new()
        v.name = md_name
        return fc
def R_md_driver_remove(oj, md_name, attr, index=None): # need refresh
    if index is None:
        success = oj.modifiers[md_name].driver_remove(attr)
    else:
        success = oj.modifiers[md_name].driver_remove(attr, index)

    if not success:
        try:
            if not oj.animation_data:           return False
            if not oj.animation_data.drivers:   return False
            path = f'modifiers[{md_name}].{attr}'
            dr = oj.animation_data.drivers.find(f'["{path}"]')
            if dr is None: return False
            if dr in bpy.data.link_mds:
                del bpy.data.link_mds[dr]

            if path in oj:
                del oj[path]

            oj.animation_data.drivers.remove(dr)
            return True
        except:
            return False
    return True


class DrTar:
    __slots__ = 'id_type', 'id', 'transform_type', 'transform_space', 'rotation_mode', 'data_path', 'bone_target',
    def __init__(self, tar):
        self.id_type = tar.id_type
        self.id = tar.id
        self.transform_type = tar.transform_type
        self.transform_space = tar.transform_space
        self.rotation_mode = tar.rotation_mode
        self.data_path = tar.data_path
        self.bone_target = tar.bone_target
class DrVar:
    __slots__ = 'name', 'type', 'tar0', 'tar1'
    def __init__(self, v):
        self.name = v.name
        self.type = v.type
        self.tar0 = DrTar(v.targets[0])
        self.tar1 = DrTar(v.targets[1])  if len(v.targets) == 2 else None

    def write(self, v):
        v.name = self.name
        v.type = self.type
        e = v.targets[0]
        o = self.tar0
        if e.id_type != o.id_type:  e.id_type = o.id_type
        e.id = o.id
        e.transform_type = o.transform_type
        e.transform_space = o.transform_space
        e.rotation_mode = o.rotation_mode
        e.data_path = o.data_path
        e.bone_target = o.bone_target
        if self.tar1 is not None:
            e = v.targets[1]
            o = self.tar1
            if e.id_type != o.id_type:  e.id_type = o.id_type
            e.id = o.id
            e.transform_type = o.transform_type
            e.transform_space = o.transform_space
            e.rotation_mode = o.rotation_mode
            e.data_path = o.data_path
            e.bone_target = o.bone_target


def dr_var_move_to_ind(variables, name, ind):
    old_ind = variables.find(name)
    v = variables[name]
    names = {v.name for v in variables}
    tm_dic = {}
    i = 0
    if old_ind < ind:
        for r in range(old_ind, ind + 1):
            e = variables[r]
            tm_dic[r] = DrVar(e)
            while True:
                if str(i) in names: i += 1
                else:
                    e.name = str(i)
                    break
            i += 1

        for r in range(old_ind, ind):
            tm_dic[r + 1].write(variables[r])

        tm_dic[old_ind].write(variables[ind])
    else:
        for r in range(ind, old_ind + 1):
            e = variables[r]
            tm_dic[r] = DrVar(e)
            while True:
                if str(i) in names: i += 1
                else:
                    e.name = str(i)
                    break
            i += 1

        tm_dic[old_ind].write(variables[ind])
        for r in range(ind + 1, old_ind + 1):
            tm_dic[r - 1].write(variables[r])

    del names
    del tm_dic


class MOD_ARRAY_ATTR:
    __slots__ = ()
    ARMATURE = ()
    ARRAY = ('constant_offset_displace', 'relative_offset_displace')
    BOOLEAN = ()
    BEVEL = ()
    #
    #
class MOD_REF_ATTR:
    __slots__ = ()
    ARMATURE = (
        'object',
        'use_bone_envelopes',
        'use_vertex_groups',
        'vertex_group',)
    ARRAY = (
        'curve',
        'end_cap',
        'offset_object',
        'start_cap',)
    BOOLEAN = (
        'object',)
    BEVEL = (
        'vertex_group',)
    #
    #
class MOD_EX_ATTR:
    __slots__ = ()
    EX2 = ('show_viewport', 'show_render')
    EX3 = ('show_in_editmode', 'show_viewport', 'show_render')
    EX4 = ('show_on_cage', 'show_in_editmode', 'show_viewport', 'show_render')

    ARMATURE = EX4
    ARRAY = EX4
    BOOLEAN = EX3
    BEVEL = EX3
    #
    #
class MOD_ATTR:
    __slots__ = ()
    ARMATURE = (
        'invert_vertex_group',
        'use_deform_preserve_volume',
        'use_multi_modifier',)
    ARRAY = (
        'constant_offset_displace',
        'count',
        'fit_length',
        'fit_type',
        'merge_threshold',
        'offset_u',
        'offset_v',
        'relative_offset_displace',
        'use_constant_offset',
        'use_merge_vertices',
        'use_merge_vertices_cap',
        'use_object_offset',
        'use_relative_offset',)
    BOOLEAN = (
        'double_threshold',
        'operand_type',
        'operation',
        'solver',
        'use_hole_tolerant',
        'use_self',)
    BEVEL = (
        'affect',
        'angle_limit',
        'face_strength_mode',
        'harden_normals',
        'invert_vertex_group',
        'limit_method',
        'loop_slide',
        'mark_seam',
        'mark_sharp',
        'material',
        'miter_inner',
        'miter_outer',
        'offset_type',
        'profile',
        'profile_type',
        'segments',
        'spread',
        'use_apply_on_spline',
        'use_clamp_overlap',
        'vmesh_method',
        'width',
        'width_pct',)

D_apply_as = {
    'ARMATURE': 0,
    'CAST': 1,
    'CLOTH': 2,
    'COLLISION': 3,
    'CORRECTIVE_SMOOTH': 4,
    'CURVE': 5,
    'DISPLACE': 6,
    'HOOK': 7,
    'LAPLACIANDEFORM': 8,
    'LAPLACIANSMOOTH': 9,
    'LATTICE': 10,
    'MESH_CACHE': 11,
    'MESH_DEFORM': 12,
    'PARTICLE_SYSTEM': 13,
    'SHRINKWRAP': 14,
    'SIMPLE_DEFORM': 15,
    'SMOOTH': 16,
    'SOFT_BODY': 17,
    'SURFACE': 18,
    'SURFACE_DEFORM': 19,
    'WARP': 20,
    'WAVE': 21,
}
D_apply_on_spline = {
    'ARMATURE': 0,
    'CAST': 1,
    'CURVE': 2,
    'LATTICE': 3,
    'SHRINKWRAP': 4,
    'SIMPLE_DEFORM': 5,
    'SMOOTH': 6,
    'WARP': 7,
    'WAVE': 8,
}
D_only_one = {
    'CLOTH',
    'COLLISION',
    'FLUID',
    'SOFT_BODY',
}