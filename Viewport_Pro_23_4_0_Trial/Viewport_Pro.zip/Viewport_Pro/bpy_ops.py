import bpy, base64
from ast import literal_eval
from bpy.types import Operator

from . import m

class VPP_FACTORY(Operator):
    bl_idname = "wm.vpp_factory"
    bl_label = "Restore to Factory settings"
    bl_options = {'REGISTER'}

    @staticmethod
    def main(reset_keymap=True):
        P = m.P
        props = P.bl_rna.properties

        for at in props:
            if hasattr(at, "default"):
                if at.identifier in {"bl_idname", "refresh"}: continue
                if getattr(at, "is_array", False):
                    getattr(P, at.identifier)[:] = at.default_array
                else:
                    setattr(P, at.identifier, at.default)

        if reset_keymap:
            try:
                wm = bpy.context.window_manager
                kc = wm.keyconfigs.addon
                if kc:
                    kms = kc.keymaps
                    if "Screen" in kms:
                        kms["Screen"].restore_to_default()
                    else:
                        km = kms.new(name="Screen")
                        kmi = km.keymap_items
                        cls_ops_kms = getattr(m, "cls_ops_kms", None)

                        if cls_ops_kms:
                            r = 3
                            for cls in cls_ops_kms:
                                kmi.new(cls.bl_idname, type=f'F1{r}', value='PRESS')
                                r += 1
            except: pass

        try:
            m.get_K()
            m.refresh()
            m.redraw()
            P.scale[0] = P.scale[0]
        except: pass

    def execute(self, context):
        self.__class__.main()
        return {'FINISHED'}
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    #
    #
class VPP_BEVEL_PROFILE(Operator):
    bl_idname = "wm.vpp_bevel_profile"
    bl_label = "Custom Profile"
    bl_options = {'INTERNAL'}

    md = None

    def execute(self, context): return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.template_curveprofile(VPP_BEVEL_PROFILE.md, "custom_profile")
    #
    #
class VPP_FALLOFF_CURVE(Operator):
    bl_idname = "wm.vpp_falloff_curve"
    bl_label = "Falloff Curve"
    bl_options = {'INTERNAL'}

    md = None
    attr = ""

    def execute(self, context): return {'FINISHED'}

    def invoke(self, context, event):
        self.md = VPP_FALLOFF_CURVE.md
        self.attr = VPP_FALLOFF_CURVE.attr
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.template_curve_mapping(self.md, self.attr)
    #
    #
class VPP_SCAN_FILE(Operator):
    bl_idname = "wm.vpp_scan_file"
    bl_label = "Accept"
    bl_options = {'INTERNAL'}
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    end_fn = None

    def execute(self, context):
        try:    self.fin(self.filepath)
        except: pass
        return {'FINISHED'}

    def invoke(self, context, event):
        self.filepath = ""
        self.fin = VPP_SCAN_FILE.end_fn
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
class VPP_R_PREF(Operator):
    bl_idname = "wm.vpp_r_pref"
    bl_label = "Get Preferences Data"
    bl_options = {'REGISTER'}

    D_en0 = {
        "keys_sel_fast": "0",
        "keys_sel": "1",
        "keys_sel_ext": "2",
        "keys_bu_sel": "3",
        "keys_bu_qe": "4",
        "keys_bu_qe_E": "5",
        "keys_bu_qe_cancel": "6",
        "keys_bu_qe_slow": "7",
        "keys_bu_qe_fast": "8",
        "keys_bu_reset": "9",
        "keys_rm": "10",
        "keys_cancel": "11",
        "keys_confirm": "12",
        "keys_pan": "13",
        "keys_pan_E": "14",
        "keys_glopan": "15",
        "keys_glopan_E": "16",
        "keys_ti_bu": "17",
        "keys_ti_bu_E": "18",
        "keys_ti_mov": "19",
        "keys_ti_mov_E": "20",
        "keys_resize": "21",
        "keys_resize_E": "22",
        "keys_undo": "23",
        "keys_redo": "24",
        "keys_batch": "25",
        "keys_me_sel": "26",
        "keys_me_sel_ext": "27",
        "keys_me_pan": "28",
        "keys_me_pan_E": "29",
        "keys_me_box": "30",
        "keys_me_box_E": "31",
        "keys_me_box_ext": "32",
        "keys_me_box_ext_E": "33",
        "keys_me_sort": "34",
        "keys_me_sort_E": "35",
        "keys_me_rename": "36",
        "keys_me_all": "37",
        "keys_me_act_up": "38",
        "keys_me_act_dn": "39",
        "keys_me_act_up_ext": "40",
        "keys_me_act_dn_ext": "41",
        "keys_me_mod_up": "42",
        "keys_me_mod_dn": "43",
        "keys_me_del": "44",
        "keys_me_apply": "45",
        "keys_dd_del_alp": "46",
        "keys_dd_del_word": "47",
        "keys_dd_del_all": "48",
        "keys_dd_left": "49",
        "keys_dd_right": "50",
        "keys_dd_up": "51",
        "keys_dd_down": "52",
        "keys_dd_shift_left": "53",
        "keys_dd_shift_right": "54",
        "keys_dd_shift_up": "55",
        "keys_dd_shift_down": "56",
        "keys_dd_pan": "57",
        "keys_dd_pan_E": "58",
        "keys_dd_box": "59",
        "keys_dd_box_E": "60",
        "keys_dd_sel": "61",
        "keys_dd_sel_all": "62",
        "keys_dd_copy": "63",
        "keys_dd_paste": "64",
        "keys_dd_cut": "65",
        "keys_dd_cancel": "66",
        "keys_dd_confirm": "67",
        "keys_dd_bar": "68",
        "keys_dd_bar_E": "69",
        "keys_dd_tab": "70",
        "keys_dd_scroll_up": "71",
        "keys_dd_scroll_down": "72",
        "keys_cp_hue_sel": "73",
        "keys_cp_hue": "74",
        "keys_cp_hue_E": "75",
        "keys_pk_cancel": "76",
        "keys_pk_confirm": "77",
        "keys_tex_cancel": "78",
        "keys_rm_1": "79",
        "keys_rm_2": "80",
        "keys_rm_3": "81",
        "keys_rm_4": "82",
        "keys_rm_5": "83",
        "keys_rm_6": "84",
        "keys_rm_7": "85",
        "keys_rm_8": "86",
        "keys_rm_9": "87",
        "keys_rm_0": "88",
        "keys_rm_back": "89",
        "keys_rm_next": "90",
        "calc_13iqe": "91",
        "calc_13i1": "92",
        "calc_13i1ex": "93",
        "calc_13i2": "94",
        "calc_13i2ex": "95",
        "calc_13i3": "96",
        "calc_13i3ex": "97",
        "calc_13i4": "98",
        "calc_13i4ex": "99",
        "calc_13i5": "100",
        "calc_13i5ex": "101",
        "calc_13i6": "102",
        "calc_13i6ex": "103",
        "calc_13i7": "104",
        "calc_13i7ex": "105",
        "calc_13i8": "106",
        "calc_13i8ex": "107",
        "calc_13i9": "108",
        "calc_13i9ex": "109",
        "calc_13i10": "110",
        "calc_13i10ex": "111",
        "calc_13i11": "112",
        "calc_13i11ex": "113",
        "calc_13i12": "114",
        "calc_13i12ex": "115",
        "calc_01fqe": "116",
        "calc_01f1": "117",
        "calc_01f1ex": "118",
        "calc_01f2": "119",
        "calc_01f2ex": "120",
        "calc_01f3": "121",
        "calc_01f3ex": "122",
        "calc_01f4": "123",
        "calc_01f4ex": "124",
        "calc_01f5": "125",
        "calc_01f5ex": "126",
        "calc_01f6": "127",
        "calc_01f6ex": "128",
        "calc_01f7": "129",
        "calc_01f7ex": "130",
        "calc_01f8": "131",
        "calc_01f8ex": "132",
        "calc_01f9": "133",
        "calc_01f9ex": "134",
        "calc_01f10": "135",
        "calc_01f10ex": "136",
        "calc_01f11": "137",
        "calc_01f11ex": "138",
        "calc_01f12": "139",
        "calc_01f12ex": "140",
        "calc_0ifqe": "141",
        "calc_0if1": "142",
        "calc_0if1ex": "143",
        "calc_0if2": "144",
        "calc_0if2ex": "145",
        "calc_0if3": "146",
        "calc_0if3ex": "147",
        "calc_0if4": "148",
        "calc_0if4ex": "149",
        "calc_0if5": "150",
        "calc_0if5ex": "151",
        "calc_0if6": "152",
        "calc_0if6ex": "153",
        "calc_0if7": "154",
        "calc_0if7ex": "155",
        "calc_0if8": "156",
        "calc_0if8ex": "157",
        "calc_0if9": "158",
        "calc_0if9ex": "159",
        "calc_0if10": "160",
        "calc_0if10ex": "161",
        "calc_0if11": "162",
        "calc_0if11ex": "163",
        "calc_0if12": "164",
        "calc_0if12ex": "165",
        "calc_0pfqe": "166",
        "calc_0pf1": "167",
        "calc_0pf1ex": "168",
        "calc_0pf2": "169",
        "calc_0pf2ex": "170",
        "calc_0pf3": "171",
        "calc_0pf3ex": "172",
        "calc_0pf4": "173",
        "calc_0pf4ex": "174",
        "calc_0pf5": "175",
        "calc_0pf5ex": "176",
        "calc_0pf6": "177",
        "calc_0pf6ex": "178",
        "calc_0pf7": "179",
        "calc_0pf7ex": "180",
        "calc_0pf8": "181",
        "calc_0pf8ex": "182",
        "calc_0pf9": "183",
        "calc_0pf9ex": "184",
        "calc_0pf10": "185",
        "calc_0pf10ex": "186",
        "calc_0pf11": "187",
        "calc_0pf11ex": "188",
        "calc_0pf12": "189",
        "calc_0pf12ex": "190",
        "calc_0dfqe": "191",
        "calc_0df1": "192",
        "calc_0df1ex": "193",
        "calc_0df2": "194",
        "calc_0df2ex": "195",
        "calc_0df3": "196",
        "calc_0df3ex": "197",
        "calc_0df4": "198",
        "calc_0df4ex": "199",
        "calc_0df5": "200",
        "calc_0df5ex": "201",
        "calc_0df6": "202",
        "calc_0df6ex": "203",
        "calc_0df7": "204",
        "calc_0df7ex": "205",
        "calc_0df8": "206",
        "calc_0df8ex": "207",
        "calc_0df9": "208",
        "calc_0df9ex": "209",
        "calc_0df10": "210",
        "calc_0df10ex": "211",
        "calc_0df11": "212",
        "calc_0df11ex": "213",
        "calc_0df12": "214",
        "calc_0df12ex": "215",
        "de": "216",
        "test": "217",
        "win_pos_init": "218",
        "win_size_init": "219",
        "win_size_init_DE": "220",
        "win_size_init_ME": "221",
        "scale": "222",
        "scale_ti_bu": "223",
        "ti_font_size": "224",
        "win_border": "225",
        "win_border_inner": "226",
        "win_offset_init": "227",
        "win_offset_top": "228",
        "win_shade_offset": "229",
        "win_shade_softness": "230",
        "win_shade_color": "231",
        "dd_shade_offset": "232",
        "dd_shade_softness": "233",
        "dd_shade_color": "234",
        "win_shade_on": "235",
        "lock_win_size": "236",
        "sys_auto_off": "237",
        "sync_act_oj": "238",
        "sync_act_md": "239",
        "auto_sel_text": "240",
        "auto_del_text": "241",
        "confirm_rename": "242",
        "confirm_del": "243",
        "confirm_apply": "244",
        "anim_tb_task": "245",
        "anim_win_min": "246",
        "anim_win_fit": "247",
        "anim_win_x": "248",
        "vbox_precise_mode": "249",
        "mesh_ed_local": "250",
        "mesh_ed_dis_invert": "251",
        "mesh_ed_face_nor_keep_act": "252",
        "mesh_ed_face_nor_keep_nor": "253",
        "mesh_ed_cop_vert": "254",
        "cursor_thickness": "255",
        "cursor_flash_rate": "256",
        "pan_method": "257",
        "win_pos_protect": "258",
        "quick_edit_method": "259",
        "quick_edit_operation": "260",
        "quick_edit_cursor": "261",
        "quick_edit_fac_slow": "262",
        "quick_edit_fac_fast": "263",
        "quick_edit_fac_slow_hue": "264",
        "quick_edit_fac_fast_hue": "265",
        "filter_algorithm": "266",
        "dd_num_type": "267",
        "dd_width": "268",
        "anim_frame_time": "269",
        "anim_speed": "270",
        "auto_pan_speed": "271",
        "th_drag": "272",
        "th_multi_drag": "273",
        "bu_auto_speed": "274",
        "bu_auto_time": "275",
        "scroll_fac": "276",
        "format_tx_f": "277",
        "format_tx_i": "278",
        "format_tx_h": "279",
        "format_tx_vec": "280",
        "color_win_rim": "281",
        "color_win": "282",
        "color_win_unfo": "283",
        "color_bg_fo": "284",
        "color_ti_bar": "285",
        "color_ti_bar_warn": "286",
        "color_ti_bar_unfo": "287",
        "color_ti_bu": "288",
        "color_ti_bu_fo": "289",
        "color_ti_bu_sh": "290",
        "color_ti_bu_sh_hold": "291",
        "color_ti_bu_x": "292",
        "color_oj_info": "293",
        "color_bg_mod": "294",
        "color_box_mod": "295",
        "color_box_mod_sel": "296",
        "color_box_mod_act": "297",
        "color_box_mod_act_rim": "298",
        "color_mod_bu_fo": "299",
        "color_selbox": "300",
        "color_selbox_rim": "301",
        "color_bu_bg": "302",
        "color_bu_1_off": "303",
        "color_bu_1_on": "304",
        "color_bu_1_rim": "305",
        "color_bu_1_fo": "306",
        "color_bu_1_ignore": "307",
        "color_bu_2": "308",
        "color_bu_2_ignore": "309",
        "color_bu_3_off": "310",
        "color_bu_3_on": "311",
        "color_bu_3_fo": "312",
        "color_bu_3_ignore": "313",
        "color_bu_4_off": "314",
        "color_bu_4_on": "315",
        "color_bu_4_rim": "316",
        "color_bu_4_fo": "317",
        "color_bu_4_ignore": "318",
        "color_bu_media": "319",
        "color_bu_media_fo": "320",
        "color_bu_media_on": "321",
        "color_bu_media_ignore": "322",
        "color_tb_bg": "323",
        "color_menu_start_bg": "324",
        "color_mi_act": "325",
        "color_mi_bg": "326",
        "color_mi_bg_fo": "327",
        "color_mi_ti": "328",
        "color_mi_ti_off": "329",
        "color_setting_act": "330",
        "color_setting_bo": "331",
        "color_setting_bo_fo": "332",
        "color_picker_bg": "333",
        "color_picker_bg_hue": "334",
        "color_picker_bg_hue_fo": "335",
        "color_picker_bu": "336",
        "color_mesh_ed_block": "337",
        "color_ddmenu": "338",
        "color_dd_actbox": "339",
        "color_filter": "340",
        "color_calc_bu": "341",
        "color_scroll_rim": "342",
        "color_scroll_rim_fo": "343",
        "color_scroll_bar_rim": "344",
        "color_scroll_bar_bg": "345",
        "color_scroll_bar_fo": "346",
        "color_tx_cursor": "347",
        "color_tx_sel": "348",
        "color_tx_copy": "349",
        "color_r_menu_bg": "350",
        "color_r_menu": "351",
        "color_flash_box": "352",
        "color_rm_bg": "353",
        "color_rm_fobox": "354",
        "color_tex_bg": "355",
        "color_tex_main": "356",
        "color_icon_1": "357",
        "color_icon_2": "358",
        "color_icon_3": "359",
        "color_icon_4": "360",
        "color_icon_5": "361",
        "color_icon_6": "362",
        "color_icon_7": "363",
        "color_icon_8": "364",
        "color_icon_ignore": "365",
        "color_icon_ignore2": "366",
        "color_icon_light": "367",
        "color_icon_start": "368",
        "color_icon_start_fo": "369",
        "color_font": "370",
        "color_font_red": "371",
        "color_font_fo": "372",
        "color_font_ti": "373",
        "color_font_sub_ti": "374",
        "color_font_sub_ti_fo": "375",
        "color_font_sub_ti_2": "376",
        "color_font_sub_ti_2_fo": "377",
        "color_font_mod_num": "378",
        "color_font_mod_num_fo": "379",
        "color_font_mod_name": "380",
        "color_font_darker": "381",
        "color_font_ignore": "382",
        "color_bu_kf_fo": "383",
        "color_bu_kf_yellow": "384",
        "color_bu_kf_yellow_fo": "385",
        "color_bu_kf_green": "386",
        "color_bu_kf_green_fo": "387",
        "color_bu_kf_orange": "388",
        "color_bu_kf_orange_fo": "389",
        "color_bu_dr": "390",
        "color_bu_dr_fo": "391",
        "color_mdicon_kf_off": "392",
        "color_mdicon_dr_off": "393",
        "color_font_rm": "394",
        "color_font_rm_ignore": "395",
        "color_bu_1_rim_ignore": "396",
        "color_mded_data_bg": "397",
        "color_mded_data_rim": "398",
        "color_status_bar_bg": "399",
        "keys_bu_sel_ext": "400",
        "mded_x": "401",
        "tb_offset": "402",
        "keys_sys_pass": "403",
    }
    D_en0_rev = {e: k for k, e in D_en0.items()}

    @staticmethod
    def decode(s):
        out = {}
        if s == "DEFAULT": return out
        try:
            b64decode = base64.b64decode
            D_en0_rev = VPP_R_PREF.D_en0_rev

            while s:
                i0 = s.find(":")
                if i0 == -1: break
                attr = s[:i0]
                if attr in D_en0_rev:   attr = D_en0_rev[attr]
                s = s[i0 + 1 :]
                c = s[0]
                if c == "[":
                    i1 = s.find("]")
                    if i1 == -1: break
                    out[attr] = literal_eval(s[: i1 + 1])
                    s = s[i1 + 2 :]
                elif c == "b":
                    i1 = s.find("'", 2)
                    if i1 == -1: break
                    out[attr] = b64decode(literal_eval(s[: i1 + 1])).decode()
                    s = s[i1 + 2 :]
                else:
                    i1 = s.find(",")
                    if i1 == -1: break
                    out[attr] = literal_eval(s[: i1])
                    s = s[i1 + 1 :]
            return out
        except: return out

    @staticmethod
    def main():
        P = m.P
        props = P.bl_rna.properties
        b64encode = base64.b64encode
        D_en0 = VPP_R_PREF.D_en0
        out = ""

        for at in props:
            if hasattr(at, "default"):
                attr = at.identifier
                if attr in {"bl_idname", "refresh"}: continue

                if getattr(at, "is_array", False):
                    vv = getattr(P, attr)
                    if any(e0 != e1 for e0, e1 in zip(at.default_array, vv)): pass
                    else: continue

                    s = "["
                    for e in vv:  s += f'{e},'
                    s = f'{s[:-1]}]'

                    out += f'{D_en0[attr] if attr in D_en0 else attr}:{s},'
                else:
                    v0 = getattr(P, attr)
                    if at.default == v0: continue

                    if isinstance(v0, str):
                        s = b64encode(v0.encode())
                    else:
                        s = v0
                    out += f'{D_en0[attr] if attr in D_en0 else attr}:{s},'

        return out if out else "DEFAULT"
    def execute(self, context):
        try:
            out = self.__class__.main()
            context.window_manager.clipboard = out
            self.report({'INFO'}, "Preferences data has been copied to the clipboard.")
        except: pass
        return {'FINISHED'}
    #
    #
