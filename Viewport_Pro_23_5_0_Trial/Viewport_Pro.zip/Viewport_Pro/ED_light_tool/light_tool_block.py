import bpy
from blf import color as blf_color
from blf import size as blf_size
from bpy_extras.view3d_utils import region_2d_to_vector_3d, region_2d_to_origin_3d
from mathutils import Vector

from .. import m
from .. m import R_quick_edit_state

from .. fn import add_light, R_lib_tuple
from .. filt import FIL_TYPE_EXC
from .. bu import VBOX, VBOX_SUB, VBOX_SET, TXBOX, BBOX, BURE2
from .. det import INFO
from .. win_mess import MENU_STANDARD
from .. props import RNA_FLOAT, RNA_FLOAT_ARRAY, RNA_BOOL, RNA_STR, RNA_POINTER
from .. bu_block import BLOCK2, BLOCK3, BLOCKS
from .. ui import QE, tuple_XYZ, BUTTON17, BOOLEAN, POINTER, FLOAT, FLOAT_ARRAY_SUBTI, TITLE

P = None
F = None
K = None
NNT = None
BOX = None
BLF = None
font_0 = None

Vector_axis = [Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0))]

# //* 0light_tool_block_lights
# *//
def R_lights(): return [e for e in bpy.context.selected_objects if e.type in {"LIGHT", "LIGHT_PROBE"}]

class B_DEFAULT(BLOCKS):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        wprops = self.w.w.props
        oo_add = BUTTON17(self, rna_add_light)
        oo_add.fx = self.fn_add_light
        oo_add.ti.text = "Selected Faces"
        oo_shot = BUTTON17(self, rna_shot_light)
        oo_shot.fx = self.fn_shot_light
        self.oo = [
            oo_add,
            oo_shot,
            BOOLEAN(self, rna_is_parent, lambda: wprops["light_tool_ed_is_parent"], self.fn_set_is_parent),
            BOOLEAN(self, rna_is_selected_objects, lambda: wprops["light_tool_ed_is_selected_objects"], self.fn_set_is_selected_objects),
            BOOLEAN(self, rna_is_flip, lambda: wprops["light_tool_ed_flip"], self.fn_set_is_flip),
            BOOLEAN(self, rna_is_link, lambda: wprops["light_tool_ed_is_link"], self.fn_set_is_link),
            BOOLEAN(self, rna_use_collection, lambda: wprops["light_tool_ed_use_collection"], self.fn_set_use_collection),
            POINTER(self, rna_collection_name, lambda: wprops["light_tool_ed_collection_name"], self.fn_set_collection_name),
            POINTER(self, rna_profile, lambda: wprops["light_profile"], self.fn_set_light_profile),
            FLOAT(self, rna_dis, lambda: wprops["light_tool_ed_dis"], self.fn_set_dis),
        ]

    def get_bo(self, L0, R0, T0):
        oo = self.oo
        _3 = F[3]
        _16 = F[16]
        _17 = F[17]
        R = R0 - _3
        L9 = R - F[101]
        T = T0 - _3
        T = oo[0].get_bo(L9, R, T - _17, T) - _3
        oo[0].ti.x = L0 + F[10]
        T = oo[1].get_bo(L9, R, T - _17, T) - _3
        R1 = R - F[101] - F[2]
        L = R1 - F[101]
        Rb = L + _16
        # /* 0light_tool_block_B_DEFAULT_get_bo
        T = oo[2].get_bo(L, Rb, T - _16, T) - _3
        # */
        # <<< 1for (0light_tool_block_B_DEFAULT_get_bo,, $[{'2': str(r)}  for r in range(3, 7)]$)
        T = oo[3].get_bo(L, Rb, T - _16, T) - _3
        T = oo[4].get_bo(L, Rb, T - _16, T) - _3
        T = oo[5].get_bo(L, Rb, T - _16, T) - _3
        T = oo[6].get_bo(L, Rb, T - _16, T) - _3
        # >>>
        T = oo[7].get_bo(L, R, T - _16, T) - _3
        T = oo[8].get_bo(L, R, T - _16, T) - _3
        T = oo[9].get_bo(L, R1, T - _16, T) - _16

        self.hi = T0 - T
        self.rim.LRBT_upd(L0, R0, T, T0)

    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_is_parent', 'prop_name':'light_tool_ed_is_parent'}$)
    def fn_set_is_parent(self, v, undo_push=True):
        self.w.w.props["light_tool_ed_is_parent"] = v
    # >>>
    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_is_selected_objects', 'prop_name':'light_tool_ed_is_selected_objects'}$)
    def fn_set_is_selected_objects(self, v, undo_push=True):
        self.w.w.props["light_tool_ed_is_selected_objects"] = v
    # >>>
    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_is_flip', 'prop_name':'light_tool_ed_flip'}$)
    def fn_set_is_flip(self, v, undo_push=True):
        self.w.w.props["light_tool_ed_flip"] = v
    # >>>
    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_is_link', 'prop_name':'light_tool_ed_is_link'}$)
    def fn_set_is_link(self, v, undo_push=True):
        self.w.w.props["light_tool_ed_is_link"] = v
    # >>>
    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_use_collection', 'prop_name':'light_tool_ed_use_collection'}$)
    def fn_set_use_collection(self, v, undo_push=True):
        self.w.w.props["light_tool_ed_use_collection"] = v
    # >>>
    # <<< || 1copy (ui_set_pointer,, ${'fn_name':'fn_set_collection_name', 'prop_name':'light_tool_ed_collection_name'}$)
    def fn_set_collection_name(self, v, undo_push=True):
        collections = bpy.data.collections
        name = R_lib_tuple(collections, v)
        ob = collections[name]  if name in collections else None
        self.w.w.props["light_tool_ed_collection_name"][:] = name, ob
    # >>>
    # <<< || 1copy (ui_set_pointer,, ${'fn_name':'fn_set_light_profile', 'prop_name':'light_profile', 'collections':'lights'}$)
    def fn_set_light_profile(self, v, undo_push=True):
        lights = bpy.data.lights
        name = R_lib_tuple(lights, v)
        ob = lights[name]  if name in lights else None
        self.w.w.props["light_profile"][:] = name, ob
    # >>>
    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_dis', 'prop_name':'light_tool_ed_dis'}$)
    def fn_set_dis(self, v, undo_push=True):
        self.w.w.props["light_tool_ed_dis"] = v
    # >>>

##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
    def fn_add_light(self):
        m.admin.report({'INFO'}, "This feature is unlocked by purchasing the Standard Edition.")
    def fn_shot_light(self):
        m.admin.report({'INFO'}, "This feature is unlocked by purchasing the Standard Edition.")
##
##
##
##

class B_LIGHT(BLOCK3):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "offset": [0.0, 0.0, 0.0],
        }
        self.props = props
        e = BUTTON17(self, rna_initialize)
        e.fx = self.fn_initialize
        self.oo = [
            TITLE(self, "Selected Lights"),
            FLOAT_ARRAY_SUBTI(self, rna_offset, self.fn_get_offset, self.fn_set_offset),
            e
        ]
        self.oo[1].init(tuple_XYZ)

    def get_bo(self, L0, R0, T0):
        RR = R0 - F[3]
        R = RR - F[101] - F[2]
        T = T0 - F[3]
        B = T - F[17]
        self.oo[0].ti.xy(L0 + F[10], B + F[5])
        T = B - F[8]
        B = self.oo[1].get_bo(R - F[101], R, T - F[16], T) - F[16]
        self.oo[2].get_bo(RR - F[61], RR, T - F[17], T)
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def fn_initialize(self):
#
        # <<< 1copy (0light_tool_block_lights,, $$)
        lights = [e_ for e_ in bpy.context.selected_objects if e_.type in {"LIGHT", "LIGHT_PROBE"}]
        # >>>
        def end_fn():
            try:
                if menu.is_confirm:
                    v = menu.A_data.oo_keys[0].props["offset"]
#
                    for light in lights:    light.vpp_offset = v
                    m.refresh()
                    m.undo_str = "[Light Tool] Initialize Offset"
                    m.undo_push()
            except: pass

        menu = MENU_STANDARD(self, [B_MENU_INIT], end_fn=end_fn)
        info = menu.A_status.ti["info"].text = f"Object amount: {len(lights)}"

    def fn_get_offset(self, ind=None):
        # <<< 1copy (ui_array_get,, ${'_prop':'offset'}$)
        if ind is None: return self.props["offset"]
        if isinstance(ind, int): return self.props["offset"][ind]
        return self.props["offset"][ind[0] : ind[1]]
        # >>>
    def fn_set_offset(self, v, undo_push=True, ind=None):
        try:
            if ind == None:
                ind = (0, 3)
            elif isinstance(ind, int):
                ind = (ind, ind + 1)
                if not hasattr(v, "__len__"):   v = [v]

            if QE.state == 1:
                tm = QE.data
                lights = tm["lights"]
                u_vecs = tm["u_vecs"]

                # <<< 1copy (0light_tool_block_lights,, $$)
                lights = [e_ for e_ in bpy.context.selected_objects if e_.type in {"LIGHT", "LIGHT_PROBE"}]
                # >>>
                of = Vector()
                zip_v = [(r, d) for r, d in zip(range(*ind), v)]

                for light in lights:
                    of.zero()
                    u_vec = u_vecs[light]
                    loc, rot, sca = light.matrix_world.decompose()
                    for r, d in zip_v:
                        of += u_vec[r] * (d - light.vpp_offset[r])
                        light.vpp_offset[r] = d

                    light.location += of
            elif QE.state == -2:
                tm = QE.data
                if "lights" not in tm: return
                lights = tm["lights"]
                org_of = tm["org_of"]
                org_pos = tm["org_pos"]

                for light in lights:
                    light.location = org_pos[light]
                    light.vpp_offset = org_of[light]
            else:
                # <<< 1copy (0light_tool_block_lights,, $$)
                lights = [e_ for e_ in bpy.context.selected_objects if e_.type in {"LIGHT", "LIGHT_PROBE"}]
                # >>>
                if not lights: return

                u_vecs = {}
                org_pos = {}
                org_of = {}
                of = Vector()
                zip_v = [(r, d) for r, d in zip(range(*ind), v)]

                for light in lights:
                    of.zero()
                    org_of[light] = light.vpp_offset.copy()
                    loc, rot, sca = light.matrix_world.decompose()
                    vec3 = {}
                    for r, d in zip_v:
                        u_vec = rot @ Vector_axis[r]
                        u_vec.normalize()

                        of += u_vec * (d - light.vpp_offset[r])
                        light.vpp_offset[r] = d
                        vec3[r] = u_vec

                    org_pos[light] = light.location.copy()
                    light.location += of
                    u_vecs[light] = vec3

                if QE.state == 0:
                    QE.state = 1
                tm = QE.data
                tm["lights"] = lights
                tm["u_vecs"] = u_vecs
                tm["org_of"] = org_of
                tm["org_pos"] = org_pos

            if undo_push:
                m.undo_str = f"[Light Tool] Offset"
                m.undo_push()
        except: pass


class B_MENU_INIT(BLOCK2):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        self.props = {
            "offset": [0.0, 0.0, 0.0],
        }
        e = FLOAT_ARRAY_SUBTI(self, rna_offset, self.fn_get_offset, self.fn_set_offset)
        self.oo = [
            TITLE(self, "Initialize Offset"),
            e
        ]
        e.init(tuple_XYZ)
        e.da_upd()

    def get_bo(self, L0, R0, T0):
        RR = R0 - F[3]
        R = RR - F[101] - F[2]
        T = T0 - F[3]
        B = T - F[17]
        self.oo[0].ti.xy(L0 + F[10], B + F[5])
        T = B - F[8]
        B = self.oo[1].get_bo(R - F[101], R, T - F[16], T) - F[16]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def fn_get_offset(self, ind=None):
        # <<< 1copy (ui_array_get,, ${'_prop':'offset'}$)
        if ind is None: return self.props["offset"]
        if isinstance(ind, int): return self.props["offset"][ind]
        return self.props["offset"][ind[0] : ind[1]]
        # >>>
    def fn_set_offset(self, v, undo_push=True, ind=None):
        if ind == None:
            ind = (0, 3)
        elif isinstance(ind, int):
            ind = (ind, ind + 1)
            if not hasattr(v, "__len__"):   v = [v]

        self.props["offset"][ind[0] : ind[1]] = v
        self.oo[1].da_upd()



rna_add_light = RNA_STR("Add Light to Faces", "Add Light to selected faces.\n\nProperties:\n    Parent\n    Selected Objects\n    Flip Direction\n    Link Light Data\n    Use Collection\n    Collection\n    Light Profile\n    Distance", "Add Light to Faces")
rna_shot_light = RNA_STR("Shoot at Surface", "Shoot to add lights to surfaces.\n\nProperties:\n    Parent\n    Flip Direction\n    Link Light Data\n    Use Collection\n    Collection\n    Light Profile\n    Distance", "Shoot at Surface")
rna_is_parent = RNA_BOOL("Parent", "Make parent when adding light.", False)
rna_is_selected_objects = RNA_BOOL("Selected Objects", "If false, only count active object.", False)
rna_is_flip = RNA_BOOL("Flip Direction", "Flip Light Direction.", False)
rna_is_link = RNA_BOOL("Link Light Data", "Use the same light data.", False)
rna_use_collection = RNA_BOOL("Use Collection", "Add the Light to collection.", False)
rna_collection_name = RNA_POINTER("Collection", "Creates a new collection if the collection does not exist.", "", "collections")
rna_profile = RNA_POINTER("Light Profile", "Use Light Profile. Object type: bpy.types.Light", "", "lights", is_check=True)
rna_dis = RNA_FLOAT("Distance", "Distance between Object and Light.", 0.001)
rna_offset = RNA_FLOAT_ARRAY("Offset", "Light Offset", (0.0, 0.0, 0.0), unit="LENGTH", subtype="TRANSLATION")
rna_initialize = RNA_STR("Initialize Offset", "Initialize current offset", "Initialize")
rna_current_offset = RNA_FLOAT_ARRAY("Current Offset", "Current Light Offset", (0.0, 0.0, 0.0), unit="LENGTH", subtype="TRANSLATION")
