import bpy, bmesh
from blf import size as blf_size

from .. import m
from .. m import BOX, BLF
from .. win_cls import AREA

from . light_tool_block import B_DEFAULT, B_LIGHT

P = None
F = None
font_0 = None

class DATA_DEFAULT(AREA):
    __slots__ = 'data'
    def R_bo_data(self): return self.w.bo["me_info"]
    def get_data(self):
        self.data = {}
        self.oo_keys = [B_DEFAULT(self), B_LIGHT(self)]
    def upd_data(self):
        b_default, b_light = self.oo.values()

        if self.w.obj_mode == "EDIT":
            s = bpy.context.scene.statistics(bpy.context.view_layer)
            i0 = s.find("Faces")
            if i0 == -1:    b_default.oo[0].ti.text = "Selected Faces :  0"
            else:
                i0 += 6
                b_default.oo[0].ti.text = f'Selected Faces :  {s[i0 : s.find("/", i0)]}'
        else:
            b_default.oo[0].ti.text = "Selected Faces"

        if self.w.props["light_tool_ed_use_collection"]:
            if b_default.oo[7].is_enable is False:
                b_default.oo[7].enable()
        else:
            if b_default.oo[7].is_enable is True:
                b_default.oo[7].disable()

        # <<< 1copy (0light_tool_block_lights,, $$)
        lights = [e_ for e_ in bpy.context.selected_objects if e_.type in {"LIGHT", "LIGHT_PROBE"}]
        # >>>
        oo_ti, oo_dis, oo_init = b_light.oo
        if lights:
            if oo_dis.is_enable is False:
                oo_dis.enable()
                oo_init.enable()

            ll = len(lights)
            oo_ti.ti.text = f"Selected Lights :  {ll}"

            if len(lights) == 1:
                if oo_dis.ti != "Offset":
                    oo_dis.ti.text = "Offset"
                    blf_size(font_0, F[9])
                    oo_dis.get_bo(*oo_dis.rim[0].R_LRBT())

                b_light.props["offset"][:] = lights[0].vpp_offset
            else:
                if oo_dis.ti.text != "Avg Offset":
                    oo_dis.ti.text = "Avg Offset"
                    blf_size(font_0, F[9])
                    oo_dis.get_bo(*oo_dis.rim[0].R_LRBT())

                try:
                    vs = [sum(e)  for e in zip(light.vpp_offset  for light in lights)]
                    # for light in lights:
                    #     vs[0] += light.vpp_offset[0]
                    #     vs[1] += light.vpp_offset[1]
                    #     vs[2] += light.vpp_offset[2]

                    b_light.props["offset"][:] = vs[0] / ll, vs[1] / ll, vs[2] / ll
                except:
                    b_light.props["offset"][:] = 0.0, 0.0, 0.0
        else:
            if oo_dis.is_enable is True:
                oo_dis.disable()
                oo_init.disable()

            oo_ti.ti.text = "Selected Lights"

        b_default.upd_oo()
        b_light.upd_oo()

    def get_face_data(self, oj):
        data = self.data
        data.clear()

        if oj.mode == "OBJECT":
            data["oj"] = oj
            polygons = {}
            ll_faces = 0
            is_act_oj_selected = False
            for o in bpy.context.selected_objects:
                if o.type != "MESH": continue
                if o == oj: is_act_oj_selected = True
                ee = [e for e in o.data.polygons if e.select]
                polygons[o] = ee
                ll_faces += len(ee)
            if is_act_oj_selected is False:
                o = oj
                ee = [e for e in o.data.polygons if e.select]
                polygons[o] = ee
                ll_faces += len(ee)

            if polygons:    data["polygons"] = polygons
            data["ll_faces"] = ll_faces
            data["ll_act_faces"] = len(polygons[oj])
        else:
            self.kill_data()



class DATA_DEFAULT_old:
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'sci',
        'oo',
        'max_ind',
        'li',
        'key_end',
        'tm_L',
        'tm_R',
        'tm_B',
        'tm_T',
        'tm_pan_h',
        'tm_1',
        # 'ref_L',
        # 'ref_R',
        'headkey',
        'endkey',
        'color_ti',
        'color_da',
        'color_bool',
        'tx_wi',
        'hi',
        'li_h',
        'custom_subtype',
        'outside',
        'data',
        'props',
    )
    def get_data(self):
        self.oo = {
            0: BL_DEFAULT(self),
            1: BL_LIGHT(self),
        }
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.color_ti       = P.color_font
        self.color_da       = P.color_font_darker
        self.color_bool     = P.color_bu_2
        self.sci            = m.SCISSOR()
        self.upd_sci()
        self.tx_wi          = F[110]*2
        self.outside        = [None]
        self.props          = w.props

        self.get_data()

        li = {}
        self.li = li
        oo = self.oo
        ll_oo = len(oo)

        me_info = w.bo["me_info"]
        _1 = F[1]

        L = me_info.L + _1
        R = me_info.R - _1
        T = me_info.T - _1

        bu_wi = F[101]
        x1 = R - F[3] - bu_wi - F[2]
        x = x1 - bu_wi

        hi_max = me_info.R_h()
        self.hi = hi_max
        hi = _1
        blf_size(font_0, F[9])
        for r in range(ll_oo):
            e = oo[r]
            e.get_bo(L, R, T, x, x1)
            li[r] = e
            hi += e.hi + _1
            if hi >= hi_max:    break
            T = e.rim.B - _1

        self.li_h = hi - _1 - _1
        self.max_ind = ll_oo - 1
        self.headkey = 0
        self.endkey = len(li) - 1
        self.data = {}

    def dxy_upd(self, x, y):
        for e in self.li.values():  e.dxy_upd(x, y)
    def upd_sci(self):
        sci         = self.sci
        wsci        = self.w.sci
        L, R, B, T  = self.w.bo["me_info"].R_LRBT()
        sci.x       = max(L, wsci.x)
        sci.w       = max(0, min(R, wsci.x + wsci.w) - sci.x)
        sci.y       = max(B, wsci.y)
        sci.h       = max(0, min(T, wsci.y + wsci.h) - sci.y)

    def I_draw(self):
        oo_v = self.oo.values()
        for e in oo_v:  e.draw_bo()
        blf_size(font_0, F[9])
        for e in oo_v:  e.draw_ti()

    def I_modal_main(self, evt):
        for e in self.li.values():
            if e.rim.inbox(evt):
                self.U_modal = e.U_modal
                return e.U_modal(evt)

        return False

    def outside_evt(self, evt):
        if self.U_modal != self.default_modal:
            self.outside[0] = True
            self.U_modal(evt)

    def upd_data(self):
        oj = bpy.context.object
        if oj:
            if oj.type == "MESH":
                for e in self.w.A_data.oo.values():  e.upd_data()
                return

        self.kill_data()
        for e in self.oo.values():  e.upd_data()

    def get_face_data(self, oj):
        data = self.data
        data.clear()

        if oj.mode == "OBJECT":
            data["oj"] = oj
            polygons = {}
            ll_faces = 0
            is_act_oj_selected = False
            for o in bpy.context.selected_objects:
                if o.type != "MESH": continue
                if o == oj: is_act_oj_selected = True
                ee = [e for e in o.data.polygons if e.select]
                polygons[o] = ee
                ll_faces += len(ee)
            if is_act_oj_selected is False:
                o = oj
                ee = [e for e in o.data.polygons if e.select]
                polygons[o] = ee
                ll_faces += len(ee)

            if polygons:    data["polygons"] = polygons
            data["ll_faces"] = ll_faces
            data["ll_act_faces"] = len(polygons[oj])
        else:
            self.kill_data()

    def to_A_data(self, clas):
        if self.__class__ != clas:
#
            self.w.A_data = clas(self.w)

    def kill_data(self):
        self.data.clear()