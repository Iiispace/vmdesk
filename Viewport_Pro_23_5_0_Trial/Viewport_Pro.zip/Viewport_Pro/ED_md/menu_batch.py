import bpy
from bgl import glEnable, glDisable, GL_BLEND, GL_SCISSOR_TEST, glScissor
from blf import size as blf_size
from blf import color as blf_color

from .. import m

from .. win_mess import MESS
from .. link_data import MOD_ATTR, MOD_REF_ATTR, MOD_EX_ATTR, MOD_ARRAY_ATTR, R_md_driver_add, R_md_driver_remove, D_apply_as, D_only_one
from .. bu import BU, BU_BOOL, BURE, BU_ENUM

P = None
F = None
K = None
BOX = None
BLF = None
font_0 = None
font_1 = None

class MESS_BATCH_KF(MESS):
    __slots__ = (
        'w',
        'md_type',
        'attrs',
        'attrs_ex',
        'attrs_ref',
        'attrs_array',
        'oo_12',
        'oo_9',
        'oo_free',
        'oo_array',
        'is_confirm',
        'operation',
        'props',
        'D_oo_index',
    )
    name = "Menu Batch"

    def __init__(self, x, y, bu_dr, operation=0, operation_ind=0):
        self.w = bu_dr
        md_type = bu_dr.w.w.act_md.type
        self.md_type = md_type
        attrs = getattr(MOD_ATTR, md_type, None)
        if attrs is None:
            MESS(x, y, "Batch function unsupported in current version.", offset=False, hide_tb=False)
            return

        props = bu_dr.w.w.act_md.bl_rna.properties
        self.props = props
        self.attrs = [e for e in attrs  if e in props]
        self.attrs_ex = getattr(MOD_EX_ATTR, md_type)
        self.attrs_array = [e for e in getattr(MOD_ARRAY_ATTR, md_type)  if e in props]

        if operation == 0:
            tx = "Keyframe"
        elif operation == 1:
            tx = "Driver"
        else:
            tx = "Set Value"

        self.is_confirm = False
        self.operation = operation

        super().__init__(x, y, tx, height=300, offset=False, hide_tb=False)

        self.default_modal = self.I_default_modal
        self.fit_win(F[2])
        if operation == 2:
            self.oo["OP_modifiers"].set_da(True)
        else:
            self.oo["bu_add_remove"].bu_on_by_ind(operation_ind)
        #
    def init_D1(self, evt):
        super().init_D1(evt)

        bo      = self.bo
        da      = self.da
        oo      = self.oo
        ma      = self.main_area
        bu_dr   = self.w
        props   = self.props

        font_color      = P.color_font
        font_size_12    = F[12]
        operation       = self.operation

        attrs = self.attrs
        attrs_array = self.attrs_array
        oo_free = set()
        self.oo_free = oo_free
        oo_array = set()
        self.oo_array = oo_array
        D_oo_index = {}
        self.D_oo_index = D_oo_index

        for attr in attrs:
            if attr in attrs_array:
                for r in range(props[attr].array_length):
                    e = BU_BOOL(ma, attr, f'{props[attr].name} [{r}]')
                    oo[f'{attr}[{r}]'] = e
                    oo_free.add(e)
                    oo_array.add(e)
                    D_oo_index[e] = r
            else:
                e = BU_BOOL(ma, attr, props[attr].name)
                oo[attr] = e
                oo_free.add(e)

        for attr in self.attrs_ex:
            oo[attr] = BU_BOOL(ma, attr, props[attr].name)

        if operation == 0: self.attrs_ref = ()
        else:
            self.attrs_ref = [e for e in getattr(MOD_REF_ATTR, self.md_type)  if e in props]

            for attr in self.attrs_ref:
                oo[attr] = BU_BOOL(ma, attr, props[attr].name)

        oo_key = bu_dr.attr
        if oo_key in attrs_array: oo_key += f'[{bu_dr.array_index}]'
        if oo_key in oo: oo[oo_key].set_da(True)

        da["tx_attributes"] = BLF(font_color, "Attributes :", font_size_12)
        da["tx_operation"] = BLF(font_color, "Operation :", font_size_12)
        oo["OP_modifiers"] = BU_BOOL(ma, "OP_modifiers", "All same type modifiers in object")
        oo["OP_selected"] = BU_BOOL(ma, "OP_selected", "All selected objects")

        oo["bu_modifiers"] = BURE(ma, "bu_modifiers", "All", self.bu_fn_modifiers)
        oo["bu_selected"] = BURE(ma, "bu_selected", "All", self.bu_fn_selected)
        if operation != 2:
            oo["bu_add_remove"] = BU_ENUM(ma, "bu_add_remove",
                [
                    BU(ma, "insert", "Insert"), BU(ma, "delete", "Delete"), BU(ma, "clear", "Clear")
                ] if operation == 0 else [
                    BU(ma, "add", "Add"), BU(ma, "remove", "Remove")
                ]
            )

        for attr in self.attrs_ex: oo_free.add(oo[attr])
        for attr in ("OP_modifiers", "OP_selected"):    oo_free.add(oo[attr])
        if operation != 0:
            for attr in self.attrs_ref: oo_free.add(oo[attr])

        self.oo_12 = {oo[k] for k in {
            "bu_ok",
        }}
        oo_9 = {oo[k] for k in ("bu_modifiers", "bu_selected")}
        self.oo_9 = oo_9
        if operation != 2: oo_9.add(oo["bu_add_remove"])

        self.tit["ti"].text = "Batch Menu"
        oo["bu_ok"].ti.text = "Confirm"

        def bu_fn_ok():
            self.is_confirm = True
            self.bu_x_fn()
        oo["bu_ok"].fn = bu_fn_ok

        self.cv.R_w         = bo["bg"].R_w
        self.cv.R_h         = self.cv_R_h

    def fin_D1(self):
#
        if self.is_confirm is False: return

        bu_dr   = self.w
        oo      = self.oo
        oj      = bu_dr.w.w.oj
        act_md  = bu_dr.w.w.act_md
        md_type = act_md.type
        attrs   = [attr for attr in self.attrs if attr not in self.attrs_array and oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs_ex if oo[attr].da.name is True]
        attrs_array = [o for o in self.oo_array if o.da.name is True]
        objs    = bpy.context.selected_objects if oo["OP_selected"].da.name is True else [oj]
        act_name = oo["bu_add_remove"].active.name
        D_oo_index = self.D_oo_index

        if act_name == "insert":
            def md_fn(o, md, attr, index=None):
                if index is None:
                    md.keyframe_insert(attr)
                else:
                    md.keyframe_insert(attr, index=index)
        elif act_name == "delete":
            def md_fn(o, md, attr, index=None):
                try:
                    if index is None:
                        md.keyframe_delete(attr)
                    else:
                        md.keyframe_delete(attr, index=index)
                except: pass
        else:
            def md_fn(o, md, attr, index=None):
                try:
                    fcs = o.animation_data.action.fcurves
                    if index is None:
                        fcs.remove(fcs.find(f'modifiers["{md.name}"].{attr}'))
                    else:
                        fcs.remove(fcs.find(f'modifiers["{md.name}"].{attr}', index=index))
                except:
                    pass

        if oo["OP_modifiers"].da.name is True:
            def job_fn(o):
                modifiers = o.modifiers
                for md in modifiers:
                    if md.type == md_type:
                        for attr in attrs:      md_fn(o, md, attr)
                        for oo in attrs_array:  md_fn(o, md, oo.name, D_oo_index[oo])
        else:
            def job_fn(o):
                modifiers = o.modifiers
                if act_md.name in modifiers:
                    md = modifiers[act_md.name]
                    if md.type == md_type:
                        for attr in attrs:      md_fn(o, md, attr)
                        for oo in attrs_array:  md_fn(o, md, oo.name, D_oo_index[oo])

        for obj in objs:
#
#
            if obj.type == 'MESH':  job_fn(obj)

        m.undo_str = f"[Modifier Editor] Batch {act_name.title()} keyframe"
        m.undo_push()
        P.refresh = True
        m.refresh()

    def get_bo_main(self):
        bo      = self.bo
        da      = self.da
        oo      = self.oo
        _2      = F[2]
        _16     = F[16]
        bu_w    = F[38]
        bu_w1   = F[52]
        attrs_array = self.attrs_array
        props   = self.props

        x = self.box["main"].L + _2 - self.cv.x
        y = self.box["main"].T - _2 + self.cv.y

        bo["bg"].LRBT(x, x + F[300], 0, y)
        cx      = bo["bg"].R_center_x()

        da["tx"].LT(bo["bg"], F[12], F[20])
        da["tx_attributes"].xy(da["tx"].x, bo["bg"].T - F[46])

        blf_size(font_0, F[9])

        L = x + F[76] - F[3]
        T = bo["bg"].T - F[8]

        if "bu_add_remove" in oo:
            e = oo["bu_add_remove"]
            e.oo[0].LTwh(L, T, bu_w1, _16)
            e.oo[1].LTwh(e.oo[0].rim.R + F[2], T, bu_w1, _16)
            if self.operation == 0: e.oo[2].LTwh(e.oo[1].rim.R + F[2], T, bu_w1, _16)
            e.get_rim()

        L = round(da["tx"].x)
        R = L + _16
        T0 = round(da["tx_attributes"].y - F[12])
        T = T0
        dy = F[22]
        for attr in self.attrs:
            if attr in attrs_array:
                for r in range(props[attr].array_length):
                    oo[f'{attr}[{r}]'].LRBT_ti_right(L, R, T - _16, T)
                    T -= dy
            else:
                oo[attr].LRBT_ti_right(L, R, T - _16, T)
                T -= dy

        if self.operation != 0:
            T -= dy // 2
            for attr in self.attrs_ref:
                oo[attr].LRBT_ti_right(L, R, T - _16, T)
                T -= dy

        L1 = L + F[150] + F[30]
        R1 = L1 + _16
        for attr in self.attrs_ex:
            oo[attr].LRBT_ti_right(L1, R1, T0 - _16, T0)
            T0 -= dy
        bu_L = L1 + F[46]

        T0 -= F[34]
        if T > T0: T = T0
        oo["bu_modifiers"].LTwh(bu_L, T + dy, bu_w, _16)

        T -= F[20]
        da["tx_operation"].xy(da["tx"].x, T)
        T -= F[12]
        for attr in ("OP_modifiers", "OP_selected"):
            oo[attr].LRBT_ti_right(L, R, T - _16, T)
            T -= dy
        oo["bu_selected"].LTwh(bu_L, T + dy, bu_w, _16)

        blf_size(font_0, F[12])
        T -= F[5]
        self.oo["bu_ok"].LRBT(cx - F[34], cx + F[34], T - F[20], T)
        T -= F[30]
        bo["bg"].B = T

    def I_draw(self):
        glEnable(GL_BLEND)
        box = self.box
        tit = self.tit

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()
        box["bu_fit"].bind_draw()

        self.sci.ENABLE()
        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in self.oo.values():      e.draw_rim()
        for e in self.oo.values():      e.draw_bg()

        for e in self.oo_free:  e.draw_ti()
        blf_size(font_0, F[12])
        for e in self.oo_12:    e.draw_ti()
        blf_size(font_0, F[9])
        for e in self.oo_9:     e.draw_ti()

        for e in self.da.values():  e.set_draw()

        glDisable(GL_SCISSOR_TEST)
        tit["bu_x"].set_draw_id(font_1)
        tit["bu_fit"].set_draw_id(font_1)
        tit["ti"].set_draw()
        m.FLASH_BOX.U_draw()

    # def dxy_upd_main(self, x, y):
    #     super().dxy_upd_main(x, y)

    def cv_R_h(self):
        return self.bo["bg"].R_h()
    def upd_cv_lim(self):
        border2 = F[2] * 2
        self.cv.lim_x = self.cv.R_w() + border2 - self.box["main"].R_w()
        self.cv.lim_y = self.cv.R_h() + border2 - self.box["main"].R_h()
        if self.cv.lim_x < 0:   self.cv.lim_x = 0
        if self.cv.lim_y < 0:   self.cv.lim_y = 0

    def I_default_modal(self, evt):
        m.M.set_mou_ic('DEFAULT')
        self.U_modal = self.I_modal_main
        self.I_modal_main(evt)
        m.redraw()
    def I_modal_main(self, evt):
        if K["cancel0"].true() or K["cancel1"].true():  self.bu_x_fn()  ;return
        if K["confirm0"].true() or K["confirm1"].true():
            self.is_confirm = True
            self.bu_x_fn()
            return

        self.main_area.U_modal(evt)
    def I_modal_main_area(self, evt):
        if self.box["ti"].inbox(evt):
            if self.box["bu_x"].inbox(evt):
                self.U_modal = self.I_modal_x
                self.modal_x(evt)
                self.box["bu_x"].color = P.color_ti_bu_x
                m.redraw()  ;return
            if self.box["bu_fit"].inbox(evt):
                self.U_modal = self.I_modal_fit
                self.modal_fit(evt)
                self.box["bu_fit"].color = P.color_ti_bu_fo
                m.redraw()  ;return
            if m.U_resize_evt(self, evt):   return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
                return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
                return
        elif self.box["main"].inbox(evt):
            if m.U_resize_evt(self, evt):   return
            for e in self.oo.values():
                if e.rim.inbox(evt):    e.inside(evt) ;return

            if K["glopan0"].true():
                self.key_end = K["glopan_E0"]
                self.to_glopan(evt)
                return
            if K["glopan1"].true():
                self.key_end = K["glopan_E1"]
                self.to_glopan(evt)
                return
            if K["pan0"].true():
                self.key_end = K["pan_E0"]
                self.to_glopan(evt)
                return
            if K["pan1"].true():
                self.key_end = K["pan_E1"]
                self.to_glopan(evt)
                return
        else:
            if evt.value == 'PRESS':
                if m.thread_isreg(m.flash_box_thread_fn):   return
                box = self.box
                m.FLASH_BOX.init(box["rim"].L, box["rim"].R, box["rim"].B, box["rim"].T)

    def bu_fn_modifiers(self):
#
        oo = self.oo
        attrs_array = self.attrs_array

        boo = bool([e for e in self.attrs if e not in attrs_array and oo[e].da.name is not True]
            or [e for e in self.oo_array if e.da.name is not True]
            or [e for e in self.attrs_ex if oo[e].da.name is not True]
            or [e for e in self.attrs_ref if oo[e].da.name is not True])

        for attr in self.attrs:
            if attr not in attrs_array: oo[attr].set_da(boo)
        for o in self.oo_array:     o.set_da(boo)
        for attr in self.attrs_ex:  oo[attr].set_da(boo)
        for attr in self.attrs_ref: oo[attr].set_da(boo)
        m.redraw()
    def bu_fn_selected(self):
#
        oo = self.oo
        attrs = ("OP_modifiers", "OP_selected")

        boo = bool([e for e in attrs if oo[e].da.name is not True])
        for attr in attrs:  oo[attr].set_da(boo)
        m.redraw()

    def I_upd_data(self): pass
    #
    #
class MESS_BATCH_DR(MESS_BATCH_KF):
    __slots__ = ()
    def fin_D1(self):
#
        if self.is_confirm is False: return

        bu_dr   = self.w
        oo      = self.oo
        oj      = bu_dr.w.w.oj
        act_md  = bu_dr.w.w.act_md
        md_type = act_md.type
        attrs   = [attr for attr in self.attrs if attr not in self.attrs_array and oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs_ex if oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs_ref if oo[attr].da.name is True]
        attrs_array = [o for o in self.oo_array if o.da.name is True]
        objs    = bpy.context.selected_objects if oo["OP_selected"].da.name is True else [oj]
        act_name = oo["bu_add_remove"].active.name
        D_oo_index = self.D_oo_index

        if act_name == "add":
            def md_fn(o, md, attr, index=None):
                try:    R_md_driver_add(o, md.name, attr, index=index)
                except: pass
        else:
            def md_fn(o, md, attr, index=None):
                try:    R_md_driver_remove(o, md.name, attr, index=index)
                except: pass

        if oo["OP_modifiers"].da.name is True:
            def job_fn(o):
                modifiers = o.modifiers
                for md in modifiers:
                    if md.type == md_type:
                        for attr in attrs:      md_fn(o, md, attr)
                        for oo in attrs_array:  md_fn(o, md, oo.name, D_oo_index[oo])
        else:
            def job_fn(o):
                modifiers = o.modifiers
                if act_md.name in modifiers:
                    md = modifiers[act_md.name]
                    if md.type == md_type:
                        for attr in attrs:      md_fn(o, md, attr)
                        for oo in attrs_array:  md_fn(o, md, oo.name, D_oo_index[oo])

        for obj in objs:
#
#
            if obj.type == 'MESH':  job_fn(obj)

        m.undo_str = f"[Modifier Editor] Batch {act_name.title()} Driver"
        m.undo_push()
        P.refresh = True
        m.refresh()
    #
    #
class MESS_BATCH_VAL(MESS_BATCH_KF):
    __slots__ = ()
    def fin_D1(self):
#
        if self.is_confirm is False: return

        bu_dr   = self.w
        oo      = self.oo
        oj      = bu_dr.w.w.oj
        act_md  = bu_dr.w.w.act_md
        md_type = act_md.type
        attrs   = [attr for attr in self.attrs if attr not in self.attrs_array and oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs_ex if oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs_ref if oo[attr].da.name is True]
        attrs_array = [o for o in self.oo_array if o.da.name is True]
        objs    = bpy.context.selected_objects if oo["OP_selected"].da.name is True else [oj]
        D_oo_index = self.D_oo_index

        def md_fn(md, attr, index=None):
            try:
                if index is None:
                    setattr(md, attr, getattr(act_md, attr))
                else:
                    getattr(md, attr)[index] = getattr(act_md, attr)[index]
            except: pass

        if oo["OP_modifiers"].da.name is True:
            def job_fn(o):
                modifiers = o.modifiers
                for md in modifiers:
                    if md.type == md_type:
                        for attr in attrs:      md_fn(md, attr)
                        for oo in attrs_array:  md_fn(md, oo.name, D_oo_index[oo])
        else:
            def job_fn(o):
                modifiers = o.modifiers
                if act_md.name in modifiers:
                    md = modifiers[act_md.name]
                    if md.type == md_type:
                        for attr in attrs:      md_fn(md, attr)
                        for oo in attrs_array:  md_fn(md, oo.name, D_oo_index[oo])

        for obj in objs:
#
#
            if obj.type == 'MESH':  job_fn(obj)

        m.undo_str = f"[Modifier Editor] Batch Set Value"
        m.undo_push()
        P.refresh = True
        m.refresh()
    #
    #
class MESS_BATCH_VAL2(MESS_BATCH_KF):
    __slots__ = 'oj', 'get_oj_from_md'
    def __init__(self, x, y, bu_dr, get_oj_from_md, at, attrs, attrs_ex, attrs_array, operation=0, operation_ind=0):
        self.w = bu_dr
        act_md = bu_dr.w.w.act_md
        md_type = act_md.type
        self.md_type = md_type
        if not hasattr(MOD_ATTR, md_type):
            MESS(x, y, "Batch function unsupported in current version.", offset=False, hide_tb=False)
            return

        self.get_oj_from_md = get_oj_from_md
        self.oj = get_oj_from_md(bu_dr.w.w.act_md)
        props = self.oj.bl_rna.properties
        self.props = props
        self.attrs = [e for e in attrs  if e in props]
        self.attrs_ex = [e for e in attrs_ex  if e in props]
        self.attrs_array = [e for e in attrs_array  if e in props]

        if operation == 0:
            tx = "Keyframe"
        elif operation == 1:
            tx = "Driver"
        else:
            tx = "Set Value"

        self.is_confirm = False
        self.operation = operation

        super(MESS_BATCH_KF, self).__init__(x, y, tx, height=300, offset=False, hide_tb=False)

        self.default_modal = self.I_default_modal
        self.fit_win(F[2])
        if operation == 2:
            self.oo["OP_modifiers"].set_da(True)
        else:
            self.oo["bu_add_remove"].bu_on_by_ind(operation_ind)

        self.oo[at].set_da(True)
        #
    def fin_D1(self):
#
        if self.is_confirm is False: return

        bu_dr   = self.w
        oo      = self.oo
        oj      = self.oj
        act_md  = bu_dr.w.w.act_md
        md_type = act_md.type
        get_oj_from_md = self.get_oj_from_md

        attrs   = [attr for attr in self.attrs if attr not in self.attrs_array and oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs_ex if oo[attr].da.name is True]
        attrs += [attr for attr in self.attrs_ref if oo[attr].da.name is True]
        attrs_array = [o for o in self.oo_array if o.da.name is True]
        objs    = bpy.context.selected_objects if oo["OP_selected"].da.name is True else [bu_dr.w.w.oj]
        D_oo_index = self.D_oo_index

        def md_fn(md, attr, index=None):
            try:
                if index is None:
                    setattr(get_oj_from_md(md), attr, getattr(oj, attr))
                else:
                    getattr(get_oj_from_md(md), attr)[index] = getattr(oj, attr)[index]
            except: pass

        if oo["OP_modifiers"].da.name is True:
            def job_fn(o):
                modifiers = o.modifiers
                for md in modifiers:
                    if md.type == md_type:
                        for attr in attrs:      md_fn(md, attr)
                        for oo in attrs_array:  md_fn(md, oo.name, D_oo_index[oo])
        else:
            def job_fn(o):
                modifiers = o.modifiers
                if act_md.name in modifiers:
                    md = modifiers[act_md.name]
                    if md.type == md_type:
                        for attr in attrs:      md_fn(md, attr)
                        for oo in attrs_array:  md_fn(md, oo.name, D_oo_index[oo])

        for obj in objs:
#
#
            if obj.type == 'MESH':  job_fn(obj)

        m.undo_str = f"[Modifier Editor] Batch Set Value"
        m.undo_push()
        P.refresh = True
        m.refresh()
    #
    #


class MESS_STATUS:
    __slots__ = (
        'w',
        'bo',
        'ti',
        'oo',
        'U_draw',
    )
    def __init__(self, w):
        self.w = w
        self.bo = {}
        self.ti = {}
        self.oo = {}
        self.U_draw = self.I_draw

    def I_draw(self):
        oo = self.oo
        oo_values = oo.values()

        glEnable(GL_BLEND)
        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in oo_values:     e.draw_rim()
        for e in oo_values:     e.draw_bg()

        blf_size(font_0, F[12])
        oo["bu_ok"].draw_ti()
        blf_size(font_0, F[9])
        oo["bu_all"].draw_ti()
        oo["bu_select"].draw_ti()
        oo["bu_active"].draw_ti()
        self.ti["info"].draw_color_pos()
    #
    #
class MESS_MDS(MESS):
    __slots__ = (
        'w',
        'option',
        'A_status',
        'bg_wi',
        'is_confirm',
    )
    name = "Modifier Options"

    D_option = {
        "delete": "Delete Modifiers",
        "apply": "Apply Modifiers",
        "apply_as_shape_key": "Apply as Shape Key",
        "save_as_shape_key": "Save as Shape Key",
        "duplicate": "Duplicate to the End",
        "copy_to": "Copy to Selected",
    }

    def __init__(self, w, x, y, option="delete"):
        self.w = w
        self.option = option
        self.A_status = MESS_STATUS(self)
        self.is_confirm = False

        super().__init__(x, y, MESS_MDS.D_option[option], height=300, offset=False, hide_tb=False)

        self.default_modal = self.I_default_modal
        self.fit_win(F[2])
        #
    def init_D1(self, evt):
        super().init_D1(evt)

        w       = self.w
        bo      = self.bo
        da      = self.da
        oo      = self.oo
        ma      = self.main_area

        self.tit["ti"].text = "Modifier Options"

        A_status    = self.A_status
        st_bo       = A_status.bo
        st_ti       = A_status.ti
        st_oo       = A_status.oo

        e = oo.pop("bu_ok")
        e.ti.text = "Confirm"
        e.fn = self.bufn_ok
        st_oo["bu_ok"] = e
        st_oo["bu_all"] = BURE(ma, "bu_all", "All", self.bufn_all)
        st_oo["bu_select"] = BURE(ma, "bu_select", "Selected", self.bufn_select)
        st_oo["bu_active"] = BURE(ma, "bu_active", "Active", self.bufn_active)

        st_bo["bg"] = BOX(P.color_status_bar_bg)
        st_ti["info"] = BLF(P.color_font_darker)
        wi_max = 0

        I_upd_data = self.I_upd_data
        blf_size(font_0, F[9])
        if self.option in {"apply_as_shape_key", "save_as_shape_key"}:
            for i, e in enumerate(w.w.oj.modifiers):
                o = BU_BOOL(ma, i, e.name, upd_fn=I_upd_data)
                oo[i] = o
                wi = o.ti.R_dimen()
                if wi > wi_max: wi_max = wi
                if e.type not in D_apply_as: o.disable()
        elif self.option == "duplicate":
            for i, e in enumerate(w.w.oj.modifiers):
                o = BU_BOOL(ma, i, e.name, upd_fn=I_upd_data)
                oo[i] = o
                wi = o.ti.R_dimen()
                if wi > wi_max: wi_max = wi
                if e.type in D_only_one: o.disable()
        else:
            for i, e in enumerate(w.w.oj.modifiers):
                oo[i] = BU_BOOL(ma, i, e.name, upd_fn=I_upd_data)
                wi = oo[i].ti.R_dimen()
                if wi > wi_max: wi_max = wi

        if w.tm_fn["ind"] in w.sel_range:
            for i in w.sel_range:   oo[i].fn_switch()
        else:
            oo[w.tm_fn["ind"]].fn_switch()

        wi_max = round(wi_max)
        self.bg_wi = wi_max + F[46] if wi_max > F[300] - F[46] else F[300]

        self.cv.R_w         = bo["bg"].R_w
        self.cv.R_h         = self.cv_R_h
        #
    def fin_D1(self):
#
        if self.is_confirm is False: return

        m.upd_disable()
        w = self.w
        oo = self.oo
        option = self.option
        modifiers = w.w.oj.modifiers
        w.bpy_ops_init()

        if option == "delete":
            fx = w.bpy_remove_by_name
            for r in range(len(oo) -1, -1, -1):
                e = oo[r]
                if e.da.name is True:
                    fx(e.ti.text)
        elif option == "apply":
            fx = w.bpy_apply_by_name
            for r in range(len(oo)):
                e = oo[r]
                if e.da.name is True:
                    try:    fx(e.ti.text)
                    except: pass
        elif option in {"apply_as_shape_key", "save_as_shape_key"}:
            fx0 = bpy.ops.object.modifier_apply_as_shapekey
            fx1 = w.bpy_remove_by_name
            keep = True if option == "save_as_shape_key" else False
            for r in range(len(oo)):
                e = oo[r]
                name = e.ti.text
                if modifiers[name].type in D_apply_as:
                    if e.da.name is True:
                        try:
                            fx0(keep_modifier=keep, modifier=name)
                        except:
                            fx1(name)
        elif option == "duplicate":
            fx0 = w.bpy_copy
            fx1 = w.bpy_move_to_ind
            for r in range(len(oo)):
                e = oo[r]
                name = e.ti.text
                if e.da.name is True:
                    if modifiers[name].type in D_only_one: continue
                    try:
                        fx0(e.ti.text)
                        fx1(modifiers.active.name, len(modifiers) - 1)
                    except: pass
        elif option == "copy_to":
            fx = w.bpy_copy_to
            for r in range(len(oo)):
                e = oo[r]
                if e.da.name is True:
                    try:    fx(e.ti.text)
                    except: pass

        m.upd_enable()
        m.undo_str = f"[Modifier Editor] {self.da['tx'].text}"
        w.bpy_ops_end()
        P.refresh = True
        m.refresh()

    def get_bo_main(self):
        bo      = self.bo
        da      = self.da
        oo      = self.oo
        _2      = F[2]
        _3      = F[3]
        _12     = F[12]
        _16     = F[16]

        A_status    = self.A_status
        st_bo       = A_status.bo
        st_ti       = A_status.ti
        st_oo       = A_status.oo
        box_main    = self.box["main"]

        x = box_main.L + _2 - self.cv.x
        y = box_main.T - _2 + self.cv.y

        bo["bg"].LRBT(x, x + self.bg_wi, 0, y)

        da["tx"].LT(bo["bg"], _12, F[20])
        L = round(da["tx"].x)
        R = L + _16
        T = round(da["tx"].y - _16)
        B = T - _16

        for r in range(len(oo)):
            oo[r].LRBT_ti_right(L, R, B, T)
            T = B - _3
            B = T - _16

        bo["bg"].B = T - F[8]

        blf_size(font_0, _12)
        cx = box_main.R_center_x()
        BB = box_main.B
        B = BB + F[10]
        T = B + F[20]
        st_oo["bu_ok"].LRBT(cx - F[34], cx + F[34], B, T)
        blf_size(font_0, F[9])
        B = T + F[6]
        T = B + _16
        L = box_main.L + _12
        R = L + F[61]
        st_oo["bu_all"].LRBT(L, R, B, T)
        B = T + _2
        T = B + _16
        st_oo["bu_select"].LRBT(L, R, B, T)
        B = T + _2
        T = B + _16
        st_oo["bu_active"].LRBT(L, R, B, T)
        st_ti["info"].xy(R + _16, st_oo["bu_active"].ti.y)
        st_bo["bg"].LRBT_upd(box_main.L, box_main.R, BB, T + _12)

    def dxy_upd_main(self, x, y):
        super().dxy_upd_main(x, y)

        A_status = self.A_status
        e = A_status.bo["bg"]
        o = self.box["main"]
        dx = o.L - e.L
        dy = o.B - e.B
        for e in A_status.bo.values():  e.dxy_upd(dx, dy)
        for e in A_status.oo.values():  e.dxy_upd(dx, dy)
        A_status.ti["info"].dxy(dx, dy)

    def I_default_modal(self, evt):
        m.M.set_mou_ic('DEFAULT')
        self.U_modal = self.I_modal_main
        self.I_modal_main(evt)
        m.redraw()
    def I_modal_main(self, evt):
        if K["cancel0"].true() or K["cancel1"].true():  self.bu_x_fn()  ;return
        if K["confirm0"].true() or K["confirm1"].true():
            self.is_confirm = True
            self.bu_x_fn()
            return

        self.main_area.U_modal(evt)
    def I_modal_main_area(self, evt):
        if self.box["ti"].inbox(evt):
            if self.box["bu_x"].inbox(evt):
                self.U_modal = self.I_modal_x
                self.modal_x(evt)
                self.box["bu_x"].color = P.color_ti_bu_x
                m.redraw()  ;return
            if self.box["bu_fit"].inbox(evt):
                self.U_modal = self.I_modal_fit
                self.modal_fit(evt)
                self.box["bu_fit"].color = P.color_ti_bu_fo
                m.redraw()  ;return
            if m.U_resize_evt(self, evt):   return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
                return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
                return
        elif self.box["main"].inbox(evt):
            if m.U_resize_evt(self, evt):   return

            if evt.mouse_region_y <= self.A_status.bo["bg"].T:
                for e in self.A_status.oo.values():
                    if e.rim.inbox(evt):    e.inside(evt) ;return
                return

            for e in self.oo.values():
                if e.rim.inbox(evt):    e.inside(evt) ;return

            if K["glopan0"].true():
                self.key_end = K["glopan_E0"]
                self.to_glopan(evt)
                return
            if K["glopan1"].true():
                self.key_end = K["glopan_E1"]
                self.to_glopan(evt)
                return
            if K["pan0"].true():
                self.key_end = K["pan_E0"]
                self.to_glopan(evt)
                return
            if K["pan1"].true():
                self.key_end = K["pan_E1"]
                self.to_glopan(evt)
                return
        else:
            if evt.value == 'PRESS':
                if m.thread_isreg(m.flash_box_thread_fn):   return
                box = self.box
                m.FLASH_BOX.init(box["rim"].L, box["rim"].R, box["rim"].B, box["rim"].T)

    def cv_R_h(self):
        return self.bo["bg"].R_h() + self.A_status.bo["bg"].R_h()
    def upd_cv_lim(self):
        border2 = F[2] * 2
        self.cv.lim_x = self.cv.R_w() + border2 - self.box["main"].R_w()
        self.cv.lim_y = self.cv.R_h() + border2 - self.box["main"].R_h()
        if self.cv.lim_x < 0:   self.cv.lim_x = 0
        if self.cv.lim_y < 0:   self.cv.lim_y = 0

    def I_draw(self):
        glEnable(GL_BLEND)
        box = self.box
        tit = self.tit

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()
        box["bu_fit"].bind_draw()

        self.sci.ENABLE()
        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        oo_values = self.oo.values()
        for e in oo_values:     e.draw_rim()
        for e in oo_values:     e.draw_bg()
        for e in oo_values:     e.draw_ti()

        for e in self.da.values():  e.set_draw()

        self.A_status.U_draw()

        glDisable(GL_SCISSOR_TEST)
        tit["bu_x"].set_draw_id(font_1)
        tit["bu_fit"].set_draw_id(font_1)
        tit["ti"].set_draw()
        m.FLASH_BOX.U_draw()

    def bufn_ok(self):
        self.is_confirm = True
        self.bu_x_fn()
    def bufn_all(self):
        boo = bool([e for e in self.oo.values() if e.da.name is not True])
        for e in self.oo.values():  e.set_da(boo)
        self.I_upd_data()
    def bufn_select(self):
        sel_range = self.w.sel_range
        for i, e in self.oo.items():
            e.set_da(True if i in sel_range else False)

        self.I_upd_data()
    def bufn_active(self):
        ind = self.w.R_act_ind()
        for i, e in self.oo.items():
            e.set_da(True if i == ind else False)

        self.I_upd_data()

    def I_upd_data(self):
        self.A_status.ti["info"].text = f"Count of items: {len([None for o in self.oo.values() if o.da.name is True])}"