import bpy, copy, decimal

from bpy.types import CollectionProperty, BlendData
from bpy_extras import view3d_utils
from mathutils import Vector, Quaternion, Matrix
from colorsys import rgb_to_hsv, hsv_to_rgb

from math import sin as math_sin
from math import cos as math_cos
from math import asin as math_asin
from math import pi as math_pi
from math import tau as math_tau

Translation = Matrix.Translation
tuple_111 = (1, 1, 1)
Vector_00m1 = Vector((0, 0, -1))
Vector_0a10 = Vector((0, 1, 0))
rot_dif_Vector_00m1_111 = Vector_00m1.rotation_difference(Vector((1, 1, 1)).normalized())
rot_dif_Vector_00m1_111_invert = rot_dif_Vector_00m1_111.inverted()
decimal_context = decimal.Context()
decimal_context.prec = 20

D_unit = {
    'km': 'KILOMETERS',
    'kilometer': 'KILOMETERS',
    'kilometers': 'KILOMETERS',
    'm': 'METERS',
    'meter': 'METERS',
    'meters': 'METERS',
    'cm': 'CENTIMETERS',
    'centimeter': 'CENTIMETERS',
    'centimeters': 'CENTIMETERS',
    'mm': 'MILLIMETERS',
    'millimeter': 'MILLIMETERS',
    'millimeters': 'MILLIMETERS',
    'um': 'MICROMETERS',
    'μ': 'MICROMETERS',
    'μm': 'MICROMETERS',
    'micrometer': 'MICROMETERS',
    'micrometers': 'MICROMETERS',
    'mi': 'MILES',
    'mile': 'MILES',
    'miles': 'MILES',
    'ft': 'FEET',
    'feet': 'FEET',
    'foot': 'FEET',
    'in': 'INCHES',
    'inche': 'INCHES',
    'inches': 'INCHES',
    'mil': 'THOU',
    'thou': 'THOU',
}
D_unit_rev = {
    'KILOMETERS': 'km',
    'METERS': 'm',
    'CENTIMETERS': 'cm',
    'MILLIMETERS': 'mm',
    'MICROMETERS': 'μm',
    'MILES': 'mi',
    'FEET': 'ft',
    'INCHES': 'in',
    'THOU': 'mil',
}

def R_unsign32(n):
    return n + (1 << 32) & 0b11111111111111111111111111111111
def R_sign32(n):
    if n <= 0b1111111111111111111111111111111:
        return n
    return n - (1 << 32)

def is_oj_valid(oj):
    try:    oj.name  ;return True
    except: return False
def R_lib_tuple(bpy_data, s):
    i = s.find('", "')
    if i == -1: return s

    a = i + 4
    while i != -1:
        k = s[1 : i], s[i + 4 : -1]
        if k in bpy_data: return k

        i = s.find('", "', a)
        a = i + 4

    return s
def R_lib_name(oj):
    if hasattr(oj, "library") and oj.library:
        filepath = oj.library.filepath.replace("\\","\\\\")
        return f'"{oj.name}", "{filepath}"'
    return f'"{oj.name}"'
def R_lib_str(oj):
    if hasattr(oj, "library") and oj.library:
        filepath = oj.library.filepath
        return f'"{oj.name}", "{filepath}"'
    return f'{oj.name}'

def is_ind_0(e):
    try:    e[0] ;return True
    except: return False

def R_str_by_num3(n):
    if n < 10:      return f"  {n}"
    elif n < 100:   return f" {n}"
    else:           return str(n)
def R_int_by_num3(s):   return int(s.replace(" ", ""))

def R_copy_color(c):    return [c[0], c[1], c[2], c[3]]

def R_str_by_inter_int(i): # int
    if i < 0: i = -i ; sign = "-"
    else:   sign = " "

    s = str(i)
    if i < 10000:
        if i < 100:
            if i < 10:      return f"      {sign} {s}"
            else:           return f"     {sign} {s}"
        else:
            if i < 1000:    return f"    {sign} {s}"
            else:           return f"  {sign} {s[0:1]} {s[1:]}"
    else:
        if i < 1000000:
            if i < 100000:  return f" {sign} {s[0:2]} {s[2:]}"
            else:           return f"{sign} {s[0:3]} {s[3:]}"
        else:
            if i <= 999999999:
                if i <= 9999999:    return f"{sign} {s[0:1]} {s[1:4]} {s[4:]}"
                elif i <= 99999999: return f"{sign} {s[0:2]} {s[2:5]} {s[5:]}"
                else:               return f"{sign} {s[0:3]} {s[3:6]} {s[6:]}"
            else:
                if i <= 99999999999:
                    if i <= 9999999999: return f"{sign} {s[0:1]} {s[1:4]} {s[4:7]} {s[7:]}"
                    else:               return f"{sign} {s[0:2]} {s[2:5]} {s[5:8]} {s[8:]}"
                else:
                    if i <= 999999999999:   return f"{sign} {s[0:3]} {s[3:6]} {s[6:9]} {s[9:]}"
                    else:                   return "≥ 10 ¹²"  if sign == " " else "≤ - 10 ¹²"
def R_str_by_inter_6(f):
    s = "{:.6f}".format(f)
    if s[0] == "-":
        n = "-"
        s = s[1 :]
    else:
        n = " "

    i = s.find(".")

    if i <= 4:
        if i <= 2:
            if i <= 1:  return f"      {n} {s[0:5]} {s[5:8]}"
            else:       return f"     {n} {s[0:6]} {s[6:8]}"
        else:
            if i <= 3:  return f"    {n} {s[0:7]} {s[7:8]}"
            else:       return f"  {n} {s[0:1]} {s[1:8]}"
    else:
        if i <= 6:
            if i <= 5:  return f" {n} {s[0:2]} {s[2:8]}"
            else:       return f"{n} {s[0:3]} {s[3:8]}"
        else:
            if i <= 9:
                if i <= 7:      return f"{n} {s[0:1]} {s[1:4]} {s[4:7]}"
                elif i <= 8:    return f"{n} {s[0:2]} {s[2:5]} {s[5:8]}"
                else:           return f"{n} {s[0:3]} {s[3:6]} {s[6:9]}"
            else:
                if i <= 11:
                    if i <= 10: return f"{n} {s[0:1]} {s[1:4]} {s[4:7]} {s[7:10]}"
                    else:       return f"{n} {s[0:2]} {s[2:5]} {s[5:8]} {s[8:11]}"
                else:
                    if i <= 12: return f"{n} {s[0:3]} {s[3:6]} {s[6:9]} {s[9:12]}"
                    else:       return "≥ 10 ¹²"  if n == " " else "≤ - 10 ¹²"
def R_str_by_inter_6_L(f):
    if f < 0: f = -f ; sign = "- "
    else:   sign = ""

    if f < 10000:
        if f < 100:
            if f < 10:
                s = "{:.6f}".format(f)
                return f"{sign}{s[0:5]} {s[5:]}"
            else:
                s = "{:.5f}".format(f)
                return f"{sign}{s[0:6]} {s[6:]}"
        else:
            if f < 1000:
                s = "{:.4f}".format(f)
                return f"{sign}{s[0:7]} {s[7:]}"
            else:
                s = "{:.3f}".format(f)
                return f"{sign}{s[0:1]} {s[1:]}"
    else:
        if f < 1000000:
            if f < 100000:
                s = "{:.2f}".format(f)
                return f"{sign}{s[0:2]} {s[2:]}"
            else:
                s = "{:.1f}".format(f)
                return f"{sign}{s[0:3]} {s[3:]}"
        else:
            s = "{:.0f}".format(f)
            if f <= 999999999:
                if f <= 9999999:    return f"{sign}{s[0:1]} {s[1:4]} {s[4:]}"
                elif f <= 99999999: return f"{sign}{s[0:2]} {s[2:5]} {s[5:]}"
                else:               return f"{sign}{s[0:3]} {s[3:6]} {s[6:]}"
            else:
                if f <= 99999999999:
                    if f <= 9999999999: return f"{sign}{s[0:1]} {s[1:4]} {s[4:7]} {s[7:]}"
                    else:               return f"{sign}{s[0:2]} {s[2:5]} {s[5:8]} {s[8:]}"
                else:
                    if f <= 999999999999:   return f"{sign}{s[0:3]} {s[3:6]} {s[6:9]} {s[9:]}"
                    else:                   return "≥ 10 ¹²"  if sign == " " else "≤ - 10 ¹²"
def R_str_by_inter_6_vec(v):
    s = ""
    c_8199 = chr(8199)
    for f in v:
        o = R_str_by_inter_6(f)
        s += f"{o.lstrip(c_8199)}, "
    return s[:-2].replace(c_8199, "")
def R_str_by_deg(f):
    if f < 0: f = -f ; sign = "-"
    else:   sign = " "

    if f < 10000:
        s = "{:.3f}".format(f)
        if f < 100:
            if f < 10:  output = f"    {sign} {s[0:5]} {s[5:]}"
            else:       output = f"   {sign} {s[0:6]} {s[6:]}"
        else:
            if f < 1000:    output = f"  {sign} {s[0:7]} {s[7:]}"
            else:           output = f"{sign} {s[0:1]} {s[1:]}"
        i = output.find(".")
        if i != -1:
            while i < len(output):
                if output[-1] in {"0", " "}:   output = output[:-1]
                else: break
    else:
        return f"{sign} " + "{:.0f}".format(f) + " °"

    if output[-1] == ".":   return output[:-1] + " °"
    return output + " °"
def R_str_by_replace_num(tx):   return tx.replace(" ", "").replace(" ", "")
def R_space_HEX(s):             return f"{s[:2]} {s[2:4]} {s[4:]}"
def R_space_hex(s):
    s = s.lower()
    return f"{s[:2]} {s[2:4]} {s[4:]}"
def R_HEX(s):   return f" {s} "
def R_hex(s):   return f" {s.lower()} "

def TR_flo_by_str(s, exc = None):
    try:    return float(s)
    except: return exc
def R_flo_dec_round(x, n):
    if n < 0:
        fac = 10 ** -n ; x /= fac ; s = "1."
        return float(decimal.Decimal(x).quantize(decimal.Decimal(s), rounding=decimal.ROUND_HALF_UP)) * fac
    else:
        s = "1."
        for r in range(0, n):   s += "0"
        return float(decimal.Decimal(x).quantize(decimal.Decimal(s), rounding=decimal.ROUND_HALF_UP))
def try_R_flo_dec_round(x, n, exc = None):
    try:    return R_flo_dec_round(x, n)
    except: return exc

def RR_sci_str_by_float(f, m_sign = " ╳ 10"): # only ^00 ~ 99
    s = "{:.1e}".format(f)  ; ind_e = s.find("e")   ; L = s[:ind_e]
    if s[ind_e + 1] == "+":
        R = s[ind_e + 2:]
        if R == "00":       R = ""
        elif R[0] == "0":   L = s[:ind_e] + m_sign ; R = R[1:]
        else:               L = s[:ind_e] + m_sign
    else:
        R = s[ind_e + 2:] ; L = s[:ind_e] + m_sign
        if R[0] == "0":     R = R[1:]
        R = "- " + R
    if L[0] == "-":         L = "- " + L[1:]
    return L, R
def RR_ans_str_by_float(f, r=14, m_sign = " •10"):
    s = str(f)      ; ind = s.find("e")
    if ind == -1:
        flo = try_R_flo_dec_round(f, r)
        if flo == None:
            return s, ""
        L = str(flo)
        if L[-2:] == ".0":  L = L[:-2]
        return L, ""
    flo = try_R_flo_dec_round(float(s[:ind]), r)
    if flo == None:     L = s[:ind]
    else:   L = str(flo)
    power = str(int(s[ind+2:]))
    if s[ind+1] == "+":     return L + m_sign, power
    return L + m_sign, "- " + power
def R_non_e_express(s, sign = "►10^"):
    ind = s.find("e")
    if ind == -1:   return s
    return s[:ind] + sign + str(int(s[ind+1:]))
def R_format(f, r="{:.14f}"):
    s = r.format(f)
    ind = s.find(".")
    if ind == -1:   return s
    while True:
        if s[-1] == "0":    s = s[:-1]
        else:   return s

def bin_search(min_ind, max_ind, v, fx, exc= lambda x: -1):
    low = min_ind   ; high = max_ind
    i = 0
    while low <= high:
        i = (low + high) // 2
        fxi = fx(i)
        if fxi < v:     low = i +1
        elif fxi > v:   high = i -1
        else:   return i
    return exc(i)
def bin_search_continue(fx, v_min, v_max, th=0.0000001):
    if fx(v_max) == False: return None
    low = v_min
    high = v_max
    while (high - low) > th:
        v = (low + high) / 2
        RET = fx(v)
        if RET == True: high = v
        else:
            low = v

    return high

def append_descend(li, e):
    low     = 0
    high    = len(li) - 1
    i       = 0
    while low <= high:
        i = (low + high) // 2
        if e < li[i]:   low = i + 1
        elif e > li[i]: high = i - 1
        else: break
    if e < li[i]:  li.insert(i + 1, e)
    else:  li.insert(i, e)

def R_tran_target_type(s):
    if s == 'CACHEFILE':        return "Cache File"
    if s == 'GREASEPENCIL':     return "Grease Pencil"
    if s == 'LIGHT_PROBE':      return "Light Probe"
    if s == 'LINESTYLE':        return "Line Style"
    if s == 'META':             return "Metaball"
    if s == 'MOVIECLIP':        return "Movie Clip"
    if s == 'NODETREE':         return "Node Tree"
    if s == 'PAINTCURVE':       return "Paint Curve"
    if s == 'POINTCLOUD':       return "Point Cloud"
    if s == 'WINDOWMANAGER':    return "Window Manager"
    return s.capitalize()
def R_tran_target_type_py(s):
    if s == "Cache File":       return 'CACHEFILE'
    if s == "Grease Pencil":    return 'GREASEPENCIL'
    if s == "Light Probe":      return 'LIGHT_PROBE'
    if s == "Line Style":       return 'LINESTYLE'
    if s == "Metaball":         return 'META'
    if s == "Movie Clip":       return 'MOVIECLIP'
    if s == "Node Tree":        return 'NODETREE'
    if s == "Paint Curve":      return 'PAINTCURVE'
    if s == "Point Cloud":      return 'POINTCLOUD'
    if s == "Window Manager":   return 'WINDOWMANAGER'
    return s.upper()

def TR_resolve(ob, dp, exc = None):
    try:    return ob.path_resolve(dp)
    except: return exc

def T_set_context_object(tx):
    try:
        obj = bpy.data.objects[tx]
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
    except: pass
def T_set_context_obj(obj):
    try:
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        return True
    except: return False

def TR_object(tx):
    try:    return bpy.data.objects[tx]
    except: return None
def TR_ind(lis, i):
    try:    return lis[i]
    except: return None
def TR_ind_ex(lis, i):
    try:    return lis[i]
    except: return ""

def R_path_value(obj, path):
    try:
        vals = obj.path_resolve(path)
        return tuple(v for v in vals)  if isinstance(vals, Vector) else vals
    except:
        return None
def R_driver_variable_value_TRANSFORMS(tar0):
    try:
        obj0        = tar0.id
        tar0_type   = tar0.transform_type
        tar0_space  = tar0.transform_space
        ch0 = tar0_type[0]
        ch1 = tar0_type[-1]

        if obj0.type == 'ARMATURE':
            bone0 = obj0.pose.bones[tar0.bone_target]
            if tar0_space == 'WORLD_SPACE':
                mat0 = obj0.matrix_world @ bone0.matrix
            elif tar0_space == 'LOCAL_SPACE':
                mat0 = obj0.matrix_local @ obj0.matrix_parent_inverse.inverted() @ bone0.matrix
            else: # TRANSFORM_SPACE
                mat0 = bone0.matrix_basis
        else:
            if tar0_space == 'WORLD_SPACE':
                mat0 = obj0.matrix_world
            elif tar0_space == 'LOCAL_SPACE':
                mat0 = obj0.matrix_local @ obj0.matrix_parent_inverse.inverted()
            else: # TRANSFORM_SPACE
                mat0 = obj0.matrix_basis

        if ch0 == 'L':
            if ch1 == 'X':      return mat0.translation.x
            elif ch1 == 'Y':    return mat0.translation.y
            else:               return mat0.translation.z
        elif ch0 == 'S':
            if ch1 == 'X':      return mat0.to_scale().x
            elif ch1 == 'Y':    return mat0.to_scale().y
            elif ch1 == 'Z':    return mat0.to_scale().z
            else:               return ""
        else:
            mode = tar0.rotation_mode
            if mode == 'AUTO':  return ""
            elif mode == 'XYZ':     rot = mat0.to_euler(mode)
            elif mode == 'XZY':     rot = mat0.to_euler(mode)
            elif mode == 'YXZ':     rot = mat0.to_euler(mode)
            elif mode == 'YZX':     rot = mat0.to_euler(mode)
            elif mode == 'ZXY':     rot = mat0.to_euler(mode)
            elif mode == 'ZYX':     rot = mat0.to_euler(mode)
            elif mode == 'QUATERNION':  rot = mat0.to_quaternion()
            else: return ""

            if ch1 == 'X':      return rot.x
            if ch1 == 'Y':      return rot.y
            if ch1 == 'Z':      return rot.z
            if ch1 == 'W':      return rot.w
    except:
        return None
def R_driver_variable_value_ROTATION_DIFF(tar0, tar1):
    try:
        obj0 = tar0.id
        obj1 = tar1.id
        if obj0.type == 'ARMATURE': return ""
        if obj1.type == 'ARMATURE': return ""
        rot0 = obj0.matrix_world.to_quaternion()
        rot1 = obj1.matrix_world.to_quaternion()
        return rot0.rotation_difference(rot1).angle
    except:
        return None
def R_driver_variable_value_LOC_DIFF(tar0, tar1):
    try:
        obj0 = tar0.id
        obj1 = tar1.id
        sp0 = tar0.transform_space
        sp1 = tar1.transform_space
        if obj0.type == 'ARMATURE': return ""
        if obj1.type == 'ARMATURE': return ""
        if sp0 == 'WORLD_SPACE':
            loc0 = obj0.matrix_world.translation
        elif sp0 == 'LOCAL_SPACE':
            loc0 = (obj0.matrix_local @ obj0.matrix_parent_inverse.inverted()).translation
        else:
            loc0 = obj0.matrix_basis.translation

        if sp1 == 'WORLD_SPACE':
            loc1 = obj1.matrix_world.translation
        elif sp1 == 'LOCAL_SPACE':
            loc1 = (obj1.matrix_local @ obj1.matrix_parent_inverse.inverted()).translation
        else:
            loc1 = obj1.matrix_basis.translation

        return (loc0 - loc1).length
    except:
        return None
def R_obj_path_by_full_path(path):
    try:
        names = {e.identifier for e in BlendData.bl_rna.properties  if isinstance(e, CollectionProperty)}

        ind_data = path.find("data.")

        ind_obj_start = ind_data + 5
        ind_obj_end = path.find("[", ind_obj_start)
        bpy_colls = getattr(bpy.data, path[ind_obj_start : ind_obj_end])

        ind_name_start = ind_obj_end + 1
        ind_name_end = path.find("]", ind_name_start)
        tar_obj = bpy_colls[path[ind_name_start + 1 : ind_name_end - 1]]
        dr_path = path[ind_name_end + 2 :]  if path[ind_name_end + 1] == "." else path[ind_name_end + 1 :]
        return tar_obj, dr_path
    except: return None, None


def rgb_to_hex(r, g, b):
    return '%02X%02X%02X' % (round(r*255), round(g*255), round(b*255))
def rgb_int_to_hex(r, g, b):
    return '%02X%02X%02X' % (r, g, b)
def hex_to_rgb(str6):
    lv = len(str6)
    return tuple(int(str6[i:i+lv//3], 16) / 255 for i in range(0, lv, lv//3))
def R_rgb_by_str(s):
    s = s.replace(" ", "").replace("#", "")
    try:
        if s[:2] != "0x":   s = f"0x{s}"
        v = min(max(int(s, 16), 0), 0xffffff)
        b = v & 0xff
        v >>= 8
        g = v & 0xff
        v >>= 8
        return v & 0xff, g, b
    except: return None

def math_split(s):
    lis = []
    def check_left(ss, i0, i1):
        for r in range(i1, i0, -1):
            if ss[r] in {")", "]"}: return None
            if ss[r] in {"(", "["}: return r
        return None

    def split(ss):
        i0 = 0
        l1 = len(ss)
        while True:
            i = ss.find(",", i0)
            if i == -1: return l1
            RET = check_left(ss, i0, i)
            if RET is None: return i
            i0 = i + 1

    while True:
        ii = split(s)
        e0 = s[: ii]
        e1 = s[ii + 1 :]
        lis.append(e0)
        if not e1: return lis
        s = e1
def float_to_str(f):
    return format(decimal_context.create_decimal(repr(f)), 'f')

def R_normal_center(bm, li_co): # bpy.ops.ed.undo()
    bpy.ops.ed.undo_push()
    bpy.ops.mesh.select_all(action='DESELECT')
    verts = bm.verts
    # new_verts = [verts.new(v) for v in li_co]
    for v in li_co:
        vert = verts.new(v)
        vert.select_set(True)
    bpy.ops.mesh.edge_face_add('INVOKE_DEFAULT')

    for f in bm.faces:
        if f.select:
            f.normal_update()
            nor = f.normal.copy()
            co = f.calc_center_median().copy()
            bpy.ops.ed.undo()
            return nor, co

    bpy.ops.ed.undo()
    return None, None
def R_face_normal(loops): # non-normalize
    n = Vector()
    v_prev = loops[-1]
    for v_curr in loops:
        n[0] += (v_prev[1] - v_curr[1]) * (v_prev[2] + v_curr[2])
        n[1] += (v_prev[2] - v_curr[2]) * (v_prev[0] + v_curr[0])
        n[2] += (v_prev[0] - v_curr[0]) * (v_prev[1] + v_curr[1])
        v_prev = v_curr
    return n
def R_bm_nor(face): # non-normalize
    n = Vector()
    loops = face.loops
    v_prev = loops[-1].vert.co
    for loop in loops:
        v_curr = loop.vert.co

        n[0] += (v_prev[1] - v_curr[1]) * (v_prev[2] + v_curr[2])
        n[1] += (v_prev[2] - v_curr[2]) * (v_prev[0] + v_curr[0])
        n[2] += (v_prev[0] - v_curr[0]) * (v_prev[1] + v_curr[1])
        v_prev = v_curr
    return n
def R_nor_to_glo(n, obj): # non-normalize
    mat = obj.matrix_world.copy()
    mat[0][3] = 0
    mat[1][3] = 0
    mat[2][3] = 0
    return mat @ n
def R_nor_to_local(n, obj): # non-normalize
    mat = obj.matrix_world.copy()
    mat[0][3] = 0
    mat[1][3] = 0
    mat[2][3] = 0
    return mat.inverted() @ n
def R_face_area(loops):
    return R_face_normal(loops).length * 0.5
def R_bm_area_glo(face, mat):
    return R_face_normal([mat @ e.vert.co  for e in face.loops]).length * 0.5
def R_median(verts):
    return sum(verts, Vector()) / len(verts)
def R_bm_length(edge, mat_copy):
    v0, v1 = edge.verts
    mat_copy.translation = 0.0, 0.0, 0.0
    return (mat_copy @ (v0.co - v1.co)).length
def R_angle(v0, v_center, v1):
    vec1 = (v0 - v_center).normalized()
    vec2 = (v1 - v_center).normalized()
    if vec1.dot(vec2) >= 0.0:
        return 2.0 * math_asin((vec1 - vec2).length / 2.0)
    return math_pi - 2.0 * math_asin((vec1 + vec2).length / 2.0)
def R_u_pos_by_angle(u_pos, u_nor, angle):
    rot = Vector_00m1.rotation_difference(u_nor)
    rot2 = (rot @ Vector_0a10).rotation_difference(u_pos)

    if u_nor.to_tuple(4) != (rot2 @ rot @ Vector_00m1).to_tuple(4):
        u_nor = rot_dif_Vector_00m1_111 @ u_nor
        u_pos = rot_dif_Vector_00m1_111 @ u_pos
        rot = Vector_00m1.rotation_difference(u_nor)
        rot2 = (rot @ Vector_0a10).rotation_difference(u_pos)
        rot2 = rot_dif_Vector_00m1_111_invert @ rot2

    pos0 = Vector((math_sin(angle), math_cos(angle), 0.0))
    pos1 = pos0.copy()
    pos1[0] *= -1
    return rot2 @ rot @ pos0, rot2 @ rot @ pos1
def R_3vert_of_2edges(bm_edge0, bm_edge1): # Return v0, same, v1
    e0_v0 = bm_edge0.verts[0]
    e0_v1 = bm_edge0.verts[1]
    e1_v0 = bm_edge1.verts[0]
    e1_v1 = bm_edge1.verts[1]
    if e0_v0 == e1_v0:  return e0_v1, e0_v0, e1_v1
    if e0_v0 == e1_v1:  return e0_v1, e0_v0, e1_v0
    if e0_v1 == e1_v0:  return e0_v0, e0_v1, e1_v1
    return e0_v0, e0_v1, e1_v0

def copy_anim_data(source, target):
    if source.animation_data:
        old_an = source.animation_data
        an = target.animation_data if target.animation_data else target.animation_data_create()
        an.action = old_an.action.copy()
        an.action_blend_type = old_an.action_blend_type
        an.action_extrapolation = old_an.action_extrapolation
        an.action_influence = old_an.action_influence
        an.use_nla = old_an.use_nla
        an.use_pin = old_an.use_pin
        an.use_tweak_mode = old_an.use_tweak_mode

        an_drivers = an.drivers
        for e in old_an.drivers:
            an_drivers.from_existing(src_driver=e)

        an_nla = an.nla_tracks
        for e in old_an.nla_tracks:
            an_nla.new(prev=e)
    #

def R_unit_velocity():
    s = bpy.context.scene.unit_settings.length_unit
    if s in D_unit_rev: return f'{D_unit_rev[s]} / s'
    return f'{s} / s'

def add_light(loc, v0, v1, wi, nor, ty="AREA", shape="RECTANGLE"):
    vec_x = v1 - v0
    wi_y = vec_x.length
    vec_x.normalize()

    rot = Vector_00m1.rotation_difference(nor)
    rot2 = (rot @ Vector_0a10).rotation_difference(vec_x)

    if nor.to_tuple(4) != (rot2 @ rot @ Vector_00m1).to_tuple(4):
        nor = rot_dif_Vector_00m1_111 @ nor
        vec_x = rot_dif_Vector_00m1_111 @ vec_x
        rot = Vector_00m1.rotation_difference(nor)
        rot2 = (rot @ Vector_0a10).rotation_difference(vec_x)
        rot2 = rot_dif_Vector_00m1_111_invert @ rot2

    bpy.ops.object.light_add(type=ty, align='WORLD')
    light = bpy.context.object
    light.matrix_world = compose(loc, rot2 @ rot, tuple_111)
    light.data.shape = shape
    light.data.size = wi
    light.data.size_y = wi_y
    return light

def compose(loc, rot, sca): # Vector, Quaternion, Vector  (XYZ)
    return Translation(loc) @ rot.to_matrix().to_4x4() @ Matrix(
        ((sca[0],0,0,0), (0,sca[1],0,0), (0,0,sca[2],0), (0,0,0,1))
    )



class NAME:
    __slots__ = "name"
    def __init__(self, name):   self.name = name

class HSB:
    __slots__ = 'h', 's', 'b'
    def __init__(self, h=0.0, s=0.0, b=0.0):
        self.h = h
        self.s = s
        self.b = b
    def hsb(self, h, s, b):
        self.h = h
        self.s = s
        self.b = b
    def hsb_by_rgb(self, r, g, b):
        self.h, self.s, self.b = rgb_to_hsv(r, g, b)
    def R_h_rad(self):
        return self.h * 6.283185307179586
    def R_rgb(self):
        return hsv_to_rgb (self.h, self.s, self.b)

class REFLIST(list):
    __slots__ = 'D_KEYIND'
    def __init__(self, lis):
        self += lis
        self.upd()
    def upd(self):
        self.D_KEYIND = {k : i  for i, k in enumerate(self)}
    def find(self, k):
        return self.D_KEYIND[k]  if k in self.D_KEYIND else -1
    def isin(self, k):
        return k in self.D_KEYIND