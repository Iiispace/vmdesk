import bpy
from gpu_extras.batch import batch_for_shader

from . import m

P = None
F = None
shader2D    = None
BIND        = None
UNFL        = None

indices_box = ((0,1,2),(0,2,3))
indices_tri = ((0,1,2),)
indices_rim = ((0,5,3),(0,6,5),(0,1,6),(1,7,6),(1,2,7),(2,3,7),(3,4,7),(3,5,4))

indices_UNKNOWN = ((0,1,8),(0,8,9),(1,2,8),(2,7,8),(2,3,7),(3,6,7),(3,4,5),(3,5,6))
indices_DATA_TRANSFER = ((0,1,6),(0,6,4),(1,7,6),(1,8,7),(1,2,8),(2,3,8),(3,9,8),(3,12,9),(12,11,9),(9,11,10),(3,13,12),(3,4,13),(4,5,13),(4,6,5))
indices_NORMAL_EDIT = ((0,4,3),(0,5,4),(0,1,5),(1,6,5),(1,2,6),(2,7,6),(2,8,7),(2,3,8),(3,4,8))
indices_UV_PROJECT = ((0,5,3),(0,7,5),(5,7,6),(0,1,7),(1,8,7),(1,9,8),(1,2,9),(2,11,9),(9,11,10),(2,3,11),(3,4,11),(3,5,4))
indices_BEVEL = ((0,6,4),(0,1,6),(1,7,6),(1,8,7),(1,2,8),(2,3,8),(3,9,8),(3,4,9),(4,5,9),(4,6,5))
indices_BOOLEAN = ((0,2,5),(0,1,2),(2,3,4),(2,4,5))
indices_MASK = ((0,8,7),(0,9,8),(0,1,9),(1,10,9),(1,2,10),(2,11,10),(2,16,11),(11,16,15),(11,15,12),(12,15,14),(12,14,13),(13,14,6),(2,17,16),(2,3,17),(3,4,17),(4,18,17),(4,5,18),(5,19,18),(5,6,19),(6,14,19),(6,8,13),(6,7,8))
indices_MULTIRES = ((0,18,3),(0,19,18),(0,16,19),(0,14,16),(0,15,14),(0,1,15),(1,12,15),(1,2,12),(2,10,12),(2,11,10),(2,8,11),(2,7,8),(2,3,7),(3,4,7),(3,5,4),(3,18,5),(5,18,6),(6,18,17),(6,17,13),(6,13,9),(13,17,16),(13,16,14),(13,12,10),(13,10,9),(9,8,6),(6,8,7))
indices_REMESH = ((0,3,2),(0,4,3),(0,5,4),(0,1,5),(1,2,5),(2,3,5))
indices_SCREW = ((0,12,13),(0,1,12),(1,2,12),(2,11,12),(2,10,11),(2,3,10),(3,4,10),(4,9,10),(4,5,9),(5,8,9),(5,6,8),(6,7,8))
indices_SOLIDIFY = ((0,7,6),(0,6,5),(0,8,7),(0,1,8),(1,2,8),(2,9,8),(2,3,9),(3,4,9),(4,6,9),(4,5,6))
indices_SUBSURF = ((0,1,2),(0,2,7),(2,3,6),(2,6,7),(3,4,5),(3,5,6))
indices_TRIANGULATE = ((0,4,3),(0,5,4),(0,1,5),(1,2,5),(2,6,5),(2,3,6),(3,4,6))
indices_VOLUME_TO_MESH = ((0,8,13),(0,7,8),(0,1,7),(1,6,7),(1,5,6),(1,2,5),(2,3,5),(3,4,5),(9,10,11),(9,11,12),(9,12,13),(9,13,8))
indices_WIREFRAME = ((0,5,3),(0,8,5),(0,1,8),(1,9,8),(1,7,9),(1,2,7),(2,6,7),(6,5,8),(6,8,7),(2,3,6),(3,4,6),(3,5,4))
indices_ARMATURE = ((0,1,16),(1,15,16),(1,12,15),(1,2,12),(2,3,4),(2,4,5),(2,5,11),(5,6,8),(6,7,8),(8,11,5),(8,9,11),(11,9,10),(11,12,2),(12,13,14),(12,14,15))
indices_CURVE = ((0,1,11),(1,10,11),(1,2,10),(2,9,10),(2,8,9),(2,3,8),(3,4,7),(3,7,8),(4,5,6),(4,6,7))
indices_DISPLACE = ((0,1,2),(0,2,5),(5,2,3),(5,3,4),(5,6,7),(5,7,0))
indices_HOOK = ((0,1,2),(0,2,7),(2,3,6),(2,6,7),(3,4,5),(3,5,6))
indices_LATTICE = ((0,16,19),(0,1,16),(1,14,16),(1,15,14),(1,12,15),(1,10,12),(1,2,10),(2,11,10),(2,8,11),(2,3,8),(3,7,8),(3,4,7),(3,5,4),(3,18,5),(3,0,18),(18,0,19),(5,18,17),(5,17,6),(17,13,6),(13,9,6),(13,16,14),(13,17,16),(13,12,10),(13,10,9),(9,8,6),(6,8,7))
indices_WARP = ((0,5,6),(0,2,5),(0,1,2),(2,3,5),(3,4,5))
indices_CLOTH = ((0,1,11),(1,10,11),(1,2,3),(1,3,4),(1,4,5),(1,5,6),(1,6,10),(6,7,10),(7,8,10),(8,9,10))
indices_SOFT_BODY = ((0,1,4),(1,2,4),(2,3,4))
indices_OCEAN = ((0,1,9),(1,8,9),(1,2,8),(2,7,8),(2,6,7),(2,3,6),(3,4,6),(4,5,6))
indices_RENDER = ((0,9,7),(0,10,9),(0,1,10),(1,2,10),(2,11,10),(2,3,4),(2,4,5),(2,5,11),(5,6,11),(6,7,11),(7,8,11),(7,9,8))
indices_KEY = ((0,1,2),(0,2,9),(2,7,9),(2,6,7),(2,3,6),(3,4,5),(3,5,6),(7,8,9))
indices_FONT = ((0,1,8),(0,8,9),(1,2,4),(1,4,5),(1,5,8),(2,3,4),(5,6,8),(6,7,8))
indices_CACHEFILE = ((0,1,7),(0,7,6),(0,6,5),(0,5,4),(1,8,7),(1,2,8),(2,3,8),(3,9,8),(3,10,9),(3,4,10),(4,5,10))
indices_BRUSH = ((0,1,8),(0,8,7),(0,7,6),(0,6,3),(1,9,8),(1,2,9),(2,10,9),(2,11,10),(2,4,11),(2,3,4),(3,5,4),(3,6,5),(6,9,10),(6,10,5))
indices_WORKSPACE = ((0,1,2),(0,2,11),(2,3,9),(2,9,11),(3,8,9),(3,4,13),(3,13,8),(4,14,13),(4,5,14),(5,15,14),(5,6,15),(6,7,15),(7,12,15),(7,8,12),(8,13,12),(9,10,11))
indices_WORLD = ((0,1,2),(0,2,11),(2,12,11),(2,3,12),(3,13,12),(3,14,13),(3,4,14),(4,14,15),(4,5,15),(5,16,15),(5,8,16),(5,6,8),(6,7,8),(8,9,16),(9,17,16),(9,10,17),(10,18,17),(10,19,18),(10,11,19),(11,12,19))
indices_HAIR = ((0,1,2),(0,2,7),(0,7,8),(0,8,19),(2,3,7),(3,4,5),(3,5,6),(3,6,7),(8,9,11),(9,10,11),(12,13,16),(13,14,16),(14,15,16),(16,17,12),(8,11,19),(11,12,19),(12,17,19),(17,18,19))
indices_SPEAKER = ((0,1,2),(0,2,5),(2,3,5),(3,4,5))
indices_SOUND = ((0,1,11),(1,2,11),(2,10,11),(2,3,10),(3,9,10),(3,4,9),(4,8,9),(4,5,8),(5,7,8),(5,6,7))
indices_SIMULATION = ((0,1,11),(0,11,9),(1,12,11),(1,13,12),(1,2,13),(2,3,13),(3,14,13),(3,17,14),(3,4,17),(4,18,17),(4,19,18),(4,5,19),(5,20,19),(5,6,20),(6,21,20),(6,7,21),(7,8,21),(8,16,21),(8,15,16),(8,9,10),(8,10,15),(9,11,10),(14,16,15),(14,17,16))
indices_SCENE = ((0,1,17),(0,10,11),(0,12,10),(0,13,12),(0,17,13),(1,2,3),(1,3,18),(1,18,17),(3,4,19),(3,19,18),(4,5,6),(4,6,19),(6,16,19),(6,7,16),(7,8,9),(7,9,15),(7,15,14),(7,14,16),(10,15,9),(10,12,15),(13,16,14),(13,17,16))
indices_MOVIECLIP = ((0,1,14),(0,14,15),(1,2,14),(2,13,14),(2,3,13),(3,12,13),(3,11,12),(3,4,11),(4,10,11),(4,5,10),(5,6,9),(5,9,10),(6,7,9),(7,8,9))
indices_AVERAGE = ((8,0,1),(2,9,4),(9,1,2),(5,7,0),(8,7,0),(9,6,4),(6,5,4),(4,3,2),(9,8,1),(5,6,7))
indices_SUM = ((1,2,8),(3,4,6),(4,5,6),(2,3,6),(8,9,0),(2,6,7),(8,0,1),(2,7,8))
indices_ROTATION_DIFF = ((1,2,3),(5,10,4),(3,9,1),(9,8,0),(1,9,0),(5,6,7),(7,0,11),(0,8,11),(5,7,11),(10,9,3),(5,11,10),(10,3,4))
indices_SINGLE_PROP = ((1,6,7),(0,5,6),(5,0,3),(7,4,3),(4,5,3),(1,0,6),(2,1,7),(2,7,3))
indices_TRANSFORMS = ((1,5,0),(1,2,4),(2,3,4),(6,7,5),(7,0,5),(1,4,5))
indices_LOC_DIFF = ((9,3,4),(0,1,3),(1,2,3),(10,11,0),(7,8,9),(10,0,3),(6,7,4),(7,9,4),(9,10,3),(4,5,6))


class MD_IND0:
    __slots__ = ()
    def upd_mod_data(self, e, md, drivers, fcurves):
        e.color_cage = m.color_empty
        e.color_edit = m.color_empty
        e.color_view = m.color_empty
        e.color_rend = m.color_empty
class MD_IND2:
    __slots__ = ()
    def upd_mod_data(self, e, md, drivers, fcurves):
        name = md.name
        e.color_cage = m.color_empty
        e.color_edit = m.color_empty

        if drivers.find(f'modifiers["{name}"].show_viewport') != None:
            e.color_view = P.color_bu_dr if md.show_viewport else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_viewport') != None:
            e.color_view = P.color_bu_kf_yellow if md.show_viewport else P.color_mdicon_kf_off
        else:
            e.color_view = P.color_icon_6 if md.show_viewport else P.color_icon_ignore2

        if drivers.find(f'modifiers["{name}"].show_render') != None:
            e.color_rend = P.color_bu_dr if md.show_render else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_render') != None:
            e.color_rend = P.color_bu_kf_yellow if md.show_render else P.color_mdicon_kf_off
        else:
            e.color_rend = P.color_icon_light if md.show_render else P.color_icon_ignore
class MD_IND3:
    __slots__ = ()
    def upd_mod_data(self, e, md, drivers, fcurves):
        name = md.name
        e.color_cage = m.color_empty

        if drivers.find(f'modifiers["{name}"].show_in_editmode') != None:
            e.color_edit = P.color_bu_dr if md.show_in_editmode else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_in_editmode') != None:
            e.color_edit = P.color_bu_kf_yellow if md.show_in_editmode else P.color_mdicon_kf_off
        else:
            e.color_edit = P.color_icon_light if md.show_in_editmode else P.color_icon_ignore

        if drivers.find(f'modifiers["{name}"].show_viewport') != None:
            e.color_view = P.color_bu_dr if md.show_viewport else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_viewport') != None:
            e.color_view = P.color_bu_kf_yellow if md.show_viewport else P.color_mdicon_kf_off
        else:
            e.color_view = P.color_icon_6 if md.show_viewport else P.color_icon_ignore2

        if drivers.find(f'modifiers["{name}"].show_render') != None:
            e.color_rend = P.color_bu_dr if md.show_render else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_render') != None:
            e.color_rend = P.color_bu_kf_yellow if md.show_render else P.color_mdicon_kf_off
        else:
            e.color_rend = P.color_icon_light if md.show_render else P.color_icon_ignore
class MD_IND4:
    __slots__ = ()
    def upd_mod_data(self, e, md, drivers, fcurves):
        name = md.name
        if drivers.find(f'modifiers["{name}"].show_on_cage') != None:
            e.color_cage = P.color_bu_dr if md.show_on_cage else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_on_cage') != None:
            e.color_cage = P.color_bu_kf_yellow if md.show_on_cage else P.color_mdicon_kf_off
        else:
            e.color_cage = P.color_icon_light if md.show_on_cage else P.color_icon_ignore

        if drivers.find(f'modifiers["{name}"].show_in_editmode') != None:
            e.color_edit = P.color_bu_dr if md.show_in_editmode else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_in_editmode') != None:
            e.color_edit = P.color_bu_kf_yellow if md.show_in_editmode else P.color_mdicon_kf_off
        else:
            e.color_edit = P.color_icon_light if md.show_in_editmode else P.color_icon_ignore

        if drivers.find(f'modifiers["{name}"].show_viewport') != None:
            e.color_view = P.color_bu_dr if md.show_viewport else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_viewport') != None:
            e.color_view = P.color_bu_kf_yellow if md.show_viewport else P.color_mdicon_kf_off
        else:
            e.color_view = P.color_icon_6 if md.show_viewport else P.color_icon_ignore2

        if drivers.find(f'modifiers["{name}"].show_render') != None:
            e.color_rend = P.color_bu_dr if md.show_render else P.color_mdicon_dr_off
        elif fcurves.find(f'modifiers["{name}"].show_render') != None:
            e.color_rend = P.color_bu_kf_yellow if md.show_render else P.color_mdicon_kf_off
        else:
            e.color_rend = P.color_icon_light if md.show_render else P.color_icon_ignore


class MD1:
    __slots__ = "color", "bat"
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D)
class MD2:
    __slots__ = "color", "bat", "bat2"
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D) ; self.bat2.draw(shader2D)
class MD22:
    __slots__ = "color", "color2", "bat", "bat2"
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D) ; BIND() ; UNFL("color", self.color2) ; self.bat2.draw(shader2D)
class MD3:
    __slots__ = "color", "bat", "bat2", "bat3"
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D) ; self.bat2.draw(shader2D) ; self.bat3.draw(shader2D)
class MD4:
    __slots__ = "color", "bat", "bat2", "bat3", "bat4"
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D) ; self.bat2.draw(shader2D) ; self.bat3.draw(shader2D) ; self.bat4.draw(shader2D)
class MD5:
    __slots__ = "color", "bat", "bat2", "bat3", "bat4", "bat5"
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D) ; self.bat2.draw(shader2D) ; self.bat3.draw(shader2D) ; self.bat4.draw(shader2D) ; self.bat5.draw(shader2D)


class EMPTY:
    __slots__ = ()
    def upd(self, x, y): pass
    def draw(self): pass
    def upd_ic_color(self, md): pass
    def bind_draw(self): pass
    def R_name(self): return "EMPTY"

class UNKNOWN(MD2, MD_IND0):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yAf5 = y+f5 ; xAf4 = x+f4 ; yAf2 = y+f2 ; xAf2 = x+f2 ; yAf4 = y+f4 ; yAf = y+f1 ; xAf = x+f1 ; yMf = y-f1 ; xMf = x-f1 ; yMf5 = y-f5 ; yMf3 = y-f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yAf5), (xAf4,yAf5), (xAf4,yAf), (xAf,yAf), (xAf,yMf), (xMf,yMf), (xMf,yAf2), (xAf2,yAf2), (xAf2,yAf4), (xMf4,yAf4))
        }, indices=indices_UNKNOWN)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf,yMf5), (xMf,yMf3), (xAf,yMf3), (xAf,yMf5))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        self.color = P.color_icon_1
    def R_name(self): return "UNKNOWN"
class DATA_TRANSFER(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; xMf5 = x-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yAf4 = y+f4 ; xMf2 = x-f2 ; yAf2 = y+f2 ; xAf2 = x+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y-f5), (xMf5,y), (xMf5,yAf5), (xAf5,yAf5), (xAf5,y), (xAf4,y), (x,y-f4), (xMf4,y), (xMf4,yAf4), (xMf2,yAf4), (xMf2,yAf2), (xAf2,yAf2), (xAf2,yAf4), (xAf4,yAf4))
        }, indices=indices_DATA_TRANSFER)
    def upd_ic_color(self, md):
        if md.object:
            self.color = P.color_icon_1
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "DATA_TRANSFER"
class MESH_CACHE(MD1, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; xMf4 = x-f4 ; yAf4 = y+f4 ; xMf1 = x-f1 ; xAf1 = x+f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y-f5), (xMf5,y), (xMf5,yAf5), (xAf5,yAf5), (xAf5,y), (xAf4,y), (x,y-f4), (xMf4,y), (xMf4,yAf4), (xMf1,yAf4), (xMf1,y), (xAf1,y), (xAf1,yAf4), (xAf4,yAf4))
        }, indices=indices_DATA_TRANSFER)
    def upd_ic_color(self, md):
        if md.filepath:
            self.color = P.color_icon_1
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "MESH_CACHE"
class MESH_SEQUENCE_CACHE(MD2, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; xMf4 = x-f4 ; yAf4 = y+f4 ; xMf1 = x-f1 ; yAf2 = y+f2 ; xAf1 = x+f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y-f5), (xMf5,y), (xMf5,yAf5), (xAf5,yAf5), (xAf5,y), (xAf4,y), (x,y-f4), (xMf4,y), (xMf4,yAf4), (xMf1,yAf4), (xMf1,yAf2), (xAf1,yAf2), (xAf1,yAf4), (xAf4,yAf4))
        }, indices=indices_DATA_TRANSFER)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y-f2), (x-f2,y), (x+f2,y))
        }, indices=indices_tri)
    def upd_ic_color(self, md):
        if md.cache_file and md.object_path:
            self.color = P.color_icon_1
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "MESH_SEQUENCE_CACHE"
class NORMAL_EDIT(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xMf4,yMf4), (xMf4,yAf4), (x,yAf4), (xAf4,y))
        }, indices=indices_NORMAL_EDIT)
    def upd_ic_color(self, md):
        if md.mode == "RADIAL" or (md.mode == "DIRECTIONAL" and md.target):
            self.color = P.color_icon_2
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "NORMAL_EDIT"
class WEIGHTED_NORMAL(MD2, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4 ; yAf2 = y+f2 ; xAf2 = x+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xMf4,yMf4), (xMf4,yAf4), (x,yAf4), (xAf4,y))
        }, indices=indices_NORMAL_EDIT)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x-f1,yAf2), (xAf2,y-f1), (xAf2,y-f2), (x-f2,yAf2))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_2
    def R_name(self): return "WEIGHTED_NORMAL"
class UV_PROJECT(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (x,yMf4), (x,y), (xMf4,y), (xMf4,yAf4), (x,yAf4), (x,y), (xAf4,y))
        }, indices=indices_UV_PROJECT)
    def upd_ic_color(self, md): self.color = P.color_icon_4
    def R_name(self): return "UV_PROJECT"
class UV_WARP(MD1, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xMf4,yMf4), (x,y), (xMf4,y), (xMf4,yAf4), (xAf4,yAf4), (x,y), (xAf4,y))
        }, indices=indices_UV_PROJECT)
    def upd_ic_color(self, md): self.color = P.color_icon_4
    def R_name(self): return "UV_WARP"
class VERTEX_WEIGHT_EDIT(MD3, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4]
        xMf1 = x-f1 ; yAf2 = y+f2 ; yAf3 = y+f3 ; xAf1 = x+f1 ; xMf4 = x-f4 ; yMf4 = y-f4 ; yMf2 = y-f2 ; xMf2 = x-f2 ; xAf2 = x+f2 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yAf2), (xMf1,yAf3), (xAf1,yAf3), (xAf1,yAf2))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf4), (xMf4,yMf2), (xMf2,yMf2), (xMf2,yMf4))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yMf4), (xAf2,yMf2), (xAf4,yMf2), (xAf4,yMf4))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.vertex_group:
            self.color = P.color_icon_5
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "VERTEX_WEIGHT_EDIT"
class VERTEX_WEIGHT_MIX(MD3, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f4 = F[4]
        yAf2 = y+f2 ; yAf3 = y+f3 ; xMf4 = x-f4 ; yMf4 = y-f4 ; yMf2 = y-f2 ; xMf2 = x-f2 ; xAf2 = x+f2 ; xAf4 = x+f4 ; xMf3 = x-f3 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf3,yAf2), (xMf3,yAf3), (xAf3,yAf3), (xAf3,yAf2))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf4), (xMf4,yMf2), (xMf2,yMf2), (xMf2,yMf4))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yMf4), (xAf2,yMf2), (xAf4,yMf2), (xAf4,yMf4))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.vertex_group_a:
            self.color = P.color_icon_5
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "VERTEX_WEIGHT_MIX"
class VERTEX_WEIGHT_PROXIMITY(MD3, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4]
        xMf4 = x-f4 ; yMf4 = y-f4 ; yMf2 = y-f2 ; xMf2 = x-f2 ; xAf2 = x+f2 ; xAf4 = x+f4 ; xMf3 = x-f3 ; xAf3 = x+f3 ; yAf1 = y+f1 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,yAf1), (xMf3,yAf4), (xAf3,yAf4))
        }, indices=indices_tri)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf4), (xMf4,yMf2), (xMf2,yMf2), (xMf2,yMf4))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yMf4), (xAf2,yMf2), (xAf4,yMf2), (xAf4,yMf4))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.vertex_group and md.target:
            self.color = P.color_icon_5
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "VERTEX_WEIGHT_PROXIMITY"
class ARRAY(MD3, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f3 = F[3] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xMf3 = x-f3 ; xMf1 = x-f1 ; xAf1 = x+f1 ; xAf3 = x+f3 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xMf3,yAf5), (xMf3,yMf5))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yMf5), (xMf1,yAf5), (xAf1,yAf5), (xAf1,yMf5))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf3,yMf5), (xAf3,yAf5), (xAf5,yAf5), (xAf5,yMf5))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "ARRAY"
class BEVEL(MD1, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,y+f1), (x-f1,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xMf4,yMf4), (xMf4,y-f1), (x+f1,yAf4), (xAf4,yAf4))
        }, indices=indices_BEVEL)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "BEVEL"
class BOOLEAN(MD22, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf5 = y-f5 ; yMf3 = y-f3 ; xAf3 = x+f3 ; yAf4 = y+f4 ; xAf5 = x+f5 ; xMf5 = x-f5 ; yMf1 = y-f1 ; yAf5 = y+f5 ; xAf1 = x+f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf5), (xMf4,yMf3), (xAf3,yMf3), (xAf3,yAf4), (xAf5,yAf4), (xAf5,yMf5))
        }, indices=indices_BOOLEAN)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf1), (xMf5,yAf5), (xAf1,yAf5), (xAf1,yMf1))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.operand_type == 'OBJECT':
            if md.object is None:
                self.color = P.color_icon_ignore
                self.color2 = P.color_icon_ignore
            else:
                if md.operation == 'DIFFERENCE':    self.color2 = P.color_icon_7
                elif md.operation == 'UNION':       self.color2 = P.color_icon_5
                else:                               self.color2 = P.color_icon_2
                self.color = P.color_icon_6  if md.solver == 'FAST' else self.color2
        elif md.collection is None:
            self.color = P.color_icon_ignore
            self.color2 = P.color_icon_ignore
        else:
            ojs = md.collection.objects
            if ojs:
                is_mesh = True
                for e in ojs:
                    if e.type != "MESH":    is_mesh = False ;break
            else:  is_mesh = False

            if is_mesh is False:
                self.color = P.color_icon_ignore
                self.color2 = P.color_icon_ignore
            else:
                if md.operation == 'DIFFERENCE':    self.color2 = P.color_icon_7
                elif md.operation == 'UNION':       self.color2 = P.color_icon_5
                else:                               self.color2 = P.color_icon_2
                self.color = P.color_icon_6  if md.solver == 'FAST' else self.color2
    def R_name(self): return "BOOLEAN"
class BUILD(MD4, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f3 = F[3] ; f5 = F[5]
        xMf5 = x-f5 ; yAf1 = y+f1 ; xAf1 = x+f1 ; yAf5 = y+f5 ; xAf3 = x+f3 ; xAf5 = x+f5 ; yMf5 = y-f5 ; xMf3 = x-f3 ; yMf1 = y-f1 ; xMf1 = x-f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yAf1), (xAf1,yAf1), (xAf1,yAf5), (xMf5,yAf5))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf3,yAf1), (xAf5,yAf1), (xAf5,yAf5), (xAf3,yAf5))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf3,yMf5), (xMf3,yMf1), (xMf5,yMf1))
        }, indices=indices_box)
        self.bat4 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yMf5), (xAf5,yMf5), (xAf5,yMf1), (xMf1,yMf1))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_7
    def R_name(self): return "BUILD"
class DECIMATE(MD1, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f5 = F[5]
        yMf5 = y-f5 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x-f5,yMf5), (xAf5,y+f5), (xAf5,yMf5))
        }, indices=indices_tri)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "DECIMATE"
class EDGE_SPLIT(MD3, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf2 = x-f2 ; yMf5 = y-f5 ; yAf2 = y+f2 ; xAf5 = x+f5 ; xMf5 = x-f5 ; xMf4 = x-f4 ; yAf4 = y+f4 ; yAf5 = y+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yMf5), (xMf2,yAf2), (xAf5,yAf2), (xAf5,yMf5))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf4,yMf5), (xMf4,yAf2), (xMf5,yAf2))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yAf4), (xAf5,yAf4), (xAf5,yAf5), (xMf2,yAf5))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_5
    def R_name(self): return "EDGE_SPLIT"
class NODES(MD1, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf3 = y-f3 ; xMf4 = x-f4 ; yAf2 = y+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yAf4), (xAf5,yAf4), (xAf5,yMf4), (xAf4,yMf3), (xMf4,yMf3), (xMf4,yAf2), (xAf4,yAf2))
        }, indices=indices_rim)
    def upd_ic_color(self, md):
        if md.node_group:
            self.color = P.color_icon_6
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "NODES"
class MASK(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; xMf2 = x-f2 ; yAf5 = y+f5 ; yAf2 = y+f2 ; xAf5 = x+f5 ; yMf2 = y-f2 ; xAf2 = x+f2 ; xAf1 = x+f1 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf1 = y+f1 ; yMf1 = y-f1 ; xMf1 = x-f1 ; yAf4 = y+f4 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf2), (xMf2,yAf2), (xMf2,yAf5), (xAf5,yAf5), (xAf5,yMf2), (xAf2,yMf2), (xAf2,yMf5), (xAf1,yMf4), (xMf4,yMf4), (xMf4,yAf1), (xMf2,yAf1), (xMf2,yMf2), (xAf1,yMf2), (xAf2,yMf1), (xAf2,yAf2), (xMf1,yAf2), (xMf1,yAf4), (xAf4,yAf4), (xAf4,yMf1))
        }, indices=indices_MASK)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "MASK"
class MIRROR(MD3, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf3 = y-f3 ; yAf3 = y+f3 ; xMf1 = x-f1 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf1 = x+f1 ; xAf2 = x+f2 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf2 = y-f2 ; xAf3 = x+f3 ; yAf2 = y+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf3), (xMf4,yAf3), (xMf1,yAf3), (xMf1,yMf3))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,yMf5), (x,yAf5), (xAf1,yAf5), (xAf1,yMf5))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yMf3), (xAf2,yAf3), (xAf5,yAf3), (xAf5,yMf3), (xAf4,yMf2), (xAf3,yMf2), (xAf3,yAf2), (xAf4,yAf2))
        }, indices=indices_rim)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "MIRROR"
class MULTIRES(MD1, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xAf2 = x+f2 ; yMf2 = y-f2 ; yMf1 = y-f1 ; yAf4 = y+f4 ; xAf1 = x+f1 ; xMf4 = x-f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xAf2,yMf4), (xAf2,yMf2), (xAf4,yMf2), (xAf4,yMf1), (xAf2,yMf1), (xAf2,yAf4), (xAf4,yAf4), (xAf1,yAf4), (xAf1,yMf1), (xMf4,yMf1), (xMf4,yAf4), (xMf4,yMf2), (xAf1,yMf2), (xAf1,yMf4), (xMf4,yMf4))
        }, indices=indices_MULTIRES)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "MULTIRES"
class REMESH(MD2, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4 ; yMf1 = y-f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xMf4,yMf4), (xMf4,yAf4), (xAf4,yAf4))
        }, indices=indices_rim)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,yMf4), (xMf4,y), (xAf4,y), (x+f2,yMf1), (x,y-f3), (x-f2,yMf1))
        }, indices=indices_REMESH)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "REMESH"
class SCREW(MD1, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xMf2 = x-f2 ; yAf1 = y+f1 ; xAf2 = x+f2 ; xMf1 = x-f1 ; yMf4 = y-f4 ; xAf4 = x+f4 ; yAf4 = y+f4 ; xMf4 = x-f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xMf2,yMf5), (xMf2,yAf1), (xAf2,yAf1), (xAf2,y), (xMf1,y), (xMf1,yMf4), (xAf4,yMf4), (xAf4,yAf4), (xMf4,yAf4), (xMf4,yMf5))
        }, indices=indices_SCREW)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "SCREW"
class SKIN(MD1, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f4 = F[4]
        xMf4 = x-f4 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xAf4 = x+f4 ; xAf2 = x+f2 ; yMf2 = y-f2 ; xMf2 = x-f2 ; yAf2 = y+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf4), (xMf4,yAf4), (xAf4,yAf4), (xAf4,yMf4), (xAf2,yMf2), (xMf2,yMf2), (xMf2,yAf2), (xAf2,yAf2))
        }, indices=indices_rim)
    def upd_ic_color(self, md): self.color = P.color_icon_7
    def R_name(self): return "SKIN"
class SOLIDIFY(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf2 = y+f2 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf2 = x+f2 ; yMf4 = y-f4 ; xMf4 = x-f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf2), (x-f2,yAf5), (xAf5,yAf5), (xAf5,y-f2), (xAf2,yMf5), (xAf2,yMf4), (xMf4,yMf4), (xMf4,yAf2), (xAf2,yAf2))
        }, indices=indices_SOLIDIFY)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "SOLIDIFY"
class SUBSURF(MD2, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yAf4 = y+f4 ; yAf5 =y+f5 ; xAf5 = x+f5 ; yMf5 = y-f5 ; xAf4 = x+f4 ; yAf2 = y+f2 ; yAf3 = y+f3 ; xMf1 = x-f1 ; xAf3 = x+f3 ; yMf1 = y-f1 ; xAf2 = x+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yAf4), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf5), (xAf4,yAf4))
        }, indices=indices_BOOLEAN)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yAf2), (xMf5,yAf3), (xMf1,yAf3), (xAf3,yMf1), (xAf3,yMf5), (xAf2,yMf5), (xAf2,yMf1), (xMf1,yAf2))
        }, indices=indices_SUBSURF)
    def upd_ic_color(self, md):
        if md.levels != 0:
            self.color = P.color_icon_1
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "SUBSURF"
class TRIANGULATE(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,y-f4), (x-f4,yAf4), (xAf4,yAf4))
        }, indices=indices_TRIANGULATE)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "TRIANGULATE"
class VOLUME_TO_MESH(MD1, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; yAf4 = y+f4 ; xMf4 = x-f4 ; xAf4 = x+f4 ; yAf1 = y+f1 ; yAf2 = y+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y-f5), (xMf5,y), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yAf4), (xMf4,yAf4), (xMf4,y), (x,y-f4), (xAf4,y), (xAf4,yAf1), (x,yAf1), (x,yAf2), (xAf5,yAf2), (xAf5,y))
        }, indices=indices_VOLUME_TO_MESH)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "VOLUME_TO_MESH"
class WELD(MD2, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3]
        xMf2 = x-f2 ; yMf2 = y-f2 ; xAf1 = x+f1 ; yAf1 = y+f1 ; yAf3 = y+f3 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yMf2), (xMf2,y), (x,y), (x,yMf2))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf1,yAf1), (xAf1,yAf3), (xAf3,yAf3), (xAf3,yAf1))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "WELD"
class WIREFRAME(MD1, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xMf4 = x-f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (x-f3,yMf4), (xAf4,y+f3), (x+f3,yAf4), (xMf4,y-f3), (xMf4,yAf4))
        }, indices=indices_WIREFRAME)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "WIREFRAME"
class ARMATURE(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; xMf1 = x-f1 ; yMf1 = y-f1 ; yAf2 = y+f2 ; xMf3 = x-f3 ; yAf3 = y+f3 ; yAf5 = y+f5 ; xAf1 = x+f1 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf1,yMf1), (xMf1,yAf2), (xMf3,yAf2), (xMf3,yAf3), (xMf1,yAf3), (xMf1,yAf5), (xAf1,yAf5), (xAf1,yAf3), (xAf5,yAf3), (xAf5,yAf2), (xAf1,yAf2), (xAf1,yMf1), (xAf5,yMf5), (x+f3,yMf5), (x,y-f2), (xMf3,yMf5))
        }, indices=indices_ARMATURE)
    def upd_ic_color(self, md):
        if md.object:
            self.color = P.color_icon_5
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "ARMATURE"
class CAST(MD2, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xMf4,yMf4), (xMf4,yAf4), (xAf4,yAf4))
        }, indices=indices_rim)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,y), (x,yAf4), (xAf4,y), (x,yMf4))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.use_x or md.use_y or md.use_z:
            self.color = P.color_icon_6
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "CAST"
class CURVE(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xAf5 = x+f5 ; yMf5 = y-f5 ; xMf1 = x-f1 ; xMf4 = x-f4 ; yMf2 = y-f2 ; yAf2 = y+f2 ; yAf5 = y+f5 ; yAf4 = y+f4 ; xMf3 = x-f3 ; yMf4 = y-f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf5,yMf5), (xMf1,yMf5), (xMf4,yMf2), (xMf4,yAf2), (xMf1,yAf5), (xAf5,yAf5), (xAf5,yAf4), (xMf1,yAf4), (xMf3,yAf2), (xMf3,yMf2), (xMf1,yMf4), (xAf5,yMf4))
        }, indices=indices_CURVE)
    def upd_ic_color(self, md):
        if md.object:
            self.color = P.color_icon_6
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "CURVE"
class DISPLACE(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yMf1 = y-f1 ; xMf2 = x-f2 ; yAf4 = y+f4 ; xAf2 = x+f2 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yMf1), (xMf2,yMf1), (xMf2,yAf4), (xAf2,yAf4), (xAf2,yMf1), (xAf5,yMf1), (xAf5,yMf4))
        }, indices=indices_DISPLACE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "DISPLACE"
class HOOK(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yAf5 = y+f5 ; yMf5 = y-f5 ; xAf4 = x+f4 ; xAf3 = x+f3 ; yMf4 = y-f4 ; xMf3 = x-f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yAf5), (xMf3,yAf5), (xMf3,yMf4), (xAf3,yMf4), (xAf3,y), (xAf4,y), (xAf4,yMf5), (xMf4,yMf5))
        }, indices=indices_HOOK)
    def upd_ic_color(self, md):
        if md.object:
            self.color = P.color_icon_6
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "HOOK"
class LAPLACIANDEFORM(MD22, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; xAf3 = x+f3 ; yAf1 = y+f1 ; yAf3 = y+f3 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,y+f5), (x+f2,y-f2), (x-f1,yMf5))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf3,yAf1), (xAf3,yAf3), (xAf5,yAf3), (xAf5,yAf1))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.vertex_group:
            self.color = P.color_icon_5
            self.color2 = P.color_icon_6
            return
        self.color = P.color_icon_ignore
        self.color2 = P.color_icon_ignore
    def R_name(self): return "LAPLACIANDEFORM"
class LATTICE(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xAf1 = x+f1 ; yMf1 = y-f1 ; yAf1 = y+f1 ; yAf4 = y+f4 ; xMf1 = x-f1 ; xMf4 = x-f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xAf1,yMf4), (xAf1,yMf1), (xAf4,yMf1), (xAf4,yAf1), (xAf1,yAf1), (xAf1,yAf4), (xAf4,yAf4), (xMf1,yAf4), (xMf1,yAf1), (xMf4,yAf1), (xMf4,yAf4), (xMf4,yMf1), (xMf1,yMf1), (xMf1,yMf4), (xMf4,yMf4))
        }, indices=indices_LATTICE)
    def upd_ic_color(self, md):
        if md.object:
            self.color = P.color_icon_6
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "LATTICE"
class MESH_DEFORM(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,y+f5), (x+f2,y-f2), (x-f1,yMf5))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.object:
            self.color = P.color_icon_5
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "MESH_DEFORM"
class SHRINKWRAP(MD22, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; xAf5 = x+f5 ; yMf2 = y-f2 ; yMf1 = y-f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (x,y), (xAf5,yMf5))
        }, indices=indices_tri)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf2), (xMf5,yMf1), (x,y+f4), (xAf5,yMf1), (xAf5,yMf2), (x,y+f3))
        }, indices=indices_BOOLEAN)
    def upd_ic_color(self, md):
        if md.target:
            self.color = P.color_icon_5
            self.color2 = P.color_icon_6
            return
        self.color = P.color_icon_ignore
        self.color2 = P.color_icon_ignore
    def R_name(self): return "SHRINKWRAP"
class SIMPLE_DEFORM(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yAf3 = y+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yAf3), (x+f5,yAf3), (x-f2,yMf4))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_5
    def R_name(self): return "SIMPLE_DEFORM"
class SMOOTH(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f5 = F[5]
        yMf3 = y-f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x-f5,yMf3), (x-f2,y), (x+f2,y), (x+f5,yMf3))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.use_x or md.use_y or md.use_z:
            self.color = P.color_icon_6
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "SMOOTH"
class CORRECTIVE_SMOOTH(MD2, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f5 = F[5]
        yMf3 = y-f3 ; xMf3 = x-f3 ; yAf2 = y+f2 ; yAf3 = y+f3 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x-f5,yMf3), (x-f2,y), (x+f2,y), (x+f5,yMf3))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf3,yAf2), (xMf3,yAf3), (xAf3,yAf3), (xAf3,yAf2))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "CORRECTIVE_SMOOTH"
class LAPLACIANSMOOTH(MD2, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        yMf3 = y-f3 ; xMf1 = x-f1 ; yAf2 = y+f2 ; yAf4 = y+f4 ; xAf1 = x+f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x-f5,yMf3), (x-f2,y), (x+f2,y), (x+f5,yMf3))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yAf2), (xMf1,yAf4), (xAf1,yAf4), (xAf1,yAf2))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.use_x or md.use_y or md.use_z:
            self.color = P.color_icon_6
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "LAPLACIANSMOOTH"
class SURFACE_DEFORM(MD22, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f5 = F[5]
        xMf5 = x-f5 ; xMf1 = x-f1 ; yMf2 = y-f2 ; xAf1 = x+f1 ; xAf5 = x+f5 ; yMf5 = y-f5 ; yAf1 = y+f1 ; yAf3 = y+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,y), (x-f3,y), (xMf1,yMf2), (xAf1,yMf2), (x+f3,y), (xAf5,y), (xAf5,yMf5), (xMf5,yMf5))
        }, indices=indices_HOOK)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yAf1), (xMf1,yAf3), (xAf1,yAf3), (xAf1,yAf1))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.target:
            self.color = P.color_icon_5
            self.color2 = P.color_icon_6
            return
        self.color = P.color_icon_ignore
        self.color2 = P.color_icon_ignore
    def R_name(self): return "SURFACE_DEFORM"
class WARP(MD1, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf2 = y+f2 ; xAf2 = x+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf2), (x-f1,yAf2), (xAf2,y+f5), (x+f5,yAf2), (xAf2,y-f1), (xAf2,yMf5))
        }, indices=indices_WARP)
    def upd_ic_color(self, md):
        if md.object_from and md.object_to:
            self.color = P.color_icon_6
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "WARP"
class WAVE(MD3, MD_IND4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,y-f4), (x+f4,yAf5), (xAf5,yAf5))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x-f1,yMf5), (x-f2,yMf5), (xAf5,y+f2), (xAf5,y+f1))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x+f3,yMf5), (x+f2,yMf5), (xAf5,y-f2), (xAf5,y-f3))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_7
    def R_name(self): return "WAVE"
class CLOTH(MD1, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf3 = x-f3 ; yMf4 = y-f4 ; yAf2 = y+f2 ; xMf5 = x-f5 ; yAf5 = y+f5 ; yAf4 = y+f4 ; xAf5 = x+f5 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf3,yMf4), (xMf3,yAf2), (xMf5,yAf2), (xMf5,yAf5), (x-f2,yAf5), (x-f1,yAf4), (x+f1,yAf4), (x+f2,yAf5), (xAf5,yAf5), (xAf5,yAf2), (xAf3,yAf2), (xAf3,yMf4))
        }, indices=indices_CLOTH)
    def upd_ic_color(self, md): self.color = P.color_icon_7
    def R_name(self): return "CLOTH"
class COLLISION(MD2, MD_IND0):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f5 = F[5]
        xAf1 = x+f1 ; yMf5 = y-f5 ; yMf1 = y-f1 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x-f5,y+f1), (x-f1,y+f5), (x+f2,y+f2), (x-f2,y-f2))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf1,yMf5), (xAf1,yMf1), (xAf5,yMf1), (xAf5,yMf5))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_7
    def R_name(self): return "COLLISION"
class DYNAMIC_PAINT(MD2, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        yAf1 = y+f1 ; xMf5 = x-f5 ; yMf5 = y-f5 ; yMf4 = y-f4 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y-f3), (x-f4,yAf1), (x,y+f5), (x+f4,yAf1), (x+f3,yAf1), (x-f3,yAf1), (x,y+f4))
        }, indices=indices_TRIANGULATE)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yMf4), (xAf5,yMf4), (xAf5,yMf5))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_3
    def R_name(self): return "DYNAMIC_PAINT"
class EXPLODE(MD3, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xMf2 = x-f2 ; yMf5 = y-f5 ; yAf2 = y+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y), (xMf5,yAf5), (xAf5,yAf5))
        }, indices=indices_tri)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yMf5), (xAf5,yAf2), (xAf5,yMf5))
        }, indices=indices_tri)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,y-f4), (xMf5,yAf2), (xMf2,y-f1))
        }, indices=indices_tri)
    def upd_ic_color(self, md): self.color = P.color_icon_7
    def R_name(self): return "EXPLODE"
class FLUID(MD3, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf2 = y-f2 ; yAf4 = y+f4 ; xMf3 = x-f3 ; yMf5 = y-f5 ; xAf1 = x+f1 ; xAf4 = x+f4 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf2), (xMf4,yAf4), (xMf3,yAf4), (xMf3,yMf2))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,yMf5), (x,yAf4), (xAf1,yAf4), (xAf1,yMf5))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf4,yMf2), (xAf4,yAf4), (xAf5,yAf4), (xAf5,yMf2))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_3
    def R_name(self): return "FLUID"
class OCEAN(MD2, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; xMf2 = x-f2 ; yMf1 = y-f1 ; xAf2 = x+f2 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf2 = y-f2 ; xMf4 = x-f4 ; yAf2 = y+f2 ; yAf1 = y+f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf2,yMf1), (x,y-f3), (xAf2,yMf1), (xAf5,yMf4), (xAf4,yMf4), (xAf2,yMf2), (x,yMf4), (xMf2,yMf2), (xMf4,yMf4))
        }, indices=indices_OCEAN)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf1), (xMf2,yAf2), (x,y), (xAf2,yAf2), (xAf5,yMf1), (xAf4,yMf1), (xAf2,yAf1), (x,yMf1), (xMf2,yAf1), (xMf4,yMf1))
        }, indices=indices_OCEAN)
    def upd_ic_color(self, md): self.color = P.color_icon_3
    def R_name(self): return "OCEAN"
class PARTICLE_INSTANCE(MD3, MD_IND3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf2 = x-f2 ; yMf5 = y-f5 ; yMf1 = y-f1 ; xAf2 = x+f2 ; xAf1 = x+f1 ; yMf4 = y-f4 ; xMf1 = x-f1 ; yMf2 = y-f2 ; xMf4 = x-f4 ; yAf2 = y+f2 ; yAf4 = y+f4 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yMf5), (xMf2,yMf1), (xAf2,yMf1), (xAf2,yMf5), (xAf1,yMf4), (xMf1,yMf4), (xMf1,yMf2), (xAf1,yMf2))
        }, indices=indices_rim)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yAf2), (xMf4,yAf4), (xMf2,yAf4), (xMf2,yAf2))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yAf2), (xAf2,yAf4), (xAf4,yAf4), (xAf4,yAf2))
        }, indices=indices_box)
    def upd_ic_color(self, md):
        if md.particle_system:
            self.color = P.color_icon_7
            return
        self.color = P.color_icon_ignore
    def R_name(self): return "PARTICLE_INSTANCE"
class PARTICLE_SYSTEM(MD3, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf2 = x-f2 ; yMf5 = y-f5 ; yMf1 = y-f1 ; xAf2 = x+f2 ; xMf4 = x-f4 ; yAf2 = y+f2 ; yAf4 = y+f4 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yMf5), (xMf2,yMf1), (xAf2,yMf1), (xAf2,yMf5))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yAf2), (xMf4,yAf4), (xMf2,yAf4), (xMf2,yAf2))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yAf2), (xAf2,yAf4), (xAf4,yAf4), (xAf4,yAf2))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_7
    def R_name(self): return "PARTICLE_SYSTEM"
class SOFT_BODY(MD22, MD_IND2):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf2 = y-f2 ; yAf5 = y+f5 ; xAf4 = x+f4 ; yMf5 = y-f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf2), (xMf4,yAf5), (xAf4,yAf5), (xAf4,yMf2), (x,y+f2))
        }, indices=indices_SOFT_BODY)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x-f5,yMf5), (x,y), (x+f5,yMf5))
        }, indices=indices_tri)
    def upd_ic_color(self, md): self.color = P.color_icon_3 ; self.color2 = P.color_icon_6
    def R_name(self): return "SOFT_BODY"

class META(MD2):
    __slots__ = ()
    def upd(self, x, y):
        f4 = F[4]
        xMf4 = x-f4 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf4), (xMf4,y), (x,y), (x,yMf4))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y), (x,yAf4), (xAf4,yAf4), (xAf4,y))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_7
    def R_name(self): return "META"
class MATERIAL(MD3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yMf1 = y-f1 ; xMf1 = x-f1 ; xAf1 = x+f1 ; xAf5 = x+f5 ; xMf2 = x-f2 ; yAf1 = y+f1 ; yAf5 = y+f5 ; xAf2 = x+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yMf1), (xMf1,yMf1), (xMf1,yMf5))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf1,yMf5), (xAf1,yMf1), (xAf5,yMf1), (xAf5,yMf5))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yAf1), (xMf2,yAf5), (xAf2,yAf5), (xAf2,yAf1))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "MATERIAL"
class LINESTYLE(MD2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f5 = F[5]
        xMf5 = x-f5 ; yMf2 = y-f2 ; yMf1 = y-f1 ; xAf5 = x+f5 ; yAf1 = y+f1 ; yAf2 = y+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf2), (xMf5,yMf1), (xAf5,yMf1), (xAf5,yMf2))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yAf1), (xMf5,yAf2), (xAf5,yAf2), (xAf5,yAf1))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "LINESTYLE"
class LIBRARY(MD3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4]
        xMf4 = x-f4 ; yMf3 = y-f3 ; yAf3 = y+f3 ; xMf2 = x-f2 ; xMf1 = x-f1 ; xAf1 = x+f1 ; xAf2 = x+f2 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf3), (xMf4,yAf3), (xMf2,yAf3), (xMf2,yMf3))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yMf3), (xMf1,yAf3), (xAf1,yAf3), (xAf1,yMf3))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yMf3), (xAf2,yAf3), (xAf4,yAf3), (xAf4,yMf3))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "LIBRARY"
class LIGHT(MD4):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4]
        xMf1 = x-f1 ; yMf4 = y-f4 ; yMf2 = y-f2 ; xAf1 = x+f1 ; xMf4 = x-f4 ; yMf1 = y-f1 ; yAf1 = y+f1 ; xMf2 = x-f2 ; yAf2 = y+f2 ; yAf4 = y+f4 ; xAf2 = x+f2 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yMf4), (xMf1,yMf2), (xAf1,yMf2), (xAf1,yMf4))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf1), (xMf4,yAf1), (xMf2,yAf1), (xMf2,yMf1))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yAf2), (xMf1,yAf4), (xAf1,yAf4), (xAf1,yAf2))
        }, indices=indices_box)
        self.bat4 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yMf1), (xAf2,yAf1), (xAf4,yAf1), (xAf4,yMf1))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "LIGHT"
class KEY(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf3 = x-f3 ; yMf5 = y-f5 ; xMf1 = x-f1 ; yAf5 = y+f5 ; xAf2 = x+f2 ; xAf1 = x+f1 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf3,yMf5), (xMf3,y), (xMf1,y), (xMf1,yAf5), (xAf2,yAf5), (xAf2,y+f4), (xAf1,y+f3), (xAf1,y), (xAf3,y), (xAf3,yMf5))
        }, indices=indices_KEY)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "KEY"
class IMAGE(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xAf4 = x+f4 ; yAf5 = y+f5 ; yMf5 = y-f5 ; xMf4 = x-f4 ; xAf3 = x+f3 ; yMf3 = y-f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf4,yAf5), (xAf4,yMf5), (xMf4,yMf5), (xMf4,yAf5), (x,y), (xAf3,yMf3), (x-f3,yMf3))
        }, indices=indices_TRIANGULATE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "IMAGE"
class COLLECTION(MD2):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf4 = y-f4 ; yAf2 = y+f2 ; xAf4 = x+f4 ; xMf5 = x-f5 ; yAf3 = y+f3 ; yAf5 = y+f5 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf4), (xMf4,yAf2), (xAf4,yAf2), (xAf4,yMf4))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yAf3), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yAf3))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "COLLECTION"
class GREASEPENCIL(MD2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf3 = y+f3 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,y-f3), (x+f1,yAf3), (xAf3,y+f1), (x-f3,yMf5))
        }, indices=indices_SOFT_BODY)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x+f2,y+f4), (xAf3,y+f5), (x+f5,yAf3), (x+f4,y+f2))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "GREASEPENCIL"
class FONT(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf3 = x-f3 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf4 = x+f4 ; yAf3 = y+f3 ; xMf1 = x-f1 ; yAf1 = y+f1 ; xAf3 = x+f3 ; yMf1 = y-f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf3,yMf5), (xMf3,yAf5), (xAf4,yAf5), (xAf4,yAf3), (xMf1,yAf3), (xMf1,yAf1), (xAf3,yAf1), (xAf3,yMf1), (xMf1,yMf1), (xMf1,yMf5))
        }, indices=indices_FONT)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "FONT"
class CACHEFILE(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf4 = x+f4 ; xAf3 = x+f3 ; xAf3 = x+f3 ; xMf3 = x-f3 ; yMf4 = y-f4 ; yAf4 = y+f4 ; yAf1 = y+f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf5), (xMf4,yAf5), (x+f1,yAf5), (xAf4,y+f2), (xAf4,yMf5), (xAf3,yMf4), (xMf3,yMf4), (xMf3,yAf4), (x,yAf4), (x,yAf1), (xAf3,yAf1))
        }, indices=indices_CACHEFILE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "CACHEFILE"
class CAMERA(MD2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f5 = F[5]
        xMf5 = x-f5 ; yMf3 = y-f3 ; yAf3 = y+f3 ; xAf2 = x+f2 ; xAf3 = x+f3 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf3), (xMf5,yAf3), (xAf2,yAf3), (xAf2,yMf3))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf3,y-f1), (xAf3,y+f1), (xAf5,yAf3), (xAf5,yMf3))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "CAMERA"
class BRUSH(MD2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf3 = x-f3 ; yMf5 = y-f5 ; yMf2 = y-f2 ; xAf3 = x+f3 ; xAf2 = x+f2 ; yMf4 = y-f4 ; xAf1 = x+f1 ; xMf1 = x-f1 ; xMf2 = x-f2 ; yMf3 = y-f3 ; yMf1 = y-f1 ; yAf5 = y+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf3,yMf5), (xMf3,yMf2), (xAf3,yMf2), (xAf3,yMf5), (xAf2,yMf4), (xAf1,yMf4), (xMf1,yMf4), (xMf2,yMf4), (xMf2,yMf3), (xMf1,yMf3), (xAf1,yMf3), (xAf2,yMf3))
        }, indices=indices_BRUSH)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf3,yMf1), (xMf3,y), (xMf1,y), (xMf1,yAf5), (xAf1,yAf5), (xAf1,y), (xAf3,y), (xAf3,yMf1))
        }, indices=indices_DISPLACE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "BRUSH"
class ACTION(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f3 = F[3] ; f4 = F[4]
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y-f4), (x-f4,y), (x,y+f4), (x+f4,y), (x+f3,y), (x,y-f3), (x-f3,y), (x,y+f3))
        }, indices=indices_rim)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "ACTION"
class WORKSPACE(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yMf4 = y-f4 ; xMf2 = x-f2 ; yMf2 = y-f2 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf2 = x+f2 ; xAf4 = x+f4 ; yMf1 = y-f1 ; xMf4 = x-f4 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yMf4), (xMf2,yMf4), (xMf2,yMf2), (xMf5,yMf2), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf2), (xAf2,yMf2), (xAf2,yMf4), (xAf5,yMf4), (xAf5,yMf5), (xAf4,yMf1), (xMf4,yMf1), (xMf4,yAf4), (xAf4,yAf4))
        }, indices=indices_WORKSPACE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "WORKSPACE"
class WORLD(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf4 = y-f4 ; yMf3 = y-f3 ; yAf4 = y+f4 ; xAf3 = x+f3 ; xAf4 = x+f4 ; yAf3 = y+f3 ; xMf3 = x-f3 ; yMf1 = y-f1 ; yAf1 = y+f1 ; xMf1 = x-f1 ; xAf1 = x+f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,y-f5), (x-f5,yMf4), (xMf4,yMf3), (xMf4,y+f2), (x-f2,yAf4), (xAf3,yAf4), (xAf4,y+f5), (x+f5,yAf4), (xAf4,yAf3), (xAf4,y-f2),
            (x+f2,yMf4), (xMf3,yMf4), (xMf3,yMf1), (xMf3,yAf1), (xMf1,yAf3), (xAf1,yAf3), (xAf3,yAf1), (xAf3,yMf1), (xAf1,yMf3), (xMf1,yMf3))
        }, indices=indices_WORLD)
    def upd_ic_color(self, md): self.color = P.color_icon_3
    def R_name(self): return "WORLD"
class WINDOWMANAGER(MD2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf3 = y-f3 ; xMf4 = x-f4 ; yAf3 = y+f3 ; xAf1 = x+f1 ; yAf2 = y+f2 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yAf4), (xAf5,yAf4), (xAf5,yMf4), (xAf4,yMf3), (xMf4,yMf3), (xMf4,yAf3), (xAf4,yAf3))
        }, indices=indices_rim)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf1,y), (xAf1,yAf2), (xAf3,yAf2), (xAf3,y))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "WINDOWMANAGER"
class VOLUME(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; yAf4 = y+f4 ; xMf4 = x-f4 ; xAf4 = x+f4 ; yAf1 = y+f1 ; yAf2 = y+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,y-f5), (xMf5,y), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yAf4), (xMf4,yAf4), (xMf4,y), (x,y-f4), (xAf4,y), (xAf4,yAf1), (x,yAf1), (x,yAf2), (xAf5,yAf2), (xAf5,y))
        }, indices=indices_VOLUME_TO_MESH)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "VOLUME"
class POINTCLOUD(MD3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf1 = x-f1 ; yMf4 = y-f4 ; yMf2 = y-f2 ; xAf1 = x+f1 ; xMf5 = x-f5 ; yAf1 = y+f1 ; yAf3 = y+f3 ; xMf3 = x-f3 ; xAf3 = x+f3 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yMf4), (xMf1,yMf2), (xAf1,yMf2), (xAf1,yMf4))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yAf1), (xMf5,yAf3), (xMf3,yAf3), (xMf3,yAf1))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf3,yAf1), (xAf3,yAf3), (xAf5,yAf3), (xAf5,yAf1))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "POINTCLOUD"
class HAIR(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yMf3 = y-f3 ; xMf3 = x-f3 ; yAf1 = y+f1 ; yAf2 = y+f2 ; xMf2 = x-f2 ; xMf1 = x-f1 ; yAf3 = y+f3 ; xAf1 = x+f1 ; xAf2 = x+f2 ; xAf3 = x+f3 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yMf3), (xMf3,yMf3), (xMf3,y), (x-f4,yAf1), (xMf3,yAf2), (xMf2,yAf1), (xMf2,yMf3), (xMf1,yMf3), (xMf1,yAf3),
            (xAf1,yAf3), (xAf1,yMf3), (xAf2,yMf3), (xAf2,yAf1), (xAf3,yAf2), (x+f4,yAf1), (xAf3,y), (xAf3,yMf3), (xAf5,yMf3), (xAf5,yMf4))
        }, indices=indices_HAIR)
    def upd_ic_color(self, md): self.color = P.color_icon_5
    def R_name(self): return "HAIR"
class TEXTURE(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (x,yMf4), (x,y), (xMf4,y), (xMf4,yAf4), (x,yAf4), (x,y), (xAf4,y))
        }, indices=indices_UV_PROJECT)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "TEXTURE"
class TEXT(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf4 = x+f4 ; xAf3 = x+f3 ; yMf4 = y-f4 ; xMf2 = x-f2 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf5), (xMf4,yAf5), (xAf4,yAf5), (xAf4,yMf5), (xAf3,yMf4), (xMf2,yMf4), (xMf2,yAf4), (xAf3,yAf4))
        }, indices=indices_rim)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "TEXT"
class SPEAKER(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f5 = F[5]
        xMf2 = x-f2 ; yMf2 = y-f2 ; yAf2 = y+f2 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yMf2), (xMf2,yAf2), (x,yAf2), (xAf3,y+f5), (xAf3,y-f5), (x,yMf2))
        }, indices=indices_SPEAKER)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "SPEAKER"
class SOUND(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yMf3 = y-f3 ; xMf3 = x-f3 ; yMf1 = y-f1 ; yAf4 = y+f4 ; xAf4 = x+f4 ; xAf1 = x+f1 ; xAf3 = x+f3 ; yAf3 = y+f3 ; xMf2 = x-f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yMf3), (xMf3,yMf1), (xMf3,yAf4), (xAf4,yAf4), (xAf4,yMf5), (xAf1,yMf5), (xAf1,yMf3), (xAf3,yMf1), (xAf3,yAf3), (xMf2,yAf3), (xMf2,yMf5))
        }, indices=indices_SOUND)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "SOUND"
class SIMULATION(MD2):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf2 = y-f2 ; yAf3 = y+f3 ; xMf1 = x-f1 ; yAf2 = y+f2 ; xAf1 = x+f1 ; xAf5 = x+f5 ; yMf1 = y-f1 ; xMf2 = x-f2 ; xMf4 = x-f4 ; yAf1 = y+f1 ; xAf2 = x+f2 ; xAf4 = x+f4 ; yMf4 = y-f4 ; yMf3 = y-f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf2), (xMf5,yAf3), (xMf1,yAf3), (x,yAf2), (xAf1,yAf3), (xAf5,yAf3), (xAf5,yMf2), (xAf1,yMf2), (x,yMf1),
            (xMf1,yMf2), (xMf2,yMf1), (xMf4,yMf1), (xMf4,yAf2), (xMf2,yAf2), (xMf1,yAf1), (xMf1,y), (xAf1,y), (xAf1,yAf1), (xAf2,yAf2), (xAf4,yAf2), (xAf4,yMf1), (xAf2,yMf1))
        }, indices=indices_SIMULATION)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yMf4), (xMf1,yMf3), (xAf1,yMf3), (xAf1,yMf4))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "SIMULATION"
class SCENE(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xMf2 = x-f2 ; yAf4 = y+f4 ; xAf2 = x+f2 ; xAf4 = x+f4 ; yMf4 = y-f4 ; yMf3 = y-f3 ; yMf1 = y-f1 ; yAf3 = y+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf5), (xMf4,yAf5), (xMf2,yAf5), (xMf2,yAf4), (xAf2,yAf4), (xAf2,yAf5), (xAf4,yAf5), (xAf4,yMf5),
            (xAf2,yMf5), (xAf2,yMf4), (xMf2,yMf4), (xMf2,yMf5), (xMf2,yMf3), (xMf2,yMf1), (xAf2,yMf1), (xAf2,yMf3), (xAf2,y), (xMf2,y), (xMf2,yAf3), (xAf2,yAf3))
        }, indices=indices_SCENE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "SCENE"
class LIGHT_PROBE(MD5):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf4 = y-f4 ; xMf4 = x-f4 ; yAf4 = y+f4 ; xMf1 = x-f1 ; yMf3 = y-f3 ; yMf2 = y-f2 ; xMf3 = x-f3 ; yAf1 = y+f1 ; xMf2 = x-f2
        yAf2 = y+f2 ; yAf3 = y+f3 ; xAf1 = x+f1 ; xAf2 = x+f2 ; yMf1 = y-f1 ; xAf3 = x+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yMf5), (xAf4,yMf4), (xMf4,yMf4), (xMf4,yAf4), (xAf4,yAf4))
        }, indices=indices_rim)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yMf3), (xMf1,yMf2), (x,yMf2), (x,yMf3))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf3,y), (xMf3,yAf1), (xMf2,yAf1), (xMf2,y))
        }, indices=indices_box)
        self.bat4 = batch_for_shader(shader2D, 'TRIS', {"pos": ((x,yAf2), (x,yAf3), (xAf1,yAf3), (xAf1,yAf2))
        }, indices=indices_box)
        self.bat5 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yMf1), (xAf2,y), (xAf3,y), (xAf3,yMf1))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_1
    def R_name(self): return "LIGHT_PROBE"
class PARTICLE(MD3):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf2 = x-f2 ; yMf5 = y-f5 ; yMf1 = y-f1 ; xAf2 = x+f2 ; xMf4 = x-f4 ; yAf2 = y+f2 ; yAf4 = y+f4 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf2,yMf5), (xMf2,yMf1), (xAf2,yMf1), (xAf2,yMf5))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yAf2), (xMf4,yAf4), (xMf2,yAf4), (xMf2,yAf2))
        }, indices=indices_box)
        self.bat3 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf2,yAf2), (xAf2,yAf4), (xAf4,yAf4), (xAf4,yAf2))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "PARTICLE"
class PALETTE(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xAf5 = x+f5 ; yMf4 = y-f4 ; xMf5 = x-f5 ; yAf4 = y+f4 ; yAf1 = y+f1 ; yMf3 = y-f3 ; xMf4 = x-f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf5,yMf4), (x-f3,yMf4), (xMf5,y-f2), (xMf5,yAf4), (xAf5,yAf4), (x,yAf1), (x,yMf3), (x-f2,yMf3), (xMf4,y-f1), (xMf4,yAf1))
        }, indices=indices_BEVEL)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "PALETTE"
class PAINTCURVE(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yAf5 = y+f5 ; xAf1 = x+f1 ; xAf4 = x+f4 ; yAf2 = y+f2 ; yMf2 = y-f2 ; yMf5 = y-f5 ; yMf4 = y-f4 ; xAf3 = x+f3 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yAf5), (xAf1,yAf5), (xAf4,yAf2), (xAf4,yMf2), (xAf1,yMf5), (xMf5,yMf5), (xMf5,yMf4), (xAf1,yMf4), (xAf3,yMf2), (xAf3,yAf2), (xAf1,yAf4), (xMf5,yAf4))
        }, indices=indices_CURVE)
    def upd_ic_color(self, md): self.color = P.color_icon_4
    def R_name(self): return "PAINTCURVE"
class OBJECT(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f4 = F[4]
        xMf4 = x-f4 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xAf4 = x+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf4), (xMf4,yAf4), (xAf4,yAf4), (xAf4,yMf4))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "OBJECT"
class NODETREE(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xAf5 = x+f5 ; xAf4 = x+f4 ; yMf3 = y-f3 ; xMf4 = x-f4 ; yAf2 = y+f2
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yAf4), (xAf5,yAf4), (xAf5,yMf4), (xAf4,yMf3), (xMf4,yMf3), (xMf4,yAf2), (xAf4,yAf2))
        }, indices=indices_rim)
    def upd_ic_color(self, md): self.color = P.color_icon_5
    def R_name(self): return "NODETREE"
class MOVIECLIP(MD1):
    __slots__ = ()
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf4 = x-f4 ; yMf2 = y-f2 ; yAf5 = y+f5 ; xAf4 = x+f4 ; yMf5 = y-f5 ; xMf2 = x-f2 ; yAf3 = y+f3 ; xAf2 = x+f2 ; xAf1 = x+f1 ; yAf2 = y+f2 ; xMf1 = x-f1 ; yMf4 = y-f4 ; xAf3 = x+f3 ; yAf4 = y+f4 ; xMf3 = x-f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf2), (xMf4,yAf5), (xAf4,yAf5), (xAf4,yMf5), (xMf2,yMf5), (xMf2,yAf3), (xAf2,yAf3), (xAf2,yMf2), (xAf1,yMf2), (xAf1,yAf2), (xMf1,yAf2), (xMf1,yMf4), (xAf3,yMf4), (xAf3,yAf4), (xMf3,yAf4), (xMf3,yMf2))
        }, indices=indices_MOVIECLIP)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def R_name(self): return "MOVIECLIP"

class AVERAGE:
    __slots__ = ("bat", "color")
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yAf3 = y+f3 ; xAf5 = x+f5 ; yAf2 = y+f2 ; xAf2 = x+f2 ; xAf1 = x+f1 ; yMf3 = y-f3 ; xMf4 = x-f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yAf3), (xAf5,yAf3), (xAf5,yAf2), (xAf2,yAf2), (xAf2,yMf4), (xAf1,yMf3), (xMf4,yMf3), (xMf4,yAf2), (xAf1,yAf2))
        }, indices=indices_AVERAGE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D)
    def R_name(self): return "AVERAGE"
class SUM:
    __slots__ = ("bat", "color")
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f3 = F[3] ; f5 = F[5]
        xAf5 = x+f5 ; yMf5 = y-f5 ; xMf5 = x-f5 ; yAf5 = y+f5 ; yAf3 = y+f3 ; xMf1 = x-f1 ; yMf3 = y-f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf5,yMf5), (xMf5,yMf5), (x,y), (xMf5,yAf5), (xAf5,yAf5), (xAf5,yAf3), (xMf1,yAf3), (x+f2,y), (xMf1,yMf3), (xAf5,yMf3))
        }, indices=indices_SUM)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D)
    def R_name(self): return "SUM"
class SCRIPTED:
    __slots__ = ("bat", "bat2", "color")
    def upd(self, x, y):
        f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xAf5 = x+f5 ; yMf4 = y-f4 ; xMf5 = x-f5 ; yMf2 = y-f2 ; yAf2 = y+f2 ; yAf4 = y+f4
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf5,yMf4), (xMf5,yMf4), (xMf5,yMf2), (xAf5,yMf2))
        }, indices=indices_box)
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf5,yAf2), (xMf5,yAf2), (xMf5,yAf4), (xAf5,yAf4))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D) ; self.bat2.draw(shader2D)
    def R_name(self): return "SCRIPTED"
class MIN:
    __slots__ = ("bat", "color")
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yMf2 = y-f2 ; xMf1 = x-f1 ; xAf1 = x+f1 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yMf2), (xMf1,yMf2), (xMf1,y), (xAf1,y), (xAf1,yMf2), (xAf5,yMf2), (xAf5,yMf4))
        }, indices=indices_DISPLACE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D)
    def R_name(self): return "MIN"
class MAX:
    __slots__ = ("bat", "color")
    def upd(self, x, y):
        f1 = F[1] ; f2 = F[2] ; f4 = F[4] ; f5 = F[5]
        xAf5 = x+f5 ; yAf4 = y+f4 ; yAf2 = y+f2 ; xAf1 = x+f1 ; xMf1 = x-f1 ; xMf5 = x-f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf5,yAf4), (xAf5,yAf2), (xAf1,yAf2), (xAf1,y), (xMf1,y), (xMf1,yAf2), (xMf5,yAf2), (xMf5,yAf4))
        }, indices=indices_DISPLACE)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D)
    def R_name(self): return "MAX"

class SINGLE_PROP:
    __slots__ = ("bat", "bat2", "color")
    def upd(self, x, y):
        f1 = F[1] ; f3 = F[3] ; f4 = F[4]
        xMf4 = x-f4 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xAf4 = x+f4 ; xAf3 = x+f3 ; yMf3 = y-f3 ; xMf3 = x-f3 ; yAf3 = y+f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf4,yMf4), (xMf4,yAf4), (xAf4,yAf4), (xAf4,yMf4), (xAf3,yMf3), (xMf3,yMf3), (xMf3,yAf3), (xAf3,yAf3))
        }, indices=indices_SINGLE_PROP)
        xMf1 = x-f1 ; yMf1 = y-f1 ; yAf1 = y+f1 ; xAf1 = x+f1
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf1,yMf1), (xMf1,yAf1), (xAf1,yAf1), (xAf1,yMf1))
        }, indices=indices_box)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D) ; self.bat2.draw(shader2D)
    def R_name(self): return "SINGLE_PROP"
class TRANSFORMS:
    __slots__ = ("bat", "bat2", "color")
    def upd(self, x, y):
        f2 = F[2] ; f3 = F[3] ; f4 = F[4] ; f5 = F[5]
        xMf5 = x-f5 ; yMf4 = y-f4 ; yAf4 = y+f4 ; xMf2 = x-f2 ; yAf3 = y+f3 ; xMf4 = x-f4 ; yMf3 = y-f3
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf4), (xMf5,yAf4), (xMf2,yAf4), (xMf2,yAf3), (xMf4,yAf3), (xMf4,yMf3), (xMf2,yMf3), (xMf2,yMf4))
        }, indices=indices_TRANSFORMS)
        xAf4 = x+f4 ; xAf2 = x+f2 ; xAf5 = x+f5
        self.bat2 = batch_for_shader(shader2D, 'TRIS', {"pos": ((xAf4,yMf3), (xAf4,yAf3), (xAf2,yAf3), (xAf2,yAf4), (xAf5,yAf4), (xAf5,yMf4), (xAf2,yMf4), (xAf2,yMf3))
        }, indices=indices_TRANSFORMS)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D) ; self.bat2.draw(shader2D)
    def R_name(self): return "TRANSFORMS"
class ROTATION_DIFF:
    __slots__ = ("bat", "color")
    def upd(self, x, y):
        f1 = F[1] ; f3 = F[3] ; f5 = F[5]
        xMf5 = x-f5 ; yMf5 = y-f5 ; yAf5 = y+f5 ; xMf3 = x-f3 ; yAf1 = y+f1 ; xAf1 = x+f1 ; yMf3 = y-f3 ; xAf5 = x+f5
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf5), (xMf5,yAf5), (xMf3,yAf5), (xMf3,yAf1), (xAf1,yAf1), (xAf1,yMf3), (xAf5,yMf3), (xAf5,yMf5), (xMf3,yMf3), (xMf3,y), (x,y), (x,yMf3))
        }, indices=indices_ROTATION_DIFF)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D)
    def R_name(self): return "ROTATION_DIFF"
class LOC_DIFF:
    __slots__ = ("bat", "color")
    def upd(self, x, y):
        f1 = F[1] ; f3 = F[3] ; f5 = F[5]
        xMf5 = x-f5 ; yMf3 = y-f3 ; yAf3 = y+f3 ; xMf3 = x-f3 ; xAf3 = x+f3 ; xAf5 = x+f5 ; yMf1 = y-f1
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": ((xMf5,yMf3), (xMf5,yAf3), (xMf3,yAf3), (xMf3,y), (xAf3,y), (xAf3,yAf3), (xAf5,yAf3), (xAf5,yMf3), (xAf3,yMf3), (xAf3,yMf1), (xMf3,yMf1), (xMf3,yMf3))
        }, indices=indices_LOC_DIFF)
    def upd_ic_color(self, md): self.color = P.color_icon_6
    def bind_draw(self): BIND() ; UNFL("color", self.color) ; self.bat.draw(shader2D)
    def R_name(self): return "LOC_DIFF"
# ▅▅▅