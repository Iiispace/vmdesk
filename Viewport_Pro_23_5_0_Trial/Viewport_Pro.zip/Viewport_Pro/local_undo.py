import bpy
from bpy.app.handlers import persistent

undo_evt = None
P = None
undo_steps = None

TM = {}

@persistent
def before_undo(self, dummy):
    TM[None] = bpy.context.scene.undo_ind
@persistent
def after_undo(self, dummy):
    i = bpy.context.scene.undo_ind
    if i == TM[None]:
        undo_evt.ind = i
        return

#

    history = undo_evt.history
    for r in range(TM[None] - 1, i - 1, -1):
        for fx in history[r]: fx()
#

    undo_evt.ind = i

@persistent
def before_redo(self, dummy):
    TM[None] = bpy.context.scene.undo_ind
@persistent
def after_redo(self, dummy):
    i = bpy.context.scene.undo_ind
    if i == TM[None]:
        undo_evt.ind = i
        return

#

    history = undo_evt.history
    for r in range(TM[None] + 1, i + 1):
        for fx in history[r]: fx()
#

    undo_evt.ind = i


class UNDO_EVT:
    __slots__ = (
        'ind',
        'history',
        'li',
    )
    def __init__(self):
        self.ind = 0
        self.history = {}
        self.li = []
        #

    def push(self, fn_old, fn_new):
        i = self.ind
        i1 = i + 1
        history = self.history
        li = self.li
        if i1 in history:
            for r in range(len(li) - 1, -1, -1):
                if li[r] < i1: break
                del history[li[r]]
                del li[r]

        if i in history:
            history[i].append(fn_old)
        else:
            history[i] = [fn_old]
            li.append(i)
        li.append(i1)
        history[i1] = [fn_new]

        if len(history) > undo_steps:
            del history[li[0]]
            del li[0]

        self.ind += 1
        bpy.context.scene.undo_ind = self.ind