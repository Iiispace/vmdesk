from . bu_md import *

from .. bu import BURE
from .. bu import BU as bu_BU
from .. bpy_ops import VPP_BEVEL_PROFILE, VPP_FALLOFF_CURVE, VPP_SCAN_FILE

P = None
F = None
K = None
BLF = None
font_0 = None

D_DATA_TRANSFER_mix_mode = {
    "REPLACE": "Replace",
    "ABOVE_THRESHOLD": "Above Threshold",
    "BELOW_THRESHOLD": "Below Threshold",
    "MIX": "Mix",
    "ADD": "Add",
    "SUB": "Subtract",
    "MUL": "Multiply"}
D_DATA_TRANSFER_vert_mapping = {
    "TOPOLOGY": "Topology",
    "NEAREST": "Nearest Vertex",
    "EDGE_NEAREST": "Nearest Edge Vertex",
    "EDGEINTERP_NEAREST": "Nearest Edge Interpolated",
    "POLY_NEAREST": "Nearest Face Vertex",
    "POLYINTERP_NEAREST": "Nearest Face Interpolated",
    "POLYINTERP_VNORPROJ": "Projected Face Interpolated"}
D_DATA_TRANSFER_layers_vgroup_select_src = {
    "ALL": "All Layers"}
D_DATA_TRANSFER_layers_vgroup_select_dst = {
    "NAME": "By Name",
    "INDEX": "By Order"}
D_DATA_TRANSFER_edge_mapping = {
    "TOPOLOGY": "Topology",
    "VERT_NEAREST": "Nearest Vertices",
    "NEAREST": "Nearest Edge",
    "POLY_NEAREST": "Nearest Face Edge",
    "EDGEINTERP_VNORPROJ": "Projected Edge Interpolated"}
D_DATA_TRANSFER_loop_mapping = {
    "TOPOLOGY": "Topology",
    "NEAREST_NORMAL": "Nearest Corner and Best Matching Normal",
    "NEAREST_POLYNOR": "Nearest Corner and Best Matching Face Normal",
    "NEAREST_POLY": "Nearest Corner of Nearest Face",
    "POLYINTERP_NEAREST": "Nearest Face Interpolated",
    "POLYINTERP_LNORPROJ": "Projected Face Interpolated"}
D_DATA_TRANSFER_poly_mapping = {
    "TOPOLOGY": "Topology",
    "NEAREST": "Nearest Face",
    "NORMAL": "Best Normal-Matching",
    "POLYINTERP_PNORPROJ": "Projected Face Interpolated"}
D_DISPLACE_direction = {
    "X": "X",
    "Y": "Y",
    "Z": "Z",
    "NORMAL": "Normal",
    "CUSTOM_NORMAL": "Custom Normal",
    "RGB_TO_XYZ": "RGB to XYZ"}
D_HOOK_falloff_type = {
    "NONE": "No Falloff",
    "CURVE": "Curve",
    "SMOOTH": "Smooth",
    "SPHERE": "Sphere",
    "ROOT": "Root",
    "INVERSE_SQUARE": "Inverse Square",
    "SHARP": "Sharp",
    "LINEAR": "Linear",
    "CONSTANT": "Constant"}
D_MULTIRES_uv_smooth = {
    "NONE": "None",
    "PRESERVE_CORNERS": "Keep Corners",
    "PRESERVE_CORNERS_AND_JUNCTIONS": "Keep Corners, Junctions",
    "PRESERVE_CORNERS_JUNCTIONS_AND_CONCAVE": "Keep Corners, Junctions, Concave",
    "PRESERVE_BOUNDARIES": "Keep Boundaries",
    "SMOOTH_ALL": "All"}
D_OCEAN_spectrum = {
    "PHILLIPS": "Turbulent Ocean",
    "PIERSON_MOSKOWITZ": "Established Ocean",
    "JONSWAP": "Established Ocean (Sharp Peaks)",
    "TEXEL_MARSEN_ARSLOE": "Shallow Water"}
D_SHRINKWRAP_wrap_mode = {
    "ON_SURFACE": "On Surface",
    "INSIDE": "Inside",
    "OUTSIDE": "Outside",
    "OUTSIDE_SURFACE": "Outside Surface",
    "ABOVE_SURFACE": "Above Surface"}
D_SUBSURF_uv_smooth = {
    "NONE": "None",
    "PRESERVE_CORNERS": "Keep Corners",
    "PRESERVE_CORNERS_AND_JUNCTIONS": "Keep Corners, Junctions",
    "PRESERVE_CORNERS_JUNCTIONS_AND_CONCAVE": "Keep Corners, Junctions, Concave",
    "PRESERVE_BOUNDARIES": "Keep Boundaries",
    "SMOOTH_ALL": "All"}
D_TRIANGULATE_quad_method = {
    "BEAUTY": "Beauty",
    "FIXED": "Fixed",
    "FIXED_ALTERNATE": "Fixed Alternate",
    "SHORTEST_DIAGONAL": "Shortest Diagonal",
    "LONGEST_DIAGONAL": "Longest Diagonal"}
D_VERTEX_WEIGHT_EDIT_falloff_type = {
    "LINEAR": "Linear",
    "CURVE": "Custom Curve",
    "SHARP": "Sharp",
    "SMOOTH": "Smooth",
    "ROOT": "Root",
    "ICON_SPHERECURVE": "Sphere",
    "RANDOM": "Random",
    "STEP": "Median Step"}
D_VERTEX_WEIGHT_EDIT_mask_tex_use_channel = {
    "INT": "Intensity",
    "RED": "Red",
    "GREEN": "Green",
    "BLUE": "Blue",
    "HUE": "Hue",
    "SAT": "Saturation",
    "VAL": "Value",
    "ALPHA": "Alpha"}
D_VERTEX_WEIGHT_MIX_mix_set = {
    "ALL": "All",
    "A": "VGroup A",
    "B": "VGroup B",
    "OR": "VGroup A or B",
    "AND": "VGroup A and B"}
D_VERTEX_WEIGHT_MIX_mix_mode = {
    "SET": "Replace",
    "ADD": "Add",
    "SUB": "Subtract",
    "MUL": "Multiply",
    "DIV": "Divide",
    "DIF": "Difference",
    "AVG": "Average",
    "MIN": "Minimum",
    "MAX": "Maximum"}
D_VERTEX_WEIGHT_MIX_mask_tex_use_channel = {
    "INT": "Intensity",
    "RED": "Red",
    "GREEN": "Green",
    "BLUE": "Blue",
    "HUE": "Hue",
    "SAT": "Saturation",
    "VAL": "Value",
    "ALPHA": "Alpha"}
D_VERTEX_WEIGHT_PROXIMITY_falloff_type = {
    "LINEAR": "Linear",
    "CURVE": "Custom Curve",
    "SHARP": "Sharp",
    "SMOOTH": "Smooth",
    "ROOT": "Root",
    "ICON_SPHERECURVE": "Sphere",
    "RANDOM": "Random",
    "STEP": "Median Step"}
D_VERTEX_WEIGHT_PROXIMITY_mask_tex_use_channel = {
    "INT": "Intensity",
    "RED": "Red",
    "GREEN": "Green",
    "BLUE": "Blue",
    "HUE": "Hue",
    "SAT": "Saturation",
    "VAL": "Value",
    "ALPHA": "Alpha"}
D_WARP_falloff_type = {
    "NONE": "No Falloff",
    "CURVE": "Curve",
    "SMOOTH": "Smooth",
    "SPHERE": "Sphere",
    "ROOT": "Root",
    "INVERSE_SQUARE": "Inverse Square",
    "SHARP": "Sharp",
    "LINEAR": "Linear",
    "CONSTANT": "Constant"}

VD_local_world = {
    "LOCAL": 1,
    "WORLD": 0}
VD_XYZ = {
    "X": 0,
    "Y": 1,
    "Z": 2}
VD_Object_display_type = {
    "BOUNDS": 1,
    "WIRE": 2,
    "SOLID": 3,
    "TEXTURED": 5}

VD_ARRAY_fit_type = {
    "FIXED_COUNT": 0,
    "FIT_LENGTH": 1,
    "FIT_CURVE": 2}
VD_BEVEL_affect = {
    "VERTICES": 0,
    "EDGES": 1}
VD_BEVEL_face_strength_mode = {
    "FSTR_NONE": 0,
    "FSTR_NEW": 1,
    "FSTR_AFFECTED": 2,
    "FSTR_ALL": 3}
VD_BEVEL_limit_method = {
    "NONE": 0,
    "ANGLE": 8,
    "WEIGHT": 16,
    "VGROUP": 32}
VD_BEVEL_miter_inner = {
    "MITER_SHARP": 0,
    "MITER_ARC": 2}
VD_BEVEL_miter_outer = {
    "MITER_SHARP": 0,
    "MITER_PATCH": 1,
    "MITER_ARC": 2}
VD_BEVEL_offset_type = {
    "OFFSET": 0,
    "WIDTH": 1,
    "DEPTH": 2,
    "PERCENT": 3,
    "ABSOLUTE": 4}
VD_BEVEL_profile_type = {
    "SUPERELLIPSE": 0,
    "CUSTOM": 1}
VD_BEVEL_vmesh_method = {
    "ADJ": 0,
    "CUTOFF": 1}
VD_BOOLEAN_operand_type = {
    "OBJECT": 2,
    "COLLECTION": 4}
VD_BOOLEAN_operation = {
    "INTERSECT": 0,
    "UNION": 1,
    "DIFFERENCE": 2}
VD_BOOLEAN_solver = {
    "FAST": 0,
    "EXACT": 1}
VD_BOOLEAN_material_mode = {
    "INDEX": 0,
    "TRANSFER": 1}
VD_CAST_cast_type = {
    "SPHERE": 0,
    "CYLINDER": 1,
    "CUBOID": 2}
VD_CORRECTIVE_SMOOTH_rest_source = {
    "ORCO": 0,
    "BIND": 1}
VD_CORRECTIVE_SMOOTH_smooth_type = {
    "SIMPLE": 0,
    "LENGTH_WEIGHTED": 1}
VD_CURVE_deform_axis = {
    "POS_X": 1,
    "POS_Y": 2,
    "POS_Z": 3,
    "NEG_X": 4,
    "NEG_Y": 5,
    "NEG_Z": 6}
VD_DATA_TRANSFER_mix_mode = {
    "REPLACE": 0,
    "ABOVE_THRESHOLD": 1,
    "BELOW_THRESHOLD": 2,
    "MIX": 16,
    "ADD": 17,
    "SUB": 18,
    "MUL": 19}
VD_DATA_TRANSFER_data_types_verts = {
    frozenset_empty: 0,
    frozenset({'VGROUP_WEIGHTS'}): 1,
    frozenset({'BEVEL_WEIGHT_VERT'}): 8,
    frozenset({'VCOL'}): 134283264,
    frozenset({'VCOL', 'VGROUP_WEIGHTS'}): 134283264,
    frozenset({'BEVEL_WEIGHT_VERT', 'VCOL'}): 134283264,
    frozenset({'BEVEL_WEIGHT_VERT', 'VGROUP_WEIGHTS'}): 9,
    frozenset({'BEVEL_WEIGHT_VERT', 'VCOL', 'VGROUP_WEIGHTS'}): 134283280}
VD_DATA_TRANSFER_data_types_verts_3_5 = {
    frozenset_empty: 0,
    frozenset({'VGROUP_WEIGHTS'}): 1,
    frozenset({'BEVEL_WEIGHT_VERT'}): 8,
    frozenset({'COLOR_VERTEX'}): 134283264,
    frozenset({'COLOR_VERTEX', 'VGROUP_WEIGHTS'}): 134283264,
    frozenset({'COLOR_VERTEX', 'BEVEL_WEIGHT_VERT'}): 134283264,
    frozenset({'BEVEL_WEIGHT_VERT', 'VGROUP_WEIGHTS'}): 9,
    frozenset({'COLOR_VERTEX', 'BEVEL_WEIGHT_VERT', 'VGROUP_WEIGHTS'}): 134283280}
VD_DATA_TRANSFER_vert_mapping = {
    "TOPOLOGY": 251658240,
    "NEAREST": 16777488,
    "EDGE_NEAREST": 16777504,
    "EDGEINTERP_NEAREST": 16778528,
    "POLY_NEAREST": 16777600,
    "POLYINTERP_NEAREST": 16778624,
    "POLYINTERP_VNORPROJ": 16778880}
VD_DATA_TRANSFER_layers_vgroup_select_src = {
    "ACTIVE": -1,
    "ALL": -2,
    "BONE_SELECT": -3,
    "BONE_DEFORM": -4}
VD_DATA_TRANSFER_layers_vgroup_select_dst = {
    "ACTIVE": -1,
    "NAME": -2,
    "INDEX": -3}
VD_DATA_TRANSFER_data_types_edges = {
    frozenset_empty: 1,
    frozenset({'SHARP_EDGE'}): 257,
    frozenset({'SEAM'}): 513,
    frozenset({'CREASE'}): 1025,
    frozenset({'BEVEL_WEIGHT_EDGE'}): 2049,
    frozenset({'FREESTYLE_EDGE'}): 4097,
    frozenset({'SHARP_EDGE', 'SEAM'}): 769,
    frozenset({'CREASE', 'SHARP_EDGE'}): 1281,
    frozenset({'SHARP_EDGE', 'BEVEL_WEIGHT_EDGE'}): 2305,
    frozenset({'SHARP_EDGE', 'FREESTYLE_EDGE'}): 4353,
    frozenset({'CREASE', 'SEAM'}): 1537,
    frozenset({'BEVEL_WEIGHT_EDGE', 'SEAM'}): 2561,
    frozenset({'SEAM', 'FREESTYLE_EDGE'}): 4609,
    frozenset({'CREASE', 'BEVEL_WEIGHT_EDGE'}): 3073,
    frozenset({'CREASE', 'FREESTYLE_EDGE'}): 5121,
    frozenset({'BEVEL_WEIGHT_EDGE', 'FREESTYLE_EDGE'}): 6145,
    frozenset({'CREASE', 'SHARP_EDGE', 'SEAM'}): 1793,
    frozenset({'SHARP_EDGE', 'BEVEL_WEIGHT_EDGE', 'SEAM'}): 2817,
    frozenset({'SHARP_EDGE', 'SEAM', 'FREESTYLE_EDGE'}): 4865,
    frozenset({'CREASE', 'SHARP_EDGE', 'BEVEL_WEIGHT_EDGE'}): 3329,
    frozenset({'CREASE', 'SHARP_EDGE', 'FREESTYLE_EDGE'}): 5377,
    frozenset({'SHARP_EDGE', 'BEVEL_WEIGHT_EDGE', 'FREESTYLE_EDGE'}): 6401,
    frozenset({'CREASE', 'BEVEL_WEIGHT_EDGE', 'SEAM'}): 3585,
    frozenset({'CREASE', 'SEAM', 'FREESTYLE_EDGE'}): 5633,
    frozenset({'BEVEL_WEIGHT_EDGE', 'SEAM', 'FREESTYLE_EDGE'}): 6657,
    frozenset({'CREASE', 'BEVEL_WEIGHT_EDGE', 'FREESTYLE_EDGE'}): 7169,
    frozenset({'CREASE', 'SHARP_EDGE', 'BEVEL_WEIGHT_EDGE', 'SEAM'}): 3841,
    frozenset({'CREASE', 'SHARP_EDGE', 'SEAM', 'FREESTYLE_EDGE'}): 5889,
    frozenset({'SHARP_EDGE', 'BEVEL_WEIGHT_EDGE', 'SEAM', 'FREESTYLE_EDGE'}): 6913,
    frozenset({'CREASE', 'SHARP_EDGE', 'BEVEL_WEIGHT_EDGE', 'FREESTYLE_EDGE'}): 7425,
    frozenset({'CREASE', 'BEVEL_WEIGHT_EDGE', 'SEAM', 'FREESTYLE_EDGE'}): 7681,
    frozenset({'BEVEL_WEIGHT_EDGE', 'SEAM', 'SHARP_EDGE', 'CREASE', 'FREESTYLE_EDGE'}): 7937}
VD_DATA_TRANSFER_edge_mapping = {
    "TOPOLOGY": 251658240,
    "VERT_NEAREST": 33554704,
    "NEAREST": 33554720,
    "POLY_NEAREST": 33554816,
    "EDGEINTERP_VNORPROJ": 33555984}
VD_DATA_TRANSFER_data_types_loops = {
    frozenset_empty: 0,
    frozenset({'CUSTOM_NORMAL'}): 131072,
    frozenset({'VCOL'}): 805306368,
    frozenset({'UV'}): 16777216,
    frozenset({'VCOL', 'CUSTOM_NORMAL'}): 805437440,
    frozenset({'UV', 'CUSTOM_NORMAL'}): 16908288,
    frozenset({'UV', 'VCOL'}): 822083584,
    frozenset({'UV', 'VCOL', 'CUSTOM_NORMAL'}): 822214656}
VD_DATA_TRANSFER_data_types_loops_3_5 = {
    frozenset_empty: 0,
    frozenset({'CUSTOM_NORMAL'}): 131072,
    frozenset({'COLOR_CORNER'}): 805306368,
    frozenset({'UV'}): 16777216,
    frozenset({'COLOR_CORNER', 'CUSTOM_NORMAL'}): 805437440,
    frozenset({'UV', 'CUSTOM_NORMAL'}): 16908288,
    frozenset({'COLOR_CORNER', 'UV'}): 822083584,
    frozenset({'COLOR_CORNER', 'UV', 'CUSTOM_NORMAL'}): 822214656}
VD_DATA_TRANSFER_loop_mapping = {
    "TOPOLOGY": 251658240,
    "NEAREST_NORMAL": 67111248,
    "NEAREST_POLYNOR": 67111312,
    "NEAREST_POLY": 67109248,
    "POLYINTERP_NEAREST": 67110272,
    "POLYINTERP_LNORPROJ": 67110528}
VD_DATA_TRANSFER_data_types_polys = {
    frozenset_empty: 0,
    frozenset({'SMOOTH'}): 33554432,
    frozenset({'FREESTYLE_FACE'}): 67108864,
    frozenset({'FREESTYLE_FACE', 'SMOOTH'}): 100663296}
VD_DATA_TRANSFER_poly_mapping = {
    "TOPOLOGY": 251658240,
    "NEAREST": 134218112,
    "NORMAL": 134219904,
    "POLYINTERP_PNORPROJ": 134219392}
VD_DECIMATE_decimate_type = {
    "COLLAPSE": 0,
    "UNSUBDIV": 1,
    "DISSOLVE": 2}
VD_DECIMATE_delimit = {
    frozenset_empty: 0,
    frozenset({'NORMAL'}): 1,
    frozenset({'MATERIAL'}): 2,
    frozenset({'SEAM'}): 4,
    frozenset({'SHARP'}): 8,
    frozenset({'UV'}): 16,
    frozenset({'MATERIAL', 'NORMAL'}): 3,
    frozenset({'NORMAL', 'SEAM'}): 5,
    frozenset({'NORMAL', 'SHARP'}): 9,
    frozenset({'UV', 'NORMAL'}): 17,
    frozenset({'MATERIAL', 'SEAM'}): 6,
    frozenset({'MATERIAL', 'SHARP'}): 10,
    frozenset({'UV', 'MATERIAL'}): 18,
    frozenset({'SEAM', 'SHARP'}): 12,
    frozenset({'UV', 'SEAM'}): 20,
    frozenset({'UV', 'SHARP'}): 24,
    frozenset({'MATERIAL', 'NORMAL', 'SEAM'}): 7,
    frozenset({'MATERIAL', 'NORMAL', 'SHARP'}): 11,
    frozenset({'UV', 'MATERIAL', 'NORMAL'}): 19,
    frozenset({'NORMAL', 'SEAM', 'SHARP'}): 13,
    frozenset({'UV', 'NORMAL', 'SEAM'}): 21,
    frozenset({'UV', 'NORMAL', 'SHARP'}): 25,
    frozenset({'MATERIAL', 'SEAM', 'SHARP'}): 14,
    frozenset({'UV', 'MATERIAL', 'SEAM'}): 22,
    frozenset({'UV', 'MATERIAL', 'SHARP'}): 26,
    frozenset({'UV', 'SEAM', 'SHARP'}): 28,
    frozenset({'MATERIAL', 'NORMAL', 'SEAM', 'SHARP'}): 15,
    frozenset({'UV', 'MATERIAL', 'NORMAL', 'SEAM'}): 23,
    frozenset({'UV', 'MATERIAL', 'NORMAL', 'SHARP'}): 27,
    frozenset({'UV', 'NORMAL', 'SEAM', 'SHARP'}): 29,
    frozenset({'UV', 'MATERIAL', 'SEAM', 'SHARP'}): 30,
    frozenset({'SHARP', 'NORMAL', 'SEAM', 'UV', 'MATERIAL'}): 31}
VD_DISPLACE_texture_coords = {
    "LOCAL": 0,
    "GLOBAL": 1,
    "OBJECT": 2,
    "UV": 3}
VD_DISPLACE_direction = {
    "X": 0,
    "Y": 1,
    "Z": 2,
    "NORMAL": 3,
    "CUSTOM_NORMAL": 5,
    "RGB_TO_XYZ": 4}
VD_DISPLACE_space = {
    "LOCAL": 0,
    "GLOBAL": 1}
VD_HOOK_falloff_type = {
    "NONE": 0,
    "CURVE": 1,
    "SMOOTH": 3,
    "SPHERE": 7,
    "ROOT": 4,
    "INVERSE_SQUARE": 8,
    "SHARP": 2,
    "LINEAR": 5,
    "CONSTANT": 6}
VD_MASK_mode = {
    "VERTEX_GROUP": 0,
    "ARMATURE": 1}
VD_MESH_CACHE_cache_format = {
    "MDD": 1,
    "PC2": 2}
VD_MESH_CACHE_deform_mode = {
    "OVERWRITE": 0,
    "INTEGRATE": 1}
VD_MESH_CACHE_interpolation = {
    "NONE": 0,
    "LINEAR": 1}
VD_MESH_CACHE_time_mode = {
    "FRAME": 0,
    "TIME": 1,
    "FACTOR": 2}
VD_MESH_CACHE_play_mode = {
    "SCENE": 0,
    "CUSTOM": 1}
VD_MESH_CACHE_forward_axis = {
    "POS_X": 0,
    "POS_Y": 1,
    "POS_Z": 2,
    "NEG_X": 3,
    "NEG_Y": 4,
    "NEG_Z": 5}
VD_MESH_CACHE_up_axis = {
    "POS_X": 0,
    "POS_Y": 1,
    "POS_Z": 2,
    "NEG_X": 3,
    "NEG_Y": 4,
    "NEG_Z": 5}
VD_MESH_CACHE_flip_axis = {
    frozenset_empty: 0,
    frozenset({'X'}): 1,
    frozenset({'Y'}): 2,
    frozenset({'Z'}): 4,
    frozenset({'X', 'Y'}): 3,
    frozenset({'X', 'Z'}): 5,
    frozenset({'Y', 'Z'}): 6,
    frozenset({'X', 'Z', 'Y'}): 7}
VD_MESH_SEQUENCE_CACHE_read_data = {
    frozenset_empty: 0,
    frozenset({'VERT'}): 1,
    frozenset({'POLY'}): 2,
    frozenset({'UV'}): 4,
    frozenset({'COLOR'}): 8,
    frozenset({'VERT', 'POLY'}): 3,
    frozenset({'VERT', 'UV'}): 5,
    frozenset({'VERT', 'COLOR'}): 9,
    frozenset({'POLY', 'UV'}): 6,
    frozenset({'POLY', 'COLOR'}): 10,
    frozenset({'UV', 'COLOR'}): 12,
    frozenset({'UV', 'VERT', 'POLY'}): 7,
    frozenset({'VERT', 'POLY', 'COLOR'}): 11,
    frozenset({'VERT', 'UV', 'COLOR'}): 13,
    frozenset({'POLY', 'UV', 'COLOR'}): 14,
    frozenset({'UV', 'VERT', 'POLY', 'COLOR'}): 15}
VD_CacheFile_up_axis = {
    "POS_X": 0,
    "POS_Y": 1,
    "POS_Z": 2,
    "NEG_X": 3,
    "NEG_Y": 4,
    "NEG_Z": 5}
VD_CacheFile_forward_axis = {
    "POS_X": 0,
    "POS_Y": 1,
    "POS_Z": 2,
    "NEG_X": 3,
    "NEG_Y": 4,
    "NEG_Z": 5}
VD_MULTIRES_uv_smooth = {
    "NONE": 0,
    "PRESERVE_CORNERS": 1,
    "PRESERVE_CORNERS_AND_JUNCTIONS": 2,
    "PRESERVE_CORNERS_JUNCTIONS_AND_CONCAVE": 3,
    "PRESERVE_BOUNDARIES": 4,
    "SMOOTH_ALL": 5}
VD_MULTIRES_boundary_smooth = {
    "PRESERVE_CORNERS": 1,
    "ALL": 0}
VD_NORMAL_EDIT_mode = {
    "RADIAL": 0,
    "DIRECTIONAL": 1}
VD_NORMAL_EDIT_mix_mode = {
    "COPY": 0,
    "ADD": 1,
    "SUB": 2,
    "MUL": 3}
VD_OCEAN_geometry_mode = {
    "GENERATE": 0,
    "DISPLACE": 1}
VD_REMESH_mode = {
    "BLOCKS": 0,
    "SMOOTH": 1,
    "SHARP": 2,
    "VOXEL": 3}
VD_SHRINKWRAP_wrap_method = {
    "NEAREST_SURFACEPOINT": 0,
    "PROJECT": 1,
    "NEAREST_VERTEX": 2,
    "TARGET_PROJECT": 3}
VD_SHRINKWRAP_wrap_mode = {
    "ON_SURFACE": 0,
    "INSIDE": 1,
    "OUTSIDE": 2,
    "OUTSIDE_SURFACE": 3,
    "ABOVE_SURFACE": 4}
VD_SHRINKWRAP_cull_face = {
    "OFF": 0,
    "FRONT": 8,
    "BACK": 16}
VD_SIMPLE_DEFORM_deform_method = {
    "TWIST": 1,
    "BEND": 2,
    "TAPER": 3,
    "STRETCH": 4}
VD_SOLIDIFY_solidify_mode = {
    "EXTRUDE": 0,
    "NON_MANIFOLD": 1}
VD_SOLIDIFY_nonmanifold_thickness_mode = {
    "FIXED": 0,
    "EVEN": 1,
    "CONSTRAINTS": 2}
VD_SOLIDIFY_nonmanifold_boundary_mode = {
    "NONE": 0,
    "ROUND": 1,
    "FLAT": 2}
VD_SUBSURF_subdivision_type = {
    "CATMULL_CLARK": 0,
    "SIMPLE": 1}
VD_SUBSURF_uv_smooth = {
    "NONE": 0,
    "PRESERVE_CORNERS": 1,
    "PRESERVE_CORNERS_AND_JUNCTIONS": 2,
    "PRESERVE_CORNERS_JUNCTIONS_AND_CONCAVE": 3,
    "PRESERVE_BOUNDARIES": 4,
    "SMOOTH_ALL": 5}
VD_SUBSURF_boundary_smooth = {
    "PRESERVE_CORNERS": 1,
    "ALL": 0}
VD_TRIANGULATE_quad_method = {
    "BEAUTY": 0,
    "FIXED": 1,
    "FIXED_ALTERNATE": 2,
    "SHORTEST_DIAGONAL": 3,
    "LONGEST_DIAGONAL": 4}
VD_TRIANGULATE_ngon_method = {
    "BEAUTY": 0,
    "CLIP": 1}
VD_VERTEX_WEIGHT_EDIT_falloff_type = {
    "LINEAR": 0,
    "CURVE": 1,
    "SHARP": 2,
    "SMOOTH": 3,
    "ROOT": 4,
    "ICON_SPHERECURVE": 7,
    "RANDOM": 8,
    "STEP": 9}
VD_VERTEX_WEIGHT_EDIT_mask_tex_use_channel = {
    "INT": 1,
    "RED": 2,
    "GREEN": 3,
    "BLUE": 4,
    "HUE": 5,
    "SAT": 6,
    "VAL": 7,
    "ALPHA": 8}
VD_VERTEX_WEIGHT_EDIT_mask_tex_mapping = {
    "LOCAL": 0,
    "GLOBAL": 1,
    "OBJECT": 2,
    "UV": 3}
VD_VERTEX_WEIGHT_MIX_mix_set = {
    "ALL": 1,
    "A": 2,
    "B": 3,
    "OR": 4,
    "AND": 5}
VD_VERTEX_WEIGHT_MIX_mix_mode = {
    "SET": 1,
    "ADD": 2,
    "SUB": 3,
    "MUL": 4,
    "DIV": 5,
    "DIF": 6,
    "AVG": 7,
    "MIN": 8,
    "MAX": 9}
VD_VERTEX_WEIGHT_MIX_mask_tex_use_channel = {
    "INT": 1,
    "RED": 2,
    "GREEN": 3,
    "BLUE": 4,
    "HUE": 5,
    "SAT": 6,
    "VAL": 7,
    "ALPHA": 8}
VD_VERTEX_WEIGHT_MIX_mask_tex_mapping = {
    "LOCAL": 0,
    "GLOBAL": 1,
    "OBJECT": 2,
    "UV": 3}
VD_VERTEX_WEIGHT_PROXIMITY_proximity_mode = {
    "OBJECT": 1,
    "GEOMETRY": 2}
VD_VERTEX_WEIGHT_PROXIMITY_proximity_geometry = {
    frozenset_empty: 0,
    frozenset({'VERTEX'}): 1,
    frozenset({'EDGE'}): 2,
    frozenset({'FACE'}): 4,
    frozenset({'VERTEX', 'EDGE'}): 3,
    frozenset({'VERTEX', 'FACE'}): 5,
    frozenset({'FACE', 'EDGE'}): 6,
    frozenset({'FACE', 'VERTEX', 'EDGE'}): 7}
VD_VERTEX_WEIGHT_PROXIMITY_falloff_type = {
    "LINEAR": 0,
    "CURVE": 1,
    "SHARP": 2,
    "SMOOTH": 3,
    "ROOT": 4,
    "ICON_SPHERECURVE": 7,
    "RANDOM": 8,
    "STEP": 9}
VD_VERTEX_WEIGHT_PROXIMITY_mask_tex_use_channel = {
    "INT": 1,
    "RED": 2,
    "GREEN": 3,
    "BLUE": 4,
    "HUE": 5,
    "SAT": 6,
    "VAL": 7,
    "ALPHA": 8}
VD_VERTEX_WEIGHT_PROXIMITY_mask_tex_mapping = {
    "LOCAL": 0,
    "GLOBAL": 1,
    "OBJECT": 2,
    "UV": 3}
VD_VOLUME_TO_MESH_resolution_mode = {
    "GRID": 0,
    "VOXEL_AMOUNT": 1,
    "VOXEL_SIZE": 2}
VD_WARP_falloff_type = {
    "NONE": 0,
    "CURVE": 1,
    "SMOOTH": 3,
    "SPHERE": 7,
    "ROOT": 4,
    "INVERSE_SQUARE": 8,
    "SHARP": 2,
    "LINEAR": 5,
    "CONSTANT": 6}
VD_WARP_texture_coords = {
    "LOCAL": 0,
    "GLOBAL": 1,
    "OBJECT": 2,
    "UV": 3}
VD_WAVE_texture_coords = {
    "LOCAL": 0,
    "GLOBAL": 1,
    "OBJECT": 2,
    "UV": 3}
VD_WEIGHTED_NORMAL_mode = {
    "FACE_AREA": 0,
    "CORNER_ANGLE": 1,
    "FACE_AREA_WITH_ANGLE": 2}
VD_WELD_mode = {
    "ALL": 0,
    "CONNECTED": 1}


def R_md_dp(name, attr):    return f'modifiers["{name}"].{attr}'
def R_driver(ob, full_path):
    if ob.animation_data:   return ob.animation_data.drivers.find(full_path)
    return None


class BU_SET:
    __slots__ = 'li', 'enum', 'amt', 'dic_val_bu', 'attr'
    def __init__(self, li_bu, enum):
        self.li = li_bu
        self.enum = enum
        self.amt = len(li_bu)
        self.dic_val_bu = {b.value : b  for b in li_bu}
        self.attr = li_bu[0].attr
        #
    def enable(self):
        if self.li[0].is_enable is True: return
        for e in self.li: e.enable()
    def disable(self):
        if self.li[0].is_enable is False: return
        for e in self.li: e.disable()

class MD:
    __slots__ = (
        'w',
        'cv',
        'RET',
        'sci',
        'U_draw',
        'U_modal',
        'default_modal',
        'oo',
        'line',
        'oo_22',
        'oo_9',
        'oo_free',
        'oo_kf',
        'oo_dr',
        'bu_sets',
        'props',
        'pick_data',
        'key_end',
    )
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.sci            = m.SCISSOR()
        self.upd_sci()
        self.oo_kf          = {}
        self.oo_dr          = {}
        self.props          = w.act_md.bl_rna.properties
        self.init()

    def upd_sci(self):
        sci = self.sci
        wsci = self.w.sci
        _2 = F[2]
        md_info = self.w.bo["md_info"]

        sci.x = max(wsci.x, md_info.L)
        sci.w = max(0, min(md_info.R - _2, wsci.x + wsci.w) - sci.x)
        sci.y = max(md_info.B + _2, wsci.y)
        sci.h = max(0, min(md_info.T, wsci.y + wsci.h) - sci.y)
    def to_default_modal(self):
        self.U_modal = self.I_modal_main
    def get_oo(self, line):
        oo      = {}
        self.oo = oo

        for e in line:
            for o in e:     oo[o.name] = o

    def change_kfdr_attr(self, old_attr, new_attr, ti):
        oo_kf = self.oo_kf
        oo_dr = self.oo_dr
        kf = oo_kf.pop(old_attr)
        dr = oo_dr.pop(old_attr)
        kf.attr = new_attr
        dr.attr = new_attr
        dr.ti.text = ti
        oo_kf[new_attr] = kf
        oo_dr[new_attr] = dr
        return kf, dr
    def replace_oo_9(self, oo, old, new, k, l0, l1):
        self.oo_9.remove(old)
        self.oo_9.add(new)
        oo[k] = new
        self.line[l0][l1] = new
    def replace_oo_9_22(self, oo, old, new, k, l0, l1):
        self.oo_9.remove(old)
        self.oo_22.add(new)
        oo[k] = new
        self.line[l0][l1] = new
    def replace_oo_22_9(self, oo, old, new, k, l0, l1):
        self.oo_22.remove(old)
        self.oo_9.add(new)
        oo[k] = new
        self.line[l0][l1] = new
    def add_oo_free(self, oo, new, k, l0):
        self.oo_free.add(new)
        self.oo[k] = new
        self.line[l0].append(new)
    def del_oo_free(self, oo, new, k, l0, l1):
        self.oo_free.remove(new)
        del self.oo[k]
        del self.line[l0][l1]
    def add_oo_9(self, oo, new, k, l0):
        self.oo_9.add(new)
        self.oo[k] = new
        self.line[l0].append(new)
    def del_oo_9(self, oo, new, k, l0, l1):
        self.oo_9.remove(new)
        del self.oo[k]
        del self.line[l0][l1]
    def ops_wrapper(self, func, undo_str=None, power_upd=True, is_try=True):
        if bpy.context.object != self.w.oj:
            old_oj = bpy.context.object
            m.set_active_object(self.w.oj)
            if is_try:
                try:    func()
                except Exception as e: m.admin.report({'WARNING'}, f'{e}')
            else:
                func()
            m.set_active_object(old_oj)
        else:
            if is_try:
                try:    func()
                except Exception as e: m.admin.report({'WARNING'}, f'{e}')
            else:
                func()

        if undo_str is not None:
            m.undo_str = undo_str
            m.undo_push()
        if power_upd:   m.power_upd()
        m.refresh()

    def upd_color(self, an_data, act_md):
        for bu_set in self.bu_sets:
            v = getattr(act_md, bu_set.attr)
            if isinstance(v, set):
                for e in bu_set.li:
                    e.on()  if e.value in v else e.off()
            else:
                for e in bu_set.li:
                    e.on()  if e.value == v else e.off()

        for e in self.oo_kf.values():   e.upd_ti(an_data, act_md)
        for e in self.oo_dr.values():   e.upd_dr(an_data, act_md)
    def upd_ref_color(self, an_data, act_md, oo, l):
        if an_data:
            drivers = an_data.drivers
            if drivers:
                name = act_md.name
                for k_bu, attr in l:
                    if drivers.find(f'["modifiers[{name}].{attr}"]') is None:
                        oo[k_bu].ti.color = P.color_font
                    else:
                        oo[k_bu].ti.color = P.color_bu_dr
                return

        for k_bu, attr in l: oo[k_bu].ti.color = P.color_font
    def upd_ti_user(self, o, n, R):
        o.name = n
        o.text = f"User :  {n}" if n in {0, 1} else f"Users :  {n}"
        o.set_size()
        o.align_R_float(R)

    def dxy_upd(self, x, y):
        self.cv.dxy_upd(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)

    def I_modal_main(self, evt):
        self.RET = False
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        for ee in self.line:
            if ee[0].rim.T < y: break
            if ee[0].rim.B <= y:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        break
                break

        return self.RET

    def to_modal_pan(self, evt):
        m.redraw()
        self.key_end.true()
        m.head_modal.append(self.I_modal_pan)
        m.U_pan_cursor(self, evt)
        rim = self.w.resize_rim
        m.get_loop_mou_info_region(evt, rim.L, rim.R, rim.B, rim.T)
        m.get_mou(evt)

        sci = self.sci
        global tm_L, tm_R, tm_B, tm_T
        tm_L = sci.x
        tm_R = sci.w + tm_L
        tm_B = sci.y
        tm_T = sci.h + tm_B
        #
    def modal_pan_end(self):
#
        del m.head_modal[-1]
        m.U_end_pan(self)
        m.init_wait_release()
        #
    def I_modal_pan(self, evt):
        m.redraw()
        if evt.type == 'ESC' and evt.value == 'RELEASE':
            self.modal_pan_end()
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_pan_end()
                return

        m.U_pan(evt)
        cv = self.cv

        if m.dy < 0:
            new_T = max(cv.T + m.dy, tm_T)
            dy = new_T - cv.T
        else:
            new_B = min(cv.B + m.dy, tm_B)
            dy = new_B - cv.B

        if m.dx < 0:
            new_R = max(cv.R + m.dx, tm_R)
            dx = new_R - cv.R
        else:
            new_L = min(cv.L + m.dx, tm_L)
            dx = new_L - cv.L

        self.dxy_upd(dx, dy)

        m.loop_mou(evt)

    def I_draw(self):
        self.sci.use()
        self.cv.bind_draw()

        for e in self.oo.values():   e.draw_bg()

        blf_size(font_0, F[22])
        for e in self.oo_22:    e.draw_ti()

        blf_size(font_0, F[9])
        for e in self.oo_9:     e.draw_ti()

        for e in self.oo_free:  e.draw_ti()
    #
    #
class MD2(MD):
    __slots__ = 'line2', 'oo2', 'is_oo2', 'bu_sets2', 'oo_kf2', 'oo_dr2', 'oo2_free', 'oo2_9', 'oo2_22', 'props2'
    def dxy_upd(self, x, y):
        self.cv.dxy_upd(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)

        if self.is_oo2 is False: return

        for e in self.oo2.values():  e.dxy_upd(x, y)
        #
    def upd_color2(self, an_data, obj):
        for bu_set in self.bu_sets2:
            v = getattr(obj, bu_set.attr[1])
            if isinstance(v, set):
                for e in bu_set.li:
                    e.on()  if e.value in v else e.off()
            else:
                for e in bu_set.li:
                    e.on()  if e.value == v else e.off()

        for e in self.oo_kf2.values():   e.upd_ti(an_data, obj)
        for e in self.oo_dr2.values():   e.upd_dr(an_data)
        #
    def I_modal_main(self, evt):
        self.RET = False
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        for ee in self.line:
            if ee[0].rim.T < y: break
            if ee[0].rim.B <= y:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        return self.RET
                break

        if self.is_oo2 is False: return

        for ee in self.line2:
            if ee[0].rim.T < y: break
            if ee[0].rim.B <= y:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        break
                break

        return self.RET
        #
    def I_draw(self):
        self.sci.use()
        self.cv.bind_draw()

        for e in self.oo.values():   e.draw_bg()
        if self.is_oo2 is True:
            for e in self.oo2.values():   e.draw_bg()

        blf_size(font_0, F[22])
        for e in self.oo_22:    e.draw_ti()

        blf_size(font_0, F[9])
        for e in self.oo_9:     e.draw_ti()

        for e in self.oo_free:  e.draw_ti()

        if self.is_oo2 is False: return

        blf_size(font_0, F[22])
        for e in self.oo2_22:    e.draw_ti()

        blf_size(font_0, F[9])
        for e in self.oo2_9:     e.draw_ti()

        for e in self.oo2_free:  e.draw_ti()
    #
    #
class PICK_OBJ:
    __slots__ = ()
    def init_pick_data(self, tx_object="tx_object", allow_type=None, exc_name=None):
        self.pick_data = {
            "tx_object":    tx_object,
            "allow_type":   allow_type,
            "exc_name":     exc_name,
        }
    def modal_pick_end(self):
#
        m.R_pick_obj_end(bpy.context)
        del m.head_modal[-1]
        m.M.set_mou_ic('DEFAULT')
        m.draw_enable()
        m.EVT.kill()
        m.redraw()
        #
    def modal_pick_confirm(self):
#
        self.modal_pick_end()
        da = self.pick_data["blf"]
        if da.text != self.w.oj.name:
            o = self.oo[self.pick_data["tx_object"]]
            o.bpy_setter(da.text)
            o.setter()
        #
    def I_modal_pick(self, evt):
        m.redraw()
        if K["pk_cancel0"].true():  self.modal_pick_end()   ;return
        if K["pk_cancel1"].true():  self.modal_pick_end()   ;return
        if K["pk_confirm0"].true():
            if K["pk_confirm0"].value != 'PRESS' or evt.value == 'PRESS':
                self.modal_pick_confirm()
                return
        if K["pk_confirm1"].true():
            if K["pk_confirm1"].value != 'PRESS' or evt.value == 'PRESS':
                self.modal_pick_confirm()
                return

        ob = m.R_pick_obj(bpy.context)
        da = self.pick_data["blf"]
        da.x = evt.mouse_region_x + 25
        da.y = evt.mouse_region_y + 10
        if ob is None:
            da.text = ""
        else:
            da.text = ob.name
            if self.pick_data["allow_type"] is None:
                da.color = P.color_font
            else:
                da.color = P.color_font  if ob.type in self.pick_data["allow_type"] else P.color_font_red

            if self.pick_data["exc_name"] is True:
                if da.text == self.w.oj.name:
                    da.color = P.color_font_red
        #
    def bu_fn_pick(self):
#
        m.M.set_mou_ic('EYEDROPPER')
        m.draw_disable(self.I_draw_pick)
        m.head_modal.append(self.I_modal_pick)
        m.R_pick_obj_init(bpy.context)
        self.pick_data["blf"] = BLF(P.color_font, "", F[12])
        m.redraw()
        #
    def I_draw_pick(self):
        self.pick_data["blf"].set_draw()


class NONE:
    __slots__ = 'w', 'U_draw', 'U_modal', 'default_modal', 'cv', 'sci'
    def __init__(self, w):
        self.w              = w
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        bo_md_info          = w.bo["md_info"]
        _2 = F[2]
        self.cv = m.CANVAS_Y(P.color_mded_data_bg, bo_md_info.L, bo_md_info.R - _2, bo_md_info.B + _2, bo_md_info.T)
        self.cv.upd()
        self.sci = m.SCISSOR()
    def init(self): pass
    def upd_sci(self): pass
    def dxy_upd(self, x, y): self.cv.dxy_upd(x, y)
    def I_draw(self): self.cv.bind_draw()
    def upd_data(self): pass
    def I_modal_main(self, evt): pass
    def to_modal_pan(self, evt): pass
    def R_type(self):   return "None"
class NEW(MD):
    __slots__ = ()
    def init(self, text="Coming soon."):
        w = self.w
        _2 = F[2]
        oo = {
            "mess0": BLF(P.color_font, size= F[12], text=text),
        }
        self.oo = oo

        bo_md_info = w.bo["md_info"]
        x   = bo_md_info.L
        y   = bo_md_info.T
        cv  = m.CANVAS_Y(P.color_mded_data_bg, x, bo_md_info.R - _2, bo_md_info.B + _2, y)
        self.cv = cv
        dy  = F[18]
        e = oo["mess0"]
        blf_size(font_0, F[12])
        L = x + F[10]
        B = y - F[22]
        e.xy(L, B)
        cv.upd()
    def I_draw(self):
        self.sci.use()
        self.cv.bind_draw()
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.w.bo["md_info"].R_w() - F[14])
        self.oo["mess0"].set_draw()
        blf_disable(font_0, WORD_WRAP)
    def dxy_upd(self, x, y):
        self.cv.dxy_upd(x, y)
        self.oo["mess0"].dxy(x, y)
    def upd_data(self): pass
    def I_modal_main(self, evt): return False

class ARMATURE(MD, PICK_OBJ):
    __slots__ = ()
    def init(self):
        w = self.w
        line = [
            [
                BUDR(self, "dr_object", "Object", "object", is_ref_driver=True),
                BUTX(self, "tx_object", "object", FIL_TYPE_EXC("bpy.data.objects", "ARMATURE"), fns={"x": self.bu_fn_x, "pick": self.bu_fn_pick})],
            [
                BUDR(self, "dr_vertex_group", "Vertex Group", "vertex_group", is_ref_driver=True),
                BUTX(self, "tx_vertex_group", "vertex_group", FIL(None), is_str=True, update_filter="self.w.w.oj.vertex_groups", fns={"x": self.bu_fn_x_vg})],
            [
                BUKF(self, "kf_invert_vertex_group", "invert_vertex_group", False),
                BUDR(self, "dr_invert_vertex_group", "Invert Vertex Group", "invert_vertex_group"),
                BUBL(self, "bl_invert_vertex_group", "invert_vertex_group")],
            [
                BUKF(self, "kf_use_deform_preserve_volume", "use_deform_preserve_volume"),
                BUDR(self, "dr_use_deform_preserve_volume", "Preserve Volume", "use_deform_preserve_volume"),
                BUBL(self, "bl_use_deform_preserve_volume", "use_deform_preserve_volume")],
            [
                BUKF(self, "kf_use_multi_modifier", "use_multi_modifier"),
                BUDR(self, "dr_use_multi_modifier", "Multi Modifier", "use_multi_modifier"),
                BUBL(self, "bl_use_multi_modifier", "use_multi_modifier")],
            [
                BUDR(self, "dr_use_vertex_groups", "Vertex Groups", "use_vertex_groups", is_ref_driver=True),
                BUBL(self, "bl_use_vertex_groups", "use_vertex_groups")],
            [
                BUDR(self, "dr_use_bone_envelopes", "Bone Envelopes", "use_bone_envelopes", is_ref_driver=True),
                BUBL(self, "bl_use_bone_envelopes", "use_bone_envelopes")],
        ]
        self.line = line
        self.get_oo(line)
        oo = self.oo

        oo["ti_blend_to"] = BLFTI(P.color_font_darker, "Blend To", F[9])

        self.oo_free = {oo[k] for k in {
            "ti_blend_to",
        }}
        self.oo_22 = {oo[k] for k in {
            "bl_invert_vertex_group",
            "bl_use_deform_preserve_volume",
            "bl_use_multi_modifier",
            "bl_use_vertex_groups",
            "bl_use_bone_envelopes",
        }}
        self.oo_9 = {oo[k] for k in {
            "dr_object",
            "tx_object",
            "dr_vertex_group",
            "tx_vertex_group",
            "kf_invert_vertex_group",
            "dr_invert_vertex_group",
            "kf_use_deform_preserve_volume",
            "dr_use_deform_preserve_volume",
            "kf_use_multi_modifier",
            "dr_use_multi_modifier",
            "dr_use_vertex_groups",
            "dr_use_bone_envelopes",
        }}

        self.bu_sets = []
        bo_md_info = w.bo["md_info"]

        x   = bo_md_info.L
        y   = bo_md_info.T
        _2  = F[2]
        _3  = F[3]
        _16 = F[16]
        _17 = F[17]
        cv  = m.CANVAS_Y(P.color_mded_data_bg, x, bo_md_info.R - _2, bo_md_info.B + _2, y)
        self.cv = cv
        R   = cv.R - F[8]
        L   = x + F[101]
        Lb  = L + _16
        T   = y - F[8]
        B   = T - _16

        blf_size(font_0, F[9])
        ti_L0 = R - F[18]
        ti_L1 = ti_L0 - F[14]
        oo["tx_object"].LRBT(L, R, B, T)
        oo["tx_object"].ti_L = [["x", ti_L0], ["pick", ti_L1]]
        ti_x_object = oo["tx_object"].ti["x"]
        ti_pick_object = oo["tx_object"].ti["pick"]
        ti_x_object.y = B + F[2.5]
        ti_pick_object.y = B + F[4.5]
        oo["dr_object"].left_bu_depth(oo["tx_object"])

        T = B - _3
        B = T - _16
        oo["tx_vertex_group"].LRBT(L, R, B, T)
        oo["tx_vertex_group"].ti_L = [["x", ti_L0]]
        ti_x_vertex_group = oo["tx_vertex_group"].ti["x"]
        ti_x_vertex_group.y = B + F[2.5]
        oo["dr_vertex_group"].left_bu_depth(oo["tx_vertex_group"])

        T = B - _3
        B = T - _16
        oo["bl_invert_vertex_group"].LRBT(L, Lb, B, T)
        oo["dr_invert_vertex_group"].right_bu_depth_with_kf(oo["bl_invert_vertex_group"], oo["kf_invert_vertex_group"])

        T = B - _16
        B = T - _16
        oo["bl_use_deform_preserve_volume"].LRBT(L, Lb, B, T)
        oo["dr_use_deform_preserve_volume"].right_bu_depth_with_kf(oo["bl_use_deform_preserve_volume"], oo["kf_use_deform_preserve_volume"])

        T = B - _3
        B = T - _16
        oo["bl_use_multi_modifier"].LRBT(L, Lb, B, T)
        oo["dr_use_multi_modifier"].right_bu_depth_with_kf(oo["bl_use_multi_modifier"], oo["kf_use_multi_modifier"])

        T = B - _16
        B = T - _16
        oo["bl_use_vertex_groups"].LRBT(L, Lb, B, T)
        oo["dr_use_vertex_groups"].right_bu_depth(oo["bl_use_vertex_groups"])
        oo["ti_blend_to"].y = oo["dr_use_vertex_groups"].ti.y
        oo["ti_blend_to"].align_R(L - F[10])

        T = B - _3
        B = T - _16
        oo["bl_use_bone_envelopes"].LRBT(L, Lb, B, T)
        oo["dr_use_bone_envelopes"].right_bu_depth(oo["bl_use_bone_envelopes"])

        blf_size(font_0, F[15])
        x_x = round(ti_x_object.R_x_by_cx(R - F[18] / 2))
        ti_x_object.x = x_x
        ti_x_vertex_group.x = x_x

        blf_size(font_0, F[10])
        ti_pick_object.x = round(ti_pick_object.R_x_by_cx(R - F[18] - F[14] / 2))

        self.init_pick_data(allow_type={"ARMATURE"})
        cv.upd()
        self.upd_data()

    def upd_data(self):
        an_data = self.w.oj.animation_data
        act_md  = self.w.act_md
        oo      = self.oo
        obj     = act_md.object

        oo["tx_object"].set_da(""  if obj == None else obj.name)
        oo["tx_vertex_group"].set_da(act_md.vertex_group)
        oo["bl_invert_vertex_group"].set_da(act_md.invert_vertex_group)
        oo["bl_use_deform_preserve_volume"].set_da(act_md.use_deform_preserve_volume)
        oo["bl_use_multi_modifier"].set_da(act_md.use_multi_modifier)
        oo["bl_use_vertex_groups"].set_da(act_md.use_vertex_groups)
        oo["bl_use_bone_envelopes"].set_da(act_md.use_bone_envelopes)

        if act_md.vertex_group:
            if oo["bl_invert_vertex_group"].is_enable is False:
                oo["bl_invert_vertex_group"].enable()
                oo["kf_invert_vertex_group"].enable()
                oo["dr_invert_vertex_group"].enable()
        else:
            if oo["bl_invert_vertex_group"].is_enable is True:
                oo["bl_invert_vertex_group"].disable()
                oo["kf_invert_vertex_group"].disable()
                oo["dr_invert_vertex_group"].disable()

        self.upd_color(an_data, act_md)

    def bu_fn_x(self):
#
        self.oo["tx_object"].bpy_setter("")
        self.oo["tx_object"].setter()
        #
    def bu_fn_x_vg(self):
#
        self.oo["tx_vertex_group"].bpy_setter("")
        self.oo["tx_vertex_group"].setter()

    def R_type(self): return "ARMATURE"
    #
    #
class ARRAY(MD, PICK_OBJ):
    __slots__ = ()
    def init(self):
        w = self.w
        _1  = F[1]
        _2  = F[2]
        _3  = F[3]
        _6  = F[6]
        _8  = F[8]
        _10 = F[10]
        _12 = F[12]
        _15 = F[15]
        _16 = F[16]
        _17 = F[17]
        _110 = F[110]
        objects = "bpy.data.objects"
        line = [
            [
                BUKF(self, "kf_fit_type", "fit_type", VD_ARRAY_fit_type),
                BUDR(self, "dr_fit_type", "Fit Type :", "fit_type")],
            [
                BU(self, "bu_fixed_count", "Fixed Count", attr="fit_type", value="FIXED_COUNT", offset_y_key=7, free_size=_10),
                BU(self, "bu_fit_length", "Fit Length", attr="fit_type", value="FIT_LENGTH", offset_y_key=7, free_size=_10),
                BU(self, "bu_fit_curve", "Fit Curve", attr="fit_type", value="FIT_CURVE", offset_y_key=7, free_size=_10)],
            [
                BUKF(self, "kf_count", "count"),
                BUDR(self, "dr_count", "Count", "count"),
                BUFL(self, "fl_count", "count", offset_x_key=15, ty="int [1,∞]")],
            [
                BUKF(self, "kf_fit_length", "fit_length"),
                BUDR(self, "dr_fit_length", "Length", "fit_length"),
                BUFL(self, "fl_fit_length", "fit_length", offset_x_key=15, ty="float [0,∞]")],
            [
                BUDR(self, "dr_curve", "Curve", "curve", is_ref_driver=True),
                BUTX(self, "tx_curve", "curve", FIL_TYPE_EXC(objects, "CURVE"), fns={"x": self.bu_fn_x_curve, "pick": self.bu_fn_pick_curve})],
            [
                BUKF(self, "kf_use_relative_offset", "use_relative_offset"),
                BUDR(self, "dr_use_relative_offset", "Relative Offset", "use_relative_offset"),
                BUBL(self, "bl_use_relative_offset", "use_relative_offset")],
            [
                BUKFS(self, "kf_relative_offset_displace0", "relative_offset_displace", 0),
                BUDRS(self, "dr_relative_offset_displace0", "X", "relative_offset_displace", 0),
                BUFLS(self, "fl_relative_offset_displace0", "relative_offset_displace", offset_x_key=15)],
            [
                BUKFS(self, "kf_relative_offset_displace1", "relative_offset_displace", 1),
                BUDRS(self, "dr_relative_offset_displace1", "Y", "relative_offset_displace", 1),
                BUFLS(self, "fl_relative_offset_displace1", "relative_offset_displace", offset_x_key=15)],
            [
                BUKFS(self, "kf_relative_offset_displace2", "relative_offset_displace", 2),
                BUDRS(self, "dr_relative_offset_displace2", "Z", "relative_offset_displace", 2),
                BUFLS(self, "fl_relative_offset_displace2", "relative_offset_displace", offset_x_key=15)],
            [
                BUKF(self, "kf_use_constant_offset", "use_constant_offset"),
                BUDR(self, "dr_use_constant_offset", "Constant Offset", "use_constant_offset"),
                BUBL(self, "bl_use_constant_offset", "use_constant_offset")],
            [
                BUKFS(self, "kf_constant_offset_displace0", "constant_offset_displace", 0),
                BUDRS(self, "dr_constant_offset_displace0", "X", "constant_offset_displace", 0),
                BUFLS(self, "fl_constant_offset_displace0", "constant_offset_displace", offset_x_key=15)],
            [
                BUKFS(self, "kf_constant_offset_displace1", "constant_offset_displace", 1),
                BUDRS(self, "dr_constant_offset_displace1", "Y", "constant_offset_displace", 1),
                BUFLS(self, "fl_constant_offset_displace1", "constant_offset_displace", offset_x_key=15)],
            [
                BUKFS(self, "kf_constant_offset_displace2", "constant_offset_displace", 2),
                BUDRS(self, "dr_constant_offset_displace2", "Z", "constant_offset_displace", 2),
                BUFLS(self, "fl_constant_offset_displace2", "constant_offset_displace", offset_x_key=15)],
            [
                BUKF(self, "kf_use_object_offset", "use_object_offset"),
                BUDR(self, "dr_use_object_offset", "Object Offset", "use_object_offset"),
                BUBL(self, "bl_use_object_offset", "use_object_offset")],
            [
                BUDR(self, "dr_offset_object", "Object", "offset_object", is_ref_driver=True),
                BUTX(self, "tx_offset_object", "offset_object", FIL_TYPE_EXC(objects, exc=(w, "oj")), fns={"x": self.bu_fn_x_offset_object, "pick": self.bu_fn_pick_offset_object})],
            [
                BUKF(self, "kf_use_merge_vertices", "use_merge_vertices"),
                BUDR(self, "dr_use_merge_vertices", "Merge", "use_merge_vertices"),
                BUBL(self, "bl_use_merge_vertices", "use_merge_vertices")],
            [
                BUKF(self, "kf_merge_threshold", "merge_threshold"),
                BUDR(self, "dr_merge_threshold", "Distance", "merge_threshold"),
                BUFL(self, "fl_merge_threshold", "merge_threshold", offset_x_key=15, ty="float [0,∞]")],
            [
                BUKF(self, "kf_use_merge_vertices_cap", "use_merge_vertices_cap"),
                BUDR(self, "dr_use_merge_vertices_cap", "First and Last Copies", "use_merge_vertices_cap"),
                BUBL(self, "bl_use_merge_vertices_cap", "use_merge_vertices_cap")],
            [
                BUKF(self, "kf_offset_u", "offset_u"),
                BUDR(self, "dr_offset_u", "Offset U", "offset_u"),
                BUFL(self, "fl_offset_u", "offset_u", offset_x_key=15, ty="float [-1,1]")],
            [
                BUKF(self, "kf_offset_v", "offset_v"),
                BUDR(self, "dr_offset_v", "Offset V", "offset_v"),
                BUFL(self, "fl_offset_v", "offset_v", offset_x_key=15, ty="float [-1,1]")],
            [
                BUDR(self, "dr_start_cap", "Cap Start", "start_cap", is_ref_driver=True),
                BUTX(self, "tx_start_cap", "start_cap", FIL_TYPE_EXC(objects, "MESH", (w, "oj")), fns={"x": self.bu_fn_x_start_cap, "pick": self.bu_fn_pick_start_cap})],
            [
                BUDR(self, "dr_end_cap", "Cap End", "end_cap", is_ref_driver=True),
                BUTX(self, "tx_end_cap", "end_cap", FIL_TYPE_EXC(objects, "MESH", (w, "oj")), fns={"x": self.bu_fn_x_end_cap, "pick": self.bu_fn_pick_end_cap})],
        ]
        self.line = line
        self.get_oo(line)
        oo = self.oo

        oo["ti_factor"] = BLFTI(P.color_font_darker, "Factor", F[9])
        oo["ti_distance"] = BLFTI(P.color_font_darker, "Distance", F[9])

        e0 = oo["fl_relative_offset_displace0"]  ;e0.index = 0
        e1 = oo["fl_relative_offset_displace1"]  ;e1.index = 1
        e2 = oo["fl_relative_offset_displace2"]  ;e2.index = 2
        array_relative_offset_displace = [e0, e1, e2]
        e0.array = array_relative_offset_displace
        e1.array = array_relative_offset_displace
        e2.array = array_relative_offset_displace
        e0 = oo["fl_constant_offset_displace0"]  ;e0.index = 0
        e1 = oo["fl_constant_offset_displace1"]  ;e1.index = 1
        e2 = oo["fl_constant_offset_displace2"]  ;e2.index = 2
        array_constant_offset_displace = [e0, e1, e2]
        e0.array = array_constant_offset_displace
        e1.array = array_constant_offset_displace
        e2.array = array_constant_offset_displace

        self.oo_free = {oo[k] for k in {
            "bu_fixed_count",
            "bu_fit_length",
            "bu_fit_curve",
            "ti_factor",
            "ti_distance",
        }}
        self.oo_22 = {oo[k] for k in {
            "bl_use_relative_offset",
            "bl_use_constant_offset",
            "bl_use_object_offset",
            "bl_use_merge_vertices",
            "bl_use_merge_vertices_cap",
        }}
        self.oo_9 = {oo[k] for k in {
            "kf_fit_type",
            "dr_fit_type",
            "kf_count",
            "dr_count",
            "fl_count",
            "kf_fit_length",
            "dr_fit_length",
            "fl_fit_length",
            "dr_curve",
            "tx_curve",
            "kf_use_relative_offset",
            "dr_use_relative_offset",
            "kf_relative_offset_displace0",
            "dr_relative_offset_displace0",
            "fl_relative_offset_displace0",
            "kf_relative_offset_displace1",
            "dr_relative_offset_displace1",
            "fl_relative_offset_displace1",
            "kf_relative_offset_displace2",
            "dr_relative_offset_displace2",
            "fl_relative_offset_displace2",
            "kf_use_constant_offset",
            "dr_use_constant_offset",
            "kf_constant_offset_displace0",
            "dr_constant_offset_displace0",
            "fl_constant_offset_displace0",
            "kf_constant_offset_displace1",
            "dr_constant_offset_displace1",
            "fl_constant_offset_displace1",
            "kf_constant_offset_displace2",
            "dr_constant_offset_displace2",
            "fl_constant_offset_displace2",
            "kf_use_object_offset",
            "dr_use_object_offset",
            "dr_offset_object",
            "tx_offset_object",
            "kf_use_merge_vertices",
            "dr_use_merge_vertices",
            "kf_merge_threshold",
            "dr_merge_threshold",
            "fl_merge_threshold",
            "kf_use_merge_vertices_cap",
            "dr_use_merge_vertices_cap",
            "kf_offset_u",
            "dr_offset_u",
            "fl_offset_u",
            "kf_offset_v",
            "dr_offset_v",
            "fl_offset_v",
            "dr_start_cap",
            "tx_start_cap",
            "dr_end_cap",
            "tx_end_cap",
        }}

        self.bu_sets = [BU_SET(line[1], VD_ARRAY_fit_type)]
        bo_md_info = w.bo["md_info"]

        x   = bo_md_info.L
        y   = bo_md_info.T
        cv  = m.CANVAS_Y(P.color_mded_data_bg, x, bo_md_info.R - _2, 0, y)
        self.cv = cv
        d   = _17
        RR  = cv.R - _8
        LL  = x + _8
        ti_L0 = RR - F[18]
        ti_L1 = ti_L0 - F[14]
        _2_5 = F[2.5]
        _4_5 = F[4.5]

        wi = round((RR - LL - 2 * _2) / 3)
        R = LL + wi
        T = y - F[22]
        B = T - F[21]
        blf_size(font_0, _10)
        oo["bu_fixed_count"].LRBT(LL, R, B, T)
        L = R + _2
        R = L + wi
        oo["bu_fit_length"].LRBT(L, R, B, T)
        oo["bu_fit_curve"].LRBT(R + _2, RR, B, T)
        oo["kf_fit_type"].above_L_with_dr(oo["bu_fixed_count"], oo["dr_fit_type"])

        blf_size(font_0, F[9])
        T = B - _3
        B = T - _16
        R = L + _110
        oo["fl_count"].LRBT(L, R, B, T)
        oo["dr_count"].left_bu_depth(oo["fl_count"])
        oo["kf_count"].right_bu_depth(oo["fl_count"])
        T = B - _2
        B = T - _16
        oo["fl_fit_length"].LRBT(L, R, B, T)
        oo["dr_fit_length"].left_bu_depth(oo["fl_fit_length"])
        oo["kf_fit_length"].right_bu_depth(oo["fl_fit_length"])
        T = B - _2
        B = T - _16
        oo["tx_curve"].LRBT(L, RR, B, T)
        oo["tx_curve"].ti_L = [["x", ti_L0], ["pick", ti_L1]]
        ti_x_curve = oo["tx_curve"].ti["x"]
        ti_pick_curve = oo["tx_curve"].ti["pick"]
        ti_x_curve.y = B + _2_5
        ti_pick_curve.y = B + _4_5
        oo["dr_curve"].left_bu_depth(oo["tx_curve"])
        T = B - d
        B = T - _16
        Lb = L + _16
        oo["bl_use_relative_offset"].LRBT(L, Lb, B, T)
        oo["dr_use_relative_offset"].left_bu_depth_with_kf(oo["bl_use_relative_offset"], oo["kf_use_relative_offset"])
        T = B - _6
        B = T - _16
        oo["fl_relative_offset_displace0"].LRBT(L, R, B, T)
        oo["dr_relative_offset_displace0"].left_bu_depth(oo["fl_relative_offset_displace0"])
        oo["kf_relative_offset_displace0"].right_bu_depth(oo["fl_relative_offset_displace0"])
        oo["ti_factor"].y = B + F[6]
        oo["ti_factor"].align_R_float(oo["dr_relative_offset_displace0"].rim.L - _12)
        T = B - _1
        B = T - _16
        oo["fl_relative_offset_displace1"].LRBT(L, R, B, T)
        oo["dr_relative_offset_displace1"].left_bu_depth(oo["fl_relative_offset_displace1"])
        oo["kf_relative_offset_displace1"].right_bu_depth(oo["fl_relative_offset_displace1"])
        T = B - _1
        B = T - _16
        oo["fl_relative_offset_displace2"].LRBT(L, R, B, T)
        oo["dr_relative_offset_displace2"].left_bu_depth(oo["fl_relative_offset_displace2"])
        oo["kf_relative_offset_displace2"].right_bu_depth(oo["fl_relative_offset_displace2"])
        T = B - d
        B = T - _16
        oo["bl_use_constant_offset"].LRBT(L, Lb, B, T)
        oo["dr_use_constant_offset"].left_bu_depth_with_kf(oo["bl_use_constant_offset"], oo["kf_use_constant_offset"])
        T = B - _6
        B = T - _16
        oo["fl_constant_offset_displace0"].LRBT(L, R, B, T)
        oo["dr_constant_offset_displace0"].left_bu_depth(oo["fl_constant_offset_displace0"])
        oo["kf_constant_offset_displace0"].right_bu_depth(oo["fl_constant_offset_displace0"])
        oo["ti_distance"].y = B + F[6]
        oo["ti_distance"].align_R_float(oo["dr_constant_offset_displace0"].rim.L - _12)
        T = B - _1
        B = T - _16
        oo["fl_constant_offset_displace1"].LRBT(L, R, B, T)
        oo["dr_constant_offset_displace1"].left_bu_depth(oo["fl_constant_offset_displace1"])
        oo["kf_constant_offset_displace1"].right_bu_depth(oo["fl_constant_offset_displace1"])
        T = B - _1
        B = T - _16
        oo["fl_constant_offset_displace2"].LRBT(L, R, B, T)
        oo["dr_constant_offset_displace2"].left_bu_depth(oo["fl_constant_offset_displace2"])
        oo["kf_constant_offset_displace2"].right_bu_depth(oo["fl_constant_offset_displace2"])
        T = B - d
        B = T - _16
        oo["bl_use_object_offset"].LRBT(L, Lb, B, T)
        oo["dr_use_object_offset"].left_bu_depth_with_kf(oo["bl_use_object_offset"], oo["kf_use_object_offset"])
        T = B - _3
        B = T - _16
        oo["tx_offset_object"].LRBT(L, RR, B, T)
        oo["tx_offset_object"].ti_L = [["x", ti_L0], ["pick", ti_L1]]
        ti_x_offset_object = oo["tx_offset_object"].ti["x"]
        ti_pick_offset_object = oo["tx_offset_object"].ti["pick"]
        ti_x_offset_object.y = B + _2_5
        ti_pick_offset_object.y = B + _4_5
        oo["dr_offset_object"].left_bu_depth(oo["tx_offset_object"])
        T = B - d
        B = T - _16
        oo["bl_use_merge_vertices"].LRBT(L, Lb, B, T)
        oo["dr_use_merge_vertices"].left_bu_depth_with_kf(oo["bl_use_merge_vertices"], oo["kf_use_merge_vertices"])
        T = B - _3
        B = T - _16
        oo["fl_merge_threshold"].LRBT(L, R, B, T)
        oo["dr_merge_threshold"].left_bu_depth(oo["fl_merge_threshold"])
        oo["kf_merge_threshold"].right_bu_depth(oo["fl_merge_threshold"])
        T = B - _3
        B = T - _16
        oo["bl_use_merge_vertices_cap"].LRBT(L, Lb, B, T)
        oo["dr_use_merge_vertices_cap"].right_bu_depth_with_kf(oo["bl_use_merge_vertices_cap"], oo["kf_use_merge_vertices_cap"])
        T = B - d
        B = T - _16
        oo["fl_offset_u"].LRBT(L, R, B, T)
        oo["dr_offset_u"].left_bu_depth(oo["fl_offset_u"])
        oo["kf_offset_u"].right_bu_depth(oo["fl_offset_u"])
        T = B - _1
        B = T - _16
        oo["fl_offset_v"].LRBT(L, R, B, T)
        oo["dr_offset_v"].left_bu_depth(oo["fl_offset_v"])
        oo["kf_offset_v"].right_bu_depth(oo["fl_offset_v"])
        T = B - _8
        B = T - _16
        oo["tx_start_cap"].LRBT(L, RR, B, T)
        oo["tx_start_cap"].ti_L = [["x", ti_L0], ["pick", ti_L1]]
        ti_x_start_cap = oo["tx_start_cap"].ti["x"]
        ti_pick_start_cap = oo["tx_start_cap"].ti["pick"]
        ti_x_start_cap.y = B + _2_5
        ti_pick_start_cap.y = B + _4_5
        oo["dr_start_cap"].left_bu_depth(oo["tx_start_cap"])
        T = B - _1
        B = T - _16
        oo["tx_end_cap"].LRBT(L, RR, B, T)
        oo["tx_end_cap"].ti_L = [["x", ti_L0], ["pick", ti_L1]]
        ti_x_end_cap = oo["tx_end_cap"].ti["x"]
        ti_pick_end_cap = oo["tx_end_cap"].ti["pick"]
        ti_x_end_cap.y = B + _2_5
        ti_pick_end_cap.y = B + _4_5
        oo["dr_end_cap"].left_bu_depth(oo["tx_end_cap"])

        blf_size(font_0, F[15])
        x_x = round(ti_x_curve.R_x_by_cx(RR - F[18] / 2))
        ti_x_curve.x = x_x
        ti_x_offset_object.x = x_x
        ti_x_start_cap.x = x_x
        ti_x_end_cap.x = x_x

        blf_size(font_0, F[10])
        x_x = round(ti_pick_curve.R_x_by_cx(ti_L0 - F[14] / 2))
        ti_pick_curve.x = x_x
        ti_pick_offset_object.x = x_x
        ti_pick_start_cap.x = x_x
        ti_pick_end_cap.x = x_x

        cv.B = min(bo_md_info.B + _2, B - _8)
        cv.upd()
        self.upd_data()

    def upd_data(self):
        an_data = self.w.oj.animation_data
        act_md  = self.w.act_md
        oo      = self.oo

        fit_type = act_md.fit_type
        if fit_type == 'FIT_CURVE':
            if oo["fl_count"].is_enable is True:
                oo["fl_count"].disable()
                oo["dr_count"].disable()
                oo["kf_count"].disable()
            if oo["fl_fit_length"].is_enable is True:
                oo["fl_fit_length"].disable()
                oo["dr_fit_length"].disable()
                oo["kf_fit_length"].disable()
            if oo["tx_curve"].is_enable is False:
                oo["tx_curve"].enable()
                oo["dr_curve"].enable()
        elif fit_type == 'FIT_LENGTH':
            if oo["fl_count"].is_enable is True:
                oo["fl_count"].disable()
                oo["dr_count"].disable()
                oo["kf_count"].disable()
            if oo["fl_fit_length"].is_enable is False:
                oo["fl_fit_length"].enable()
                oo["dr_fit_length"].enable()
                oo["kf_fit_length"].enable()
            if oo["tx_curve"].is_enable is True:
                oo["tx_curve"].disable()
                oo["dr_curve"].disable()
        else:
            if oo["fl_count"].is_enable is False:
                oo["fl_count"].enable()
                oo["dr_count"].enable()
                oo["kf_count"].enable()
            if oo["fl_fit_length"].is_enable is True:
                oo["fl_fit_length"].disable()
                oo["dr_fit_length"].disable()
                oo["kf_fit_length"].disable()
            if oo["tx_curve"].is_enable is True:
                oo["tx_curve"].disable()
                oo["dr_curve"].disable()

        if act_md.use_relative_offset:
            if oo["fl_relative_offset_displace0"].is_enable is False:
                oo["fl_relative_offset_displace0"].enable()
                oo["fl_relative_offset_displace1"].enable()
                oo["fl_relative_offset_displace2"].enable()
                oo["dr_relative_offset_displace0"].enable()
                oo["dr_relative_offset_displace1"].enable()
                oo["dr_relative_offset_displace2"].enable()
                oo["kf_relative_offset_displace0"].enable()
                oo["kf_relative_offset_displace1"].enable()
                oo["kf_relative_offset_displace2"].enable()
                oo["ti_factor"].enable()
        else:
            if oo["fl_relative_offset_displace0"].is_enable is True:
                oo["fl_relative_offset_displace0"].disable()
                oo["fl_relative_offset_displace1"].disable()
                oo["fl_relative_offset_displace2"].disable()
                oo["dr_relative_offset_displace0"].disable()
                oo["dr_relative_offset_displace1"].disable()
                oo["dr_relative_offset_displace2"].disable()
                oo["kf_relative_offset_displace0"].disable()
                oo["kf_relative_offset_displace1"].disable()
                oo["kf_relative_offset_displace2"].disable()
                oo["ti_factor"].disable()

        if act_md.use_constant_offset:
            if oo["fl_constant_offset_displace0"].is_enable is False:
                oo["fl_constant_offset_displace0"].enable()
                oo["fl_constant_offset_displace1"].enable()
                oo["fl_constant_offset_displace2"].enable()
                oo["dr_constant_offset_displace0"].enable()
                oo["dr_constant_offset_displace1"].enable()
                oo["dr_constant_offset_displace2"].enable()
                oo["kf_constant_offset_displace0"].enable()
                oo["kf_constant_offset_displace1"].enable()
                oo["kf_constant_offset_displace2"].enable()
                oo["ti_distance"].enable()
        else:
            if oo["fl_constant_offset_displace0"].is_enable is True:
                oo["fl_constant_offset_displace0"].disable()
                oo["fl_constant_offset_displace1"].disable()
                oo["fl_constant_offset_displace2"].disable()
                oo["dr_constant_offset_displace0"].disable()
                oo["dr_constant_offset_displace1"].disable()
                oo["dr_constant_offset_displace2"].disable()
                oo["kf_constant_offset_displace0"].disable()
                oo["kf_constant_offset_displace1"].disable()
                oo["kf_constant_offset_displace2"].disable()
                oo["ti_distance"].disable()

        if act_md.use_object_offset:
            if oo["tx_offset_object"].is_enable is False:
                oo["tx_offset_object"].enable()
                oo["dr_offset_object"].enable()
        else:
            if oo["tx_offset_object"].is_enable is True:
                oo["tx_offset_object"].disable()
                oo["dr_offset_object"].disable()

        if act_md.use_merge_vertices:
            if oo["fl_merge_threshold"].is_enable is False:
                oo["fl_merge_threshold"].enable()
                oo["dr_merge_threshold"].enable()
                oo["kf_merge_threshold"].enable()
            if oo["bl_use_merge_vertices_cap"].is_enable is False:
                oo["bl_use_merge_vertices_cap"].enable()
                oo["dr_use_merge_vertices_cap"].enable()
                oo["kf_use_merge_vertices_cap"].enable()
        else:
            if oo["fl_merge_threshold"].is_enable is True:
                oo["fl_merge_threshold"].disable()
                oo["dr_merge_threshold"].disable()
                oo["kf_merge_threshold"].disable()
            if oo["bl_use_merge_vertices_cap"].is_enable is True:
                oo["bl_use_merge_vertices_cap"].disable()
                oo["dr_use_merge_vertices_cap"].disable()
                oo["kf_use_merge_vertices_cap"].disable()

        oo["fl_count"].set_da(act_md.count)
        oo["fl_fit_length"].set_da(act_md.fit_length)
        oo["tx_curve"].set_da(""  if act_md.curve == None else act_md.curve.name)
        oo["bl_use_relative_offset"].set_da(act_md.use_relative_offset)
        e = act_md.relative_offset_displace
        oo["fl_relative_offset_displace0"].set_da(e[0])
        oo["fl_relative_offset_displace1"].set_da(e[1])
        oo["fl_relative_offset_displace2"].set_da(e[2])
        oo["bl_use_constant_offset"].set_da(act_md.use_constant_offset)
        e = act_md.constant_offset_displace
        oo["fl_constant_offset_displace0"].set_da(e[0])
        oo["fl_constant_offset_displace1"].set_da(e[1])
        oo["fl_constant_offset_displace2"].set_da(e[2])
        oo["bl_use_object_offset"].set_da(act_md.use_object_offset)
        oo["tx_offset_object"].set_da(""  if act_md.offset_object == None else act_md.offset_object.name)
        oo["bl_use_merge_vertices"].set_da(act_md.use_merge_vertices)
        oo["fl_merge_threshold"].set_da(act_md.merge_threshold)
        oo["bl_use_merge_vertices_cap"].set_da(act_md.use_merge_vertices_cap)
        oo["fl_offset_u"].set_da(act_md.offset_u)
        oo["fl_offset_v"].set_da(act_md.offset_v)
        oo["tx_start_cap"].set_da(""  if act_md.start_cap == None else act_md.start_cap.name)
        oo["tx_end_cap"].set_da(""  if act_md.end_cap == None else act_md.end_cap.name)

        self.upd_color(an_data, act_md)

    def bu_fn_x_curve(self):
#
        self.oo["tx_curve"].bpy_setter("")
        self.oo["tx_curve"].setter()
        #
    def bu_fn_x_offset_object(self):
#
        self.oo["tx_offset_object"].bpy_setter("")
        self.oo["tx_offset_object"].setter()
        #
    def bu_fn_x_start_cap(self):
#
        self.oo["tx_start_cap"].bpy_setter("")
        self.oo["tx_start_cap"].setter()
        #
    def bu_fn_x_end_cap(self):
#
        self.oo["tx_end_cap"].bpy_setter("")
        self.oo["tx_end_cap"].setter()
        #
    def bu_fn_pick_curve(self):
#
        self.init_pick_data("tx_curve", allow_type={"CURVE"})
        super().bu_fn_pick()
        #
    def bu_fn_pick_offset_object(self):
#
        self.init_pick_data("tx_offset_object", exc_name=True)
        super().bu_fn_pick()
        #
    def bu_fn_pick_start_cap(self):
#
        self.init_pick_data("tx_start_cap", allow_type={"MESH"}, exc_name=True)
        super().bu_fn_pick()
        #
    def bu_fn_pick_end_cap(self):
#
        self.init_pick_data("tx_end_cap", allow_type={"MESH"}, exc_name=True)
        super().bu_fn_pick()
        #

    def R_type(self): return "ARRAY"
    #
    #
class BEVEL(MD):
    __slots__ = 'oo_alt'
    def init(self):
        w = self.w
        _2  = F[2]
        _3  = F[3]
        _8  = F[8]
        _10 = F[10]
        _17 = F[17]
        _76 = F[76]
        _93 = F[93]
        line = [
            [
                BUKF(self, "kf_affect", "affect", VD_BEVEL_affect),
                BUDR(self, "dr_affect", "Affect", "affect"),
                BU(
                    self, "bu_vertices", "Vertices",
                    offset_y_key=6, attr="affect", value="VERTICES", free_size=_10),
                BU(
                    self, "bu_edges", "Edges",
                    offset_y_key=6, attr="affect", value="EDGES", free_size=_10)],
            [
                BUKF(self, "kf_offset_type", "offset_type", VD_BEVEL_offset_type),
                BUDR(self, "dr_offset_type", "Width Type :", "offset_type")],
            [
                BU(self, "bu_offset", "Offset", attr="offset_type", value="OFFSET", offset_y_key=5),
                BU(self, "bu_width", "Width", attr="offset_type", value="WIDTH", offset_y_key=5),
                BU(self, "bu_depth", "Depth", attr="offset_type", value="DEPTH", offset_y_key=5),
                BU(self, "bu_percent", "Percent", attr="offset_type", value="PERCENT", offset_y_key=5),
                BU(self, "bu_absolute", "Absolute", attr="offset_type", value="ABSOLUTE", offset_y_key=5)],
            [
                BUKF(self, "kf_width", "width"),
                BUDR(self, "dr_width", "Amount", "width"),
                BUFL(self, "fl_width", "width", offset_x_key=18, ty="float [0,∞]")],
            [
                BUKF(self, "kf_segments", "segments"),
                BUDR(self, "dr_segments", "Segments", "segments"),
                BUFL(self, "fl_segments", "segments", offset_x_key=18, ty="int [1,1000]")],
            [
                BUKF(self, "kf_limit_method", "limit_method", VD_BEVEL_limit_method),
                BUDR(self, "dr_limit_method", "Limit Method :", "limit_method")],
            [
                BU(self, "bu_none", "None", attr="limit_method", value="NONE", offset_y_key=5),
                BU(self, "bu_angle", "Angle", attr="limit_method", value="ANGLE", offset_y_key=5),
                BU(self, "bu_weight", "Weight", attr="limit_method", value="WEIGHT", offset_y_key=5),
                BU(self, "bu_vertex_group", "Vertex Group", attr="limit_method", value="VGROUP", offset_y_key=5)],
            [
                BUKF(self, "kf_angle_limit", "angle_limit"),
                BUDR(self, "dr_angle_limit", "Angle", "angle_limit"),
                BUFL(self, "fl_angle_limit", "angle_limit", offset_x_key=18, ty="float [0,π]"),
                BUFD(self, "fd_angle_limit", "angle_limit", offset_x_key=9, ty="float [0,180]")],
            [
                BUKF(self, "kf_profile_type", "profile_type", VD_BEVEL_profile_type),
                BUDR(self, "dr_profile_type", "Profile Type :", "profile_type")],
            [
                BU(self, "bu_superellipse", "Superellipse", attr="profile_type", value="SUPERELLIPSE", offset_y_key=5),
                BU(self, "bu_custom", "Custom", attr="profile_type", value="CUSTOM", offset_y_key=5)],
            [
                BUKF(self, "kf_profile", "profile"),
                BUDR(self, "dr_profile", "Shape", "profile"),
                BUFL(self, "fl_profile", "profile", offset_x_key=18, ty="float [0,1]"),
                BURE(self, "bu_profile", "Edit Profile", self.bu_fn_profile)],
            [
                BUKF(self, "kf_miter_outer", "miter_outer", VD_BEVEL_miter_outer),
                BUDR(self, "dr_miter_outer", "Miter Outer", "miter_outer"),
                BU(self, "bu_sharp", "Sharp", attr="miter_outer", value="MITER_SHARP", offset_y_key=5),
                BU(self, "bu_patch", "Patch", attr="miter_outer", value="MITER_PATCH", offset_y_key=5),
                BU(self, "bu_arc", "Arc", attr="miter_outer", value="MITER_ARC", offset_y_key=5)],
            [
                BUKF(self, "kf_miter_inner", "miter_inner", VD_BEVEL_miter_inner),
                BUDR(self, "dr_miter_inner", "Miter Inner", "miter_inner"),
                BU(self, "bu_sharp2", "Sharp", attr="miter_inner", value="MITER_SHARP", offset_y_key=5),
                BU(self, "bu_arc2", "Arc", attr="miter_inner", value="MITER_ARC", offset_y_key=5)],
            [
                BUKF(self, "kf_spread", "spread"),
                BUDR(self, "dr_spread", "Spread", "spread"),
                BUFL(self, "fl_spread", "spread", offset_x_key=18, offset_y_key=4.9, ty="float [0,∞]")],
            [
                BUKF(self, "kf_vmesh_method", "vmesh_method", VD_BEVEL_vmesh_method),
                BUDR(self, "dr_vmesh_method", "Intersections :", "vmesh_method"),
                BUKF(self, "kf_use_clamp_overlap", "use_clamp_overlap"),
                BUDR(self, "dr_use_clamp_overlap", "Clamp Overlap", "use_clamp_overlap"),
                BUBL(self, "bl_use_clamp_overlap", "use_clamp_overlap")],
            [
                BU(self, "bu_grid_fill", "Grid Fill", attr="vmesh_method", value="ADJ", offset_y_key=5),
                BU(self, "bu_cutoff", "Cutoff", attr="vmesh_method", value="CUTOFF", offset_y_key=5)],
            [
                BUKF(self, "kf_face_strength_mode", "face_strength_mode", VD_BEVEL_face_strength_mode),
                BUDR(self, "dr_face_strength_mode", "Face Strength :", "face_strength_mode")],
            [
                BU(self, "bu_none2", "None", attr="face_strength_mode", value="FSTR_NONE", offset_y_key=5),
                BU(self, "bu_new", "New", attr="face_strength_mode", value="FSTR_NEW", offset_y_key=5),
                BU(self, "bu_affected", "Affected", attr="face_strength_mode", value="FSTR_AFFECTED", offset_y_key=5),
                BU(self, "bu_all", "All", attr="face_strength_mode", value="FSTR_ALL", offset_y_key=5)],
            [
                BUKF(self, "kf_material", "material"),
                BUDR(self, "dr_material", "Material Index", "material"),
                BUFL(self, "fl_material", "material", offset_x_key=18, offset_y_key=4.9, ty="int [-1,32767]")],
            [
                BUKF(self, "kf_mark_seam", "mark_seam"),
                BUDR(self, "dr_mark_seam", "Mark Seam", "mark_seam"),
                BUBL(self, "bl_mark_seam", "mark_seam")],
            [
                BUKF(self, "kf_mark_sharp", "mark_sharp"),
                BUDR(self, "dr_mark_sharp", "Mark Sharp", "mark_sharp"),
                BUBL(self, "bl_mark_sharp", "mark_sharp")],
            [
                BUKF(self, "kf_harden_normals", "harden_normals"),
                BUDR(self, "dr_harden_normals", "Harden Normal", "harden_normals"),
                BUBL(self, "bl_harden_normals", "harden_normals")],
        ]
        self.line = line
        self.get_oo(line)
        oo_alt = {}
        self.oo_alt = oo_alt
        oo  = self.oo

        oo["kf_loop_slide"] = BUKF(self, "kf_loop_slide", "loop_slide")
        oo["dr_loop_slide"] = BUDR(self, "dr_loop_slide", "Loop Slide", "loop_slide")
        oo["bl_loop_slide"] = BUBL(self, "bl_loop_slide", "loop_slide")

        oo_alt["tx_vertex_group"] = BUTX(self, "tx_vertex_group", "vertex_group", FIL(None), is_str=True, update_filter="self.w.w.oj.vertex_groups", fns={"x": self.bu_fn_x})

        oo_alt["fd_angle_limit"] = oo["fd_angle_limit"]
        oo_alt["fl_angle_limit"] = oo["fl_angle_limit"]

        oo_alt["bl_invert_vertex_group"] = BUBL(self, "bl_invert_vertex_group", "invert_vertex_group")
        oo_alt["kf_invert_vertex_group"] = BUKF(self, "kf_invert_vertex_group", "invert_vertex_group", False)
        oo_alt["dr_invert_vertex_group"] = BUDR(self, "dr_invert_vertex_group", "Invert", "invert_vertex_group")

        self.oo_free = {oo["bu_vertices"], oo["bu_edges"]}
        self.oo_22 = {oo[k] for k in {
            "bl_use_clamp_overlap",
            "bl_loop_slide",
            "bl_mark_seam",
            "bl_mark_sharp",
            "bl_harden_normals",
        }}
        self.oo_9 = {oo[k] for k in {
            "kf_affect",
            "dr_affect",
            "kf_offset_type",
            "dr_offset_type",
            "bu_offset",
            "bu_width",
            "bu_depth",
            "bu_percent",
            "bu_absolute",
            "kf_width",
            "dr_width",
            "fl_width",
            "kf_segments",
            "dr_segments",
            "fl_segments",
            "kf_limit_method",
            "dr_limit_method",
            "bu_none",
            "bu_angle",
            "bu_weight",
            "bu_vertex_group",
            "kf_angle_limit",
            "dr_angle_limit",
            "fl_angle_limit",
            "fd_angle_limit",
            "kf_profile_type",
            "dr_profile_type",
            "bu_superellipse",
            "bu_custom",
            "kf_profile",
            "dr_profile",
            "fl_profile",
            "bu_profile",
            "kf_miter_outer",
            "dr_miter_outer",
            "bu_sharp",
            "bu_patch",
            "bu_arc",
            "kf_miter_inner",
            "dr_miter_inner",
            "bu_sharp2",
            "bu_arc2",
            "kf_spread",
            "dr_spread",
            "fl_spread",
            "kf_vmesh_method",
            "dr_vmesh_method",
            "bu_grid_fill",
            "bu_cutoff",
            "kf_use_clamp_overlap",
            "dr_use_clamp_overlap",
            "kf_loop_slide",
            "dr_loop_slide",
            "kf_face_strength_mode",
            "dr_face_strength_mode",
            "bu_none2",
            "bu_new",
            "bu_affected",
            "bu_all",
            "kf_material",
            "dr_material",
            "fl_material",
            "kf_mark_seam",
            "dr_mark_seam",
            "kf_mark_sharp",
            "dr_mark_sharp",
            "kf_harden_normals",
            "dr_harden_normals",
        }}

        bu_sets = [
            BU_SET([oo["bu_vertices"], oo["bu_edges"]], VD_BEVEL_affect),
            BU_SET(line[2], VD_BEVEL_offset_type),
            BU_SET(line[6], VD_BEVEL_limit_method),
            BU_SET(line[9], VD_BEVEL_profile_type),
        ]
        self.bu_sets = bu_sets
        e = line[11]
        bu_sets.append(BU_SET([e[2], e[3], e[4]], VD_BEVEL_miter_outer))
        e = line[12]
        bu_sets.append(BU_SET([e[2], e[3]], VD_BEVEL_miter_inner))
        e = line[15]
        bu_sets.append(BU_SET([e[0], e[1]], VD_BEVEL_vmesh_method))
        e = line[17]
        bu_sets.append(BU_SET([e[0], e[1], e[2], e[3]], VD_BEVEL_face_strength_mode))

        bo_md_info = w.bo["md_info"]
        x   = bo_md_info.L
        y   = bo_md_info.T
        cv  = m.CANVAS_Y(P.color_mded_data_bg, x, bo_md_info.R - _2, 0, y)
        self.cv = cv
        R   = cv.R - _8
        L   = x + _8
        T   = y - _8
        B   = T - F[18]

        bu_w = round(55 * P.scale[0])
        bu_h = F[16]
        R1 = L + bu_w
        L2 = R1 + _2
        R2 = L2 + bu_w
        L3 = R2 + _2
        R3 = L3 + bu_w
        L4 = R3 + _2
        R4 = L4 + bu_w
        L5 = R4 + _2
        blf_size(font_0, _10)
        L7 = R - round((R - L3 - _2) / 2)
        oo["bu_edges"].LRBT(L7, R, B, T)
        R7 = L7 - _2
        oo["bu_vertices"].LRBT(L3, R7, B, T)

        blf_size(font_0, F[9])
        oo["dr_affect"].left_bu_depth_with_kf(oo["bu_vertices"], oo["kf_affect"])
        oo["kf_affect"].ti.y += _2
        oo["dr_affect"].ti.y += _2

        T = B - F[18]
        B = T - _17
        oo["bu_offset"].LRBT(L, R1, B, T)
        oo["bu_width"].LRBT(L2, R2, B, T)
        oo["bu_depth"].LRBT(L3, R3, B, T)
        oo["bu_percent"].LRBT(L4, R4, B, T)
        oo["bu_absolute"].LRBT(L5, R, B, T)

        oo["kf_offset_type"].above_L_with_dr(oo["bu_offset"], oo["dr_offset_type"])

        T = B - _2
        B = T - bu_h
        oo["fl_width"].LRBT(oo["bu_depth"].rim.L, oo["bu_percent"].rim.R, B, T)
        oo["dr_width"].left_bu_depth(oo["fl_width"])
        oo["kf_width"].right_bu_depth(oo["fl_width"])
        T = B - _2
        B = T - bu_h
        oo["fl_segments"].LRBT(oo["bu_depth"].rim.L, oo["bu_percent"].rim.R, B, T)
        oo["dr_segments"].left_bu_depth(oo["fl_segments"])
        oo["kf_segments"].right_bu_depth(oo["fl_segments"])

        T = B - F[30]
        B = T - _17
        oo["bu_none"].LRBT(L, R1, B, T)
        oo["bu_angle"].LRBT(L2, R2, B, T)
        oo["bu_weight"].LRBT(L3, R3, B, T)
        oo_VG = oo["bu_vertex_group"]
        oo_VG.next_bu(oo["bu_weight"], _76)
        oo["kf_limit_method"].above_L_with_dr(oo["bu_none"], oo["dr_limit_method"])

        T = B - _2
        B = T - bu_h
        oo["fl_angle_limit"].LRBT(L2, R3, B, T)
        oo["fd_angle_limit"].LRBT(oo_VG.rim.L, oo_VG.rim.R, B, T)
        oo["dr_angle_limit"].left_bu_depth(oo["fl_angle_limit"])
        oo["kf_angle_limit"].right_bu_depth(oo["fd_angle_limit"])

        T = oo["dr_angle_limit"].rim.B - F[31]
        B = T - _17
        oo["bu_superellipse"].LRBT(L, L + _76, B, T)
        oo["bu_custom"].next_bu(oo["bu_superellipse"], _76)

        oo["kf_profile_type"].above_L_with_dr(oo["bu_superellipse"], oo["dr_profile_type"])

        T = B - _2
        B = T - bu_h
        L_cus = oo["bu_custom"].rim.L
        oo["fl_profile"].LRBT(L_cus, L_cus + oo["fl_width"].rim.R_w(), B, T)
        oo["dr_profile"].left_bu_depth(oo["fl_profile"])
        oo["kf_profile"].right_bu_depth(oo["fl_profile"])
        oo["bu_profile"].LRBT(R - F[61], R, B, T)

        oo["bu_sharp"].LTwh(L_cus, oo["bu_profile"].rim.B - round(28 * P.scale[0]), bu_w, _17)
        oo["bu_patch"].next_bu(oo["bu_sharp"], bu_w)
        oo["bu_arc"].next_bu(oo["bu_patch"], bu_w)
        oo["dr_miter_outer"].left_bu_depth(oo["bu_sharp"])
        oo["kf_miter_outer"].right_bu_depth(oo["bu_arc"])

        oo["bu_sharp2"].LTwh(L_cus, oo["bu_sharp"].rim.B - _3, bu_w, _17)
        oo["bu_arc2"].next_bu(oo["bu_sharp2"], bu_w)
        oo["dr_miter_inner"].left_bu_depth(oo["bu_sharp2"])
        oo["kf_miter_inner"].right_bu_depth(oo["bu_arc2"])

        T = oo["bu_arc2"].rim.B - _3
        R_spread = oo["bu_arc2"].rim.R
        oo["fl_spread"].LRBT(L_cus, R_spread, T - bu_h, T)
        oo["dr_spread"].left_bu_depth(oo["fl_spread"])
        oo["kf_spread"].right_bu_depth(oo["fl_spread"])

        oo["bu_grid_fill"].LTwh(L, oo["fl_spread"].rim.B - F[31], bu_w, _17)
        oo["bu_cutoff"].next_bu(oo["bu_grid_fill"], bu_w)

        oo["kf_vmesh_method"].above_L_with_dr(oo["bu_grid_fill"], oo["dr_vmesh_method"])

        rim = oo["kf_vmesh_method"].rim
        L0 = R_spread - bu_h
        oo["bl_use_clamp_overlap"].LRBT(L0, R_spread, rim.B, rim.T)
        oo["dr_use_clamp_overlap"].right_bu_depth_with_kf(oo["bl_use_clamp_overlap"], oo["kf_use_clamp_overlap"])

        T = oo["bl_use_clamp_overlap"].rim.B - _3
        oo["bl_loop_slide"].LRBT(L0, R_spread, T - bu_h, T)
        oo["dr_loop_slide"].right_bu_depth_with_kf(oo["bl_loop_slide"], oo["kf_loop_slide"])

        oo["bu_none2"].LTwh(L, oo["bu_grid_fill"].rim.B - F[31], bu_w, _17)
        oo["bu_new"].next_bu(oo["bu_none2"], bu_w)
        oo["bu_affected"].next_bu(oo["bu_new"], bu_w)
        oo["bu_all"].next_bu(oo["bu_affected"], bu_w)

        oo["kf_face_strength_mode"].above_L_with_dr(oo["bu_none2"], oo["dr_face_strength_mode"])

        T = oo["bu_all"].rim.B - _3
        oo["fl_material"].LRBT(oo["bu_affected"].rim.L, oo["bu_all"].rim.R, T - bu_h, T)
        oo["dr_material"].left_bu_depth(oo["fl_material"])
        oo["kf_material"].right_bu_depth(oo["fl_material"])

        T = oo["fl_material"].rim.B - _3
        B = T - bu_h

        L = oo["fl_material"].rim.L
        Lb = L + bu_h
        oo["bl_mark_seam"].LRBT(L, Lb, B, T)
        oo["dr_mark_seam"].right_bu_depth_with_kf(oo["bl_mark_seam"], oo["kf_mark_seam"])
        T = B - _3
        B = T - bu_h
        oo["bl_mark_sharp"].LRBT(L, Lb, B, T)
        oo["dr_mark_sharp"].right_bu_depth_with_kf(oo["bl_mark_sharp"], oo["kf_mark_sharp"])
        T = B - _3
        B = T - bu_h
        oo["bl_harden_normals"].LRBT(L, Lb, B, T)
        oo["dr_harden_normals"].right_bu_depth_with_kf(oo["bl_harden_normals"], oo["kf_harden_normals"])

        cv.B = min(bo_md_info.B + _2, B - _8)
        cv.upd()
        self.upd_data()

    def upd_data(self):
        an_data = self.w.oj.animation_data
        act_md  = self.w.act_md
        oo      = self.oo

        b       = oo["fl_width"]
        if act_md.offset_type == "PERCENT":
            attr    = "width_pct"
            if b.attr != attr:
                b.attr = attr
                oo["kf_width"].attr = attr
                oo["dr_width"].attr = attr
                oo["dr_width"].ti.text = "Width (%)"
                blf_size(font_0, F[9])
                oo["dr_width"].left_bu_depth(b)
                oo["kf_width"].right_bu_depth(b)
                b.tx_format = m.U_format_f
                b.unit = 0
                b.da.name = None

            b.set_da(act_md.width_pct)
        else:
            attr    = "width"
            if b.attr != attr:
                b.attr = attr
                oo["kf_width"].attr = attr
                oo["dr_width"].attr = attr
                oo["dr_width"].ti.text = "Amount"
                blf_size(font_0, F[9])
                oo["dr_width"].left_bu_depth(b)
                oo["kf_width"].right_bu_depth(b)
                b.tx_format = m.U_FORMAT_F
                b.unit = 1
                b.da.name = None

            b.set_da(act_md.width)

        b = oo["fl_angle_limit"]
        if act_md.limit_method == "VGROUP":
            if b.attr != "vertex_group":
                oo_alt = self.oo_alt
                blf_size(font_0, F[9])

                kf_angle, dr_angle = self.change_kfdr_attr("angle_limit", "vertex_group", "Vertex Group")
                dr_angle.is_ref_driver = True
                B = kf_angle.rim.B
                T = kf_angle.rim.T
                self.line[7].remove(kf_angle)
                self.oo_9.remove(kf_angle)

                R_profile = oo["fl_profile"].rim.R
                e2 = oo_alt["tx_vertex_group"]
                self.replace_oo_9(oo, b, e2, "fl_angle_limit", 7, 1)
                e2.LRBT(oo["bu_custom"].rim.L, R_profile, B, T)
                e2.ti_L = [["x", R_profile - F[18]]]
                dr_angle.left_bu_depth_with_kf(e2, kf_angle)

                R = oo["bu_absolute"].rim.R
                e = oo_alt["bl_invert_vertex_group"]
                self.replace_oo_9_22(oo, oo["fd_angle_limit"], e, "fd_angle_limit", 7, 2)
                e.LRBT(R - F[16], R, B, T)

                e_kf = oo_alt["kf_invert_vertex_group"]
                e_dr = oo_alt["dr_invert_vertex_group"]
                self.add_oo_9(oo, e_kf, "kf_invert_vertex_group", 7)
                self.add_oo_9(oo, e_dr, "dr_invert_vertex_group", 7)
                e_dr.left_bu_depth_with_kf(e, e_kf)

                ti_x_vertex_group = e2.ti["x"]
                ti_x_vertex_group.y = B + F[2.5]
                blf_size(font_0, F[15])
                ti_x_vertex_group.x = ti_x_vertex_group.R_x_by_cx(R_profile - F[18] / 2)

                if dr_angle.is_enable is False: dr_angle.enable()

            oo["fl_angle_limit"].set_da(act_md.vertex_group)
            oo["fd_angle_limit"].set_da(act_md.invert_vertex_group)
        else:
            if b.attr != "angle_limit":
                oo_alt = self.oo_alt
                blf_size(font_0, F[9])

                kf_angle, dr_angle = self.change_kfdr_attr("vertex_group", "angle_limit", "Angle")
                dr_angle.is_ref_driver = False
                B = kf_angle.rim.B
                T = kf_angle.rim.T

                e_kf = oo_alt["kf_invert_vertex_group"]
                e_dr = oo_alt["dr_invert_vertex_group"]
                self.del_oo_9(oo, e_dr, "dr_invert_vertex_group", 7, -1)
                self.del_oo_9(oo, e_kf, "kf_invert_vertex_group", 7, -1)

                e2 = oo_alt["fl_angle_limit"]
                self.replace_oo_9(oo, oo_alt["tx_vertex_group"], e2, "fl_angle_limit", 7, 1)
                self.oo_9.add(kf_angle)
                self.line[7].insert(0, kf_angle)

                e2.LRBT(oo["bu_angle"].rim.L, oo["bu_weight"].rim.R, B, T)
                dr_angle.left_bu_depth(e2)

                e = oo_alt["fd_angle_limit"]
                self.replace_oo_22_9(oo, oo_alt["bl_invert_vertex_group"], e, "fd_angle_limit", 7, 3)
                e.LRBT(oo["bu_vertex_group"].rim.L, oo["bu_vertex_group"].rim.R, B, T)
                kf_angle.right_bu_depth(e)

            if act_md.limit_method == "ANGLE":
                if oo["fl_angle_limit"].is_enable is False:
                    oo["fl_angle_limit"].enable()
                    oo["fd_angle_limit"].enable()
                    oo["kf_angle_limit"].enable()
                if oo["dr_angle_limit"].is_enable is False:
                    oo["dr_angle_limit"].enable()
            else:
                if oo["fl_angle_limit"].is_enable is True:
                    oo["fl_angle_limit"].disable()
                    oo["fd_angle_limit"].disable()
                    oo["kf_angle_limit"].disable()
                if oo["dr_angle_limit"].is_enable is True:
                    oo["dr_angle_limit"].disable()

            oo["fl_angle_limit"].set_da(act_md.angle_limit)
            oo["fd_angle_limit"].set_da(act_md.angle_limit)

        if act_md.profile_type == "CUSTOM":
            if oo["bu_profile"].is_enable is False:
                oo["fl_profile"].disable()
                oo["dr_profile"].disable()
                oo["kf_profile"].disable()
                oo["bu_profile"].enable()
        else:
            if oo["bu_profile"].is_enable is True:
                oo["fl_profile"].enable()
                oo["dr_profile"].enable()
                oo["kf_profile"].enable()
                oo["bu_profile"].disable()

        if act_md.affect == "VERTICES":
            if oo["bu_sharp"].is_enable is True:
                oo["dr_miter_outer"].disable()
                oo["kf_miter_outer"].disable()
                oo["bu_sharp"].disable()
                oo["bu_patch"].disable()
                oo["bu_arc"].disable()
                oo["dr_miter_inner"].disable()
                oo["kf_miter_inner"].disable()
                oo["bu_sharp2"].disable()
                oo["bu_arc2"].disable()
                oo["dr_vmesh_method"].disable()
                oo["kf_vmesh_method"].disable()
                oo["bu_grid_fill"].disable()
                oo["bu_cutoff"].disable()
                oo["bl_loop_slide"].disable()
                oo["dr_loop_slide"].disable()
                oo["kf_loop_slide"].disable()
                oo["bl_mark_seam"].disable()
                oo["dr_mark_seam"].disable()
                oo["kf_mark_seam"].disable()
                oo["bl_mark_sharp"].disable()
                oo["dr_mark_sharp"].disable()
                oo["kf_mark_sharp"].disable()
            if oo["fl_spread"].is_enable is True:
                oo["fl_spread"].disable()
                oo["dr_spread"].disable()
                oo["kf_spread"].disable()
        else:
            if oo["bu_sharp"].is_enable is False:
                oo["dr_miter_outer"].enable()
                oo["kf_miter_outer"].enable()
                oo["bu_sharp"].enable()
                oo["bu_patch"].enable()
                oo["bu_arc"].enable()
                oo["dr_miter_inner"].enable()
                oo["kf_miter_inner"].enable()
                oo["bu_sharp2"].enable()
                oo["bu_arc2"].enable()
                oo["dr_vmesh_method"].enable()
                oo["kf_vmesh_method"].enable()
                oo["bu_grid_fill"].enable()
                oo["bu_cutoff"].enable()
                oo["bl_loop_slide"].enable()
                oo["dr_loop_slide"].enable()
                oo["kf_loop_slide"].enable()
                oo["bl_mark_seam"].enable()
                oo["dr_mark_seam"].enable()
                oo["kf_mark_seam"].enable()
                oo["bl_mark_sharp"].enable()
                oo["dr_mark_sharp"].enable()
                oo["kf_mark_sharp"].enable()
            if act_md.miter_inner == "MITER_ARC":
                if oo["fl_spread"].is_enable is False:
                    oo["fl_spread"].enable()
                    oo["dr_spread"].enable()
                    oo["kf_spread"].enable()
            else:
                if oo["fl_spread"].is_enable is True:
                    oo["fl_spread"].disable()
                    oo["dr_spread"].disable()
                    oo["kf_spread"].disable()

        oo["fl_segments"].set_da(act_md.segments)
        oo["fl_profile"].set_da(act_md.profile)
        oo["fl_spread"].set_da(act_md.spread)
        oo["bl_use_clamp_overlap"].set_da(act_md.use_clamp_overlap)
        oo["bl_loop_slide"].set_da(act_md.loop_slide)
        oo["fl_material"].set_da(act_md.material)
        oo["bl_mark_seam"].set_da(act_md.mark_seam)
        oo["bl_mark_sharp"].set_da(act_md.mark_sharp)
        oo["bl_harden_normals"].set_da(act_md.harden_normals)

        self.upd_color(an_data, act_md)

    def I_modal_main(self, evt):
        self.RET = False
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        oo = self.oo

        if oo["kf_loop_slide"].rim.B <= y <= oo["kf_loop_slide"].rim.T:
            if oo["kf_loop_slide"].rim.L <= x <= oo["kf_loop_slide"].rim.R:
                oo["kf_loop_slide"].inside(evt)
                return self.RET
            if oo["dr_loop_slide"].rim.L <= x <= oo["dr_loop_slide"].rim.R:
                oo["dr_loop_slide"].inside(evt)
                return self.RET
            if oo["bl_loop_slide"].rim.L <= x <= oo["bl_loop_slide"].rim.R:
                oo["bl_loop_slide"].inside(evt)
                return self.RET

        for ee in self.line:
            if ee[0].rim.T < y: break
            if ee[0].rim.B <= y:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        break
                break

        return self.RET

    def bu_fn_x(self):
        try:
#
            self.w.act_md.vertex_group = ""
            m.undo_str = '[Modifier Editor] md.vertex_group = ""'
            m.undo_push()
        except: pass
    def bu_fn_profile(self):
#
        try:
            VPP_BEVEL_PROFILE.md = self.w.act_md
            bpy.ops.wm.vpp_bevel_profile("INVOKE_DEFAULT")
        except: pass

    def R_type(self): return "BEVEL"
    #
    #
class BOOLEAN(MD2, PICK_OBJ):
    __slots__ = ()
    def init(self):
        w = self.w
        _2  = F[2]
        _3  = F[3]
        _12 = F[12]
        _16 = F[16]
        _17 = F[17]
        line = [
            [
                BUKF(self, "kf_operation", "operation", VD_BOOLEAN_operation),
                BUDR(self, "dr_operation", "Operation :", "operation")],
            [
                BU(
                    self, "bu_intersect", "Intersect",
                    offset_y_key=-5.6, attr="operation", value="INTERSECT", free_size=_12),
                BU(
                    self, "bu_union", "Union",
                    offset_y_key=-5.6, attr="operation", value="UNION", free_size=_12),
                BU(
                    self, "bu_difference", "Difference",
                    offset_y_key=-5.6, attr="operation", value="DIFFERENCE", free_size=_12)],
            [
                BUKF(self, "kf_operand_type", "operand_type", VD_BOOLEAN_operand_type),
                BUDR(self, "dr_operand_type", "Operand Type :", "operand_type")],
            [
                BU(self, "bu_object", "Object", attr="operand_type", value='OBJECT'),
                BUTX(self, "tx_object", "object", FIL_TYPE_EXC("bpy.data.objects", "MESH", (w, "oj")))],
            [
                BU(self, "bu_collection", "Collection", attr="operand_type", value="COLLECTION"),
                BUTX(self, "tx_collection", "collection", FIL("bpy.data.collections"))],
            [
                BUKF(self, "kf_solver", "solver", VD_BOOLEAN_solver),
                BUDR(self, "dr_solver", "Solver", "solver"),
                BU(self, "bu_fast", "Fast", attr="solver", value="FAST", offset_y_key=5),
                BU(self, "bu_exact", "Exact", attr="solver", value="EXACT", offset_y_key=5)],
            [
                BUKF(self, "kf_overlap", "double_threshold"),
                BUDR(self, "dr_overlap", "Overlap Threshold", "double_threshold"),
                BUFL(self, "fl_overlap", "double_threshold", offset_x_key=15, ty="float [0,1]")],
            [
                BUKF(self, "kf_self", "use_self", False), BUDR(self, "dr_self", "Self", "use_self"),
                BUBL(self, "bl_self", "use_self")],
            [
                BUKF(self, "kf_hole", "use_hole_tolerant", False),
                BUDR(self, "dr_hole", "Hole Tolerant", "use_hole_tolerant"),
                BUBL(self, "bl_hole", "use_hole_tolerant")],
        ]
        self.line = line
        self.get_oo(line)
        oo  = self.oo
        oo["bu_pick"] = BURE(self, "bu_pick", "⊕", self.bu_fn_pick, is_soft=True)
        oo["bu_x"] = BURE(self, "bu_x", "✕", self.bu_fn_x, offset_y_key=2.5, free_size=True, is_soft=True)

        self.oo_free = {oo[k] for k in {
            "bu_intersect",
            "bu_union",
            "bu_difference",
            "bu_x",
        }}
        self.oo_22 = {oo[k] for k in {
            "bl_self",
            "bl_hole"
        }}
        self.oo_9 = {oo[k] for k in {
            "kf_operation",
            "dr_operation",
            "kf_operand_type",
            "dr_operand_type",
            "bu_object",
            "tx_object",
            "bu_collection",
            "tx_collection",
            "kf_solver",
            "dr_solver",
            "bu_fast",
            "bu_exact",
            "kf_overlap",
            "dr_overlap",
            "fl_overlap",
            "kf_self",
            "dr_self",
            "kf_hole",
            "dr_hole",
            "bu_pick",
        }}

        self.bu_sets = [BU_SET(line[1], VD_BOOLEAN_operation)]

        self.oo_kf2 = {}
        self.oo_dr2 = {}
        self.props2 = w.oj.bl_rna.properties
        at0 = "object"
        line2 = [
            [
                BUKF2(self, "kf_display_type", (at0, "display_type"), VD_Object_display_type),
                BUDR2(self, "dr_display_type", "Display", (at0, "display_type")),
                BU2(self, "bu_display_type_bounds", "Bounds", attr=(at0, "display_type"), value="BOUNDS", offset_y_key=5),
                BUKF2(self, "kf_hide_viewport", (at0, "hide_viewport")),
                BUDR2(self, "dr_hide_viewport", "Hide in Viewport", (at0, "hide_viewport")),
                BUBL2(self, "bl_hide_viewport", (at0, "hide_viewport"))],
            [
                BU2(self, "bu_display_type_wire", "Wire", attr=(at0, "display_type"), value="WIRE", offset_y_key=5),
                BUKF2(self, "kf_hide_render", (at0, "hide_render")),
                BUDR2(self, "dr_hide_render", "Disable in Renders", (at0, "hide_render")),
                BUBL2(self, "bl_hide_render", (at0, "hide_render"))],
            [
                BU2(self, "bu_display_type_solid", "Solid", attr=(at0, "display_type"), value="SOLID", offset_y_key=5),
                BUKF2(self, "kf_show_bounds", (at0, "show_bounds")),
                BUDR2(self, "dr_show_bounds", "Display Bounds", (at0, "show_bounds")),
                BUBL2(self, "bl_show_bounds", (at0, "show_bounds"))],
            [
                BU2(self, "bu_display_type_textured", "Textured", attr=(at0, "display_type"), value="TEXTURED", offset_y_key=5),
                BUKF2(self, "kf_show_wire", (at0, "show_wire")),
                BUDR2(self, "dr_show_wire", "Display Wire", (at0, "show_wire")),
                BUBL2(self, "bl_show_wire", (at0, "show_wire"))],
            [
                BURE(self, "bu_make_parent", "Make Parent", self.bu_fn_make_parent, offset_y_key=5),
                BURE(self, "bu_select_target", "Select Target", self.bu_fn_select_target, offset_y_key=5)],
            [
                BURE(self, "bu_switch_ray", "Ray Visibility Status :  All enabled", self.bu_fn_switch_ray, offset_y_key=5)],
        ]
        self.line2 = line2
        oo2 = {}
        for e in line2:
            for o in e:     oo2[o.name] = o
        self.oo2 = oo2
        self.is_oo2 = False

        oo2["ti_target_object0"] = BLFTI(P.color_font_darker, "▾", F[12])
        oo2["ti_target_object1"] = BLFTI(P.color_font_darker, "Target Object :", F[9])
        oo2["bu_switch_ray"].ti.name = True

        self.oo2_free = {oo2[k] for k in {
            "ti_target_object0",
            "ti_target_object1",
        }}

        self.oo2_22 = {oo2[k] for k in {
            "bl_hide_viewport",
            "bl_hide_render",
            "bl_show_bounds",
            "bl_show_wire",
        }}

        self.oo2_9 = {oo2[k] for k in {
            "kf_hide_viewport",
            "dr_hide_viewport",
            "kf_hide_viewport",
            "dr_hide_viewport",
            "kf_hide_render",
            "dr_hide_render",
            "kf_display_type",
            "dr_display_type",
            "bu_display_type_bounds",
            "bu_display_type_wire",
            "bu_display_type_solid",
            "bu_display_type_textured",
            "kf_show_bounds",
            "dr_show_bounds",
            "kf_show_wire",
            "dr_show_wire",
            "bu_make_parent",
            "bu_select_target",
            "bu_switch_ray",
        }}

        self.bu_sets2 = [
            BU_SET([oo2["bu_display_type_bounds"], oo2["bu_display_type_wire"], oo2["bu_display_type_solid"], oo2["bu_display_type_textured"]], VD_Object_display_type),
        ]

        bo_md_info = w.bo["md_info"]

        x   = bo_md_info.L
        y   = bo_md_info.T
        cv  = m.CANVAS_Y(P.color_mded_data_bg, x, bo_md_info.R - _2, bo_md_info.B + _2, y)
        self.cv = cv
        L   = x + F[8]
        R   = L + F[93]
        T   = y - F[22]
        B   = T - F[20]

        blf_size(font_0, _12)
        oo["bu_intersect"].LRBT(L, R, B, T)
        L = R + _2
        R = L + F[93]
        oo["bu_union"].LRBT(L, R, B, T)
        L = R + _2
        R = cv.R - F[8]
        oo["bu_difference"].LRBT(L, R, B, T)

        blf_size(font_0, F[9])
        oo["kf_operation"].above_L_with_dr(oo["bu_intersect"], oo["dr_operation"])

        oo["bu_object"].LTwh(oo["bu_intersect"].rim.L, oo["bu_intersect"].rim.B - F[31], F[76], _16)
        oo["bu_collection"].below_bu(oo["bu_object"], _16)
        L = oo["bu_object"].rim.R + _2
        oo["tx_object"].LRBT(L, R, oo["bu_object"].rim.B, oo["bu_object"].rim.T)
        oo["tx_collection"].LRBT(L, R, oo["bu_collection"].rim.B, oo["bu_collection"].rim.T)

        oo["bu_object"].ti_offset_x_set(oo["bu_collection"].offset_x + F[1])
        oo["kf_operand_type"].above_L_with_dr(oo["bu_object"], oo["dr_operand_type"])

        B = oo["bu_object"].rim.T + _2
        T = B + _16
        oo["bu_pick"].LRBT(R - _17, R, B, T)

        bu_wi = round((F[110] - _2) / 2)
        L = oo["bu_union"].rim.R - bu_wi
        R = L + F[110]
        T = oo["bu_collection"].rim.B - F[13]
        B = T - _17
        R4 = L + bu_wi
        oo["bu_fast"].LRBT(L, R4, B, T)
        L5 = R4 + _2
        oo["bu_exact"].LRBT(L5, R, B, T)
        oo["dr_solver"].left_bu_depth(oo["bu_fast"])
        oo["kf_solver"].right_bu_depth(oo["bu_exact"])
        T = B - _3
        B = T - _16
        oo["fl_overlap"].LRBT(L, R, B, T)
        oo["dr_overlap"].left_bu_depth(oo["fl_overlap"])
        oo["kf_overlap"].right_bu_depth(oo["fl_overlap"])

        T = B - F[8]
        B = T - _16
        Lb  = L + _16
        oo["bl_self"].LRBT(L, Lb, B, T)
        oo["dr_self"].right_bu_depth_with_kf(oo["bl_self"], oo["kf_self"])
        T = B - _3
        B = T - _16
        oo["bl_hole"].LRBT(L, Lb, B, T)
        oo["dr_hole"].right_bu_depth_with_kf(oo["bl_hole"], oo["kf_hole"])

        if "material_mode" in self.props:
            kf_material_mode = BUKF(self, "kf_material_mode", "material_mode", VD_BOOLEAN_material_mode)
            dr_material_mode = BUDR(self, "dr_material_mode", "Material Mode", "material_mode")
            bu_material_mode_index_based = BU(self, "bu_material_mode_index_based", "Index", attr="material_mode", value="INDEX", offset_y_key=5)
            bu_material_mode_transfer = BU(self, "bu_material_mode_transfer", "Transfer", attr="material_mode", value="TRANSFER", offset_y_key=5)
            line.append([kf_material_mode, dr_material_mode, bu_material_mode_index_based, bu_material_mode_transfer])
            self.oo_9.update({kf_material_mode, dr_material_mode, bu_material_mode_index_based, bu_material_mode_transfer})
            oo["kf_material_mode"] = kf_material_mode
            oo["dr_material_mode"] = dr_material_mode
            oo["bu_material_mode_index_based"] = bu_material_mode_index_based
            oo["bu_material_mode_transfer"] = bu_material_mode_transfer

            self.bu_sets.append(BU_SET(line[-1][2:], VD_BOOLEAN_material_mode))

            T = B - F[8]
            B = T - _17
            bu_material_mode_index_based.LRBT(L, R4, B, T)
            bu_material_mode_transfer.LRBT(L5, R, B, T)
            dr_material_mode.left_bu_depth(bu_material_mode_index_based)
            kf_material_mode.right_bu_depth(bu_material_mode_transfer)

        oo["bu_x"].ti.size = F[15]
        oo["bu_x"].ti.set_size()
        oo["bu_x"].before_bu(oo["bu_pick"], _17)

        self.init_pick_data(allow_type={"MESH"}, exc_name=True)
        cv.upd()
        self.upd_data()

    def init_oo2(self):
        _2  = F[2]
        _3  = F[3]
        _8  = F[8]
        _16 = F[16]
        _17 = F[17]

        rim = self.oo["bl_hole"].rim
        oo2 = self.oo2
        cv = self.cv
        RR = cv.R - F[8]
        L = rim.L
        Lf = self.oo["fl_overlap"].rim.R
        Lb = rim.R

        L0 = Lb
        Lb += _16
        T0 = rim.B - F[61]
        B0 = T0 - _16
        Lt0 = cv.L + F[12]
        y0 = T0 + F[12]
        oo2["ti_target_object0"].xy(Lt0, y0)
        oo2["ti_target_object1"].xy(Lt0 + F[14], y0)
        oo2["bl_hide_viewport"].LRBT(L0, Lb, B0, T0)
        oo2["dr_hide_viewport"].right_bu_depth_with_kf(oo2["bl_hide_viewport"], oo2["kf_hide_viewport"])
        T1 = B0 - _3
        B1 = T1 - _16
        oo2["bl_hide_render"].LRBT(L0, Lb, B1, T1)
        oo2["dr_hide_render"].right_bu_depth_with_kf(oo2["bl_hide_render"], oo2["kf_hide_render"])
        T2 = B1 - _3
        B2 = T2 - _16
        oo2["bl_show_bounds"].LRBT(L0, Lb, B2, T2)
        oo2["dr_show_bounds"].right_bu_depth_with_kf(oo2["bl_show_bounds"], oo2["kf_show_bounds"])
        T3 = B2 - _3
        B3 = T3 - _16
        oo2["bl_show_wire"].LRBT(L0, Lb, B3, T3)
        oo2["dr_show_wire"].right_bu_depth_with_kf(oo2["bl_show_wire"], oo2["kf_show_wire"])

        # wi = round((RR - L - 3 * _2) / 4)
        R = L - _8
        L1 = R - F[61]
        hi = T0 - T1 - _2
        oo2["bu_display_type_bounds"].LRBT(L1, L, T0 - hi, T0)
        oo2["bu_display_type_wire"].LRBT(L1, L, T1 - hi, T1)
        oo2["bu_display_type_solid"].LRBT(L1, L, T2 - hi, T2)
        T = T3 - hi
        oo2["bu_display_type_textured"].LRBT(L1, L, T, T3)
        oo2["dr_display_type"].left_bu_depth_with_kf(oo2["bu_display_type_bounds"], oo2["kf_display_type"])
        T -= _16
        B = T - _17
        wi = F[101]
        Le = L - wi
        Re = L0 + wi
        oo2["bu_make_parent"].LRBT(Le, L, B, T)
        oo2["bu_select_target"].LRBT(L0, Re, B, T)
        T = B - F[6]
        B = T - _17
        oo2["bu_switch_ray"].LRBT(Le, Re, B, T)

    def upd_data(self):
        an_data = self.w.oj.animation_data
        act_md  = self.w.act_md
        oo      = self.oo
        obj     = act_md.object
        coll    = act_md.collection

        if act_md.operand_type == 'OBJECT':
            oo["bu_object"].on()        ;oo["bu_collection"].off()
            oo["tx_object"].enable()    ;oo["tx_collection"].disable()

            if act_md.solver == 'FAST':
                oo["bu_fast"].on()          ;oo["bu_exact"].off()

                if oo["fl_overlap"].is_enable is False:
                    oo["fl_overlap"].enable()
                    oo["dr_overlap"].enable()
                    oo["kf_overlap"].enable()
                if oo["bl_self"].is_enable is True:
                    oo["bl_self"].disable()
                    oo["dr_self"].disable()
                    oo["kf_self"].disable()
                if oo["bl_hole"].is_enable is True:
                    oo["bl_hole"].disable()
                    oo["dr_hole"].disable()
                    oo["kf_hole"].disable()
                if "bu_material_mode_index_based" in oo and oo["bu_material_mode_index_based"].is_enable is True:
                    oo["dr_material_mode"].disable()
                    oo["kf_material_mode"].disable()
                    oo["bu_material_mode_index_based"].disable()
                    oo["bu_material_mode_transfer"].disable()

            elif act_md.solver == 'EXACT':
                oo["bu_fast"].off()         ;oo["bu_exact"].on()

                if oo["fl_overlap"].is_enable is True:
                    oo["fl_overlap"].disable()
                    oo["dr_overlap"].disable()
                    oo["kf_overlap"].disable()
                if oo["bl_self"].is_enable is False:
                    oo["bl_self"].enable()
                    oo["dr_self"].enable()
                    oo["kf_self"].enable()
                if oo["bl_hole"].is_enable is False:
                    oo["bl_hole"].enable()
                    oo["dr_hole"].enable()
                    oo["kf_hole"].enable()
                if "bu_material_mode_index_based" in oo and oo["bu_material_mode_index_based"].is_enable is False:
                    oo["dr_material_mode"].enable()
                    oo["kf_material_mode"].enable()
                    oo["bu_material_mode_index_based"].enable()
                    oo["bu_material_mode_transfer"].enable()
            else:
                oo["bu_fast"].off()         ;oo["bu_exact"].off()

                if oo["fl_overlap"].is_enable is False:
                    oo["fl_overlap"].enable()
                    oo["dr_overlap"].enable()
                    oo["kf_overlap"].enable()
                if oo["bl_self"].is_enable is True:
                    oo["bl_self"].disable()
                    oo["dr_self"].disable()
                    oo["kf_self"].disable()
                if oo["bl_hole"].is_enable is True:
                    oo["bl_hole"].disable()
                    oo["dr_hole"].disable()
                    oo["kf_hole"].disable()
                if "bu_material_mode_index_based" in oo and oo["bu_material_mode_index_based"].is_enable is True:
                    oo["dr_material_mode"].disable()
                    oo["kf_material_mode"].disable()
                    oo["bu_material_mode_index_based"].disable()
                    oo["bu_material_mode_transfer"].disable()

        elif act_md.operand_type == 'COLLECTION':
            oo["bu_object"].off()       ;oo["bu_collection"].on()
            oo["tx_object"].disable()   ;oo["tx_collection"].enable()
            if coll != None:
                md_coll_obs = coll.objects
                if md_coll_obs:
                    is_mesh = True
                    for e in md_coll_obs:
                        if e.type != "MESH":    is_mesh = False ; break
                    oo["tx_collection"].da.color = P.color_font  if is_mesh else P.color_font_red
                else: oo["tx_collection"].da.color = P.color_font_red

            if act_md.solver == 'FAST':
                oo["bu_fast"].on()          ;oo["bu_exact"].off()

                if oo["fl_overlap"].is_enable is False:
                    oo["fl_overlap"].enable()
                    oo["dr_overlap"].enable()
                    oo["kf_overlap"].enable()
                if oo["bl_self"].is_enable is True:
                    oo["bl_self"].disable()
                    oo["dr_self"].disable()
                    oo["kf_self"].disable()
                if oo["bl_hole"].is_enable is True:
                    oo["bl_hole"].disable()
                    oo["dr_hole"].disable()
                    oo["kf_hole"].disable()
                if "bu_material_mode_index_based" in oo and oo["bu_material_mode_index_based"].is_enable is True:
                    oo["dr_material_mode"].disable()
                    oo["kf_material_mode"].disable()
                    oo["bu_material_mode_index_based"].disable()
                    oo["bu_material_mode_transfer"].disable()

            elif act_md.solver == 'EXACT':
                oo["bu_fast"].off()         ;oo["bu_exact"].on()

                if oo["fl_overlap"].is_enable is True:
                    oo["fl_overlap"].disable()
                    oo["dr_overlap"].disable()
                    oo["kf_overlap"].disable()
                if oo["bl_self"].is_enable is True:
                    oo["bl_self"].disable()
                    oo["dr_self"].disable()
                    oo["kf_self"].disable()
                if oo["bl_hole"].is_enable is False:
                    oo["bl_hole"].enable()
                    oo["dr_hole"].enable()
                    oo["kf_hole"].enable()
                if "bu_material_mode_index_based" in oo and oo["bu_material_mode_index_based"].is_enable is False:
                    oo["dr_material_mode"].enable()
                    oo["kf_material_mode"].enable()
                    oo["bu_material_mode_index_based"].enable()
                    oo["bu_material_mode_transfer"].enable()

            else:
                oo["bu_fast"].off()         ;oo["bu_exact"].off()

                if oo["fl_overlap"].is_enable is False:
                    oo["fl_overlap"].enable()
                    oo["dr_overlap"].enable()
                    oo["kf_overlap"].enable()
                if oo["bl_self"].is_enable is True:
                    oo["bl_self"].disable()
                    oo["dr_self"].disable()
                    oo["kf_self"].disable()
                if oo["bl_hole"].is_enable is True:
                    oo["bl_hole"].disable()
                    oo["dr_hole"].disable()
                    oo["kf_hole"].disable()
                if "bu_material_mode_index_based" in oo and oo["bu_material_mode_index_based"].is_enable is True:
                    oo["dr_material_mode"].disable()
                    oo["kf_material_mode"].disable()
                    oo["bu_material_mode_index_based"].disable()
                    oo["bu_material_mode_transfer"].disable()

        else:
            oo["bu_object"].off()       ;oo["bu_collection"].off()
            oo["tx_object"].disable()   ;oo["tx_collection"].disable()

        oo["tx_object"].set_da(""  if obj == None else obj.name)
        oo["tx_collection"].set_da(""  if coll == None else coll.name)
        oo["fl_overlap"].set_da(act_md.double_threshold)
        oo["bl_self"].set_da(act_md.use_self)
        oo["bl_hole"].set_da(act_md.use_hole_tolerant)

        self.upd_color(an_data, act_md)
        self.upd_ref_color(an_data, act_md, oo, (
            ("bu_object", "object"),
        ))

        if obj and act_md.operand_type == 'OBJECT':
            if self.is_oo2 is False:
                self.is_oo2 = True
                self.init_oo2()

            oo2 = self.oo2
            oo2["bl_hide_viewport"].set_da(obj.hide_viewport)
            oo2["bl_hide_render"].set_da(obj.hide_render)
            oo2["bl_show_bounds"].set_da(obj.show_bounds)
            oo2["bl_show_wire"].set_da(obj.show_wire)

            if obj.parent:
                if oo2["bu_make_parent"].ti.text == "Make Parent":
                    oo2["bu_make_parent"].ti.text = "Clear Parent"
            else:
                if oo2["bu_make_parent"].ti.text == "Clear Parent":
                    oo2["bu_make_parent"].ti.text = "Make Parent"

            ll_ray = obj.visible_camera + obj.visible_diffuse + obj.visible_glossy + obj.visible_shadow + obj.visible_transmission + obj.visible_volume_scatter
            if ll_ray == 0:
                if oo2["bu_switch_ray"].ti.name is not False:
                    oo2["bu_switch_ray"].ti.name = False
                    oo2["bu_switch_ray"].ti.text = "Ray Visibility Status :  All disabled"
            elif ll_ray == 6:
                if oo2["bu_switch_ray"].ti.name is not True:
                    oo2["bu_switch_ray"].ti.name = True
                    oo2["bu_switch_ray"].ti.text = "Ray Visibility Status :  All enabled"
            else:
                if oo2["bu_switch_ray"].ti.name is not None:
                    oo2["bu_switch_ray"].ti.name = None
                    oo2["bu_switch_ray"].ti.text = "Ray Visibility Status :  Partially enabled"

            self.upd_color2(obj.animation_data, obj)
        else:
            self.is_oo2 = False

    def I_modal_main(self, evt):
        self.RET = False
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        for ee in self.line:
            if ee[0].rim.B <= y <= ee[0].rim.T:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        return self.RET
                break

        if self.oo["bu_pick"].rim.in_BT(evt):
            if self.oo["bu_pick"].rim.in_LR(evt):
                self.oo["bu_pick"].inside(evt)
                return self.RET
            elif self.oo["bu_x"].rim.in_LR(evt):
                self.oo["bu_x"].inside(evt)
                return self.RET

        for ee in self.line2:
            if ee[0].rim.T < y: break
            if ee[0].rim.B <= y:
                for e in ee:
                    if e.rim.L <= x <= e.rim.R:
                        e.inside(evt)
                        break
                break
        return self.RET

    def bu_fn_pick(self):
#
        if self.w.act_md.operand_type == 'OBJECT':
            super().bu_fn_pick()
            return

        act_collection = bpy.context.view_layer.active_layer_collection.name
        if act_collection != 'Master Collection':
            self.oo["tx_collection"].bpy_setter(act_collection)
            self.oo["tx_collection"].setter()
        #
    def bu_fn_x(self):
#
        if self.w.act_md.operand_type == 'OBJECT':
            self.oo["tx_object"].bpy_setter("")
            self.oo["tx_object"].setter()
        else:
            self.oo["tx_collection"].bpy_setter("")
            self.oo["tx_collection"].setter()

    def R_target(self):
        try:    obj = self.w.act_md.object
        except: obj = None
        if not obj: return None
        try:
            if bpy.context.object.mode != "OBJECT":
                m.admin.report({'INFO'}, "Object mode requires")
                return None
        except:
            m.admin.report({'INFO'}, "No context object")
            return None
        return obj
    def bu_fn_make_parent(self):
#
        obj = self.R_target()
        if obj is None: return
        try:
            if obj.parent:
                m.undo_str = '[Modifier Editor] Clear Parent'
                with bpy.context.temp_override(selected_editable_objects=[obj]):
                    bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
            else:
                m.undo_str = '[Modifier Editor] Make Parent'
                with bpy.context.temp_override(object=self.w.oj, selected_editable_objects=[obj]):
                    bpy.ops.object.parent_set(keep_transform=True)
            m.undo_push()
        except:
            m.admin.report({'INFO'}, "Make / Clear Parent Fail")
    def bu_fn_select_target(self):
#
        obj = self.R_target()
        if obj is None: return
        if T_set_context_obj(self.w.act_md.object):
            m.undo_str = f'[Modifier Editor] Set active object: {self.w.act_md.object.name}'
            m.undo_push()
    def bu_fn_switch_ray(self):
#
        obj = self.R_target()
        if obj is None: return
        ll_ray = obj.visible_camera + obj.visible_diffuse + obj.visible_glossy + obj.visible_shadow + obj.visible_transmission + obj.visible_volume_scatter
        v = True if ll_ray == 0 else False

        obj.visible_camera = v
        obj.visible_diffuse = v
        obj.visible_glossy = v
        obj.visible_shadow = v
        obj.visible_transmission = v
        obj.visible_volume_scatter = v

        m.undo_str = '[Modifier Editor] Switch Ray Visibility'
        m.undo_push()

    def R_type(self): return "BOOLEAN"
    #
    #

##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
##
class MD_TEMP(MD):
    __slots__ = ()
    def init(self):
        w = self.w
        oo = {
            "mess0": BLF(P.color_font, size= F[12], text="The trial version only provides Armature, Array, Bevel and Boolean categories for testing. Please purchase the standard version."),
        }
        self.oo = oo

        bo_md_info = w.bo["md_info"]
        x   = bo_md_info.L
        y   = bo_md_info.T
        dy  = F[18]
        e = oo["mess0"]
        blf_size(font_0, F[12])
        L = x + F[10]
        B = y - F[22]
        e.xy(L, B)
        _2 = F[2]
        self.cv = m.CANVAS_Y(P.color_mded_data_bg, bo_md_info.L, bo_md_info.R - _2, bo_md_info.B + _2, bo_md_info.T)
        self.cv.upd()
    def I_draw(self):
        self.sci.use()
        self.cv.bind_draw()
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.w.bo["md_info"].R_w() - F[14])
        self.oo["mess0"].set_draw()
        blf_disable(font_0, WORD_WRAP)
    def dxy_upd(self, x, y):
        self.cv.dxy_upd(x, y)
        self.oo["mess0"].dxy(x, y)
    def upd_data(self): pass
    def I_modal_main(self, evt): return False
class BUILD(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "BUILD"
class CAST(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "CAST"
class CLOTH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "CLOTH"
class COLLISION(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "COLLISION"
class CORRECTIVE_SMOOTH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "CORRECTIVE_SMOOTH"
class CURVE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "CURVE"
class DATA_TRANSFER(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "DATA_TRANSFER"
class DECIMATE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "DECIMATE"
class DISPLACE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "DISPLACE"
class DYNAMIC_PAINT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "DYNAMIC_PAINT"
class EDGE_SPLIT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "EDGE_SPLIT"
class EXPLODE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "EXPLODE"
class FLUID(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "FLUID"
class HOOK(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "HOOK"
class LAPLACIANDEFORM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "LAPLACIANDEFORM"
class LAPLACIANSMOOTH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "LAPLACIANSMOOTH"
class LATTICE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "LATTICE"
class MASK(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MASK"
class MESH_CACHE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MESH_CACHE"
class MESH_DEFORM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MESH_DEFORM"
class MESH_SEQUENCE_CACHE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MESH_SEQUENCE_CACHE"
class MESH_TO_VOLUME(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MESH_TO_VOLUME"
class MIRROR(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MIRROR"
class MULTIRES(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "MULTIRES"
class NODES(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "NODES"
class NORMAL_EDIT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "NORMAL_EDIT"
class OCEAN(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "OCEAN"
class PARTICLE_INSTANCE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "PARTICLE_INSTANCE"
class PARTICLE_SYSTEM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "PARTICLE_SYSTEM"
class REMESH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "REMESH"
class SCREW(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SCREW"
class SHRINKWRAP(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SHRINKWRAP"
class SIMPLE_DEFORM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SIMPLE_DEFORM"
class SKIN(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SKIN"
class SMOOTH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SMOOTH"
class SOFT_BODY(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SOFT_BODY"
class SOLIDIFY(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SOLIDIFY"
class SUBSURF(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SUBSURF"
class SURFACE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SURFACE"
class SURFACE_DEFORM(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "SURFACE_DEFORM"
class TRIANGULATE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "TRIANGULATE"
class UV_PROJECT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "UV_PROJECT"
class UV_WARP(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "UV_WARP"
class VERTEX_WEIGHT_EDIT(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VERTEX_WEIGHT_EDIT"
class VERTEX_WEIGHT_MIX(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VERTEX_WEIGHT_MIX"
class VERTEX_WEIGHT_PROXIMITY(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VERTEX_WEIGHT_PROXIMITY"
class VOLUME_DISPLACE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VOLUME_DISPLACE"
class VOLUME_TO_MESH(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "VOLUME_TO_MESH"
class WARP(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WARP"
class WAVE(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WAVE"
class WEIGHTED_NORMAL(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WEIGHTED_NORMAL"
class WELD(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WELD"
class WIREFRAME(MD_TEMP):
    __slots__ = ()
    def R_type(self): return "WIREFRAME"
##
##
##
##
