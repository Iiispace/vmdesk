import bpy
from bmesh import from_edit_mesh
from blf import size as blf_size
from blf import color as blf_color

from .. import m, win

from .. props import EDITOR
from .. m import BOX, BLF, update_state
from .. bu import BU4, ENUM_SET
from .. det import INFO
from .. fn import R_face_normal

from . mesh_data import DATA_VERT, DATA_VERT_3, DATA_FACE

P = None
F = None
K = None
N = None
font_0 = None
BLEND = None

bm_data = {}

class OP_MESH(EDITOR):
    __slots__ = ()
    bl_idname = "wm.mesh_editor_operator"
    bl_label = "Mesh Editor"

    def R_cls(self): return MESH_ED
    def R_size(self): return P.win_size_init_ME


class MESH_ED(win.WIN):
    __slots__ = (
        'oo',
        'A_data',
        'A_bu',
        'props',
    )
    name = "Mesh Editor"
    W = []
    IND = []

    def init_D1(self):
        c = self.color
        c.font = P.color_font
        c.dr_info = P.color_oj_info

        self.bo = {
            "me_info":  BOX(c.dr_info),
        }
        self.ti = {
            "info":     BLF(),
        }
        self.da = {

        }
        A_bu = FAKE_AREA(self)
        self.A_bu = A_bu
        details_space = INFO("Space", "Data space.")
        self.oo = {
            "space":    ENUM_SET(A_bu, "space", "", [
                BU4(A_bu, "global", "Global", details=details_space),
                BU4(A_bu, "local", "Local", details=details_space),
            ], 2, self.bufn_space),
        }
        self.props = {
            "mesh_ed_local":                P.mesh_ed_local,
            "mesh_ed_dis_invert":           P.mesh_ed_dis_invert,
            "mesh_ed_face_nor_keep_act":    P.mesh_ed_face_nor_keep_act,
            "mesh_ed_face_nor_keep_nor":    P.mesh_ed_face_nor_keep_nor,
            "mesh_ed_cop_vert":             P.mesh_ed_cop_vert,
        }

        blf_title = self.tit["ti"]
        ind = blf_title.name
        if ind == 1:
            blf_title.text = "Mesh Editor"
        else:
            blf_title.text = f"Mesh Editor {ind}"

        self.cv.R_w = self.bo["me_info"].R_w
        self.cv.R_h = self.cv_R_h
        self.upd_data = self.I_upd_data

        self.A_data = DATA_VERT(self)


# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo_main(self):
        inn = P.win_border_inner
        bo  = self.bo
        ti  = self.ti
        da  = self.da
        x   = self.box["main"].L + P.win_border - self.cv.x
        y   = self.box["main"].T - P.win_border + self.cv.y
        u   = P.scale[0]
        depth = inn - 3

        bo_info = bo["me_info"]
        bo_info.depth_L(x, round(308 * u) + depth)
        bo_info.depth_T(y - F[21], round(300 * u))

        ti["info"].xy(bo_info.L + F[5], y - F[13])

        blf_size(font_0, F[9])
        bu_wi = round(40 * u)
        bu_hi = F[16]
        T = y - F[1]
        R = bo_info.R

        self.oo["space"].LRBT(R - bu_wi * 2 - F[2], R, T - bu_hi, T)

        self.A_data.__init__(self)

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd_main(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)

        self.A_data.dxy_upd(x, y)

    def glopan_upd(self):
        self.A_data.upd_sci()
    def I_modal_glopan_end_D1(self):
#
        self.I_upd_data()
    def modal_mov_end_D1(self):
#
        pass

    def cv_R_h(self):
        return self.bo["me_info"].R_h() + F[21]

    def bufn_space(self):
#
        self.props["mesh_ed_local"] = False if m.tm["ind"] == 0 else True
        self.I_upd_data()

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def modal_main_area(self, evt):
        if self.A_bu.U_modal(evt):  return True

        if self.bo["me_info"].inbox(evt):
            if self.A_data.U_modal(evt):    return True
        else:
            self.A_data.unfocus()

        if K["undo0"].true() or K["undo1"].true():
            m.undo()
            m.EVT.kill_except(evt)
            return True
        if K["redo0"].true() or K["redo1"].true():
            m.redo()
            m.EVT.kill_except(evt)
            return True

        return False

    def outside_evt(self, evt):
        # /* 0mesh_ed_outside_evt
        self.A_data.unfocus()
        self.A_bu.outside_evt(evt)
        # */
    def title_evt(self, evt):
        # <<< 1copy (0mesh_ed_outside_evt,, $$)
        self.A_data.unfocus()
        self.A_bu.outside_evt(evt)
        # >>>

# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def draw_main(self):
        bo = self.bo
        ti = self.ti
        bo["me_info"].bind_draw()

        for e in self.oo.values():  e.draw_bo()

        blf_size(font_0, F[11])
        blf_color(font_0, *self.color.font)
        ti["info"].draw_pos()

        blf_size(font_0, F[9])
        for e in self.oo.values():  e.draw_ti()

        BLEND()
        self.A_data.U_draw()

# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    # //* 0mesh_ed_to_A_data
    # *//
    def I_upd_data(self):
#

        if update_state["state"] is False:
            get_bm_data()
            need_update = True
        elif "bm_data" in update_state:
            need_update = False
        else:
            update_state["bm_data"] = None
            get_bm_data()
            need_update = True

        oo = self.oo
        oo["space"].set_da(1 if self.props["mesh_ed_local"] else 0)
        oj = bm_data["oj"]
        if oj:
            if "total_vert_sel" in bm_data:
                if bm_data["total_vert_sel"] is None:
                    self.ti["info"].text = "Edit Mode (Vertex Limit Exceeded)"
                else:
                    if bm_data["total_vert_sel"] == 2:
                        self.ti["info"].text = "Edit Mode (2 Vertices)"
                        if need_update: get_bm_vert2()
                        # <<< 1copy (0mesh_ed_to_A_data,, ${'_cls':'DATA_VERT'}$)
                        if type(self.A_data) != DATA_VERT:
#
                            self.A_data = DATA_VERT(self)
                        # >>>
                    elif bm_data["total_face_sel"] == 0 and bm_data["total_vert_sel"] == 3:
                        self.ti["info"].text = "Edit Mode (3 Vertices)"
                        if need_update: get_bm_vert3()
                        # <<< 1copy (0mesh_ed_to_A_data,, ${'_cls':'DATA_VERT_3'}$)
                        if type(self.A_data) != DATA_VERT_3:
#
                            self.A_data = DATA_VERT_3(self)
                        # >>>
                    elif bm_data["total_face_sel"] > 0:
                        self.ti["info"].text = "Edit Mode (1 Face)"  if bm_data["total_face_sel"] == 1 else "Edit Mode (Faces)"
                        if need_update: get_bm_face()
                        # <<< 1copy (0mesh_ed_to_A_data,, ${'_cls':'DATA_FACE'}$)
                        if type(self.A_data) != DATA_FACE:
#
                            self.A_data = DATA_FACE(self)
                        # >>>
                    else:
                        self.ti["info"].text = "Edit Mode"
                        if need_update: get_bm_face()
                        # <<< 1copy (0mesh_ed_to_A_data,, ${'_cls':'DATA_FACE'}$)
                        if type(self.A_data) != DATA_FACE:
#
                            self.A_data = DATA_FACE(self)
                        # >>>
            else:
                self.ti["info"].text = "Edit Mode (Mesh) requires"
        else:
            self.ti["info"].text = "No active object"

        self.A_data.upd_data()

    def kill_data(self):    pass

class FAKE_AREA:
    __slots__ = (
        'w',
        'U_modal',
        'outside',
    )
    def __init__(self, w):
        self.w = w
        self.U_modal = self.I_modal_main
        self.outside = [None]
    def I_modal_main(self, evt):
        for e in self.w.oo.values():
            if e.is_inside(evt):
                return self.U_modal(evt)
        return False
    def to_default_modal(self):
        self.U_modal = self.I_modal_main
    def outside_evt(self, evt):
        if self.U_modal != self.I_modal_main:
            self.outside[0] = True
            self.U_modal(evt)



class BMS:
    __slots__ = 'bm', 'verts_sel', 'edges_sel', 'faces_sel'
    def __init__(self, bm, verts_sel, edges_sel, faces_sel):
        self.bm = bm
        self.verts_sel = verts_sel
        self.edges_sel = edges_sel
        self.faces_sel = faces_sel

def get_bm_data():
#
    bm_data.clear()
    oj = bpy.context.object
    bm_data["oj"] = oj
    if oj.mode == "EDIT" and oj.type == "MESH":
        bms = {}
        bm_dic = {}
        total_vert_sel = 0
        total_edge_sel = 0
        total_face_sel = 0

        for ob in bpy.context.objects_in_mode:
            ob_data = ob.data
            total_vert_sel += ob_data.total_vert_sel
            total_edge_sel += ob_data.total_edge_sel
            total_face_sel += ob_data.total_face_sel
            if total_vert_sel >= P.mesh_ed_vert_lim:
                bm_data["total_vert_sel"] = None
                return
            bm = from_edit_mesh(ob_data)
            verts_sel = [e  for e in bm.verts if e.select]
            edges_sel = [e  for e in bm.edges if e.select]
            faces_sel = [e  for e in bm.faces if e.select]
            bms[ob] = BMS(bm, verts_sel, edges_sel, faces_sel)
            bm_dic.update({e: ob  for e in verts_sel})
            bm_dic.update({e: ob  for e in edges_sel})
            bm_dic.update({e: ob  for e in faces_sel})

        bm_data["bms"] = bms
        bm_data["bm_dic"] = bm_dic
        bm_data["total_vert_sel"] = total_vert_sel
        bm_data["total_edge_sel"] = total_edge_sel
        bm_data["total_face_sel"] = total_face_sel
def get_bm_vert2():
    verts = []
    bms = bm_data["bms"]
    for b in bms.values():
        verts += b.verts_sel

    v_act = bms[bm_data["oj"]].bm.select_history.active
    if verts[0] == v_act:
        v0 = verts[0]
        v1 = verts[1]
    else:
        v0 = verts[1]
        v1 = verts[0]

    vec = v0.co - v1.co
    bm_dic = bm_data["bm_dic"]
    vec_glo = (bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)

    bm_data["vert0"] = v0
    bm_data["vert1"] = v1
    bm_data["vec"] = vec
    bm_data["u_vec"] = vec.normalized()
    bm_data["vec_glo"] = vec_glo
    bm_data["u_vec_glo"] = vec_glo.normalized()
def get_bm_vert3():
    verts = []
    edges = []
    bms = bm_data["bms"]
    for b in bms.values():
        verts += b.verts_sel
        edges += b.edges_sel

    bm_dic = bm_data["bm_dic"]
    vert3_co = [v.co  for v in verts]
    vert3_co_world = [bm_dic[v].matrix_world @ v.co  for v in verts]

    bm_data["nor3"] = R_face_normal(vert3_co).normalized()
    bm_data["nor3_glo"] = R_face_normal(vert3_co_world).normalized()
    bm_data["verts"] = verts
    bm_data["edges"] = edges
    bm_data["vert3_co"] = vert3_co
    bm_data["vert3_co_world"] = vert3_co_world
def get_bm_face():
    verts = []
    edges = []
    faces = []
    bms = bm_data["bms"]
    for b in bms.values():
        verts += b.verts_sel
        edges += b.edges_sel
        faces += b.faces_sel

    bm_data["verts"] = verts
    bm_data["edges"] = edges
    bm_data["faces"] = faces
