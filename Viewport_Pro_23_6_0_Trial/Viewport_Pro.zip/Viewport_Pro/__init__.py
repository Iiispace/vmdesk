bl_info = {
    "name" : "Viewport Pro",
    "author" : "Iiispace",
    "version" : (23, 6, 0),
    "blender" : (3, 4),
    "location" : "View3d > Tool",
    "warning" : "",
    "description" : "This is the first version of the standard release for Blender 3.4, 3.5, 3.6",
    "wiki_url" : "",
    "category" : "3D View",
}

if "bpy" in locals():
    if 'm' in locals():

#
        import importlib

import bpy, gpu
from os.path import realpath, dirname
from bpy.props import IntProperty, StringProperty, FloatVectorProperty, PointerProperty
from blf import load as blf_load
from blf import unload as blf_unload
from blf import position as blf_pos
from blf import size as blf_size
from blf import draw as blf_draw
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP
from bpy.utils import register_class, unregister_class
from bpy.app.handlers import persistent
from bpy import types
from bpy.path import abspath
from gpu_extras.batch import batch_for_shader

from . import(
    prefs, npanel, m, tex, local_undo,
    bu_block, bu, dd, filt, ic, ll, rm, tb, win_cls, win_mess, win, det, props, ui
)
if bl_info["version"] >= (23, 6, 0):
    m.is_bgl = False
else:
    m.is_bgl = True

from . ED_md import mo, bu_md, cl_md, menu_batch, mods, oj_data
from . ED_dr import dr_ed, dr_data, dr_val, dr_vars
from . ED_setting import setting_ed, setting_data
from . ED_mesh import mesh_ed, mesh_data, mesh_block
from . ED_light_tool import light_tool_ed, light_tool_data, light_tool_block

from . bpy_ops import *

from . import debug_draw
import time
sec = 0
def empty_fn():pass

is_unreg = [False]
is_subscribe = False
font_dir = "\\".join((dirname(realpath(__file__)), "Fonts"))
path_font_0 = abspath("\\".join((font_dir, "droidsans.ttf")))
path_font_1 = abspath("\\".join((font_dir, "bmonofont-i18n.ttf")))


warning_data = {}
def init_warning():
    x = 50
    y = 110
    L = x
    R = L + 400
    T = y
    B = T - 100
    vertices = ((L, B), (R, B), (L, T), (R, T))
    indices = ((0, 1, 2), (2, 1, 3))

    warning_data["shader"] = gpu.shader.from_builtin(m.UNIFORM_COLOR)
    warning_data["box"] = batch_for_shader(warning_data["shader"], 'TRIS', {"pos": vertices}, indices=indices)
    warning_data["title"] = "-- Warning --   Re-enable detected"
    warning_data["body"] = "Need Restart Blender, otherwise it will crash when using the add-on."
    warning_data["blf_pos"] = (L + 15, T - 22)
    types.SpacePreferences.draw_handler_add(draw_warning, (), 'WINDOW', 'POST_PIXEL')
def draw_warning():
    warning_data["shader"].uniform_float("color", (0, 0, 0, 1))
    warning_data["box"].draw(warning_data["shader"])
    x, y = warning_data["blf_pos"]
    blf_pos(0, x, y, 0)
    blf_size(0, 16)
    blf_draw(0, warning_data["title"])
    blf_pos(0, x, y - 25, 0)
    blf_enable(0, WORD_WRAP)
    blf_wrap(0, 370)
    blf_draw(0, warning_data["body"])
    blf_disable(0, WORD_WRAP)

pass_bl_new_blend = [False]
@persistent
def bl_start_up(dummy):
#
    context = bpy.context

    m.addon_version = bl_info["version"]
    ver = bpy.app.version
    m.blender_version = ver[0] + float(f'0.{ver[1]}') + 0.0001
    m.UNIFORM_COLOR = "UNIFORM_COLOR"  if m.blender_version >= 4.0 else "2D_UNIFORM_COLOR"
    font_0 = blf_load(path_font_0)
    font_1 = blf_load(path_font_1)
    m.font_0 = font_0
    m.font_1 = font_1

    m.get_P()
    m.get_F()
    m.get_K()
    m.get_win_protect_fn()
    m.undo_evt = local_undo.undo_evt = local_undo.UNDO_EVT()

    m.bus_unit_system()
    m.bus_unit_length()

    P = m.P
    F = m.F
    K = m.K
    N = m.N
    NNT = m.NNT
    NF = m.NF
    BOX = m.BOX
    BLF = m.BLF
    RECT = m.RECT
    BOX_C = m.BOX_C
    shader2D = m.shader2D
    BIND = m.BIND
    UNFL = m.UNFL
    ENABLE_SCISSOR = m.ENABLE_SCISSOR
    DISABLE_SCISSOR = m.DISABLE_SCISSOR
    BLEND = m.BLEND
    scissor_set = m.scissor_set

    local_undo.P = P
    local_undo.undo_steps = context.preferences.edit.undo_steps
    bpy.context.scene.undo_ind = 0

    # //* 0__init__def
    # *//
    # //* 0__init__file
    # *//

    # IMPORT
    # <<< || 1match (0__init__file, -4, ${'file':'props'}$,       ${'.P='}$)
    props.P= P
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'ui'}$,          ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BOX_C=', '.BLF=', '.font_0='}$)
    ui.P= P
    ui.F= F
    ui.K= K
    ui.N= N
    ui.BOX= BOX
    ui.BLF= BLF
    ui.BOX_C= BOX_C
    ui.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'dr_data'}$,     ${'.P=', '.F=', '.N=', '.font_0='}$)
    dr_data.P= P
    dr_data.F= F
    dr_data.N= N
    dr_data.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'dr_ed'}$,       ${'.P=', '.F=', '.K=', '.N=', '.font_0=', '.BLEND'}$)
    dr_ed.P= P
    dr_ed.F= F
    dr_ed.K= K
    dr_ed.N= N
    dr_ed.font_0= font_0
    dr_ed.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'dr_val'}$,      ${'.P=', '.F=', '.N=', '.font_0='}$)
    dr_val.P= P
    dr_val.F= F
    dr_val.N= N
    dr_val.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'dr_vars'}$,     ${'.P=', '.F=', '.K=', '.N=', '.BIND=', '.UNFL=', '.font_0=', '.BLEND'}$)
    dr_vars.P= P
    dr_vars.F= F
    dr_vars.K= K
    dr_vars.N= N
    dr_vars.BIND= BIND
    dr_vars.UNFL= UNFL
    dr_vars.font_0= font_0
    dr_vars.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'bu_md'}$,       ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.RECT=', '.font_0='}$)
    bu_md.P= P
    bu_md.F= F
    bu_md.K= K
    bu_md.N= N
    bu_md.BOX= BOX
    bu_md.BLF= BLF
    bu_md.RECT= RECT
    bu_md.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'cl_md'}$,       ${'.P=', '.F=', '.K=', '.BLF=', '.font_0='}$)
    cl_md.P= P
    cl_md.F= F
    cl_md.K= K
    cl_md.BLF= BLF
    cl_md.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'menu_batch'}$,  ${'.P=', '.F=', '.K=', '.BOX=', '.BLF=', '.font_0=', '.font_1=', '.DISABLE_SCISSOR', '.BLEND'}$)
    menu_batch.P= P
    menu_batch.F= F
    menu_batch.K= K
    menu_batch.BOX= BOX
    menu_batch.BLF= BLF
    menu_batch.font_0= font_0
    menu_batch.font_1= font_1
    menu_batch.DISABLE_SCISSOR= DISABLE_SCISSOR
    menu_batch.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'mo'}$,          ${'.P=', '.F=', '.K=', '.BOX=', '.BLF=', '.font_0=', '.BLEND'}$)
    mo.P= P
    mo.F= F
    mo.K= K
    mo.BOX= BOX
    mo.BLF= BLF
    mo.font_0= font_0
    mo.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'mods'}$,        ${'.P=', '.F=', '.K=', '.BIND=', '.UNFL=', '.font_0=', '.font_1=', '.BLEND'}$)
    mods.P= P
    mods.F= F
    mods.K= K
    mods.BIND= BIND
    mods.UNFL= UNFL
    mods.font_0= font_0
    mods.font_1= font_1
    mods.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'oj_data'}$,     ${'.P=', '.F=', '.N=', '.BOX=', '.font_0='}$)
    oj_data.P= P
    oj_data.F= F
    oj_data.N= N
    oj_data.BOX= BOX
    oj_data.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'setting_data'}$,${'.P=', '.F=', '.K=', '.BOX=', '.BLF=', '.font_0=', '.BLEND'}$)
    setting_data.P= P
    setting_data.F= F
    setting_data.K= K
    setting_data.BOX= BOX
    setting_data.BLF= BLF
    setting_data.font_0= font_0
    setting_data.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'setting_ed'}$,  ${'.P=', '.F=', '.K=', '.BOX=', '.BLF=', '.font_0='}$)
    setting_ed.P= P
    setting_ed.F= F
    setting_ed.K= K
    setting_ed.BOX= BOX
    setting_ed.BLF= BLF
    setting_ed.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'bu_block'}$,    ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.BOX_C=', '.font_0='}$)
    bu_block.P= P
    bu_block.F= F
    bu_block.K= K
    bu_block.N= N
    bu_block.BOX= BOX
    bu_block.BLF= BLF
    bu_block.BOX_C= BOX_C
    bu_block.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'bu'}$,          ${'.P=', '.F=', '.K=', '.N=', '.NF=', '.BOX=', '.BLF=', '.RECT=', '.font_0='}$)
    bu.P= P
    bu.F= F
    bu.K= K
    bu.N= N
    bu.NF= NF
    bu.BOX= BOX
    bu.BLF= BLF
    bu.RECT= RECT
    bu.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'dd'}$,          ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.shader2D=', '.BIND=', '.UNFL=', '.font_0=', '.BLEND'}$)
    dd.P= P
    dd.F= F
    dd.K= K
    dd.N= N
    dd.BOX= BOX
    dd.BLF= BLF
    dd.shader2D= shader2D
    dd.BIND= BIND
    dd.UNFL= UNFL
    dd.font_0= font_0
    dd.BLEND= BLEND
    # >>>
    dd.VAL_COLOR = bu_block.VAL_COLOR
    # <<< || 1match (0__init__file, -4, ${'file':'filt'}$,        ${'.P='}$)
    filt.P= P
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'ic'}$,          ${'.P=', '.F=', '.shader2D=', '.BIND=', '.UNFL='}$)
    ic.P= P
    ic.F= F
    ic.shader2D= shader2D
    ic.BIND= BIND
    ic.UNFL= UNFL
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'ll'}$,          ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.font_0=', '.BLEND'}$)
    ll.P= P
    ll.F= F
    ll.K= K
    ll.N= N
    ll.BOX= BOX
    ll.BLF= BLF
    ll.font_0= font_0
    ll.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'rm'}$,          ${'.P=', '.F=', '.K=', '.BOX=', '.BLF=', '.font_0=', '.BLEND'}$)
    rm.P= P
    rm.F= F
    rm.K= K
    rm.BOX= BOX
    rm.BLF= BLF
    rm.font_0= font_0
    rm.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'tb'}$,          ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.shader2D=', '.BIND=', '.UNFL=', '.font_0=', '.BLEND'}$)
    tb.P= P
    tb.F= F
    tb.K= K
    tb.N= N
    tb.BOX= BOX
    tb.BLF= BLF
    tb.shader2D= shader2D
    tb.BIND= BIND
    tb.UNFL= UNFL
    tb.font_0= font_0
    tb.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'tex'}$,         ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.font_0=', '.BLEND'}$)
    tex.P= P
    tex.F= F
    tex.K= K
    tex.N= N
    tex.BOX= BOX
    tex.BLF= BLF
    tex.font_0= font_0
    tex.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'win_cls'}$,     ${'.P=', '.F=', '.K=', '.font_0=', '.BLEND'}$)
    win_cls.P= P
    win_cls.F= F
    win_cls.K= K
    win_cls.font_0= font_0
    win_cls.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'win_mess'}$,    ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.font_0=', '.font_1=', '.DISABLE_SCISSOR', '.BLEND'}$)
    win_mess.P= P
    win_mess.F= F
    win_mess.K= K
    win_mess.N= N
    win_mess.BOX= BOX
    win_mess.BLF= BLF
    win_mess.font_0= font_0
    win_mess.font_1= font_1
    win_mess.DISABLE_SCISSOR= DISABLE_SCISSOR
    win_mess.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'win'}$,         ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.font_1=', '.DISABLE_SCISSOR', '.BLEND'}$)
    win.P= P
    win.F= F
    win.K= K
    win.N= N
    win.BOX= BOX
    win.BLF= BLF
    win.font_1= font_1
    win.DISABLE_SCISSOR= DISABLE_SCISSOR
    win.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'mesh_ed'}$,     ${'.P=', '.F=', '.K=', '.N=', '.font_0=', '.BLEND'}$)
    mesh_ed.P= P
    mesh_ed.F= F
    mesh_ed.K= K
    mesh_ed.N= N
    mesh_ed.font_0= font_0
    mesh_ed.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'mesh_data'}$,   ${'.P=', '.F=', '.font_0='}$)
    mesh_data.P= P
    mesh_data.F= F
    mesh_data.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'mesh_block'}$,  ${'.P=', '.F=', '.K=', '.BOX=', '.BLF=', '.font_0='}$)
    mesh_block.P= P
    mesh_block.F= F
    mesh_block.K= K
    mesh_block.BOX= BOX
    mesh_block.BLF= BLF
    mesh_block.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'det'}$,         ${'.P=', '.F=', '.K=', '.N=', '.BOX=', '.BLF=', '.font_0=', '.BLEND'}$)
    det.P= P
    det.F= F
    det.K= K
    det.N= N
    det.BOX= BOX
    det.BLF= BLF
    det.font_0= font_0
    det.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'light_tool_ed'}$,      ${'.P=', '.F=', '.K=', '.N=', '.font_0=', '.BLEND'}$)
    light_tool_ed.P= P
    light_tool_ed.F= F
    light_tool_ed.K= K
    light_tool_ed.N= N
    light_tool_ed.font_0= font_0
    light_tool_ed.BLEND= BLEND
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'light_tool_data'}$,    ${'.P=', '.F=', '.font_0='}$)
    light_tool_data.P= P
    light_tool_data.F= F
    light_tool_data.font_0= font_0
    # >>>
    # <<< || 1match (0__init__file, -4, ${'file':'light_tool_block'}$,   ${'.P=', '.F=', '.K=', '.NNT=', '.BOX=', '.BLF=', '.font_0='}$)
    light_tool_block.P= P
    light_tool_block.F= F
    light_tool_block.K= K
    light_tool_block.NNT= NNT
    light_tool_block.BOX= BOX
    light_tool_block.BLF= BLF
    light_tool_block.font_0= font_0
    # >>>

    mesh_data.bm_data = mesh_ed.bm_data
    mesh_block.bm_data = mesh_ed.bm_data
    win_mess.BUTTON20 = ui.BUTTON20

    # IMPORT END

    link_mds    = bpy.data.link_mds
    for obj in bpy.data.objects:
        if obj.animation_data:
            for fc in obj.animation_data.drivers:
                path = fc.data_path
                if path[: 12] == '["modifiers[':    link_mds[fc] = obj

    subscribe()
    upd_link_data()

    if bl_start_up in bpy.app.handlers.version_update:  bpy.app.handlers.version_update.remove(bl_start_up)
    pass_bl_new_blend[0] = True
    #
    #
@persistent
def bl_unload(dummy):
#
    if m.admin is not None:     m.admin.modal_end()
    unsubscribe()
    blf_unload(path_font_0)
    blf_unload(path_font_1)

def BL_START_UP():
    bl_start_up(None)
    pass_bl_new_blend[0] = False
m.bl_start_up = BL_START_UP
props.bl_start_up = BL_START_UP

@persistent
def bl_new_blend(dummy):
    if pass_bl_new_blend[0] is True:
        pass_bl_new_blend[0] = False
#
        return

#
    unsubscribe()
    link_mds    = bpy.data.link_mds
    for obj in bpy.data.objects:
        if obj.animation_data:
            for fc in obj.animation_data.drivers:
                path = fc.data_path
                if path[: 12] == '["modifiers[':    link_mds[fc] = obj

    subscribe()
    upd_link_data()


is_upding = False
# @persistent
def upd_link_data():
    global is_upding
    if is_upding:   return
    is_upding = True
#
    link_mds = bpy.data.link_mds
    for fc, obj in link_mds.copy().items(): T_upd_md(fc, obj)

    is_upding = False

def T_upd_md(fc, obj):
    try:
        dr          = fc.driver
        path        = fc.data_path
        i           = path.rfind(".")
        attr        = path[i + 1 : -2]
        md_name     = path[12 : i - 1]
        mds         = obj.modifiers
        v           = dr.variables[0]
        tar         = v.targets[0]

        vl = getattr(tar.id.modifiers[v.name], attr)
        if getattr(mds[md_name], attr) != vl:
            setattr(mds[md_name], attr, vl)
#
        return False
    except: return True
def T_del_fc(obj, fc):
    try:    obj.animation_data.drivers.remove(fc)
    except: pass


classes = (
    prefs.ModEd_Prefs,
    npanel.ModEd_Panel,
    npanel.ModEd_Pref_Panel,
    m.M,
    m.PREF,
    mo.OP_MO,
    tex.OP_TEX,
    dr_ed.OP_DR,
    setting_ed.OP_SETTING,
    mesh_ed.OP_MESH,
    light_tool_ed.OP_LIGHT_TOOL,
    VPP_FACTORY,
    VPP_BEVEL_PROFILE,
    VPP_FALLOFF_CURVE,
    VPP_SCAN_FILE,
    VPP_R_PREF,
    OPS_MOVE_FRONT,
    OPS_IMG_GET,
)
subscribe_attr = (
    (types.BooleanModifier, 'object'),
    (types.BevelModifier, 'vertex_group'),
    (types.ArmatureModifier, 'object'),
    (types.ArmatureModifier, 'vertex_group'),
    (types.ArmatureModifier, 'use_vertex_groups'),
    (types.ArmatureModifier, 'use_bone_envelopes'),
    (types.ArrayModifier, 'curve'),
    (types.ArrayModifier, 'end_cap'),
    (types.ArrayModifier, 'offset_object'),
    (types.ArrayModifier, 'start_cap'),
    (types.CastModifier, 'object'),
    (types.CastModifier, 'vertex_group'),
    (types.CurveModifier, 'object'),
    (types.CurveModifier, 'vertex_group'),
    (types.CorrectiveSmoothModifier, 'vertex_group'),
    (types.DataTransferModifier, 'object'),
    (types.DataTransferModifier, 'vertex_group'),
    (types.DecimateModifier, 'vertex_group'),
    (types.DisplaceModifier, 'texture'),
    (types.DisplaceModifier, 'texture_coords_bone'),
    (types.DisplaceModifier, 'texture_coords_object'),
    (types.DisplaceModifier, 'uv_layer'),
    (types.DisplaceModifier, 'vertex_group'),
    (types.ExplodeModifier, 'particle_uv'),
    (types.ExplodeModifier, 'vertex_group'),
    (types.HookModifier, 'object'),
    (types.HookModifier, 'subtarget'),
    (types.HookModifier, 'vertex_group'),
    (types.LaplacianDeformModifier, 'vertex_group'),
    (types.LaplacianSmoothModifier, 'vertex_group'),
    (types.LatticeModifier, 'object'),
    (types.LatticeModifier, 'vertex_group'),
    (types.MaskModifier, 'armature'),
    (types.MaskModifier, 'vertex_group'),
    (types.MeshCacheModifier, 'filepath'),
    (types.MeshCacheModifier, 'vertex_group'),
    (types.MeshDeformModifier, 'object'),
    (types.MeshDeformModifier, 'vertex_group'),
    (types.MeshSequenceCacheModifier, 'cache_file'),
    (types.MeshSequenceCacheModifier, 'object_path'),
    (types.MirrorModifier, 'mirror_object'),
    (types.MultiresModifier, 'filepath'),
    (types.NormalEditModifier, 'target'),
    (types.NormalEditModifier, 'vertex_group'),
    (types.OceanModifier, 'bake_foam_fade'),
    (types.OceanModifier, 'damping'),
    (types.OceanModifier, 'depth'),
    (types.OceanModifier, 'fetch_jonswap'),
    (types.OceanModifier, 'filepath'),
    (types.OceanModifier, 'foam_layer_name'),
    (types.OceanModifier, 'frame_end'),
    (types.OceanModifier, 'frame_start'),
    (types.OceanModifier, 'invert_spray'),
    (types.OceanModifier, 'random_seed'),
    (types.OceanModifier, 'repeat_x'),
    (types.OceanModifier, 'repeat_y'),
    (types.OceanModifier, 'resolution'),
    (types.OceanModifier, 'sharpen_peak_jonswap'),
    (types.OceanModifier, 'spatial_size'),
    (types.OceanModifier, 'spectrum'),
    (types.OceanModifier, 'spray_layer_name'),
    (types.OceanModifier, 'use_foam'),
    (types.OceanModifier, 'use_normals'),
    (types.OceanModifier, 'use_spray'),
    (types.OceanModifier, 'viewport_resolution'),
    (types.OceanModifier, 'wave_alignment'),
    (types.OceanModifier, 'wave_direction'),
    (types.OceanModifier, 'wave_scale_min'),
    (types.OceanModifier, 'wind_velocity'),
    (types.ParticleInstanceModifier, 'index_layer_name'),
    (types.ParticleInstanceModifier, 'object'),
    (types.ParticleInstanceModifier, 'particle_system'),
    (types.ParticleInstanceModifier, 'value_layer_name'),
    (types.ScrewModifier, 'object'),
    (types.ShrinkwrapModifier, 'auxiliary_target'),
    (types.ShrinkwrapModifier, 'target'),
    (types.ShrinkwrapModifier, 'vertex_group'),
    (types.SimpleDeformModifier, 'origin'),
    (types.SimpleDeformModifier, 'vertex_group'),
    (types.SmoothModifier, 'vertex_group'),
    (types.SolidifyModifier, 'rim_vertex_group'),
    (types.SolidifyModifier, 'shell_vertex_group'),
    (types.SolidifyModifier, 'vertex_group'),
    (types.SurfaceDeformModifier, 'target'),
    (types.SurfaceDeformModifier, 'use_sparse_bind'),
    (types.SurfaceDeformModifier, 'vertex_group'),
    (types.UVProjectModifier, 'uv_layer'),
    (types.UVWarpModifier, 'bone_from'),
    (types.UVWarpModifier, 'bone_to'),
    (types.UVWarpModifier, 'object_from'),
    (types.UVWarpModifier, 'object_to'),
    (types.UVWarpModifier, 'uv_layer'),
    (types.UVWarpModifier, 'vertex_group'),
    (types.VertexWeightEditModifier, 'mask_tex_map_bone'),
    (types.VertexWeightEditModifier, 'mask_tex_map_object'),
    (types.VertexWeightEditModifier, 'mask_tex_uv_layer'),
    (types.VertexWeightEditModifier, 'mask_texture'),
    (types.VertexWeightEditModifier, 'mask_vertex_group'),
    (types.VertexWeightEditModifier, 'vertex_group'),
    (types.VertexWeightMixModifier, 'mask_tex_map_bone'),
    (types.VertexWeightMixModifier, 'mask_tex_map_object'),
    (types.VertexWeightMixModifier, 'mask_tex_uv_layer'),
    (types.VertexWeightMixModifier, 'mask_texture'),
    (types.VertexWeightMixModifier, 'mask_vertex_group'),
    (types.VertexWeightMixModifier, 'vertex_group_a'),
    (types.VertexWeightMixModifier, 'vertex_group_b'),
    (types.VertexWeightProximityModifier, 'mask_tex_map_bone'),
    (types.VertexWeightProximityModifier, 'mask_tex_map_object'),
    (types.VertexWeightProximityModifier, 'mask_tex_uv_layer'),
    (types.VertexWeightProximityModifier, 'mask_texture'),
    (types.VertexWeightProximityModifier, 'mask_vertex_group'),
    (types.VertexWeightProximityModifier, 'target'),
    (types.VertexWeightProximityModifier, 'vertex_group'),
    (types.VolumeToMeshModifier, 'grid_name'),
    (types.VolumeToMeshModifier, 'object'),
    (types.WarpModifier, 'bone_from'),
    (types.WarpModifier, 'bone_to'),
    (types.WarpModifier, 'object_from'),
    (types.WarpModifier, 'object_to'),
    (types.WarpModifier, 'texture'),
    (types.WarpModifier, 'texture_coords_bone'),
    (types.WarpModifier, 'texture_coords_object'),
    (types.WarpModifier, 'uv_layer'),
    (types.WarpModifier, 'vertex_group'),
    (types.WaveModifier, 'start_position_object'),
    (types.WaveModifier, 'texture'),
    (types.WaveModifier, 'texture_coords_bone'),
    (types.WaveModifier, 'texture_coords_object'),
    (types.WaveModifier, 'uv_layer'),
    (types.WaveModifier, 'vertex_group'),
    (types.WeightedNormalModifier, 'vertex_group'),
    (types.WeldModifier, 'vertex_group'),
    (types.WireframeModifier, 'vertex_group'),
)
m.subscribe_attr = subscribe_attr
m.upd_link_data = upd_link_data

msgbus_attrs = (
    ((types.UnitSettings, "system"), m.bus_unit_system),
    ((types.UnitSettings, "length_unit"), m.bus_unit_length),
    ((types.UnitSettings, "scale_length"), m.bus_unit_length),
)
m.msgbus_attrs = msgbus_attrs

def subscribe():
    global is_subscribe
    if is_subscribe is True: return
    is_subscribe = True
    subscribe_rna = bpy.msgbus.subscribe_rna

    for attr in subscribe_attr:
        subscribe_rna(
            key     = attr,
            owner   = attr,
            args    = (),
            notify  = upd_link_data)

    for attr, e in msgbus_attrs:
        subscribe_rna(
            key     = attr,
            owner   = attr,
            args    = (),
            notify  = e)
#
    #
def unsubscribe():
    global is_subscribe
    if is_subscribe is False: return
    is_subscribe = False
    bpy.data.link_mds.clear()
    clear_by_owner = bpy.msgbus.clear_by_owner

    for attr in subscribe_attr:     clear_by_owner(attr)
    for attr, e in msgbus_attrs:    clear_by_owner(attr)

#
    #

def register():
#
    if m.is_publish is False:
        try:
            for r in range(7): register_class(getattr(debug_draw, f"DEBUG_fn_{r}"))
        except: pass

    for cls in classes: register_class(cls)

    if bl_start_up not in bpy.app.handlers.version_update:
        bpy.app.handlers.version_update.append(bl_start_up)
    if bl_new_blend not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(bl_new_blend)
    if local_undo.after_undo not in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.append(local_undo.after_undo)
    if local_undo.before_undo not in bpy.app.handlers.undo_pre:
        bpy.app.handlers.undo_pre.append(local_undo.before_undo)
    if local_undo.after_redo not in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.append(local_undo.after_redo)
    if local_undo.before_redo not in bpy.app.handlers.redo_pre:
        bpy.app.handlers.redo_pre.append(local_undo.before_redo)
    types.BlendData.link_mds = {}
    types.Scene.undo_ind = IntProperty(default=0, options={'HIDDEN'})
    types.WorkSpace.tm_pref = PointerProperty(type=m.PREF)
    types.Object.vpp_offset = FloatVectorProperty(name="Distance", options=set(), subtype="TRANSLATION", unit="LENGTH")

    reg_keymap()
    if is_unreg[0] is True:
#
        init_warning()
    #
def unregister():
#
    for cls in classes: unregister_class(cls)

    if bl_start_up in bpy.app.handlers.version_update:
        bpy.app.handlers.version_update.remove(bl_start_up)
    if bl_new_blend in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(bl_new_blend)
    if local_undo.after_undo in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.remove(local_undo.after_undo)
    if local_undo.before_undo in bpy.app.handlers.undo_pre:
        bpy.app.handlers.undo_pre.remove(local_undo.before_undo)
    if local_undo.after_redo in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.remove(local_undo.after_redo)
    if local_undo.before_redo in bpy.app.handlers.redo_pre:
        bpy.app.handlers.redo_pre.remove(local_undo.before_redo)

    bl_unload(None)
    unreg_keymap()
    m.P = None
    is_unreg[0] = True

addon_keymaps = []
def reg_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        m.cls_ops_kms = [
            mo.OP_MO,
            dr_ed.OP_DR,
            mesh_ed.OP_MESH,
            setting_ed.OP_SETTING,
            light_tool_ed.OP_LIGHT_TOOL,
        ]
        r = 3
        for cls in m.cls_ops_kms:
            km = wm.keyconfigs.addon.keymaps.new(name='Window')
            kmi = km.keymap_items.new(cls.bl_idname, type=f'F1{r}', value='PRESS')
            kmi.properties.use_pos = True
            addon_keymaps.append((km, kmi))
            r += 1
def unreg_keymap():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

if __name__ == "__main__":  register()