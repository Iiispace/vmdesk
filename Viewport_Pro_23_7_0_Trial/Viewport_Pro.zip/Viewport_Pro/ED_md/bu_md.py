import bpy
from bpy.types import CacheFile
from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP
from math import degrees as math_deg
from math import radians as math_rad

from . menu_batch import MESS_BATCH_KF, MESS_BATCH_DR, MESS_BATCH_VAL, MESS_BATCH_VAL2

from .. import m
from .. rm import RM
from .. dd import DDTX, DDVAL, DDTX_RENAME
from .. fn import bin_search, TR_ind, TR_ind_ex, R_str_by_deg, R_str_by_deg_standard, R_str_by_percent, R_str_by_percent_int, R_unit_velocity, R_lib_tuple, R_obj_path_by_full_path, T_set_context_obj, R_lib_name
from .. link_data import MOD_REF_ATTR, R_md_driver_add, R_md_driver_remove, R_id_type, D_rna_blendData
from .. calc import calc_vec
from .. filt import FIL, FIL_TYPE_EXC
from .. det import INFO, DETAILS
from .. ui import color_black, color_white

P = None
F = None
K = None
N = None
BOX = None
BLF = None
RECT = None
font_0 = None

frozenset_empty = frozenset(set())

def TR_fc_by_path(oj, path):
    try:    return oj.animation_data.action.fcurves.find(path)
    except: return None
def TR_dr_by_path(oj, path):
    try:    return oj.animation_data.drivers.find(path)
    except: return None


class BU:
    __slots__ = (
        'w',
        'name',
        'fn',
        'rim',
        'bg',
        'ti',
        'on',
        'off',
        'fo',
        'unfo',
        'draw_ti',
        'offset_y_key',
        'is_enable',
        'offset_x',
        'offset_y',
        'attr',
        'value',
        'color_bg',
        'enable',
        'disable',
        'is_allow',
    )
    def __init__(self, w, name, ti,
        fn              = None,
        offset_y_key    = 4.5,
        free_size       = False,
        attr            = None,
        value           = None,
        ):
        self.color_bg   = P.color_bu_1_off

        self.w      = w
        self.name   = name
        self.fn     = self.setter  if fn is None else fn
        self.attr   = attr
        self.value  = value
        self.rim    = BOX(P.color_bu_1_rim)
        self.bg     = BOX(self.color_bg)

        if free_size is False:
            self.ti = BLF(P.color_font, ti)
            self.draw_ti = self.I_draw_ti
        else:
            self.ti = BLF(P.color_font, ti, free_size)
            self.draw_ti = self.ti.set_draw

        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.unfo       = self.I_off

        self.offset_y_key   = offset_y_key
        self.is_enable      = True
        self.enable         = N
        self.disable        = self.I_disable
        self.is_allow       = True

    def I_disable(self): #soft
#
        self.rim.color  = P.color_bu_1_rim_ignore
        self.color_bg   = P.color_bu_1_ignore
        if self.bg.color == P.color_bu_1_off:
            self.bg.color = self.color_bg
        else:
            self.bg.color = P.color_bu_1_ignore_on
        self.ti.color   = P.color_font_ignore
        self.is_enable  = False
        self.enable     = self.I_enable
        self.disable    = N
        m.redraw()
    def I_enable(self):
#
        self.rim.color  = P.color_bu_1_rim
        self.color_bg   = P.color_bu_1_off
        if self.bg.color == P.color_bu_1_ignore:
            self.bg.color = self.color_bg
        else:
            self.bg.color = P.color_bu_1_on
        self.ti.color   = P.color_font
        self.is_enable  = True
        self.enable     = N
        self.disable    = self.I_disable
        m.redraw()

    def LTwh(self, L, T, w, h): # must blf_size
        rim = self.rim
        bg  = self.bg
        ti  = self.ti

        rim.LTwh(L, T, w, h)
        rim.upd()

        if bg.color == P.color_bu_1_on:
            bg.LRBT(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        else:
            bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])

        bg.upd()
        ti.set_x_by_bo_float(bg)
        self.offset_x   = ti.x - bg.L
        self.offset_y   = F[self.offset_y_key]
        ti.y            = bg.B + self.offset_y
    def LRBT(self, L, R, B, T):
        rim = self.rim
        bg  = self.bg
        ti  = self.ti
        _1  = F[1]

        rim.LRBT_upd(L, R, B, T)

        if bg.color == P.color_bu_1_on:
            bg.LRBT(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        else:
            bg.LRBT(rim.L + F[1], rim.R, rim.B, rim.T - F[1])

        bg.upd()
        ti.set_x_by_bo_float(bg)
        self.offset_x   = ti.x - bg.L
        self.offset_y   = F[self.offset_y_key]
        ti.y            = bg.B + self.offset_y

    def next_bu(self, b, wi):
        rim = b.rim
        L = rim.R + F[2]
        self.LRBT(L, L + wi, rim.B, rim.T)
    def before_bu(self, b, wi):
        rim = b.rim
        R = rim.L - F[2]
        self.LRBT(R - wi, R, rim.B, rim.T)
    def below_bu(self, b, h):
        rim = b.rim
        T = rim.B - F[2]
        self.LRBT(rim.L, rim.R, T - h, T)

    def ti_align_L(self, e):
        self.offset_x = e.offset_x
        self.ti.x = self.bg.L + self.offset_x
    def ti_offset_x_set(self, x):
        self.offset_x = x
        self.ti.x = self.bg.L + x

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bg.dxy_upd(x, y)
        self.ti.dxy(x, y)

    def setter(self):
        v = getattr(self.w.w.act_md, self.attr)
        if isinstance(v, set):
            if self.value in v: v.remove(self.value)
            else:               v.add(self.value)
        else:
            if v == self.value: return True
            v = self.value

        try:
            setattr(self.w.w.act_md, self.attr, v)
            m.undo_str = f'[Modifier Editor] md.{self.attr} = "{v}"'
        except: pass

    def I_on(self):
        rim = self.rim
        bg  = self.bg

        bg.color = P.color_bu_1_on  if self.is_enable is True else P.color_bu_1_ignore_on
        bg.LRBT_upd(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
        self.ti.LB(bg, self.offset_x, self.offset_y)

        self.on     = N
        self.off    = self.I_off
        self.fo     = N
        self.unfo   = self.I_on
    def I_off(self):
        rim = self.rim
        bg  = self.bg

        bg.color = self.color_bg
        bg.LRBT_upd(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = self.I_on
        self.off    = N
        self.fo     = self.I_fo
        self.unfo   = self.I_off
    def I_fo(self):
        rim = self.rim
        bg  = self.bg

        if self.is_enable is True:  bg.color = P.color_bu_1_fo
        bg.LRBT_upd(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        self.ti.LB(bg, self.offset_x, self.offset_y)
        self.on     = self.I_on
        self.off    = self.I_off
        self.fo     = N

    def draw_bg(self):
        self.rim.bind_draw()
        self.bg.bind_draw()
    def I_draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()

    def inside(self, evt):
        self.is_allow = True
        self.fo()
        self.w.U_modal = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def to_outside(self):
        self.unfo()
        m.redraw()
        self.w.U_modal = self.w.default_modal
    def is_to_outside(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.unfo()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return True
        return False

    def I_modal_fo(self, evt):
        if self.is_to_outside(evt): return

        if evt.value == 'RELEASE': self.is_allow = True
        if K["bu_insert_kf0"].true() or K["bu_insert_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Insert_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_kf0"].true() or K["bu_del_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Delete_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_clear_kf0"].true() or K["bu_clear_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Clear_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_dr0"].true() or K["bu_add_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_Driver()
            m.EVT.kill()
            self.to_outside()
            return True
        if K["bu_del_dr0"].true() or K["bu_del_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Delete_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp0"].true() or K["bu_dp1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Data_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_full0"].true() or K["bu_dp_full1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Full_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_paste0"].true() or K["bu_dp_paste1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Paste_Full_Path_to_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_keying_set0"].true() or K["bu_add_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_to_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_keying_set0"].true() or K["bu_del_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Remove_from_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Reset_to_Default_Value()
            m.EVT.kill_except(evt)
            return True
        if K["bu_batch_kf0"].true() or K["bu_batch_kf1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Keyframe_Batch()
            self.to_outside()
            return True
        if K["bu_batch_dr0"].true() or K["bu_batch_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Driver_Batch()
            self.to_outside()
            return True
        if K["bu_batch_value0"].true() or K["bu_batch_value1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Value_Batch()
            self.to_outside()
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            if self.is_allow:
                self.w.RET = True
                self.is_allow = False
                if self.fn() is True: return True
                m.undo_push()
                return True
        if K["rm0"].true() or K["rm1"].true():
            self.w.RET = True
            self.rm_init(evt)
            self.to_outside()
            return True

    def R_oo_dr(self): return self.w.oo_dr[self.attr]
    def rm_init(self, evt):
        self.R_oo_dr().rm_init(evt, override={
            "title": self.ti.text
        })
    #
    #


class BUBL:
    __slots__ = (
        'w',
        'name',
        'attr',
        'da_color',
        'da_color_ignore',
        'offset_x_key',
        'offset_y_key',
        'rim',
        'da',
        'on',
        'off',
        'fo',
        'enable',
        'disable',
        'inside',
        'is_enable',
        'offset_x',
        'offset_y',
        'U_fn',
        'free_fn',
    )
    def __init__(self, w, name, attr, offset_x_key = 1.5, offset_y_key = 0, fn=None):
        self.w      = w
        self.name   = name
        self.attr   = attr

        self.da_color           = P.color_bu_2
        self.da_color_ignore    = P.color_bu_2_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.free_fn    = fn

    def LTwh(self, L, T, w, h):
        rim = self.rim
        rim.LTwh(L, T, w, h)
        rim.upd()
        self.offset_x   = F[self.offset_x_key]
        self.offset_y   = F[self.offset_y_key]
        self.da.LB(self.rim, self.offset_x, self.offset_y)
    def LRBT(self, L, R, B, T):
        rim = self.rim
        rim.LRBT_upd(L, R, B, T)
        self.offset_x   = F[self.offset_x_key]
        self.offset_y   = F[self.offset_y_key]
        self.da.LB(rim, self.offset_x, self.offset_y)

    def right_dr(self, dr, w, d = 10):
        L = dr.rim.R + F[d] - F[4]
        self.LRBT(L, L + w, dr.rim.B, dr.rim.T)

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)

    def I_on(self):
        self.rim.color  = P.color_bu_3_on
        self.on         = N
        self.off        = self.I_off
        self.fo         = self.I_fo
    def I_off(self):
        self.rim.color  = P.color_bu_3_off
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        if hasattr(self, "is_cursor_changed") and self.is_cursor_changed is True:
            m.M.set_mou_ic('DEFAULT')
    def I_fo(self):
        self.rim.color  = P.color_bu_3_fo
        self.on         = self.I_on
        self.off        = self.I_off
        self.fo         = N

    def I_enable(self):
        self.is_enable  = True
        self.inside     = self.I_inside
        self.da.color   = self.da_color
        self.I_off()
        self.enable     = N
        self.disable    = self.I_disable
    def I_disable(self, soft=True):
        self.is_enable  = False
        if soft is False:   self.inside = N
        self.rim.color  = P.color_bu_3_ignore
        self.da.color   = self.da_color_ignore
        self.enable     = self.I_enable
        self.disable    = N
        self.on         = N
        self.off        = N
        self.fo         = N

    def draw_rim(self): pass
    def draw_bg(self):  self.rim.bind_draw()
    def draw_ti(self):  self.da.draw_color_pos()

    def set_da(self, boo):
        if self.da.name != boo:
            self.da.name = boo
            self.da.text = "■"  if boo else ""

    def fn(self):
        self.U_fn   = N
        if self.free_fn is not None:    self.free_fn() ;return

        act_md      = self.w.w.act_md

        if getattr(act_md, self.attr):
            self.da.text = ""
            self.da.name = False
            setattr(act_md, self.attr, False)
            m.undo_str = f'[Modifier Editor] md.{self.attr} = False'
        else:
            self.da.text = "■"
            self.da.name = True
            setattr(act_md, self.attr, True)
            m.undo_str = f'[Modifier Editor] md.{self.attr} = True'
        m.undo_push()

    def I_inside(self, evt):
        self.fo()
        self.U_fn       = self.fn
        self.w.U_modal  = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def to_outside(self):
        self.off()
        m.redraw()
        self.w.U_modal = self.w.default_modal
    def is_to_outside(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return True
        return False

    def I_modal_fo(self, evt):
        if self.is_to_outside(evt): return

        if evt.value == 'RELEASE':  self.U_fn = self.fn
        if K["bu_insert_kf0"].true() or K["bu_insert_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Insert_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_kf0"].true() or K["bu_del_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Delete_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_clear_kf0"].true() or K["bu_clear_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Clear_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_dr0"].true() or K["bu_add_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_Driver()
            m.EVT.kill()
            self.to_outside()
            return True
        if K["bu_del_dr0"].true() or K["bu_del_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Delete_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp0"].true() or K["bu_dp1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Data_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_full0"].true() or K["bu_dp_full1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Full_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_paste0"].true() or K["bu_dp_paste1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Paste_Full_Path_to_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_keying_set0"].true() or K["bu_add_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_to_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_keying_set0"].true() or K["bu_del_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Remove_from_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Reset_to_Default_Value()
            m.EVT.kill_except(evt)
            return True
        if K["bu_batch_kf0"].true() or K["bu_batch_kf1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Keyframe_Batch()
            self.to_outside()
            return True
        if K["bu_batch_dr0"].true() or K["bu_batch_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Driver_Batch()
            self.to_outside()
            return True
        if K["bu_batch_value0"].true() or K["bu_batch_value1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Value_Batch()
            self.to_outside()
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.w.RET = True
            self.U_fn()
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.w.RET = True
            self.rm_init(evt)
            self.to_outside()
            return True

    def R_oo_dr(self): return self.w.oo_dr[self.attr]
    def rm_init(self, evt):
#
        self.R_oo_dr().rm_init(evt)
class BUTX(BUBL):
    __slots__ = (
        'fil',
        'is_str',
        'update_filter',
        'bpy_setter',
        'fns',
        'ti',
        'ti_L',
    )
    def __init__(self, w, name, attr, fil,
            offset_x_key    = 5.1,
            offset_y_key    = 5.1,
            is_str          = False,
            update_filter   = None,
            bpy_setter      = None,
            fns             = None,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.fil    = fil

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key
        self.is_str             = is_str
        self.update_filter      = update_filter

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.bpy_setter = self.I_bpy_setter  if bpy_setter is None else bpy_setter
        self.fns        = fns
        if fns is None:
            self.ti = {}
        else:
            self.ti = {"x": BLF(P.color_font_darker, "✕", F[15])}
            if "pick" in fns:   self.ti["pick"] = BLF(P.color_font_darker, "⊕", F[10])

    def I_enable(self):
        self.is_enable  = True
        self.inside     = self.I_inside
        self.da.color   = self.da_color
        self.I_off()
        self.enable     = N
        self.disable    = self.I_disable
        if self.ti:
            for e in self.ti.values():  e.color = P.color_font_darker
    def I_disable(self, soft=True):
        self.is_enable  = False
        if soft is False:   self.inside = N
        self.rim.color  = P.color_bu_3_ignore
        self.da.color   = self.da_color_ignore
        self.enable     = self.I_enable
        self.disable    = N
        self.on         = N
        self.off        = N
        self.fo         = N
        if self.ti:
            for e in self.ti.values():  e.color = self.da_color_ignore

    def set_da(self, s):
        if self.da.name != s:
            blf_size(font_0, F[9])
            self.da.name = self.da.text = s
            if self.ti:
                self.da.fix_long_text(self.ti_L[-1][1] - F[12], F[8])
            else:
                self.da.fix_long_text(self.rim.R - F[12], F[8])
    def setter(self):
        attr = getattr(self.w.w.act_md, self.attr)
        if self.is_str:
            self.set_da(attr)
            return

        if isinstance(self.update_filter, dict):
            self.set_da(self.update_filter[attr] if attr in self.update_filter else attr)
            return

        if attr == None:    self.set_da("")
        else:               self.set_da(attr.name)
    def I_bpy_setter(self, s, undo_push=True):
        if isinstance(self.update_filter, dict):
            try:
                if s in self.update_filter: pass
                else:
                    dict_rev = {e: k for k, e in self.update_filter.items()}
                    if s in dict_rev: s = dict_rev[s]

                setattr(self.w.w.act_md, self.attr, s)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{self.attr} = {s}'
                    m.undo_push()
                    m.power_upd()
            except: pass
            return

        try:
            if self.is_str:
                setattr(self.w.w.act_md, self.attr, s)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{self.attr} = "{s}"'
                    m.undo_push()
                    m.power_upd()
                return

            if s == "":
                setattr(self.w.w.act_md, self.attr, None)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{self.attr} = None'
                    m.undo_push()
                    m.power_upd()
            else:
                bpy_type = self.fil.bpy_type
                collection = eval(bpy_type) if isinstance(bpy_type, str) else bpy_type
                tar = collection[R_lib_tuple(collection, s)]
                setattr(self.w.w.act_md, self.attr, tar)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{self.attr} ▶ {getattr(tar, "name", tar)}'
                    m.undo_push()
                    m.power_upd()
        except: pass

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        self.da.dxy(x, y)
        if self.ti:
            for e in self.ti.values():  e.dxy(x, y)
            for e in self.ti_L:  e[1] += x
    def draw_ti(self):
        self.da.draw_color_pos()
        if self.ti:
            for e in self.ti.values():  e.set_draw()
            blf_size(font_0, F[9])

    def fn(self, ind=None):
        if ind is None:
            if isinstance(self.update_filter, str):
                try:
                    new_li = eval(self.update_filter)
                except:
                    new_li = []
                self.fil.bpy_type = new_li

            def end_fn():   self.is_to_outside(m.EVT.evt)

            DDTX(self, self.fil, tx_clear=self.fil is not None, end_fn=end_fn)
        else:
            self.fns[ind]()
    def fn_copy(self):
#
        bpy.context.window_manager.clipboard = f"{self.da.name}"
    def fn_paste(self):
#
        self.bpy_setter(bpy.context.window_manager.clipboard)

    def to_outside(self):
        self.off()
        if self.ti and self.is_enable is True:
            for e in self.ti.values():
                if e.color != P.color_font_darker:
                    m.redraw()
                    e.color = P.color_font_darker
        m.redraw()
        self.w.U_modal = self.w.default_modal
    def is_to_outside(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            if self.ti and self.is_enable is True:
                for e in self.ti.values():
                    if e.color != P.color_font_darker:
                        m.redraw()
                        e.color = P.color_font_darker
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return True
        return False
    def I_modal_fo(self, evt):
        if self.is_to_outside(evt): return

        ind = None
        if self.ti:
            x = evt.mouse_region_x
            for k, e in self.ti_L:
                if x >= e:
                    ind = k
                    break

            if self.is_enable is True:
                if ind is None or evt.value == "PRESS":
                    for e in self.ti.values():
                        if e.color != P.color_font_darker:
                            m.redraw()
                            e.color = P.color_font_darker
                else:
                    for k, e in self.ti.items():
                        if k == ind:
                            if e.color != P.color_font:
                                m.redraw()
                                e.color = P.color_font
                        else:
                            if e.color != P.color_font_darker:
                                m.redraw()
                                e.color = P.color_font_darker

        if evt.value == 'RELEASE':  self.U_fn = self.fn
        if K["bu_add_dr0"].true() or K["bu_add_dr1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Add_Driver()
            m.EVT.kill()
            self.to_outside()
            return True
        if K["bu_del_dr0"].true() or K["bu_del_dr1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Delete_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp0"].true() or K["bu_dp1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Copy_Data_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_full0"].true() or K["bu_dp_full1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Copy_Full_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_paste0"].true() or K["bu_dp_paste1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Paste_Full_Path_to_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Reset_to_Default_Value()
            m.EVT.kill_except(evt)
            return True
        if K["bu_batch_kf0"].true() or K["bu_batch_kf1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Keyframe_Batch()
            self.to_outside()
            return True
        if K["bu_batch_dr0"].true() or K["bu_batch_dr1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Driver_Batch()
            self.to_outside()
            return True
        if K["bu_batch_value0"].true() or K["bu_batch_value1"].true():
            self.w.RET = True
            self.R_oo_dr(evt).fn_Value_Batch()
            self.to_outside()
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.w.RET = True
            self.U_fn()  if ind is None else self.U_fn(ind)
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.w.RET = True
            self.rm_init(evt)
            self.to_outside()
            return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.w.RET = True
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.w.RET = True
            self.fn_paste()
            return True
    def R_oo_dr(self, evt):
        oo_dr = self.w.oo_dr
        if self.attr in oo_dr:
            bu_dr = oo_dr[self.attr]
        else:
            bu_dr = BUDR(self.w, "", f"{self.attr}".title(), self.attr, is_ref_driver=True)
            x = evt.mouse_region_x
            y = evt.mouse_region_y
            bu_dr.rim.LRBT(x, x, y, y)
            if f"bu_{self.attr}" in self.w.oo:
                bu_dr.ti.color = self.w.oo[f"bu_{self.attr}"].ti.color
        return bu_dr
    def rm_init(self, evt):
#
        self.R_oo_dr(evt).rm_init(evt)
    #
    #
class BUTXMIX(BUTX):
    __slots__ = ()
    def setter(self):
        v = getattr(self.w.w.act_md, self.attr)

        dic, s = self.update_filter
        try:    l = eval(s)
        except: l = []

        if v in l: pass
        elif v in dic: v = dic[v]

        self.set_da(v)
        #
    def I_bpy_setter(self, s, undo_push=True):
        if s:
            if s[0] == "=":
                s = s[1:]
                if s in self.update_filter[0]:
                    try:    l = eval(self.update_filter[1])
                    except: l = []
                    if l and s in l:
                        e = l[s]
                        old_name = e.name
                        e.name = f'{old_name}_'
                        is_success = True
                        try:    setattr(self.w.w.act_md, self.attr, e.name)
                        except: is_success = False
                        e.name = old_name
                        if is_success and undo_push:
                            m.undo_str = f'[Modifier Editor] md.{self.attr} = {s}'
                            m.undo_push()
                            m.power_upd()
                        return
            else:
                dic = {e: k for k, e in self.update_filter[0].items()}
                if s in dic: s = dic[s]

            try:
                setattr(self.w.w.act_md, self.attr, s)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{self.attr} = {s}'
                    m.undo_push()
                    m.power_upd()
            except: pass
        else: return
        #
    def fn(self):
        dic, s = self.update_filter
        try:    l = eval(s)
        except: l = []

        if l:
            NAME = m.NAME
            li = [e for e in self.fil.bpy_type] + [NAME(f'={e.name}') for e in l]
        else:
            li = self.fil.bpy_type
        DDTX(self, FIL_TYPE_EXC(li), tx_clear=True)
    #
    #
class BUFL(BUBL):
    __slots__ = (
        'ty',
        'tx_format',
        'bpy_setter',
        'key_end',
        'key_slow',
        'key_fast',
        'R_qe_dx',
        'qe_value',
        'qe_org',
        'qe_unit',
        'qe_unit_slow',
        'qe_unit_fast',
        'qe_fn',
        'qe_bu',
        'unit',
        'step',
        'is_cursor_changed',
    )
    def __init__(self,
            w,
            name,
            attr,
            offset_x_key    = 5.1,
            offset_y_key    = 4.9,
            ty              = "float [-∞,∞]"
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.ty     = ty

        prop = w.props[attr]
        self.is_cursor_changed = False

        if ty[0:3] == 'int':
            self.bpy_setter     = self.I_bpy_setter_int
            self.tx_format      = R_str_by_deg  if self.__class__ == BUFD else m.U_format_i
            self.unit = 0
            self.step = 1.0
        else:
            self.step = prop.step / 100.0
            if self.__class__ == BUFD:
                self.tx_format = R_str_by_deg
                self.unit = 0
            else:
                u = prop.unit
                if u in {"LENGTH", "VELOCITY"}:
                    self.tx_format = m.U_FORMAT_F
                    self.unit = 1
                elif u == "AREA":
                    self.tx_format = m.U_FORMAT_F2
                    self.unit = 2
                elif u == "VOLUME":
                    self.tx_format = m.U_FORMAT_F3
                    self.unit = 3
                else:
                    self.tx_format = m.U_format_f
                    self.unit = 0

            self.bpy_setter     = self.I_bpy_setter

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True

    def R_unit_fac(self):
        u = self.unit
        if u == 0:      return 1.0
        if u == 1:      return m.unit_length_fac
        elif u == 2:    return m.unit_length_fac2
        elif u == 3:    return m.unit_length_fac3
        return 1.0
    def R_bpy_value(self):  return getattr(self.w.w.act_md, self.attr)
    def do_step(self, flo): self.bpy_setter(self.R_bpy_value() + flo)
    def set_da(self, flo):
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def setter(self):
        flo = getattr(self.w.w.act_md, self.attr)
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def I_bpy_setter(self, flo, undo_push=True):
        setattr(self.w.w.act_md, self.attr, flo)
        if undo_push:
            m.undo_str = f'[Modifier Editor] md.{self.attr} = {flo}'
            m.undo_push()
    def I_bpy_setter_int(self, flo, undo_push=True):
        v = round(flo)
        setattr(self.w.w.act_md, self.attr, v)
        if undo_push:
            m.undo_str = f'[Modifier Editor] md.{self.attr} = {v}'
            m.undo_push()

    def fn(self, multi_edit=None):
        if self.da.name is None: return
        try:    subtype = self.w.props[self.attr].subtype
        except: subtype = "NONE"
        override_ty = "calc_0pf"  if subtype in {'ANGLE', 'EULER', 'AXISANGLE'} else None
        DDVAL(self, self.ty, multi_edit=multi_edit, end_fn=m.refresh, override_ty=override_ty)
    def fn_copy(self):
        try:
#
            v = self.da.name
            fac = self.R_unit_fac()
            if fac != 1.0:  v /= fac
            bpy.context.window_manager.clipboard = m.R_str_by_float(v) if isinstance(v, float) else f"{v}"
        except: pass
    def fn_paste(self):
        try:
#
            vv = calc_vec(bpy.context.window_manager.clipboard)
            v = vv[0]
            fac = self.R_unit_fac()
            if fac != 1.0:  v *= fac
            self.bpy_setter(v)
        except: pass
    def fn_cut(self):
        self.fn_copy()
    def R_dp(self):
        return f'modifiers["{self.w.w.act_md.name}"].{self.attr}'
    def driver_add(self, exp = ""):
        dp = self.R_dp()
        oj = self.w.w.oj
#
        dr = oj.animation_data.drivers.find(dp)  if oj.animation_data else None
        if dr is None:  dr = oj.driver_add(dp)
        else:           dr.driver.type = 'SCRIPTED'
        dr.driver.expression = exp
        P.refresh = True
        m.undo_str = f'[Modifier Editor] driver.expression = {exp}'
        m.undo_push()

    def to_outside(self):
        self.off()
        m.redraw()
        self.w.U_modal = self.w.default_modal
    def is_to_outside(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.off()
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return True
        return False

    def I_modal_fo(self, evt):
        if self.is_to_outside(evt): return

        if self.is_enable is True:
            if evt.mouse_region_x <= self.rim.L + F[16]:
                self.is_cursor_changed = True
                m.M.set_mou_ic('SCROLL_X')
            elif evt.mouse_region_x >= self.rim.R - F[16]:
                self.is_cursor_changed = True
                m.M.set_mou_ic('SCROLL_X')
            elif self.is_cursor_changed is True:
                self.is_cursor_changed = False
                m.M.set_mou_ic('DEFAULT')

        if K["bu_insert_kf0"].true() or K["bu_insert_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Insert_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_kf0"].true() or K["bu_del_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Delete_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_clear_kf0"].true() or K["bu_clear_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Clear_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_dr0"].true() or K["bu_add_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_Driver()
            m.EVT.kill()
            self.to_outside()
            return True
        if K["bu_del_dr0"].true() or K["bu_del_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Delete_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp0"].true() or K["bu_dp1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Data_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_full0"].true() or K["bu_dp_full1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Full_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_paste0"].true() or K["bu_dp_paste1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Paste_Full_Path_to_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_keying_set0"].true() or K["bu_add_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_to_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_keying_set0"].true() or K["bu_del_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Remove_from_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Reset_to_Default_Value()
            m.EVT.kill_except(evt)
            return True
        if K["bu_batch_kf0"].true() or K["bu_batch_kf1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Keyframe_Batch()
            self.to_outside()
            return True
        if K["bu_batch_dr0"].true() or K["bu_batch_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Driver_Batch()
            self.to_outside()
            return True
        if K["bu_batch_value0"].true() or K["bu_batch_value1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Value_Batch()
            self.to_outside()
            return True
        if K["bu_qe0"].true():
#
            self.w.RET = True
            self.key_end = K["bu_qe_E0"]
            self.to_modal_qe(evt, K["bu_qe0"])
            return True
        if K["bu_qe1"].true():
#
            self.w.RET = True
            self.key_end = K["bu_qe_E1"]
            self.to_modal_qe(evt, K["bu_qe1"])
            return True
        if K["bu_sel0"].true() or K["bu_sel1"].true():
            self.w.RET = True
            if self.is_cursor_changed is True:
                if evt.mouse_region_x <= self.rim.L + F[16]:
                    self.do_step(-self.step)
                else:
                    self.do_step(self.step)
                return True
            self.fn()
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.w.RET = True
            self.rm_init(evt)
            self.to_outside()
            return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.w.RET = True
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.w.RET = True
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            self.w.RET = True
            self.fn_cut()
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            try:
                self.w.oo_dr[self.attr].fn_Reset_to_Default_Value()
#
            except:
                pass
#
            return True
        if K["bu_left0"].true() or K["bu_left1"].true():
            self.w.RET = True
            self.do_step(-self.step)
            return True
        if K["bu_right0"].true() or K["bu_right1"].true():
            self.w.RET = True
            self.do_step(self.step)
            return True
        if K["bu_up0"].true() or K["bu_up1"].true():
            self.w.RET = True
            self.do_step(10*self.step)
            return True
        if K["bu_down0"].true() or K["bu_down1"].true():
            self.w.RET = True
            self.do_step(-10*self.step)
            return True

    def rm_init(self, evt):
#
        self.w.oo_dr[self.attr].rm_init(evt)

    def is_alt(self, evt):    return evt.alt
    def is_ctrl(self, evt):   return evt.ctrl
    def is_shift(self, evt):  return evt.shift
    def is_oskey(self, evt):  return evt.oskey
    def NF(self, evt):        return False
    def IR_dx(self):    return m.dx
    def IR_dy(self):    return m.dy
    def to_modal_qe(self, evt, mk=None):
#
        if self.da.name is None: return
        self.w.RET = True
        self.key_end.true()
        m.upd_disable()

        r = m.region_data
        m.get_loop_mou_info_region(evt, r.L, r.R, r.B, r.T)
        m.get_mou(evt)
        tm = m.tm
        tm["x"] = evt.mouse_x
        tm["y"] = evt.mouse_y
        tm["bu"] = self
        try:    m.M.set_mou_ic(P.quick_edit_cursor)
        except: pass

        self.R_qe_dx = self.IR_dx if P.quick_edit_method == 'HORIZONTAL' else self.IR_dy
        dic = m.dic_hold_key
        slow0 = K["bu_qe_slow0"].type0
        self.key_slow = getattr(self, f"is_{dic[slow0]}") if slow0 in dic else self.NF
        fast0 = K["bu_qe_fast0"].type0
        self.key_fast = getattr(self, f"is_{dic[fast0]}") if fast0 in dic else self.NF

        if P.quick_edit_operation == 'REAL_TIME':
            if self.ty[0] == "i":
                self.qe_fn = self.I_qe_real_time_int
            else:
                self.qe_fn = self.I_qe_real_time_float
        else:
            if self.ty[0] == "i":
                self.qe_fn = self.I_qe_performance_int
            else:
                self.qe_fn = self.I_qe_performance_float

        self.qe_value   = self.da.name
        self.qe_org     = self.qe_value
        self.qe_unit = getattr(P, f'{m.R_calc_attr(self.ty)}qe')
        self.qe_unit_slow = P.quick_edit_fac_slow * self.qe_unit
        self.qe_unit_fast = P.quick_edit_fac_fast * self.qe_unit
        self.qe_bu = self

        tm["is_quick_edit"] = {"state": 0}
        if self.is_to_modal_multi(evt, mk): return

        m.head_modal.append(self.I_modal_qe)
    def is_to_modal_multi(self, evt, mk): return False
    def modal_qe_end(self, cancel=False):
#
        del m.head_modal[-1]
        tm = m.tm
        tm["is_quick_edit"].clear()
        tm["is_quick_edit"]["state"] = -1
        m.EVT.kill()
        m.I_end_pan_hide(self)

        self.w.to_default_modal()

        if cancel:
            m.upd_enable()
            if isinstance(self.qe_org, list):
                oo = self.array
                for e in oo:    e.I_off()

                ind = tm["bu_range"][0]
                for e in self.qe_org:
                    o = oo[ind]
                    o.da.name = None
                    o.bpy_setter(e, undo_push=False)
                    ind += 1
            else:
                self.off()
                self.da.name = None
                self.bpy_setter(self.qe_org, undo_push=False)
            m.refresh()
            del tm["is_quick_edit"]
            return

        if isinstance(self.qe_org, list):
            oo = self.array
            for e in oo:
                e.I_off()
                e.da.name = None
            self.bpy_setter([self.qe_value] * (tm["bu_range"][1] - tm["bu_range"][0]), tm["bu_range"])
        else:
            self.off()
            self.bpy_setter(self.qe_value)

        self.da.name = None
        m.upd_enable()
        m.refresh()
        del tm["is_quick_edit"]
        #
    def I_modal_qe(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_qe_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_qe_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_qe_end()
                return

        m.I_pan(evt)
        if self.key_slow(evt):      self.qe_fn(self.R_qe_dx() * self.qe_unit_slow)
        elif self.key_fast(evt):    self.qe_fn(self.R_qe_dx() * self.qe_unit_fast)
        else:                       self.qe_fn(self.R_qe_dx() * self.qe_unit)
        m.loop_mou(evt)
    def I_qe_performance_float(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_performance_int(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(round(self.qe_value))
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        setattr(self.w.w.act_md, self.attr, self.qe_value)
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_real_time_int(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        setattr(self.w.w.act_md, self.attr, v)
        self.da.text = self.tx_format(v)
class BUFD(BUFL):
    __slots__ = ()
    def do_step(self, flo): self.bpy_setter(math_deg(self.R_bpy_value()) + flo)
    def set_da(self, flo):
        deg = math_deg(flo)
        if self.da.name != deg:
            self.da.name = deg
            self.da.text = self.tx_format(deg)
    def setter(self):
        deg = math_deg(getattr(self.w.w.act_md, self.attr))
        if self.da.name != deg:
            self.da.name = deg
            self.da.text = self.tx_format(deg)
    def I_bpy_setter(self, flo, undo_push=True):
        flo = math_rad(flo)
        setattr(self.w.w.act_md, self.attr, flo)
        if undo_push:
            m.undo_str = f'[Modifier Editor] md.{self.attr} = {flo}'
            m.undo_push()

    def fn(self, multi_edit=None):
        if self.da.name is None: return
        DDVAL(self, self.ty, multi_edit=multi_edit, end_fn=m.refresh, override_ty="calc_0df")

    def I_qe_performance_float(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_performance_int(self, dx):
        pass
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        setattr(self.w.w.act_md, self.attr, math_rad(self.qe_value))
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_real_time_int(self, dx):
        pass
    #
    #
class BUFLS(BUFL):
    __slots__ = "index", "array", "multi_oo"
    def R_array(self): return self.array
    def R_bpy_value(self):  return getattr(self.w.w.act_md, self.attr)[self.index]
    def setter(self):
        flo = getattr(self.w.w.act_md, self.attr)[self.index]
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def I_bpy_setter(self, flo, bu_range=None, undo_push=True):
        lis = getattr(self.w.w.act_md, self.attr)
        if bu_range is None:
            lis[self.index] = flo
            if undo_push:
                m.undo_str = f'[Modifier Editor] md.{self.attr}[{self.index}] = {flo}'
                m.undo_push()
        else:
            i0, i1 = bu_range
            lis[i0 : i1] = flo
            if undo_push:
                m.undo_str = f'[Modifier Editor] md.{self.attr}[{bu_range[0]}:{bu_range[1]}] = {flo}'
                m.undo_push()
    def I_bpy_setter_int(self, flo, bu_range=None, undo_push=True):
        lis = getattr(self.w.w.act_md, self.attr)
        if bu_range is None:
            flo = round(flo)
            lis[self.index] = flo
            if undo_push:
                m.undo_str = f'[Modifier Editor] md.{self.attr}[{self.index}] = {flo}'
                m.undo_push()
        else:
            i0, i1 = bu_range
            lis[i0 : i1] = [round(e) for e in flo]
            if undo_push:
                m.undo_str = f'[Modifier Editor] md.{self.attr}[{bu_range[0]}:{bu_range[1]}] = {flo}'
                m.undo_push()
    def driver_add(self, exp = ""):
        dp = self.R_dp()
        oj = self.w.w.oj
#
        dr = oj.animation_data.drivers.find(dp, index=self.index)  if oj.animation_data else None
        if dr is None:  dr = oj.driver_add(dp, index=self.index)
        else:           dr.driver.type = 'SCRIPTED'
        dr.driver.expression = exp
        P.refresh = True
        m.undo_str = f'[Modifier Editor] driver.expression = {exp}'
        m.undo_push()

    def is_to_modal_multi(self, evt, mk):
        try:
            org_y = mk.org_y
            dx = evt.mouse_x - mk.org_x
            dy = evt.mouse_y - org_y
            if abs(dy) > abs(dx):
                org_y += evt.mouse_region_y - evt.mouse_y
                multi_oo = tuple((i, e) for i, e in enumerate(self.array))
                self.multi_oo = multi_oo

                for i, e in multi_oo:
                    if org_y >= e.rim.B:
                        self.qe_bu = e
                        self.qe_value   = e.da.name
                        self.qe_org     = self.qe_value
                        break

                ind = self.qe_bu.index

                m.tm["ind"] = [ind, multi_oo[-1][1].rim.B, multi_oo[0][1].rim.T, evt.mouse_region_y, ind]
                m.head_modal.append(self.I_modal_multi)
                return True
            return False
        except:
            return False
        #
    def modal_multi_end(self, cancel=False):
#
        del m.head_modal[-1]
        m.upd_enable()
        oo = self.array

        if cancel:
            m.EVT.kill()
            m.I_end_pan_hide(self)
        else:
            tm_ind = m.tm["ind"]
            ind_org = tm_ind[0]
            i = tm_ind[4]
            if ind_org > i: ind_org, i = i, ind_org
            tm_ind.clear()
            m.tm["ind"] = [oo[r] for r in range(ind_org, i)]
            tm_ind = m.tm["ind"]
            qe_bu = oo[i]
            self.qe_bu = qe_bu
            self.qe_org = [e.da.name for e in tm_ind]
            self.qe_value = qe_bu.da.name
            self.qe_org.append(self.qe_value)
            for e in tm_ind:
                e.da.name = None
                e.da.text = "     Multiple Editing"

            m.tm["bu_range"] = (ind_org, i + 1)
            qe_bu.fn(multi_edit="custom")

        for e in oo:    e.I_off()
        self.w.to_default_modal()
        #
    def I_modal_multi(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_multi_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_multi_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_multi_end()
                return

        m.I_pan(evt)
        tm_ind = m.tm["ind"]

        if abs(evt.mouse_region_x - m.tm["x"]) >= P.th_multi_drag:
#
            m.loop_mou(evt)
            oo = self.R_array()
            ind_org = tm_ind[0]
            i = tm_ind[4]
            if ind_org > i: ind_org, i = i, ind_org
            tm_ind.clear()
            m.tm["ind"] = [oo[r] for r in range(ind_org, i)]
            self.qe_bu = oo[i]
            self.qe_org = [e.da.name for e in m.tm["ind"]]
            self.qe_value = self.qe_bu.da.name
            self.qe_org.append(self.qe_value)
            m.tm["bu_range"] = (ind_org, i + 1)

            if P.quick_edit_operation == 'REAL_TIME':
                if self.ty[0] == "i":
                    self.qe_fn = self.I_qe_real_time_int_multi
                else:
                    self.qe_fn = self.I_qe_real_time_float_multi
            else:
                if self.ty[0] == "i":
                    self.qe_fn = self.I_qe_performance_int_multi
                else:
                    self.qe_fn = self.I_qe_performance_float_multi

            del m.head_modal[-1]
            m.tm["bu"] = self.qe_bu
            m.head_modal.append(self.I_modal_qe_multi if m.tm["ind"] else self.I_modal_qe)
            return

        ind_org, B, T, old_y, ind = tm_ind
        tm_ind[3] = min(max(B, old_y + m.dy), T)
        y = tm_ind[3]

        for i, e, in self.multi_oo:
            if y >= e.rim.B:
                tm_ind[4] = i
                if ind_org > i: ind_org, i = i, ind_org
                color_off = P.color_bu_3_off
                color_fo = P.color_bu_3_fo
                for i0, e0 in self.multi_oo:
                    e0.rim.color = color_fo if ind_org <= i0 <= i else color_off
                break

        m.loop_mou(evt)

    def I_qe_performance_float_multi(self, dx):
        self.qe_value += dx
        tx = self.qe_bu.tx_format(self.qe_value)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.da.text = tx
        #
    def I_qe_performance_int_multi(self, dx):
        self.qe_value += dx
        tx = self.qe_bu.tx_format(round(self.qe_value))
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.da.text = tx
        #
    def I_qe_real_time_float_multi(self, dx):
        self.qe_value += dx
        v = self.qe_value
        self.qe_bu.bpy_setter(v, undo_push=False)
        tx = self.qe_bu.tx_format(v)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.bpy_setter(v, undo_push=False)
            e.da.text = tx
        #
    def I_qe_real_time_int_multi(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.qe_bu.bpy_setter(v, undo_push=False)
        tx = self.qe_bu.tx_format(v)
        self.qe_bu.da.text = tx
        for e in m.tm["ind"]:
            e.bpy_setter(v, undo_push=False)
            e.da.text = tx
        #
    def I_qe_performance_float(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_performance_int(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(round(self.qe_value))
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        self.bpy_setter(self.qe_value, undo_push=False)
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_real_time_int(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.bpy_setter(v, undo_push=False)
        self.da.text = self.tx_format(v)

    def I_modal_qe_multi(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_qe_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_qe_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_qe_end()
                return

        m.I_pan(evt)
        if self.key_slow(evt):      self.qe_fn(self.R_qe_dx() * self.qe_unit_slow)
        elif self.key_fast(evt):    self.qe_fn(self.R_qe_dx() * self.qe_unit_fast)
        else:                       self.qe_fn(self.R_qe_dx() * self.qe_unit)
        m.loop_mou(evt)
        #

    def to_outside(self):
        for e in self.array: e.off()
        self.w.U_modal = self.w.default_modal
    def is_to_outside(self, evt):
        if self.w.sci.inbox(evt) == False:
            for e in self.array: e.off()
            self.w.U_modal = self.w.default_modal
            return True
        array = self.array
        if self.rim.in_LR(evt) and array[-1].rim.B <= evt.mouse_region_y <= array[0].rim.T: pass
        else:
            for e in self.array: e.off()
            self.w.U_modal = self.w.default_modal
            return True
        return False

    def I_modal_fo(self, evt):
        m.redraw()
        if self.is_to_outside(evt): return
        y = evt.mouse_region_y

        array = self.array
        for e in array:
            if y >= e.rim.B:
                self = e
                break
        ind = self.index
        for e in array:
            if e.index == ind: e.fo()
            else: e.off()

        if self.is_enable is True:
            if evt.mouse_region_x <= self.rim.L + F[16]:
                self.is_cursor_changed = True
                m.M.set_mou_ic('SCROLL_X')
            elif evt.mouse_region_x >= self.rim.R - F[16]:
                self.is_cursor_changed = True
                m.M.set_mou_ic('SCROLL_X')
            elif self.is_cursor_changed is True:
                self.is_cursor_changed = False
                m.M.set_mou_ic('DEFAULT')

        if K["bu_insert_kf0"].true() or K["bu_insert_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Insert_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_kf0"].true() or K["bu_del_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Delete_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_clear_kf0"].true() or K["bu_clear_kf1"].true():
            self.w.RET = True
            oo_dr = self.R_oo_dr()
            m.tm["bu_kf"] = oo_dr.R_oo_kf()
            oo_dr.fn_Clear_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_dr0"].true() or K["bu_add_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_Driver()
            m.EVT.kill()
            self.to_outside()
            return True
        if K["bu_del_dr0"].true() or K["bu_del_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Delete_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp0"].true() or K["bu_dp1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Data_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_full0"].true() or K["bu_dp_full1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Full_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_paste0"].true() or K["bu_dp_paste1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Paste_Full_Path_to_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_keying_set0"].true() or K["bu_add_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_to_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_keying_set0"].true() or K["bu_del_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Remove_from_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Reset_to_Default_Value()
            m.EVT.kill_except(evt)
            return True
        if K["bu_batch_kf0"].true() or K["bu_batch_kf1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Keyframe_Batch()
            self.to_outside()
            return True
        if K["bu_batch_dr0"].true() or K["bu_batch_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Driver_Batch()
            self.to_outside()
            return True
        if K["bu_batch_value0"].true() or K["bu_batch_value1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Value_Batch()
            self.to_outside()
            return True
        if K["bu_qe0"].true():
#
            self.w.RET = True
            self.key_end = K["bu_qe_E0"]
            self.to_modal_qe(evt, K["bu_qe0"])
            return True
        if K["bu_qe1"].true():
#
            self.w.RET = True
            self.key_end = K["bu_qe_E1"]
            self.to_modal_qe(evt, K["bu_qe1"])
            return True
        if K["bu_sel0"].true() or K["bu_sel1"].true():
            self.w.RET = True
            if self.is_cursor_changed is True:
                if evt.mouse_region_x <= self.rim.L + F[16]:
                    self.do_step(-self.step)
                else:
                    self.do_step(self.step)
                return True
            self.fn()
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.w.RET = True
            self.rm_init(evt)
            self.to_outside()
            return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.w.RET = True
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.w.RET = True
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            self.w.RET = True
            self.fn_cut()
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            try:
                self.w.oo_dr[f'{self.attr}{self.index}'].fn_Reset_to_Default_Value()
#
            except:
                pass
#
            return True
        if K["bu_left0"].true() or K["bu_left1"].true():
            self.w.RET = True
            self.do_step(-self.step)
            return True
        if K["bu_right0"].true() or K["bu_right1"].true():
            self.w.RET = True
            self.do_step(self.step)
            return True
        if K["bu_up0"].true() or K["bu_up1"].true():
            self.w.RET = True
            self.do_step(10*self.step)
            return True
        if K["bu_down0"].true() or K["bu_down1"].true():
            self.w.RET = True
            self.do_step(-10*self.step)
            return True

    def fn_paste(self):
#
        ans = calc_vec(bpy.context.window_manager.clipboard)
        fac = self.R_unit_fac()

        if len(ans) > 1:
            for i, e in enumerate(self.array):
                try:    e.bpy_setter(ans[i] * fac  if fac != 1.0 else ans[i])
                except: pass
            return
        try:    self.bpy_setter(ans[0] * fac  if fac != 1.0 else ans[0])
        except: pass
    def fn_cut(self):
        try:
#
            lis = [e.da.name for e in self.array]

            fac = self.R_unit_fac()
            if fac != 1.0:  lis = [e / fac for e in lis]
            s = ""
            for v in lis:
                s += m.R_str_by_float(v) if isinstance(v, float) else f"{v}"
                s += ","
            bpy.context.window_manager.clipboard = s[: -1]
        except: pass

    def R_oo_dr(self): return self.w.oo_dr[f'{self.attr}{self.index}']
    def rm_init(self, evt):
#
        self.R_oo_dr().rm_init(evt)
    def batch_init(self, evt):
        self.w.oo_dr[f'{self.attr}{self.index}'].fn_Value_Batch()
class BUBLS(BU):
    __slots__ = ()
    def setter(self):
        array = getattr(self.w.w.act_md, self.attr)
        try:
            v = not array[self.value]
            array[self.value] = v
            m.undo_str = f'[Modifier Editor] md.{self.attr}[{self.value}] = "{v}"'
        except: pass
    def R_oo_dr(self): return self.w.oo_dr[f'{self.attr}{self.value}']
class BUSW(BU):
    __slots__ = ()
    def setter(self):
        v = not getattr(self.w.w.act_md, self.attr)

        try:
            setattr(self.w.w.act_md, self.attr, v)
            m.undo_str = f'[Modifier Editor] md.{self.attr} = {v}'
        except: pass


class BUFL_POW(BUFL):
    __slots__ = ()
    def I_bpy_setter(self, flo, undo_push=True):
        setattr(self.w.w.act_md, self.attr, flo)
        if undo_push:
            m.undo_str = f'[Modifier Editor] md.{self.attr} = {flo}'
            m.undo_push()
            m.power_upd()
    def I_bpy_setter_int(self, flo, undo_push=True):
        v = round(flo)
        setattr(self.w.w.act_md, self.attr, v)
        if undo_push:
            m.undo_str = f'[Modifier Editor] md.{self.attr} = {v}'
            m.undo_push()
            m.power_upd()
class BUFL_CUS(BUFL):
    __slots__ = ()
    def __init__(self,
            w,
            name,
            attr,
            offset_x_key    = 5.1,
            offset_y_key    = 4.9,
            ty              = "float [-∞,∞]",
            fn              = None
        ):
        super().__init__(w, name, attr, offset_x_key=offset_x_key, offset_y_key=offset_y_key, ty=ty)
        self.bpy_setter = fn
class BUBL_POW(BUBL):
    __slots__ = ()
    def fn(self):
        self.U_fn   = N
        if self.free_fn is not None:    self.free_fn() ;return

        act_md      = self.w.w.act_md

        if getattr(act_md, self.attr):
            self.da.text = ""
            self.da.name = False
            setattr(act_md, self.attr, False)
            m.undo_str = f'[Modifier Editor] md.{self.attr} = False'
        else:
            self.da.text = "■"
            self.da.name = True
            setattr(act_md, self.attr, True)
            m.undo_str = f'[Modifier Editor] md.{self.attr} = True'
        m.undo_push()
        m.power_upd()
class BUTX_EVAL(BUTX):
    __slots__ = ()
    def setter(self):
        at0, at1 = self.attr
        try:    e0 = eval(at0)
        except: e0 = None
        if e0 is None: return
        attr = getattr(e0, at1, None)
        if attr is None: return

        if self.is_str:
            self.set_da(attr)
            return

        if isinstance(self.update_filter, dict):
            self.set_da(self.update_filter[attr] if attr in self.update_filter else attr)
            return

        if attr == None:    self.set_da("")
        else:               self.set_da(attr.name)
    def I_bpy_setter(self, s, undo_push=True):
        if isinstance(self.update_filter, dict):
            try:
                if s in self.update_filter: pass
                else:
                    dict_rev = {e: k for k, e in self.update_filter.items()}
                    if s in dict_rev: s = dict_rev[s]

                at0, at1 = self.attr
                e0 = eval(at0)
                setattr(e0, at1, s)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] {at1} = {s}'
                    m.undo_push()
                    m.power_upd()
            except: pass
            return

        try:
            at0, at1 = self.attr
            e0 = eval(at0)

            if self.is_str:
                setattr(e0, at1, s)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] {at1} = "{s}"'
                    m.undo_push()
                    m.power_upd()
                return

            if s == "":
                setattr(e0, at1, None)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] {at1} = None'
                    m.undo_push()
                    m.power_upd()
            else:
                bpy_type = self.fil.bpy_type
                collection = eval(bpy_type) if isinstance(bpy_type, str) else bpy_type
                tar = collection[R_lib_tuple(collection, s)]
                setattr(e0, at1, tar)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] {at1} ▶ {getattr(tar, "name", tar)}'
                    m.undo_push()
                    m.power_upd()
        except: pass
    def rm_init(self, evt):
#
        pass


class BUKF:
    __slots__ = (
        'w',
        'name',
        'attr',
        'rim',
        'ti',
        'U_set_last',
        'U_set_no_kf',
        'U_set_kf_fit',
        'U_set_kf_unfit',
        'U_set_nokf_fit',
        'U_set_nokf_unfit',
        'draw_ti',
        'upd_ti',
        'enum',
        'color_fo',
        'fc_event',
        'is_enable',
    )
    def __init__(self, w, name, attr, type_attr=True):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, "•")

        self.U_set_last         = self.IU_set_no_kf
        self.U_set_no_kf        = N
        self.U_set_kf_fit       = self.I_set_kf_fit
        self.U_set_kf_unfit     = self.I_set_kf_unfit
        self.U_set_nokf_fit     = self.I_set_nokf_fit
        self.U_set_nokf_unfit   = self.I_set_nokf_unfit
        self.draw_ti            = self.I_draw_ti

        w.oo_kf[attr] = self
        self.is_enable = True

        if type_attr is True:       self.upd_ti = self.upd_fc
        elif type_attr is False:    self.upd_ti = self.upd_fc_bool
        else:
            self.upd_ti = self.upd_fc_enum_set if frozenset_empty in type_attr else self.upd_fc_enum
            self.enum   = type_attr

    def R_oo_dr(self): return self.w.oo_dr[self.attr]

    def disable(self):
        self.is_enable = False
        e = self.ti.color
        if e == P.color_font:
            self.ti.color = P.color_font_ignore
        elif e == P.color_bu_kf_yellow:
            self.ti.color = P.color_bu_kf_yellow_ignore
        elif e == P.color_bu_kf_green:
            self.ti.color = P.color_bu_kf_green_ignore
        elif e == P.color_bu_kf_orange:
            self.ti.color = P.color_bu_kf_orange_ignore
    def enable(self):
        self.is_enable = True
        e = self.ti.color
        if e == P.color_font_ignore:
            self.ti.color = P.color_font
        elif e == P.color_bu_kf_yellow_ignore:
            self.ti.color = P.color_bu_kf_yellow
        elif e == P.color_bu_kf_green_ignore:
            self.ti.color = P.color_bu_kf_green
        elif e == P.color_bu_kf_orange_ignore:
            self.ti.color = P.color_bu_kf_orange

    def above_L(self, e):
        rim = e.rim
        self.ti.xy(rim.L, rim.T + F[7.8])
        self.rim.LRBT(rim.L - F[5], rim.L + F[11], rim.T, rim.T + F[17])
    def above_L_with_dr(self, e, dr): #blf_size
        self.above_L(e)
        dr.next_kf(self)

    def LBT(self, L, B, T):
        self.ti.xy(L, B + F[5.1])
        self.rim.LRBT(L - F[5], L + F[11], B, T)
    def LBT_with_dr(self, L, B, T, dr):
        self.ti.xy(L, B + F[5.1])
        self.rim.LRBT(L - F[5], L + F[11], B, T)
        dr.next_kf(self)
    def right_bu_depth(self, bu, d=10): # must blf_size
        rim = bu.rim

        x = rim.R + F[d]
        self.ti.x     = x
        self.ti.y     = rim.B + F[5.1]
        self.rim.LRBT(x - F[5], x + F[11], rim.B, rim.T)

    def dxy_upd(self, x, y):
        self.rim.dxy(x, y)
        self.ti.dxy(x, y)

    def draw_rim(self): pass
    def draw_bg(self):  pass
    def I_draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()
    def I_draw_ti_fo(self):
        blf_color(font_0, *self.color_fo)
        self.ti.draw_pos()

    def IU_set_no_kf(self):     self.U_set_no_kf = self.I_set_no_kf
    def IU_set_kf_fit(self):    self.U_set_kf_fit = self.I_set_kf_fit
    def IU_set_kf_unfit(self):  self.U_set_kf_unfit = self.I_set_kf_unfit
    def IU_set_nokf_fit(self):  self.U_set_nokf_fit = self.I_set_nokf_fit
    def IU_set_nokf_unfit(self):self.U_set_nokf_unfit = self.I_set_nokf_unfit

    def I_set_no_kf(self):
#
        self.U_set_last()
        self.U_set_no_kf    = N
        self.U_set_last     = self.IU_set_no_kf
        self.ti.color_tx(P.color_font  if self.is_enable else P.color_font_ignore, "•")
    def I_set_kf_fit(self):
#
        self.U_set_last()
        self.U_set_kf_fit   = N
        self.U_set_last     = self.IU_set_kf_fit
        self.ti.color_tx(P.color_bu_kf_yellow  if self.is_enable else P.color_bu_kf_yellow_ignore, "◆")
    def I_set_kf_unfit(self):
#
        self.U_set_last()
        self.U_set_kf_unfit = N
        self.U_set_last     = self.IU_set_kf_unfit
        self.ti.color_tx(P.color_bu_kf_orange  if self.is_enable else P.color_bu_kf_orange_ignore, "◆")
    def I_set_nokf_fit(self):
#
        self.U_set_last()
        self.U_set_nokf_fit = N
        self.U_set_last     = self.IU_set_nokf_fit
        self.ti.color_tx(P.color_bu_kf_green  if self.is_enable else P.color_bu_kf_green_ignore, "◇")
    def I_set_nokf_unfit(self):
#
        self.U_set_last()
        self.U_set_nokf_unfit   = N
        self.U_set_last         = self.IU_set_nokf_unfit
        self.ti.color_tx(P.color_bu_kf_orange  if self.is_enable else P.color_bu_kf_orange_ignore, "◇")
    def upd_fc(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}')
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if fc.evaluate(r) == getattr(act_md, self.attr): self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if fc.evaluate(r) == getattr(act_md, self.attr): self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_enum(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}')
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        v = getattr(act_md, self.attr)
                        if v in self.enum and self.enum[v] == round(fc.evaluate(r)): self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        v = getattr(act_md, self.attr)
                        if v in self.enum and self.enum[v] == round(fc.evaluate(r)): self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_enum_set(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}')
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        v = frozenset(getattr(act_md, self.attr))
                        if v in self.enum and self.enum[v] == round(fc.evaluate(r)): self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        v = frozenset(getattr(act_md, self.attr))
                        if v in self.enum and self.enum[v] == round(fc.evaluate(r)): self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_bool(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}')
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if round(fc.evaluate(r)) == int(getattr(act_md, self.attr)):
                            self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if round(fc.evaluate(r)) == int(getattr(act_md, self.attr)):
                            self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()

    def get_color_fo(self):
        if self.is_enable is False:
            self.color_fo = self.ti.color
            return
        if self.ti.color == P.color_font:           self.color_fo = P.color_bu_kf_fo
        elif self.ti.color == P.color_bu_kf_yellow:  self.color_fo = P.color_bu_kf_yellow_fo
        elif self.ti.color == P.color_bu_kf_green:   self.color_fo = P.color_bu_kf_green_fo
        else:   self.color_fo = P.color_bu_kf_orange_fo
    def inside(self, evt):
        self.get_color_fo()
        self.draw_ti = self.I_draw_ti_fo
        self.fc_event = self.I_fc_event

        self.w.U_modal = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def to_outside(self):
        self.draw_ti = self.I_draw_ti
        m.redraw()
        self.w.U_modal = self.w.default_modal
    def is_to_outside(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.draw_ti = self.I_draw_ti
            m.redraw()
            self.w.U_modal = self.w.default_modal
            return True
        return False

    def I_modal_fo(self, evt):
        if self.is_to_outside(evt): return

        if evt.value == 'RELEASE':  self.fc_event = self.I_fc_event
        if K["bu_insert_kf0"].true() or K["bu_insert_kf1"].true():
            self.w.RET = True
            m.tm["bu_kf"] = self
            self.R_oo_dr().fn_Insert_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_kf0"].true() or K["bu_del_kf1"].true():
            self.w.RET = True
            m.tm["bu_kf"] = self
            self.R_oo_dr().fn_Delete_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_clear_kf0"].true() or K["bu_clear_kf1"].true():
            self.w.RET = True
            m.tm["bu_kf"] = self
            self.R_oo_dr().fn_Clear_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_dr0"].true() or K["bu_add_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_Driver()
            m.EVT.kill()
            self.to_outside()
            return True
        if K["bu_del_dr0"].true() or K["bu_del_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Delete_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp0"].true() or K["bu_dp1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Data_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_full0"].true() or K["bu_dp_full1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Copy_Full_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_paste0"].true() or K["bu_dp_paste1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Paste_Full_Path_to_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_keying_set0"].true() or K["bu_add_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Add_to_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_keying_set0"].true() or K["bu_del_keying_set1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Remove_from_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Reset_to_Default_Value()
            m.EVT.kill_except(evt)
            return True
        if K["bu_batch_kf0"].true() or K["bu_batch_kf1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Keyframe_Batch()
            self.to_outside()
            return True
        if K["bu_batch_dr0"].true() or K["bu_batch_dr1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Driver_Batch()
            self.to_outside()
            return True
        if K["bu_batch_value0"].true() or K["bu_batch_value1"].true():
            self.w.RET = True
            self.R_oo_dr().fn_Value_Batch()
            self.to_outside()
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.w.RET = True
            self.fc_event()
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.w.RET = True
            self.rm_init(evt)
            self.to_outside()
            return True
    def rm_init(self, evt):
#
        if self.attr is None:   return
        self.R_oo_dr().rm_init(evt)

    def I_fc_event(self, require=None):
#
        self.fc_event = N
        oj          = self.w.w.oj
        an_data     = oj.animation_data
        act_md      = self.w.w.act_md
        self.upd_ti(an_data, act_md)
        path = f'modifiers["{act_md.name}"].{self.attr}'
        if require is None:
            if self.ti.text == "◆":
                self.w.w.oj.keyframe_delete(path)
                m.undo_str = f"[Modifier Editor] keyframe_delete('{path}')"
            else:
                self.w.w.oj.keyframe_insert(path)
                m.undo_str = f"[Modifier Editor] keyframe_insert('{path}')"
        elif require == "INSERT":
            self.w.w.oj.keyframe_insert(path)
            m.undo_str = f"[Modifier Editor] keyframe_insert('{path}')"
        else:
            self.w.w.oj.keyframe_delete(path)
            m.undo_str = f"[Modifier Editor] keyframe_delete('{path}')"

        P.refresh = True
        m.refresh()
        self.get_color_fo()
        m.redraw()
        m.undo_push()
    #
    #
class BUKFS(BUKF):
    __slots__ = 'index'
    def __init__(self, w, name, attr, index, type_attr = True):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.index  = index
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, "•")

        self.U_set_last         = self.IU_set_no_kf
        self.U_set_no_kf        = N
        self.U_set_kf_fit       = self.I_set_kf_fit
        self.U_set_kf_unfit     = self.I_set_kf_unfit
        self.U_set_nokf_fit     = self.I_set_nokf_fit
        self.U_set_nokf_unfit   = self.I_set_nokf_unfit
        self.draw_ti            = self.I_draw_ti

        w.oo_kf[f'{attr}{index}'] = self
        self.is_enable = True

        if type_attr is True:       self.upd_ti = self.upd_fc
        elif type_attr is False:    self.upd_ti = self.upd_fc_bool
        else:
            self.upd_ti = self.upd_fc_enum
            self.enum   = type_attr
        #

    def R_oo_dr(self): return self.w.oo_dr[f'{self.attr}{self.index}']

    def upd_fc(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}', index=self.index)
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current

                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if fc.evaluate(r) == getattr(act_md, self.attr)[self.index]: self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if fc.evaluate(r) == getattr(act_md, self.attr)[self.index]: self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
        #
    def I_fc_event(self, require=None):
#
        self.fc_event = N
        oj          = self.w.w.oj
        an_data     = oj.animation_data
        act_md      = self.w.w.act_md
        self.upd_ti(an_data, act_md)
        path = f'modifiers["{act_md.name}"].{self.attr}'
        if require is None:
            if self.ti.text == "◆":
                self.w.w.oj.keyframe_delete(path, index=self.index)
                m.undo_str = f"[Modifier Editor] keyframe_delete('{path}', index={self.index})"
            else:
                self.w.w.oj.keyframe_insert(path, index=self.index)
                m.undo_str = f"[Modifier Editor] keyframe_insert('{path}', index={self.index})"
        elif require == "INSERT":
            self.w.w.oj.keyframe_insert(path, index=self.index)
            m.undo_str = f"[Modifier Editor] keyframe_insert('{path}', index={self.index})"
        else:
            self.w.w.oj.keyframe_delete(path, index=self.index)
            m.undo_str = f"[Modifier Editor] keyframe_delete('{path}', index={self.index})"

        P.refresh = True
        m.refresh()
        self.get_color_fo()
        m.redraw()
        m.undo_push()
    #
    #
class BUKFMIX(BUKF):
    __slots__ = ()
    def upd_fc_enum(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(f'modifiers["{act_md.name}"].{self.attr}')
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        v = getattr(act_md, self.attr)
                        l0, s = self.enum
                        try:    l1 = eval(s)
                        except: l1 = {}
                        ev = round(fc.evaluate(r))

                        if (v in l0 and l0[v] == ev) or (ev < len(l1) and l1[ev].name == v): self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        v = getattr(act_md, self.attr)
                        l0, s = self.enum
                        try:    l1 = eval(s)
                        except: l1 = {}
                        ev = round(fc.evaluate(r))

                        if (v in l0 and l0[v] == ev) or (ev < len(l1) and l1[ev].name == v): self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()


class BUDR:
    __slots__ = (
        'w',
        'name',
        'attr',
        'rim',
        'ti',
        'U_set_ti_dr',
        'U_set_ti_nodr',
        'draw_ti',
        'color_fo',
        'dr_event',
        'array_index',
        'is_ref_driver',
        'is_enable',
    )
    def __init__(self, w, name, ti, attr,
            array_index     = 0,
            is_ref_driver   = False,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, ti)

        self.U_set_ti_dr    = self.I_set_ti_dr
        self.U_set_ti_nodr  = N
        self.draw_ti        = self.I_draw_ti
        self.array_index    = array_index
        self.is_ref_driver  = is_ref_driver

        w.oo_dr[attr] = self
        self.is_enable = True

    def R_oo_kf(self): return self.w.oo_kf[self.attr]

    def disable(self):
        self.is_enable = False
        if self.ti.color == P.color_font:
            self.ti.color = P.color_font_ignore
        elif self.ti.color == P.color_bu_dr:
            self.ti.color = P.color_bu_dr_ignore
    def enable(self):
        self.is_enable = True
        if self.ti.color == P.color_font_ignore:
            self.ti.color = P.color_font
        elif self.ti.color == P.color_bu_dr_ignore:
            self.ti.color = P.color_bu_dr

    def LBT(self, L, B, T): # must blf_size
        self.ti.xy(L, B + F[5.1])
        self.rim.LRBT(L - F[4], self.ti.R_end_x() + F[4], B, T)
    def next_kf(self, e): # must blf_size
        rim = e.rim
        ti  = e.ti
        self.ti.xy(ti.x + F[14], ti.y)
        self.rim.LRBT(rim.R, self.ti.R_end_x() + F[4], rim.B, rim.T)

    def left_bu_depth_with_kf(self, bu, kf, d=10): # must blf_size
        rim = bu.rim
        self.ti.align_R_float(rim.L - F[d])
        self.ti.y   = rim.B + F[5.1]
        kf.ti.xy(self.ti.x - F[14], self.ti.y)
        self.rim.B  = kf.rim.B = rim.B
        self.rim.T  = kf.rim.T = rim.T
        kf.rim.L    = kf.ti.x - F[5]
        kf.rim.R    = kf.ti.x + F[11]
        self.rim.L  = kf.rim.R
        self.rim.R  = self.ti.R_end_x() + F[4]
        #
    def left_bu_depth(self, bu, d=10): # must blf_size
        rim = bu.rim
        self.ti.align_R_float(rim.L - F[d])
        self.ti.y   = rim.B + F[5.1]
        self.rim.LRBT(
            self.ti.x - F[14] + F[11],
            self.ti.R_end_x() + F[4],
            rim.B,
            rim.T
        )
        #
    def right_bu_depth_with_kf(self, bu, kf, d=10): # must blf_size
        rim = bu.rim

        x = rim.R + F[d]
        kf.ti.x     = x
        kf.ti.y     = rim.B + F[5.1]
        kf.rim.LRBT(x - F[5], x + F[11], rim.B, rim.T)
        self.next_kf(kf)
    def right_bu_depth(self, bu, d=9): # must blf_size
        rim = bu.rim

        self.ti.x   = rim.R + F[d]
        self.ti.y   = rim.B + F[5.1]
        self.rim.LRBT(rim.R, self.ti.R_end_x() + F[4], rim.B, rim.T)
    def LR_bu_depth_with_kf(self, bu, kf):
        self.left_bu_depth(bu)
        kf.right_bu_depth(bu)

    def dxy_upd(self, x, y):
        self.rim.dxy(x, y)
        self.ti.dxy(x, y)

    def draw_rim(self): pass
    def draw_bg(self):  pass
    def I_draw_ti(self):
        self.ti.set_color()
        self.ti.draw_pos()
    def I_draw_ti_fo(self):
        blf_color(font_0, *self.color_fo)
        self.ti.draw_pos()

    def I_set_ti_dr(self):
#
        self.U_set_ti_dr    = N
        self.U_set_ti_nodr  = self.I_set_ti_nodr
        self.ti.color       = P.color_bu_dr  if self.is_enable else P.color_bu_dr_ignore
    def I_set_ti_nodr(self):
#
        self.U_set_ti_dr    = self.I_set_ti_dr
        self.U_set_ti_nodr  = N
        self.ti.color       = P.color_font  if self.is_enable else P.color_font_ignore

    def upd_dr(self, an_data, act_md):
        if an_data:
            drivers = an_data.drivers
            if drivers:
                if self.is_ref_driver:
                    path = f'["modifiers[{act_md.name}].{self.attr}"]'
                else:
                    path = f'modifiers["{act_md.name}"].{self.attr}'
                if drivers.find(path) != None:
                    self.U_set_ti_dr()
                    return
        self.U_set_ti_nodr()

    def inside(self, evt):
        if self.is_enable is True:
            if self.ti.color == P.color_font:
                self.color_fo = P.color_font_fo
            else:
                self.color_fo = P.color_bu_dr_fo
        else:
            self.color_fo = self.ti.color

        self.draw_ti    = self.I_draw_ti_fo
        self.dr_event   = self.I_dr_event
        self.w.U_modal  = self.I_modal_fo
        self.I_modal_fo(evt)
        m.redraw()

    def to_outside(self):
        self.draw_ti    = self.I_draw_ti
        m.redraw()
        self.w.U_modal  = self.w.default_modal
    def is_to_outside(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False:
            self.draw_ti    = self.I_draw_ti
            m.redraw()
            self.w.U_modal  = self.w.default_modal
            return True
        return False

    def I_modal_fo(self, evt):
        if self.is_to_outside(evt): return

        if evt.value == 'RELEASE':  self.dr_event = self.I_dr_event
        if K["bu_insert_kf0"].true() or K["bu_insert_kf1"].true():
            self.w.RET = True
            m.tm["bu_kf"] = self.R_oo_kf()
            self.fn_Insert_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_kf0"].true() or K["bu_del_kf1"].true():
            self.w.RET = True
            m.tm["bu_kf"] = self.R_oo_kf()
            self.fn_Delete_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_clear_kf0"].true() or K["bu_clear_kf1"].true():
            self.w.RET = True
            m.tm["bu_kf"] = self.R_oo_kf()
            self.fn_Clear_Keyframe()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_dr0"].true() or K["bu_add_dr1"].true():
            self.w.RET = True
            self.fn_Add_Driver()
            m.EVT.kill()
            self.to_outside()
            return True
        if K["bu_del_dr0"].true() or K["bu_del_dr1"].true():
            self.w.RET = True
            self.fn_Delete_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp0"].true() or K["bu_dp1"].true():
            self.w.RET = True
            self.fn_Copy_Data_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_full0"].true() or K["bu_dp_full1"].true():
            self.w.RET = True
            self.fn_Copy_Full_Path()
            m.EVT.kill_except(evt)
            return True
        if K["bu_dp_paste0"].true() or K["bu_dp_paste1"].true():
            self.w.RET = True
            self.fn_Paste_Full_Path_to_Driver()
            m.EVT.kill_except(evt)
            return True
        if K["bu_add_keying_set0"].true() or K["bu_add_keying_set1"].true():
            self.w.RET = True
            self.fn_Add_to_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_del_keying_set0"].true() or K["bu_del_keying_set1"].true():
            self.w.RET = True
            self.fn_Remove_from_Keying_Set()
            m.EVT.kill_except(evt)
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.w.RET = True
            self.fn_Reset_to_Default_Value()
            m.EVT.kill_except(evt)
            return True
        if K["bu_batch_kf0"].true() or K["bu_batch_kf1"].true():
            self.w.RET = True
            self.fn_Keyframe_Batch()
            self.to_outside()
            return True
        if K["bu_batch_dr0"].true() or K["bu_batch_dr1"].true():
            self.w.RET = True
            self.fn_Driver_Batch()
            self.to_outside()
            return True
        if K["bu_batch_value0"].true() or K["bu_batch_value1"].true():
            self.w.RET = True
            self.fn_Driver_Batch()
            self.to_outside()
            return True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.w.RET = True
            self.dr_event()
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.w.RET = True
            self.rm_init(evt)
            self.to_outside()
            return True
    def enforce_outside(self):
        if self.w.U_modal == self.I_modal_fo:
            self.draw_ti    = self.I_draw_ti
            self.w.U_modal  = self.w.default_modal

    def I_dr_event(self):
        if self.attr is None: return
        self.draw_ti    = self.I_draw_ti
        self.w.U_modal  = self.w.default_modal
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()

    def R_data_path(self):
        return f'modifiers["{self.w.w.act_md.name}"].{self.attr}'
    def R_full_path(self):
        w = self.w.w
        return f'bpy.data.objects[{R_lib_name(w.oj)}].modifiers["{w.act_md.name}"].{self.attr}'
    def driver_add(self, exp = "var"):
#
        w = self.w.w
        return R_md_driver_add(w.oj, w.act_md.name, self.attr, exp=exp)
    def driver_remove(self):
#
        w = self.w.w
        return R_md_driver_remove(w.oj, w.act_md.name, self.attr)

    def rm_init(self, evt, override=None):
        if self.attr is None:   return
#
        self.enforce_outside()
        bu_kf       = self.R_oo_kf()  if self.attr in self.w.oo_kf else None

        if self.is_ref_driver:
            is_anim = 0
            md_type = self.w.w.act_md.type
            attrs = getattr(MOD_REF_ATTR, md_type, None)
            if attrs is not None:
                if self.attr in attrs:
                    o = self.w.w.oj
                    try:
                        path = f'modifiers[{self.w.w.act_md.name}].{self.attr}'
                        dr = o.animation_data.drivers.find(f'["{path}"]')
                    except:
                        dr = None

                    if dr is None:
                        line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 0}
                    else:
                        line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 1}
                else:
                    attrs = None

            if attrs is None:
                line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver ", 1: 0}
                line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver ", 1: 0}
            line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe ", 1: 0}
            line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe ", 1: 0}
            line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe ", 1: 0}
        else:
            is_anim = 1
            if bu_kf.ti.text == "◆":
                line0 = {9: "fn_Replace_Keyframe", 0: "Replace Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 1}
            else:
                line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 0}

            if bu_kf.ti.text == "•":
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 0}
            else:
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 1}

            if self.U_set_ti_dr == self.I_set_ti_dr:
                line3 = {9: "fn_Add_Driver", 0: "Add Driver"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 0}
            else:
                line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 1}

        if override is None:    override = {}
        if "title" in override:
            ti_tx = override["title"]
        else:
            ti_tx       = self.ti.text
            if ti_tx[-2:] == " :":  ti_tx = ti_tx[:-2]

        m.tm["bu_kf"] = bu_kf

        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y,
        override["li"]  if "li" in override else [
            line0,
            line1,
            line2,
            line3,
            line4,
            {9: "fn_Copy_Data_Path", 0: "Copy Data Path"},
            {9: "fn_Copy_Full_Path", 0: "Copy Full Path"},
            {9: "fn_Paste_Full_Path_to_Driver", 0: "Paste Full Path to Driver"},
            {9: "fn_Add_to_Keying_Set", 0: "Add to Keying Set", 1: is_anim},
            {9: "fn_Remove_from_Keying_Set", 0: "Remove from Keying Set", 1: is_anim},
            {9: "fn_Reset_to_Default_Value", 0: "Reset to Default Value"},
            {9: "fn_Keyframe_Batch", 0: "Keyframe Batch"},
            {9: "fn_Driver_Batch", 0: "Driver Batch"},
            {9: "fn_Value_Batch", 0: "Value Batch"},
            {9: "fn_detail", 0: "Details"},
        ],
        fin_D1  = override["rm_end"]  if "rm_end" in override else None,
        title   = ti_tx,
        width   = F[150])

    def fn_Insert_Keyframe(self):
        try:    m.tm["bu_kf"].I_fc_event("INSERT")
        except: pass
    def fn_Replace_Keyframe(self):
        try:    m.tm["bu_kf"].I_fc_event("INSERT")
        except: pass
    def fn_Delete_Keyframe(self):
        try:    m.tm["bu_kf"].I_fc_event("DELETE")
        except: pass
    def fn_Clear_Keyframe(self):
        w       = self.w.w
        path = f'modifiers["{w.act_md.name}"].{self.attr}'
        fc = TR_fc_by_path(w.oj, path)
        if fc is None:  return
        w.oj.animation_data.action.fcurves.remove(fc)
        P.refresh = True
        m.refresh()
        m.redraw()
        m.undo_str = f"[Modifier Editor] Clear Keyframe {path}"
        m.undo_push()
    def fn_Add_Driver(self):
#
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()
    def fn_Open_Driver_Editor(self):
#
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()
    def fn_Delete_Driver(self):
#
        if self.driver_remove():
            P.refresh = True
            m.refresh()
            m.undo_str = "[Modifier Editor] Driver Delete"
            m.undo_push()
    def fn_Copy_Data_Path(self):
#
        bpy.context.window_manager.clipboard = self.R_data_path()
    def fn_Copy_Full_Path(self):
#
        bpy.context.window_manager.clipboard = self.R_full_path()
    def fn_Paste_Full_Path_to_Driver(self):
        full_path = bpy.context.window_manager.clipboard
        if not full_path:
            m.admin.report({'INFO'}, "Clipboard is Empty")
            return
        tar_obj, dr_path = R_obj_path_by_full_path(full_path)
        if tar_obj is None:
            m.admin.report({'INFO'}, "Invalid path")
            return

        id_type = R_id_type(tar_obj)
        if id_type is None: return
        try:
            w = self.w.w
            fc = self.driver_add()
            vs = fc.driver.variables
            v = vs[0] if vs else vs.new()
            tar = v.targets[0]
            tar.id_type = id_type
            tar.id = tar_obj
            tar.data_path = dr_path
        except:
            m.admin.report({'INFO'}, "Unknown Error")
            return

        P.refresh = True
        m.refresh()
        m.redraw()
        m.undo_str = f"[Modifier Editor] Paste Full Path to Driver"
        m.undo_push()
    def fn_Add_to_Keying_Set(self):
        try:
#
            if self.is_ref_driver: return
            w = self.w.w
            keying_sets = bpy.context.scene.keying_sets
            act_ks = keying_sets.active
            if act_ks is None:
                act_ks = keying_sets.new(idname='Button Keying Set', name='Button Keying Set')
                act_ks.use_insertkey_xyz_to_rgb = True
                act_ks.use_insertkey_override_xyz_to_rgb = True

            kspath = act_ks.paths.add(w.oj, f'modifiers["{w.act_md.name}"].{self.attr}')
            keying_sets.active = keying_sets.active
            m.undo_str = "[Modifier Editor] Add to Keying Set"
            m.undo_push()
            m.admin.report({'INFO'}, f"Property added to Keying Set: '{act_ks.bl_idname}'")
        except: pass
    def fn_Remove_from_Keying_Set(self):
        try:
#
            if self.is_ref_driver: return
            w = self.w.w
            keying_sets = bpy.context.scene.keying_sets
            act_ks = keying_sets.active
            if act_ks is None:  return

            w_oj = w.oj
            dp = f'modifiers["{w.act_md.name}"].{self.attr}'
            paths = act_ks.paths
            for p in paths:
                if p.id != w_oj:        continue
                if p.data_path != dp:   continue

                paths.remove(p)
                keying_sets.active = keying_sets.active
                m.undo_str = "[Modifier Editor] Remove from Keying Set"
                m.undo_push()
                m.admin.report({'INFO'}, f"Property removed from Keying Set: '{act_ks.bl_idname}'")
        except: pass
    def fn_Reset_to_Default_Value(self):
        try:
#
            w = self.w.w
            act_md = w.act_md
            attr = self.attr
            prop = act_md.bl_rna.properties[attr]
            prop_ty = prop.type

            if prop_ty == "STRING":
                setattr(act_md, attr, "")
            elif prop_ty == "POINTER":
                setattr(act_md, attr, None)
            elif getattr(prop, "is_array", False):
                getattr(act_md, attr)[:] = prop.default_array
            else:
                setattr(act_md, attr, prop.default)

            m.refresh()
            m.undo_str = f"[Modifier Editor] Reset Value: {attr}"
            m.undo_push()
        except:
            pass
    def fn_Add_Reference_Driver(self):
#
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()
    def fn_Delete_Reference_Driver(self):
#
        if self.driver_remove():
            P.refresh = True
            m.refresh()
            m.undo_str = "[Modifier Editor] Delete Reference Driver"
            m.undo_push()
    def fn_Keyframe_Batch(self):
#
        try:
            if self.attr is None:   return

            try:    kf_tx = self.R_oo_kf().ti.text
            except: kf_tx = ""
            self.batch_init(m.EVT.evt, 1 if kf_tx == "◆" else 0)
        except: pass
    def fn_Driver_Batch(self):
#
        try:
            if self.attr is None:   return

            self.batch_init(m.EVT.evt, 0 if self.ti.color == P.color_font else 1, 1)
        except: pass
    def fn_Value_Batch(self):
#
        try:
            if self.attr is None:   return

            self.batch_init(m.EVT.evt, 0, 2)
        except: pass
    def fn_detail(self):
        try:
            rna = self.w.w.act_md.bl_rna.properties[self.attr]
        except: return

        # <<< 1copy (0ui_fn_detail,, ${'self.rna':'rna'}$)
        if not hasattr(rna, "description"): return
        name = rna.name
        if not name: name = " "
        description = rna.description
        if not isinstance(description, str):    description = description()
        if not description: description = "No description."
        details = INFO(name, description)
        evt = m.EVT.evt
        blf_size(font_0, F[9])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, F[480])
        e = BLF(text=details.body)
        hi = round(e.R_dimen_y()) + F[-1] + F[46]
        e.text = details.title
        hi += round(e.R_dimen_y())
        wi = F[480]
        blf_disable(font_0, WORD_WRAP)
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), details)
        # >>>

    def batch_init(self, evt, ind=0, operation=0):
#
        if operation == 0:
            MESS_BATCH_KF(evt.mouse_region_x, evt.mouse_region_y, self, operation, ind)
        elif operation == 1:
            MESS_BATCH_DR(evt.mouse_region_x, evt.mouse_region_y, self, operation, ind)
        else:
            MESS_BATCH_VAL(evt.mouse_region_x, evt.mouse_region_y, self, operation, ind)
    #
    #
class BUDRS(BUDR):
    __slots__ = ()
    def __init__(self, w, name, ti, attr,
            array_index     = 0,
            is_ref_driver   = False,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, ti)

        self.U_set_ti_dr    = self.I_set_ti_dr
        self.U_set_ti_nodr  = N
        self.draw_ti        = self.I_draw_ti
        self.array_index    = array_index
        self.is_ref_driver  = is_ref_driver

        w.oo_dr[f'{attr}{array_index}'] = self
        self.is_enable = True

    def R_oo_kf(self): return self.w.oo_kf[f'{self.attr}{self.array_index}']

    def upd_dr(self, an_data, act_md):
        if an_data:
            drivers = an_data.drivers
            if drivers:
                if self.is_ref_driver:
                    path = f'["modifiers[{act_md.name}].{self.attr}"]'
                else:
                    path = f'modifiers["{act_md.name}"].{self.attr}'
                if drivers.find(path, index=self.array_index) != None:
                    self.U_set_ti_dr()
                    return
        self.U_set_ti_nodr()
    #
    def driver_add(self, exp = "var"):
#
        w = self.w.w
        return R_md_driver_add(w.oj, w.act_md.name, self.attr, exp=exp, index=self.array_index)
    #
    def driver_remove(self):
#
        w = self.w.w
        return R_md_driver_remove(w.oj, w.act_md.name, self.attr, index=self.array_index)
    #

    def rm_init(self, evt, override=None):
        if self.attr is None:   return
#
        self.enforce_outside()
        bu_kf       = self.R_oo_kf()

        if self.is_ref_driver:
            md_type = self.w.w.act_md.type
            attrs = getattr(MOD_REF_ATTR, md_type, None)
            if attrs is not None:
                if self.attr in attrs:
                    o = self.w.w.oj
                    try:
                        path = f'modifiers[{self.w.w.act_md.name}].{self.attr}'
                        dr = o.animation_data.drivers.find(f'["{path}"]')
                    except:
                        dr = None

                    if dr is None:
                        line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 0}
                    else:
                        line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 1}
                else:
                    attrs = None

            if attrs is None:
                line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver ", 1: 0}
                line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver ", 1: 0}
            line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe ", 1: 0}
            line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe ", 1: 0}
            line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe ", 1: 0}
        else:
            if bu_kf.ti.text == "◆":
                line0 = {9: "fn_Replace_Keyframe", 0: "Replace Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 1}
            else:
                line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 0}

            if bu_kf.ti.text == "•":
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 0}
            else:
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 1}

            if self.U_set_ti_dr == self.I_set_ti_dr:
                line3 = {9: "fn_Add_Driver", 0: "Add Driver"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 0}
            else:
                line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 1}

        if override is None:    override = {}
        if "title" in override:
            ti_tx = override["title"]
        else:
            ti_tx       = self.ti.text
            if ti_tx[-2:] == " :":  ti_tx = ti_tx[:-2]

        m.tm["bu_kf"] = bu_kf

        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y,
        override["li"]  if "li" in override else [
            line0,
            line1,
            line2,
            line3,
            line4,
            {9: "fn_Copy_Data_Path", 0: "Copy Data Path"},
            {9: "fn_Copy_Full_Path", 0: "Copy Full Path"},
            {9: "fn_Paste_Full_Path_to_Driver", 0: "Paste Full Path to Driver"},
            {9: "fn_Add_to_Keying_Set", 0: "Add to Keying Set"},
            {9: "fn_Remove_from_Keying_Set", 0: "Remove from Keying Set"},
            {9: "fn_Reset_to_Default_Value", 0: "Reset to Default Value"},
            {9: "fn_Keyframe_Batch", 0: "Keyframe Batch"},
            {9: "fn_Driver_Batch", 0: "Driver Batch"},
            {9: "fn_Value_Batch", 0: "Value Batch"},
            {9: "fn_detail", 0: "Details"},
        ],
        fin_D1  = override["rm_end"]  if "rm_end" in override else None,
        title   = ti_tx,
        width   = F[150])
    def fn_Copy_Full_Path(self):
#
        bpy.context.window_manager.clipboard = f'{self.R_full_path()}[{self.array_index}]'

    def fn_Add_to_Keying_Set(self):
        try:
#
            if self.is_ref_driver: return
            w = self.w.w
            keying_sets = bpy.context.scene.keying_sets
            act_ks = keying_sets.active
            if act_ks is None:
                act_ks = keying_sets.new(idname='Button Keying Set', name='Button Keying Set')
                act_ks.use_insertkey_xyz_to_rgb = True
                act_ks.use_insertkey_override_xyz_to_rgb = True

            kspath = act_ks.paths.add(w.oj, f'modifiers["{w.act_md.name}"].{self.attr}', index=self.array_index)
            keying_sets.active = keying_sets.active
            m.undo_str = "[Modifier Editor] Add to Keying Set"
            m.undo_push()
            m.admin.report({'INFO'}, f"Property added to Keying Set: '{act_ks.bl_idname}'")
        except: pass
    def fn_Remove_from_Keying_Set(self):
        try:
#
            if self.is_ref_driver: return
            w = self.w.w
            keying_sets = bpy.context.scene.keying_sets
            act_ks = keying_sets.active
            if act_ks is None:  return

            w_oj = w.oj
            dp = f'modifiers["{w.act_md.name}"].{self.attr}'
            paths = act_ks.paths
            i = self.array_index
            for p in paths:
                if p.id != w_oj:        continue
                if p.data_path != dp:   continue
                if p.array_index != i:  continue

                paths.remove(p)
                keying_sets.active = keying_sets.active
                m.undo_str = "[Modifier Editor] Remove from Keying Set"
                m.undo_push()
                m.admin.report({'INFO'}, f"Property removed from Keying Set: '{act_ks.bl_idname}'")
        except: pass
    def fn_Reset_to_Default_Value(self):
        try:
#
            i = self.array_index
            w = self.w.w
            act_md = w.act_md
            attr = self.attr
            prop = act_md.bl_rna.properties[attr]
            prop_ty = prop.type

            if prop_ty == "STRING":
                setattr(act_md, attr, "")
            elif prop_ty == "POINTER":
                setattr(act_md, attr, None)
            else:
                getattr(act_md, attr)[i] = prop.default_array[i]

            m.refresh()
            m.undo_str = f"[Modifier Editor] Reset Value: {attr}[{i}]"
            m.undo_push()
        except:
            pass
    #
    #


class BLFTI(m.BLF):
    __slots__ = 'wrap_wi', 'draw_ti'
    def __init__(self, color=None, text="", size=0, x=0, y=0, wrap_wi=None):
        if wrap_wi is None:
            self.draw_ti = self.I_draw_ti
        else:
            self.draw_ti = self.I_draw_ti_wrap
            self.wrap_wi = wrap_wi

        super().__init__(color, text, size, x, y)
    def draw_rim(self): pass
    def draw_bg(self): pass
    def I_draw_ti(self):
        if self.text:   self.set_draw()
    def I_draw_ti_wrap(self):
        if self.text:
            blf_enable(font_0, WORD_WRAP)
            blf_wrap(font_0, self.wrap_wi)
            self.set_draw()
            blf_disable(font_0, WORD_WRAP)
    def dxy_upd(self, x, y):
        self.x += x
        self.y += y
    def enable(self): self.color = P.color_font_darker
    def disable(self): self.color = P.color_font_ignore


class BU2(BU):
    __slots__ = 'is_eval'
    def __init__(self, w, name, ti,
        fn              = None,
        offset_y_key    = 4.5,
        free_size       = False,
        attr            = None,
        value           = None,
        is_eval         = False,
        ):
        self.color_bg   = P.color_bu_1_off

        self.w      = w
        self.name   = name
        self.fn     = self.setter  if fn is None else fn
        self.attr   = attr
        self.value  = value
        self.rim    = BOX(P.color_bu_1_rim)
        self.bg     = BOX(self.color_bg)

        if free_size is False:
            self.ti = BLF(P.color_font, ti)
            self.draw_ti = self.I_draw_ti
        else:
            self.ti = BLF(P.color_font, ti, free_size)
            self.draw_ti = self.ti.set_draw

        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.unfo       = self.I_off

        self.offset_y_key   = offset_y_key
        self.is_enable      = True
        self.enable         = N
        self.disable        = self.I_disable
        self.is_allow       = True
        self.is_eval        = is_eval

    def setter(self):
        at0, at1 = self.attr
        if self.is_eval:
            try:    obj = eval(at0)
            except: return
        else:
            obj = getattr(self.w.w.act_md, at0, None)
        if obj is None: return

        v = getattr(obj, at1)
        if isinstance(v, set):
            if self.value in v: v.remove(self.value)
            else:               v.add(self.value)
        else:
            if v == self.value: return True
            v = self.value

        try:
            setattr(obj, at1, v)
            m.undo_str = f'[Modifier Editor] md.{at0}.{at1} = "{v}"'
        except: pass
        #
    def R_oo_dr(self): return self.w.oo_dr2[self.attr]
    #
    #
class BUBL2(BUBL):
    __slots__ = 'is_eval'
    def __init__(self, w, name, attr, offset_x_key = 1.5, offset_y_key = 0, fn=None, is_eval=False):
        self.w      = w
        self.name   = name
        self.attr   = attr

        self.da_color           = P.color_bu_2
        self.da_color_ignore    = P.color_bu_2_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.free_fn    = fn
        self.is_eval    = is_eval

    def R_oo_dr(self): return self.w.oo_dr2[self.attr]
    def fn(self):
        self.U_fn   = N
        if self.free_fn is not None:    self.free_fn() ;return

        at0, at1 = self.attr
        if self.is_eval:
            try:    obj = eval(at0)
            except: return
        else:
            obj = getattr(self.w.w.act_md, at0, None)
        if obj is None: return

        if getattr(obj, at1):
            self.da.text = ""
            self.da.name = False
            setattr(obj, at1, False)
            m.undo_str = f'[Modifier Editor] md.{at0}.{at1} = False'
        else:
            self.da.text = "■"
            self.da.name = True
            setattr(obj, at1, True)
            m.undo_str = f'[Modifier Editor] md.{at0}.{at1} = True'
        m.undo_push()
    def rm_init(self, evt):
#
        self.w.oo_dr2[self.attr].rm_init(evt)
    def batch_init(self, evt):
        self.w.oo_dr2[self.attr].fn_Value_Batch()
    #
    #
class BUFL2(BUFL):
    __slots__ = 'is_eval'
    def __init__(self,
            w,
            name,
            attr,
            offset_x_key    = 5.1,
            offset_y_key    = 4.9,
            ty              = "float [-∞,∞]",
            is_eval         = False,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.ty     = ty

        prop = w.props2[attr[1]]
        self.is_cursor_changed = False

        if ty[0:3] == 'int':
            self.bpy_setter     = self.I_bpy_setter_int
            self.tx_format      = R_str_by_deg  if self.__class__ == BUFD else m.U_format_i
            self.unit = 0
            self.step = 1.0
        else:
            self.step = prop.step / 100.0
            u = prop.unit
            if u in {"LENGTH", "VELOCITY"}:
                self.tx_format = m.U_FORMAT_F
                self.unit = 1
            elif u == "AREA":
                self.tx_format = m.U_FORMAT_F2
                self.unit = 2
            elif u == "VOLUME":
                self.tx_format = m.U_FORMAT_F3
                self.unit = 3
            else:
                self.tx_format = m.U_format_f
                self.unit = 0

            self.bpy_setter     = self.I_bpy_setter

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.is_eval    = is_eval

    def R_oo_dr(self): return self.w.oo_dr2[self.attr]
    def R_bpy_value(self):
        try:
            at0, at1 = self.attr
            obj = eval(at0)  if self.is_eval else getattr(self.w.w.act_md, at0, None)
            if obj is None: return 0.0
            return getattr(obj, at1)
        except:
            return 0.0
    def setter(self):
        at0, at1 = self.attr
        if self.is_eval:
            try:    obj = eval(at0)
            except: return
        else:
            obj = getattr(self.w.w.act_md, at0, None)
        if obj is None: return

        flo = getattr(obj, at1)
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def I_bpy_setter(self, flo, undo_push=True):
        at0, at1 = self.attr
        if self.is_eval:
            try:    obj = eval(at0)
            except: return
        else:
            obj = getattr(self.w.w.act_md, at0, None)
        if obj is None: return

        setattr(obj, at1, flo)
        if undo_push:
            m.undo_str = f'[Modifier Editor] md.{at0}.{at1} = {flo}'
            m.undo_push()
    def I_bpy_setter_int(self, flo, undo_push=True):
        at0, at1 = self.attr
        if self.is_eval:
            try:    obj = eval(at0)
            except: return
        else:
            obj = getattr(self.w.w.act_md, at0, None)
        if obj is None: return

        v = round(flo)
        setattr(obj, at1, v)
        if undo_push:
            m.undo_str = f'[Modifier Editor] md.{at0}.{at1} = {v}'
            m.undo_push()
    def R_dp(self):
        at0, at1 = self.attr
        if self.is_eval:
            return ''
        else:
            return f'modifiers["{self.w.w.act_md.name}"].{at0}.{at1}'
    def driver_add(self, exp = ""):
        at0, at1 = self.attr
        if self.is_eval:
            try:    obj = eval(at0)
            except: return
        else:
            obj = getattr(self.w.w.act_md, at0, None)
        if obj is None: return

#
        dr = obj.animation_data.drivers.find(at1)  if obj.animation_data else None
        if dr is None:  dr = obj.driver_add(at1)
        else:           dr.driver.type = 'SCRIPTED'
        dr.driver.expression = exp
        P.refresh = True
        m.undo_str = f'[Modifier Editor] driver.expression = {exp}'
        m.undo_push()
    def I_qe_real_time_float(self, dx):
        try:
            at0, at1 = self.attr
            self.qe_value += dx
            if self.is_eval:
                setattr(eval(at0), at1, self.qe_value)
            else:
                setattr(getattr(self.w.w.act_md, at0), at1, self.qe_value)
            self.da.text = self.tx_format(self.qe_value)
        except: pass
    def I_qe_real_time_int(self, dx):
        try:
            at0, at1 = self.attr
            self.qe_value += dx
            v = round(self.qe_value)
            if self.is_eval:
                setattr(eval(at0), at1, v)
            else:
                setattr(getattr(self.w.w.act_md, at0), at1, v)
            self.da.text = self.tx_format(v)
        except: pass

    def rm_init(self, evt):
#
        self.w.oo_dr2[self.attr].rm_init(evt)
    #
    #
class BUTX2(BUTX):
    __slots__ = 'is_eval'
    def __init__(self, w, name, attr, fil,
            offset_x_key    = 5.1,
            offset_y_key    = 5.1,
            is_str          = False,
            update_filter   = None,
            bpy_setter      = None,
            is_eval         = False,
            fns             = None,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.fil    = fil

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key
        self.is_str             = is_str
        self.update_filter      = update_filter

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.bpy_setter = self.I_bpy_setter  if bpy_setter is None else bpy_setter
        self.is_eval    = is_eval
        self.fns        = fns
        if fns is None:
            self.ti = {}
        else:
            self.ti = {"x": BLF(P.color_font_darker, "✕", F[15])}
            if "pick" in fns:   self.ti["pick"] = BLF(P.color_font_darker, "⊕", F[10])

    def setter(self):
        at0, at1 = self.attr
        if self.is_eval:
            try:    attr = getattr(eval(at0), at1)
            except: attr = None
        else:
            try:    attr = getattr(getattr(self.w.w.act_md, at0), at1)
            except: attr = None

        if self.is_str:
            self.set_da("" if attr is None else attr)
            return

        if isinstance(self.update_filter, dict):
            if attr is None:    attr = ""
            self.set_da(self.update_filter[attr] if attr in self.update_filter else attr)
            return

        if attr == None:    self.set_da("")
        else:               self.set_da(attr.name)
        #
    def I_bpy_setter(self, s, undo_push=True):
        at0, at1 = self.attr

        if isinstance(self.update_filter, dict):
            try:
                if s in self.update_filter: pass
                else:
                    dict_rev = {e: k for k, e in self.update_filter.items()}
                    if s in dict_rev: s = dict_rev[s]

                if self.is_eval:
                    setattr(eval(at0), at1, s)
                    if undo_push:
                        m.undo_str = f'[Modifier Editor] {at1} = {s}'
                        m.undo_push()
                        m.power_upd()
                    return

                setattr(getattr(self.w.w.act_md, at0), at1, s)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{at0}.{at1} = {s}'
                    m.undo_push()
                    m.power_upd()
            except: pass
            return

        try:
            if self.is_str:
                if self.is_eval:
                    setattr(eval(at0), at1, s)
                    if undo_push:
                        m.undo_str = f'[Modifier Editor] {at1} = "{s}"'
                        m.undo_push()
                        m.power_upd()
                    return

                setattr(getattr(self.w.w.act_md, at0), at1, s)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{at0}.{at1} = "{s}"'
                    m.undo_push()
                    m.power_upd()
                return

            if s == "":
                if self.is_eval:
                    setattr(eval(at0), at1, None)
                    if undo_push:
                        m.undo_str = f'[Modifier Editor] {at1} = None'
                        m.undo_push()
                        m.power_upd()
                    return
                setattr(getattr(self.w.w.act_md, at0), at1, None)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{at0}.{at1} = None'
                    m.undo_push()
                    m.power_upd()
            else:
                bpy_type = self.fil.bpy_type
                collection = eval(bpy_type) if isinstance(bpy_type, str) else bpy_type
                tar = collection[s]
                if self.is_eval:
                    setattr(eval(at0), at1, tar)
                    if undo_push:
                        m.undo_str = f'[Modifier Editor] {at1} ▶ {getattr(tar, "name", tar)}'
                        m.undo_push()
                        m.power_upd()
                    return
                setattr(getattr(self.w.w.act_md, at0), at1, tar)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md.{at0}.{at1} ▶ {getattr(tar, "name", tar)}'
                    m.undo_push()
                    m.power_upd()
        except: pass
        #
    def R_oo_dr(self, evt):
        oo_dr2 = self.w.oo_dr2
        if self.attr in oo_dr2:
            bu_dr = oo_dr2[self.attr]
        else:
            "TODO"
            return None
            bu_dr = BUDR(self.w, "", f"{self.attr}".title(), self.attr, is_ref_driver=True)
            x = evt.mouse_region_x
            y = evt.mouse_region_y
            bu_dr.rim.LRBT(x, x, y, y)
            if f"bu_{self.attr}" in self.w.oo:
                bu_dr.ti.color = self.w.oo[f"bu_{self.attr}"].ti.color
        return bu_dr
    #
    #
class BUKF2(BUKF):
    __slots__ = 'is_eval', 'R_anim_data', 'R_fc_path'
    def __init__(self, w, name, attr, type_attr=True, is_eval=False, R_fc_path=None):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, "•")

        self.U_set_last         = self.IU_set_no_kf
        self.U_set_no_kf        = N
        self.U_set_kf_fit       = self.I_set_kf_fit
        self.U_set_kf_unfit     = self.I_set_kf_unfit
        self.U_set_nokf_fit     = self.I_set_nokf_fit
        self.U_set_nokf_unfit   = self.I_set_nokf_unfit
        self.draw_ti            = self.I_draw_ti

        w.oo_kf2[attr] = self
        self.is_eval = is_eval
        self.is_enable = True

        if type_attr is True:       self.upd_ti = self.upd_fc
        elif type_attr is False:    self.upd_ti = self.upd_fc_bool
        else:
            self.upd_ti = self.upd_fc_enum_set if frozenset_empty in type_attr else self.upd_fc_enum
            self.enum   = type_attr

        self.R_fc_path = self.R_fc_path_default  if R_fc_path is None else R_fc_path

    def R_oo_dr(self): return self.w.oo_dr2[self.attr]
    def R_fc_path_default(self): return self.attr[1]

    def upd_fc(self, an_data, obj):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(self.R_fc_path())
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if fc.evaluate(r) == getattr(obj, self.attr[1], None): self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if fc.evaluate(r) == getattr(obj, self.attr[1], None): self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_enum(self, an_data, obj):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(self.R_fc_path())
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        v = getattr(obj, self.attr[1], None)
                        if v in self.enum and self.enum[v] == round(fc.evaluate(r)): self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        v = getattr(obj, self.attr[1], None)
                        if v in self.enum and self.enum[v] == round(fc.evaluate(r)): self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_enum_set(self, an_data, obj):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(self.R_fc_path())
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        v = frozenset(getattr(obj, self.attr[1], None))
                        if v in self.enum and self.enum[v] == round(fc.evaluate(r)): self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        v = frozenset(getattr(obj, self.attr[1], None))
                        if v in self.enum and self.enum[v] == round(fc.evaluate(r)): self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_bool(self, an_data, obj):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(self.R_fc_path())
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if round(fc.evaluate(r)) == int(getattr(obj, self.attr[1], None)):
                            self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if round(fc.evaluate(r)) == int(getattr(obj, self.attr[1], None)):
                            self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()

    def I_fc_event(self, require=None):
#
        self.fc_event = N
        at0, at1 = self.attr
        if self.is_eval:
            try:    obj = eval(at0)
            except: obj = None
        else:
            obj = getattr(self.w.w.act_md, at0, None)

        if obj is None: return

        anim_data = self.R_anim_data() if hasattr(self, "R_anim_data") else obj.animation_data
        path = f'{at1}'
        self.upd_ti(anim_data, obj)

        if require is None:
            if self.ti.text == "◆":
                obj.keyframe_delete(path)
                m.undo_str = f"[Modifier Editor] keyframe_delete('{path}')"
            else:
                obj.keyframe_insert(path)
                m.undo_str = f"[Modifier Editor] keyframe_insert('{path}')"
        elif require == "INSERT":
            obj.keyframe_insert(path)
            m.undo_str = f"[Modifier Editor] keyframe_insert('{path}')"
        else:
            obj.keyframe_delete(path)
            m.undo_str = f"[Modifier Editor] keyframe_delete('{path}')"

        P.refresh = True
        m.refresh()
        self.get_color_fo()
        m.redraw()
        m.undo_push()
    #
    #
class BUDR2(BUDR):
    __slots__ = 'is_eval', 'fn_reset', 'fn_full_path'
    def __init__(self, w, name, ti, attr,
            array_index     = 0,
            is_ref_driver   = False,
            is_eval = False,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, ti)

        self.U_set_ti_dr    = self.I_set_ti_dr
        self.U_set_ti_nodr  = N
        self.draw_ti        = self.I_draw_ti
        self.array_index    = array_index
        self.is_ref_driver  = is_ref_driver

        w.oo_dr2[attr] = self
        self.is_eval = is_eval
        self.is_enable = True

    def R_oo_kf(self): return self.w.oo_kf2[self.attr]

    def upd_dr(self, an_data):
        if an_data:
            drivers = an_data.drivers
            if drivers:
                if self.is_ref_driver:
                    path = f'["self.{self.attr}"]'
                else:
                    path = f'{self.attr[1]}'
                if drivers.find(path) != None:
                    self.U_set_ti_dr()
                    return
        self.U_set_ti_nodr()

    def I_dr_event(self):
        m.admin.report({'INFO'}, "Coming Soon")

    def R_data_path(self):
        at0, at1 = self.attr
        return f'{at1}'
    def R_full_path(self):
        if hasattr(self, "fn_full_path"):
            return self.fn_full_path()

        w = self.w.w
        at0, at1 = self.attr
        if self.is_eval:
            oj = eval(at0)
        else:
            oj = getattr(w.act_md, at0)
        try:
            datas = D_rna_blendData[oj.rna_type.identifier]
        except: return ""

        return f'bpy.data.{datas}[{R_lib_name(oj)}].{at1}'
    def driver_add(self, exp = "var"):
        m.admin.report({'INFO'}, "Coming Soon")
    def driver_remove(self):
        try:
            w = self.w.w
            at0, at1 = self.attr
            if self.is_eval:
                oj = eval(at0)
            else:
                oj = getattr(w.act_md, at0)

            fcs = oj.animation_data.drivers
            fc = fcs.find(at1)
            if fc is None: return False
            fcs.remove(fc)
            return True
        except: return False
    def fn_Clear_Keyframe(self):
        at0, at1 = self.attr
        w       = self.w.w
        path = f'{at1}'
        if self.is_eval:
            try:    fc = TR_fc_by_path(eval(at0), path)
            except: return
        else:
            fc = TR_fc_by_path(getattr(w.act_md, at0, None), path)
        if fc is None:  return
        w.oj.animation_data.action.fcurves.remove(fc)
        P.refresh = True
        m.refresh()
        m.redraw()
        m.undo_str = f"[Modifier Editor] Clear Keyframe {path}"
        m.undo_push()
    def fn_Add_Driver(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_Open_Driver_Editor(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_Add_to_Keying_Set(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_Remove_from_Keying_Set(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_Reset_to_Default_Value(self):
        if hasattr(self, "fn_reset"):
            try:    self.fn_reset()
            except: pass
            return
        try:
#
            w = self.w.w
            at0, at1 = self.attr
            if self.is_eval:
                obj = eval(at0)
            else:
                obj = getattr(w.act_md, at0)
            prop = obj.bl_rna.properties[at1]
            if getattr(prop, "is_array", False):
                getattr(obj, at1)[:] = prop.default_array
            else:
                setattr(obj, at1, prop.default)

            m.refresh()
            m.undo_str = f"[Modifier Editor] Reset Value: {at1}"
            m.undo_push()
        except:
            pass
    def fn_Add_Reference_Driver(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_Delete_Reference_Driver(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_Keyframe_Batch(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_Driver_Batch(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_Value_Batch(self):
        evt = m.EVT.evt
        w = self.w.w
        at0, at1 = self.attr
        if self.is_eval:
            return
            oj = eval(at0)
        else:
            oj = getattr(w.act_md, at0)

        attrs = [e[1]  for e in self.w.oo_dr2]
        attrs.sort()
        MESS_BATCH_VAL2(evt.mouse_region_x, evt.mouse_region_y, self, (lambda e: getattr(e, at0)), at1, attrs, [], [], 2, 0)

    # /* 0BUDR2_rm_init
    def rm_init(self, evt, override=None):
        if self.attr is None:   return
#
        self.enforce_outside()
        bu_kf       = self.R_oo_kf()  if self.attr in self.w.oo_kf2 else None

        if self.is_ref_driver:
            md_type = self.w.w.act_md.type
            attrs = getattr(MOD_REF_ATTR, md_type, None)
            if attrs is not None:
                if self.attr in attrs:
                    o = self.w.w.oj
                    try:
                        path = f'modifiers[{self.w.w.act_md.name}].{self.attr}'
                        dr = o.animation_data.drivers.find(f'["{path}"]')
                    except:
                        dr = None

                    if dr is None:
                        line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 0}
                    else:
                        line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 1}
                else:
                    attrs = None

            if attrs is None:
                line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver ", 1: 0}
                line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver ", 1: 0}
            line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe ", 1: 0}
            line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe ", 1: 0}
            line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe ", 1: 0}
        else:
            if bu_kf.ti.text == "◆":
                line0 = {9: "fn_Replace_Keyframe", 0: "Replace Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 1}
            else:
                line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 0}

            if bu_kf.ti.text == "•":
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 0}
            else:
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 1}

            if self.U_set_ti_dr == self.I_set_ti_dr:
                line3 = {9: "fn_Add_Driver", 0: "Add Driver"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 0}
            else:
                line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 1}

        if override is None:    override = {}
        if "title" in override:
            ti_tx = override["title"]
        else:
            ti_tx       = self.ti.text
            if ti_tx[-2:] == " :":  ti_tx = ti_tx[:-2]

        m.tm["bu_kf"] = bu_kf

        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y,
        override["li"]  if "li" in override else [
            line0,
            line1,
            line2,
            line3,
            line4,
            {9: "fn_Copy_Data_Path", 0: "Copy Data Path"},
            {9: "fn_Copy_Full_Path", 0: "Copy Full Path"},
            {9: "fn_Paste_Full_Path_to_Driver", 0: "Paste Full Path to Driver"},
            {9: "fn_Add_to_Keying_Set", 0: "Add to Keying Set"},
            {9: "fn_Remove_from_Keying_Set", 0: "Remove from Keying Set"},
            {9: "fn_Reset_to_Default_Value", 0: "Reset to Default Value"},
            {9: "fn_Keyframe_Batch", 0: "Keyframe Batch"},
            {9: "fn_Driver_Batch", 0: "Driver Batch"},
            {9: "fn_Value_Batch", 0: "Value Batch"},
            {9: "fn_detail", 0: "Details"},
        ],
        fin_D1  = override["rm_end"]  if "rm_end" in override else None,
        title   = ti_tx,
        width   = F[150])
    # */

    def fn_Paste_Full_Path_to_Driver(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_detail(self):
        try:
            w = self.w.w
            at0, at1 = self.attr
            if self.is_eval:
                obj = eval(at0)
            else:
                obj = getattr(w.act_md, at0)
            rna = obj.bl_rna.properties[at1]
        except: return

        # <<< 1copy (0ui_fn_detail,, ${'self.rna':'rna'}$)
        if not hasattr(rna, "description"): return
        name = rna.name
        if not name: name = " "
        description = rna.description
        if not isinstance(description, str):    description = description()
        if not description: description = "No description."
        details = INFO(name, description)
        evt = m.EVT.evt
        blf_size(font_0, F[9])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, F[480])
        e = BLF(text=details.body)
        hi = round(e.R_dimen_y()) + F[-1] + F[46]
        e.text = details.title
        hi += round(e.R_dimen_y())
        wi = F[480]
        blf_disable(font_0, WORD_WRAP)
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), details)
        # >>>

    def batch_init(self, evt, ind=0, operation=0):
        pass
    #
    #

class GEOFL(BUFL2): # need set tx_format, unit
    __slots__ = ()
    def __init__(self,
            w,
            name,
            attr,
            offset_x_key    = 5.1,
            offset_y_key    = 4.9,
            ty              = "float [-∞,∞]",
            is_eval         = False,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.ty     = ty

        self.is_cursor_changed = False

        if ty[0:3] == 'int':
            self.bpy_setter     = self.I_bpy_setter_int
            self.step = 1.0
        else:
            self.bpy_setter     = self.I_bpy_setter
            self.step = max(0.0001, min((attr.max_value - attr.min_value) / 100.0, 1.0))

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.is_eval    = is_eval

    def R_bpy_value(self):
        try:    return self.w.w.act_md[self.attr.identifier]
        except: return 0.0
    # /* 0GEOFL_setter
    def setter(self):
        flo = self.R_bpy_value()
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def I_bpy_setter(self, flo, undo_push=True):
        try:
            flo = float(flo)
            self.w.w.act_md[self.attr.identifier] = flo
            if undo_push:
                m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"] = {flo}'
                m.undo_push()
                m.power_upd()
        except: pass
    # */
    def I_bpy_setter_int(self, flo, undo_push=True):
        try:
            flo = round(flo)
            self.w.w.act_md[self.attr.identifier] = flo
            if undo_push:
                m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"] = {flo}'
                m.undo_push()
                m.power_upd()
        except: pass
    def R_dp(self):
        return self.w.oo_dr2[self.attr].R_data_path()
    def driver_add(self, exp = "var"):
        return self.w.oo_dr2[self.attr].driver_add(exp)
    def I_qe_real_time_float(self, dx):
        try:
            self.qe_value += dx
            self.w.w.act_md[self.attr.identifier] = self.qe_value
            self.da.text = self.tx_format(self.qe_value)
        except: pass
    def I_qe_real_time_int(self, dx):
        try:
            self.qe_value += dx
            v = round(self.qe_value)
            self.w.w.act_md[self.attr.identifier] = v
            self.da.text = self.tx_format(v)
        except: pass
    def fn(self, multi_edit=None):
        if self.da.name is None: return
        DDVAL(self, self.ty, multi_edit=multi_edit, end_fn=m.refresh,
            override_ty="calc_0pf"  if self.attr.bl_subtype_label == "Angle" else None)
    #
    #
class GEOFLS(BUFLS): # need set tx_format, unit
    __slots__ = ()
    def __init__(self,
            w,
            name,
            attr,
            offset_x_key    = 5.1,
            offset_y_key    = 4.9,
            ty              = "float [-∞,∞]",
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.ty     = ty

        self.is_cursor_changed = False

        if ty[0:3] == 'int':
            self.bpy_setter     = self.I_bpy_setter_int
            self.step = 1.0
        else:
            self.bpy_setter     = self.I_bpy_setter
            self.step = max(0.0001, min((attr.max_value - attr.min_value) / 100.0, 1.0))

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = offset_x_key
        self.offset_y_key       = offset_y_key

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True

    def R_bpy_value(self):
        try:    return self.w.w.act_md[self.attr.identifier][self.index]
        except: return 0.0
    # /* 0GEOFLS_setter
    def setter(self):
        flo = self.R_bpy_value()
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def I_bpy_setter(self, flo, bu_range=None, undo_push=True):
        try:
            lis = self.w.w.act_md[self.attr.identifier]
            if bu_range is None:
                lis[self.index] = float(flo)
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"][{self.index}] = {flo}'
                    m.undo_push()
                    m.power_upd()
            else:
                i0, i1 = bu_range
                lis[i0 : i1] = [float(e)  for e in flo]
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"][{bu_range[0]}:{bu_range[1]}] = {flo}'
                    m.undo_push()
                    m.power_upd()
        except: pass
    # */
    def I_bpy_setter_int(self, flo, bu_range=None, undo_push=True):
        try:
            lis = self.w.w.act_md[self.attr.identifier]
            if bu_range is None:
                flo = round(flo)
                lis[self.index] = flo
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"][{self.index}] = {flo}'
                    m.undo_push()
                    m.power_upd()
            else:
                i0, i1 = bu_range
                lis[i0 : i1] = [round(e) for e in flo]
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"][{bu_range[0]}:{bu_range[1]}] = {flo}'
                    m.undo_push()
                    m.power_upd()
        except: pass
    def R_dp(self):
        return self.R_oo_dr().R_data_path()
    def driver_add(self, exp = "var"):
        return self.R_oo_dr().driver_add(exp)
    def R_oo_dr(self): return self.w.oo_dr2[self.attr, self.index]
    def fn(self, multi_edit=None):
        if self.da.name is None: return
        DDVAL(self, self.ty, multi_edit=multi_edit, end_fn=m.refresh,
            override_ty="calc_0pf"  if self.attr.bl_subtype_label == "Euler Angles" else None)
    #
    #
class GEOFD(GEOFL):
    __slots__ = ()
    def do_step(self, flo): self.bpy_setter(math_deg(self.R_bpy_value()) + flo)
    def set_da(self, flo):
        deg = math_deg(flo)
        if self.da.name != deg:
            self.da.name = deg
            self.da.text = self.tx_format(deg)

    # <<< 1copy (0GEOFL_setter,, ${
    #     "flo = self.R_bpy_value()": "flo = math_deg(self.R_bpy_value())",
    #     "flo = float(flo)": "flo = float(math_rad(flo))",
    # }$)
    def setter(self):
        flo = math_deg(self.R_bpy_value())
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def I_bpy_setter(self, flo, undo_push=True):
        try:
            flo = float(math_rad(flo))
            self.w.w.act_md[self.attr.identifier] = flo
            if undo_push:
                m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"] = {flo}'
                m.undo_push()
                m.power_upd()
        except: pass
    # >>>

    def fn(self, multi_edit=None):
        if self.da.name is None: return
        DDVAL(self, self.ty, multi_edit=multi_edit, end_fn=m.refresh, override_ty="calc_0df")

    def I_qe_performance_float(self, dx):
        self.qe_value += dx
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_performance_int(self, dx):
        pass
    def I_qe_real_time_float(self, dx):
        self.qe_value += dx
        self.w.w.act_md[self.attr.identifier] = math_rad(self.qe_value)
        self.da.text = self.tx_format(self.qe_value)
    def I_qe_real_time_int(self, dx):
        pass
    #
    #
class GEOFDS(GEOFLS):
    __slots__ = ()
    def do_step(self, flo): self.bpy_setter(math_deg(self.R_bpy_value()) + flo)
    def set_da(self, flo):
        deg = math_deg(flo)
        if self.da.name != deg:
            self.da.name = deg
            self.da.text = self.tx_format(deg)

    # <<< 1copy (0GEOFLS_setter,, ${
    #     "flo = self.R_bpy_value()": "flo = math_deg(self.R_bpy_value())",
    #     "float(flo)": "float(math_rad(flo))",
    #     "float(e)": "float(math_rad(e))",
    # }$)
    def setter(self):
        flo = math_deg(self.R_bpy_value())
        if self.da.name != flo:
            self.da.name = flo
            self.da.text = self.tx_format(flo)
    def I_bpy_setter(self, flo, bu_range=None, undo_push=True):
        try:
            lis = self.w.w.act_md[self.attr.identifier]
            if bu_range is None:
                lis[self.index] = float(math_rad(flo))
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"][{self.index}] = {flo}'
                    m.undo_push()
                    m.power_upd()
            else:
                i0, i1 = bu_range
                lis[i0 : i1] = [float(math_rad(e))  for e in flo]
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"][{bu_range[0]}:{bu_range[1]}] = {flo}'
                    m.undo_push()
                    m.power_upd()
        except: pass
    # >>>

    def fn(self, multi_edit=None):
        if self.da.name is None: return
        DDVAL(self, self.ty, multi_edit=multi_edit, end_fn=m.refresh, override_ty="calc_0df")

    #
    #
class GEOBOOL(BUBL2):
    __slots__ = ()
    def __init__(self, w, name, attr):
        self.w      = w
        self.name   = name
        self.attr   = attr

        self.da_color           = P.color_bu_2
        self.da_color_ignore    = P.color_bu_2_ignore
        self.offset_x_key       = 1.5
        self.offset_y_key       = 0

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.free_fn    = None
    def fn(self):
        self.U_fn   = N
        try:
            s = not self.w.w.act_md[self.attr.identifier]
            self.w.w.act_md[self.attr.identifier] = s
            m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"] ▶ {s}'
            m.undo_push()
            m.power_upd()
        except: pass
    #
    #
class GEOSTR(BUTX2):
    __slots__ = ()
    def __init__(self, w, name, attr, fil=None, is_str=True, fns=None):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.fil    = fil

        self.da_color           = P.color_font
        self.da_color_ignore    = P.color_font_ignore
        self.offset_x_key       = 5.1
        self.offset_y_key       = 5.1
        self.is_str             = is_str
        self.update_filter      = None

        self.rim        = BOX(P.color_bu_3_off)
        self.da         = BLF(self.da_color)
        self.da.name    = None
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True
        self.bpy_setter = self.I_bpy_setter
        self.fns        = fns
        if fns is None:
            self.ti = {}
        else:
            self.ti = {"x": BLF(P.color_font_darker, "✕", F[15])}
            if "pick" in fns:   self.ti["pick"] = BLF(P.color_font_darker, "⊕", F[10])

    def setter(self):
        if self.is_str:
            self.set_da(self.w.w.act_md[self.attr.identifier])
        else:
            v = self.w.w.act_md[self.attr.identifier]
            self.set_da("" if v == None else v.name)
    def I_bpy_setter(self, s, undo_push=True):
        if self.is_str:
            try:
                self.w.w.act_md[self.attr.identifier] = s
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"] = {s}'
                    m.undo_push()
                    m.power_upd()
            except: pass
            return

        try:
            if s == "":
                self.w.w.act_md[self.attr.identifier] = None
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"] = None'
                    m.undo_push()
                    m.power_upd()
            else:
                bpy_type = self.fil.bpy_type
                collection = eval(bpy_type) if isinstance(bpy_type, str) else bpy_type
                tar = collection[R_lib_tuple(collection, s)]
                self.w.w.act_md[self.attr.identifier] = tar
                if undo_push:
                    m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"] ▶ tar.name'
                    m.undo_push()
                    m.power_upd()
        except: pass
    #
    #
class GEOATTR(GEOSTR):
    __slots__ = ()
    def setter(self):
        self.set_da(self.w.w.act_md[f'{self.attr.identifier}_attribute_name'])
    def I_bpy_setter(self, s, undo_push=True):
        try:
            at = f'{self.attr.identifier}_attribute_name'
            self.w.w.act_md[at] = s
            if undo_push:
                m.undo_str = f'[Modifier Editor] md["{at}"] ▶ {s}'
                m.undo_push()
                m.power_upd()
        except: pass
class GEOKF(BUKF2):
    __slots__ = ()
    def R_fc_path_default(self): return f'modifiers["{self.w.w.act_md.name}"]["{self.attr.identifier}"]'

    def upd_fc(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(self.R_fc_path())
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if fc.evaluate(r) == act_md[self.attr.identifier]: self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if fc.evaluate(r) == act_md[self.attr.identifier]: self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_bool(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(self.R_fc_path())
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if round(fc.evaluate(r)) == int(act_md[self.attr.identifier]):
                            self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if round(fc.evaluate(r)) == int(act_md[self.attr.identifier]):
                            self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()

    def I_fc_event(self, require=None):
#
        self.fc_event = N
        ww = self.w.w
        obj = ww.act_md

        path = f'["{self.attr.identifier}"]'
        self.upd_ti(ww.oj.animation_data, obj)

        if require is None:
            if self.ti.text == "◆":
                obj.keyframe_delete(path)
                m.undo_str = f"[Modifier Editor] keyframe_delete('{path}')"
            else:
                obj.keyframe_insert(path)
                m.undo_str = f"[Modifier Editor] keyframe_insert('{path}')"
        elif require == "INSERT":
            obj.keyframe_insert(path)
            m.undo_str = f"[Modifier Editor] keyframe_insert('{path}')"
        else:
            obj.keyframe_delete(path)
            m.undo_str = f"[Modifier Editor] keyframe_delete('{path}')"

        P.refresh = True
        m.refresh()
        self.get_color_fo()
        m.redraw()
        m.undo_push()
        m.head_modal.append(self.modal_wait_release)
    def modal_wait_release(self, evt):
        if self.rim.inbox(evt) == False or self.w.sci.inbox(evt) == False or evt.value == "RELEASE":
            del m.head_modal[-1]
    #
    #
class GEODR(BUDR2):
    __slots__ = ()
    def R_data_path(self):
        try:
            use_attr = self.w.w.act_md[f'{self.attr.identifier}_use_attribute']
        except:
            use_attr = False
        at = f'{self.attr.identifier}_attribute_name'  if use_attr else self.attr.identifier
        return f'modifiers["{self.w.w.act_md.name}"]["{at}"]'
    def R_full_path(self):
        return f'bpy.data.objects["{self.w.w.oj.name}"].{self.R_data_path()}'
    def driver_add(self, exp = "var"):
        try:
            fc = self.w.w.act_md.driver_add(f'["{self.attr.identifier}"]')
            fc.driver.expression = "var"
            return fc
        except:
            return None
    def driver_remove(self):
#
        return self.w.w.act_md.driver_remove(f'["{self.attr.identifier}"]')

    def upd_dr(self, an_data):
        if an_data:
            drivers = an_data.drivers
            if drivers:
                if self.is_ref_driver:
                    return

                if drivers.find(f'modifiers["{self.w.w.act_md.name}"]["{self.attr.identifier}"]') != None:
                    self.U_set_ti_dr()
                    return
        self.U_set_ti_nodr()

    def has_driver(self):
        an_data = self.w.w.oj.animation_data
        if an_data:
            drivers = an_data.drivers
            if drivers:
                if drivers.find(f'modifiers["{self.w.w.act_md.name}"]["{self.attr.identifier}"]') != None:
                    return True
        return False
    def I_dr_event(self):
#
        self.draw_ti    = self.I_draw_ti
        self.w.U_modal  = self.w.default_modal

        if not self.has_driver():
            self.fn_Add_Driver()
            return

        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()

    def fn_Clear_Keyframe(self):
        w       = self.w.w
        path = f'modifiers["{w.act_md.name}"]["{self.attr.identifier}"]'
        fc = TR_fc_by_path(w.oj, path)
        if fc is None:  return
        w.oj.animation_data.action.fcurves.remove(fc)
        P.refresh = True
        m.refresh()
        m.redraw()
        m.undo_str = f"[Modifier Editor] Clear Keyframe {path}"
        m.undo_push()
    def fn_Add_Driver(self):
#
        fc = self.driver_add()
        if fc == None:
            m.admin.report({'INFO'}, "Not animatable")
            return

        m.undo_str = "[Modifier Editor] md.driver_add('[" + f'"{self.attr.identifier}"' + "]')"
        m.undo_push()
        m.power_upd()

        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()
    def fn_Open_Driver_Editor(self):
#
        from .. ED_dr.dr_ed import DR_ED
        DR_ED(self)
        m.init_wait_release()
    def fn_Delete_Driver(self):
#
        if self.driver_remove():
            m.undo_str = "[Modifier Editor] Driver Delete"
            m.undo_push()
            m.power_upd()
    def fn_Paste_Full_Path_to_Driver(self):
        full_path = bpy.context.window_manager.clipboard
        if not full_path:
            m.admin.report({'INFO'}, "Clipboard is Empty")
            return
        tar_obj, dr_path = R_obj_path_by_full_path(full_path)
        if tar_obj is None:
            m.admin.report({'INFO'}, "Invalid path")
            return

        id_type = R_id_type(tar_obj)
        if id_type is None: return
        try:
            w = self.w.w
            fc = self.driver_add()
            if fc == None:
                m.admin.report({'INFO'}, "Can't add driver")
                return
            vs = fc.driver.variables
            v = vs[0] if vs else vs.new()
            tar = v.targets[0]
            tar.id_type = id_type
            tar.id = tar_obj
            tar.data_path = dr_path
        except:
            m.admin.report({'INFO'}, "Unknown Error")
            return

        m.undo_str = f"[Modifier Editor] Paste Full Path to Driver"
        m.undo_push()
        m.power_upd()
    def fn_Add_to_Keying_Set(self):
        try:
#
            if self.is_ref_driver: return
            w = self.w.w
            keying_sets = bpy.context.scene.keying_sets
            act_ks = keying_sets.active
            if act_ks is None:
                act_ks = keying_sets.new(idname='Button Keying Set', name='Button Keying Set')
                act_ks.use_insertkey_xyz_to_rgb = True
                act_ks.use_insertkey_override_xyz_to_rgb = True

            kspath = act_ks.paths.add(w.oj, f'modifiers["{w.act_md.name}"]["{self.attr.identifier}"]')
            keying_sets.active = keying_sets.active
            m.undo_str = "[Modifier Editor] Add to Keying Set"
            m.undo_push()
            m.admin.report({'INFO'}, f"Property added to Keying Set: '{act_ks.bl_idname}'")
        except: pass
    def fn_Remove_from_Keying_Set(self):
        try:
#
            if self.is_ref_driver: return
            w = self.w.w
            keying_sets = bpy.context.scene.keying_sets
            act_ks = keying_sets.active
            if act_ks is None:  return

            w_oj = w.oj
            dp = f'modifiers["{w.act_md.name}"]["{self.attr.identifier}"]'
            paths = act_ks.paths
            for p in paths:
                if p.id != w_oj:        continue
                if p.data_path != dp:   continue

                paths.remove(p)
                keying_sets.active = keying_sets.active
                m.undo_str = "[Modifier Editor] Remove from Keying Set"
                m.undo_push()
                m.admin.report({'INFO'}, f"Property removed from Keying Set: '{act_ks.bl_idname}'")
        except: pass
    def fn_Reset_to_Default_Value(self):
        try:
#
            v = self.attr.default_value
            self.w.w.act_md[self.attr.identifier] = v
            m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"] ▶ {v}'
            m.undo_push()
            m.power_upd()
        except:
            pass
    def fn_Value_Batch(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_detail(self):
        try:
            rna = self.attr
        except: return

        # <<< 1copy (0ui_fn_detail,, ${'self.rna':'rna'}$)
        if not hasattr(rna, "description"): return
        name = rna.name
        if not name: name = " "
        description = rna.description
        if not isinstance(description, str):    description = description()
        if not description: description = "No description."
        details = INFO(name, description)
        evt = m.EVT.evt
        blf_size(font_0, F[9])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, F[480])
        e = BLF(text=details.body)
        hi = round(e.R_dimen_y()) + F[-1] + F[46]
        e.text = details.title
        hi += round(e.R_dimen_y())
        wi = F[480]
        blf_disable(font_0, WORD_WRAP)
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), details)
        # >>>

    # <<< 1copy (0BUDR2_rm_init,, ${
    #     '0: "Paste Full Path to Driver"': '0: "Paste Full Path to Driver", 1: 0 if self.is_ref_driver else 1',
    #     '0: "Add to Keying Set"': '0: "Add to Keying Set", 1: 0 if self.is_ref_driver else 1',
    #     '0: "Remove from Keying Set"': '0: "Remove from Keying Set", 1: 0 if self.is_ref_driver else 1',
    #     '0: "Keyframe Batch"': '0: "Keyframe Batch", 1: 0 if self.is_ref_driver else 1',
    #     '0: "Driver Batch"': '0: "Driver Batch", 1: 0 if self.is_ref_driver else 1',
    # }$)
    def rm_init(self, evt, override=None):
        if self.attr is None:   return
#
        self.enforce_outside()
        bu_kf       = self.R_oo_kf()  if self.attr in self.w.oo_kf2 else None

        if self.is_ref_driver:
            md_type = self.w.w.act_md.type
            attrs = getattr(MOD_REF_ATTR, md_type, None)
            if attrs is not None:
                if self.attr in attrs:
                    o = self.w.w.oj
                    try:
                        path = f'modifiers[{self.w.w.act_md.name}].{self.attr}'
                        dr = o.animation_data.drivers.find(f'["{path}"]')
                    except:
                        dr = None

                    if dr is None:
                        line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 0}
                    else:
                        line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 1}
                else:
                    attrs = None

            if attrs is None:
                line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver ", 1: 0}
                line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver ", 1: 0}
            line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe ", 1: 0}
            line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe ", 1: 0}
            line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe ", 1: 0}
        else:
            if bu_kf.ti.text == "◆":
                line0 = {9: "fn_Replace_Keyframe", 0: "Replace Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 1}
            else:
                line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 0}

            if bu_kf.ti.text == "•":
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 0}
            else:
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 1}

            if self.U_set_ti_dr == self.I_set_ti_dr:
                line3 = {9: "fn_Add_Driver", 0: "Add Driver"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 0}
            else:
                line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 1}

        if override is None:    override = {}
        if "title" in override:
            ti_tx = override["title"]
        else:
            ti_tx       = self.ti.text
            if ti_tx[-2:] == " :":  ti_tx = ti_tx[:-2]

        m.tm["bu_kf"] = bu_kf

        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y,
        override["li"]  if "li" in override else [
            line0,
            line1,
            line2,
            line3,
            line4,
            {9: "fn_Copy_Data_Path", 0: "Copy Data Path"},
            {9: "fn_Copy_Full_Path", 0: "Copy Full Path"},
            {9: "fn_Paste_Full_Path_to_Driver", 0: "Paste Full Path to Driver", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Add_to_Keying_Set", 0: "Add to Keying Set", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Remove_from_Keying_Set", 0: "Remove from Keying Set", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Reset_to_Default_Value", 0: "Reset to Default Value"},
            {9: "fn_Keyframe_Batch", 0: "Keyframe Batch", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Driver_Batch", 0: "Driver Batch", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Value_Batch", 0: "Value Batch"},
            {9: "fn_detail", 0: "Details"},
        ],
        fin_D1  = override["rm_end"]  if "rm_end" in override else None,
        title   = ti_tx,
        width   = F[150])
    # >>>
    #
    #

class GEOKFS(GEOKF):
    __slots__ = 'index'
    def __init__(self, w, name, attr, index, type_attr=True, is_eval=False, R_fc_path=None):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.index  = index
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, "•")

        self.U_set_last         = self.IU_set_no_kf
        self.U_set_no_kf        = N
        self.U_set_kf_fit       = self.I_set_kf_fit
        self.U_set_kf_unfit     = self.I_set_kf_unfit
        self.U_set_nokf_fit     = self.I_set_nokf_fit
        self.U_set_nokf_unfit   = self.I_set_nokf_unfit
        self.draw_ti            = self.I_draw_ti

        w.oo_kf2[attr, index] = self
        self.is_eval = is_eval
        self.is_enable = True

        if type_attr is True:       self.upd_ti = self.upd_fc
        elif type_attr is False:    self.upd_ti = self.upd_fc_bool
        else:
            self.upd_ti = self.upd_fc_enum_set if frozenset_empty in type_attr else self.upd_fc_enum
            self.enum   = type_attr

        self.R_fc_path = self.R_fc_path_default  if R_fc_path is None else R_fc_path
    def R_oo_dr(self): return self.w.oo_dr2[self.attr, self.index]
    def R_fc_path_default(self): return f'modifiers["{self.w.w.act_md.name}"]["{self.attr.identifier}"]'
    def upd_fc(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(self.R_fc_path(), index=self.index)
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if fc.evaluate(r) == act_md[self.attr.identifier][self.index]: self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if fc.evaluate(r) == act_md[self.attr.identifier][self.index]: self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def upd_fc_bool(self, an_data, act_md):
        if an_data:
            action = an_data.action
            if action:
                fc = action.fcurves.find(self.R_fc_path(), index=self.index)
                if fc != None:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    r = bpy.context.scene.frame_current
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if round(fc.evaluate(r)) == int(act_md[self.attr.identifier][self.index]):
                            self.U_set_nokf_fit()
                        else: self.U_set_nokf_unfit()
                    else:
                        if round(fc.evaluate(r)) == int(act_md[self.attr.identifier][self.index]):
                            self.U_set_kf_fit()
                        else: self.U_set_kf_unfit()
                    return
        self.U_set_no_kf()
    def I_fc_event(self, require=None):
#
        self.fc_event = N
        ww = self.w.w
        obj = ww.act_md

        path = f'["{self.attr.identifier}"]'
        self.upd_ti(ww.oj.animation_data, obj)

        if require is None:
            if self.ti.text == "◆":
                obj.keyframe_delete(path, index=self.index)
                m.undo_str = f"[Modifier Editor] keyframe_delete('{path}', index={self.index})"
            else:
                obj.keyframe_insert(path, index=self.index)
                m.undo_str = f"[Modifier Editor] keyframe_insert('{path}', index={self.index})"
        elif require == "INSERT":
            obj.keyframe_insert(path, index=self.index)
            m.undo_str = f"[Modifier Editor] keyframe_insert('{path}', index={self.index})"
        else:
            obj.keyframe_delete(path, index=self.index)
            m.undo_str = f"[Modifier Editor] keyframe_delete('{path}', index={self.index})"

        P.refresh = True
        m.refresh()
        self.get_color_fo()
        m.redraw()
        m.undo_push()
        m.head_modal.append(self.modal_wait_release)
    #
    #
class GEODRS(GEODR):
    __slots__ = ()
    def __init__(self, w, name, ti, attr,
            array_index     = 0,
            is_ref_driver   = False,
            is_eval = False,
        ):
        self.w      = w
        self.name   = name
        self.attr   = attr
        self.rim    = RECT()
        self.ti     = BLF(P.color_font, ti)

        self.U_set_ti_dr    = self.I_set_ti_dr
        self.U_set_ti_nodr  = N
        self.draw_ti        = self.I_draw_ti
        self.array_index    = array_index
        self.is_ref_driver  = is_ref_driver

        w.oo_dr2[attr, array_index] = self
        self.is_eval = is_eval
        self.is_enable = True

    def R_oo_kf(self): return self.w.oo_kf2[self.attr, self.array_index]

    def driver_add(self, exp = "var"):
        try:
            fc = self.w.w.act_md.driver_add(f'["{self.attr.identifier}"]', self.array_index)
            fc.driver.expression = "var"
            return fc
        except:
            return None
    def driver_remove(self):
#
        return self.w.w.act_md.driver_remove(f'["{self.attr.identifier}"]', self.array_index)

    def upd_dr(self, an_data):
        if an_data:
            drivers = an_data.drivers
            if drivers:
                if self.is_ref_driver:
                    return

                if drivers.find(f'modifiers["{self.w.w.act_md.name}"]["{self.attr.identifier}"]', index=self.array_index) != None:
                    self.U_set_ti_dr()
                    return
        self.U_set_ti_nodr()

    def has_driver(self):
        an_data = self.w.w.oj.animation_data
        if an_data:
            drivers = an_data.drivers
            if drivers:
                if drivers.find(f'modifiers["{self.w.w.act_md.name}"]["{self.attr.identifier}"]', index=self.array_index) != None:
                    return True
        return False

    def fn_Clear_Keyframe(self):
        w       = self.w.w
        oj      = w.oj
        try:    fcurves = oj.animation_data.action.fcurves
        except: return
        path = f'modifiers["{w.act_md.name}"]["{self.attr.identifier}"]'
        fc0 = fcurves.find(path, index=0)
        fc1 = fcurves.find(path, index=1)
        fc2 = fcurves.find(path, index=2)
        if fc0 == None and fc1 == None and fc2 == None: return
        if fc0 != None: fcurves.remove(fc0)
        if fc1 != None: fcurves.remove(fc1)
        if fc2 != None: fcurves.remove(fc2)
        P.refresh = True
        m.refresh()
        m.redraw()
        m.undo_str = f"[Modifier Editor] Clear Keyframe {path}"
        m.undo_push()
    def fn_Add_to_Keying_Set(self):
        try:
#
            if self.is_ref_driver: return
            w = self.w.w
            keying_sets = bpy.context.scene.keying_sets
            act_ks = keying_sets.active
            if act_ks is None:
                act_ks = keying_sets.new(idname='Button Keying Set', name='Button Keying Set')
                act_ks.use_insertkey_xyz_to_rgb = True
                act_ks.use_insertkey_override_xyz_to_rgb = True

            kspath = act_ks.paths.add(w.oj, f'modifiers["{w.act_md.name}"]["{self.attr.identifier}"]', index=self.array_index)
            keying_sets.active = keying_sets.active
            m.undo_str = "[Modifier Editor] Add to Keying Set"
            m.undo_push()
            m.admin.report({'INFO'}, f"Property added to Keying Set: '{act_ks.bl_idname}'")
        except: pass
    def fn_Remove_from_Keying_Set(self):
        try:
#
            if self.is_ref_driver: return
            w = self.w.w
            keying_sets = bpy.context.scene.keying_sets
            act_ks = keying_sets.active
            if act_ks is None:  return

            w_oj = w.oj
            dp = f'modifiers["{w.act_md.name}"]["{self.attr.identifier}"]'
            paths = act_ks.paths
            i = self.array_index
            for p in paths:
                if p.id != w_oj:        continue
                if p.data_path != dp:   continue
                if p.array_index != i:  continue

                paths.remove(p)
                keying_sets.active = keying_sets.active
                m.undo_str = "[Modifier Editor] Remove from Keying Set"
                m.undo_push()
                m.admin.report({'INFO'}, f"Property removed from Keying Set: '{act_ks.bl_idname}'")
        except: pass
    def fn_Reset_to_Default_Value(self):
        try:
#
            i = self.array_index
            v = self.attr.default_value[i]
            self.w.w.act_md[self.attr.identifier][i] = v
            m.undo_str = f'[Modifier Editor] md["{self.attr.identifier}"][{i}] ▶ {v}'
            m.undo_push()
            m.power_upd()
        except:
            pass
    def fn_Value_Batch(self):
        m.admin.report({'INFO'}, "Coming Soon")
    def fn_detail(self):
        try:
            rna = self.attr
        except: return

        # <<< 1copy (0ui_fn_detail,, ${'self.rna':'rna'}$)
        if not hasattr(rna, "description"): return
        name = rna.name
        if not name: name = " "
        description = rna.description
        if not isinstance(description, str):    description = description()
        if not description: description = "No description."
        details = INFO(name, description)
        evt = m.EVT.evt
        blf_size(font_0, F[9])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, F[480])
        e = BLF(text=details.body)
        hi = round(e.R_dimen_y()) + F[-1] + F[46]
        e.text = details.title
        hi += round(e.R_dimen_y())
        wi = F[480]
        blf_disable(font_0, WORD_WRAP)
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), details)
        # >>>

    # <<< 1copy (0BUDR2_rm_init,, ${
    #     'if self.attr in self.w.oo_kf2': 'if (self.attr, self.array_index) in self.w.oo_kf2',
    #     '0: "Paste Full Path to Driver"': '0: "Paste Full Path to Driver", 1: 0 if self.is_ref_driver else 1',
    #     '0: "Add to Keying Set"': '0: "Add to Keying Set", 1: 0 if self.is_ref_driver else 1',
    #     '0: "Remove from Keying Set"': '0: "Remove from Keying Set", 1: 0 if self.is_ref_driver else 1',
    #     '0: "Keyframe Batch"': '0: "Keyframe Batch", 1: 0 if self.is_ref_driver else 1',
    #     '0: "Driver Batch"': '0: "Driver Batch", 1: 0 if self.is_ref_driver else 1',
    # }$)
    def rm_init(self, evt, override=None):
        if self.attr is None:   return
#
        self.enforce_outside()
        bu_kf       = self.R_oo_kf()  if (self.attr, self.array_index) in self.w.oo_kf2 else None

        if self.is_ref_driver:
            md_type = self.w.w.act_md.type
            attrs = getattr(MOD_REF_ATTR, md_type, None)
            if attrs is not None:
                if self.attr in attrs:
                    o = self.w.w.oj
                    try:
                        path = f'modifiers[{self.w.w.act_md.name}].{self.attr}'
                        dr = o.animation_data.drivers.find(f'["{path}"]')
                    except:
                        dr = None

                    if dr is None:
                        line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 0}
                    else:
                        line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                        line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver", 1: 1}
                else:
                    attrs = None

            if attrs is None:
                line3 = {9: "fn_Add_Reference_Driver", 0: "Add Reference Driver ", 1: 0}
                line4 = {9: "fn_Delete_Reference_Driver", 0: "Delete Reference Driver ", 1: 0}
            line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe ", 1: 0}
            line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe ", 1: 0}
            line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe ", 1: 0}
        else:
            if bu_kf.ti.text == "◆":
                line0 = {9: "fn_Replace_Keyframe", 0: "Replace Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 1}
            else:
                line0 = {9: "fn_Insert_Keyframe", 0: "Insert Keyframe"}
                line1 = {9: "fn_Delete_Keyframe", 0: "Delete Keyframe", 1: 0}

            if bu_kf.ti.text == "•":
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 0}
            else:
                line2 = {9: "fn_Clear_Keyframe", 0: "Clear Keyframe", 1: 1}

            if self.U_set_ti_dr == self.I_set_ti_dr:
                line3 = {9: "fn_Add_Driver", 0: "Add Driver"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 0}
            else:
                line3 = {9: "fn_Open_Driver_Editor", 0: "Open Driver Editor"}
                line4 = {9: "fn_Delete_Driver", 0: "Delete Driver", 1: 1}

        if override is None:    override = {}
        if "title" in override:
            ti_tx = override["title"]
        else:
            ti_tx       = self.ti.text
            if ti_tx[-2:] == " :":  ti_tx = ti_tx[:-2]

        m.tm["bu_kf"] = bu_kf

        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y,
        override["li"]  if "li" in override else [
            line0,
            line1,
            line2,
            line3,
            line4,
            {9: "fn_Copy_Data_Path", 0: "Copy Data Path"},
            {9: "fn_Copy_Full_Path", 0: "Copy Full Path"},
            {9: "fn_Paste_Full_Path_to_Driver", 0: "Paste Full Path to Driver", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Add_to_Keying_Set", 0: "Add to Keying Set", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Remove_from_Keying_Set", 0: "Remove from Keying Set", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Reset_to_Default_Value", 0: "Reset to Default Value"},
            {9: "fn_Keyframe_Batch", 0: "Keyframe Batch", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Driver_Batch", 0: "Driver Batch", 1: 0 if self.is_ref_driver else 1},
            {9: "fn_Value_Batch", 0: "Value Batch"},
            {9: "fn_detail", 0: "Details"},
        ],
        fin_D1  = override["rm_end"]  if "rm_end" in override else None,
        title   = ti_tx,
        width   = F[150])
    # >>>
    #
    #

class GEORGBA(GEOFL):
    __slots__ = 'bo', 'color_space'
    def __init__(self, w, name, attr):
        self.w      = w
        self.name   = name
        self.attr   = attr

        self.bpy_setter     = self.I_bpy_setter

        self.rim        = BOX(P.color_bu_3_off)
        self.on         = self.I_on
        self.off        = N
        self.fo         = self.I_fo
        self.enable     = N
        self.disable    = self.I_disable
        self.inside     = self.I_inside
        self.is_enable  = True

        color_space = bpy.context.scene.display_settings.display_device
        if color_space == "None":
            todo
        elif color_space == "XYZ":
            todo
        else:
            self.bo = [
                BOX(color_black),
                BOX(color_white),
                BOX(),
                BOX(),
            ]

    def draw_rim(self): pass
    def draw_bg(self):
        self.rim.bind_draw()
        bo = self.bo
        bo[0].bind_draw()
        bo[1].bind_draw()
        e = bo[-1]
        c3 = e.color
        e.bind_color((c3[0], c3[1], c3[2], 1.0))
        bo[2].draw()
        e.bind_draw()
    def draw_ti(self):  pass

    def LRBT(self, L, R, B, T):
        rim = self.rim
        rim.LRBT_upd(L, R, B, T)
        bo = self.bo
        hi = T - B
        _1 = F[1]
        R1 = R - _1
        L1 = R1 - hi
        T -= _1
        B += _1
        bo[1].LRBT_upd(L1, R1, B, T)
        R0 = R1 - hi
        L0 = L1 - hi
        bo[0].LRBT_upd(L0, R0, B, T)
        bo[2].LRBT_upd(L + _1, L0, B, T)
        bo[3].LRBT_upd(L0, R1, B, T)

    def dxy_upd(self, x, y):
        self.rim.dxy_upd(x, y)
        for e in self.bo:   e.dxy_upd(x, y)

    def setter(self): pass