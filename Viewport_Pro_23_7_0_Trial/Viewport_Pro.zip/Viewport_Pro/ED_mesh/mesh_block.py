import bpy
from mathutils import Vector
from mathutils.geometry import intersect_line_plane, area_tri
from math import sqrt, degrees, radians, tau, pi
from blf import color as blf_color
from numpy.linalg import matrix_rank
from copy import copy

from .. import m
from .. m import R_quick_edit_state

from .. fn import (
    math_split,
    bin_search_continue,
    R_nor_to_glo,
    R_face_normal,
    R_nor_to_local,
    R_bm_nor,
    R_face_area,
    R_median,
    R_normal_center,
    R_angle,
    R_str_by_deg,
    R_u_pos_by_angle,
    R_3vert_of_2edges,
)
from .. calc import calc_vec_3
from .. bu import VBOX, VBOX_SUB, VBOX_SET, TXBOX, BBOX, BURE2
from .. det import INFO
from .. props import RNA_FLOAT, RNA_FLOAT_ARRAY, RNA_BOOL, RNA_STR
from .. bu_block import BLOCK, BLOCK2, BLOCK3, BLOCK_INT_BOOL, BLOCK_STR, BLOCK_STR_BOOL
from .. ui import QE, FLOAT, FLOAT_RAD, FLOAT_DEG, FLOAT_ARRAY_SUBTI, BOOLEAN, BUTTON, VEC3, tuple_XYZ

P = None
F = None
K = None
BOX = None
BLF = None
font_0 = None

bm_data = None

## 0mesh_block_upd_all_bm ##    for o_ in bm_data["bms"]:   o_.data.update()

class B_DIS(BLOCK_INT_BOOL):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "dis": 0.0,
        }
        self.props = props
        self.oo = [
            FLOAT(self, rna_distance, lambda: props["dis"], self.fn_set_dis),
            BOOLEAN(self, rna_invert, lambda: self.w.w.props["mesh_ed_dis_invert"], self.fn_set_invert)
        ]
        self.oo[1].is_title_left = True

    def fn_set_dis(self, v, undo_push=True):
        if "u_vec" in bm_data:
            wprops = self.w.w.props
            d_vec = bm_data["u_vec"  if wprops["mesh_ed_local"] else "u_vec_glo"] * v
            # /* 0mesh_block_fn_set_dis
            vert0 = bm_data["vert0"]
            vert1 = bm_data["vert1"]
            if wprops["mesh_ed_dis_invert"]:
                vert0, vert1 = vert1, vert0
            if wprops["mesh_ed_local"]:
                vert0.co[:] = vert1.co + d_vec
            else:
                bm_dic = bm_data["bm_dic"]
                new_loc = bm_dic[vert1].matrix_world @ vert1.co + d_vec
                vert0.co[:] = bm_dic[vert0].matrix_world.inverted_safe() @ new_loc
            # <<< 1copy (0mesh_block_upd_all_bm,, $$)
            for o_ in bm_data["bms"]:   o_.data.update()
            # >>>

            if undo_push:
                m.undo_str = f'[Mesh Editor] props["dis"] = {v}'
                m.undo_push()
            # */
    def fn_set_invert(self, v, undo_push=True):
        self.w.w.props["mesh_ed_dis_invert"] = v
    #
    #
class B_DIR(BLOCK):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "direction": [0.0, 0.0, 0.0],
        }
        self.props = props
        self.oo = [
            FLOAT_ARRAY_SUBTI(self, rna_direction, self.fn_get_direction, self.fn_set_direction),
        ]
        self.oo[0].init(tuple_XYZ)

    def fn_get_direction(self, ind=None):
        # <<< 1copy (ui_array_get,, ${'_prop':'direction'}$)
        if ind is None: return self.props["direction"]
        if isinstance(ind, int): return self.props["direction"][ind]
        return self.props["direction"][ind[0] : ind[1]]
        # >>>
    def fn_set_direction(self, v, undo_push=True, ind=None):
        if "vec" not in bm_data: return
        wprops = self.w.w.props
        d_vec = bm_data["vec"  if wprops["mesh_ed_local"] else "vec_glo"]

        # <<< 1copy (ui_array_set,, ${
        #     '_len': '3',
        #     '_prop': 'direction',
        #     '_editor': 'Mesh Editor',
        #     '#int': 'd_vec[ind] = v',
        #     '#array': 'd_vec[i0 : i1] = v',
        #     'm.undo_push()': '',
        # }$)
        if ind is None: ind = (0, 3)
        if isinstance(ind, int):
            self.props["direction"][ind] = v
            d_vec[ind] = v
            if undo_push is True:
                m.undo_str = f'[Mesh Editor] props["direction"][{ind}] = {v}'
                
        else:
            i0 = ind[0]
            i1 = ind[1]
            self.props["direction"][i0 : i1] = v
            d_vec[i0 : i1] = v
            if undo_push is True:
                m.undo_str = f'[Mesh Editor] props["direction"][{ind}][{i0}:{i1}] = {v}'
                
        # >>>

        # <<< 1copy (0mesh_block_fn_set_dis,, ${'m.undo_str = f'+"'"+'[Mesh Editor] props["dis"] = {v}'+"'":''}$)
        vert0 = bm_data["vert0"]
        vert1 = bm_data["vert1"]
        if wprops["mesh_ed_dis_invert"]:
            vert0, vert1 = vert1, vert0
        if wprops["mesh_ed_local"]:
            vert0.co[:] = vert1.co + d_vec
        else:
            bm_dic = bm_data["bm_dic"]
            new_loc = bm_dic[vert1].matrix_world @ vert1.co + d_vec
            vert0.co[:] = bm_dic[vert0].matrix_world.inverted_safe() @ new_loc
        # <<< 1copy (0mesh_block_upd_all_bm,, $$)
        for o_ in bm_data["bms"]:   o_.data.update()
        # >>>
        if undo_push:
            
            m.undo_push()
        # >>>
    #
    #
class B_VEC(BLOCK_STR):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "vec": [0.0, 0.0, 0.0],
        }
        self.props = props
        self.oo = [
            VEC3(self, rna_vec, lambda: props["vec"], self.fn_set_vec),
        ]

    def fn_set_vec(self, v, undo_push=True):
        if "u_vec" in bm_data and hasattr(v, "__len__") and len(v) == 3:
            vec3 = Vector(v).normalized()
            wprops = self.w.w.props
            d_vec = vec3 * bm_data["vec"  if wprops["mesh_ed_local"] else "vec_glo"].length
            # <<< 1copy (0mesh_block_fn_set_dis,, ${'["dis"] = {v}':'["vec"] = {vec3.to_tuple(6)}'}$)
            vert0 = bm_data["vert0"]
            vert1 = bm_data["vert1"]
            if wprops["mesh_ed_dis_invert"]:
                vert0, vert1 = vert1, vert0
            if wprops["mesh_ed_local"]:
                vert0.co[:] = vert1.co + d_vec
            else:
                bm_dic = bm_data["bm_dic"]
                new_loc = bm_dic[vert1].matrix_world @ vert1.co + d_vec
                vert0.co[:] = bm_dic[vert0].matrix_world.inverted_safe() @ new_loc
            # <<< 1copy (0mesh_block_upd_all_bm,, $$)
            for o_ in bm_data["bms"]:   o_.data.update()
            # >>>

            if undo_push:
                m.undo_str = f'[Mesh Editor] props["vec"] = {vec3.to_tuple(6)}'
                m.undo_push()
            # >>>
    #
    #

class B_DIR3(BLOCK_STR_BOOL):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "nor": [0.0, 0.0, 0.0],
        }
        self.props = props
        self.oo = [
            VEC3(self, rna_nor3, lambda: props["nor"], self.fn_set_nor3),
            BOOLEAN(self, rna_lock_act, lambda: self.w.w.props["mesh_ed_face_nor_keep_act"], self.fn_set_lock_act)
        ]
        self.oo[1].is_title_left = True

    def fn_set_nor3(self, v, undo_push=True):
        if "nor3" in bm_data and hasattr(v, "__len__") and len(v) == 3:
            nor3 = Vector(v).normalized()

            wprops = self.w.w.props
            m_co = R_if_keep_act_co(wprops["mesh_ed_face_nor_keep_act"], wprops["mesh_ed_local"])

            if wprops["mesh_ed_local"] is True:
                if m_co is None:    m_co = R_median(bm_data["vert3_co"])
                rot = bm_data["nor3"].rotation_difference(nor3)
                for v in bm_data["verts"]:
                    v.co[:] = m_co + (rot @ (v.co - m_co))
            else:
                if m_co is None:    m_co = R_median(bm_data["vert3_co_world"])
                rot = bm_data["nor3_glo"].rotation_difference(nor3)
                bm_dic = bm_data["bm_dic"]
                for v in bm_data["verts"]:
                    mat = bm_dic[v].matrix_world
                    v.co[:] = mat.inverted_safe() @ (m_co + (rot @ (mat @ v.co - m_co)))

            # <<< 1copy (0mesh_block_upd_all_bm,, $$)
            for o_ in bm_data["bms"]:   o_.data.update()
            # >>>
            if undo_push:
                m.undo_str = f'[Mesh Editor] props["nor"] = {nor3.to_tuple(6)}'
                m.undo_push()

    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_lock_act', 'prop_name':'mesh_ed_face_nor_keep_act'}$)
    def fn_set_lock_act(self, v, undo_push=True):
        self.w.w.props["mesh_ed_face_nor_keep_act"] = v
    # >>>
    #
    #
class B_COLL(BLOCK):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        e = BUTTON(self, rna_collinear)
        self.oo = [e]
        e.fx = self.fn_collinear
        e.ti.text = "Collinear Threshold"

    def get_bo(self, L0, R0, T0):
        R = R0 - F[3]
        T = T0 - F[3]
        B = self.oo[0].get_bo(R - F[82], R, T - F[16], T) - F[3]
        R -= F[101] * 2 + F[2]
        self.oo[0].ti.align_R(R - F[10])
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def fn_collinear(self):
        try:
            if "nor3" in bm_data:
                wprops = self.w.w.props
                ll_edges = bm_data["total_edge_sel"]
                bm_dic = bm_data["bm_dic"]
                bms = bm_data["bms"]
                verts = []
                edges = []

                for b in bms.values():
                    verts += b.verts_sel
                    edges += b.edges_sel

                if ll_edges == 1:
                    e0 = edges[0]
                    e0_v0, e0_v1 = e0.verts

                    for single_v in verts:
                        if single_v not in {e0_v0, e0_v1}: break

                    mat = bm_dic[e0].matrix_world
                    v0_glo = mat @ e0_v0.co
                    v1_glo = mat @ e0_v1.co
                elif ll_edges == 2:
                    e0, e1 = edges
                    e0_v0, e0_v1 = e0.verts
                    e1_v0, e1_v1 = e1.verts
                    if e0_v0 in e1.verts:
                        single_v = e0_v0
                        v0_glo = bm_dic[e0].matrix_world @ e0_v1.co
                    else:
                        single_v = e0_v1
                        v0_glo = bm_dic[e0].matrix_world @ e0_v0.co

                    v1_glo = bm_dic[e1].matrix_world @ (e1_v0.co if e1_v1 == single_v else e1_v1.co)
                else:
                    last_v = R_last_vert()
                    if last_v == None:
                        single_v = verts[-1]
                        v0_glo = bm_dic[verts[0]].matrix_world @ verts[0].co
                        v1_glo = bm_dic[verts[1]].matrix_world @ verts[1].co
                    else:
                        vs = []
                        for v in verts:
                            if v == last_v: single_v = v
                            else:
                                vs.append(v)

                        v0_glo = bm_dic[vs[0]].matrix_world @ vs[0].co
                        v1_glo = bm_dic[vs[1]].matrix_world @ vs[1].co

                act = R_act_vert(wprops["mesh_ed_face_nor_keep_act"])
                org_pos = None
                if act != None and act == single_v:     org_pos = act.co.copy()

                single_v_mat = bm_dic[single_v].matrix_world
                sv = single_v_mat @ single_v.co
                nor = R_face_normal((sv, v0_glo, v1_glo)).normalized()
                if nor.length == 0.0:
                    m.admin.report({'INFO'}, "Abort, Normal is 0.0")
                    return
                vec_h = (v1_glo - v0_glo).cross(nor)
                pos = intersect_line_plane(sv, sv + vec_h, v0_glo, vec_h)
                if pos == None:
                    m.admin.report({'INFO'}, "Abort, no intersection found")
                    return
                single_v.co[:] = single_v_mat.inverted_safe() @ pos

                if org_pos is not None:
                    offset = org_pos - act.co
                    for v in verts: v.co += offset

                # <<< 1copy (0mesh_block_upd_all_bm,, $$)
                for o_ in bm_data["bms"]:   o_.data.update()
                # >>>
                m.undo_str = '[Mesh Editor] Make Collinear'
                m.undo_push()
        except:
            m.admin.report({'ERROR'}, "Error 0. Please report to the author")
    #
    #
class B_ANGLE(BLOCK2):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "rad": 0.0,
            "deg": 0.0,
        }
        self.props = props
        self.oo = [
            FLOAT_RAD(self, rna_incl_rad, lambda: props["rad"], self.fn_set_rad),
            FLOAT_DEG(self, rna_incl_deg, lambda: props["deg"], self.fn_set_deg)
        ]

    def fn_set_rad(self, v, undo_push=True):
        if "total_vert_sel" in bm_data and bm_data["total_vert_sel"] == 3:
            is_local = self.w.w.props["mesh_ed_local"]
            if QE.state == 1:
                tm = QE.data
                # <<< 1flip (0mesh_block_fn_set_rad_tm,, $' = '$)
                u_nor = tm["u_nor"]
                u_pos = tm["u_pos"]
                org_co_glo = tm["org_co_glo"]
                verts = tm["verts"]
                length = tm["length"]
                org_pos = tm["org_pos"]
                mat_inv = tm["mat_inv"]
                is_keep_act = tm["is_keep_act"]
                # >>>
            elif QE.state == -2:
                tm = QE.data
                v0, v1, v2 = tm["verts"]
                o0, o1, o2 = tm["org_pos"]
                v0.co[:] = o0
                v1.co[:] = o1
                v2.co[:] = o2
                # <<< 1copy (0mesh_block_upd_all_bm,, $$)
                for o_ in bm_data["bms"]:   o_.data.update()
                # >>>
                return
            else:
                if bm_data["total_edge_sel"] == 2:
                    verts, org_co_glo, mat_inv = R_v012_2_edges(*bm_data["edges"], bm_data["bm_dic"], is_local)
                else:
                    verts, org_co_glo, mat_inv = R_v012_3_verts(bm_data["verts"], bm_data["bm_dic"], is_local)

                org_pos = (verts[0].co.copy(), verts[1].co.copy(), verts[2].co.copy())
                u_nor = R_face_normal(org_co_glo).normalized()
                u_pos = (org_co_glo[0] - org_co_glo[1]).normalized()
                length = (org_co_glo[1] - org_co_glo[2]).length
                is_keep_act = self.w.w.props["mesh_ed_face_nor_keep_act"]

                if u_nor == Vector():   u_nor = Vector((0.0, 0.0, 1.0))
                if QE.state == 0:
                    QE.state = 1
                    tm = QE.data
                    # /* 0mesh_block_fn_set_rad_tm
                    tm["u_nor"] = u_nor
                    tm["u_pos"] = u_pos
                    tm["org_co_glo"] = org_co_glo
                    tm["verts"] = verts
                    tm["length"] = length
                    tm["org_pos"] = org_pos
                    tm["mat_inv"] = mat_inv
                    tm["is_keep_act"] = is_keep_act
                    # */

            u_vec0, u_vec1 = R_u_pos_by_angle(u_pos, u_nor, v)
            pos0 = length * u_vec0 + org_co_glo[1]
            pos1 = length * u_vec1 + org_co_glo[1]
            an_0 = R_angle(org_co_glo[2], org_co_glo[1], pos0)
            an_1 = R_angle(org_co_glo[2], org_co_glo[1], pos1)

            if v % tau < pi:   new_pos = pos0 if an_0 < an_1 else pos1
            else:              new_pos = pos1 if an_0 < an_1 else pos0

            v2 = verts[2]
            if is_local == False:   new_pos = mat_inv @ new_pos
            act_v = R_act_vert(is_keep_act)
            if act_v == v2:
                offset = org_pos[2] - new_pos
                new_pos += offset
                verts[0].co[:] = org_pos[0] + offset
                verts[1].co[:] = org_pos[1] + offset
            else:
                v2.co[:] = new_pos

            # <<< 1copy (0mesh_block_upd_all_bm,, $$)
            for o_ in bm_data["bms"]:   o_.data.update()
            # >>>
            if undo_push:
                m.undo_str = f'[Mesh Editor] Included Angle = {v}'
                m.undo_push()

    def fn_set_deg(self, v, undo_push=True):
        self.fn_set_rad(radians(v), undo_push=undo_push)
    #
    #

class B_NOR(BLOCK3):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "nor": [0.0, 0.0, 0.0],
        }
        self.props = props
        wprops = self.w.w.props
        self.oo = [
            VEC3(self, rna_nor, lambda: props["nor"], self.fn_set_nor),
            BOOLEAN(self, rna_keep_nor, lambda: wprops["mesh_ed_face_nor_keep_nor"], self.fn_set_keep_nor),
            BOOLEAN(self, rna_lock_act, lambda: wprops["mesh_ed_face_nor_keep_act"], self.fn_set_lock_act)
        ]
        self.oo[1].is_title_left = True
        self.oo[2].is_title_left = True

    def get_bo(self, L0, R0, T0):
        _16 = F[16]
        R = R0 - F[3]
        L = R - _16
        T = T0 - F[3]
        T = self.oo[0].get_bo(R - F[101] - F[101] - F[2], R, T - _16, T) - F[4]
        T = self.oo[1].get_bo(L, R, T - _16, T) - F[4]
        B = self.oo[2].get_bo(L, R, T - _16, T) - F[3]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def fn_set_nor(self, v, undo_push=True):
        if "faces" in bm_data and bm_data["total_face_sel"] == 1 and hasattr(v, "__len__") and len(v) == 3: pass
        else: return False
        try:
            props = self.w.w.props
            plane = bm_data["faces"][0]
            oj = bm_data["oj"]
            is_act = False
            if props["mesh_ed_face_nor_keep_act"]:
                try:    act_vert = bm_data["bms"][oj].bm.select_history.active
                except: act_vert = None
                if act_vert in plane.verts: is_act = True

            plane_co = act_vert.co.copy() if is_act else plane.calc_center_median()
            inp = Vector(v).normalized() if props["mesh_ed_local"] else R_nor_to_local(Vector(v), oj).normalized()

            if props["mesh_ed_face_nor_keep_nor"]:
                plane_edges = plane.edges

                lines = {}
                for vert in plane.verts:
                    ll_faces = len(vert.link_faces)
                    if ll_faces > 3:
                        if undo_push:
                            m.admin.report({'INFO'}, "Some vertices in selected face have more than 3 linked faces, abort.")
                        return False

                    if ll_faces == 1:   continue
                    elif ll_faces == 2:
                        faces = vert.link_faces
                        face = faces[1 if faces[0] == plane else 0]
                        plane_edges = plane.edges
                        share_edge = set(plane_edges).intersection(face.edges)
                        if len(share_edge) != 1:
                            if undo_push:
                                m.admin.report({'INFO'}, "2 of the linked faces of the vertices in the selected face have no or more than one shared edge, abort.")
                            return False

                        share_edge, = share_edge
                        v0, v1 = share_edge.verts

                        for edge in face.edges:
                            if edge == share_edge: continue
                            if v0 in edge.verts:
                                lines[v0] = edge
                            elif v1 in edge.verts:
                                lines[v1] = edge

                    elif ll_faces == 3:
                        faces = vert.link_faces
                        if faces[0] == plane:
                            face1 = faces[1]
                            face2 = faces[2]
                        elif faces[1] == plane:
                            face1 = faces[0]
                            face2 = faces[2]
                        else:
                            face1 = faces[0]
                            face2 = faces[1]

                        check_connect_plane = False
                        check_connect_other = False

                        for e in face1.edges:
                            if plane in e.link_faces:
                                check_connect_plane = True
                            elif face2 in e.link_faces:
                                check_connect_other = True
                                line = e

                        if check_connect_plane is False or check_connect_other is False:
                            if undo_push:
                                m.admin.report({'INFO'}, "The 3 linked faces of a vertice in the selected face are not connected, abort.")
                            return False

                        lines[vert] = line

                new_pos = {}
                if lines:
                    for edge in lines.values():
                        if edge.verts[0] in plane.verts:
                            v0 = edge.verts[1]
                            v1 = edge.verts[0]
                        else:
                            v0 = edge.verts[0]
                            v1 = edge.verts[1]

                        fake_dir = (v0.co - v1.co).normalized()
                        break

                    for vert in plane.verts:
                        if vert in lines:
                            edge_verts = lines[vert].verts
                            v0 = edge_verts[0 if edge_verts[1] == vert else 1]
                            pos = intersect_line_plane(v0.co, vert.co, plane_co, inp)
                            if pos is None:
                                if undo_push:
                                    m.admin.report({'INFO'}, "The linked face of the selected face has the same normal as the selected face, abort.")
                                return False
                            new_pos[vert] = pos
                        else:
                            pos = intersect_line_plane(vert.co + fake_dir, vert.co, plane_co, inp)
                            if pos is None:
                                if undo_push:
                                    m.admin.report({'INFO'}, "The linked face of the selected face has the same normal as the selected face, abort.")
                                return False
                            new_pos[vert] = pos
                else:
                    old_vec = R_bm_nor(plane).normalized()

                    for vert in plane.verts:
                        pos = intersect_line_plane(vert.co + old_vec, vert.co, plane_co, inp)
                        if pos is None:
                            if undo_push:
                                m.admin.report({'INFO'}, "The linked face of the selected face has the same normal as the selected face, abort.")
                            return False
                        new_pos[vert] = pos

                for vert, pos in new_pos.items():
                    vert.co[:] = pos
            else:
                new_pos = {}
                old_vec = R_bm_nor(plane).normalized()

                for vert in plane.verts:
                    pos = intersect_line_plane(vert.co + old_vec, vert.co, plane_co, inp)
                    if pos is None:
                        if undo_push:
                            m.admin.report({'INFO'}, "The linked face of the selected face has the same normal as the selected face, abort.")
                        return False
                    new_pos[vert] = pos

                for vert, pos in new_pos.items():
                    vert.co[:] = pos


            new_nor = R_bm_nor(plane).normalized()
            if (inp[0] > 0.0 and new_nor[0] < 0.0) or (inp[0] < 0.0 and new_nor[0] > 0.0):  plane.normal_flip()
            # <<< 1copy (0mesh_block_upd_all_bm,, $$)
            for o_ in bm_data["bms"]:   o_.data.update()
            # >>>
            if undo_push:
                undo_str = f'[Mesh Editor] Face Normal = {inp}'
                m.undo_str = undo_str[: -2].replace("<Vector (", "")
                m.undo_push()
            return True
        except:
            m.admin.report({'ERROR'}, "Error 1. Please report to the author")
            return False

    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_keep_nor', 'prop_name':'mesh_ed_face_nor_keep_nor'}$)
    def fn_set_keep_nor(self, v, undo_push=True):
        self.w.w.props["mesh_ed_face_nor_keep_nor"] = v
    # >>>
    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_lock_act', 'prop_name':'mesh_ed_face_nor_keep_act'}$)
    def fn_set_lock_act(self, v, undo_push=True):
        self.w.w.props["mesh_ed_face_nor_keep_act"] = v
    # >>>
    #
    #
class B_COP(BLOCK2):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        e = BUTTON(self, rna_coplanar)
        self.oo = [e, BOOLEAN(self, rna_cop_vert, lambda: self.w.w.props["mesh_ed_cop_vert"], self.fn_set_cop_vert)]
        e.fx = self.fn_coplanar
        e.ti.text = "Coplanar Threshold"
        self.oo[1].is_title_left = True

    def get_bo(self, L0, R0, T0):
        R = R0 - F[3]
        T = T0 - F[3]
        T = self.oo[0].get_bo(R - F[82], R, T - F[16], T) - F[4]
        self.oo[0].ti.align_R(R - F[101] * 2 - F[2] - F[10])
        B = self.oo[1].get_bo(R - F[16], R, T - F[16], T) - F[3]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def fn_coplanar(self):
        if "faces" not in bm_data: return
        try:
            wprops = self.w.w.props
            a = self.w.oo[0]
            success = False
            if wprops["mesh_ed_cop_vert"] and bm_data["total_vert_sel"] != sum(len(face.verts)  for face in bm_data["faces"]): pass
            elif hasattr(a, "props") and "nor" in a.props:
                success = a.fn_set_nor(a.props["nor"], undo_push=False)
            if success == False:
                bm_dic = bm_data["bm_dic"]
                if wprops["mesh_ed_cop_vert"]:
                    verts_co = [bm_dic[v].matrix_world @ v.co  for v in bm_data["verts"]]
                else:
                    verts_co = []
                    for face in bm_data["faces"]:
                        verts_co += [bm_dic[v].matrix_world @ v.co  for v in face.verts]

                if len(verts_co) < 4: return
                nor, center = R_normal_center(bm_data["bms"][bm_data["oj"]].bm, verts_co)
                if nor == None or nor.length == 0:
                    m.admin.report({'INFO'}, "Can't find the normal, abort.")
                    m.undo_str = '[Mesh Editor] Make Coplanar'
                    m.undo_push()
                    return

                oj = bpy.context.object
                if oj and oj.mode == "EDIT" and oj.type == "MESH":
                    from . mesh_ed import get_bm_data, get_bm_face
                    get_bm_data()
                    get_bm_face()
                else:
                    return

                if wprops["mesh_ed_cop_vert"]:
                    verts = bm_data["verts"]
                else:
                    verts = []
                    for face in bm_data["faces"]:
                        verts += face.verts

                bm_dic = bm_data["bm_dic"]
                for v in verts:
                    mat = bm_dic[v].matrix_world
                    vert_co = mat @ v.co
                    pos = intersect_line_plane(vert_co + nor, vert_co, center, nor)
                    if pos == None: continue
                    v.co[:] = mat.inverted_safe() @ pos

                # <<< 1copy (0mesh_block_upd_all_bm,, $$)
                for o_ in bm_data["bms"]:   o_.data.update()
                # >>>

            m.undo_str = '[Mesh Editor] Make Coplanar'
            m.undo_push()
        except:
            m.admin.report({'ERROR'}, "Error 2. Please report to the author")

    # <<< || 1copy (ui_set_bool,, ${'fn_name':'fn_set_cop_vert', 'prop_name':'mesh_ed_cop_vert'}$)
    def fn_set_cop_vert(self, v, undo_push=True):
        self.w.w.props["mesh_ed_cop_vert"] = v
    # >>>
    #
    #
class B_AREA(BLOCK):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "area": 0.0,
        }
        self.props = props
        self.oo = [
            FLOAT(self, rna_area, lambda: props["area"], self.fn_set_area),
        ]

    # //* 0mesh_block_fn_set_area_tm
    # *//
    def fn_set_area(self, v, undo_push=True):
        # /* 0mesh_block_fn_set_area
        if "faces" not in bm_data: return
        wprops = self.w.w.props
        v = max(0.0, v)
        if QE.state == 1:
            tm = QE.data
            # <<< 1flip (0mesh_block_fn_set_area_tm,, $' = '$)
            QE.data = tm
            old_v = tm["old_v"]
            pos_org = tm["pos_org"]
            verts = tm["verts"]
            center = tm["center"]
            dir_org = tm["dir_org"]
            mat_inv = tm["mat_inv"]
            # >>>
            fac = sqrt(v / old_v)
        elif QE.state == -2:
            tm = QE.data
            if "pos_org" not in tm: return
            pos_org = tm["pos_org"]
            for e in tm["verts"]:
                e.co[:] = pos_org[e]
            # <<< 1copy (0mesh_block_upd_all_bm,, $$)
            for o_ in bm_data["bms"]:   o_.data.update()
            # >>>
            return
        else:
            old_v = self.props["area"]
            if old_v == 0.0: return
            fac = sqrt(v / old_v)
            pos_org = {}
            verts = []
            for face in bm_data["faces"]:
                pos_org.update({e: e.co.copy()  for e in face.verts})
                verts += face.verts
            center = R_if_keep_act_co(wprops["mesh_ed_face_nor_keep_act"], wprops["mesh_ed_local"])

            if wprops["mesh_ed_local"]:
                if center == None:
                    center = R_median([e.co  for e in verts])
                dir_org = {e: e.co - center  for e in verts}
                mat_inv = None
            else:
                bm_dic = bm_data["bm_dic"]
                if center == None:
                    center = R_median([bm_dic[e].matrix_world @ e.co  for e in verts])
                dir_org = {e: bm_dic[e].matrix_world @ e.co - center  for e in verts}
                mat_inv = {e: bm_dic[e].matrix_world.inverted_safe()  for e in verts}

            if QE.state == 0:
                # <<< 1copy (0mesh_block_fn_set_area_tm,, $$)
                tm = QE.data
                tm["old_v"] = old_v
                tm["pos_org"] = pos_org
                tm["verts"] = verts
                tm["center"] = center
                tm["dir_org"] = dir_org
                tm["mat_inv"] = mat_inv
                # >>>
                QE.state = 1

        if wprops["mesh_ed_local"]:
            for e in verts:
                e.co[:] = fac * dir_org[e] + center
        else:
            for e in verts:
                e.co[:] = mat_inv[e] @ (fac * dir_org[e] + center)

        # <<< 1copy (0mesh_block_upd_all_bm,, $$)
        for o_ in bm_data["bms"]:   o_.data.update()
        # >>>
        if undo_push:
            m.undo_str = f"[Mesh Editor] Faces Area = {v}"
            m.undo_push()
        # */
    #
    #
class B_LEN(BLOCK):
    __slots__ = ()
    def __init__(self, w):
        self.w = w
        self.rim = BOX()
        props = {
            "length": 0.0,
        }
        self.props = props
        self.oo = [
            FLOAT(self, rna_length, lambda: props["length"], self.fn_set_length),
        ]

    def fn_set_length(self, v, undo_push=True):
        # <<< 1copy (0mesh_block_fn_set_area,, ${
        #     '["area"]': '["length"]',
        #     'fac = sqrt(v / old_v)': 'fac = v / old_v',
        #     '["faces"]': '["edges"]',
        #     'Faces Area': 'Edges Length',
        # }$)
        if "faces" not in bm_data: return
        wprops = self.w.w.props
        v = max(0.0, v)
        if QE.state == 1:
            tm = QE.data
            # <<< 1flip (0mesh_block_fn_set_area_tm,, $' = '$)
            QE.data = tm
            old_v = tm["old_v"]
            pos_org = tm["pos_org"]
            verts = tm["verts"]
            center = tm["center"]
            dir_org = tm["dir_org"]
            mat_inv = tm["mat_inv"]
            # >>>
            fac = v / old_v
        elif QE.state == -2:
            tm = QE.data
            if "pos_org" not in tm: return
            pos_org = tm["pos_org"]
            for e in tm["verts"]:
                e.co[:] = pos_org[e]
            # <<< 1copy (0mesh_block_upd_all_bm,, $$)
            for o_ in bm_data["bms"]:   o_.data.update()
            # >>>
            return
        else:
            old_v = self.props["length"]
            if old_v == 0.0: return
            fac = v / old_v
            pos_org = {}
            verts = []
            for face in bm_data["edges"]:
                pos_org.update({e: e.co.copy()  for e in face.verts})
                verts += face.verts
            center = R_if_keep_act_co(wprops["mesh_ed_face_nor_keep_act"], wprops["mesh_ed_local"])

            if wprops["mesh_ed_local"]:
                if center == None:
                    center = R_median([e.co  for e in verts])
                dir_org = {e: e.co - center  for e in verts}
                mat_inv = None
            else:
                bm_dic = bm_data["bm_dic"]
                if center == None:
                    center = R_median([bm_dic[e].matrix_world @ e.co  for e in verts])
                dir_org = {e: bm_dic[e].matrix_world @ e.co - center  for e in verts}
                mat_inv = {e: bm_dic[e].matrix_world.inverted_safe()  for e in verts}

            if QE.state == 0:
                # <<< 1copy (0mesh_block_fn_set_area_tm,, $$)
                tm = QE.data
                tm["old_v"] = old_v
                tm["pos_org"] = pos_org
                tm["verts"] = verts
                tm["center"] = center
                tm["dir_org"] = dir_org
                tm["mat_inv"] = mat_inv
                # >>>
                QE.state = 1

        if wprops["mesh_ed_local"]:
            for e in verts:
                e.co[:] = fac * dir_org[e] + center
        else:
            for e in verts:
                e.co[:] = mat_inv[e] @ (fac * dir_org[e] + center)

        # <<< 1copy (0mesh_block_upd_all_bm,, $$)
        for o_ in bm_data["bms"]:   o_.data.update()
        # >>>
        if undo_push:
            m.undo_str = f"[Mesh Editor] Edges Length = {v}"
            m.undo_push()
        # >>>
    #
    #



def R_if_keep_act_co(is_keep_act, is_local):
    if is_keep_act is False:    return None

    # /* 0mesh_block_try_get_act_history
    try:    act = bm_data["bms"][bm_data["oj"]].bm.select_history.active
    except:
#
        act = None
    if act == None: return None
    # */

    if hasattr(act, "edges"):   m_co = act.calc_center_median()
    elif hasattr(act, "verts"): m_co = (act.verts[0].co + act.verts[1].co) / 2
    else:                       m_co = act.co

    if is_local is False:       return bm_data["oj"].matrix_world @ m_co
    return m_co
def R_act_vert(is_keep_act, use_prop=True):
    if use_prop:
        if is_keep_act == False: return None

    # <<< 1copy (0mesh_block_try_get_act_history,, $$)
    try:    act = bm_data["bms"][bm_data["oj"]].bm.select_history.active
    except:
#
        act = None
    if act == None: return None
    # >>>
    if hasattr(act, "edges"):   return None
    elif hasattr(act, "verts"): return None
    return act
def R_last_vert():
    # /* 0mesh_block_try_get_his
    try:    his = bm_data["bms"][bm_data["oj"]].bm.select_history
    except:
#
        return None
    # */
    if his:
        last = his[-1]
        if hasattr(last, "edges"):  return None
        if hasattr(last, "verts"):  return None
        return last
    else:
        return None
def R_last_vert_edge():
    # <<< 1copy (0mesh_block_try_get_his,, $$)
    try:    his = bm_data["bms"][bm_data["oj"]].bm.select_history
    except:
#
        return None
    # >>>
    if his:
        last = his[-1]
        if hasattr(last, "edges"):  return None
        return last
    else:
        return None
def R_last_2vert():
    # <<< 1copy (0mesh_block_try_get_his,, ${'return None':'return None, None'}$)
    try:    his = bm_data["bms"][bm_data["oj"]].bm.select_history
    except:
#
        return None, None
    # >>>
    if his:
        last = his[-1]
        if hasattr(last, "edges"):  return None, None
        if hasattr(last, "verts"):  return None, None
        if len(his) == 1:   return last, None
        last2 = his[-2]
        if hasattr(last2, "edges"): return last, None
        if hasattr(last2, "verts"): return last, None
        return last, last2
    return None, None

def R_angle_2_edges(e0, e1, matrix_world=None):
    # /* 0mesh_block_R_angle_2_edges
    e0_v0, e0_v1 = e0.verts
    e1_v0, e1_v1 = e1.verts

    if e0_v0 == e1_v0:
        v0 = e0_v1
        v1 = e0_v0
        v2 = e1_v1
    elif e0_v0 == e1_v1:
        v0 = e0_v1
        v1 = e0_v0
        v2 = e1_v0
    elif e0_v1 == e1_v0:
        v0 = e0_v0
        v1 = e0_v1
        v2 = e1_v1
    else:
        v0 = e0_v0
        v1 = e0_v1
        v2 = e1_v0
    # */

    if matrix_world is None:
        v0_co = v0.co
        v1_co = v1.co
        v2_co = v2.co
    else:
        v0_co = matrix_world @ v0.co
        v1_co = matrix_world @ v1.co
        v2_co = matrix_world @ v2.co

    return R_angle(v0_co, v1_co, v2_co)
def R_v012_2_edges(e0, e1, bm_dic, is_local):
    # <<< 1copy (0mesh_block_R_angle_2_edges,, $$)
    e0_v0, e0_v1 = e0.verts
    e1_v0, e1_v1 = e1.verts

    if e0_v0 == e1_v0:
        v0 = e0_v1
        v1 = e0_v0
        v2 = e1_v1
    elif e0_v0 == e1_v1:
        v0 = e0_v1
        v1 = e0_v0
        v2 = e1_v0
    elif e0_v1 == e1_v0:
        v0 = e0_v0
        v1 = e0_v1
        v2 = e1_v1
    else:
        v0 = e0_v0
        v1 = e0_v1
        v2 = e1_v0
    # >>>

    last = R_last_vert_edge()
    if hasattr(last, "verts"):
        if v0 in last.verts:    v0, v2 = v2, v0
    elif last == v0:
        v0, v2 = v2, v0
    mat = bm_dic[e0].matrix_world
    if is_local:
        v0_co = v0.co.copy()
        v1_co = v1.co.copy()
        v2_co = v2.co.copy()
    else:
        v0_co = mat @ v0.co
        v1_co = mat @ v1.co
        v2_co = mat @ v2.co

    return [v0, v1, v2], [v0_co, v1_co, v2_co], mat.inverted_safe()
def R_angle_3_verts(verts, verts_co):
    v0_co, v1_co, v2_co = verts_co

    last_v, last_v1 = R_last_2vert()
    if last_v == verts[0]:
        if last_v1 == verts[2]:
            v0_co, v1_co, v2_co = v1_co, v2_co, v0_co
        else:
            v0_co, v2_co = v2_co, v0_co
    elif last_v == verts[1]:
        if last_v1 == verts[0]:
            v0_co, v1_co, v2_co = v2_co, v0_co, v1_co
        else:
            v1_co, v2_co = v2_co, v1_co
    elif last_v1 == verts[0]:
        v0_co, v1_co = v1_co, v0_co

    return R_angle(v0_co, v1_co, v2_co)
def R_v012_3_verts(verts, bm_dic, is_local):
    v0, v1, v2 = verts

    last_v, last_v1 = R_last_2vert()
    if last_v == v0:
        if last_v1 == v2:   v0, v1, v2 = v1, v2, v0
        else:               v0, v2 = v2, v0
    elif last_v == v1:
        if last_v1 == v0:   v0, v1, v2 = v2, v0, v1
        else:               v1, v2 = v2, v1
    elif last_v1 == v0:
        v0, v1 = v1, v0

    if is_local:
        v0_co = v0.co.copy()
        v1_co = v1.co.copy()
        v2_co = v2.co.copy()
    else:
        v0_co = bm_dic[v0].matrix_world @ v0.co
        v1_co = bm_dic[v1].matrix_world @ v1.co
        v2_co = bm_dic[v2].matrix_world @ v2.co

    return [v0, v1, v2], [v0_co, v1_co, v2_co], bm_dic[v2].matrix_world.inverted_safe()



rna_distance = RNA_FLOAT("Distance", "Distance between 2 vertices.", 0.0, unit="LENGTH")
rna_invert = RNA_BOOL("Invert", "If true, move from the non-active vertex.", False)
rna_direction = RNA_FLOAT_ARRAY("Direction", "Vector direction of 2 vertices, point to active vertex.\nProperties: Invert", (0.0, 0.0, 0.0), unit="LENGTH", subtype="TRANSLATION")
rna_vec = RNA_STR("Unit Vector", "Unit vector direction of 2 vertices, point to active vertex.\nProperties: Invert", (1.0, 0.0, 0.0))
rna_nor3 = RNA_STR("Face Normal", "Depends on vertex arrangement.", (1.0, 0.0, 0.0))
rna_lock_act = RNA_BOOL("Lock Active Vertex", "If true, keep active vertex location.", False)
rna_collinear = RNA_STR("Make Collinear", "Make vertices collinear.\nProperties: Lock Active Vertex", "Make Collinear")
rna_incl_rad = RNA_FLOAT("Included Angle", "Included angle [0, π] in radians between 2 edges. If 3 vertices selected, the angle will be based on the second selected vertex.\nWhen modifying the angle, the last selected vertex will move and maintain the length from the second vertex.", 0.0)
rna_incl_deg = RNA_FLOAT("Included Angle", "Included angle [0, 180] in degrees between 2 edges. If 3 vertices selected, the angle will be based on the second selected vertex.\nWhen modifying the angle, the last selected vertex will move and maintain the length from the second vertex.", 0.0)
rna_nor = RNA_STR("Face Normal", "Unit vector direction of Face Normal.\nProperties: Keep Normals to Other Faces, Lock Active Vertex", (1.0, 0.0, 0.0))
rna_keep_nor = RNA_BOOL("Keep Normals to Other Faces", "Keep normals of unselected faces if possible.", False)
rna_coplanar = RNA_STR("Make Coplanar", "Make vertices coplanar.\nProperties: Include Selected Vertices, Keep Normals to Other Faces, Lock Active Vertex", "Make Coplanar")
rna_cop_vert = RNA_BOOL("Include Selected Vertices", "If false, only count selected faces.", False)
rna_area = RNA_FLOAT("Faces Area", "Area of selected faces.", 0.0)
rna_length = RNA_FLOAT("Edges Length", "The total Length of selected edges.", 0.0)
