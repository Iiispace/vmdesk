import bpy, bmesh
from blf import size as blf_size
from numpy.linalg import matrix_rank
from math import degrees

from .. import m
from .. m import BOX, BLF
from .. win_cls import AREA
from .. fn import bin_search_continue, R_bm_nor, R_nor_to_glo, R_bm_area_glo, R_bm_length

from . mesh_block import B_DIS, B_DIR, B_VEC, B_DIR3, B_COLL, B_ANGLE, B_NOR, B_COP, B_AREA, B_LEN, R_angle_2_edges, R_angle_3_verts

P = None
F = None
font_0 = None

bm_data = None

class DATA_VERT(AREA):
    __slots__ = ()
    def R_bo_data(self): return self.w.bo["me_info"]
    def get_data(self):
        self.oo_keys = [B_DIS(self), B_DIR(self), B_VEC(self)]
    def upd_data(self):
        b_dis, b_dir, b_vec = self.oo.values()
        oo_dis, oo_invert = b_dis.oo

        if "u_vec" in bm_data:
            wprops = self.w.props
            if wprops["mesh_ed_local"]:
                b_dis.props["dis"] = bm_data["vec"].length
                if wprops["mesh_ed_dis_invert"]:
                    b_dir.props["direction"][:] = -bm_data["vec"]
                    b_vec.props["vec"][:] = -bm_data["u_vec"]
                else:
                    b_dir.props["direction"][:] = bm_data["vec"]
                    b_vec.props["vec"][:] = bm_data["u_vec"]
            else:
                b_dis.props["dis"] = bm_data["vec_glo"].length
                if wprops["mesh_ed_dis_invert"]:
                    b_dir.props["direction"][:] = -bm_data["vec_glo"]
                    b_vec.props["vec"][:] = -bm_data["u_vec_glo"]
                else:
                    b_dir.props["direction"][:] = bm_data["vec_glo"]
                    b_vec.props["vec"][:] = bm_data["u_vec_glo"]

            if oo_dis.is_enable is False:
                oo_dis.enable()
                oo_invert.enable()
                b_dir.oo[0].enable()
                b_vec.oo[0].enable()
        else:
            if oo_dis.is_enable is True:
                oo_dis.disable()
                oo_invert.disable()
                b_dir.oo[0].disable()
                b_vec.oo[0].disable()

        b_dis.upd_oo()
        b_dir.upd_oo()
        b_vec.upd_oo()
class DATA_VERT_3(DATA_VERT):
    __slots__ = ()
    def get_data(self):
        self.oo_keys = [B_DIR3(self), B_COLL(self), B_ANGLE(self)]
    def upd_data(self):
        b_dir3, b_coll, b_angle = self.oo.values()
        if "nor3" in bm_data:
            b_dir3.props["nor"][:] = bm_data["nor3"  if self.w.props["mesh_ed_local"] else "nor3_glo"]

            vert3_co_world = bm_data["vert3_co_world"]
            v0, v1, v2 = vert3_co_world
            vecs = [v0 - v2, v1 - v2]
            th = bin_search_continue(lambda v: matrix_rank(vecs, v) < 2, 0, 1000)
            if th is None:
                b_coll.oo[0].ti.text = f"Collinear Threshold  > {m.U_format_f(1000)}"
            else:
                b_coll.oo[0].ti.text = f"Collinear Threshold  {m.U_format_f(th)}"

            if bm_data["total_edge_sel"] == 2:
                if self.w.props["mesh_ed_local"] == True:
                    an = R_angle_2_edges(*bm_data["edges"])
                else:
                    an = R_angle_2_edges(*bm_data["edges"], bm_data["bm_dic"][bm_data["edges"][0]].matrix_world)
            else:
                if self.w.props["mesh_ed_local"] == True:
                    an = R_angle_3_verts(bm_data["verts"], bm_data["vert3_co"])
                else:
                    an = R_angle_3_verts(bm_data["verts"], bm_data["vert3_co_world"])
            b_angle.props["rad"] = an
            b_angle.props["deg"] = degrees(an)

            if b_dir3.oo[0].is_enable is False:
                b_dir3.oo[0].enable()
                b_dir3.oo[1].enable()
                b_coll.oo[0].enable()
                b_angle.oo[0].enable()
                b_angle.oo[1].enable()
        else:
            if b_dir3.oo[0].is_enable is True:
                b_dir3.oo[0].disable()
                b_dir3.oo[1].disable()
                b_coll.oo[0].disable()
                b_angle.oo[0].disable()
                b_angle.oo[1].disable()

        b_dir3.upd_oo()
        b_angle.upd_oo()
class DATA_FACE(DATA_VERT):
    __slots__ = ()
    def get_data(self):
        self.oo_keys = [B_NOR(self), B_COP(self), B_AREA(self), B_LEN(self), B_ANGLE(self)]
    def upd_data(self):
        b_nor, b_cop, b_area, b_len, b_angle = self.oo.values()
        if "faces" in bm_data:
            bm_dic = bm_data["bm_dic"]

            if bm_data["total_face_sel"] == 1:
                if self.w.props["mesh_ed_local"]:
                    vec = R_bm_nor(bm_data["faces"][0]).normalized()
                else:
                    vec = R_nor_to_glo(R_bm_nor(bm_data["faces"][0]), bm_data["oj"]).normalized()
                b_nor.props["nor"] = vec

                if b_nor.oo[0].is_enable is False:
                    b_nor.oo[0].enable()
            else:
                if b_nor.oo[0].is_enable is True:
                    b_nor.oo[0].disable()

            if self.w.props["mesh_ed_cop_vert"]:
                verts = bm_data["verts"]
            else:
                verts = []
                for face in bm_data["faces"]:
                    verts += face.verts
            if len(verts) > 3:
                verts_glo = [bm_dic[v].matrix_world @ v.co  for v in verts]
                v0 = verts_glo.pop()
                vecs = [v - v0  for v in verts_glo]
                th = bin_search_continue(lambda v: matrix_rank(vecs, v) < 3, 0, 1000)
                if th is None:
                    b_cop.oo[0].ti.text = f"Coplanar Threshold  > {m.U_format_f(1000)}"
                else:
                    b_cop.oo[0].ti.text = f"Coplanar Threshold  {m.U_format_f(th)}"
                if b_cop.oo[0].is_enable is False:
                    b_cop.oo[0].enable()
            else:
                b_cop.oo[0].ti.text = f"Coplanar Threshold  {m.U_format_f(0)}"
                if b_cop.oo[0].is_enable is True:
                    b_cop.oo[0].disable()

            if self.w.props["mesh_ed_local"]:
                a = sum(face.calc_area()  for face in bm_data["faces"])
                l = sum((e.verts[0].co - e.verts[1].co).length  for e in bm_data["edges"])
            else:
                a = sum(R_bm_area_glo(face, bm_dic[face].matrix_world)  for face in bm_data["faces"])
                l = sum(R_bm_length(e, bm_dic[e].matrix_world.copy())  for e in bm_data["edges"])
            b_area.props["area"] = a
            b_len.props["length"] = l
            if a == 0:
                if b_area.oo[0].is_enable is True:
                    b_area.oo[0].disable()
            else:
                if b_area.oo[0].is_enable is False:
                    b_area.oo[0].enable()
            if l == 0:
                if b_len.oo[0].is_enable is True:
                    b_len.oo[0].disable()
            else:
                if b_len.oo[0].is_enable is False:
                    b_len.oo[0].enable()

            if bm_data["total_vert_sel"] == 3:
                if self.w.props["mesh_ed_local"] == True:
                    an = R_angle_3_verts(bm_data["verts"], [v.co  for v in bm_data["verts"]])
                else:
                    an = R_angle_3_verts(bm_data["verts"], [bm_dic[v].matrix_world @ v.co  for v in bm_data["verts"]])
                b_angle.props["rad"] = an
                b_angle.props["deg"] = degrees(an)
                if b_angle.oo[0].is_enable is False:
                    b_angle.oo[0].enable()
                    b_angle.oo[1].enable()
            else:
                if b_angle.oo[0].is_enable is True:
                    b_angle.oo[0].disable()
                    b_angle.oo[1].disable()
        else:
            if b_nor.oo[0].is_enable is True:
                b_nor.oo[0].disable()
            if b_cop.oo[0].is_enable is True:
                b_cop.oo[0].disable()
            if b_area.oo[0].is_enable is True:
                b_area.oo[0].disable()
            if b_len.oo[0].is_enable is True:
                b_len.oo[0].disable()
            if b_angle.oo[0].is_enable is True:
                b_angle.oo[0].disable()
                b_angle.oo[1].disable()

        b_nor.upd_oo()
        b_cop.upd_oo()
        b_area.upd_oo()
        b_len.upd_oo()
        b_angle.upd_oo()

