from collections import deque

from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable

from .. import m
from .. bu import BU_SIM_9
from .. keys import non_release, dict_type
from .. win_cls import MOVE_FULL_PROTECT, FLASH, OO_FO

class KEY_ED(MOVE_FULL_PROTECT, FLASH, OO_FO): # head_modal
    __slots__ = (
        'w',
        'U_draw',
        'bo',
        'ti',
        'da',
        'oo',
        'key_end',
        'key4',
    )
    def fin(self):

        del m.head_modal[-1]
        m.W_D.remove(self)
        m.redraw()
        m.EVT.kill()
    def __init__(self, w, evt):
        global P, F, K, font_0
        P = m.P
        F = m.F
        K = m.K
        font_0 = m.font_0

        BOX = m.BOX
        RIM = m.RIM
        BLF = m.BLF

        self.w = w
        self.U_draw = self.I_draw
        m.head_modal.append(self.I_modal_main)
        m.W_D.append(self)

        bo = {
            "rim":      RIM(P.color_win_rim),
            "bg":       BOX(P.color_win),
        }
        self.bo = bo
        ti = {
            "ti":       BLF(text=w.w.ti.text),
            "keys":     BLF(text="Keystrokes :"),
        }
        self.ti = ti
        da = {
            "info":     BLF(text="Focus on the area and press the desired key"),
            "keys":     BLF(),
        }
        self.da = da
        oo = {
            "clear":    BU_SIM_9(self, "clear", "Clear", color_type=1),
            "yes":      BU_SIM_9(self, "yes", "Confirm", color_type=1),
            "no":       BU_SIM_9(self, "no", "Cancel", color_type=1),
        }
        self.oo = oo
        self.key4 = deque(maxlen=4)
        self.oo_fo = None

        x = evt.mouse_region_x
        y = evt.mouse_region_y
        unit = P.scale[0]
        _1 = F[1]
        _d = F[15]
        dw = F[150] + _d
        bu_hi = F[16]
        L = x - dw
        R = x + dw
        T = y + F[38]

        L0 = L + F[6]
        T0 = T - _d
        ti["ti"].xy(L0, T0)
        T0 -= _d
        da["info"].xy(L0, T0)
        T0 -= _d
        ti["keys"].xy(L0, T0)
        da["keys"].xy(L0 + F[61], T0)
        T0 -= F[10]
        blf_size(font_0, F[9])
        oo["clear"].LRBT(L0, L0 + F[46], T0 - bu_hi, T0, _1)
        dx = F[30]
        wi = F[52]
        T0 -= F[22]
        B = T0 - bu_hi
        R0 = x - dx
        oo["yes"].LRBT(R0 - wi, R0, B, T0, _1)
        R0 = x + dx
        oo["no"].LRBT(R0, R0 + wi, B, T0, _1)

        B -= F[8]
        r = bo["rim"]
        r.LRBTd_rev(L, R, B, T, _1)
        bo["bg"].LRBT(L, R, B, T)
        if P.win_shade_on:
            bo["shade"] = m.SHADE(P.win_shade_color)
            bo["shade"].get_by_rim(
                L, R, B, T,
                P.win_shade_softness, P.win_shade_offset, unit
            )
        else:
            bo["shade"] = m.BOX_FAKE()

        dx, dy = m.R_full_protect_dxy(r.L, r.R, r.B, r.T)
        self.dxy_upd(dx, dy)
        m.redraw()

    def dxy_upd(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        if self.bo["rim"].inbox_xy(x, y) is False:
            self.unfocus()
            if K["cancel0"].true() or K["cancel1"].true():
                self.fin()
                return
            if evt.value == 'PRESS':
                self.do_flash()
                return
            return

        if y >= self.ti["ti"].y:
            self.unfocus()
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
                return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
                return
        else:
            for e in self.oo.values():
                if e.inbox_xy(x, y):
                    self.focus_check(evt, e)
                    e.modal(evt)
                    return

            self.unfocus()

        if evt.value == 'PRESS':
            ty = evt.type
            if ty in non_release or ty in dict_type:
                if ty not in self.key4:
                    self.key4.append(ty)
                    tx = ""
                    for e in self.key4: tx += f'{e}   '
                    self.da["keys"].text = tx
                    m.redraw()

    def bufn_clear(self):
        self.key4.clear()

        self.da["keys"].text = ""
    def bufn_yes(self):
        self.w.w.write_type(self.key4, self.w)
        self.fin()
        m.refresh()
    def bufn_no(self):
        self.fin()

    def I_draw(self):
        bo = self.bo
        ti = self.ti
        da = self.da
        oo = self.oo

        m.BLEND()
        bo["shade"].draw()
        bo["rim"].bind_draw()
        bo["bg"].bind_draw()

        m.bind_color_bu_1_rim()
        oo_clear = oo["clear"]
        oo_yes = oo["yes"]
        oo_no = oo["no"]

        oo_clear.rim.draw()
        oo_yes.rim.draw()
        oo_no.rim.draw()

        oo_clear.bg.bind_draw()
        oo_yes.bg.bind_draw()
        oo_no.bg.bind_draw()

        blf_size(font_0, F[12])
        blf_color(font_0, *P.color_font)
        ti["ti"].draw_pos()

        blf_size(font_0, F[9])
        ti["keys"].draw_pos()
        da["keys"].draw_pos()
        oo_clear.ti.draw_pos()
        oo_yes.ti.draw_pos()
        oo_no.ti.draw_pos()

        blf_color(font_0, *P.color_font_darker)
        da["info"].draw_pos()

        m.FLASH_BOX.U_draw()

class KEY_ED_SINGLE(KEY_ED):
    __slots__ = 'end_fn'
    def __init__(self, w, evt, end_fn, sub_ti=""):
        self.end_fn = end_fn
        super().__init__(w, evt)
        self.key4 = deque(maxlen=1)
        self.ti["ti"].text += sub_ti
        self.ti["keys"].text = "Keystroke :"
    def bufn_yes(self):
        self.fin()
        self.end_fn(self.key4)