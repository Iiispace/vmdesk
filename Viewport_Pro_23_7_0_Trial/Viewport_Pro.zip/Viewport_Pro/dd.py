import bpy, gpu

from blf import size as blf_size
from blf import color as blf_color
from gpu_extras.batch import batch_for_shader
from bpy.app.timers import register as thread_reg
from bpy.app.timers import unregister as thread_unreg
from colorsys import rgb_to_hsv, hsv_to_rgb

from . import m, bu, calc, py_math, rm, win_mess
from . fn import HSB, rgb_int_to_hex, R_rgb_by_str
from . color_list import D_null, L_rgb_to_glc, L_rgb_to_glb, glc_find, glb_find

P = None
F = None
K = None
N = None
BOX = None
BLF = None
shader2D    = None
BIND        = None
UNFL        = None
font_0      = None
BLEND       = None

VAL_COLOR   = None

indices_box = ((0,1,2),(0,2,3))
color_black = (0.0, 0.0, 0.0, 1.0)
color_white = (1.0, 1.0, 1.0, 1.0)


class DDTX:
    __slots__ = (
        'w',
        'fil',
        'U_modal',
        'U_draw',
        'default_modal',
        'U_draw_cursor',
        'U_sw_cursor',
        'cursor_time',
        'draw_ot',
        'draw_act',
        'bo_cursor',
        'bo',
        'ti',
        'da',
        'li',
        'bu_scrollY',
        'sci',
        'sci_tx',
        'sci_fil',
        'init_li',
        'upd_fil',
        'fil_wi',
        'fil_limL',
        'fil_limR',
        'fil_limB',
        'fil_limT',
        'li9_y',
        'fil_x',
        'fil_y',
        'bo_cursor_wi',
        'thread_cursor',
        'thread_copy',
        'tx_limL',
        'tx_limR',
        'bo_tx_Rm4',
        'dxi0',
        'dxi1',
        'th_auto_L',
        'th_auto_R',
        'U_init_thread_cursor',
        'U_kill_thread_cursor',
        'i0',
        'i1',
        'key_end',
        'tm_T',
        'tm_B',
        'tm_h',
        'tm_d',
        'amt_10',
        'actbox',
        'act_ind',
        'tx_org',
        'fil_attr',
        'end_fn',
        'is_dd_confirm',
        'confirm_text',
    )
    def __init__(self,
        BU,
        fil             = None,
        tx_clear        = None,
        end_fn          = None,
        enable_filter   = None,
    ):
        u       = P.scale[0]

        self.w          = BU
        self.fil        = fil
        self.fil_attr   = None  if fil is None else fil.attr
        self.end_fn     = end_fn

        self.default_modal  = self.I_modal_main
        self.U_draw_cursor  = self.I_draw_cursor
        self.U_sw_cursor    = self.I_sw_cursor_on
        self.cursor_time    = P.cursor_flash_rate

        self.draw_ot    = {}
        self.draw_act   = {}
        bo_cursor       = BOX(P.color_tx_cursor)
        self.bo_cursor  = bo_cursor
        m.tm["is_dd_confirm"] = False
        self.is_dd_confirm = False

        bo = {
            "shade":        m.SHADE(P.dd_shade_color) if P.win_shade_on else m.BOX_FAKE(),
            "bg":           BOX(P.color_ddmenu),
            "tx":           BOX(P.color_bu_3_on),
            "fil":          BOX(P.color_filter),
            "highlight":    BOX(P.color_tx_sel),
        }
        self.bo = bo

        self.ti = {}
        override = type(BU) is dict
        if override:
#
            da_name = BU["name"]
            bo_tx_L, bo_tx_R, bo_tx_B, bo_tx_T = BU["LRBT"]
            tx_x    = bo_tx_L + F[5]
            tx_y    = bo_tx_B + F[5]
        else:
#
            da_name = BU.da.name
            tx_x    = BU.da.x
            tx_y    = BU.da.y
            rim     = BU.rim
            bo_tx_L = rim.L
            bo_tx_R = rim.R
            bo_tx_B = rim.B
            bo_tx_T = rim.T

        self.tx_org     = da_name

        da = {
            "tx":       BLF(P.color_font, da_name, x = tx_x, y = tx_y)
        }
        self.da = da

        self.li         = []
        self.bu_scrollY = bu.BUSCROLLY(self, "scrollY")
        self.sci = m.SCISSOR(0, 0, bpy.context.window.width, bpy.context.window.height)
        self.sci_tx     = m.SCISSOR()
        self.sci_fil    = m.SCISSOR()

        m.admin.tb.draw_top.append(self)
        m.head_modal.append(self.run_modal)

        _1          = F[1]

        bo["tx"].LRBT(bo_tx_L, bo_tx_R, bo_tx_B, bo_tx_T)
        L   = bo["tx"].L - _1
        R   = bo["tx"].R + _1

        if (fil == None or P.filter_algorithm == 'DISABLE') and enable_filter is not True:
            B   = bo["tx"].B - _1
            T   = bo["tx"].T + _1
            self.U_draw     = self.I_draw_simple
            self.init_li    = N
            self.upd_fil    = N
            self.act_ind    = None
            self.fil_x      = 0
            self.fil_y      = 0
            self.fil_limL   = 0
            self.fil_limR   = 0
            self.fil_limB   = 0
            self.fil_limT   = 0
            self.fil_wi     = R - F[15] - L - F[2]
            bo["fil"].T     = -1
        else:
            self.U_draw     = self.I_draw
            self.init_li    = self.I_init_li

            d = F[16] * 10 + F[2] + F[2]
            B = bo["tx"].B - d
            if B < 0 and not hasattr(self, "to_modal_mov"):
                B   = bo["tx"].B - _1
                T   = bo["tx"].T + d
                bo["fil"].LRBT(L + F[2], R - F[15], bo["tx"].T + F[2], T - F[2])
            else:
                T = bo["tx"].T + _1
                bo["fil"].LRBT(L + F[2], R - F[15], B + F[2], bo["tx"].B - F[2])

            self.fil_wi     = bo["fil"].R_w()
            self.bu_scrollY.LRBT(bo["fil"].R + _1, R - F[2], bo["fil"].B, bo["fil"].T)

            self.fil_limL   = bo["fil"].L + F[4]
            self.fil_limT   = bo["fil"].T - F[11]
            self.li9_y      = self.fil_limT - 9 * F[16]
            self.fil_x      = self.fil_limL
            self.fil_y      = self.fil_limT

            fil.get_li_full_sort()
            self.upd_fil    = self.I_upd_fil  if fil.li_full else N
            fil.find_ind(da_name)
            if fil.ind0 is not None:    self.init_li()

            self.act_ind    = fil.R_ind(self.tx_org)

        self.sci_tx.box_round(bo["tx"])
        self.sci_fil.box_round(bo["fil"])
        bo["bg"].LRBT(L, R, B, T)
        if P.win_shade_on:
            bo["shade"].get_by_rim(L, R, B, T, P.dd_shade_softness, P.dd_shade_offset, u)

        bo_cursor.B         = bo["tx"].B + _1
        bo_cursor.T         = bo["tx"].T - _1
        self.bo_cursor_wi   = F[P.cursor_thickness]
        bo["highlight"].B   = bo_cursor.B + _1
        bo["highlight"].T   = bo_cursor.T - _1

        ll = len(self.da["tx"].text)
        if P.auto_sel_text: self.set_highlight(0, ll)
        else:   self.set_highlight(ll, ll)

        for e in bo.values():  e.upd()

        self.thread_cursor  = self.I_thread_cursor
        self.thread_copy    = self.I_thread_tx_copy
        self.I_init_thread_cursor()
        self.tx_limL        = self.da["tx"].x
        self.bo_tx_Rm4      = bo["tx"].R - F[4]
        self.calc_tx_lim()

        if self.tx_limL != self.tx_limR:
            self.dxi0 = bo["highlight"].L - self.da["tx"].x
            self.dxi1 = bo["highlight"].R - self.da["tx"].x
            self.da["tx"].x = self.tx_limR
            self.upd_highlight()

        self.th_auto_L  = bo["tx"].L + F[4]
        self.th_auto_R  = bo["tx"].R - F[4]

        w = self
# INS class DDTX_ACTBOX
        class DDTX_ACTBOX:
            __slots__ = "color", "bat", "upd"
            def __init__(self):
                self.bat    = batch_for_shader(shader2D, 'TRIS', {"pos": (
                    (0,0), (0,0), (0,0), (0,0))}, indices=indices_box
                )
                self.color  = P.color_dd_actbox
                self.upd    = self.I_upd_null  if w.act_ind is None else self.I_upd

            def bind_draw(self):
                BIND()
                UNFL("color", self.color)
                self.bat.draw(shader2D)

            def I_upd_null(self, i0, i1):  pass
            def I_upd(self, i0, i1):
                if i0 is None:
                    L = 0
                    R = 0
                    B = 0
                    T = 0
                else:
                    ind     = w.act_ind - i0
                    if 0 <= ind < len(w.li):
                        L = bo["fil"].L
                        R = bo["fil"].R
                        y = w.li[ind].y
                        T = y + F[11]
                        B = y - F[4]
                    else:
                        L = 0
                        R = 0
                        B = 0
                        T = 0

                self.bat    = batch_for_shader(shader2D, 'TRIS', {"pos": (
                    (L,B), (L,T), (R,T), (R,B))}, indices=indices_box
                )
# INS class DDTX_ACTBOX END
        actbox          = DDTX_ACTBOX()
        self.actbox     = actbox
        if fil is None: actbox.upd(None, None)
        else:           actbox.upd(fil.ind0, fil.ind1)

        if tx_clear is None:
            if P.auto_del_text:     self.evt_del_all()
        elif tx_clear:              self.evt_del_all()

        if bo["tx"].inbox(m.EVT.evt):
            self.U_modal = self.I_modal_tx
            m.M.set_mou_ic('TEXT')
        else:
            self.U_modal = self.I_modal_main
            m.M.set_mou_ic('DEFAULT')

        m.init_wait_release()
        m.redraw()

    def fin(self, evt):
#
        del m.head_modal[-1]
        m.admin.tb.draw_top.remove(self)
        if self.fil is not None:    self.fil.clear()
        self.U_kill_thread_cursor()

        m.M.set_mou_ic('DEFAULT')
        m.EVT.kill()
        m.admin.push_modal()
        if self.end_fn is not None: self.end_fn()
        m.redraw()
# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_init_thread_cursor(self):
        self.U_init_thread_cursor   = N
        self.U_kill_thread_cursor   = self.I_kill_thread_cursor
        thread_reg(self.thread_cursor)
    def I_kill_thread_cursor(self):
#
        self.U_init_thread_cursor   = self.I_init_thread_cursor
        self.U_kill_thread_cursor   = N
        thread_unreg(self.thread_cursor)
    def thread_cursor_reset(self):
        self.U_kill_thread_cursor()
        self.I_init_thread_cursor()
        self.U_draw_cursor  = self.I_draw_cursor
        self.U_sw_cursor    = self.I_sw_cursor_on

    def set_highlight(self, i0, i1):
        blf_size(font_0, F[9])
        bo_highlight    = self.bo["highlight"]
        bo_cursor       = self.bo_cursor
        self.i0 = i0
        self.i1 = i1
        L       = self.da["tx"].R_nth_x(i0)
        R       = self.da["tx"].R_nth_x(i1)

        bo_highlight.L  = L
        bo_highlight.R  = R
        bo_highlight.upd()
        bo_cursor.L     = R
        bo_cursor.R     = R + self.bo_cursor_wi
        bo_cursor.upd()
    def upd_highlight(self): #self.dxi0, self.dxi1
        bo_highlight    = self.bo["highlight"]
        bo_cursor       = self.bo_cursor
        L   = self.da["tx"].x + self.dxi0
        R   = self.da["tx"].x + self.dxi1

        bo_highlight.L  = L
        bo_highlight.R  = R
        bo_highlight.upd()
        bo_cursor.L     = R
        bo_cursor.R     = R + self.bo_cursor_wi
        bo_cursor.upd()
    def set_cursor_tx(self, s):
        ll = len(s)
        tx = self.da["tx"]
        i0 = self.i0
        i1 = self.i1

        if i0 == i1:
            tx.text = tx.text[ : i0] + s + tx.text[i1 : ]
            i1 += ll
            self.set_highlight(i1, i1)
        elif i0 < i1:
            tx.text = tx.text[ : i0] + s + tx.text[i1 : ]
            i0 += ll
            self.set_highlight(i0, i0)
        else:
            tx.text = tx.text[ : i1] + s + tx.text[i0 : ]
            i1 += ll
            self.set_highlight(i1, i1)

        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_pos()
        self.upd_fil()

    def calc_tx_lim(self):
        blf_size(font_0, F[9])
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)

    def check_limL(self):
        self.calc_tx_lim()
        if self.da["tx"].x > self.tx_limL:
            self.dxi0 = self.bo["highlight"].L - self.da["tx"].x
            self.dxi1 = self.bo["highlight"].R - self.da["tx"].x
            self.da["tx"].x = self.tx_limL
            self.upd_highlight()
    def check_limR(self):
        self.calc_tx_lim()
        if self.da["tx"].x < self.tx_limR:
            self.dxi0 = self.bo["highlight"].L - self.da["tx"].x
            self.dxi1 = self.bo["highlight"].R - self.da["tx"].x
            self.da["tx"].x = self.tx_limR
            self.upd_highlight()
    def check_cursor_posR(self): #self.tx_lim
        if self.bo_cursor.L > self.bo_tx_Rm4:
            tx = self.da["tx"]
            dif = self.bo_tx_Rm4 - self.bo_cursor.L
            new_x = tx.x + dif
            if new_x > self.tx_limL:    new_x = self.tx_limL
            elif new_x < self.tx_limR:  new_x = self.tx_limR
            self.dxi0 = self.bo["highlight"].L - tx.x
            self.dxi1 = self.bo["highlight"].R - tx.x
            tx.x = new_x
            self.upd_highlight()
    def check_cursor_posL(self): #self.tx_lim
        if self.bo_cursor.L < self.tx_limL:
            tx = self.da["tx"]
            dif = self.tx_limL - self.bo_cursor.L
            new_x = tx.x + dif
            if new_x > self.tx_limL:    new_x = self.tx_limL
            elif new_x < self.tx_limR:  new_x = self.tx_limR
            self.dxi0 = self.bo["highlight"].L - tx.x
            self.dxi1 = self.bo["highlight"].R - tx.x
            tx.x = new_x
            self.upd_highlight()
    def check_cursor_pos(self): #self.tx_lim
        if self.bo_cursor.L > self.bo_tx_Rm4:
            tx = self.da["tx"]
            dif = self.bo_tx_Rm4 - self.bo_cursor.L
            new_x = tx.x + dif
            if new_x > self.tx_limL:    new_x = self.tx_limL
            elif new_x < self.tx_limR:  new_x = self.tx_limR
            self.dxi0 = self.bo["highlight"].L - tx.x
            self.dxi1 = self.bo["highlight"].R - tx.x
            tx.x = new_x
            self.upd_highlight()
        elif self.bo_cursor.L < self.tx_limL:
            tx = self.da["tx"]
            dif = self.tx_limL - self.bo_cursor.L
            new_x = tx.x + dif
            if new_x > self.tx_limL:    new_x = self.tx_limL
            elif new_x < self.tx_limR:  new_x = self.tx_limR
            self.dxi0 = self.bo["highlight"].L - tx.x
            self.dxi1 = self.bo["highlight"].R - tx.x
            tx.x = new_x
            self.upd_highlight()

    def I_init_li(self): #self.fil.ind0 != None
        li      = self.li
        fil     = self.fil
        maxW    = 0
        attr    = self.fil_attr

        li.clear()
        self.draw_act.clear()
        blf_size(font_0, F[9])

        fil_li      = fil.li_full
        fil_ind0    = fil.ind0
        fil_ind1    = fil.ind1

        y = self.fil_limT
        for r in range(fil_ind0, min(fil_ind1 + 1, fil_ind0 + 11)):
            li.append(BLF(text = getattr(fil_li[r], attr), size = r, y = y))
            d = li[-1].R_dimen()
            if d > maxW:    maxW = d
            y -= F[16]

        self.fil_limR   = min(self.fil_limL, self.fil_limL - maxW + self.fil_wi - F[8])
        self.draw_ot    = {r : None for r in range(len(li))}
        amt             = fil.ind1 - fil.ind0 - 9
        self.fil_limB   = self.fil_limT + (amt * F[16])  if amt > 0 else self.fil_limT
        self.bu_scrollY.upd_scroll(self.fil_limT, self.fil_limB, self.fil_y, amt)

    def I_upd_fil(self):
        self.fil_x  = self.fil_limL
        self.fil_y  = self.fil_limT
        self.fil.find_ind(self.da["tx"].text)

        if self.fil.ind0 == None:
            self.li.clear()
            self.draw_ot.clear()
            self.draw_act.clear()
            self.fil_limB = self.fil_limT
            self.bu_scrollY.upd_scroll(0,0,0,0)
        else:
            self.init_li()

        self.actbox.upd(self.fil.ind0, self.fil.ind1)

    def upd_draw_act_by_y(self, y):
        if not self.li: return
        fil = self.fil
        fil_ind = int((self.fil_y - y + F[12]) // F[16]) + fil.ind0

        if fil.ind0 <= fil_ind <= fil.ind1:
            i = fil_ind - self.li[0].size

            if 0 <= i < len(self.li):   pass
            else:   return

            if self.draw_act:
                for k in self.draw_act:
                    if k == i:  return
                self.draw_ot[k] = None
                self.draw_act.clear()
            self.draw_act[i] = None
            del self.draw_ot[i]
            m.redraw()
        else:   self.clear_draw_act()
    def clear_draw_act(self):
        if self.draw_act:
            for k in self.draw_act:     self.draw_ot[k] = None
            self.draw_act.clear()
            m.redraw()

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def run_modal(self, evt):   self.U_modal(evt)
    def I_modal_main(self, evt):
        if self.bo["bg"].inbox(evt) == False:
            if K["dd_sel0"].true(): self.evt_confirm(evt)  ;return
            if K["dd_sel1"].true(): self.evt_confirm(evt)  ;return

        bu_RET = self.bu_scrollY.evt(evt)
        if bu_RET is not None:
            if K["dd_bar0"].true():
                self.key_end = K["dd_bar_E0"]
                if bu_RET:  self.to_modal_bar_bu(evt)
                else:       self.to_modal_bar_bg(evt)
                return
            if K["dd_bar1"].true():
                self.key_end = K["dd_bar_E1"]
                if bu_RET:  self.to_modal_bar_bu(evt)
                else:       self.to_modal_bar_bg(evt)
                return

        if self.bo["tx"].inbox(evt):
            self.clear_draw_act()
            m.M.set_mou_ic('TEXT')
            self.U_modal = self.I_modal_tx
            self.I_modal_tx(evt)
            return

        if self.bo["fil"].inbox(evt):
            self.upd_draw_act_by_y(evt.mouse_region_y)
            if K["dd_pan0"].true():
                self.key_end = K["dd_pan_E0"]  ;self.to_modal_pan_fil(evt)  ;return
            if K["dd_pan1"].true():
                self.key_end = K["dd_pan_E1"]  ;self.to_modal_pan_fil(evt)  ;return
            if K["dd_sel0"].true():     self.evt_fil_sel(evt)  ;return
            if K["dd_sel1"].true():     self.evt_fil_sel(evt)  ;return
        else:   self.clear_draw_act()

        if K["dd_cancel0"].true():  self.fin(evt)   ;return
        if K["dd_cancel1"].true():  self.fin(evt)   ;return
        if K["dd_confirm0"].true(): self.evt_confirm(evt)  ;return
        if K["dd_confirm1"].true(): self.evt_confirm(evt)  ;return
        self.unicode_evt(evt)

    def I_modal_tx(self, evt):
        if self.bo["tx"].inbox(evt) == False:
            m.M.set_mou_ic('DEFAULT')
            self.U_modal = self.I_modal_main
            self.I_modal_main(evt)
            return

        if K["rm0"].true():         self.evt_rm_tx(evt)    ;return
        if K["rm1"].true():         self.evt_rm_tx(evt)    ;return
        if K["dd_cancel0"].true():  self.fin(evt)   ;return
        if K["dd_cancel1"].true():  self.fin(evt)   ;return
        if K["dd_confirm0"].true(): self.evt_confirm(evt)  ;return
        if K["dd_confirm1"].true(): self.evt_confirm(evt)  ;return
        self.unicode_evt(evt)

    def evt_rm_tx(self, evt):
#

        def end_fn():
            m.M.set_mou_ic('TEXT'  if self.bo["tx"].inbox(m.EVT.evt) else 'DEFAULT')

        rm.RM_HEAD(self, evt, (
            ("Cut", self.evt_cut),
            ("Copy", self.evt_copy),
            ("Paste", self.evt_paste),
            ("Delete", self.evt_del_alp),
            ("Select All", self.evt_sel_all)
        ), info = f"", end_fn = end_fn)
    def evt_fil_sel(self, evt):
        if self.draw_act:   pass
        else:   return
        for i in self.draw_act:     self.da["tx"].text = self.li[i].text
        self.evt_confirm(evt)
    def evt_confirm(self, evt):
        m.tm["is_dd_confirm"] = True
        self.is_dd_confirm = True
        self.confirm_text = self.da["tx"].text
        if hasattr(self.w, "bpy_setter"):
            self.w.bpy_setter(self.da["tx"].text)
            self.w.setter()
        self.fin(evt)
    def evt_del_alp(self):
        i0  = self.i0
        i1  = self.i1
        tx  = self.da["tx"]

        if tx.text == "":    return
        self.thread_cursor_reset()
        if i0 == i1:
            i0 -= 1
            tx.text = tx.text[ : i0] + tx.text[i1 : ]
            self.set_highlight(i0, i0)
        elif i0 < i1:
            tx.text = tx.text[ : i0] + tx.text[i1 : ]
            self.set_highlight(i0, i0)
        else:
            tx.text = tx.text[ : i1] + tx.text[i0 : ]
            self.set_highlight(i1, i1)
        self.check_limR()
#
        self.upd_fil()
        m.redraw()
    def evt_del_word(self):
        i0  = self.i0
        i1  = self.i1
        tx  = self.da["tx"]
        s   = tx.text

        if s == "": return
        self.thread_cursor_reset()
        if i0 == i1:
            while i0 > 0:
                if s[i0 - 1 : i0] != " ":    i0 -= 1  ;break
                i0 -= 1
            while i0 > 0:
                if s[i0 - 1 : i0] == " ":    break
                i0 -= 1
            tx.text = s[ : i0] + tx.text[i1 : ]
            self.set_highlight(i0, i0)
            self.check_limR()
#
            self.upd_fil()
        else:
            self.evt_del_alp()
            return
        m.redraw()
    def evt_del_all(self):
        if self.da["tx"].text == "": return
        self.evt_sel_all()
        self.evt_del_alp()
    def evt_left(self):
        self.thread_cursor_reset()
        i = max(0, self.i1 - 1)
        self.set_highlight(i, i)
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posL()
        m.redraw()
    def evt_right(self):
        self.thread_cursor_reset()
        i = min(self.i1 + 1, len(self.da["tx"].text))
        self.set_highlight(i, i)
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posR()
        m.redraw()
    def evt_up(self):
        self.thread_cursor_reset()
        self.set_highlight(0, 0)
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posL()
        m.redraw()
    def evt_down(self):
        self.thread_cursor_reset()
        i = len(self.da["tx"].text)
        self.set_highlight(i, i)
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posR()
        m.redraw()
    def evt_shift_left(self):
        self.thread_cursor_reset()
        i = max(0, self.i1 - 1)
        self.set_highlight(self.i0, i)
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posL()
        m.redraw()
    def evt_shift_right(self):
        self.thread_cursor_reset()
        i = min(self.i1 + 1, len(self.da["tx"].text))
        self.set_highlight(self.i0, i)
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posR()
        m.redraw()
    def evt_shift_up(self):
        self.thread_cursor_reset()
        self.set_highlight(self.i0, 0)
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posL()
        m.redraw()
    def evt_shift_down(self):
        self.thread_cursor_reset()
        self.set_highlight(self.i0, len(self.da["tx"].text))
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posR()
        m.redraw()
    def evt_sel(self, evt):
        self.thread_cursor_reset()
        if self.bo["tx"].inbox(evt) == False:   return
        if self.da["tx"].text == "":            return
        blf_size(font_0, F[9])
        i = self.da["tx"].R_ind(evt.mouse_region_x)
        self.set_highlight(i, i)
        m.redraw()
    def evt_sel_all(self):
        self.thread_cursor_reset()
        if self.da["tx"].text == "":            return
        self.set_highlight(0, len(self.da["tx"].text))
        self.tx_limR = min(self.bo_tx_Rm4 - self.da["tx"].R_dimen(), self.tx_limL)
        self.check_cursor_posR()
        m.redraw()
    def evt_copy(self):
        if self.i0 == self.i1:  return
        if self.i0 < self.i1:
            bpy.context.window_manager.clipboard = self.da["tx"].text[self.i0 : self.i1]
        else: bpy.context.window_manager.clipboard = self.da["tx"].text[self.i1 : self.i0]
        self.bo["highlight"].color = P.color_tx_copy
        thread_reg(self.thread_copy, first_interval=0.1)
        m.redraw()
        m.EVT.kill_except(m.EVT.evt)
    def evt_paste(self):
        self.set_cursor_tx(bpy.context.window_manager.clipboard)
        m.redraw()
        m.EVT.kill_except(m.EVT.evt)
    def evt_cut(self):
        if self.i0 == self.i1:  return
        if self.i0 < self.i1:
            bpy.context.window_manager.clipboard = self.da["tx"].text[self.i0 : self.i1]
        else: bpy.context.window_manager.clipboard = self.da["tx"].text[self.i1 : self.i0]
        self.set_cursor_tx("")
        m.redraw()
        m.EVT.kill_except(m.EVT.evt)
    def evt_tab(self):
        ll = len(self.li)
        if ll == 0: return
        fil = self.fil
        fil_ind = int((self.fil_y - self.fil_limT + F[8]) // F[16]) + fil.ind0
        if fil.ind0 <= fil_ind <= fil.ind1:
            i = fil_ind - self.li[0].size
            if 0 <= i < ll:
                self.evt_sel_all()
                self.set_cursor_tx(self.li[i].text)
                m.redraw()
    def evt_scroll(self, dy): # int
#
        if not self.li: return

        ll              = len(self.li)
        self.draw_ot    = {r : None for r in range(ll)}
        self.draw_act.clear()
        self.amt_10     = self.fil.ind1 - self.fil.ind0 - 9
        m.dy            = dy
        self.pan_fil_y()
        self.bu_scrollY.upd_scroll(self.fil_limT, self.fil_limB, self.fil_y, self.amt_10)
        m.redraw()

    def to_modal_bar_bg(self, evt):
#
        if not self.li: return

        e           = self.bu_scrollY
        self.tm_T   = e.max_T
        self.tm_B   = e.min_B + e.bar_rim.R_h()
        self.tm_h   = self.tm_T - self.tm_B

        if self.tm_h == 0:
            m.get_mou(evt)
            m.head_modal.append(self.I_modal_bar_x)
            self.key_end.true()
            return
        self.tm_d = self.fil_limB - self.fil_limT

        dy      = evt.mouse_region_y - e.bar_rim.R_center_y()
        self.bu_scrollY.bar_mov(dy)
        rate    = (self.tm_T - self.bu_scrollY.bar_rim.T) / self.tm_h
        new_y   = self.fil_limT + round(rate * self.tm_d)
        m.dy    = new_y - self.fil_y
        self.pan_fil_y()
        m.get_mou(evt)
        m.redraw()
        m.head_modal.append(self.I_modal_bar)
        self.key_end.true()
    def to_modal_bar_bu(self, evt):
#
        if not self.li: return

        e           = self.bu_scrollY
        self.tm_T   = e.max_T
        self.tm_B   = e.min_B + e.bar_rim.R_h()
        self.tm_h   = self.tm_T - self.tm_B

        if self.tm_h == 0:
            m.get_mou(evt)
            m.head_modal.append(self.I_modal_bar_x)
            self.key_end.true()
            return

        self.tm_d = self.fil_limB - self.fil_limT
        m.get_mou(evt)
        m.head_modal.append(self.I_modal_bar)
        self.key_end.true()
    def to_modal_pan_fil(self, evt):
        if not self.li: return

        ll              = len(self.li)
        self.draw_ot    = {r : None for r in range(ll)}
        self.draw_act.clear()

        m.U_pan_cursor(self, evt)
        m.get_loop_mou_info()
        m.get_mou(evt)
        self.amt_10     = self.fil.ind1 - self.fil.ind0 - 9
        if ll < 11:     m.head_modal.append(self.I_modal_pan_fil_x)
        else:           m.head_modal.append(self.I_modal_pan_fil)
        self.key_end.true()
    def to_modal_pan(self, evt):
#
        m.U_pan_cursor(self, evt)
        m.get_loop_mou_info()
        m.get_mou(evt)
        self.calc_tx_lim()
        self.dxi0 = self.bo["highlight"].L - self.da["tx"].x
        self.dxi1 = self.bo["highlight"].R - self.da["tx"].x
        m.head_modal.append(self.I_modal_pan)
        self.key_end.true()
    def to_modal_box(self, evt, k):
        self.thread_cursor_reset()
        if self.da["tx"].text == "":    return
        blf_size(font_0, F[9])
        i = self.da["tx"].R_ind(k.org_x + evt.mouse_region_x-evt.mouse_x  if k.value == 'DRAG' else evt.mouse_region_x)
        self.set_highlight(i, i)
        self.calc_tx_lim()
        m.head_modal.append(self.I_modal_box)
        self.key_end.true()
    def unicode_evt(self, evt):
        if K["dd_del_all0"].true():     self.evt_del_all()  ;return
        if K["dd_del_all1"].true():     self.evt_del_all()  ;return
        if K["dd_del_word0"].true():    self.evt_del_word() ;return
        if K["dd_del_word1"].true():    self.evt_del_word() ;return
        if K["dd_del_alp0"].true():     self.evt_del_alp()  ;return
        if K["dd_del_alp1"].true():     self.evt_del_alp()  ;return
        if K["dd_shift_left0"].true():  self.evt_shift_left()   ;return
        if K["dd_shift_left1"].true():  self.evt_shift_left()   ;return
        if K["dd_shift_right0"].true(): self.evt_shift_right()  ;return
        if K["dd_shift_right1"].true(): self.evt_shift_right()  ;return
        if K["dd_shift_up0"].true():    self.evt_shift_up()     ;return
        if K["dd_shift_up1"].true():    self.evt_shift_up()     ;return
        if K["dd_shift_down0"].true():  self.evt_shift_down()   ;return
        if K["dd_shift_down1"].true():  self.evt_shift_down()   ;return
        if K["dd_left0"].true():        self.evt_left()   ;return
        if K["dd_left1"].true():        self.evt_left()   ;return
        if K["dd_right0"].true():       self.evt_right()  ;return
        if K["dd_right1"].true():       self.evt_right()  ;return
        if K["dd_up0"].true():          self.evt_up()     ;return
        if K["dd_up1"].true():          self.evt_up()     ;return
        if K["dd_down0"].true():        self.evt_down()   ;return
        if K["dd_down1"].true():        self.evt_down()   ;return
        if self.bo["tx"].inbox(evt):
            if K["dd_box0"].true():
                self.key_end = K["dd_box_E0"]  ;self.to_modal_box(evt, K["dd_box0"])  ;return
            if K["dd_box1"].true():
                self.key_end = K["dd_box_E1"]  ;self.to_modal_box(evt, K["dd_box1"])  ;return
        if K["dd_pan0"].true():  self.key_end = K["dd_pan_E0"]  ;self.to_modal_pan(evt)  ;return
        if K["dd_pan1"].true():  self.key_end = K["dd_pan_E1"]  ;self.to_modal_pan(evt)  ;return
        if K["dd_copy0"].true():        self.evt_copy()     ;return
        if K["dd_copy1"].true():        self.evt_copy()     ;return
        if K["dd_paste0"].true():       self.evt_paste()    ;return
        if K["dd_paste1"].true():       self.evt_paste()    ;return
        if K["dd_cut0"].true():         self.evt_cut()      ;return
        if K["dd_cut1"].true():         self.evt_cut()      ;return
        if K["dd_sel_all0"].true():     self.evt_sel_all()  ;return
        if K["dd_sel_all1"].true():     self.evt_sel_all()  ;return
        if K["dd_sel0"].true():         self.evt_sel(evt)   ;return
        if K["dd_sel1"].true():         self.evt_sel(evt)   ;return
        if K["dd_tab0"].true():         self.evt_tab()      ;return
        if K["dd_tab1"].true():         self.evt_tab()      ;return
        if K["dd_scroll_up0"].true() or K["dd_scroll_up1"].true():
            self.evt_scroll(-P.scroll_fac)
            return
        if K["dd_scroll_down0"].true() or K["dd_scroll_down1"].true():
            self.evt_scroll(P.scroll_fac)
            return

        if evt.value == 'PRESS':
            self.thread_cursor_reset()
            if evt.unicode != '':   self.set_cursor_tx(evt.unicode)
#
            m.redraw()

    def I_modal_bar_end(self):
#
        del m.head_modal[-1]
        self.U_modal = self.I_modal_main
        m.init_wait_release()
    def I_modal_bar_x(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.I_modal_bar_end()
                return
        m.dx = m.mou_x - evt.mouse_x
        self.pan_fil_x()
        m.get_mou(evt)  ;m.redraw()
    def I_modal_bar(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.I_modal_bar_end()
                return
        m.dx    = m.mou_x - evt.mouse_x
        dy      = evt.mouse_y - m.mou_y

        self.bu_scrollY.bar_mov(dy)
        rate    = (self.tm_T - self.bu_scrollY.bar_rim.T) / self.tm_h
        new_y   = self.fil_limT + round(rate * self.tm_d)
        m.dy    = new_y - self.fil_y
        self.pan_fil_x()
        self.pan_fil_y()
        m.get_mou(evt)
        m.redraw()

    def I_modal_pan_fil_end(self):
#
        del m.head_modal[-1]
        self.U_modal = self.I_modal_main
        m.U_end_pan(self)
        m.init_wait_release()
    def I_modal_pan_fil_x(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.I_modal_pan_fil_end()
                return
        m.U_pan(evt)
        new_x = self.fil_x + m.dx

        dif_x = new_x - self.fil_limL
        if dif_x > 0:   new_x -= dif_x
        else:
            dif_x = self.fil_limR - new_x
            if dif_x > 0:   new_x += dif_x
        self.fil_x = new_x

        m.loop_mou(evt)  ;m.redraw()
    def I_modal_pan_fil(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.I_modal_pan_fil_end()
                return
        m.U_pan(evt)

        self.pan_fil_x()
        self.pan_fil_y()

        self.bu_scrollY.upd_scroll(self.fil_limT, self.fil_limB, self.fil_y, self.amt_10)
        m.loop_mou(evt)
        m.redraw()
    def pan_fil_x(self):
        new_x = self.fil_x + m.dx
        dif_x = new_x - self.fil_limL
        if dif_x > 0:   new_x -= dif_x
        else:
            dif_x = self.fil_limR - new_x
            if dif_x > 0:   new_x += dif_x
        self.fil_x = new_x
    def pan_fil_y(self):
        li      = self.li
        new_y   = self.fil_y + m.dy
        attr    = self.fil_attr
        if m.dy < 0:
            dif_y = self.fil_limT - new_y
            if dif_y > 0:
                new_y += dif_y
                dy = new_y - self.fil_y
                self.fil_y = new_y
                for e in li:   e.y += dy
            else:
                self.fil_y += m.dy
                for e in li:   e.y += m.dy

            e = li[0]
            dif_y = self.fil_limT - e.y
            if dif_y > 0:
                _16 = F[16]
                n = min(int(dif_y // _16 + 1), e.size - self.fil.ind0)

                fil_li  = self.fil.li_full
                maxW    = 0
                i       = e.size - n
                y       = self.fil_y - (i - self.fil.ind0) * _16

                blf_size(font_0, F[9])
                for e in li:
                    e.y     = y
                    e.size  = i
                    e.text  = getattr(fil_li[i], attr)

                    d = e.R_dimen()
                    if d > maxW:    maxW = d

                    y -= _16
                    i += 1
                self.fil_limR = min(self.fil_limL, self.fil_limL - maxW + self.fil_wi - F[8])
        else:
            dif_y = new_y - self.fil_limB
            if dif_y > 0:
                new_y -= dif_y
                dy = new_y - self.fil_y
                self.fil_y = new_y
                for e in li:   e.y += dy
            else:
                self.fil_y += m.dy
                for e in li:   e.y += m.dy

            e = li[-1]
            dif_y = e.y - self.li9_y
            if dif_y > 0:
                _16 = F[16]
                n = min(int(dif_y // _16 + 1), self.fil.ind1 - e.size)

                fil_li  = self.fil.li_full
                maxW    = 0
                i       = e.size + n
                y       = self.fil_y - (i - self.fil.ind0) * _16

                blf_size(font_0, F[9])
                for e in reversed(li):
                    e.y     = y
                    e.size  = i
                    e.text  = getattr(fil_li[i], attr)

                    d = e.R_dimen()
                    if d > maxW:    maxW = d

                    y += _16
                    i -= 1
                self.fil_limR = min(self.fil_limL, self.fil_limL - maxW + self.fil_wi - F[8])

        self.actbox.upd(li[0].size, li[-1].size)

    def I_modal_pan_end(self):
#
        del m.head_modal[-1]
        self.U_modal = self.I_modal_main
        m.U_end_pan(self)
        m.init_wait_release()
    def I_modal_pan(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.I_modal_pan_end()
                return
        m.U_pan(evt)
        new_x = self.da["tx"].x + m.dx
        if new_x > self.tx_limL:    new_x = self.tx_limL
        elif new_x < self.tx_limR:  new_x = self.tx_limR
        self.da["tx"].x = new_x
        self.upd_highlight()
        m.loop_mou(evt)
        m.redraw()

    def auto_pan(self, evt): #calc lim
        dif = self.th_auto_L - evt.mouse_region_x
        if dif > 0:
            tx = self.da["tx"]
            new_x = min(tx.x + dif, self.tx_limL)
            if new_x != tx.x:
                dx = new_x - tx.x
                tx.x = new_x
                self.bo["highlight"].dx_upd(dx)
                self.bo_cursor.dx_upd(dx)
            return
        dif = self.th_auto_R - evt.mouse_region_x
        if dif < 0:
            tx = self.da["tx"]
            new_x = max(tx.x + dif, self.tx_limR)
            if new_x != tx.x:
                dx = new_x - tx.x
                tx.x = new_x
                self.bo["highlight"].dx_upd(dx)
                self.bo_cursor.dx_upd(dx)

    def I_modal_box_end(self, evt):
#
        if self.bo["tx"].inbox(evt) == False: m.M.set_mou_ic('DEFAULT')
        del m.head_modal[-1]
        self.U_modal = self.I_modal_main
        m.init_wait_release()
    def I_modal_box(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.I_modal_box_end(evt)
                return
        blf_size(font_0, F[9])
        i = self.da["tx"].R_ind(evt.mouse_region_x)
        if i != self.i1:    self.set_highlight(self.i0, i)

        self.auto_pan(evt)
        m.redraw()
# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        bo = self.bo
        BLEND()
        bo["shade"].draw()
        bo["bg"].bind_draw()                ;bo["tx"].bind_draw()
        bo["fil"].bind_draw()

        self.bu_scrollY.U_draw()

        self.sci_tx.ENABLE()
        bo["highlight"].bind_draw()         ;self.U_draw_cursor()

        blf_size(font_0, F[9])
        self.da["tx"].set_color()           ;self.da["tx"].draw_pos()

        self.sci_fil.use()
        BLEND()
        self.actbox.bind_draw()
        li  = self.li
        x   = self.fil_x
        blf_color(font_0, *P.color_font)
        for i in self.draw_ot:  li[i].draw_pos_by_x(x)
        blf_color(font_0, *P.color_font_fo)
        for i in self.draw_act: li[i].draw_pos_by_x(x)

        self.sci_fil.DISABLE()

    def I_draw_cursor(self):    self.bo_cursor.bind_draw()

    def I_draw_simple(self):
        bo = self.bo
        BLEND()
        bo["bg"].bind_draw()                ;bo["tx"].bind_draw()

        self.sci_tx.ENABLE()
        bo["highlight"].bind_draw()         ;self.U_draw_cursor()

        blf_size(font_0, F[9])
        self.da["tx"].set_color()           ;self.da["tx"].draw_pos()
        self.sci_tx.DISABLE()
# ▅▅▅  THREAD                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_thread_cursor(self):
        self.U_sw_cursor()
        m.redraw()
        return self.cursor_time
    def I_thread_tx_copy(self):
        self.bo["highlight"].color = P.color_tx_sel
        m.redraw()

    def I_sw_cursor_on(self):
        self.U_sw_cursor = self.I_sw_cursor_off
        self.U_draw_cursor = self.I_draw_cursor

    def I_sw_cursor_off(self):
        self.U_sw_cursor = self.I_sw_cursor_on
        self.U_draw_cursor = N
    #
    #
class DDTXMIX(DDTX):
    __slots__ = ()


class DDVAL(DDTX):
    __slots__ = (
        'ty',
        'calc',
        'oo',
        'RET',
        'hard_min',
        'hard_max',
        'is_int',
        'multi_edit',
        'local_undo',
        'unit',
    )
    def __init__(self, BU, ty, end_fn=None, multi_edit=None, local_undo=None, override_ty=None):
#
        _1  = F[1]
        u   = P.scale[0]

        self.w  = BU
        self.ty = ty
        tm = m.tm
        tm["is_dd_confirm"] = False
        tm["bu"] = BU
        if hasattr(BU, 'act_ind'):
            act_ind = BU.act_ind
            w_rim = BU.rim[act_ind]
            w_da = BU.da[act_ind]
        else:
            w_rim = BU.rim
            w_da = BU.da

        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.U_draw_cursor  = self.I_draw_cursor
        self.U_sw_cursor    = self.I_sw_cursor_on
        self.cursor_time    = P.cursor_flash_rate
        self.end_fn         = end_fn
        self.multi_edit     = multi_edit
        self.local_undo     = local_undo

        bo_cursor           = BOX(P.color_tx_cursor)
        self.bo_cursor      = bo_cursor
        bo = {
            "shade":        m.SHADE(P.dd_shade_color) if P.win_shade_on else m.BOX_FAKE(),
            "bg":           BOX(P.color_ddmenu),
            "tx":           BOX(P.color_bu_3_on),
            "fil":          BOX(P.color_filter),
            "oo":           BOX(P.color_calc_bu),
            "highlight":    BOX(P.color_tx_sel),
        }
        self.bo = bo
        unit_sys = getattr(BU, "unit", None)
        self.unit = unit_sys
        bu_value = w_da.name
        if unit_sys is None or unit_sys == 0: pass
        elif unit_sys == 1:
            bu_value /= m.unit_length_fac
        elif unit_sys == 2:
            bu_value /= m.unit_length_fac2
        elif unit_sys == 3:
            bu_value /= m.unit_length_fac3

        da = {
            "tx":           BLF(P.color_font, m.R_str_by_float(bu_value), x = w_rim.L + F[5.1], y = w_da.y),
            "real_base":    BLF(None, "Click here to calculate", None),
            "imag_base":    BLF(None, "", None),
            "real_pow":     BLF(None, "", None),
            "imag_pow":     BLF(None, "", None),
            "i":            BLF(None, "", None),
            "conv":         BLF(P.color_font_darker, f"To {ty} :", None),
            "ans":          BLF(None, "", None),
        }
        self.da     = da
        self.sci    = m.SCISSOR(0, 0, bpy.context.window.width, bpy.context.window.height)
        self.sci_tx = m.SCISSOR()

        m.admin.tb.draw_top.append(self)
        m.head_modal.append(self.run_modal)

        bo["tx"].copy_LRBT(w_rim)
        L               = bo["tx"].L - _1
        self.init_li    = N
        self.upd_fil    = N
        if unit_sys in {1, 2, 3}:
            self.calc = calc.CALC(bu_value, unit_system=m.unit_system, unit_length=m.unit_length)
        else:
            self.calc = calc.CALC(bu_value)

        if P.dd_num_type == 'SIMPLE':
            self.U_draw = self.I_draw_simple
            B   = bo["tx"].B - _1
            T   = bo["tx"].T + _1
            R   = bo["tx"].R + _1
        else:
            self.U_draw = self.I_draw_complex

            BB  = bo["tx"].B - _1
            T   = bo["tx"].T + _1
            R   = L + 180 * u

            bo["tx"].R = R - _1
            bo_fil = bo["fil"]
            bo_fil.LRBT(bo["tx"].L, bo["tx"].R, BB - 35 * u, BB)

            x   = L + F[5]
            y   = BB - F[13]
            da["real_base"].x   = x
            da["real_base"].y   = y
            da["imag_base"].y   = y
            da["i"].y           = y
            y += F[3]
            da["real_pow"].y    = y
            da["imag_pow"].y    = y
            da["conv"].x        = x
            da["conv"].y        = y - F[19.1]
            da["ans"].x         = x + F[82]
            da["ans"].y         = da["conv"].y

            blf_size(font_0, F[9])
            BURE_FA     = bu.BURE_FA
            att         = m.R_calc_attr(ty)  if override_ty is None else override_ty
            oo          = {}
            self.oo     = oo

            for r in range(1, 13):
                n       = str(r)
                attr    = f"{att}{n}"
                oo[n]   = BURE_FA(
                    self,
                    n,
                    getattr(P, attr),
                    getattr(self, "bu_fn_" + n), base_evt=self.base_evt
                )
                oo[n].attr = attr

            bu_h = F[16]
            buL = L + F[5]
            buR = buL + F[46]
            buT = bo_fil.B - F[5]
            buB = buT - bu_h
            buL2 = buR + F[3]
            buR2 = buL2 + F[46]
            buL3 = buR2 + F[8]
            buR3 = R - F[5]
            oo["1"].LRBT(buL, buR, buB, buT)
            oo["2"].LRBT(buL2, buR2, buB, buT)
            oo["3"].LRBT(buL3, buR3, buB, buT)
            buT = buB - F[3]
            buB = buT - bu_h
            oo["4"].LRBT(buL, buR, buB, buT)
            oo["5"].LRBT(buL2, buR2, buB, buT)
            oo["6"].LRBT(buL3, buR3, buB, buT)
            buT = buB - F[3]
            buB = buT - bu_h
            oo["7"].LRBT(buL, buR, buB, buT)
            oo["8"].LRBT(buL2, buR2, buB, buT)
            oo["9"].LRBT(buL3, buR3, buB, buT)
            buT = buB - F[3]
            buB = buT - bu_h
            oo["10"].LRBT(buL, buR, buB, buT)
            oo["11"].LRBT(buL2, buR2, buB, buT)
            oo["12"].LRBT(buL3, buR3, buB, buT)
            B = oo["12"].bg.B - F[6]
            bo["oo"].LRBT(bo_fil.L, bo_fil.R, B + _1, bo_fil.B - _1)

        self.sci_tx.box_round(self.bo["tx"])
        bo["bg"].LRBT(L, R, B, T)
        if P.win_shade_on:
            bo["shade"].get_by_rim(L, R, B, T, P.dd_shade_softness, P.dd_shade_offset, u)

        bo_cursor.B         = bo["tx"].B + _1
        bo_cursor.T         = bo["tx"].T - _1
        self.bo_cursor_wi   = F[P.cursor_thickness]
        bo["highlight"].B   = bo_cursor.B + _1
        bo["highlight"].T   = bo_cursor.T - _1

        ll = len(self.da["tx"].text)
        if P.auto_sel_text:     self.set_highlight(0, ll)
        else:                   self.set_highlight(ll, ll)

        for e in self.bo.values():  e.upd()

        self.thread_cursor  = self.I_thread_cursor
        self.thread_copy    = self.I_thread_tx_copy
        self.I_init_thread_cursor()
        self.tx_limL        = self.da["tx"].x
        self.bo_tx_Rm4      = bo["tx"].R - F[4]
        self.calc_tx_lim()
        if self.tx_limL != self.tx_limR:
            self.dxi0 = bo["highlight"].L - self.da["tx"].x
            self.dxi1 = bo["highlight"].R - self.da["tx"].x
            self.da["tx"].x = self.tx_limR
            self.upd_highlight()

        self.th_auto_L  = bo["tx"].L + F[4]
        self.th_auto_R  = bo["tx"].R - F[4]

        self.get_hard_min_max(ty)
        da["conv"].name = da["conv"].R_end_x()
        m.M.set_mou_ic('TEXT' if bo["tx"].inbox(m.EVT.evt) else 'DEFAULT')
        m.init_wait_release()
        m.redraw()

    def fin(self, evt):
        del m.head_modal[-1]
        m.admin.tb.draw_top.remove(self)
        self.U_kill_thread_cursor()

        m.M.set_mou_ic('DEFAULT')
        # try:    self.w.w.U_modal(evt)
        # except: pass
        # m.init_wait_release()
        m.EVT.kill()
        m.redraw()
        if self.end_fn is not None: self.end_fn()

    def get_hard_min_max(self, ty):
        i0 = ty.find("[")
        i1 = ty.find(",", i0 + 1)
        i2 = ty.find("]", i1 + 1)
        s_min = ty[i0 + 1 : i1]
        s_max = ty[i1 + 1 : i2]

        if ty[0] == "i":
            self.is_int = True
            try:    self.hard_min = int(s_min)
            except: self.hard_min = float("-inf")
            try:    self.hard_max = int(s_max)
            except: self.hard_max = float("inf")
        else:
            self.is_int = False
            if s_min == "π":
                s_min = 3.1415926535897932384626433832795
            if s_max == "π":
                s_max = 3.1415926535897932384626433832795
            try:    self.hard_min = float(s_min)
            except: self.hard_min = float("-inf")
            try:    self.hard_max = float(s_max)
            except: self.hard_max = float("inf")
    def calc_ans(self):
#
        da = self.da
        c = self.calc
        if da["tx"].text != "":
            tx0 = da["tx"].text[0]
            if tx0 in {"#", ";"}:
                da["real_base"].text = "Comfirm To add driver" if tx0 == "#" else "Calculate in python expression"
                da["real_pow"].text = ""
                da["imag_base"].text = ""
                da["imag_pow"].text = ""
                da["i"].text = ""

                frame = bpy.context.scene.frame_current
                tx = da["tx"].text[1 :].replace("frame", str(frame))
#
                output = py_math.TR_eval(tx)
                if output is None:
                    da["ans"].text = "Evaluate fail"
                    return (tx0, None)
                else:
                    if tx0 == ";":
                        da["real_base"].text = f"{m.R_str_by_float(output)}"

                    output = min(max(self.hard_min, output), self.hard_max)
                    da["ans"].text = m.U_format_i(round(output)) if self.is_int else m.U_format_f(output)
                    return (tx0, output)

        c.calc(da["tx"].text)
#
        is_too_big = False

        if type(c.ans_tx) is tuple:
            if c.ans_tx[0][0] == 'i':
                c.ans_flo = 0
                c.ans_tx = ('0.000000', '', '+0.000000', '')
                is_too_big = True

            blf_size(font_0, F[9])
            da["real_base"].text = c.ans_tx[0]
            da["real_pow"].text = c.ans_tx[1]
            da["imag_base"].text = c.ans_tx[2]
            da["imag_pow"].text = c.ans_tx[3]
            da["i"].text = "i" if da["imag_base"].text else ""
            if da["real_pow"].text == "":
                da["imag_base"].x = da["real_base"].R_end_x() + F[2]
                da["imag_pow"].x = da["imag_base"].R_end_x() + F[2]
            else:
                da["real_pow"].x = da["real_base"].R_end_x() + F[2]
                blf_size(font_0, F[7])
                da["imag_base"].x = da["real_pow"].R_end_x() + F[2]
                blf_size(font_0, F[9])
                da["imag_pow"].x = da["imag_base"].R_end_x() + F[2]
            blf_size(font_0, F[7])
            da["i"].x = da["imag_pow"].R_end_x() + F[2]
        else:
            da["real_base"].text = c.ans_tx
            da["real_pow"].text = ""
            da["imag_base"].text = ""
            da["imag_pow"].text = ""
            da["i"].text = ""
            is_too_big = True

        ans = calc.R_sabs(c.ans_flo)
        if ans is None: da["ans"].text = ""
        else:
            ans = min(max(self.hard_min, ans), self.hard_max)
            da["ans"].text = m.U_format_i(round(ans)) if self.is_int else m.U_format_f(ans)

        m.redraw()
        if da["ans"].x < da["conv"].name:
            da["conv"].name = da["ans"].x
            da["conv"].text = ""
        if is_too_big: return None
        return ans
# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def bu_fn(self, ex):
        try:
#
            self.evt_sel_all()
            self.set_cursor_tx(ex)
            self.evt_sel_all()
            if self.calc_ans() is None:
                self.set_cursor_tx("Invalid output")
                return

            x = self.calc.ans_flo
            if type(x) is complex:
                if x.imag < 0:  self.set_cursor_tx(f"{'%f' % x.real} {'%f' % x.imag} i")
                else:           self.set_cursor_tx(f"{'%f' % x.real} +{'%f' % x.imag} i")
            else:
                self.set_cursor_tx('%f' % x)
        except:
            self.evt_sel_all()
            self.set_cursor_tx("Invalid output")
    def bu_fn_1(self):  self.bu_fn(getattr(P, self.oo["1"].attr + "ex"))
    def bu_fn_2(self):  self.bu_fn(getattr(P, self.oo["2"].attr + "ex"))
    def bu_fn_3(self):  self.bu_fn(getattr(P, self.oo["3"].attr + "ex"))
    def bu_fn_4(self):  self.bu_fn(getattr(P, self.oo["4"].attr + "ex"))
    def bu_fn_5(self):  self.bu_fn(getattr(P, self.oo["5"].attr + "ex"))
    def bu_fn_6(self):  self.bu_fn(getattr(P, self.oo["6"].attr + "ex"))
    def bu_fn_7(self):  self.bu_fn(getattr(P, self.oo["7"].attr + "ex"))
    def bu_fn_8(self):  self.bu_fn(getattr(P, self.oo["8"].attr + "ex"))
    def bu_fn_9(self):  self.bu_fn(getattr(P, self.oo["9"].attr + "ex"))
    def bu_fn_10(self):  self.bu_fn(getattr(P, self.oo["10"].attr + "ex"))
    def bu_fn_11(self):  self.bu_fn(getattr(P, self.oo["11"].attr + "ex"))
    def bu_fn_12(self):  self.bu_fn(getattr(P, self.oo["12"].attr + "ex"))
# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_modal_wait_top(self, evt):
#
        oo  = self.oo
        blf_size(font_0, F[9])
        for r in range(1, 13):
            e = oo[str(r)]
            tx = getattr(P, e.attr)
            if e.ti.text != tx:
                e.ti.text = tx
                e.LRBT(*e.rim.R_LRBT())

        self.U_modal = self.I_modal_main
        m.redraw()

    def I_modal_main(self, evt):
        if self.bo["bg"].inbox(evt) == False:
            if K["dd_cancel0"].true():  self.fin(evt)   ;return
            if K["dd_cancel1"].true():  self.fin(evt)   ;return
            if K["dd_confirm0"].true(): self.evt_confirm(evt)  ;return
            if K["dd_confirm1"].true(): self.evt_confirm(evt)  ;return
            if K["dd_sel0"].true():     self.evt_confirm(evt)  ;return
            if K["dd_sel1"].true():     self.evt_confirm(evt)  ;return
            self.unicode_evt(evt)
            return

        if self.bo["tx"].inbox(evt):
            m.M.set_mou_ic('TEXT')
            self.U_modal = self.I_modal_tx
            self.I_modal_tx(evt)
            return

        if self.bo["fil"].inbox(evt):
            if K["dd_sel0"].true(): self.calc_ans() ;return
            if K["dd_sel1"].true(): self.calc_ans() ;return

        if self.base_evt(evt):  return
        if K["dd_confirm0"].true(): self.evt_confirm(evt)  ;return
        if K["dd_confirm1"].true(): self.evt_confirm(evt)  ;return
        self.unicode_evt(evt)

        for e in self.oo.values():
            if e.rim.inbox(evt):    e.inside(evt)   ;return

    def evt_confirm(self, evt):
        m.tm["is_dd_confirm"] = True
        ans = self.calc_ans()
        v = None
        if type(ans) is tuple:
#
            if ans[0] == "#":
                try:    self.w.driver_add(self.da["tx"].text[1 :])
                except: pass
            elif ans[1] is not None:    v = ans[1]
        elif ans is not None:
#
            v = ans
            u = self.unit
            if u is None or u == 0: pass
            elif u == 1:    v *= m.unit_length_fac
            elif u == 2:    v *= m.unit_length_fac2
            elif u == 3:    v *= m.unit_length_fac3
        else:
            pass
#

        m.tm["dd_confirm_value"] = v
        if v is not None:
            if hasattr(self.w, "set"):
                if hasattr(self.w, 'act_ind'):
                    if self.multi_edit is True:
                        self.fin(evt)
                        return
                    else:
                        self.w.set(v, ind=self.w.act_ind)
                else:
                    self.w.set(v)
                m.refresh()
            elif self.multi_edit is None:
#
                self.w.bpy_setter(v)
                self.w.setter()
            else:
                if self.multi_edit == "custom":
#
                    bu_range = m.tm["bu_range"]
                    self.w.bpy_setter([v] * (bu_range[1] - bu_range[0]), bu_range)
                    self.fin(evt)
                    return

#
                self.w.bpy_setter(v, False)
                self.w.setter()
                for e in self.multi_edit:
                    e.bpy_setter(v, False)
                    e.setter()

                if self.local_undo is None: m.undo_push()
                else: self.local_undo()
        else:
            m.admin.report({'INFO'}, "Invalid Input")

        self.fin(evt)
    def evt_tab(self): pass
    def base_evt(self, evt):
        if K["rm0"].true() or K["rm1"].true():
            for e in self.oo.values():
                if e.rim.inbox(evt):
                    e.off()
                    self.U_modal = self.I_modal_main
                    def rm_edit_name():
#
                        from . import tex
                        self.U_modal = self.I_modal_wait_top
                        self.U_kill_thread_cursor()
                        tex.TEX_EDIT(self, m.EVT.evt, (P, e.attr),
                            f"Calculator {self.ty} button {e.name} (Name)")
                    def rm_edit_exp():
                        att = e.attr + "ex"
#
                        from . import tex
                        self.U_modal = self.I_modal_wait_top
                        self.U_kill_thread_cursor()
                        tex.TEX_EDIT(self, m.EVT.evt, (P, att),
                            f"Calculator {self.ty} button {e.name} (Expression)")
                    def rm_reset_name():
#
                        from . import tex
                        self.U_modal = self.I_modal_wait_top
                        self.U_kill_thread_cursor()
                        tex.TEX_EDIT(self, m.EVT.evt, (P, e.attr),
                            f"Calculator {self.ty} button {e.name} (Name)",
                            tx = m.R_pref_default(e.attr))
                    def rm_reset_exp():
#
                        att = e.attr + "ex"
                        from . import tex
                        self.U_modal = self.I_modal_wait_top
                        self.U_kill_thread_cursor()
                        tex.TEX_EDIT(self, m.EVT.evt, (P, att),
                            f"Calculator {self.ty} button {e.name} (Expression)",
                            tx = m.R_pref_default(att))
                    rm.RM_HEAD(self, evt,
                        (
                            ("Edit Name", rm_edit_name),
                            ("Edit Expression", rm_edit_exp),
                            ("Reset Name", rm_reset_name),
                            ("Reset Expression", rm_reset_exp)
                        ),
                        info = f"Target: Calculator button {e.name}")
                    return True

        if K["dd_cancel0"].true():  self.fin(evt)   ;return True
        if K["dd_cancel1"].true():  self.fin(evt)   ;return True
        return False
# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw_complex(self):
        bo = self.bo
        da = self.da
        BLEND()
        bo["shade"].draw()
        bo["bg"].bind_draw()                ;bo["tx"].bind_draw()
        bo["fil"].bind_draw()               ;bo["oo"].bind_draw()

        m.bind_color_bu_1_rim()
        for e in self.oo.values():  e.draw_rim()
        for e in self.oo.values():  e.draw_bg()

        self.sci_tx.ENABLE()
        bo["highlight"].bind_draw()         ;self.U_draw_cursor()

        blf_size(font_0, F[9])
        da["tx"].set_color()                ;da["tx"].draw_pos()
        self.sci_tx.DISABLE()

        for e in self.oo.values():  e.draw_ti()

        da["real_base"].draw_pos()          ;da["imag_base"].draw_pos()
        da["i"].draw_pos()                  ;da["conv"].set_color()
        da["conv"].draw_pos()               ;da["tx"].set_color()
        da["ans"].draw_pos()

        blf_size(font_0, F[7])
        da["real_pow"].draw_pos()           ;da["imag_pow"].draw_pos()


class DDTX_FN(DDTX):
    __slots__ = 'confirm_fn', 'fin_D1'
    def __init__(self,
        evt,
        name,
        fil,
        LRBT        = None,
        confirm_fn  = None,
        tx_clear    = None,
        fin_D1      = None,
    ):
        self.confirm_fn = confirm_fn

        if LRBT is None:
            cx      = evt.mouse_region_x
            B       = evt.mouse_region_y - F[8]
            w2      = F[150]
            LRBT    = (cx - w2, cx + w2, B, B + F[16])

        super().__init__({"name": name, "LRBT": LRBT}, fil, tx_clear = tx_clear)

        if not self.bo["tx"].inbox(evt):    m.M.set_mou_ic('DEFAULT')

        self.fin_D1 = fin_D1

    def fin(self, *e):
#
        del m.head_modal[-1]
        m.admin.tb.draw_top.remove(self)
        if self.fil is not None:    self.fil.clear()
        self.U_kill_thread_cursor()

        m.M.set_mou_ic('DEFAULT')
        # m.init_wait_release()
        m.EVT.kill()
        m.redraw()

        if self.fin_D1 is not None: self.fin_D1()

    def evt_confirm(self, *e):
#
        self.confirm_fn(self.da["tx"].text)
        self.fin()

class DDTX_RENAME(DDTX):
    __slots__ = (
        'attr',
        'confirm_upd',
        'oo',
        'RET',
        'ti_target_wi',
        'sci_target',
        'read_only',
        'tm_limL',
        'tm_limR',
        'full_path_head',
    )
    def __init__(self,
        evt,
        name,
        attr,
        fil             = None,
        LRBT            = None,
        target          = "",
        confirm_upd     = None,
        tx_clear        = None,
        read_only       = False,
        full_path_head  = "bpy.data.",
    ):
        self.attr           = attr
        self.confirm_upd    = N  if confirm_upd is None else confirm_upd
        self.read_only      = read_only
        self.full_path_head = full_path_head

        if LRBT is None:
            cx      = evt.mouse_region_x
            B       = evt.mouse_region_y - F[8]
            w2      = F[150]
            LRBT    = (cx - w2, cx + w2, B, B + F[16])

        super().__init__({"name": name, "LRBT": LRBT}, fil, tx_clear = tx_clear)

        bo      = self.bo
        ti      = self.ti
        bo_bg   = bo["bg"]

        bo_bg.T += F[21]
        T = bo_bg.B
        ti["ti"]        = BLF(P.color_font, "Read-only" if read_only else "Rename",
            F[12], bo_bg.L + F[6], bo_bg.T - F[15])
        ti["target"]    = BLF(text=f"Target:  {target}")
        BURE            = bu.BURE
        base_evt        = self.base_evt
        oo = {
            "copy": BURE(
                self,
                "copy",
                "Copy path",
                self.bu_fn_copy_path,
                base_evt    = base_evt),
            "copy_full": BURE(
                self,
                "copy_full",
                "Copy full path",
                self.bu_fn_copy_path_full,
                base_evt    = base_evt),
            "confirm": BURE(
                self,
                "confirm",
                "Confirm",
                self.evt_confirm,
                base_evt    = base_evt),
            "cancel": BURE(
                self,
                "cancel",
                "Cancel",
                self.fin,
                base_evt    = base_evt),
        }
        self.oo = oo
        if fil == None or P.filter_algorithm == 'DISABLE':
            L = bo["tx"].L - F[1] + F[2]
            T = bo["tx"].B - F[2]
        else:
            L = bo["fil"].L
            T = bo["fil"].B - F[2]
        R = bo_bg.R - F[2]
        bo["bu_bg"] = BOX(P.color_bu_bg, L, R, T - F[5] - F[5] - F[16], T)

        T   = bo["bu_bg"].B - F[2]
        bo["target"] = BOX(bo["tx"].color, L, R, T - F[16], T)
        ti["target"].LB(bo["target"], F[5], F[5])
        bo_bg.B = bo["target"].B - F[2]
        blf_size(font_0, F[9])
        self.ti_target_wi = round(ti["target"].R_dimen()) + 1
        T = bo["bu_bg"].T - F[5]
        B = T - F[16]
        bu_wi = (bo["bu_bg"].R_w() - F[5] * 5) // 4
        L = bo["bu_bg"].L + F[5]
        R = L + bu_wi
        oo["copy"].LRBT(L, R, B, T)
        L = R + F[5]
        R = L + bu_wi
        oo["copy_full"].LRBT(L, R, B, T)
        L = R + F[5]
        R = L + bu_wi
        oo["confirm"].LRBT(L, R, B, T)
        L = R + F[5]
        oo["cancel"].LRBT(L, bo["bu_bg"].R - F[5], B, T)

        bo["target"].upd()  ;bo_bg.upd()  ;bo["bu_bg"].upd()
        self.sci_target = m.SCISSOR()
        self.sci_target.box(bo["target"])

        if read_only:   oo["confirm"].disable()

        if P.win_shade_on:
            bo["shade"] = m.SHADE(P.win_shade_color)
            bo["shade"].get_by_rim(
                bo_bg.L, bo_bg.R, bo_bg.B, bo_bg.T,
                P.win_shade_softness, P.win_shade_offset, P.scale[0]
            )
            bo["shade"].upd()
        else:   bo["shade"] = m.BOX_FAKE()

        e   = bo["bg"]
        bo["rim"]   = m.RIM(P.color_win_rim)
        bo["rim"].LRBTd_rev(e.L, e.R, e.B, e.T, F[1])
        bo["rim"].upd()

    def fin(self, *e):
#
        del m.head_modal[-1]
        m.admin.tb.draw_top.remove(self)
        self.U_kill_thread_cursor()

        m.M.set_mou_ic('DEFAULT')
        m.init_wait_release()
        m.redraw()

    def I_modal_main(self, evt):
        if self.bo["bg"].inbox(evt) == False:
            if K["dd_sel0"].true(): self.evt_confirm()  ;return
            if K["dd_sel1"].true(): self.evt_confirm()  ;return

        bu_RET = self.bu_scrollY.evt(evt)
        if bu_RET is not None:
            if K["dd_bar0"].true():
                self.key_end = K["dd_bar_E0"]
                if bu_RET:  self.to_modal_bar_bu(evt)
                else:       self.to_modal_bar_bg(evt)
                return
            if K["dd_bar1"].true():
                self.key_end = K["dd_bar_E1"]
                if bu_RET:  self.to_modal_bar_bu(evt)
                else:       self.to_modal_bar_bg(evt)
                return

        if self.bo["tx"].inbox(evt):
            self.clear_draw_act()
            m.M.set_mou_ic('TEXT')
            self.U_modal = self.I_modal_tx
            self.I_modal_tx(evt)
            return

        if self.bo["fil"].inbox(evt):
            self.upd_draw_act_by_y(evt.mouse_region_y)
            if K["dd_pan0"].true():
                self.key_end = K["dd_pan_E0"]  ;self.to_modal_pan_fil(evt)  ;return
            if K["dd_pan1"].true():
                self.key_end = K["dd_pan_E1"]  ;self.to_modal_pan_fil(evt)  ;return
            if K["dd_sel0"].true():     self.evt_fil_sel(evt)  ;return
            if K["dd_sel1"].true():     self.evt_fil_sel(evt)  ;return
        else:   self.clear_draw_act()

        if self.bo["target"].inbox(evt):
            if K["dd_pan0"].true():
                self.key_end = K["dd_pan_E0"]  ;self.to_modal_pan_target(evt)  ;return
            if K["dd_pan1"].true():
                self.key_end = K["dd_pan_E1"]  ;self.to_modal_pan_target(evt)  ;return

        if K["dd_cancel0"].true() or K["dd_cancel1"].true():
            self.fin()
            if self.fil is not None:    self.fil.clear()
            return
        if K["dd_confirm0"].true() or K["dd_confirm1"].true():
            self.evt_confirm()
            return
        if K["ti_mov0"].true():
            if evt.mouse_region_y > self.bo["tx"].T:
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
                return
        if K["ti_mov1"].true():
            if evt.mouse_region_y > self.bo["tx"].T:
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
                return
        if self.oo["copy"].rim.in_BT(evt):
            for e in self.oo.values():
                if e.rim.in_LR(evt):    e.inside(evt)  ;return
        self.unicode_evt(evt)
    def base_evt(self, evt):
        if K["dd_cancel0"].true() or K["dd_cancel1"].true():
            self.fin()
            if self.fil is not None:    self.fil.clear()
            return True
        if K["dd_confirm0"].true() or K["dd_confirm1"].true():
            self.evt_confirm()
            return True
        return False

    def evt_confirm(self, *e):
#
        self.fin()
        name    = self.da["tx"].text
        def fn_yes():
            if callable(self.attr):     self.attr(name)
            else:
                attr0   = self.attr[0]
                attr1   = self.attr[1]
                setattr(attr0, attr1, name)
                self.confirm_upd()
                m.undo_str = f'[Modifier Editor] Object.{attr1} = "{name}"'
                m.undo_push()

            if self.fil is not None:    self.fil.clear()
        def fn_no():
            if self.fil is not None:    self.fil.clear()

        if name == self.tx_org or self.read_only:
            fn_no()
            return
        if P.confirm_rename:
            attr = self.fil_attr
            if any(getattr(e, attr) == name for e in self.fil.li_full):
                evt = m.EVT.evt
                win_mess.MESS_BOOL(
                    evt.mouse_region_x,
                    evt.mouse_region_y,
                    "The name already exist, are you sure you want to change it?",
                    fn_yes,
                    fn_no
                )
                return
        fn_yes()
    def bu_fn_copy_path(self):
#
        bpy.context.window_manager.clipboard = self.ti["target"].text[9 :]
    def bu_fn_copy_path_full(self):
#
        bpy.context.window_manager.clipboard = f'{self.full_path_head}{self.ti["target"].text[9 :]}'

    def to_modal_mov(self, evt):
#
        self.key_end.true()
        m.head_modal.append(self.I_modal_mov)
        self.U_modal = N
        m.get_mou(evt)
    def protect_pos(self):
        new_x, new_y = m.IR_protect_pos(self.bo["bg"], F[-1])
        dx, dy = new_x - self.bo["bg"].L, new_y - self.bo["bg"].T
        if dx == 0 and dy == 0: return
        self.dxy_upd(dx, dy)
    def modal_mov_end(self):
#
        del m.head_modal[-1]
        self.protect_pos()

        self.bu_scrollY.mov_end_upd()
        bo  = self.bo

        self.th_auto_L  = bo["tx"].L + F[4]
        self.th_auto_R  = bo["tx"].R - F[4]
        self.bo_tx_Rm4  = bo["tx"].R - F[4]
        self.calc_tx_lim()

        self.li9_y      = self.fil_limT - 9 * F[16]
        self.U_modal    = self.I_modal_main
        m.EVT.kill()
        m.EVT.U_ENABLE_evt()
        m.redraw()
    def I_modal_mov(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_mov_end()
                return
        m.dx = evt.mouse_x - m.mou_x
        m.dy = evt.mouse_y - m.mou_y
        self.dxy_upd(m.dx, m.dy)
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()

    def to_modal_pan_target(self, evt):
#
        m.head_modal.append(self.I_modal_pan_target)
        self.key_end.true()

        self.tm_limL = self.bo["target"].L + F[5]
        self.tm_limR = self.tm_limL - max(0, self.ti_target_wi - self.fil_wi)

        m.U_pan_cursor(self, evt)
        m.get_loop_mou_info()
        m.get_mou(evt)
    def I_modal_pan_target(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.I_modal_pan_end()
                return
        m.U_pan(evt)
        new_x = self.ti["target"].x + m.dx
        if new_x > self.tm_limL:    new_x = self.tm_limL
        elif new_x < self.tm_limR:  new_x = self.tm_limR
        self.ti["target"].x = new_x

        m.loop_mou(evt)  ;m.redraw()

    def dxy_upd(self, x, y):
        self.bo_cursor.dxy_upd(x, y)
        for e in self.li:           e.y += y
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)
        self.sci_tx.dxy(x, y)
        self.sci_fil.dxy(x, y)
        self.sci_target.dxy(x, y)
        self.bu_scrollY.dxy_upd(x, y)
        self.fil_x += x
        self.fil_y += y
        self.fil_limL += x
        self.fil_limR += x
        self.fil_limB += y
        self.fil_limT += y
        self.tx_limL += x
        if self.fil is not None:    self.actbox.upd(self.fil.ind0, self.fil.ind1)

    def I_draw(self):
        bo  = self.bo
        ti  = self.ti
        oo_values = self.oo.values()

        BLEND()
        bo["rim"].bind_draw()

        super().I_draw()

        BLEND()
        bo["target"].bind_draw()
        bo["bu_bg"].bind_draw()
        ti["ti"].set_draw()
        blf_size(font_0, F[9])
        blf_color(font_0, *P.color_font_darker)

        self.sci_target.ENABLE()
        ti["target"].draw_pos()
        self.sci_target.DISABLE()

        BLEND()
        m.bind_color_bu_1_rim()
        for e in oo_values:     e.draw_rim()
        for e in oo_values:     e.draw_bg()
        for e in oo_values:     e.draw_ti()

    def I_draw_simple(self):
        bo  = self.bo
        ti  = self.ti
        oo  = self.oo

        BLEND()
        bo["rim"].bind_draw()

        super().I_draw_simple()

        BLEND()
        bo["target"].bind_draw()
        bo["bu_bg"].bind_draw()
        ti["ti"].set_draw()
        blf_size(font_0, F[9])
        blf_color(font_0, *P.color_font_darker)

        self.sci_target.ENABLE()
        ti["target"].draw_pos()
        self.sci_target.DISABLE()

        BLEND()
        m.bind_color_bu_1_rim()
        for e in oo.values():   e.draw_rim()
        for e in oo.values():   e.draw_bg()
        for e in oo.values():   e.draw_ti()
        #

class DD_COLOR:
    __slots__ = (
        'w',
        'RET',
        'rna',
        'color',
        'color_org',
        'oo',
        'bo',
        'ti',
        'U_modal',
        'default_modal',
        'U_draw',
        'picker_wi',
        'HSB',
        'last_fo',
        'key_end',
        'key_slow',
        'key_fast',
        'qe_unit_slow',
        'qe_unit_fast',
        'tm_x',
        'tm_y',
        'tm_L',
        'tm_R',
        'tm_B',
        'tm_T',
        'end_fn',
        'space',
        'R_true_color',
        'true_color',
        'L_rgb_to',
        'is_cursor_LR',
        'is_dd_confirm',
    )
    #
    def fin(self):
#
        m.W_D.remove(self)
        m.W_M.remove(self)

        m.M.set_mou_ic('DEFAULT')
        m.EVT.kill()
        m.redraw()
        self.end_fn()
        #
    def __init__(self, w, rna, end_fn=None):
        _1  = F[1]
        u   = P.scale[0]

        self.w = w
        self.rna = rna
        color = w.get()
        self.color          = color
        self.color_org      = [e for e in color]
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.U_draw         = self.I_draw
        self.HSB            = HSB()
        self.last_fo        = None
        self.end_fn         = end_fn
        space               = w.space
        self.space          = space
        self.true_color     = [0, 0, 0]
        self.is_cursor_LR   = False
        self.is_dd_confirm  = False
        self.RET            = {'RUNNING_MODAL'}

        m.W_D.append(self)
        m.W_M.append(self)
        m.redraw()

        bo = {
            # /* 0dd_COLOR_bo
            "shade":        None,
            "rim":          m.RIM(P.color_win_rim),
            "bg":           BOX(P.color_picker_bg),
            "bg_hue":       BOX(P.color_picker_bg_hue),
            "bo_0":         m.BOX_C() if space == "GLSL-C" else BOX(),
            "bo_1":         m.BOX_C() if space == "GLSL-C" else BOX(),
            "bg_black":     BOX(color_black),
            "bg_white":     BOX(color_white),
            "picker_H0":    m.PICKER_H0(),
            "picker_H1":    m.PICKER_H1(),
            "bu_H0":        m.RIM(color_white),
            "bu_H1_0":      BOX(P.color_picker_bu),
            "bu_H1_1":      BOX(),
            # */
        }
        self.bo = bo
        ti = {
            # /* 0dd_COLOR_ti
            "ti":           BLF(text=f"Color Space :  {space}"),
            "hex":          BLF(text="Gamma Corrected Hex"),
            "info":         BLF(),
            # */
        }
        self.ti = ti
        oo = {
            # /* 0dd_COLOR_oo
            "rgba": VAL_COLOR(self, rna, color, w.get, w.set),
            # */
        }
        self.oo = oo

        if len(color) == 4:
            w_bo = w.bo
            e = w_bo[0]
            bo["bg_black"].LRBT_upd(e.L, e.R, e.B, e.T)
            e = w_bo[1]
            bo["bg_white"].LRBT_upd(e.L, e.R, e.B, e.T)
            e = w_bo[2]
            bo["bo_0"].LRBT_upd(e.L, e.R, e.B, e.T)
            e = w_bo[3]
            bo["bo_1"].LRBT_upd(e.L, e.R, e.B, e.T)
        else:
            TODO

        w_rim = w.rim
        R = w_rim.R + _1
        T = w_rim.T + _1

        picker_wi = round(213 * u)
        self.picker_wi = picker_wi
        d = F[2]
        d2 = F[10]
        R0 = R - d
        R1 = R0 - d2
        L1 = R1 - F[16]
        R2 = L1 - F[4]
        L2 = R2 - picker_wi
        L0 = L2 - d2
        L = L0 - d

        blf_size(font_0, F[8])
        oo["rgba"].get_bo(L0, R0, bo["bo_0"].B - F[3])
        T0 = oo["rgba"].rim.B - d
        T1 = T0 - d2
        B1 = T1 - picker_wi
        B0 = B1 - d2
        B = B0 - d

        bo["bg_hue"].LRBT_upd(L0, R0, B0, T0)
        bo["picker_H1"].LRBT_upd(L1, R1, B1, T1)
        bo["picker_H0"].LRBT_upd(L2, R2, B1, T1)
        if space == "GLSL-C":
            self.R_true_color = self.IR_true_color_GLSL_C
            self.L_rgb_to = L_rgb_to_glc
        elif space == "GLSL-B":
            self.R_true_color = self.IR_true_color_GLSL_B
            self.L_rgb_to = L_rgb_to_glb
        else:
            self.R_true_color = self.IR_hex_DEFAULT

        self.upd_by_rgb()

        bo["bg"].LRBT_upd(L, R, B, T)
        L -= _1
        R += _1
        B -= _1
        T += _1
        bo["rim"].LRBTd_upd(L, R, B, T, _1)

        ti["ti"].xy(L + F[7], T - F[14])
        e = oo["rgba"].oo_hex.sub_ti
        ti["hex"].xy(e.x + F[13], e.y + F[16])
        ti["info"].xy(e.x + F[110] + F[22], e.y - d)

        if P.win_shade_on:
            e = m.SHADE(P.dd_shade_color)
            e.get_by_rim(L, R, B, T, P.dd_shade_softness, P.dd_shade_offset, u)
            e.upd()
            bo["shade"] = e
        else:
            bo["shade"] = m.BOX_FAKE()
        #
# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd(self, x, y):
        bo = self.bo
        ti = self.ti
        oo = self.oo
        # <<< || 1forline (0dd_COLOR_bo, 8, $'bo[e].dxy_upd(x, y)\n', 'e'$, $lambda x: x.split(':', 1)[0].lstrip()$)
        bo["shade"].dxy_upd(x, y)
        bo["rim"].dxy_upd(x, y)
        bo["bg"].dxy_upd(x, y)
        bo["bg_hue"].dxy_upd(x, y)
        bo["bo_0"].dxy_upd(x, y)
        bo["bo_1"].dxy_upd(x, y)
        bo["bg_black"].dxy_upd(x, y)
        bo["bg_white"].dxy_upd(x, y)
        bo["picker_H0"].dxy_upd(x, y)
        bo["picker_H1"].dxy_upd(x, y)
        bo["bu_H0"].dxy_upd(x, y)
        bo["bu_H1_0"].dxy_upd(x, y)
        bo["bu_H1_1"].dxy_upd(x, y)
        # >>>
        # <<< || 1forline (0dd_COLOR_ti, 8, $'ti[e].dxy(x, y)\n', 'e'$, $lambda x: x.split(':', 1)[0].lstrip()$)
        ti["ti"].dxy(x, y)
        ti["hex"].dxy(x, y)
        ti["info"].dxy(x, y)
        # >>>
        # <<< || 1forline (0dd_COLOR_oo, 8, $'oo[e].dxy(x, y)\n', 'e'$, $lambda x: x.split(':', 1)[0].lstrip()$)
        oo["rgba"].dxy(x, y)
        # >>>

    def upd_H1_by_y(self, y):
        bo = self.bo
        rgba = self.oo["rgba"]
        true_h = max(min(1.0, (y - bo["picker_H1"].B) / self.picker_wi), 0.0)
        hsb = self.HSB
        hsb.h = true_h
        r, g, b = hsb.R_rgb()
        self.true_color[:] = r, g, b
        self.set_colors(round(r*255), round(g*255), round(b*255), update=False)
        rgba.float_hsv[:] = rgb_to_hsv(*self.color[:3])
        rgba.str_hex = rgb_int_to_hex(*self.R_true_color(self.color))

        _1 = F[1]
        _6 = F[6]
        wi = self.picker_wi
        L = bo["picker_H1"].R + _1
        R = L + F[8]
        y = wi * true_h + bo["picker_H1"].B
        bo["bu_H1_0"].LRBT_upd(L, R, y, y + _1)
        bo["bu_H1_1"].LRBT_upd(R, R + _1, y - _6, y + _6)

        e = bo["picker_H0"]
        e.hue = true_h
        x = wi * hsb.s + e.L
        y = wi * hsb.b + e.B
        bo["bu_H0"].LRBTd_upd(x - _6, x + _6, y - _6, y + _6, _1)
        rgba.upd_oo()
        #
    def upd_H0_by_xy(self, x, y):
        bo = self.bo
        rgba = self.oo["rgba"]
        e = bo["picker_H0"]
        hsb = self.HSB
        true_h = hsb.h
        wi = self.picker_wi
        s = min(max(0.0, (x - e.L) / wi), 1.0)
        v = min(max(0.0, (y - e.B) / wi), 1.0)
        hsb.s = s
        hsb.b = v
        r, g, b = hsv_to_rgb(true_h, s, v)
        self.set_colors(round(r*255), round(g*255), round(b*255), update=False)
        rgba.float_hsv[:] = rgb_to_hsv(*self.color[:3])
        rgba.str_hex = rgb_int_to_hex(*self.R_true_color(self.color))

        _1 = F[1]
        _6 = F[6]
        wi = self.picker_wi
        L = bo["picker_H1"].R + _1
        R = L + F[8]
        y = wi * true_h + bo["picker_H1"].B
        bo["bu_H1_0"].LRBT_upd(L, R, y, y + _1)
        bo["bu_H1_1"].LRBT_upd(R, R + _1, y - _6, y + _6)

        e = bo["picker_H0"]
        e.hue = true_h
        x = wi * hsb.s + e.L
        y = wi * hsb.b + e.B
        bo["bu_H0"].LRBTd_upd(x - _6, x + _6, y - _6, y + _6, _1)
        rgba.upd_oo()
        #
    def upd_by_rgb(self):
        rgba = self.oo["rgba"]
        color = self.color

        h, s, v = rgb_to_hsv(*color[:3])
        rgba.float_hsv[:] = h, s, v

        r, g, b = self.R_true_color(color)
#
        rgba.str_hex = rgb_int_to_hex(r, g, b)
        rgba.upd_oo()

        r /= 255
        g /= 255
        b /= 255
        self.true_color[:] = r, g, b

        # /* 0dd_upd_hue
        bo = self.bo
        hsb = self.HSB
        wi = self.picker_wi

        hsb.hsb_by_rgb(r, g, b)
        true_h = hsb.h
        y = wi * true_h + bo["picker_H1"].B

        _1 = F[1]
        _6 = F[6]
        L = bo["picker_H1"].R + _1
        R = L + F[8]
        bo["bu_H1_0"].LRBT_upd(L, R, y, y + _1)
        bo["bu_H1_1"].LRBT_upd(R, R + _1, y - _6, y + _6)

        e = bo["picker_H0"]
        e.hue = true_h
        x = wi * hsb.s + e.L
        y = wi * hsb.b + e.B
        bo["bu_H0"].LRBTd_upd(x - _6, x + _6, y - _6, y + _6, _1)
        # */
    def upd_by_hsv(self):
        rgba = self.oo["rgba"]
        color = self.color
        h, s, v = rgba.float_hsv

        color[:3] = hsv_to_rgb(h, s, v)

        r, g, b = self.R_true_color(color)
        rgba.str_hex = rgb_int_to_hex(r, g, b)
        rgba.upd_oo()

        r /= 255
        g /= 255
        b /= 255
        self.true_color[:] = r, g, b

        # <<< 1copy (0dd_upd_hue,, $$)
        bo = self.bo
        hsb = self.HSB
        wi = self.picker_wi

        hsb.hsb_by_rgb(r, g, b)
        true_h = hsb.h
        y = wi * true_h + bo["picker_H1"].B

        _1 = F[1]
        _6 = F[6]
        L = bo["picker_H1"].R + _1
        R = L + F[8]
        bo["bu_H1_0"].LRBT_upd(L, R, y, y + _1)
        bo["bu_H1_1"].LRBT_upd(R, R + _1, y - _6, y + _6)

        e = bo["picker_H0"]
        e.hue = true_h
        x = wi * hsb.s + e.L
        y = wi * hsb.b + e.B
        bo["bu_H0"].LRBTd_upd(x - _6, x + _6, y - _6, y + _6, _1)
        # >>>
    def IR_true_color_GLSL_C(self, c):
        r = glc_find(c[0])
        g = glc_find(c[1])
        b = glc_find(c[2])
        if r in D_null: r = D_null[r]
        if g in D_null: g = D_null[g]
        if b in D_null: b = D_null[b]
        return r, g, b
    def IR_true_color_GLSL_B(self, c):
        r = glb_find(c[0])
        g = glb_find(c[1])
        b = glb_find(c[2])
        if r in D_null: r = D_null[r]
        if g in D_null: g = D_null[g]
        if b in D_null: b = D_null[b]
        return r, g, b

    def is_alt(self, evt):    return evt.alt
    def is_ctrl(self, evt):   return evt.ctrl
    def is_shift(self, evt):  return evt.shift
    def is_oskey(self, evt):  return evt.oskey
    def NF(self, evt):        return False

    def set_colors(self, r, g, b, update=True):
        is_null = False
        if self.space == "GLSL-C":
            if r in D_null or g in D_null or b in D_null:   is_null = (r, g, b)
            r = L_rgb_to_glc[r]
            g = L_rgb_to_glc[g]
            b = L_rgb_to_glc[b]
        elif self.space == "GLSL-B":
            if r in D_null or g in D_null or b in D_null:   is_null = (r, g, b)
            r = L_rgb_to_glb[r]
            g = L_rgb_to_glb[g]
            b = L_rgb_to_glb[b]
        else:
            TODO

        self.color[:3] = r + 0.00001, g + 0.00001, b + 0.00001

        if update:
            if is_null:
                tx = '%02X%02X%02X' % is_null
                self.ti["info"].text = f"#{tx} invalid in {self.space}"
            else:
                self.ti["info"].text = ""
            self.upd_by_rgb()
# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def run_modal(self, evt):   self.U_modal(evt)
    def I_modal_main(self, evt):
        bo = self.bo
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        if bo["bg"].inbox_xy(x, y) is False:
            if K["dd_sel0"].true() or K["dd_sel1"].true():
                self.is_dd_confirm = True
                self.fin()
                return
            self.base_evt(evt)
            return

        rgba = self.oo["rgba"]
        if y >= rgba.rim.T:
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
            elif K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
            else:
                self.base_evt(evt)
            return

        if bo["bg_hue"].inbox_xy(x, y):
            self.U_modal = self.I_modal_hue
            bo["bg_hue"].color = P.color_picker_bg_hue_fo
            m.redraw()
            self.I_modal_hue(evt)
            return

        rgba.I_modal_main(evt)

        self.base_evt(evt)
        #
    def I_modal_hue(self, evt):
        bo = self.bo
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        if bo["bg_hue"].inbox_xy(x, y) is False:
            self.U_modal = self.I_modal_main
            bo["bg_hue"].color = P.color_picker_bg_hue
            m.redraw()
            self.I_modal_main(evt)
            return

        if K["cp_hue0"].true():
            self.key_end = K["cp_hue_E0"]
            self.to_modal_hue(evt)
            return
        if K["cp_hue1"].true():
            self.key_end = K["cp_hue_E1"]
            self.to_modal_hue(evt)
            return
        if K["cp_hue_sel0"].true() or K["cp_hue_sel1"].true():
#
            if x >= bo["picker_H1"].L - F[2]: self.upd_H1_by_y(y)
            else:   self.upd_H0_by_xy(x, y)
            # self.upd_by_hsv()
            m.redraw()
            return

        self.base_evt(evt)
    def base_evt(self, evt):
        if K["dd_cancel0"].true() or K["dd_cancel1"].true():
            self.color[:] = self.color_org
            self.fin()
            return True
        if K["dd_confirm0"].true() or K["dd_confirm1"].true():
            self.is_dd_confirm = True
            self.fin()
            return True

        return False

    def to_modal_hue(self, evt):
#
        self.key_end.true()
        m.upd_disable()
        m.redraw()
        bo = self.bo
        r = m.region_data
        m.get_loop_mou_info_region(evt, r.L, r.R, r.B, r.T)
        m.get_mou(evt)
        tm = m.tm
        tm["x"] = evt.mouse_x
        tm["y"] = evt.mouse_y
        try:    m.M.set_mou_ic(P.quick_edit_cursor)
        except: pass

        dic = m.dic_hold_key
        slow0 = K["bu_qe_slow0"].type0
        self.key_slow = getattr(self, f"is_{dic[slow0]}") if slow0 in dic else self.NF
        fast0 = K["bu_qe_fast0"].type0
        self.key_fast = getattr(self, f"is_{dic[fast0]}") if fast0 in dic else self.NF
        self.qe_unit_slow = P.quick_edit_fac_slow_hue
        self.qe_unit_fast = P.quick_edit_fac_fast_hue

        picker_H1 = bo["picker_H1"]
        self.tm_T = picker_H1.T
        self.tm_B = picker_H1.B

        if evt.mouse_region_x >= picker_H1.L - F[2]:
            m.head_modal.append(self.I_modal_hue_H1)
            self.tm_y = bo["bu_H1_0"].B
        else:
            m.head_modal.append(self.I_modal_hue_H0)
            e = bo["bu_H0"]
            self.tm_x = (e.R - e.L) // 2 + e.L
            self.tm_y = (e.T - e.B) // 2 + e.B
            self.tm_L = bo["picker_H0"].L
            self.tm_R = bo["picker_H0"].R
        #
    def modal_hue_end(self):
#
        tm = m.tm
        offset = tm["mouse_region_offset"]
        if m.head_modal[-1] == self.I_modal_hue_H0:
            e = self.bo["bu_H0"]
            tm["x"] = round((e.R - e.L) // 2 + e.L + offset[0])
            tm["y"] = round((e.T - e.B) // 2 + e.B + offset[1])
        else:
            e = self.bo["bu_H1_0"]
            tm["x"] = round(e.L + offset[0])
            tm["y"] = round(e.B + offset[1])

        m.upd_enable()
        del m.head_modal[-1]
        m.EVT.kill()
        m.I_end_pan_hide(self)
        # self.upd_by_hsv()
        m.refresh()
        #
    def I_modal_hue_H0(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_hue_end()
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_hue_end()
                return

        x_old = self.tm_x
        y_old = self.tm_y

        m.I_pan(evt)
        if self.key_slow(evt):
            self.tm_y += m.dy * self.qe_unit_slow
            self.tm_x += m.dx * self.qe_unit_slow
        elif self.key_fast(evt):
            self.tm_y += m.dy * self.qe_unit_fast
            self.tm_x += m.dx * self.qe_unit_fast
        else:
            self.tm_y += m.dy
            self.tm_x += m.dx

        self.tm_y = min(max(self.tm_B, self.tm_y), self.tm_T)
        self.tm_x = min(max(self.tm_L, self.tm_x), self.tm_R)
        self.upd_H0_by_xy(round(self.tm_x), round(self.tm_y))
        m.loop_mou(evt)
        #
    def I_modal_hue_H1(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true():
            self.modal_hue_end()
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_hue_end()
                return

        y_old = self.tm_y

        m.I_pan(evt)
        if self.key_slow(evt):      self.tm_y += m.dy * self.qe_unit_slow
        elif self.key_fast(evt):    self.tm_y += m.dy * self.qe_unit_fast
        else:                       self.tm_y += m.dy

        self.tm_y = min(max(self.tm_B, self.tm_y), self.tm_T)
        self.upd_H1_by_y(round(self.tm_y))

        m.loop_mou(evt)
        #

    def to_modal_mov(self, evt):
#
        self.key_end.true()
        m.head_modal.append(self.I_modal_mov)
        m.get_mou(evt)
    def protect_pos(self):
        new_x, new_y = m.IR_protect_pos(self.bo["bg"], F[-1])
        dx, dy = new_x - self.bo["bg"].L, new_y - self.bo["bg"].T
        if dx == 0 and dy == 0: return
        self.dxy_upd(dx, dy)
    def modal_mov_end(self):
#
        del m.head_modal[-1]
        self.protect_pos()

        bo  = self.bo

        m.EVT.kill()
        m.redraw()
    def I_modal_mov(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_mov_end()
                return
        m.dx = evt.mouse_x - m.mou_x
        m.dy = evt.mouse_y - m.mou_y
        self.dxy_upd(m.dx, m.dy)
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()

    def to_modal_pick(self, evt):
        m.EVT.kill()
        m.redraw()

        state = getattr(gpu, "state", None)
        if state is None:
            self.ti["info"].text = "Pick function requires v3.x"
            m.admin.report({'INFO'}, "Picker function requires blender 3.x or above")
            return

        m.head_modal.append(self.I_modal_pick)
        m.M.set_mou_ic('EYEDROPPER')
        self.U_draw = self.I_draw_pick

        global tm
        tm = m.tm
        tm["fn"] = state.active_framebuffer_get
        tm["rim"] = BOX(P.color_bu_3_off)
        tm["bg"] = BOX(P.color_bu_3_on)
        tm["bo"] = BOX([0, 0, 0, 1.0])
        tm["ti"] = BLF()

        rd = m.region_data
        self.tm_L = rd.L
        self.tm_R = rd.R
        self.tm_B = rd.B
        self.tm_T = rd.T
        self.get_tm_pick(evt)

    def modal_pick_end(self, evt, confirm=False):
#
        del m.head_modal[-1]
        m.EVT.kill()
        m.M.set_mou_ic('DEFAULT')
        self.U_draw = self.I_draw
        if confirm:
            rgb = R_rgb_by_str(tm["ti"].text)
            if rgb is not None: self.set_colors(*rgb)
            m.refresh()
        m.admin.push_modal()
    def I_modal_pick(self, evt):
        m.redraw()
        if evt.type == 'MOUSEMOVE': self.get_tm_pick(evt) ;return
        if K["cancel0"].true() or K["cancel1"].true() or K["dd_cancel0"].true() or K["dd_cancel1"].true():
            self.modal_pick_end(evt)
            return
        if K["sel_fast0"].true() or K["sel_fast1"].true() or K["confirm0"].true() or K["confirm1"].true():
            self.modal_pick_end(evt, True)
            return

        self.get_tm_pick(evt)
        #
    def get_tm_pick(self, evt):
        wi = F[110]
        hi = F[20]
        _1 = F[1]
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        if self.tm_L <= x <= self.tm_R and self.tm_B <= y <= self.tm_T:
            R = x + hi + wi
            if R > self.tm_R:   R = x - hi
            L = R - wi
            T = self.tm_B + hi  if y < self.tm_B + hi else y
            B = T - hi
        else:
            L = min(max(x + F[7], self.tm_L), self.tm_R - wi)
            R = L + wi
            T = min(max(y + F[7], self.tm_B + hi), self.tm_T)
            B = T - hi

        tm["rim"].LRBT_upd(L, R, B, T)
        L += _1
        R -= _1
        B += _1
        T -= _1
        tm["bg"].LRBT_upd(L, R, B, T)
        L0 = L + _1
        tm["bo"].LRBT_upd(L0, L0 + hi, B + _1, T - _1)
        tm["ti"].xy(L0 + F[34], B + F[5])

        r, g, b = tm["fn"]().read_color(evt.mouse_x, evt.mouse_y, 1, 1, 3, 0, 'FLOAT').to_list()[0][0]
        r = round(r*255)
        g = round(g*255)
        b = round(b*255)
        tm["ti"].text = f'# {m.U_format_h(rgb_int_to_hex(r, g, b))}'
        r = L_rgb_to_glb[r] + 0.000001
        g = L_rgb_to_glb[g] + 0.000001
        b = L_rgb_to_glb[b] + 0.000001
        tm["bo"].color[:3] = r, g, b
# ▅▅▅  DRAW UPDATE                 ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        # /* 0dd_COLOR_I_draw
        w = self.w
        v = self.color
        bo = self.bo
        ti = self.ti
        rgba = self.oo["rgba"]

        BLEND()
        bo["shade"].draw()
        bo["rim"].bind_draw()
        bo["bg"].bind_draw()
        bo["bg_hue"].bind_draw()
        bo["bg_black"].bind_draw()
        bo["bg_white"].bind_draw()

        bo["bo_0"].bind_color((v[0], v[1], v[2], 1.0))
        bo["bo_0"].draw()
        bo["bo_1"].bind_color(v)
        bo["bo_1"].draw()

        bo["picker_H0"].draw()
        bo["picker_H1"].draw()
        bo["bu_H0"].bind_draw()
        bo["bu_H1_0"].bind_draw()
        bo["bu_H1_1"].draw()

        rgba.draw_box()

        blf_size(font_0, F[8])
        blf_color(font_0, *P.color_font_darker)
        ti["hex"].draw_pos()
        ti["info"].draw_pos()

        blf_color(font_0, *P.color_font)
        blf_size(font_0, F[11])
        ti["ti"].draw_pos()
        blf_size(font_0, F[9])
        rgba.draw_blf()
        # */
    def I_draw_pick(self):
        # <<< 1copy (0dd_COLOR_I_draw,, $$)
        w = self.w
        v = self.color
        bo = self.bo
        ti = self.ti
        rgba = self.oo["rgba"]

        BLEND()
        bo["shade"].draw()
        bo["rim"].bind_draw()
        bo["bg"].bind_draw()
        bo["bg_hue"].bind_draw()
        bo["bg_black"].bind_draw()
        bo["bg_white"].bind_draw()

        bo["bo_0"].bind_color((v[0], v[1], v[2], 1.0))
        bo["bo_0"].draw()
        bo["bo_1"].bind_color(v)
        bo["bo_1"].draw()

        bo["picker_H0"].draw()
        bo["picker_H1"].draw()
        bo["bu_H0"].bind_draw()
        bo["bu_H1_0"].bind_draw()
        bo["bu_H1_1"].draw()

        rgba.draw_box()

        blf_size(font_0, F[8])
        blf_color(font_0, *P.color_font_darker)
        ti["hex"].draw_pos()
        ti["info"].draw_pos()

        blf_color(font_0, *P.color_font)
        blf_size(font_0, F[11])
        ti["ti"].draw_pos()
        blf_size(font_0, F[9])
        rgba.draw_blf()
        # >>>

        BLEND()
        tm["rim"].bind_draw()
        tm["bg"].bind_draw()
        tm["bo"].bind_draw()

        blf_size(font_0, F[10])
        blf_color(font_0, *P.color_font)
        tm["ti"].draw_pos()

    def upd_data(self): pass

