from bpy.app.timers import register as thread_reg
from . import m
# KC = bpy.context.window_manager.keyconfigs.user.keymaps

def NF(): return False

class KEY:
    __slots__ = (
        'type0',
        'type1',
        'type2',
        'type3',
        'value',
        'hold',
        'repeat',
        'll',
        'true',
        'org_x',
        'org_y',
    )
    def __init__(self,
        type0='',
        type1='',
        type2='',
        type3='',
        value='',
        hold    = 0.0,
        repeat  = False,
        match   = False,
        ):
        self.type0  = type0
        self.type1  = type1
        self.type2  = type2
        self.type3  = type3
        self.value  = value
        self.hold   = hold
        self.repeat = repeat

        if match:
            if type1 == False:
                if type2 == False:
                    if type3 == False:  self.ll = 1
                    else: self.ll = 2
                elif type3 == False:    self.ll = 2
                else: self.ll = 3
            else:
                if type2 == False:
                    if type3 == False:  self.ll = 2
                    else: self.ll = 3
                elif type3 == False:    self.ll = 3
                else: self.ll = 4
        else: self.ll = None

        EVT = m.EVT
        EVT_press = EVT.press

        def check_press():
            if self.type0 in EVT_press:
                if self.type1 == False or self.type1 in EVT_press:
                    if self.type2 == False or self.type2 in EVT_press:
                        if self.type3 == False or self.type3 in EVT_press:
                            if self.ll == None:    return True
                            if self.ll == EVT.ll_press:    return True
            return False
        def check_release():
            if self in EVT.release_true:    return True

            if self.type0 in EVT_press:
                if self.type1 == False or self.type1 in EVT_press:
                    if self.type2 == False or self.type2 in EVT_press:
                        if self.type3 == False or self.type3 in EVT_press:
                            EVT.pre_release[self] = None ;return False
            return False
        def check_drag():
            if self in EVT.drag_true:       return True
            if self in EVT.pre_drag:        return False

            if self.type0 in EVT_press:
                if self.type1 == False or self.type1 in EVT_press:
                    if self.type2 == False or self.type2 in EVT_press:
                        if self.type3 == False or self.type3 in EVT_press:
                            if self.ll == None:
                                EVT.pre_drag[self] = (EVT.evt.mouse_x, EVT.evt.mouse_y)
                                return False
                            if self.ll == EVT.ll_press:
                                EVT.pre_drag[self] = (EVT.evt.mouse_x, EVT.evt.mouse_y)
                                return False
            return False
        def check_hold():
            if self.type0 in EVT_press:
                if self.type1 == False or self.type1 in EVT_press:
                    if self.type2 == False or self.type2 in EVT_press:
                        if self.type3 == False or self.type3 in EVT_press:
                            if self.ll != None:
                                if self.ll != EVT.ll_press: return False
                            if self in EVT.hold_true:       return True
                            if self in EVT.hold_checking:   return False

                            def hold_fn():
                                del EVT.hold_checking[self]
                                EVT.pre_hold[self] = None
                                m.admin.push_modal()

                            EVT.hold_checking[self] = hold_fn
                            thread_reg(hold_fn, first_interval=self.hold)
            return False
        def check_dou_press():
            if self in EVT.dou_checking:
                if EVT.ll_press == 0:   EVT.dou_true[self] = None   ;return False

            if self.type0 in EVT_press:
                if self.type1 == False or self.type1 in EVT_press:
                    if self.type2 == False or self.type2 in EVT_press:
                        if self.type3 == False or self.type3 in EVT_press:
                            if self.ll != None:
                                if self.ll != EVT.ll_press: return False

                            if self in EVT.dou_checking:
                                if self in EVT.dou_true:
                                    del EVT.dou_true[self]
                                    return True
                                return False

                            def dou_fn():
                                del EVT.dou_checking[self]
                                if self in EVT.dou_true:    del EVT.dou_true[self]

                            EVT.dou_checking[self] = dou_fn
                            thread_reg(dou_fn, first_interval=self.hold)
            return False
        def check_dou_release():
            if self in EVT.dou_checking:
                if check_release():     return True
            else:
                if check_release():
                    def dou_fn():
                        del EVT.dou_checking[self]

                    EVT.dou_checking[self] = dou_fn
                    thread_reg(dou_fn, first_interval=self.hold)

            return False

        if value == 'PRESS':        self.true = check_press
        elif value == 'RELEASE':    self.true = check_release
        elif value == 'DRAG':       self.true = check_drag
        elif value == 'HOLD':       self.true = check_hold
        elif value == 'DOU_PRESS':  self.true = check_dou_press
        elif value == 'DOU_RELEASE':self.true = check_dou_release

        else: self.true = NF

    def copy(self, e):
        self.type0  = e.type0
        self.type1  = e.type1
        self.type2  = e.type2
        self.type3  = e.type3
        self.value  = e.value
        self.hold   = e.hold
        self.repeat = e.repeat
        self.ll     = e.ll
        self.true   = e.true

non_release = {
'BUTTON4MOUSE': 0b100,
'BUTTON5MOUSE': 0b101,
'BUTTON6MOUSE': 0b110,
'BUTTON7MOUSE': 0b111,

'WHEELUPMOUSE': 0b10000,
'WHEELDOWNMOUSE': 0b10001,
'WHEELINMOUSE': 0b10010,
'WHEELOUTMOUSE': 0b10011,

'MEDIA_PLAY': 0b10001001,
'MEDIA_STOP': 0b10001010,
'MEDIA_FIRST': 0b10001011,
'MEDIA_LAST': 0b10001100,

'NDOF_MOTION': 0b10010111,
'NDOF_BUTTON_MENU': 0b10011000,
'NDOF_BUTTON_FIT': 0b10011001,
'NDOF_BUTTON_TOP': 0b10011010,
'NDOF_BUTTON_BOTTOM': 0b10011011,
'NDOF_BUTTON_LEFT': 0b10011100,
'NDOF_BUTTON_RIGHT': 0b10011101,
'NDOF_BUTTON_FRONT': 0b10011110,
'NDOF_BUTTON_BACK': 0b10011111,
'NDOF_BUTTON_ISO1': 0b10100000,
'NDOF_BUTTON_ISO2': 0b10100001,
'NDOF_BUTTON_ROLL_CW': 0b10100010,
'NDOF_BUTTON_ROLL_CCW': 0b10100011,
'NDOF_BUTTON_SPIN_CW': 0b10100100,
'NDOF_BUTTON_SPIN_CCW': 0b10100101,
'NDOF_BUTTON_TILT_CW': 0b10100110,
'NDOF_BUTTON_TILT_CCW': 0b10100111,
'NDOF_BUTTON_ROTATE': 0b10101000,
'NDOF_BUTTON_PANZOOM': 0b10101001,
'NDOF_BUTTON_DOMINANT': 0b10101010,
'NDOF_BUTTON_PLUS': 0b10101011,
'NDOF_BUTTON_MINUS': 0b10101100,
'NDOF_BUTTON_ESC': 0b10101101,
'NDOF_BUTTON_ALT': 0b10101110,
'NDOF_BUTTON_SHIFT': 0b10101111,
'NDOF_BUTTON_CTRL': 0b10110000,
'NDOF_BUTTON_1': 0b10110001,
'NDOF_BUTTON_2': 0b10110010,
'NDOF_BUTTON_3': 0b10110011,
'NDOF_BUTTON_4': 0b10110100,
'NDOF_BUTTON_5': 0b10110101,
'NDOF_BUTTON_6': 0b10110110,
'NDOF_BUTTON_7': 0b10110111,
'NDOF_BUTTON_8': 0b10111000,
'NDOF_BUTTON_9': 0b10111001,
'NDOF_BUTTON_10': 0b10111010,
'NDOF_BUTTON_A': 0b10111011,
'NDOF_BUTTON_B': 0b10111100,
'NDOF_BUTTON_C': 0b10111101,
}

dict_value = {
'ANY': 0b0,
'PRESS': 0b1,
'RELEASE': 0b10,
'DOU_PRESS': 0b11,
'DOU_RELEASE': 0b100,
'DRAG': 0b101,
'NORTH': 0b110,
'NORTH_EAST': 0b111,
'EAST': 0b1000,
'SOUTH_EAST': 0b1001,
'SOUTH': 0b1010,
'SOUTH_WEST': 0b1011,
'WEST': 0b1100,
'NORTH_WEST': 0b1101,
'NOTHING': 0b1110,
'HOLD': 0b1111
}
dict_type = {
False: 0b0,
'LEFTMOUSE': 0b1,
'MIDDLEMOUSE': 0b10,
'RIGHTMOUSE': 0b11,
# 'BUTTON4MOUSE': 0b100,
# 'BUTTON5MOUSE': 0b101,
# 'BUTTON6MOUSE': 0b110,
# 'BUTTON7MOUSE': 0b111,
# 'PEN': 0b1000,
# 'ERASER': 0b1001,
# 'MOUSEMOVE': 0b1010,
# 'INBETWEEN_MOUSEMOVE': 0b1011,
# 'TRACKPADPAN': 0b1100,
# 'TRACKPADZOOM': 0b1101,
# 'MOUSEROTATE': 0b1110,
# 'MOUSESMARTZOOM': 0b1111,
# 'WHEELUPMOUSE': 0b10000,
# 'WHEELDOWNMOUSE': 0b10001,
# 'WHEELINMOUSE': 0b10010,
# 'WHEELOUTMOUSE': 0b10011,
# 'EVT_TWEAK_L': 0b10100,
# 'EVT_TWEAK_M': 0b10101,
# 'EVT_TWEAK_R': 0b10110,
'A': 0b10111,
'B': 0b11000,
'C': 0b11001,
'D': 0b11010,
'E': 0b11011,
'F': 0b11100,
'G': 0b11101,
'H': 0b11110,
'I': 0b11111,
'J': 0b100000,
'K': 0b100001,
'L': 0b100010,
'M': 0b100011,
'N': 0b100100,
'O': 0b100101,
'P': 0b100110,
'Q': 0b100111,
'R': 0b101000,
'S': 0b101001,
'T': 0b101010,
'U': 0b101011,
'V': 0b101100,
'W': 0b101101,
'X': 0b101110,
'Y': 0b101111,
'Z': 0b110000,
'ZERO': 0b110001,
'ONE': 0b110010,
'TWO': 0b110011,
'THREE': 0b110100,
'FOUR': 0b110101,
'FIVE': 0b110110,
'SIX': 0b110111,
'SEVEN': 0b111000,
'EIGHT': 0b111001,
'NINE': 0b111010,
'LEFT_CTRL': 0b111011,
'LEFT_ALT': 0b111100,
'LEFT_SHIFT': 0b111101,
'RIGHT_ALT': 0b111110,
'RIGHT_CTRL': 0b111111,
'RIGHT_SHIFT': 0b1000000,
'OSKEY': 0b1000001,
'APP': 0b1000010,
'GRLESS': 0b1000011,
'ESC': 0b1000100,
'TAB': 0b1000101,
'RET': 0b1000110,
'SPACE': 0b1000111,
'LINE_FEED': 0b1001000,
'BACK_SPACE': 0b1001001,
'DEL': 0b1001010,
'SEMI_COLON': 0b1001011,
'PERIOD': 0b1001100,
'COMMA': 0b1001101,
'QUOTE': 0b1001110,
'ACCENT_GRAVE': 0b1001111,
'MINUS': 0b1010000,
'PLUS': 0b1010001,
'SLASH': 0b1010010,
'BACK_SLASH': 0b1010011,
'EQUAL': 0b1010100,
'LEFT_BRACKET': 0b1010101,
'RIGHT_BRACKET': 0b1010110,
'LEFT_ARROW': 0b1010111,
'DOWN_ARROW': 0b1011000,
'RIGHT_ARROW': 0b1011001,
'UP_ARROW': 0b1011010,
'NUMPAD_2': 0b1011011,
'NUMPAD_4': 0b1011100,
'NUMPAD_6': 0b1011101,
'NUMPAD_8': 0b1011110,
'NUMPAD_1': 0b1011111,
'NUMPAD_3': 0b1100000,
'NUMPAD_5': 0b1100001,
'NUMPAD_7': 0b1100010,
'NUMPAD_9': 0b1100011,
'NUMPAD_PERIOD': 0b1100100,
'NUMPAD_SLASH': 0b1100101,
'NUMPAD_ASTERIX': 0b1100110,
'NUMPAD_0': 0b1100111,
'NUMPAD_MINUS': 0b1101000,
'NUMPAD_ENTER': 0b1101001,
'NUMPAD_PLUS': 0b1101010,
'F1': 0b1101011,
'F2': 0b1101100,
'F3': 0b1101101,
'F4': 0b1101110,
'F5': 0b1101111,
'F6': 0b1110000,
'F7': 0b1110001,
'F8': 0b1110010,
'F9': 0b1110011,
'F10': 0b1110100,
'F11': 0b1110101,
'F12': 0b1110110,
'F13': 0b1110111,
'F14': 0b1111000,
'F15': 0b1111001,
'F16': 0b1111010,
'F17': 0b1111011,
'F18': 0b1111100,
'F19': 0b1111101,
'F20': 0b1111110,
'F21': 0b1111111,
'F22': 0b10000000,
'F23': 0b10000001,
'F24': 0b10000010,
'PAUSE': 0b10000011,
'INSERT': 0b10000100,
'HOME': 0b10000101,
'PAGE_UP': 0b10000110,
'PAGE_DOWN': 0b10000111,
'END': 0b10001000,
# 'MEDIA_PLAY': 0b10001001,
# 'MEDIA_STOP': 0b10001010,
# 'MEDIA_FIRST': 0b10001011,
# 'MEDIA_LAST': 0b10001100,
# 'TEXTINPUT': 0b10001101,
# 'WINDOW_DEACTIVATE': 0b10001110,
# 'TIMER': 0b10001111,
# 'TIMER0': 0b10010000,
# 'TIMER1': 0b10010001,
# 'TIMER2': 0b10010010,
# 'TIMER_JOBS': 0b10010011,
# 'TIMER_AUTOSAVE': 0b10010100,
# 'TIMER_REPORT': 0b10010101,
# 'TIMERREGION': 0b10010110,
# 'NDOF_MOTION': 0b10010111,
# 'NDOF_BUTTON_MENU': 0b10011000,
# 'NDOF_BUTTON_FIT': 0b10011001,
# 'NDOF_BUTTON_TOP': 0b10011010,
# 'NDOF_BUTTON_BOTTOM': 0b10011011,
# 'NDOF_BUTTON_LEFT': 0b10011100,
# 'NDOF_BUTTON_RIGHT': 0b10011101,
# 'NDOF_BUTTON_FRONT': 0b10011110,
# 'NDOF_BUTTON_BACK': 0b10011111,
# 'NDOF_BUTTON_ISO1': 0b10100000,
# 'NDOF_BUTTON_ISO2': 0b10100001,
# 'NDOF_BUTTON_ROLL_CW': 0b10100010,
# 'NDOF_BUTTON_ROLL_CCW': 0b10100011,
# 'NDOF_BUTTON_SPIN_CW': 0b10100100,
# 'NDOF_BUTTON_SPIN_CCW': 0b10100101,
# 'NDOF_BUTTON_TILT_CW': 0b10100110,
# 'NDOF_BUTTON_TILT_CCW': 0b10100111,
# 'NDOF_BUTTON_ROTATE': 0b10101000,
# 'NDOF_BUTTON_PANZOOM': 0b10101001,
# 'NDOF_BUTTON_DOMINANT': 0b10101010,
# 'NDOF_BUTTON_PLUS': 0b10101011,
# 'NDOF_BUTTON_MINUS': 0b10101100,
# 'NDOF_BUTTON_ESC': 0b10101101,
# 'NDOF_BUTTON_ALT': 0b10101110,
# 'NDOF_BUTTON_SHIFT': 0b10101111,
# 'NDOF_BUTTON_CTRL': 0b10110000,
# 'NDOF_BUTTON_1': 0b10110001,
# 'NDOF_BUTTON_2': 0b10110010,
# 'NDOF_BUTTON_3': 0b10110011,
# 'NDOF_BUTTON_4': 0b10110100,
# 'NDOF_BUTTON_5': 0b10110101,
# 'NDOF_BUTTON_6': 0b10110110,
# 'NDOF_BUTTON_7': 0b10110111,
# 'NDOF_BUTTON_8': 0b10111000,
# 'NDOF_BUTTON_9': 0b10111001,
# 'NDOF_BUTTON_10': 0b10111010,
# 'NDOF_BUTTON_A': 0b10111011,
# 'NDOF_BUTTON_B': 0b10111100,
# 'NDOF_BUTTON_C': 0b10111101,
# 'ACTIONZONE_AREA': 0b10111110,
# 'ACTIONZONE_REGION': 0b10111111,
# 'ACTIONZONE_FULLSCREEN': 0b11000000,
}
type_dict = (
False,
'LEFTMOUSE',
'MIDDLEMOUSE',
'RIGHTMOUSE',
'BUTTON4MOUSE',
'BUTTON5MOUSE',
'BUTTON6MOUSE',
'BUTTON7MOUSE',
'PEN',
'ERASER',
'MOUSEMOVE',
'INBETWEEN_MOUSEMOVE',
'TRACKPADPAN',
'TRACKPADZOOM',
'MOUSEROTATE',
'MOUSESMARTZOOM',
'WHEELUPMOUSE',
'WHEELDOWNMOUSE',
'WHEELINMOUSE',
'WHEELOUTMOUSE',
'EVT_TWEAK_L',
'EVT_TWEAK_M',
'EVT_TWEAK_R',
'A',
'B',
'C',
'D',
'E',
'F',
'G',
'H',
'I',
'J',
'K',
'L',
'M',
'N',
'O',
'P',
'Q',
'R',
'S',
'T',
'U',
'V',
'W',
'X',
'Y',
'Z',
'ZERO',
'ONE',
'TWO',
'THREE',
'FOUR',
'FIVE',
'SIX',
'SEVEN',
'EIGHT',
'NINE',
'LEFT_CTRL',
'LEFT_ALT',
'LEFT_SHIFT',
'RIGHT_ALT',
'RIGHT_CTRL',
'RIGHT_SHIFT',
'OSKEY',
'APP',
'GRLESS',
'ESC',
'TAB',
'RET',
'SPACE',
'LINE_FEED',
'BACK_SPACE',
'DEL',
'SEMI_COLON',
'PERIOD',
'COMMA',
'QUOTE',
'ACCENT_GRAVE',
'MINUS',
'PLUS',
'SLASH',
'BACK_SLASH',
'EQUAL',
'LEFT_BRACKET',
'RIGHT_BRACKET',
'LEFT_ARROW',
'DOWN_ARROW',
'RIGHT_ARROW',
'UP_ARROW',
'NUMPAD_2',
'NUMPAD_4',
'NUMPAD_6',
'NUMPAD_8',
'NUMPAD_1',
'NUMPAD_3',
'NUMPAD_5',
'NUMPAD_7',
'NUMPAD_9',
'NUMPAD_PERIOD',
'NUMPAD_SLASH',
'NUMPAD_ASTERIX',
'NUMPAD_0',
'NUMPAD_MINUS',
'NUMPAD_ENTER',
'NUMPAD_PLUS',
'F1',
'F2',
'F3',
'F4',
'F5',
'F6',
'F7',
'F8',
'F9',
'F10',
'F11',
'F12',
'F13',
'F14',
'F15',
'F16',
'F17',
'F18',
'F19',
'F20',
'F21',
'F22',
'F23',
'F24',
'PAUSE',
'INSERT',
'HOME',
'PAGE_UP',
'PAGE_DOWN',
'END',
'MEDIA_PLAY',
'MEDIA_STOP',
'MEDIA_FIRST',
'MEDIA_LAST',
'TEXTINPUT',
'WINDOW_DEACTIVATE',
'TIMER',
'TIMER0',
'TIMER1',
'TIMER2',
'TIMER_JOBS',
'TIMER_AUTOSAVE',
'TIMER_REPORT',
'TIMERREGION',
'NDOF_MOTION',
'NDOF_BUTTON_MENU',
'NDOF_BUTTON_FIT',
'NDOF_BUTTON_TOP',
'NDOF_BUTTON_BOTTOM',
'NDOF_BUTTON_LEFT',
'NDOF_BUTTON_RIGHT',
'NDOF_BUTTON_FRONT',
'NDOF_BUTTON_BACK',
'NDOF_BUTTON_ISO1',
'NDOF_BUTTON_ISO2',
'NDOF_BUTTON_ROLL_CW',
'NDOF_BUTTON_ROLL_CCW',
'NDOF_BUTTON_SPIN_CW',
'NDOF_BUTTON_SPIN_CCW',
'NDOF_BUTTON_TILT_CW',
'NDOF_BUTTON_TILT_CCW',
'NDOF_BUTTON_ROTATE',
'NDOF_BUTTON_PANZOOM',
'NDOF_BUTTON_DOMINANT',
'NDOF_BUTTON_PLUS',
'NDOF_BUTTON_MINUS',
'NDOF_BUTTON_ESC',
'NDOF_BUTTON_ALT',
'NDOF_BUTTON_SHIFT',
'NDOF_BUTTON_CTRL',
'NDOF_BUTTON_1',
'NDOF_BUTTON_2',
'NDOF_BUTTON_3',
'NDOF_BUTTON_4',
'NDOF_BUTTON_5',
'NDOF_BUTTON_6',
'NDOF_BUTTON_7',
'NDOF_BUTTON_8',
'NDOF_BUTTON_9',
'NDOF_BUTTON_10',
'NDOF_BUTTON_A',
'NDOF_BUTTON_B',
'NDOF_BUTTON_C',
'ACTIONZONE_AREA',
'ACTIONZONE_REGION',
'ACTIONZONE_FULLSCREEN',
)
value_dict = (
'ANY',
'PRESS',
'RELEASE',
'DOU_PRESS',
'DOU_RELEASE',
'DRAG',
'NORTH',
'NORTH_EAST',
'EAST',
'SOUTH_EAST',
'SOUTH',
'SOUTH_WEST',
'WEST',
'NORTH_WEST',
'NOTHING',
'HOLD'
)
key_value_to_title = {
'ANY': 'Any',
'PRESS': 'Press',
'RELEASE': 'Release',
'DOU_PRESS': 'Double Press',
'DOU_RELEASE': 'Double Release',
'DRAG': 'Drag',
'NORTH': 'North',
'NORTH_EAST': 'North East',
'EAST': 'East',
'SOUTH_EAST': 'South East',
'SOUTH': 'South',
'SOUTH_WEST': 'South West',
'WEST': 'West',
'NORTH_WEST': 'North West',
'NOTHING': 'Nothing',
'HOLD': 'Hold',
}
key_title_to_value = {v: k for k, v in key_value_to_title.items()}

time_keys = {
'Double Press': 'DOU_PRESS',
'Double Release': 'DOU_RELEASE',
'Hold': 'HOLD',
}

def R_tx_comb(km):
    s0 = "" if km.type0 is False else km.type0
    s1 = "" if km.type1 is False else km.type1
    s2 = "" if km.type2 is False else km.type2
    s3 = "" if km.type3 is False else km.type3
    tx = f'{s0}   {s1}   {s2}   {s3}'
    if tx == "         ": tx = "None"
    return tx

class NAME_VAL:
    __slots__ = "name", "val"
    def __init__(self, name, val):
        self.name   = name
        self.val    = val

value_enums = (
    NAME_VAL('Press', 'PRESS'),
    NAME_VAL('Release', 'RELEASE'),
    NAME_VAL('Double Press', 'DOU_PRESS'),
    NAME_VAL('Double Release', 'DOU_RELEASE'),
    NAME_VAL('Drag', 'DRAG'),
    NAME_VAL('Hold', 'HOLD'),
)
value_enums_press = (NAME_VAL('Press', 'PRESS'),)
value_enums_release = (NAME_VAL('Release', 'RELEASE'),)

key_value_set = {
'PRESS',
'RELEASE',
'DOU_PRESS',
'DOU_RELEASE',
'DRAG',
'HOLD',
}
key_title_set = {
'Press',
'Release',
'Double Press',
'Double Release',
'Drag',
'Hold',
}

# sel_value_enums = (
#     NAME_VAL('Press', 'PRESS'),
#     NAME_VAL('Release', 'RELEASE'),
# )
# sel_key_value_set = {
# 'PRESS',
# 'RELEASE',
# }
# sel_key_title_set = {
# 'Press',
# 'Release',
# }
