import time
last_time = 0
####
import bpy, blf, gpu, io
from bpy.props import(StringProperty, IntProperty, IntVectorProperty)
from bpy.types import PropertyGroup
from bpy.utils.units import to_value as units_to_value

from math import ceil as math_ceil
from math import floor as math_floor
from struct import pack as struct_pack
from struct import unpack as struct_unpack
from bpy.types import Operator
from gpu_extras.batch import batch_for_shader
from gpu.types import GPUShader
from gpu.matrix import get_projection_matrix
try:
    xxxxxxxx
    from gpu.state import scissor_test_set, scissor_set, blend_set
    def ENABLE_SCISSOR():
        scissor_test_set(True)
    def DISABLE_SCISSOR():
        scissor_test_set(False)
    def BLEND():
        blend_set("ALPHA")
except:
    from bgl import glEnable, glDisable, GL_BLEND, GL_SCISSOR_TEST, glScissor
    def ENABLE_SCISSOR():
        glEnable(GL_SCISSOR_TEST)
    def DISABLE_SCISSOR():
        glDisable(GL_SCISSOR_TEST)
    def BLEND():
        glEnable(GL_BLEND)
    scissor_set = glScissor
from blf import color as blf_color
from blf import size as blf_size
from blf import draw as blf_draw
from blf import position as blf_pos
from blf import dimensions as blf_dimen
from bpy.app.timers import register as thread_reg
from bpy.app.timers import unregister as thread_unreg
from bpy.app.timers import is_registered as thread_isreg
# from bpy.app.handlers import persistent
from bpy.app.handlers import depsgraph_update_post
from bpy.app.handlers import frame_change_post
from bpy.ops import _BPyOpsSubModOp

from . fn import R_unsign32
from . import prefs, keys, tb, fn


def N(*p): pass
def NN(*p, **pp): pass
def NF(*p): return False
def NNF(*p, **pp): return False
def NT(*p): return True
def NNT(*p, **pp): return True

class EMPTY: pass
class XY:
    __slots__ = "x", "y"
    def __init__(self, x = 0, y = 0):
        self.x = x
        self.y = y
class LRBT:
    __slots__ = "L", "R", "B", "T"
    def __init__(self, L, R, B, T):
        self.L = L
        self.R = R
        self.B = B
        self.T = T
class NAME:
    __slots__ = "name"
    def __init__(self, name):   self.name = name
class NAME_VAL:
    __slots__ = "name", "val"
    def __init__(self, name, val):
        self.name   = name
        self.val    = val
class TABLE(list):
    __slots__ = "table"
    def __init__(self):
        self.table = {}
    def new(self, e):
        self.append(e)
        self.table[e] = len(self) - 1
    def delete(self, e):
        table = self.table
        del self[table[e]]
        table.clear()
        for i, e in enumerate(self):    table[e] = i
    def kill(self):
        self.clear()
        self.table.clear()
class REGION_DATA:
    __slots__ = "L", "R", "B", "T", "border"
    def __init__(self):
        self.border = LRBT(0,0,0,0)
    def upd(self):
        a   = bpy.context.region
        L   = 0
        R   = 0
        B   = 0
        T   = 0
        for r in bpy.context.area.regions:
            if r.type == 'TOOLS':
                if r.alignment == "LEFT":   L += r.width
                else:                       R -= r.width
            elif r.type == 'UI':
                if r.alignment == "LEFT":   L += r.width
                else:                       R -= r.width
            elif r.type == 'TOOL_HEADER':
                if r.alignment == "TOP":    T -= r.height
                else:                       B += r.height

        b       = self.border
        b.L     = L
        b.R     = R
        b.B     = B
        b.T     = T
        self.L  = L
        self.R  = a.width + R
        self.B  = B
        self.T  = a.height + T
    def outside(self, x, y):
        return x < self.L or x > self.R or y < self.B or y > self.T

##
##
##
##
##
##
is_publish = True
##
##
##
##
##

##
##
##

##
##
##
##
##
##
is_trial = True
##
##
##
##
##
##


addon_version = None
blender_version = None
bl_start_up = None
UNIFORM_COLOR = ""

P               = None
F               = {}
update_state    = {"state": False}
redraw          = None
AREA            = None
stdout          = io.StringIO()
admin           = None
region_data     = REGION_DATA()
UNDO_PUSH       = None
undo_evt        = None
color_empty     = (0,0,0,0)
tm              = {}
mou_x           = 0
mou_y           = 0
dx              = 0
dy              = 0
W_A             = []
W_D             = []
W_M             = []
W_act           = None
han_draw        = None
head_modal      = []
is_outside      = False
U_format_f      = None
U_format_i      = None
U_format_h      = None
U_format_vec    = None
unit_system     = None
unit_length     = None
unit_length_fac     = None
unit_length_fac2    = None
unit_length_fac3    = None

K = {}
K_list = {
    # <<< ||* 1ifmatch (0prefs_key, 4,
    #$lambda line: (f'"{line.split(":", 1)[0].lstrip()[5 : ]}",\n', True)$,
    #$lambda line: ('', False)$,
    #${'IntVectorProperty'}$)
    "sys_pass",
    "sys_pass_E",
    "sel_fast",
    "sel",
    "sel_ext",
    "bu_sel",
    "bu_sel_ext",
    "bu_qe",
    "bu_qe_E",
    "bu_qe_cancel",
    "bu_qe_slow",
    "bu_qe_fast",
    "bu_reset",
    "bu_reset_all",
    "bu_left",
    "bu_right",
    "bu_up",
    "bu_down",
    "bu_insert_kf",
    "bu_del_kf",
    "bu_clear_kf",
    "bu_add_dr",
    "bu_del_dr",
    "bu_dp",
    "bu_dp_full",
    "bu_dp_paste",
    "bu_add_keying_set",
    "bu_del_keying_set",
    "bu_batch_kf",
    "bu_batch_dr",
    "bu_batch_value",
    "rm",
    "cancel",
    "confirm",
    "pan",
    "pan_E",
    "glopan",
    "glopan_E",
    "ti_bu",
    "ti_bu_E",
    "ti_mov",
    "ti_mov_E",
    "resize",
    "resize_E",
    "undo",
    "redo",
    "me_sel",
    "me_sel_ext",
    "me_pan",
    "me_pan_E",
    "me_box",
    "me_box_E",
    "me_box_ext",
    "me_box_ext_E",
    "me_sort",
    "me_sort_E",
    "me_rename",
    "me_all",
    "me_act_up",
    "me_act_dn",
    "me_act_up_ext",
    "me_act_dn_ext",
    "me_mod_up",
    "me_mod_dn",
    "me_del",
    "me_apply",
    "dd_del_alp",
    "dd_del_word",
    "dd_del_all",
    "dd_left",
    "dd_right",
    "dd_up",
    "dd_down",
    "dd_shift_left",
    "dd_shift_right",
    "dd_shift_up",
    "dd_shift_down",
    "dd_pan",
    "dd_pan_E",
    "dd_box",
    "dd_box_E",
    "dd_sel",
    "dd_sel_all",
    "dd_copy",
    "dd_paste",
    "dd_cut",
    "dd_cancel",
    "dd_confirm",
    "dd_bar",
    "dd_bar_E",
    "dd_tab",
    "dd_scroll_up",
    "dd_scroll_down",
    "cp_hue_sel",
    "cp_hue",
    "cp_hue_E",
    "pk_cancel",
    "pk_confirm",
    "tex_cancel",
    "rm_1",
    "rm_2",
    "rm_3",
    "rm_4",
    "rm_5",
    "rm_6",
    "rm_7",
    "rm_8",
    "rm_9",
    "rm_0",
    "rm_back",
    "rm_next",
    # >>>
}
dic_hold_key = {
    "LEFT_CTRL": "ctrl",
    "LEFT_ALT": "alt",
    "LEFT_SHIFT": "shift",
    "OSKEY": "oskey",
}


bpy_mds = None

U_resize_evt    = N
U_pan_cursor    = N
U_end_pan       = N
U_pan           = N
U_press         = N
U_release       = N
cursor_warp     = None

def I_resize_evt(self, evt):
    if evt.mouse_region_y >= self.resize_rim.T2:
        if evt.mouse_region_x <= self.resize_rim.L2:
            M.set_mou_ic('SCROLL_XY')
            self.U_modal = self.evt_resize_NW
            self.evt_resize_NW(evt)
            return True
        if evt.mouse_region_x >= self.resize_rim.R2:
            M.set_mou_ic('SCROLL_XY')
            self.U_modal = self.evt_resize_NE
            self.evt_resize_NE(evt)
            return True

        M.set_mou_ic('MOVE_Y')
        self.U_modal = self.evt_resize_N
        self.evt_resize_N(evt)
        return True
    if evt.mouse_region_x <= self.resize_rim.L2:
        if evt.mouse_region_y <= self.resize_rim.B2:
            M.set_mou_ic('SCROLL_XY')
            self.U_modal = self.evt_resize_SW
            self.evt_resize_SW(evt)
            return True

        M.set_mou_ic('MOVE_X')
        self.U_modal = self.evt_resize_W
        self.evt_resize_W(evt)
        return True
    if evt.mouse_region_x >= self.resize_rim.R2:
        if evt.mouse_region_y <= self.resize_rim.B2:
            M.set_mou_ic('SCROLL_XY')
            self.U_modal = self.evt_resize_SE
            self.evt_resize_SE(evt)
            return True

        M.set_mou_ic('MOVE_X')
        self.U_modal = self.evt_resize_E
        self.evt_resize_E(evt)
        return True
    if evt.mouse_region_y <= self.resize_rim.B2:
        M.set_mou_ic('MOVE_Y')
        self.U_modal = self.evt_resize_S
        self.evt_resize_S(evt)
        return True
def I_pan_cursor(self, evt):
    M.set_mou_ic('PAINT_CROSS')
def I_pan_cursor_hide(self, evt):
    M.set_mou_ic('NONE')
    tm["x"] = evt.mouse_x
    tm["y"] = evt.mouse_y
def I_end_pan(self):
    M.set_mou_ic('DEFAULT')
    redraw()
def I_end_pan_hide(self):
    M.set_mou_ic('DEFAULT')
    cursor_warp(tm["x"], tm["y"])
    redraw()
def loop_mou(evt):
    global mou_x, mou_y
    if evt.mouse_x <= tm["L"]:
        if evt.mouse_y <= tm["B"]:
            cursor_warp(tm["R2"], tm["T2"])
            mou_x = tm["R2"]
            mou_y = tm["T2"]
        elif evt.mouse_y >= tm["T"]:
            cursor_warp(tm["R2"], tm["B2"])
            mou_x = tm["R2"]
            mou_y = tm["B2"]
        else:
            cursor_warp(tm["R2"], evt.mouse_y)
            mou_x = tm["R2"]
            mou_y = evt.mouse_y
    elif evt.mouse_x >= tm["R"]:
        if evt.mouse_y <= tm["B"]:
            cursor_warp(tm["L2"], tm["T2"])
            mou_x = tm["L2"]
            mou_y = tm["T2"]
        elif evt.mouse_y >= tm["T"]:
            cursor_warp(tm["L2"], tm["B2"])
            mou_x = tm["L2"]
            mou_y = tm["B2"]
        else:
            cursor_warp(tm["L2"], evt.mouse_y)
            mou_x = tm["L2"]
            mou_y = evt.mouse_y
    elif evt.mouse_y <= tm["B"]:
        cursor_warp(evt.mouse_x, tm["T2"])
        mou_x = evt.mouse_x
        mou_y = tm["T2"]
    elif evt.mouse_y >= tm["T"]:
        cursor_warp(evt.mouse_x, tm["B2"])
        mou_x = evt.mouse_x
        mou_y = tm["B2"]
    else:
        mou_x = evt.mouse_x
        mou_y = evt.mouse_y
def get_loop_mou_info(L=None, R=None, B=None, T=None, th=5):
    max_x = bpy.context.window.width -6
    max_y = bpy.context.window.height -6

    if L == None:
        L = 3
        R = max_x
        B = 3
        T = max_y
    else:
        if L < 3:       L = 3
        if B < 3:       B = 3
        if R > max_x:   R = max_x
        if T > max_y:   T = max_y

    tm["L"]     = L
    tm["R"]     = R
    tm["B"]     = B
    tm["T"]     = T
    tm["L2"]    = L + th
    tm["R2"]    = R - th
    tm["B2"]    = B + th
    tm["T2"]    = T - th
    tm["dx_lim"] = (R - L) // 2
    tm["dy_lim"] = (T - B) // 2
def get_loop_mou_info_region(evt, L=None, R=None, B=None, T=None, th=5):
    dx = evt.mouse_x - evt.mouse_region_x
    dy = evt.mouse_y - evt.mouse_region_y
    tm["mouse_region_offset"] = (dx, dy)
    L += dx
    R += dx
    B += dy
    T += dy
    max_x = bpy.context.window.width -6
    max_y = bpy.context.window.height -6
    if L == None:
        L = 3
        R = max_x
        B = 3
        T = max_y
    else:
        if L < 3:       L = 3
        if B < 3:       B = 3
        if R > max_x:   R = max_x
        if T > max_y:   T = max_y
    tm["L"]     = L
    tm["R"]     = R
    tm["B"]     = B
    tm["T"]     = T
    tm["L2"]    = L + th
    tm["R2"]    = R - th
    tm["B2"]    = B + th
    tm["T2"]    = T - th
    tm["dx_lim"] = (R - L) // 2
    tm["dy_lim"] = (T - B) // 2
def I_pan(evt):
    global dx, dy
    dx = evt.mouse_x - mou_x
    dy = evt.mouse_y - mou_y
    if abs(dx) > tm["dx_lim"]:    dx = 0
    if abs(dy) > tm["dy_lim"]:    dy = 0
def I_pan_invert(evt):
    global dx, dy
    dx = mou_x - evt.mouse_x
    dy = mou_y - evt.mouse_y
    if abs(dx) > tm["dx_lim"]:    dx = 0
    if abs(dy) > tm["dy_lim"]:    dy = 0

try:
    shader2D    = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
except:
    shader2D    = gpu.shader.from_builtin('UNIFORM_COLOR')
BIND        = shader2D.bind
UNFL        = shader2D.uniform_float
font_0      = 0
font_1      = 1
indices_box = ((0,1,2),(0,2,3))
indices_tri = ((0,1,2),)
indices_rim = ((0,5,3),(0,6,5),(0,1,6),(1,7,6),(1,2,7),(2,3,7),(3,4,7),(3,5,4))

def get_fn(): pass

def pref_on():
    prefs.U_upd_F = prefs.I_upd_F
    prefs.U_upd_pos = prefs.I_upd_pos
    prefs.U_upd_cv = prefs.I_upd_cv
def pref_off():
    prefs.U_upd_F = get_F
    prefs.U_upd_pos = N
    prefs.U_upd_cv = N
def get_P():
    global P, U_resize_evt, U_pan_cursor, U_end_pan, U_pan, UNDO_PUSH
    P               = bpy.context.preferences.addons[__package__].preferences
    UNDO_PUSH       = bpy.ops.ed.undo_push
    U_resize_evt    = N  if P.lock_win_size else I_resize_evt

    get_format_f()
    get_format_i()
    get_format_h()
    get_format_vec()

    from . ED_md import mods
    mods.BU_FOCUS.bo.color = P.color_mod_bu_fo
    mods.BU_FOCUS.ti.color = P.color_font_mod_num_fo

    if P.pan_method in {'I_pan_hide', 'I_pan_hide_invert'}:
        U_pan_cursor    = I_pan_cursor_hide
        U_end_pan       = I_end_pan_hide
        U_pan           = I_pan  if P.pan_method == 'I_pan_hide' else I_pan_invert
    else:
        U_pan_cursor    = I_pan_cursor
        U_end_pan       = I_end_pan
        U_pan           = I_pan  if P.pan_method == 'I_pan' else I_pan_invert
def get_F():
    global F
    u = P.scale[0]
    u_ti = P.scale[1] * u
    ti_h = round(24 * u * P.scale[1])
    ti_bu_d = round((ti_h - ti_h * P.scale_ti_bu) // 2)
    ti_bu_h = ti_h - ti_bu_d * 2

    F[-1] =      ti_h
    F[-2] =      ti_bu_d
    F[-3] =      ti_bu_h
    F[-4] =      round(P.ti_font_size * u_ti) # ti_tx_s
    F[-5] =      round((12 - 0.3846 * P.ti_font_size) * u_ti) # ti_tx_d
    F[-6] =      round((12 - 0.3615 * P.ti_font_size) * u_ti) # ti_tx_d
    F[-7] =      round(ti_bu_h * 0.9843)    # x_s
    F[-8] =      round(ti_bu_h * 0.2059)    # x_dx
    F[-9] =      round(ti_bu_h * 0.2137)    # x_d
    F[-10] =     round(ti_bu_h * 1.3922)    # fit_s
    F[-11] =     round(ti_bu_h * 0.0784)    # fit_d
    F[-12] =     round(ti_bu_h * -0.2235)   # fit_d
    F[-13] =     round(ti_bu_h * 1.8078)    # min_s
    F[-14] =     round(ti_bu_h * 0.049)     # min_d
    F[-15] =     round(ti_bu_h * 0.1157)    # min_d

    F[1.5] =     1.5 * u
    F[2.5] =     2.5 * u
    F[3.8] =     3.8 * u
    F[4.5] =     4.5 * u
    F[4.9] =     4.9 * u
    F[5.1] =     5.1 * u
    F[5.6] =     5.6 * u
    F[6.1] =     6.1 * u
    F[7.8] =     7.8 * u
    F[18.1] =    18.1 * u
    F[19.1] =    19.1 * u

    F[0] =       0
    F[1] =       round(u)
    F[2] =       round(2 * u)
    F[3] =       round(3 * u)
    F[4] =       round(4 * u)
    F[5] =       round(5 * u)
    F[6] =       round(6 * u)
    F[7] =       round(7 * u)
    F[8] =       round(8 * u)
    F[9] =       round(9 * u)
    F[10] =      round(10 * u)
    F[11] =      round(11 * u)
    F[12] =      round(12 * u)
    F[13] =      round(13 * u)
    F[14] =      round(14 * u)
    F[15] =      round(15 * u)
    F[16] =      round(16 * u)
    F[17] =      round(17 * u)
    F[18] =      round(18 * u)
    F[19] =      round(19 * u)
    F[20] =      round(20 * u)
    F[21] =      round(21 * u)
    F[22] =      round(22 * u)
    F[24] =      round(24 * u)
    F[30] =      round(30 * u)
    F[31] =      round(31 * u)
    F[34] =      round(34 * u)
    F[38] =      round(38 * u)
    F[46] =      round(46 * u)
    F[52] =      round(52 * u)

    F[61] =      round(61 * u)
    F[76] =      round(76 * u)
    F[82] =      round(82 * u)
    F[93] =      round(93 * u)
    F[101] =     round(101 * u)
    F[110] =     round(110 * u)
    F[150] =     round(150 * u)
    F[300] =     round(300 * u)
    F[480] =     round(480 * u)
    F[500] =     round(500 * u)

    # F["x"] = 0.15*u
    # F["y"] = 2*u
    F[-16] = F[15] - F[1] - F[1]
    F[-5.6] = F[5.6] + 0.5
    F[-911] = F[16] + F[1]          # mod_h
    F[-999] = F[-911] + F[1]         # mod_hi
    F[-998] = F[-999] * 27          # mod_h_full
    F[-997] = F[-999] // 2          # mod_h_half
    F[-996] = F[-999] - F[1]
def get_K():
    type_dict   = keys.type_dict
    value_dict  = keys.value_dict
    KEY         = keys.KEY

    for e in K_list:
        key = getattr(P, "keys_" + e)
        # /* 0m_get_K
        k = R_unsign32(key[0])
        type0 = type_dict[k & 0b11111111]
        k >>= 0b1000
        type1 = type_dict[k & 0b11111111]
        k >>= 0b1000
        type2 = type_dict[k & 0b11111111]
        k >>= 0b1000
        type3 = type_dict[k & 0b11111111]

        k = R_unsign32(key[2])
        type_0 = type_dict[k & 0b11111111]
        k >>= 0b1000
        type_1 = type_dict[k & 0b11111111]
        k >>= 0b1000
        type_2 = type_dict[k & 0b11111111]
        k >>= 0b1000
        type_3 = type_dict[k & 0b11111111]

        k = R_unsign32(key[4])
        value0 = value_dict[k & 0b11111111]
        k >>= 0b1000
        value_0 = value_dict[k & 0b11111111]
        k >>= 0b1000
        repeat0 = True if k & 0b1 else False
        k >>= 0b1
        repeat_0 = True if k & 0b1 else False
        k >>= 0b1
        match0 = True if k & 0b1 else False
        k >>= 0b1
        match_0 = True if k & 0b1 else False

        k = R_unsign32(key[1])
        K[e + "0"] = KEY(type0, type1, type2, type3, value0,
            struct_unpack('>f', struct_pack('>l', k))[0], repeat0, match0)

        k = R_unsign32(key[3])
        K[e + "1"] = KEY(type_0, type_1, type_2, type_3, value_0,
            struct_unpack('>f', struct_pack('>l', k))[0], repeat_0, match_0)
        # */
def get_K_by(identifier):
    type_dict   = keys.type_dict
    value_dict  = keys.value_dict
    KEY         = keys.KEY
    key = getattr(P, identifier)
    e = identifier[5 :]
    # <<< 1copy (0m_get_K,, $$)
    k = R_unsign32(key[0])
    type0 = type_dict[k & 0b11111111]
    k >>= 0b1000
    type1 = type_dict[k & 0b11111111]
    k >>= 0b1000
    type2 = type_dict[k & 0b11111111]
    k >>= 0b1000
    type3 = type_dict[k & 0b11111111]
    k = R_unsign32(key[2])
    type_0 = type_dict[k & 0b11111111]
    k >>= 0b1000
    type_1 = type_dict[k & 0b11111111]
    k >>= 0b1000
    type_2 = type_dict[k & 0b11111111]
    k >>= 0b1000
    type_3 = type_dict[k & 0b11111111]
    k = R_unsign32(key[4])
    value0 = value_dict[k & 0b11111111]
    k >>= 0b1000
    value_0 = value_dict[k & 0b11111111]
    k >>= 0b1000
    repeat0 = True if k & 0b1 else False
    k >>= 0b1
    repeat_0 = True if k & 0b1 else False
    k >>= 0b1
    match0 = True if k & 0b1 else False
    k >>= 0b1
    match_0 = True if k & 0b1 else False
    k = R_unsign32(key[1])
    K[e + "0"] = KEY(type0, type1, type2, type3, value0,
        struct_unpack('>f', struct_pack('>l', k))[0], repeat0, match0)
    k = R_unsign32(key[3])
    K[e + "1"] = KEY(type_0, type_1, type_2, type_3, value_0,
        struct_unpack('>f', struct_pack('>l', k))[0], repeat_0, match_0)
    # >>>
def get_format_f():
    global U_format_f
    U_format_f = getattr(fn, P.format_tx_f)
def get_format_i():
    global U_format_i
    U_format_i = getattr(fn, P.format_tx_i)
def get_format_h():
    global U_format_h
    U_format_h = getattr(fn, P.format_tx_h)
def get_format_vec():
    global U_format_vec
    U_format_vec = getattr(fn, P.format_tx_vec)
def U_FORMAT_F(v):
    return U_format_f(v / unit_length_fac)
def U_FORMAT_F2(v):
    return U_format_f(v / unit_length_fac2)
def U_FORMAT_F3(v):
    return U_format_f(v / unit_length_fac3)
UR_protect_pos = N
def get_win_protect_fn():
    global UR_protect_pos
    UR_protect_pos = IR_org_pos  if P.win_pos_protect == 'DISABLE' else IR_protect_pos


def get_mou(evt):
    global mou_x, mou_y
    mou_x = evt.mouse_x
    mou_y = evt.mouse_y
def get_mou_region(evt):
    global mou_x, mou_y
    mou_x = evt.mouse_region_x
    mou_y = evt.mouse_region_y


modal_wait_release_end_fn = N
def modal_wait_release(evt):
    if U_press == I_press:
        del head_modal[-1]
        modal_wait_release_end_fn(evt)
#
def init_wait_release(evt = None, end_fn = None):
    if head_modal:
        if head_modal[-1] == modal_wait_release: return
#
    global modal_wait_release_end_fn
    modal_wait_release_end_fn = N   if end_fn == None else end_fn
    head_modal.append(modal_wait_release)
    modal_wait_release(evt)

def T_redraw():
    try: redraw()
    except: pass

def bind_color_bu_1_rim():      BIND() ;UNFL("color", P.color_bu_1_rim)
def bind_color_bu_4_rim():      BIND() ;UNFL("color", P.color_bu_4_rim)
def bind_color_setting_bo():    BIND() ;UNFL("color", P.color_setting_bo)
def bind_color_setting_bo_fo(): BIND() ;UNFL("color", P.color_setting_bo_fo)

class RECT:
    __slots__ = "L", "R", "B", "T"
    def __init__(self, L=0, R=0, B=0, T=0):
        self.L  = L
        self.R  = R
        self.B  = B
        self.T  = T

    def LRBT(self, L, R, B, T):
        self.L  = L
        self.R  = R
        self.B  = B
        self.T  = T
    def dxy(self, dx, dy):
        self.L += dx
        self.R += dx
        self.B += dy
        self.T += dy
    def inbox(self, evt):
        return self.L <= evt.mouse_region_x <= self.R and self.B <= evt.mouse_region_y <= self.T
    def inbox_xy(self, x, y):
        return self.L <= x <= self.R and self.B <= y <= self.T
    def in_LR_x(self, x):
        return self.L <= x <= self.R
    def in_BT_y(self, y):
        return self.B <= y <= self.T
class BOX:
    __slots__ = "color", "L", "R", "B", "T", "bat"
    def __init__(self, color=None, L=0, R=0, B=0, T=0):
        self.color  = color
        self.L  = L
        self.R  = R
        self.B  = B
        self.T  = T

    def upd(self):
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": (
            (self.L,self.B),(self.L,self.T),
            (self.R,self.T),(self.R,self.B))}, indices=indices_box
        )
    def upd_bat(self, L, R, B, T):
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": (
            (L,B),(L,T),
            (R,T),(R,B))}, indices=indices_box
        )
    def draw(self): self.bat.draw(shader2D)
    def bind(self): BIND() ; UNFL("color", self.color)
    def bind_color(self, c): BIND() ; UNFL("color", c)
    def bind_draw(self):
        BIND()
        UNFL("color", self.color)
        self.bat.draw(shader2D)
    def LRBT(self, L, R, B, T):
        self.L  = L
        self.R  = R
        self.B  = B
        self.T  = T
    def LRBT_upd(self, L, R, B, T):
        self.L  = L
        self.R  = R
        self.B  = B
        self.T  = T
        self.upd()
    def inbox(self, evt):
        return self.L <= evt.mouse_region_x <= self.R and self.B <= evt.mouse_region_y <= self.T
    def inbox_xy(self, x, y):
        return self.L <= x <= self.R and self.B <= y <= self.T
    def out_T(self, evt): return self.T < evt.mouse_region_y
    def out_B(self, evt): return self.B > evt.mouse_region_y
    def out_L(self, evt): return self.L > evt.mouse_region_x
    def out_R(self, evt): return self.R < evt.mouse_region_x
    def in_T(self, evt):  return self.T >= evt.mouse_region_y
    def in_B(self, evt):  return self.B <= evt.mouse_region_y
    def in_L(self, evt):  return self.L <= evt.mouse_region_x
    def in_R(self, evt):  return self.R >= evt.mouse_region_x
    def in_LR(self, evt):
        return self.L <= evt.mouse_region_x <= self.R
    def in_BT(self, evt):
        return self.B <= evt.mouse_region_y <= self.T
    def in_LR_x(self, x):
        return self.L <= x <= self.R
    def in_BT_y(self, y):
        return self.B <= y <= self.T

    def copy_LRBT(self, e): self.LRBT(e.L, e.R, e.B, e.T)

    def inset_with_depth(self, e, d):   self.LRBT(e.L + d, e.R - d, e.B + d, e.T - d)
    def dxy(self, dx, dy):
        self.L += dx
        self.R += dx
        self.B += dy
        self.T += dy
    def dxy_upd(self, dx, dy):
        self.L += dx
        self.R += dx
        self.B += dy
        self.T += dy

        self.upd()
    def dx(self, dx):           self.L += dx  ; self.R += dx
    def dx_upd(self, dx):       self.L += dx  ; self.R += dx  ; self.upd()
    def dy(self, dy):           self.B += dy  ; self.T += dy
    def dy_upd(self, dy):       self.B += dy  ; self.T += dy  ; self.upd()

    def R_w(self):  return self.R - self.L
    def R_h(self):  return self.T - self.B
    def R_center_x(self):   return self.L + (self.R - self.L) // 2
    def R_center_y(self):   return self.B + (self.T - self.B) // 2
    def R_center_x_float(self):   return self.L + (self.R - self.L) / 2
    def R_center_y_float(self):   return self.B + (self.T - self.B) / 2
    def R_LRBT(self):   return self.L, self.R, self.B, self.T
    def R_copy(self):   return BOX(self.color, self.L, self.R, self.B, self.T)

    def depth_L(self, L, d): self.L = L  ; self.R = self.L + d
    def depth_R(self, R, d): self.R = R  ; self.L = self.R - d
    def depth_B(self, B, d): self.B = B  ; self.T = self.B + d
    def depth_T(self, T, d): self.T = T  ; self.B = self.T - d
    def LTwh(self, L, T, w, h):
        self.L = L
        self.T = T
        self.R = L + w
        self.B = T - h
    def set_by_blf(self, e, dx = 13, dy = 6):
        self.L = e.x - F[dx]
        self.R = e.R_end_x() + F[dx]
        self.B = e.y - F[dy]
        self.T = e.R_end_y() + F[dy]
class RIM:
    __slots__ = "color", "L", "R", "B", "T", "L2", "R2", "B2", "T2", "bat"
    def __init__(self, color=None, L=0, R=0, B=0, T=0, L2=0, R2=0, B2=0, T2=0):
        self.color  = color
        self.L  = L
        self.R  = R
        self.B  = B
        self.T  = T
        self.L2 = L2
        self.R2 = R2
        self.B2 = B2
        self.T2 = T2

    def upd(self):
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos" : (
            (self.L,self.B),(self.L,self.T),
            (self.R,self.T),(self.R,self.B),
            (self.R2,self.B2),(self.L2,self.B2),
            (self.L2,self.T2),(self.R2,self.T2))},
            indices=indices_rim
        )
    def draw(self): self.bat.draw(shader2D)
    def bind(self): BIND() ; UNFL("color", self.color)
    def bind_draw(self): self.bind() ; self.draw()
    def LRBTd(self, L, R, B, T, d):
        self.L  = L
        self.R  = R
        self.B  = B
        self.T  = T
        self.L2 = L+d
        self.R2 = R-d
        self.B2 = B+d
        self.T2 = T-d
    def LRBTd_upd(self, L, R, B, T, d):
        self.L  = L
        self.R  = R
        self.B  = B
        self.T  = T
        self.L2 = L+d
        self.R2 = R-d
        self.B2 = B+d
        self.T2 = T-d
        self.upd()
    def LRBTd_rev(self, L, R, B, T, d):
        self.L2 = L
        self.R2 = R
        self.B2 = B
        self.T2 = T
        self.L  = L-d
        self.R  = R+d
        self.B  = B-d
        self.T  = T+d
    def LRBTd_rev_upd(self, L, R, B, T, d):
        self.L2 = L
        self.R2 = R
        self.B2 = B
        self.T2 = T
        self.L  = L-d
        self.R  = R+d
        self.B  = B-d
        self.T  = T+d
        self.upd()
    def inbox(self, event):
        return self.L <= event.mouse_region_x <= self.R and self.B <= event.mouse_region_y <= self.T
    def inbox_xy(self, x, y):
        return self.L <= x <= self.R and self.B <= y <= self.T
    def out_T(self, event): return self.T < event.mouse_region_y
    def out_B(self, event): return self.B > event.mouse_region_y
    def out_L(self, event): return self.L > event.mouse_region_x
    def out_R(self, event): return self.R < event.mouse_region_x
    def in_T(self, event):  return self.T >= event.mouse_region_y
    def in_B(self, event):  return self.B <= event.mouse_region_y
    def in_L(self, event):  return self.L <= event.mouse_region_x
    def in_R(self, event):  return self.R >= event.mouse_region_x

    def R_LRBT(self):   return self.L, self.R, self.B, self.T

    def dx(self, dx):
        self.L += dx
        self.R += dx
        self.L2 += dx
        self.R2 += dx
    def dy(self, dy):
        self.B += dy
        self.T += dy
        self.B2 += dy
        self.T2 += dy
    def dxy(self, dx, dy):
        self.L += dx
        self.R += dx
        self.L2 += dx
        self.R2 += dx

        self.B += dy
        self.T += dy
        self.B2 += dy
        self.T2 += dy
    def dxy_upd(self, dx, dy):
        self.L += dx
        self.R += dx
        self.L2 += dx
        self.R2 += dx

        self.B += dy
        self.T += dy
        self.B2 += dy
        self.T2 += dy

        self.upd()
class BLF:
    __slots__ = "color", "text", "size", "x", "y", "name"
    def __init__(self, color=None, text="", size=0, x=0, y=0):
        self.color  = color
        self.size   = size
        self.x      = x
        self.y      = y
        self.text   = text

    def set_color(self):        blf_color(font_0, *self.color)
    def set_size(self):         blf_size(font_0, self.size)
    def set_pos(self):          blf_pos(font_0, self.x, self.y, 0)
    def set_pos_by(self, x, y): blf_pos(font_0, x, y, 0)
    def set_wrap(self, w):      blf.word_wrap(font_0, w)
    def enable(self, e=blf.WORD_WRAP):      blf.enable(font_0, e)
    def disable(self, e=blf.WORD_WRAP):     blf.disable(font_0, e)
    def draw(self):         blf_draw(font_0, self.text)
    def draw_pos(self):     blf_pos(font_0, self.x, self.y, 0)  ;blf_draw(font_0, self.text)
    def draw_pos_by_x(self, x):  blf_pos(font_0, x, self.y, 0)  ;blf_draw(font_0, self.text)
    def draw_color_pos(self):
        blf_color(font_0, *self.color)
        blf_pos(font_0, self.x, self.y, 0)
        blf_draw(font_0, self.text)
    def set_draw(self):
        blf_color(font_0, *self.color)
        blf_size(font_0, self.size)
        blf_pos(font_0, self.x, self.y, 0)
        blf_draw(font_0, self.text)
    def set_draw_id(self, font_id):
        blf_color(font_id, *self.color)
        blf_size(font_id, self.size)
        blf_pos(font_id, self.x, self.y, 0)
        blf_draw(font_id, self.text)
    def R_nth_x(self, i):
        return self.x + blf_dimen(font_0, self.text[0:i])[0]
    def R_nth_y(self, i):
        return self.y - blf_dimen(font_0, self.text[0:i])[1]
    def R_end_x(self):
        return self.x + blf_dimen(font_0, self.text)[0]
    def R_end_y(self):
        return self.y + blf_dimen(font_0, self.text)[1]
    def R_dimen(self):          return blf_dimen(font_0, self.text)[0]
    def R_dimen_y(self):        return blf_dimen(font_0, self.text)[1]
    def R_nth_dimen(self, i):   return blf_dimen(font_0, self.text[0:i])[0]
    def R_nth_dimen_y(self, i): return blf_dimen(font_0, self.text[0:i])[1]
    def R_ind_pos(self, mou_x):
        len_text = len(self.text)
        if len_text == 0:   return len_text, self.R_end_x()

        i = [0, len_text -1]
        while True:
            if i[0] == i[1]:
                i_0 = i[0] - 1  ; i_2 = i[0] + 1
                if i_0 < 0: i_0 = 0
                i_0_pos = self.R_nth_x(i_0)     ; i_1_pos = self.R_nth_x(i[0])
                d0 = abs(mou_x - i_0_pos)       ; d1 = abs(mou_x - i_1_pos)
                if i_2 >= len_text:     i_2_pos = self.R_end_x()
                else:                   i_2_pos = self.R_nth_x(i_2)
                d2 = abs(mou_x - i_2_pos)       ; min_dx = min(d0, d1, d2)
                if min_dx == d0:    return i_0, i_0_pos
                elif min_dx == d1:  return i[0], i_1_pos
                else:               return i_2, i_2_pos

            ind = (i[1] + i[0]) // 2
            if mou_x < self.R_nth_x(ind):
                i[1] = ind -1
                if i[1] < i[0]:     i[1] = i[0]
            else:
                if i[0] == ind:     i[0] = i[1]
                else:   i[0] = ind
    def R_ind(self, mou_x):
        len_text = len(self.text)
        if len_text == 0:   return len_text

        i = [0, len_text -1]
        while True:
            if i[0] == i[1]:
                i_0 = i[0] - 1  ; i_2 = i[0] + 1
                if i_0 < 0: i_0 = 0
                i_0_pos = self.R_nth_x(i_0)     ; i_1_pos = self.R_nth_x(i[0])
                d0 = abs(mou_x - i_0_pos)       ; d1 = abs(mou_x - i_1_pos)
                if i_2 >= len_text:     i_2_pos = self.R_end_x()
                else:                   i_2_pos = self.R_nth_x(i_2)
                d2 = abs(mou_x - i_2_pos)       ; min_dx = min(d0, d1, d2)
                if min_dx == d0:    return i_0
                elif min_dx == d1:  return i[0]
                else:               return i_2

            ind = (i[1] + i[0]) // 2
            if mou_x < self.R_nth_x(ind):
                i[1] = ind -1
                if i[1] < i[0]:     i[1] = i[0]
            else:
                if i[0] == ind:     i[0] = i[1]
                else:   i[0] = ind
    def R_x_by_cx(self, cx):    return cx - blf_dimen(font_0, self.text)[0] // 2
    def R_y_by_cy(self, cy):    return cy - blf_dimen(font_0, self.text)[1] // 2
    def set_x_by_bo(self, e):
        self.x = e.R_center_x() - blf_dimen(font_0, self.text)[0] // 2 - F[1]
    def set_y_by_bo(self, e):
        self.y = e.R_center_y() - blf_dimen(font_0, self.text)[1] // 2
    def set_x_by_bo_float(self, e):
        self.x = e.R_center_x_float() - blf_dimen(font_0, self.text)[0] / 2 - F[1]
    def set_y_by_bo_float(self, e):
        self.y = e.R_center_y_float() - blf_dimen(font_0, self.text)[1] / 2
    def set_xy_by_bo(self, e):
        self.x = e.R_center_x() - blf_dimen(font_0, self.text)[0] // 2
        self.y = e.R_center_y() - blf_dimen(font_0, self.text)[1] // 2
    def set_xy_by_bo_float(self, e):
        self.x = e.R_center_x_float() - blf_dimen(font_0, self.text)[0] / 2
        self.y = e.R_center_y_float() - blf_dimen(font_0, self.text)[1] / 2
    def align_R_float(self, R):
        self.x += R - self.x - blf_dimen(font_0, self.text)[0]
    def align_R(self, R):
        self.x += R - self.x - round(blf_dimen(font_0, self.text)[0])
    def fix_long_text(self, lim, dx):
        if self.R_end_x() > lim:
            self.text = self.text[:self.R_ind(lim - dx)] + " ‧‧"
    def fix_long_text_by_x(self, x, lim, dx):
        if x + blf_dimen(font_0, self.text)[0] > lim:
            self.x = x
            self.text = self.text[:self.R_ind(lim - dx)] + " ‧‧"
    def fix_long_text_L(self, lim, dx):
        if self.x >= lim: return
        self.text = "‧‧ " + self.text[self.R_ind(lim + dx):]
    def dxy(self, dx, dy):
        self.x += dx
        self.y += dy
    def xy(self, x, y):
        self.x = x
        self.y = y
    def xys(self, x, y, s):
        self.x = x
        self.y = y
        self.size = s
    def LBs(self, e, dx, dy, s):
        self.x = e.L + dx
        self.y = e.B + dy
        self.size = s
    def LB(self, e, dx, dy):
        self.x = e.L + dx
        self.y = e.B + dy
    def LT(self, e, dx, dy):
        self.x = e.L + dx
        self.y = e.T - dy
    def color_tx(self, color, tx):
        self.color = color
        self.text = tx
    def copy(self, e):
        self.x      = e.x
        self.y      = e.y
        self.size   = e.size
        self.text   = e.text
        self.color  = e.color
class LINE_H:
    __slots__ = "color", "L", "R", "y", "bat"
    def __init__(self, color=None, L=0, R=0, y=0):
        self.color  = color
        self.L      = L
        self.R      = R
        self.y      = y
    def upd(self):
        self.bat = batch_for_shader(
            shader2D, 'LINE_STRIP', {"pos": ((self.L, self.y), (self.R, self.y))})
    def upd_bat(self, L, R, y):
        self.bat = batch_for_shader(shader2D, 'LINE_STRIP', {"pos": ((L, y), (R, y))})
    def bind(self):     BIND() ; UNFL("color", self.color)
    def draw(self):     self.bat.draw(shader2D)
    def bind_draw(self):
        BIND() ; UNFL("color", self.color)
        self.bat.draw(shader2D)
class CANVAS:
    __slots__ = "x", "y", "lim_x", "lim_y", "R_w", "R_h"
    def __init__(self, x=0, y=0, lim_x=0, lim_y=0):
        self.x = x
        self.y = y
        self.lim_x = lim_x
        self.lim_y = lim_y

    def dx(self, x):
        self.x += x
        if self.x < 0:  self.x = 0
        elif self.x > self.lim_x:   self.x = self.lim_x
    def dy(self, y):
        self.y += y
        if self.y < 0:  self.y = 0
        elif self.y > self.lim_y:   self.y = self.lim_y
    def dxy(self, x, y):
        self.x += x
        if self.x < 0:  self.x = 0
        elif self.x > self.lim_x:   self.x = self.lim_x
        self.y += y
        if self.y < 0:  self.y = 0
        elif self.y > self.lim_y:   self.y = self.lim_y
    def set_pos(self, x, y):
        self.pos_x = x
        self.pos_y = y
class CANVAS_Y:
    __slots__ = "L", "R", "B", "T", "color", "bat"
    def __init__(self, color=None, L=0, R=0, B=0, T=0, bat=None):
        self.L = L
        self.R = R
        self.B = B
        self.T = T
        self.color = color
        self.bat = bat
    def upd(self):
        self.bat = batch_for_shader(shader2D, 'TRIS', {"pos": (
            (self.L,self.B),(self.L,self.T),
            (self.R,self.T),(self.R,self.B))}, indices=indices_box
        )
    def draw(self): self.bat.draw(shader2D)
    def bind(self): BIND() ; UNFL("color", self.color)
    def bind_draw(self):
        BIND() ; UNFL("color", self.color)
        self.bat.draw(shader2D)
    def LRBT(self, L, R, B, T):
        self.L = L ; self.R = R ; self.B = B ; self.T = T
    def inbox(self, evt):
        return self.L <= evt.mouse_region_x <= self.R and self.B <= evt.mouse_region_y <= self.T
    def inbox_xy(self, x, y):
        return self.L <= x <= self.R and self.B <= y <= self.T
    def dxy(self, dx, dy):
        self.L += dx  ; self.R += dx  ; self.B += dy  ; self.T += dy
    def dxy_upd(self, dx, dy):  self.dxy(dx, dy)  ; self.upd()
    def dx(self, dx):           self.L += dx  ; self.R += dx
    def dx_upd(self, dx):       self.L += dx  ; self.R += dx  ; self.upd()
    def dy(self, dy):           self.B += dy  ; self.T += dy
    def dy_upd(self, dy):       self.B += dy  ; self.T += dy  ; self.upd()

    def R_w(self):  return self.R - self.L
    def R_h(self):  return self.T - self.B
    def R_center_x(self):   return self.L + (self.R - self.L) // 2
    def R_center_y(self):   return self.B + (self.T - self.B) // 2
    def R_center_x_float(self):   return self.L + (self.R - self.L) / 2
    def R_center_y_float(self):   return self.B + (self.T - self.B) / 2
class SCISSOR:
    __slots__ = "x", "y", "w", "h"
    def __init__(self, x=0, y=0, w=0, h=0):
        self.x = x
        self.y = y
        self.w = w
        self.h = h

    def LRBT(self, L, R, B, T):
        self.x = L ; self.y = B ; self.w = R-L ; self.h = T-B
    def box(self, bo):  self.LRBT(bo.L, bo.R, bo.B, bo.T)
    def box_round(self, bo):
        self.LRBT(math_ceil(bo.L), math_floor(bo.R), math_ceil(bo.B), math_floor(bo.T))
    def ENABLE(self):
        ENABLE_SCISSOR()
        scissor_set(self.x, self.y, self.w, self.h)
    def use(self):  scissor_set(self.x, self.y, self.w, self.h)
    def DISABLE(self):
        DISABLE_SCISSOR()
    def dxy(self, dx, dy): self.x += dx ; self.y += dy
    def R_R(self): return self.x + self.w
    def R_T(self): return self.y + self.h
    def inbox(self, evt):
        if evt.mouse_region_x <= self.x:             return False
        if evt.mouse_region_y <= self.y:             return False
        if evt.mouse_region_y >= self.y + self.h:    return False
        if evt.mouse_region_x >= self.x + self.w:    return False
        return True
    def inbox_xy(self, x, y):
        if x <= self.x:             return False
        if y <= self.y:             return False
        if y >= self.y + self.h:    return False
        if x >= self.x + self.w:    return False
        return True
class SELBOX:
    __slots__ = "rim", "bg"
    def __init__(self, L, R, B, T):
        d = F[1]
        self.rim = RIM(P.color_selbox_rim, L-d, R+d, B-d, T+d, L, R, B, T)
        self.bg = BOX(P.color_selbox, L, R, B, T)
        self.rim.upd()
        self.bg.upd()
    def U_draw(self):
        BLEND()
        self.rim.bind_draw()
        self.bg.bind_draw()
    def dxy_RB(self, x, y):
        r = self.rim
        b = self.bg
        b.B += y
        b.R += x
        r.B += y
        r.R += x
        r.B2 += y
        r.R2 += x
    def dxy_upd_RB(self, x, y):
        r = self.rim
        b = self.bg
        b.B += y
        b.R += x
        r.B += y
        r.R += x
        r.B2 += y
        r.R2 += x

        r.upd()
        b.upd()
    def dy_T(self, y):
        r = self.rim
        b = self.bg
        b.T += y
        r.T += y
        r.T2 += y
    def dy_upd_T(self, y):
        r = self.rim
        b = self.bg
        b.T += y
        r.T += y
        r.T2 += y

        r.upd()
        b.upd()
class BOX_FAKE:
    __slots__ = "L", "R", "B", "T"
    def __init__(self):
        self.L = 0.0
        self.R = 0.0
        self.B = 0.0
        self.T = 0.0
    def draw(self): pass
    def bind_draw(self): pass
    def upd(self): pass
    def dxy_upd(self, x, y): pass
    def dxy(self, x, y): pass
    def inbox(self, evt): return False

vertex_shader_shade = '''
    uniform mat4 winMat;

    in vec2 position;
    out vec2 pos;

    void main(){
        pos = position;
        gl_Position = winMat * vec4(position, 0.0, 1.0);
    }
'''

fragment_shader_shade = '''
    uniform vec4 color;
    uniform vec4 LRBT;
    uniform float d;

    in vec2 pos;
    out vec4 FragColor;

    float a = color[3];

    void main(){
        if (pos[0] < LRBT[0]){
            a *= (d - LRBT[0] + pos[0]) / d;
        }else{
            if (pos[0] > LRBT[1]){
                a *= (d - pos[0] + LRBT[1]) / d;
            }
        }
        if (pos[1] < LRBT[2]){
            a *= (d - LRBT[2] + pos[1]) / d;
        }else{
            if (pos[1] > LRBT[3]){
                a *= (d - pos[1] + LRBT[3]) / d;
            }
        }
        FragColor = vec4(color[0], color[1], color[2], a);
    }
'''

fragment_shader_picker_H0 = '''
    uniform vec4 LRBT;
    uniform float HUE;

    in vec2 pos;
    out vec4 FragColor;

    float L = LRBT[0] + 1.0;
    float B = LRBT[2] + 1.0;
    float s = (pos[0] - L) / (LRBT[1] - 1.0 - L);
    float v = (pos[1] - B) / (LRBT[3] - 1.0 - B);

    float r;
    float g;
    float b;

    float A[256] = float[](
        0.0,2.16e-05,4.33e-05,6.5e-05,
        8.6e-05,0.0001083,0.00012207030886202119,0.00023,
        0.00033,0.00042724607919808477,0.00058,0.0007324218458961695,
        0.001037597598042339,0.001342773379292339,0.0015,0.001647949160542339,
        0.001953124941792339,0.002258300664834678,0.002868652227334678,0.003173828008584678,
        0.003540038946084678,0.003845214727334678,0.004211425548419356,0.005004882579669356,
        0.005371093517169356,0.005859374767169356,0.006286620860919356,0.006713866954669356,
        0.007202148204669356,0.008300780784338713,0.008850097190588713,0.009399413596838713,
        0.010009765159338713,0.010620116721838713,0.011230468284338713,0.012695312034338713,
        0.013305663596838713,0.014038085471838713,0.014892577659338713,0.015624999534338713,
        0.016357420943677425,0.017211913131177425,0.018066405318677425,0.019775389693677425,
        0.020751952193677425,0.021728514693677425,0.022705077193677425,0.023681639693677425,
        0.024658202193677425,0.025634764693677425,0.026855467818677425,0.027832030318677425,
        0.030029295943677425,0.031249999068677425,0.03247070126235485,0.03369140438735485,
        0.03491210751235485,0.03613281063735485,0.03759765438735485,0.03881835751235485,
        0.04028320126235485,0.04150390438735485,0.04443359188735485,0.04589843563735485,
        0.04736327938735485,0.04882812313735485,0.05053710751235485,0.05200195126235485,
        0.05371093563735485,0.05517577938735485,0.05712890438735485,0.05859374813735485,
        0.06054687313735485,0.06201171688735485,0.0639648400247097,0.0673828087747097,
        0.0693359337747097,0.0712890587747097,0.0732421837747097,0.0751953087747097,
        0.0771484337747097,0.0791015587747097,0.0810546837747097,0.0834960900247097,
        0.0854492150247097,0.0874023400247097,0.0898437462747097,0.0917968712747097,
        0.0942382775247097,0.0964355431497097,0.0986328087747097,0.1035156212747097,
        0.1059570275247097,0.1083984337747097,0.1108398400247097,0.1132812462747097,
        0.1157226525247097,0.1181640587747097,0.1210937462747097,0.1235351525247097,
        0.1259765550494194,0.1289062425494194,0.1313476487994194,0.1342773362994194,
        0.1372070237994194,0.1396484300494194,0.1425781175494194,0.1455078050494194,
        0.1484374925494194,0.1513671800494194,0.1542968675494194,0.1572265550494194,
        0.1606445237994194,0.1669921800494194,0.1699218675494194,0.1728515550494194,
        0.1762695237994194,0.1796874925494194,0.1826171800494194,0.1860351487994194,
        0.1894531175494194,0.1928710862994194,0.1962890550494194,0.1997070237994194,
        0.2031249925494194,0.2070312425494194,0.2104492112994194,0.2138671800494194,
        0.2177734300494194,0.2216796800494194,0.2250976487994194,0.2285156175494194,
        0.2324218675494194,0.2363281175494194,0.2402343675494194,0.2441406175494194,
        0.2480468675494194,0.2519531100988388,0.2558593600988388,0.2602538913488388,
        0.2646484225988388,0.2685546725988388,0.2724609225988388,0.2763671725988388,
        0.2812499850988388,0.2851562350988388,0.289555,0.2939452975988388,
        0.2983398288488388,0.3027343600988388,0.307135,0.3115234225988388,
        0.3164062350988388,0.320805,0.3251952975988388,0.330085,
        0.3349609225988388,0.3398437350988388,0.3447265475988388,0.3486327975988388,
        0.3583984225988388,0.360845,0.3632812350988388,0.36866,
        0.3740234225988388,0.37891,0.3837890475988388,0.3945312350988388,
        0.39698,0.3994140475988388,0.4042968600988388,0.40967,
        0.4150390475988388,0.4208984225988388,0.4316406100988388,0.4365234225988388,
        0.4423827975988388,0.44532,0.4482421725988388,0.4531249850988388,
        0.4589843600988388,0.4648437350988388,0.47071,0.4765624850988388,
        0.48243,0.4882812350988388,0.494145,0.4999999850988388,
        0.50574,0.5114745795726776,0.517825,0.5241698920726776,
        0.5300292670726776,0.53638,0.5427245795726776,0.549075,
        0.5554198920726776,0.5612792670726776,0.5681152045726776,0.5739745795726776,
        0.5808105170726776,0.5876464545726776,0.5935058295726776,0.6003417670726776,
        0.6071777045726776,0.6140136420726776,0.6208495795726776,0.6267089545726776,
        0.6345214545726776,0.6403808295726776,0.6481933295726776,0.6550292670726776,
        0.6618652045726776,0.6687011420726776,0.6755370795726776,0.6833495795726776,
        0.6901855170726776,0.6970214545726776,0.7048339545726776,0.7126464545726776,
        0.7194823920726776,0.7263183295726776,0.7341308295726776,0.7419433295726776,
        0.7497558295726776,0.7565917670726776,0.7644042670726776,0.7712402045726776,
        0.7790527045726776,0.7868652045726776,0.7946777045726776,0.8024902045726776,
        0.8064,0.8103027045726776,0.8181152045726776,0.8269042670726776,
        0.8347167670726776,0.8435058295726776,0.8513183295726776,0.8591308295726776,
        0.8747558295726776,0.8845214545726776,0.8923339545726776,0.896245,
        0.9001464545726776,0.9089355170726776,0.9177245795726776,0.9255370795726776,
        0.9343261420726776,0.9431152045726776,0.9606933295726776,0.9646,
        0.9685058295726776,0.9782714545726776,0.9860839545726776,0.9958495795726776
    );

    void main()
    {
        if (s != 0.0) {
            int i = int (HUE * 6.0);
            float f = HUE * 6.0 - i;
            float p = v * (1.0 - s);
            float q = v * (1.0 - s * f);
            float t = v * (1.0 - s * (1.0 - f));
            i %= 6;

            if (i == 0){        r = v; g = t; b = p;
            } else if (i == 1){ r = q; g = v; b = p;
            } else if (i == 2){ r = p; g = v; b = t;
            } else if (i == 3){ r = p; g = q; b = v;
            } else if (i == 4){ r = t; g = p; b = v;
            } else {            r = v; g = p; b = q;
            }
        }

        FragColor = vec4(A[int(r*255)], A[int(g*255)], A[int(b*255)], 1.0);
    }
'''
fragment_shader_picker_H1 = '''
    uniform vec4 LRBT;

    in vec2 pos;
    out vec4 FragColor;

    float T = LRBT[3] - 1.0;
    float y = 6*(pos[1] - T)/(T - LRBT[2] + 1.0) + 6;
    float r;
    float g;
    float b;

    float A[256] = float[](
        0.0,2.16e-05,4.33e-05,6.5e-05,
        8.6e-05,0.0001083,0.00012207030886202119,0.00023,
        0.00033,0.00042724607919808477,0.00058,0.0007324218458961695,
        0.001037597598042339,0.001342773379292339,0.0015,0.001647949160542339,
        0.001953124941792339,0.002258300664834678,0.002868652227334678,0.003173828008584678,
        0.003540038946084678,0.003845214727334678,0.004211425548419356,0.005004882579669356,
        0.005371093517169356,0.005859374767169356,0.006286620860919356,0.006713866954669356,
        0.007202148204669356,0.008300780784338713,0.008850097190588713,0.009399413596838713,
        0.010009765159338713,0.010620116721838713,0.011230468284338713,0.012695312034338713,
        0.013305663596838713,0.014038085471838713,0.014892577659338713,0.015624999534338713,
        0.016357420943677425,0.017211913131177425,0.018066405318677425,0.019775389693677425,
        0.020751952193677425,0.021728514693677425,0.022705077193677425,0.023681639693677425,
        0.024658202193677425,0.025634764693677425,0.026855467818677425,0.027832030318677425,
        0.030029295943677425,0.031249999068677425,0.03247070126235485,0.03369140438735485,
        0.03491210751235485,0.03613281063735485,0.03759765438735485,0.03881835751235485,
        0.04028320126235485,0.04150390438735485,0.04443359188735485,0.04589843563735485,
        0.04736327938735485,0.04882812313735485,0.05053710751235485,0.05200195126235485,
        0.05371093563735485,0.05517577938735485,0.05712890438735485,0.05859374813735485,
        0.06054687313735485,0.06201171688735485,0.0639648400247097,0.0673828087747097,
        0.0693359337747097,0.0712890587747097,0.0732421837747097,0.0751953087747097,
        0.0771484337747097,0.0791015587747097,0.0810546837747097,0.0834960900247097,
        0.0854492150247097,0.0874023400247097,0.0898437462747097,0.0917968712747097,
        0.0942382775247097,0.0964355431497097,0.0986328087747097,0.1035156212747097,
        0.1059570275247097,0.1083984337747097,0.1108398400247097,0.1132812462747097,
        0.1157226525247097,0.1181640587747097,0.1210937462747097,0.1235351525247097,
        0.1259765550494194,0.1289062425494194,0.1313476487994194,0.1342773362994194,
        0.1372070237994194,0.1396484300494194,0.1425781175494194,0.1455078050494194,
        0.1484374925494194,0.1513671800494194,0.1542968675494194,0.1572265550494194,
        0.1606445237994194,0.1669921800494194,0.1699218675494194,0.1728515550494194,
        0.1762695237994194,0.1796874925494194,0.1826171800494194,0.1860351487994194,
        0.1894531175494194,0.1928710862994194,0.1962890550494194,0.1997070237994194,
        0.2031249925494194,0.2070312425494194,0.2104492112994194,0.2138671800494194,
        0.2177734300494194,0.2216796800494194,0.2250976487994194,0.2285156175494194,
        0.2324218675494194,0.2363281175494194,0.2402343675494194,0.2441406175494194,
        0.2480468675494194,0.2519531100988388,0.2558593600988388,0.2602538913488388,
        0.2646484225988388,0.2685546725988388,0.2724609225988388,0.2763671725988388,
        0.2812499850988388,0.2851562350988388,0.289555,0.2939452975988388,
        0.2983398288488388,0.3027343600988388,0.307135,0.3115234225988388,
        0.3164062350988388,0.320805,0.3251952975988388,0.330085,
        0.3349609225988388,0.3398437350988388,0.3447265475988388,0.3486327975988388,
        0.3583984225988388,0.360845,0.3632812350988388,0.36866,
        0.3740234225988388,0.37891,0.3837890475988388,0.3945312350988388,
        0.39698,0.3994140475988388,0.4042968600988388,0.40967,
        0.4150390475988388,0.4208984225988388,0.4316406100988388,0.4365234225988388,
        0.4423827975988388,0.44532,0.4482421725988388,0.4531249850988388,
        0.4589843600988388,0.4648437350988388,0.47071,0.4765624850988388,
        0.48243,0.4882812350988388,0.494145,0.4999999850988388,
        0.50574,0.5114745795726776,0.517825,0.5241698920726776,
        0.5300292670726776,0.53638,0.5427245795726776,0.549075,
        0.5554198920726776,0.5612792670726776,0.5681152045726776,0.5739745795726776,
        0.5808105170726776,0.5876464545726776,0.5935058295726776,0.6003417670726776,
        0.6071777045726776,0.6140136420726776,0.6208495795726776,0.6267089545726776,
        0.6345214545726776,0.6403808295726776,0.6481933295726776,0.6550292670726776,
        0.6618652045726776,0.6687011420726776,0.6755370795726776,0.6833495795726776,
        0.6901855170726776,0.6970214545726776,0.7048339545726776,0.7126464545726776,
        0.7194823920726776,0.7263183295726776,0.7341308295726776,0.7419433295726776,
        0.7497558295726776,0.7565917670726776,0.7644042670726776,0.7712402045726776,
        0.7790527045726776,0.7868652045726776,0.7946777045726776,0.8024902045726776,
        0.8064,0.8103027045726776,0.8181152045726776,0.8269042670726776,
        0.8347167670726776,0.8435058295726776,0.8513183295726776,0.8591308295726776,
        0.8747558295726776,0.8845214545726776,0.8923339545726776,0.896245,
        0.9001464545726776,0.9089355170726776,0.9177245795726776,0.9255370795726776,
        0.9343261420726776,0.9431152045726776,0.9606933295726776,0.9646,
        0.9685058295726776,0.9782714545726776,0.9860839545726776,0.9958495795726776
    );

    void main()
    {
        if (y <= 1) {
            r = 1.0;
            g = y;
            b = 0.0;
        } else if (y <= 2) {
            r = 2.0 - y;
            g = 1.0;
            b = 0.0;
        } else if (y <= 3) {
            r = 0.0;
            g = 1.0;
            b = y - 2.0;
        } else if (y <= 4) {
            r = 0.0;
            g = 4.0 - y;
            b = 1.0;
        } else if (y <= 5) {
            r = y - 4.0;
            g = 0.0;
            b = 1.0;
        } else {
            r = 1.0;
            g = 0.0;
            b = 6.0 - y;
        }

        FragColor = vec4(A[int(r*255)], A[int(g*255)], A[int(b*255)], 1.0);
    }
'''
fragment_shader_gamma = '''
    uniform vec4 color;

    in vec2 pos;
    out vec4 FragColor;

    void main(){
        FragColor = color;
    }
'''


shader_SHADE = GPUShader(vertex_shader_shade, fragment_shader_shade)
shader_SHADE_BIND = shader_SHADE.bind
shader_SHADE_UNFL = shader_SHADE.uniform_float

shader_PICKER_H0 = GPUShader(vertex_shader_shade, fragment_shader_picker_H0)
shader_PICKER_H0_BIND = shader_PICKER_H0.bind
shader_PICKER_H0_UNFL = shader_PICKER_H0.uniform_float

shader_PICKER_H1 = GPUShader(vertex_shader_shade, fragment_shader_picker_H1)
shader_PICKER_H1_BIND = shader_PICKER_H1.bind
shader_PICKER_H1_UNFL = shader_PICKER_H1.uniform_float

shader_BOX_GAMMA = GPUShader(vertex_shader_shade, fragment_shader_gamma)
shader_BOX_GAMMA_BIND = shader_BOX_GAMMA.bind
shader_BOX_GAMMA_UNFL = shader_BOX_GAMMA.uniform_float

class SHADE:
    __slots__ = "L", "R", "B", "T", "L2", "R2", "B2", "T2", "d", "color", "bat"
    def __init__(self, color):
        self.color = color
    def get_by_rim(self, L, R, B, T, softness, offset, unit):
        self.LRBTd(
            L + offset[0] * unit,
            R + offset[1] * unit,
            B + offset[2] * unit,
            T + offset[3] * unit,
            softness)
    def LRBTd(self, L, R, B, T, d):
        self.L = L
        self.R = R
        self.B = B
        self.T = T
        self.d = d
        self.L2 = L + d
        self.R2 = R - d
        self.B2 = B + d
        self.T2 = T - d
    def upd(self):
        self.bat = batch_for_shader(shader_SHADE, 'TRIS', {"position": (
            (self.L, self.B), (self.L, self.T),
            (self.R, self.T), (self.R, self.B))}, indices=indices_box)
    def draw(self):
        shader_SHADE_BIND()
        shader_SHADE_UNFL("color", self.color)
        shader_SHADE_UNFL("d", self.d)
        shader_SHADE_UNFL("LRBT", (self.L2, self.R2, self.B2, self.T2))
        shader_SHADE_UNFL("winMat", get_projection_matrix())
        self.bat.draw(shader_SHADE)
    def dxy(self, x, y):
        self.L += x
        self.R += x
        self.B += y
        self.T += y
        self.L2 += x
        self.R2 += x
        self.B2 += y
        self.T2 += y
    def dxy_upd(self, x, y):
        self.L += x
        self.R += x
        self.B += y
        self.T += y
        self.L2 += x
        self.R2 += x
        self.B2 += y
        self.T2 += y
        self.bat = batch_for_shader(shader_SHADE, 'TRIS', {"position": (
            (self.L, self.B), (self.L, self.T),
            (self.R, self.T), (self.R, self.B))}, indices=indices_box)
class PICKER_H0:
    __slots__ = "L", "R", "B", "T", "bat", "hue"
    def __init__(self):
        self.hue = 0.0
    def LRBT(self, L, R, B, T):
        self.L = L
        self.R = R
        self.B = B
        self.T = T
    def LRBT_upd(self, L, R, B, T):
        self.L = L
        self.R = R
        self.B = B
        self.T = T
        self.bat = batch_for_shader(shader_PICKER_H0, 'TRIS', {"position": (
            (self.L, self.B), (self.L, self.T),
            (self.R, self.T), (self.R, self.B))}, indices=indices_box)
    def dxy_upd(self, x, y):
        self.L += x
        self.R += x
        self.B += y
        self.T += y
        self.bat = batch_for_shader(shader_PICKER_H0, 'TRIS', {"position": (
            (self.L, self.B), (self.L, self.T),
            (self.R, self.T), (self.R, self.B))}, indices=indices_box)
    def draw(self):
        shader_PICKER_H0_BIND()
        shader_PICKER_H0_UNFL("LRBT", (self.L, self.R, self.B, self.T))
        shader_PICKER_H0_UNFL("HUE", self.hue)
        shader_PICKER_H0_UNFL("winMat", get_projection_matrix())
        self.bat.draw(shader_PICKER_H0)
class PICKER_H1:
    __slots__ = "L", "R", "B", "T", "bat"
    def LRBT(self, L, R, B, T):
        self.L = L
        self.R = R
        self.B = B
        self.T = T
    def LRBT_upd(self, L, R, B, T):
        self.L = L
        self.R = R
        self.B = B
        self.T = T
        self.bat = batch_for_shader(shader_PICKER_H1, 'TRIS', {"position": (
            (self.L, self.B), (self.L, self.T),
            (self.R, self.T), (self.R, self.B))}, indices=indices_box)
    def dxy_upd(self, x, y):
        self.L += x
        self.R += x
        self.B += y
        self.T += y
        self.bat = batch_for_shader(shader_PICKER_H1, 'TRIS', {"position": (
            (self.L, self.B), (self.L, self.T),
            (self.R, self.T), (self.R, self.B))}, indices=indices_box)
    def draw(self):
        shader_PICKER_H1_BIND()
        shader_PICKER_H1_UNFL("LRBT", (self.L, self.R, self.B, self.T))
        shader_PICKER_H1_UNFL("winMat", get_projection_matrix())
        self.bat.draw(shader_PICKER_H1)
class BOX_C(BOX):
    __slots__ = ()
    def upd(self):
        self.bat = batch_for_shader(shader_BOX_GAMMA, 'TRIS', {"position": (
            (self.L,self.B),(self.L,self.T),
            (self.R,self.T),(self.R,self.B))}, indices=indices_box
        )
    def upd_bat(self, L, R, B, T):
        self.bat = batch_for_shader(shader_BOX_GAMMA, 'TRIS', {"pos": (
            (L,B),(L,T),
            (R,T),(R,B))}, indices=indices_box
        )
    def draw(self): self.bat.draw(shader_BOX_GAMMA)
    def bind(self):
        shader_BOX_GAMMA_BIND()
        shader_BOX_GAMMA_UNFL("color", self.color)
        shader_BOX_GAMMA_UNFL("winMat", get_projection_matrix())
    def bind_color(self, c):
        shader_BOX_GAMMA_BIND()
        shader_BOX_GAMMA_UNFL("color", c)
        shader_BOX_GAMMA_UNFL("winMat", get_projection_matrix())
    def bind_draw(self):
        shader_BOX_GAMMA_BIND()
        shader_BOX_GAMMA_UNFL("color", self.color)
        shader_BOX_GAMMA_UNFL("winMat", get_projection_matrix())
        self.bat.draw(shader_BOX_GAMMA)
    def R_copy(self):   return BOX_C(self.color, self.L, self.R, self.B, self.T)


def set_W_act(w):
    global W_D, W_act, is_outside
    if W_act != None:   W_act.unact()
    W_act = w
    is_outside = False
    W_D.remove(w)  ;W_D.append(w)
    W_M.remove(w)  ;W_M.append(w)

is_upd_data         = False
is_upd_data_pre     = True
U_release_fn        = N
def I_press():
    global U_press, U_release
    U_press     = N
    U_release   = I_release
def I_release():
    global U_press, U_release
    U_release   = N
    U_press     = I_press
    U_release_fn()
def I_upd_data():
    global is_upd_data
    is_upd_data = False
    update_state.clear()
    update_state["state"] = True
    for e in W_M: e.upd_data()
    update_state["state"] = False
def upd_enable():
    global is_upd_data_pre
    is_upd_data_pre = True
#
def upd_disable():
    global is_upd_data_pre
    is_upd_data_pre = False
def power_upd():
    prefs.U_upd_pos = N
    e = bpy.context.workspace.tm_pref
    e.win_pos[0] = e.win_pos[0]
    prefs.U_upd_pos = prefs.I_upd_pos
def refresh():
    update_state.clear()
    update_state["state"] = True
    for e in W_M: e.upd_data()
    update_state["state"] = False

def data_upd_han(dummy):
    if is_upd_data_pre:
        global is_upd_data
        is_upd_data = True
        redraw()
#

def kill_admin():
    bpy.context.window.cursor_modal_restore()

    if M.TIMER is not None:
        bpy.context.window_manager.event_timer_remove(M.TIMER)
        M.TIMER = None
    global han_draw, U_press, U_release, admin

    if data_upd_han in depsgraph_update_post:   depsgraph_update_post.remove(data_upd_han)
    if data_upd_han in frame_change_post:       frame_change_post.remove(data_upd_han)

    bpy.types.SpaceView3D.draw_handler_remove(han_draw, 'WINDOW')
    han_draw    = None
    admin       = None
    U_press     = N
    U_release   = N
    pref_off()
#
def call_admin():
    if P is None: bl_start_up()
    if admin == None:
        bpy.ops.object.m_operator('INVOKE_DEFAULT')
        return

    try:    admin.tb
    except:
        M.st_modal_end()
        bpy.ops.object.m_operator('INVOKE_DEFAULT')

    if not W_A:       pref_on()

def I_draw_3D():
    if bpy.context.area == AREA:
        # global last_time
        # new_time = time.time()
        # print(new_time - last_time)
        # last_time = new_time
        if is_upd_data: I_upd_data()
        for e in W_D:   e.U_draw()
        admin.tb.U_draw()
U_draw_3D = I_draw_3D
def draw_3D():
    try:    admin.tb
    except:
        M.st_modal_end()
#
    U_draw_3D()
def draw_disable(draw_fn = N):
    global U_draw_3D
    U_draw_3D = draw_fn
def draw_enable():
    global U_draw_3D
    U_draw_3D = I_draw_3D


def IR_org_pos(rim, ti_h):      return rim.L, rim.T
def IR_protect_pos(rim, ti_h):
    bor_B   = admin.tb.bo["bg"].T + ti_h

    if rim.R < region_data.L + ti_h * 4:    x = rim.L + region_data.L + ti_h * 4 - rim.R
    elif rim.L > region_data.R - ti_h:      x = region_data.R - ti_h
    else: x = rim.L

    if rim.T < bor_B:                       y = bor_B
    elif rim.T > region_data.T:             y = region_data.T
    else: y = rim.T
    return x, y
def R_protect_dxy_LT(rim, ti_h):
    x, y = IR_protect_pos(rim, ti_h)
    return x - rim.L, y - rim.T
def R_full_protect_dxy(L, R, B, T):
    dx = 0
    dy = 0
    if R > region_data.R:           dx = region_data.R - R
    elif L < region_data.L:         dx = region_data.L - L
    if T > region_data.T:           dy = region_data.T - T
    elif B < admin.tb.bo["bg"].T:   dy = admin.tb.bo["bg"].T - B
    return dx, dy


class EVT:
    __slots__ = ()
    press = {}

    pre_release = {}
    release_true = {}

    pre_drag = {}
    drag_true = {}

    pre_hold = {}
    hold_true = {}
    hold_checking = {}

    dou_true = {}
    dou_checking = {}

    @classmethod
    def clear_release_true(cls):    cls.release_true.clear()
    @classmethod
    def clear_drag_true(cls):       cls.drag_true.clear()
    @classmethod
    def clear_hold_true(cls):       cls.hold_true.clear()

    @classmethod
    def kill(cls):
        cls.press.clear()
        cls.drag_true.clear()
        cls.hold_true.clear()
        cls.release_true.clear()
        cls.pre_release.clear()
        cls.pre_drag.clear()
        cls.pre_hold.clear()
        for e in cls.hold_checking.values():    thread_unreg(e)
        cls.hold_checking.clear()
        for e in cls.dou_checking.values():     thread_unreg(e)
        cls.dou_checking.clear()
        cls.auto_clear = {}
    @classmethod
    def kill_except(cls, evt):
        li = cls.press
        if evt.ctrl:
            LEFT_CTRL   = 'LEFT_CTRL' in li
            RIGHT_CTRL  = 'RIGHT_CTRL' in li
        else:
            LEFT_CTRL   = False
            RIGHT_CTRL  = False
        if evt.shift:
            LEFT_SHIFT  = 'LEFT_SHIFT' in li
            RIGHT_SHIFT = 'RIGHT_SHIFT' in li
        else:
            LEFT_SHIFT  = False
            RIGHT_SHIFT = False
        if evt.alt:
            LEFT_ALT    = 'LEFT_ALT' in li
            RIGHT_ALT   = 'RIGHT_ALT' in li
        else:
            LEFT_ALT    = False
            RIGHT_ALT   = False
        if evt.oskey:
            OSKEY       = 'OSKEY' in li
        else:
            OSKEY       = False

        cls.kill()
        if LEFT_CTRL:   li['LEFT_CTRL'] = None
        if RIGHT_CTRL:  li['RIGHT_CTRL'] = None
        if LEFT_SHIFT:  li['LEFT_SHIFT'] = None
        if RIGHT_SHIFT: li['RIGHT_SHIFT'] = None
        if LEFT_ALT:    li['LEFT_ALT'] = None
        if RIGHT_ALT:   li['RIGHT_ALT'] = None
        if OSKEY:       li['OSKEY'] = None

    @classmethod
    def I_ENABLE_evt(cls):
        cls.U_get_evt       = cls.get_evt
        cls.U_ENABLE_evt    = N
        cls.U_DISABLE_evt   = cls.I_DISABLE_evt
        cls.auto_clear      = {}
    @classmethod
    def I_DISABLE_evt(cls):
        cls.U_get_evt       = N
        cls.U_ENABLE_evt    = cls.I_ENABLE_evt
        cls.U_DISABLE_evt   = N
        cls.auto_clear      = {}

    @classmethod
    def get_evt(cls, evt):
        if evt.type == 'WINDOW_DEACTIVATE':     cls.kill()  ;return
        cls.evt = evt
        if cls.auto_clear:
            for e in cls.auto_clear:  e()

        if evt.value == 'PRESS':
            if evt.type in keys.dict_type:  cls.press[evt.type] = None
            elif evt.type in keys.non_release:
                cls.press[evt.type] = None
                evt_type = evt.type
                def clear_fn():
                    if evt_type in EVT.press:   del EVT.press[evt_type]
                cls.auto_clear[clear_fn] = None
        elif evt.value == 'RELEASE':
            k = evt.type
            if k in cls.press:   del cls.press[k]
            cls.pre_drag.clear()
            for k in cls.hold_checking: thread_unreg(cls.hold_checking[k])
            cls.hold_checking.clear()

        if cls.pre_release:
            for k in cls.pre_release.copy():
                if k.ll == None:
                    if k.type0 not in cls.press:
                        del cls.pre_release[k]
                        cls.release_true[k] = None
                        cls.auto_clear[cls.clear_release_true] = None
                    elif k.type1 != False and k.type1 not in cls.press:
                        del cls.pre_release[k]
                        cls.release_true[k] = None
                        cls.auto_clear[cls.clear_release_true] = None
                    elif k.type2 != False and k.type2 not in cls.press:
                        del cls.pre_release[k]
                        cls.release_true[k] = None
                        cls.auto_clear[cls.clear_release_true] = None
                    elif k.type3 != False and k.type3 not in cls.press:
                        del cls.pre_release[k]
                        cls.release_true[k] = None
                        cls.auto_clear[cls.clear_release_true] = None
                elif k.type0 not in cls.press:
                    if k.type1 not in cls.press:
                        if k.type2 not in cls.press:
                            if k.type3 not in cls.press:
                                del cls.pre_release[k]
                                if not cls.press:
                                    cls.release_true[k] = None
                                    cls.auto_clear[cls.clear_release_true] = None

        if cls.pre_drag:
            for k in cls.pre_drag.copy():
                if max(abs(evt.mouse_x - cls.pre_drag[k][0]),
                abs(evt.mouse_y - cls.pre_drag[k][1])) >= P.th_drag:
                    k.org_x, k.org_y = cls.pre_drag[k][0], cls.pre_drag[k][1]
                    del cls.pre_drag[k]
                    cls.drag_true[k] = None
                    cls.auto_clear[cls.clear_drag_true] = None

        if cls.pre_hold:
            for k in cls.pre_hold.copy():
                del cls.pre_hold[k]
                cls.hold_true[k] = None
                cls.auto_clear[cls.clear_hold_true] = None
        cls.ll_press = len(cls.press)
        # if cls.press:
        #     if evt.value == 'RELEASE':
        #         if evt.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:    cls.kill()
        # print(cls.press, evt.type, evt.value, cls.pre_release, cls.release_true)

class PREF(PropertyGroup):
    __slots__ = ()

    def upd_pos(self, context):         prefs.U_upd_pos()
    def upd_canvas(self, context):      prefs.U_upd_cv()
    win_pos: IntVectorProperty(
        name = "Position: Window", subtype = 'TRANSLATION', min = -65535, max = 65535,
        size = 2, default = (20, 739),
        update = upd_pos)
    win_size: IntVectorProperty(
        name = "Size: Window", subtype = 'TRANSLATION', min = 24, max = 65535,
        size = 2, default = (584, 713),
        update = upd_pos)
    win_canvas_pos: IntVectorProperty(
        name = "Position: Canvas", subtype = 'TRANSLATION', min = 0,
        size = 2, default = (0, 0),
        update = upd_canvas)

class M(Operator):
# ▅▅▅  HEAD                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    __slots__ = (
        'tb',
        'U_modal',
        'window',
        'push_fn',
    )
    bl_idname = "object.m_operator"
    bl_label = "M"
    bl_options = {"INTERNAL"}

    SET_mou_ic = None
    TIMER = None
    is_pass = False

    def invoke(self, context, event):
#
        global redraw, U_release, han_draw, admin, cursor_warp, AREA

        region_data.upd()

        admin           = self
        AREA            = context.area
        redraw          = AREA.tag_redraw
        self.tb         = tb.TB()
        self.U_modal    = self.I_modal

        U_release = I_release
        M.SET_mou_ic = N

        if data_upd_han not in depsgraph_update_post:
            depsgraph_update_post.append(data_upd_han)

        if data_upd_han not in frame_change_post:
            frame_change_post.append(data_upd_han)

        han_draw = bpy.types.SpaceView3D.draw_handler_add(draw_3D, (), 'WINDOW', 'POST_PIXEL')
        self.window = context.window
        cursor_warp = self.window.cursor_warp
        context.window_manager.modal_handler_add(self)
        M.TIMER = None
        EVT.I_ENABLE_evt()
        EVT.kill()
        return {'RUNNING_MODAL'}

    def push_modal(self, push_fn=None):
        self.U_modal = self.I_modal_push
        self.push_fn = push_fn
        if M.TIMER is None:
            M.TIMER = bpy.context.window_manager.event_timer_add(0, window=bpy.context.window)
    def modal_end(self):
        if M.TIMER is not None:
            bpy.context.window_manager.event_timer_remove(M.TIMER)
            M.TIMER = None

        for e in W_M:
            if hasattr(e, "kill_cls"):
                e.kill_cls()

        kill_admin()
        W_A.clear()
        W_D.clear()
        W_M.clear()
        global W_act, is_outside
        W_act = None
        head_modal.clear()
        is_outside = False
        try:    redraw()
        except: pass
    @ staticmethod
    def st_modal_end():
        if M.TIMER is not None:
            bpy.context.window_manager.event_timer_remove(M.TIMER)
            M.TIMER = None

        for e in W_M:
            if hasattr(e, "kill_cls"):
                e.kill_cls()

        kill_admin()
        W_A.clear()
        W_D.clear()
        W_M.clear()
        global W_act, is_outside
        W_act = None
        head_modal.clear()
        is_outside = False

    def modal(self, context, event):
        if context.area is None or context.space_data.region_quadviews:
            if context.area is not None:
                admin.report({'WARNING'}, "This Add-on does not support Quad View in the current version.")
            self.modal_end()
            return {'FINISHED'}

        # debug
        # if evt.type == "F16" and event.value == "RELEASE":
        #     print()

        return self.U_modal(event)
    def I_modal(self, event):
        EVT.U_get_evt(event)

        if event.value == 'PRESS':      U_press()
        elif event.value == 'RELEASE':  U_release()
        for e in reversed(head_modal):
            e(event)
            M.SET_mou_ic()
            return {'RUNNING_MODAL'}

        if M.is_pass is True:
            if K["sys_pass_E0"].true() or K["sys_pass_E1"].true():
                self.end_pass()
                return {'RUNNING_MODAL'}
            else:
                return {'PASS_THROUGH'}
        else:
            if K["sys_pass0"].true() and self.tb.U_draw != N:
                self.to_pass()
                K["sys_pass_E0"].true()
                return {'PASS_THROUGH'}
            if K["sys_pass1"].true() and self.tb.U_draw != N:
                self.to_pass()
                K["sys_pass_E1"].true()
                return {'PASS_THROUGH'}

        self.tb.U_modal(event)
        if self.tb.RET is not None:
            M.SET_mou_ic()
            return self.tb.RET

        for e in reversed(W_M):
            e.U_modal(event)
            if e.RET is not None:
                M.SET_mou_ic()
                if e.RET == 'PASS_THROUGH': EVT.kill()
                return e.RET

        M.SET_mou_ic()
        EVT.kill()
        return {'PASS_THROUGH'}
    def I_modal_push(self, event):
        if self.push_fn is not None: self.push_fn(event)
        self.U_modal = self.I_modal
        if M.TIMER is not None:
            bpy.context.window_manager.event_timer_remove(M.TIMER)
            M.TIMER = None

        EVT.U_get_evt(event)

        if event.value == 'PRESS':      U_press()
        elif event.value == 'RELEASE':  U_release()
        for e in reversed(head_modal):
            e(event)
            M.SET_mou_ic()
            return {'RUNNING_MODAL'}

        self.tb.U_modal(event)
        if self.tb.RET is not None:
            M.SET_mou_ic()
            return self.tb.RET

        for e in reversed(W_M):
            e.U_modal(event)
            if e.RET is not None:
                M.SET_mou_ic()
                if e.RET == 'PASS_THROUGH': EVT.kill()
                return e.RET

        M.SET_mou_ic()
        EVT.kill()
        return {'PASS_THROUGH'}
    def I_modal_progress(self, event):
        EVT.U_get_evt(event)

        if event.value == 'PRESS':      U_press()
        elif event.value == 'RELEASE':  U_release()

        if head_modal:
            head_modal[-1](event)
            M.SET_mou_ic()
            redraw()
            return {'RUNNING_MODAL'}

        e = W_M[-1].U_modal(event)

        M.SET_mou_ic()
        redraw()
        return {'RUNNING_MODAL'}
    def I_modal_fin(self, event):
        self.modal_end()
        return {'FINISHED'}
    def I_modal_restart(self, event):
        self.modal_end()
        call_admin()
        return {'FINISHED'}

    def I_draw_pass(self):
        BLEND()
        self.tb.bo["bg"].bind_draw()
    def to_pass(self):
#
        M.is_pass = True
        draw_disable(self.I_draw_pass)
        try:    redraw()
        except: pass
    def end_pass(self):
#
        M.is_pass = False
        draw_enable()
        EVT.kill()
        try:    redraw()
        except: pass

# ▅▅▅  CLS                         ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    @classmethod
    def U_add_timer(cls, t=0):
        if M.TIMER is None:
            M.TIMER = bpy.context.window_manager.event_timer_add(t, window=bpy.context.window)
    @classmethod
    def U_kill_timer(cls):
        if M.TIMER is None: return
        bpy.context.window_manager.event_timer_remove(M.TIMER)
        M.TIMER = None

    @classmethod
    def ISET_mou_ic(cls):
        cls.SET_mou_ic = N
        bpy.context.window.cursor_modal_set(cls.mou_ic)
    @classmethod
    def RESTORE_mou_ic(cls):
        cls.SET_mou_ic = N
        bpy.context.window.cursor_modal_restore()
    @classmethod
    def set_mou_ic(cls, s):
        cls.mou_ic = s
        cls.SET_mou_ic = cls.ISET_mou_ic
    @classmethod
    def restore_mou_ic(cls):    cls.SET_mou_ic = cls.RESTORE_mou_ic


class FLASH_BOX:
    __slots__ = ()
    bo = BOX()
    U_draw = N

    @classmethod
    def init(cls, L, R, B, T):
        if thread_isreg(flash_box_thread_fn):   thread_unreg(flash_box_thread_fn)
        cls.bo.LRBT(L, R, B, T)
        cls.bo.color = [*P.color_flash_box]
        cls.bo.upd()
        cls.I_change_light()
        cls.U_draw = cls.I_draw
        cls.counter = 0
        thread_reg(flash_box_thread_fn, first_interval=0.04)

    @classmethod
    def kill(cls):
        if thread_isreg(flash_box_thread_fn):
            thread_unreg(flash_box_thread_fn)
#
            cls.U_draw = N
            redraw

    @classmethod
    def I_change_light(cls):
        cls.bo.color[3] = P.color_flash_box[3]
        cls.U_change_color = cls.I_change_dark
        redraw()
    @classmethod
    def I_change_dark(cls):
        cls.bo.color[3] = 0
        cls.U_change_color = cls.I_change_light
        redraw()

    @classmethod
    def I_draw(cls):
        BLEND()
        cls.bo.bind_draw()


def flash_box_thread_fn():
    if FLASH_BOX.counter > 8:
        FLASH_BOX.U_draw = N
        thread_unreg(flash_box_thread_fn)
#
        redraw()
    FLASH_BOX.U_change_color()
    FLASH_BOX.counter += 1
    return 0.04

def modal_pass(*e): return {'PASS_THROUGH'}
def modal_disable(modal_fn = modal_pass):
#
    admin.U_modal = modal_fn
def modal_enable():
#
    admin.U_modal = admin.I_modal

def disable_bpy_upd(): # disable view_layer_update
    global _bpy_view_layer_update
    _bpy_view_layer_update = _BPyOpsSubModOp._view_layer_update
    _BPyOpsSubModOp._view_layer_update = N
def enable_bpy_upd():
    if _BPyOpsSubModOp._view_layer_update == N:
#
        _BPyOpsSubModOp._view_layer_update = _bpy_view_layer_update

def R_calc_attr(ty):
    if ty[0] == "i":
        return "calc_13i"
    else:
        if ty == "float [0,1]":     return "calc_01f"
        elif ty == "float [0,∞]":   return "calc_0if"
        elif ty == "float [0,π]":   return "calc_0pf"
        elif ty in {"float [0,180]", "float [0,360]"}:  return "calc_0df"
        else:
            return "calc_0if"
def R_pref_default(s):
    prop = P.bl_rna.properties[s]
    if getattr(prop, "is_array", False):    return prop.default_array
    return prop.default
def R_str_by_float(f):
    if P.vbox_precise_mode:
        s = str(f)
        return s if s.find("e") == -1 else fn.float_to_str(f)
    else:
        s = ('%f' % f).rstrip("0")
        return s[:-1]  if s[-1] == "." else s
def R_str_by_float_array(li):
    s = ""
    for v in li:
        s += f'{R_str_by_float(v)}, '
    return s[ : -2]


undo_str = "Unknow operation"
def undo_push(fn_old=None, fn_new=None):
    global undo_str
    if fn_old is not None:
        undo_evt.push(fn_old, fn_new)
    UNDO_PUSH(message=undo_str)
    undo_str = "Unknow operation"
def undo():
    try:
#
        bpy.ops.ed.undo()
        return True
    except:
#
        return False
def redo():
    try:
#
        bpy.ops.ed.redo()
        return True
    except:
#
        return False

def set_active_object(obj):
    bpy.context.view_layer.objects.active = obj


def sys_off():
#
    if M.TIMER is None:
        M.TIMER = bpy.context.window_manager.event_timer_add(0, window=bpy.context.window)
    admin.U_modal = admin.I_modal_fin
def sys_restart():
#
    if M.TIMER is None:
        M.TIMER = bpy.context.window_manager.event_timer_add(0, window=bpy.context.window)
    admin.U_modal = admin.I_modal_restart


def R_unit_flo(s):
    unit_scale = bpy.context.scene.unit_settings.scale_length
    if unit_scale <= 9.999999717180685e-10: unit_scale = 1.0
    if unit_scale == 1.0:
        return units_to_value(unit_system, "LENGTH", s, str_ref_unit=unit_length)
    return units_to_value(unit_system, "LENGTH", s, str_ref_unit=unit_length) / unit_scale
def bus_unit_system():
#
    global unit_system, unit_length_fac, unit_length_fac2, unit_length_fac3
    unit_system = bpy.context.scene.unit_settings.system
    unit_length_fac = R_unit_flo("1")
    unit_length_fac2 = unit_length_fac * unit_length_fac
    unit_length_fac3 = unit_length_fac * unit_length_fac2
    #
def bus_unit_length():
#
    global unit_length, unit_length_fac, unit_length_fac2, unit_length_fac3
    unit_length = bpy.context.scene.unit_settings.length_unit
    unit_length_fac = R_unit_flo("1")
    unit_length_fac2 = unit_length_fac * unit_length_fac
    unit_length_fac3 = unit_length_fac * unit_length_fac2
    #

def R_pick_obj_init(context):
    global tm

    upd_disable()
    try:
        tm["mode"] = context.object.mode
        bpy.ops.object.mode_set(mode ='OBJECT')
    except:
        tm["mode"] = None

    tm["active_object"] = context.object
    tm["selected_objects"] = context.selected_objects.copy()
def R_pick_obj(context):
    bpy.ops.view3d.select("INVOKE_DEFAULT", deselect_all=True)
    if context.selected_objects: return context.selected_objects[0]
    return None
def R_pick_obj_end(context):
    for obj in context.selected_objects:
        obj.select_set(False)
    for obj in tm["selected_objects"]:
        obj.select_set(True)

    context.view_layer.objects.active = tm["active_object"]
    if tm["mode"] != None:
        try:    bpy.ops.object.mode_set(mode = tm["mode"])
        except: pass
    upd_enable()

def R_quick_edit_state():
    if "is_quick_edit" in tm:
        TEMP = tm["is_quick_edit"]
        if TEMP:
            state = TEMP["state"]
            if state == 0:
                TEMP["state"] = 1
                return 1, TEMP
            elif state == 1:
                return 2, TEMP
            else:
                return state, TEMP
    return 0, None
