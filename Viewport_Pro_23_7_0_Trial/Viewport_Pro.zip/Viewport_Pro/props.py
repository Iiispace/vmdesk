import bpy

from . keys import value_enums, value_enums_press, value_enums_release

P = None

bl_start_up = None

def op_poll(context):
    try:
        if context.area.type in {'VIEW_3D'}: return False
        return True
    except: return True

class EDITOR(bpy.types.Operator):
    __slots__ = ()
    bl_options = {"REGISTER"}

    use_pos: bpy.props.BoolProperty(name="Override Position", default=False, description="Use cursor position instead of default position.")
    pos_offset: bpy.props.IntVectorProperty(name="Offset", size=2, default=(-150, 15), subtype="TRANSLATION", description="Window offset when Override Position is enabled.")

    def R_size(self): return P.win_size_init

    def invoke(self, context, event):


        if P is None:   bl_start_up()
        if op_poll(context):  return {'CANCELLED'}

        if self.use_pos:
            pos_xy = event.mouse_region_x + self.pos_offset[0], event.mouse_region_y + self.pos_offset[1]
            self.R_cls()(size_xy=self.R_size(), pos_xy=pos_xy)
        else:
            self.R_cls()(size_xy=self.R_size())

        return {'FINISHED'}


class BL_ITEM:
    __slots__ = 'description', 'identifier', 'name'
    def __init__(self, identifier, name, description):
        self.identifier = identifier
        self.name = name
        self.description = description

class BL_RNA:
    __slots__ = (
        'default',
        'description',
        'enum_items',
        'fx',
        'icon',
        'identifier',
        'is_animatable',
        'is_argument_optional',
        'is_enum_flag',
        'is_hidden',
        'is_library_editable',
        'is_never_none',
        'is_output',
        'is_overridable',
        'is_path_output',
        'is_readonly',
        'is_registered',
        'is_registered_optional',
        'is_required',
        'is_runtime',
        'is_skip_save',
        'length_max',
        'name',
        'rna_type',
        'srna',
        'subtype',
        'tags',
        'translation_context',
        'type',
        'unit',
        'is_array',
        'array_length',
        'step',
        'hard_min',
        'hard_max',
        'ids',
    )

class RNA_STR(BL_RNA):
    __slots__ = 'filter_enums'
    def __init__(self, name, description, default, is_readonly=False):
        self.type = "STR_SIM"
        self.name = name
        self.description = description
        self.default = default
        self.is_readonly = is_readonly
class RNA_BUTTON(BL_RNA):
    __slots__ = ()
    def __init__(self, name, description, fx_ti, fx):
        self.type = "BUTTON"
        self.name = name
        self.description = description
        self.fx = fx
        self.default = fx_ti
class RNA_FLOAT(BL_RNA):
    __slots__ = ()
    # /* 0props_RNA_FLOAT_init
    def __init__(self, name, description, default, hard_min=-3.4028234663852886e+38, hard_max=3.4028234663852886e+38, subtype="NONE", unit="NONE"):
        self.type = "FLOAT"
        self.subtype = subtype
        self.name = name
        self.description = description
        self.default = default
        self.step = 1.0
        self.unit = unit
        self.hard_min = hard_min
        self.hard_max = hard_max
        self.is_array = False
    # */
class RNA_FLOAT_ARRAY(BL_RNA):
    __slots__ = 'default_array'
    # <<< 1copy (0props_RNA_FLOAT_init,, ${'self.is_array = False':'self.is_array = True\n        self.array_length = len(default)'}$)
    def __init__(self, name, description, default, hard_min=-3.4028234663852886e+38, hard_max=3.4028234663852886e+38, subtype="NONE", unit="NONE"):
        self.type = "FLOAT"
        self.subtype = subtype
        self.name = name
        self.description = description
        self.default = default
        self.step = 1.0
        self.unit = unit
        self.hard_min = hard_min
        self.hard_max = hard_max
        self.is_array = True
        self.array_length = len(default)
    # >>>
        self.default_array = default
class RNA_ENUM(BL_RNA):
    __slots__ = ()
    def __init__(self, name, description, default, enum_items):
        self.type = 'ENUM'
        self.name = name
        self.description = description
        self.default = default
        self.enum_items = enum_items
class RNA_BOOL(BL_RNA):
    __slots__ = ()
    def __init__(self, name, description, default):
        self.type = 'BOOLEAN'
        self.name = name
        self.description = description
        self.default = default
class RNA_POINTER(BL_RNA):
    __slots__ = 'fixed_type', 'is_check'
    def __init__(self, name, description, default, fixed_type, is_check=False):
        self.type = "POINTER"
        self.name = name
        self.description = description
        self.default = default
        self.fixed_type = fixed_type
        self.is_check = is_check

description_km_value = "Press – Triggered when a keystroke is pressed\nRelease – Triggered when a keystroke is released\nDouble Press – Press the keystroke twice within the timer (Duration), each keymap has a separate duration property\nDouble Release – Release the keystroke twice within the timer (Duration)\nHold – Hold down the keystroke for a specified time (Duration)\nDrag – Threshold exceeded while holding keystroke (Default 3 pixels)"

rna_km_duration = RNA_FLOAT("Duration", "Key Duration, for Value in {'Double Press', 'Double Release', 'Hold'}", None)
rna_km_value = RNA_STR("Value", description_km_value, None)
rna_km_value.filter_enums = value_enums
rna_km_value_press = RNA_STR("Value", description_km_value, None)
rna_km_value_press.filter_enums = value_enums_press
rna_km_value_release = RNA_STR("Value", description_km_value, None)
rna_km_value_release.filter_enums = value_enums_release
rna_km_exact = RNA_BOOL("Exact", "Match the count of keys.", None)
rna_km_repeat = RNA_BOOL("Repeat", "Spare, non-functional.", None)



prefs_np = {
    # <<< 1ifmatch (0prefs, 4,
    #     $lambda line: (f'"{line.split(":", 1)[0].lstrip()}",\n', True)$,
    #     $$,
    #     ${'Property('}$
    # )
    "win_pos_init",
    "win_size_init",
    "win_size_init_DE",
    "win_size_init_ME",
    "win_size_init_LT",
    "win_size_init_SETTING",
    "scale",
    "scale_ti_bu",
    "ti_font_size",
    "tb_offset",
    "win_border",
    "win_border_inner",
    "win_offset_init",
    "win_offset_top",
    "win_shade_offset",
    "win_shade_softness",
    "win_shade_color",
    "dd_shade_offset",
    "dd_shade_softness",
    "dd_shade_color",
    "win_shade_on",
    "lock_win_size",
    "sys_auto_off",
    "sync_act_oj",
    "sync_act_md",
    "auto_sel_text",
    "auto_del_text",
    "confirm_rename",
    "confirm_del",
    "confirm_apply",
    "anim_tb_task",
    "anim_win_min",
    "anim_win_fit",
    "anim_win_x",
    "vbox_precise_mode",
    "mesh_ed_local",
    "mesh_ed_dis_invert",
    "mesh_ed_face_nor_keep_act",
    "mesh_ed_face_nor_keep_nor",
    "mesh_ed_cop_vert",
    "mesh_ed_vert_lim",
    "light_tool_ed_is_parent",
    "light_tool_ed_is_selected_objects",
    "light_tool_ed_is_link",
    "light_tool_ed_use_collection",
    "light_tool_ed_collection_name",
    "light_tool_ed_flip",
    "light_tool_ed_dis",
    "mded_x",
    "cursor_thickness",
    "cursor_flash_rate",
    "pan_method",
    "win_pos_protect",
    "quick_edit_method",
    "quick_edit_operation",
    "quick_edit_cursor",
    "quick_edit_fac_slow",
    "quick_edit_fac_fast",
    "quick_edit_fac_slow_hue",
    "quick_edit_fac_fast_hue",
    "filter_algorithm",
    "dd_num_type",
    "dd_width",
    "anim_frame_time",
    "anim_speed",
    "auto_pan_speed",
    "th_drag",
    "th_multi_drag",
    "bu_auto_speed",
    "bu_auto_time",
    "scroll_fac",
    "format_tx_f",
    "format_tx_i",
    "format_tx_h",
    "format_tx_vec",
    "color_win_rim",
    "color_win",
    "color_win_unfo",
    "color_bg_fo",
    "color_ti_bar",
    "color_ti_bar_warn",
    "color_ti_bar_unfo",
    "color_ti_bu",
    "color_ti_bu_fo",
    "color_ti_bu_sh",
    "color_ti_bu_sh_hold",
    "color_ti_bu_x",
    "color_oj_info",
    "color_bg_mod",
    "color_box_mod",
    "color_box_mod_sel",
    "color_box_mod_act",
    "color_box_mod_act_rim",
    "color_mod_bu_fo",
    "color_selbox",
    "color_selbox_rim",
    "color_bu_bg",
    "color_bu_1_off",
    "color_bu_1_on",
    "color_bu_1_rim",
    "color_bu_1_fo",
    "color_bu_1_ignore",
    "color_bu_1_ignore_on",
    "color_bu_1_rim_ignore",
    "color_bu_2",
    "color_bu_2_ignore",
    "color_bu_3_off",
    "color_bu_3_on",
    "color_bu_3_fo",
    "color_bu_3_ignore",
    "color_bu_4_off",
    "color_bu_4_on",
    "color_bu_4_rim",
    "color_bu_4_fo",
    "color_bu_4_ignore",
    "color_bu_media",
    "color_bu_media_fo",
    "color_bu_media_on",
    "color_bu_media_ignore",
    "color_tb_bg",
    "color_menu_start_bg",
    "color_mi_act",
    "color_mi_bg",
    "color_mi_bg_fo",
    "color_mi_ti",
    "color_mi_ti_off",
    "color_setting_act",
    "color_setting_bo",
    "color_setting_bo_fo",
    "color_picker_bg",
    "color_picker_bg_hue",
    "color_picker_bg_hue_fo",
    "color_picker_bu",
    "color_mded_data_bg",
    "color_mded_data_rim",
    "color_mesh_ed_block",
    "color_ddmenu",
    "color_dd_actbox",
    "color_filter",
    "color_calc_bu",
    "color_scroll_rim",
    "color_scroll_rim_fo",
    "color_scroll_bar_rim",
    "color_scroll_bar_bg",
    "color_scroll_bar_fo",
    "color_tx_cursor",
    "color_tx_sel",
    "color_tx_copy",
    "color_r_menu_bg",
    "color_r_menu",
    "color_flash_box",
    "color_rm_bg",
    "color_rm_fobox",
    "color_tex_bg",
    "color_tex_main",
    "color_status_bar_bg",
    "color_icon_1",
    "color_icon_2",
    "color_icon_3",
    "color_icon_4",
    "color_icon_5",
    "color_icon_6",
    "color_icon_7",
    "color_icon_8",
    "color_icon_ignore",
    "color_icon_ignore2",
    "color_icon_light",
    "color_icon_start",
    "color_icon_start_fo",
    "color_font",
    "color_font_red",
    "color_font_fo",
    "color_font_ti",
    "color_font_sub_ti",
    "color_font_sub_ti_fo",
    "color_font_sub_ti_2",
    "color_font_sub_ti_2_fo",
    "color_font_mod_num",
    "color_font_mod_num_fo",
    "color_font_mod_name",
    "color_font_darker",
    "color_font_ignore",
    "color_bu_kf_fo",
    "color_bu_kf_yellow",
    "color_bu_kf_yellow_fo",
    "color_bu_kf_yellow_ignore",
    "color_bu_kf_green",
    "color_bu_kf_green_fo",
    "color_bu_kf_green_ignore",
    "color_bu_kf_orange",
    "color_bu_kf_orange_fo",
    "color_bu_kf_orange_ignore",
    "color_bu_dr",
    "color_bu_dr_fo",
    "color_bu_dr_ignore",
    "color_mdicon_kf_off",
    "color_mdicon_dr_off",
    "color_font_rm",
    "color_font_rm_ignore",
    # >>>
}
prefs_all_keys = {
    # <<< 1ifmatch (0prefs_key, 4,
    #     $lambda line: (f'"{line.split(":", 1)[0].lstrip()}",\n', True)$,
    #     $$,
    #     ${'IntVectorProperty'}$
    # )
    "keys_sys_pass",
    "keys_sys_pass_E",
    "keys_sel_fast",
    "keys_sel",
    "keys_sel_ext",
    "keys_bu_sel",
    "keys_bu_sel_ext",
    "keys_bu_qe",
    "keys_bu_qe_E",
    "keys_bu_qe_cancel",
    "keys_bu_qe_slow",
    "keys_bu_qe_fast",
    "keys_bu_reset",
    "keys_bu_reset_all",
    "keys_bu_left",
    "keys_bu_right",
    "keys_bu_up",
    "keys_bu_down",
    "keys_bu_insert_kf",
    "keys_bu_del_kf",
    "keys_bu_clear_kf",
    "keys_bu_add_dr",
    "keys_bu_del_dr",
    "keys_bu_dp",
    "keys_bu_dp_full",
    "keys_bu_dp_paste",
    "keys_bu_add_keying_set",
    "keys_bu_del_keying_set",
    "keys_bu_batch_kf",
    "keys_bu_batch_dr",
    "keys_bu_batch_value",
    "keys_rm",
    "keys_cancel",
    "keys_confirm",
    "keys_pan",
    "keys_pan_E",
    "keys_glopan",
    "keys_glopan_E",
    "keys_ti_bu",
    "keys_ti_bu_E",
    "keys_ti_mov",
    "keys_ti_mov_E",
    "keys_resize",
    "keys_resize_E",
    "keys_undo",
    "keys_redo",
    "keys_me_sel",
    "keys_me_sel_ext",
    "keys_me_pan",
    "keys_me_pan_E",
    "keys_me_box",
    "keys_me_box_E",
    "keys_me_box_ext",
    "keys_me_box_ext_E",
    "keys_me_sort",
    "keys_me_sort_E",
    "keys_me_rename",
    "keys_me_all",
    "keys_me_act_up",
    "keys_me_act_dn",
    "keys_me_act_up_ext",
    "keys_me_act_dn_ext",
    "keys_me_mod_up",
    "keys_me_mod_dn",
    "keys_me_del",
    "keys_me_apply",
    "keys_dd_del_alp",
    "keys_dd_del_word",
    "keys_dd_del_all",
    "keys_dd_left",
    "keys_dd_right",
    "keys_dd_up",
    "keys_dd_down",
    "keys_dd_shift_left",
    "keys_dd_shift_right",
    "keys_dd_shift_up",
    "keys_dd_shift_down",
    "keys_dd_pan",
    "keys_dd_pan_E",
    "keys_dd_box",
    "keys_dd_box_E",
    "keys_dd_sel",
    "keys_dd_sel_all",
    "keys_dd_copy",
    "keys_dd_paste",
    "keys_dd_cut",
    "keys_dd_cancel",
    "keys_dd_confirm",
    "keys_dd_bar",
    "keys_dd_bar_E",
    "keys_dd_tab",
    "keys_dd_scroll_up",
    "keys_dd_scroll_down",
    "keys_cp_hue_sel",
    "keys_cp_hue",
    "keys_cp_hue_E",
    "keys_pk_cancel",
    "keys_pk_confirm",
    "keys_tex_cancel",
    "keys_rm_1",
    "keys_rm_2",
    "keys_rm_3",
    "keys_rm_4",
    "keys_rm_5",
    "keys_rm_6",
    "keys_rm_7",
    "keys_rm_8",
    "keys_rm_9",
    "keys_rm_0",
    "keys_rm_back",
    "keys_rm_next",
    # >>>
}
prefs_km = {e  for e in prefs_all_keys  if f'{e}_E' not in prefs_all_keys and e[-2 :] != "_E"}
prefs_km.discard("keys_sel_fast")
prefs_km.discard("keys_sel")

prefs_km2 = {e  for e in prefs_all_keys  if e not in prefs_km and e[-2 :] != "_E"}
prefs_km2.discard("keys_sel_fast")
prefs_km2.discard("keys_sel")

prefs_km_sel = {
    "keys_sel_fast",
}
prefs_exp = {
    # <<< 1ifmatch (0prefs_exp, 4,
    #     $lambda line: (f'"{line.split(":", 1)[0].lstrip()}",\n', True)$,
    #     $$,
    #     ${'StringProperty'}$
    # )
    "calc_13i1",
    "calc_13i1ex",
    "calc_13i2",
    "calc_13i2ex",
    "calc_13i3",
    "calc_13i3ex",
    "calc_13i4",
    "calc_13i4ex",
    "calc_13i5",
    "calc_13i5ex",
    "calc_13i6",
    "calc_13i6ex",
    "calc_13i7",
    "calc_13i7ex",
    "calc_13i8",
    "calc_13i8ex",
    "calc_13i9",
    "calc_13i9ex",
    "calc_13i10",
    "calc_13i10ex",
    "calc_13i11",
    "calc_13i11ex",
    "calc_13i12",
    "calc_13i12ex",
    "calc_01f1",
    "calc_01f1ex",
    "calc_01f2",
    "calc_01f2ex",
    "calc_01f3",
    "calc_01f3ex",
    "calc_01f4",
    "calc_01f4ex",
    "calc_01f5",
    "calc_01f5ex",
    "calc_01f6",
    "calc_01f6ex",
    "calc_01f7",
    "calc_01f7ex",
    "calc_01f8",
    "calc_01f8ex",
    "calc_01f9",
    "calc_01f9ex",
    "calc_01f10",
    "calc_01f10ex",
    "calc_01f11",
    "calc_01f11ex",
    "calc_01f12",
    "calc_01f12ex",
    "calc_0if1",
    "calc_0if1ex",
    "calc_0if2",
    "calc_0if2ex",
    "calc_0if3",
    "calc_0if3ex",
    "calc_0if4",
    "calc_0if4ex",
    "calc_0if5",
    "calc_0if5ex",
    "calc_0if6",
    "calc_0if6ex",
    "calc_0if7",
    "calc_0if7ex",
    "calc_0if8",
    "calc_0if8ex",
    "calc_0if9",
    "calc_0if9ex",
    "calc_0if10",
    "calc_0if10ex",
    "calc_0if11",
    "calc_0if11ex",
    "calc_0if12",
    "calc_0if12ex",
    "calc_0pf1",
    "calc_0pf1ex",
    "calc_0pf2",
    "calc_0pf2ex",
    "calc_0pf3",
    "calc_0pf3ex",
    "calc_0pf4",
    "calc_0pf4ex",
    "calc_0pf5",
    "calc_0pf5ex",
    "calc_0pf6",
    "calc_0pf6ex",
    "calc_0pf7",
    "calc_0pf7ex",
    "calc_0pf8",
    "calc_0pf8ex",
    "calc_0pf9",
    "calc_0pf9ex",
    "calc_0pf10",
    "calc_0pf10ex",
    "calc_0pf11",
    "calc_0pf11ex",
    "calc_0pf12",
    "calc_0pf12ex",
    "calc_0df1",
    "calc_0df1ex",
    "calc_0df2",
    "calc_0df2ex",
    "calc_0df3",
    "calc_0df3ex",
    "calc_0df4",
    "calc_0df4ex",
    "calc_0df5",
    "calc_0df5ex",
    "calc_0df6",
    "calc_0df6ex",
    "calc_0df7",
    "calc_0df7ex",
    "calc_0df8",
    "calc_0df8ex",
    "calc_0df9",
    "calc_0df9ex",
    "calc_0df10",
    "calc_0df10ex",
    "calc_0df11",
    "calc_0df11ex",
    "calc_0df12",
    "calc_0df12ex",
    # >>>
}
prefs_qe = {
    # <<< 1ifmatch (0prefs_exp, 4,
    #     $lambda line: (f'"{line.split(":", 1)[0].lstrip()}",\n', True)$,
    #     $$,
    #     ${'FloatProperty'}$
    # )
    "calc_13iqe",
    "calc_01fqe",
    "calc_0ifqe",
    "calc_0pfqe",
    "calc_0dfqe",
    # >>>
}
prefs_np.update(prefs_qe)
prefs_np.update(prefs_exp)
