import bpy
from blf import size as blf_size
from blf import color as blf_color
from blf import dimensions as blf_dimen
from . import m, bu

P = None
F = None
K = None
BOX = None
BLF = None
font_0 = None
BLEND = None

# li = {0: name, 1: color, 9: id}
class RM:
    __slots__ = (
        'w',
        'bo',
        'ti',
        'da',
        'RET',
        'sci',
        'rank',
        'U_modal',
        'U_draw',
        'default_modal',
        'key_end',
        'page',
        'pages',
        'bu_media',
        'll',
        'li',
        'll_li',
        'data',
        'bu_h',
        'fobox',
        'fin_D1',
        'is_head_modal',
    )
    def fin(self):
#
        m.M.set_mou_ic('DEFAULT')
        m.EVT.kill()
        if self.is_head_modal:
            del m.head_modal[-1]
            m.admin.tb.draw_top.remove(self)
        else:
            m.W_D.remove(self)
            m.W_M.remove(self)
        m.redraw()
        self.fin_D1()
    def __init__(self, w, x, y, data,
            fin_D1      = None,
            title       = "Context Menu",
            info        = "",
            width       = None,
            is_head_modal = False
        ):
#
        m.M.set_mou_ic('DEFAULT')
        _1          = F[1]
        unit        = P.scale[0]
        BURE_FA     = bu.BURE_FA

        if is_head_modal:
            m.admin.tb.draw_top.append(self)
            m.head_modal.append(self.run_modal)
        else:
            m.W_D.append(self)
            m.W_M.append(self)

        self.RET            = {'RUNNING_MODAL'}
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.U_draw         = self.I_draw
        self.fin_D1         = self.fin_D1_default if fin_D1 is None else fin_D1
        self.is_head_modal  = is_head_modal

        bo = {}
        ti = {}

        self.w      = w
        self.data   = data
        ll          = len(data)
        self.ll     = ll

        rank        = []
        self.rank   = rank
        self.bo     = bo
        self.ti     = ti
        self.bu_h   = F[18]
        x_dR        = F[38]

        if width is None:   width = x_dR + F[101]

        self.page       = 1
        self.pages      = ll // 10  if ll % 10 == 0 else ll // 10 + 1

        T = y + F[22]
        R = x + x_dR
        L = R - width

        blf_size(font_0, F[9])
        max_dimen = 0.0
        for e in data:
            dimen = blf_dimen(font_0, e[0])[0]
            if dimen > max_dimen:   max_dimen = dimen

        if max_dimen > width - x_dR:
            R = L + max_dimen + x_dR

        bo["bg"]        = BOX(P.color_rm_bg, L, R, 0, T)
        self.li         = []
        self.get_li()
        B               = self.li[-1].y - round(26 * unit)
        bo["bg"].B      = B
        bo["rim"]       = m.RIM(P.color_win_rim)
        bo["rim"].LRBTd_rev(L, R, B, T, _1)
        ti["ti"]        = BLF(P.color_font_darker, title, None, L + F[6], T - F[14])
        ti["info"]      = BLF(None, info, None, ti["ti"].x, B + F[8])
        blf_size(font_0, F[11])
        ti["ti"].fix_long_text(R - F[6], F[10])

        if P.win_shade_on:
            bo["shade"] = m.SHADE(P.win_shade_color)
            bo["shade"].get_by_rim(
                L, R, B, T,
                P.win_shade_softness, P.win_shade_offset, unit
            )
        else:   bo["shade"] = m.BOX_FAKE()

        self.sci        = m.SCISSOR()
        self.sci.box(bo["bg"])
        self.bu_media   = bu.BU_LR(self, self.bu_fn_back, self.bu_fn_next,
            base_evt    = self.base_evt,
            enable_back = False,
            enable_next = False if self.pages == 1 else True,
            is_RET      = False)
        ti["page"]      = BLF(None, f"1 / {self.pages}", None, R - round(57*unit), ti["info"].y)

        self.bu_media.RB(R - F[2], B + F[3])

        class FOBOX(BOX):
            __slots__ = (
                'ind',
            )

        fobox           = FOBOX(P.color_rm_fobox)
        self.fobox      = fobox
        fobox.ind       = None

        for e in bo.values():   e.upd()
        m.EVT.kill()
        m.redraw()

    def get_li(self):
        data    = self.data
        li      = self.li
        rank    = self.rank
        bg      = self.bo["bg"]
        h       = self.bu_h
        x       = bg.L + F[20]
        y       = bg.T - round(P.scale[0] * 33)
        rank_x  = bg.L + F[7]
        r0      = (self.page - 1) * 10
        color0  = P.color_font_rm_ignore
        color1  = P.color_font_rm

        li.clear()
        rank.clear()
        for r in range(r0, min(r0 + 10, self.ll)):
            if 1 in data[r]:
                c = color0 if data[r][1] == 0 else color1
            else:
                c = color1
            li.append(BLF(c, data[r][0], None, x, y))
            rank.append(BLF(None, str(r+1)[-1:], None, rank_x, y))
            y -= h

        self.ll_li = len(li)

    def R_data_by_ind(self):
        try:
            if self.fobox.ind is None:  return None
            return self.data[(self.page - 1) *10 + self.fobox.ind]
        except:
            return None
    def fin_D1_default(self):
        data = self.R_data_by_ind()
        if data is None: return
        if 1 in data and data[1] == 0: return
        if isinstance(data[9], str):
            func = getattr(self.w, data[9], None)
            if func is None: return
            func()
        else:
            data[9]()

    def run_modal(self, evt):   self.U_modal(evt)
    def I_modal_main(self, evt):
        if self.bo["bg"].inbox(evt) == False:
            if self.fobox.ind is not None: self.fobox.ind = None ;m.redraw()

            if K["dd_cancel0"].true():  self.fin()  ;return
            if K["dd_cancel1"].true():  self.fin()  ;return
            if K["sel_fast0"].true():   self.fin()  ;return
            if K["sel_fast1"].true():   self.fin()  ;return
            return
        T = self.ti["ti"].y - F[4]
        if T < evt.mouse_region_y:
            if self.fobox.ind is not None: self.fobox.ind = None ;m.redraw()

            if K["cancel0"].true():     self.fin()  ;return
            if K["cancel1"].true():     self.fin()  ;return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
                return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
                return
            return
        i = (T - F[3] - evt.mouse_region_y) // self.bu_h
        if 0 <= i < self.ll_li:
            if self.fobox.ind != i:
                m.redraw()
                self.fobox.ind = i
                bo_bg = self.bo["bg"]
                d = F[2]
                B = self.li[i].y - F[6]
                self.fobox.LRBT(bo_bg.L + d, bo_bg.R - d, B, B + self.bu_h)
                self.fobox.upd()

            if K["sel_fast0"].true() or K["sel_fast1"].true(): self.fin() ;return

            self.base_evt(evt)
            return

        if self.fobox.ind is not None: self.fobox.ind = None ;m.redraw()

        if self.bu_media.rim.inbox(evt):
            self.bu_media.inside(evt)
            return

        if K["dd_cancel0"].true():  self.fin()  ;return
        if K["dd_cancel1"].true():  self.fin()  ;return
        if K["rm_10"].true() or K["rm_11"].true():
            self.fobox.ind = 0
            self.fin()
            return
        if K["rm_20"].true() or K["rm_21"].true():
            self.fobox.ind = 1
            self.fin()
            return
        if K["rm_30"].true() or K["rm_31"].true():
            self.fobox.ind = 2
            self.fin()
            return
        if K["rm_40"].true() or K["rm_41"].true():
            self.fobox.ind = 3
            self.fin()
            return
        if K["rm_50"].true() or K["rm_51"].true():
            self.fobox.ind = 4
            self.fin()
            return
        if K["rm_60"].true() or K["rm_61"].true():
            self.fobox.ind = 5
            self.fin()
            return
        if K["rm_70"].true() or K["rm_71"].true():
            self.fobox.ind = 6
            self.fin()
            return
        if K["rm_80"].true() or K["rm_81"].true():
            self.fobox.ind = 7
            self.fin()
            return
        if K["rm_90"].true() or K["rm_91"].true():
            self.fobox.ind = 8
            self.fin()
            return
        if K["rm_00"].true() or K["rm_01"].true():
            self.fobox.ind = 9
            self.fin()
            return
        if K["rm_back0"].true() or K["rm_back1"].true():
            self.bu_media.evt_back()
            return
        if K["rm_next0"].true() or K["rm_next1"].true():
            self.bu_media.evt_next()
            return

    def base_evt(self, evt):
        if K["dd_cancel0"].true() or K["dd_cancel1"].true():
            self.fobox.ind = None
            self.fin()
            return True
        if K["rm_10"].true() or K["rm_11"].true():
            self.fobox.ind = 0
            self.fin()
            return True
        if K["rm_20"].true() or K["rm_21"].true():
            self.fobox.ind = 1
            self.fin()
            return True
        if K["rm_30"].true() or K["rm_31"].true():
            self.fobox.ind = 2
            self.fin()
            return True
        if K["rm_40"].true() or K["rm_41"].true():
            self.fobox.ind = 3
            self.fin()
            return True
        if K["rm_50"].true() or K["rm_51"].true():
            self.fobox.ind = 4
            self.fin()
            return True
        if K["rm_60"].true() or K["rm_61"].true():
            self.fobox.ind = 5
            self.fin()
            return True
        if K["rm_70"].true() or K["rm_71"].true():
            self.fobox.ind = 6
            self.fin()
            return True
        if K["rm_80"].true() or K["rm_81"].true():
            self.fobox.ind = 7
            self.fin()
            return True
        if K["rm_90"].true() or K["rm_91"].true():
            self.fobox.ind = 8
            self.fin()
            return True
        if K["rm_00"].true() or K["rm_01"].true():
            self.fobox.ind = 9
            self.fin()
            return True
        if K["rm_back0"].true() or K["rm_back1"].true():
            self.bu_media.evt_back()
            return True
        if K["rm_next0"].true() or K["rm_next1"].true():
            self.bu_media.evt_next()
            return True
        return False

    def dxy_upd(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.x += x ;e.y += y
        for e in self.li:           e.dxy(x, y)
        for e in self.rank:         e.dxy(x, y)
        self.bu_media.dxy_upd(x, y)
        self.fobox.dxy_upd(x, y)
        self.sci.dxy(x, y)
    def to_modal_mov(self, evt):
        self.key_end.true()
        m.head_modal.append(self.I_modal_mov)
        m.get_mou(evt)
    def modal_mov_end(self):
#
        del m.head_modal[-1]
        e = self.bo["bg"]
        dx, dy = m.R_full_protect_dxy(e.L, e.R, e.B, e.T)
        if dx != 0 or dy != 0:
            self.dxy_upd(dx, dy)

        m.EVT.kill()
        m.redraw()
    def I_modal_mov(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_mov_end()
                return
        m.dx    = evt.mouse_x - m.mou_x
        m.dy    = evt.mouse_y - m.mou_y
        self.dxy_upd(m.dx, m.dy)
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()

    def bu_fn_back(self):
        if self.page == 1: return
        self.page -= 1
        self.ti["page"].text = f"{self.page} / {self.pages}"

        self.get_li()

        if self.page == 1:
            self.bu_media.enable_next()
            self.bu_media.disable_back()
        m.redraw()
    def bu_fn_next(self):
        if self.page == self.pages: return
        self.page += 1
        self.ti["page"].text = f"{self.page} / {self.pages}"

        self.get_li()

        if self.page == self.pages:
            self.bu_media.disable_next()
            self.bu_media.enable_back()
        m.redraw()

    def I_draw(self):
        BLEND()
        bo  = self.bo
        ti  = self.ti

        bo["shade"].draw()
        bo["rim"].bind_draw()
        bo["bg"].bind_draw()
        if self.fobox.ind is not None:  self.fobox.bind_draw()

        m.bind_color_bu_1_rim()

        blf_size(font_0, F[11])
        ti["ti"].set_color()        ;ti["ti"].draw_pos()

        blf_size(font_0, F[9])
        for e in self.li:           e.draw_color_pos()

        blf_size(font_0, F[8])
        ti["ti"].set_color()        ;ti["info"].draw_pos()
        ti["page"].draw_pos()

        blf_size(font_0, F[7])
        for e in self.rank:         e.draw_pos()

        self.bu_media.draw()
    #


class RM_HEAD:
    __slots__ = (
        'w',
        'U_draw',
        'U_modal',
        'default_modal',
        'bo',
        'ti',
        'oo',
        'RET',
        'rank',
        'sci',
        'key_end',
        'end_fn',
    )
    def __init__(self, w, evt, li, info="", end_fn=None):
#
        self.w = w
        m.M.set_mou_ic('DEFAULT')
        m.head_modal.append(self.run_modal)
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.end_fn         = end_fn
        m.admin.tb.draw_top.append(self)

        BURE_FA = bu.BURE_FA

        bo = {
            "rim":      m.RIM(P.color_win_rim),
            "bg":       BOX(P.color_rm_bg)
        }
        self.bo = bo

        ti = {
            "ti":       BLF(P.color_font_darker, "Context Menu"),
            "info":     BLF(text = info)
        }
        self.ti = ti

        def R_bu_fn(bu_fn):
            def fx(): self.fin();bu_fn()
            return fx

        oo = {str(i+1): BURE_FA(self, str(i+1), e[0],
            R_bu_fn(e[1]), auto=False, base_evt=self.base_evt) for i, e in enumerate(li)
        }
        self.oo     = oo
        rank        = []
        self.rank   = rank

        bgL = evt.mouse_region_x
        bgT = evt.mouse_region_y
        bgR = bgL + F[150]

        ti["ti"].x = bgL + F[6]
        ti["ti"].y = bgT - F[15]

        L   = bgL + F[2]
        R   = bgR - F[2]
        T   = ti["ti"].y - F[6]
        L4  = L + F[4]

        blf_size(font_0, F[9])
        for r in range(len(oo)):
            n = str(r + 1)
            B = T - F[16]
            oo[n].LRBT(L, R, B, T)
            T = B - F[2]
            rank.append(BLF(text=n, x=L4, y=B + F[6]))

        bo_bg = bo["bg"]
        bo_bg.LRBT(bgL, bgR, T - F[16], bgT)
        bo["rim"].LRBTd_rev(bo_bg.L, bo_bg.R, bo_bg.B, bo_bg.T, F[1])

        ti["info"].x    = ti["ti"].x
        ti["info"].y    = bo_bg.B + F[6]
        self.sci        = m.SCISSOR()
        self.sci.box(bo_bg)

        if P.win_shade_on:
            bo["shade"] = m.SHADE(P.win_shade_color)
            bo["shade"].get_by_rim(
                bo_bg.L, bo_bg.R, bo_bg.B, bo_bg.T,
                P.win_shade_softness, P.win_shade_offset, P.scale[0]
            )
        else:   bo["shade"] = m.BOX_FAKE()

        for e in self.bo.values():  e.upd()
        dx, dy = m.R_protect_dxy_LT(bo_bg, F[-1])
        if dx == 0 and dy == 0: pass
        else:   self.dxy_upd(dx, dy)

        m.EVT.kill()
        m.redraw()

    def fin(self):
#
        del m.head_modal[-1]
        m.admin.tb.draw_top.remove(self)
        m.EVT.kill()
        m.redraw()
        if self.end_fn is not None: self.end_fn()

    def run_modal(self, evt):   self.U_modal(evt)
    def I_modal_main(self, evt):
        if self.bo["bg"].inbox(evt) == False:
            if K["dd_cancel0"].true():  self.fin()  ;return
            if K["dd_cancel1"].true():  self.fin()  ;return
            if K["sel_fast0"].true():   self.fin()  ;return
            if K["sel_fast1"].true():   self.fin()  ;return
            return
        if self.oo["1"].rim.T < evt.mouse_region_y:
            if K["cancel0"].true():     self.fin()  ;return
            if K["cancel1"].true():     self.fin()  ;return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
                return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
                return
            return
        for e in self.oo.values():
            if e.rim.inbox(evt):    e.inside(evt)   ;return
        if K["dd_cancel0"].true():  self.fin()  ;return
        if K["dd_cancel1"].true():  self.fin()  ;return

    def base_evt(self, evt):
        if K["dd_cancel0"].true():  self.fin()  ;return True
        if K["dd_cancel1"].true():  self.fin()  ;return True
        return False

    def to_modal_mov(self, evt):
#
        self.key_end.true()
        m.head_modal.append(self.I_modal_mov)
        self.U_modal = m.N
        m.get_mou(evt)
    def protect_pos(self):
        new_x, new_y = m.IR_protect_pos(self.bo["bg"], F[-1])
        dx = new_x - self.bo["bg"].L
        dy = new_y - self.bo["bg"].T
        if dx == 0 and dy == 0: return
        self.dxy_upd(dx, dy)
    def modal_mov_end(self):
#
        del m.head_modal[-1]
        self.protect_pos()
        self.U_modal = self.I_modal_main
        m.EVT.kill()
        m.EVT.U_ENABLE_evt()
        m.redraw()
    def I_modal_mov(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_mov_end()
                return
        m.dx = evt.mouse_x - m.mou_x
        m.dy = evt.mouse_y - m.mou_y
        self.dxy_upd(m.dx, m.dy)
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()

    def dxy_upd(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)
        for e in self.rank:         e.dxy(x, y)
        self.sci.dxy(x, y)

    def I_draw(self):
        BLEND()
        bo  = self.bo
        ti  = self.ti

        bo["shade"].draw()
        bo["rim"].bind_draw()
        bo["bg"].bind_draw()

        # self.sci.ENABLE()
        m.bind_color_bu_1_rim()
        for e in self.oo.values():  e.draw_rim()
        for e in self.oo.values():  e.draw_bg()

        blf_size(font_0, F[12])
        ti["ti"].set_color()        ;ti["ti"].draw_pos()

        blf_size(font_0, F[9])
        for e in self.oo.values():  e.draw_ti()

        blf_size(font_0, F[7])
        ti["ti"].set_color()        ;ti["info"].draw_pos()
        for e in self.rank:         e.draw_pos()
        # self.sci.DISABLE()