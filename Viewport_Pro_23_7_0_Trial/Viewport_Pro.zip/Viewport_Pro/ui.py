import bpy
from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP

from . import m

from . dd import DDVAL, DDTX, DD_COLOR
from . calc import calc_vec, calc_vec_3
from . filt import FIL, FIL_TYPE_EXC
from . rm import RM
from . det import INFO, DETAILS
from . fn import NAME, R_str_by_deg, R_lib_str
from . ED_setting.setting_key_edit import KEY_ED_SINGLE

P = None
F = None
K = None
N = None
BOX = None
BOX_C = None
BLF = None
font_0 = None

color_black = (0.0, 0.0, 0.0, 1.0)
color_white = (1.0, 1.0, 1.0, 1.0)
tuple_XYZ = ('X', 'Y', 'Z')

D_PREF_SUBTYPES = {
    "scale": ("Global", "Title"),
    "win_shade_offset": ("Left", "Right", "Bottom", "Top"),
    "dd_shade_offset": ("Left", "Right", "Bottom", "Top"),
    "cursor_flash_rate": ("2 sec",),
    "th_drag": ("px",),
    "th_multi_drag": ("px",),
    "scroll_fac": ("px",),
    "bu_auto_speed": ("sec",),
    "bu_auto_time": ("sec",),
}
D_timer_type_rev = {
    'Timer': 'TIMER',
    'Timer 0': 'TIMER0',
    'Timer 1': 'TIMER1',
    'Timer 2': 'TIMER2',
    'Timer Jobs': 'TIMER_JOBS',
    'Timer Autosave': 'TIMER_AUTOSAVE',
    'Timer Report': 'TIMER_REPORT',
    'Timer Region': 'TIMERREGION'}


class QE:
    __slots__ = ()
    state = -1
    data = {}
    @classmethod
    def kill(cls):
        cls.state = -1
        cls.data.clear()

def R_rna_ty(rna):
    ty = rna.type.lower()
    if ty != "int":
        i0 = rna.hard_min
        i1 = rna.hard_max
        if i0 > 3.4e+38:    i0 = "3.40*10^38"
        elif i0 < -3.4e+38: i0 = "-3.40*10^38"
        else:
            i0 = m.R_str_by_float(i0)
        if i1 > 3.4e+38:    i1 = "3.40*10^38"
        elif i1 < -3.4e+38: i1 = "-3.40*10^38"
        else:
            i1 = m.R_str_by_float(i1)
        return f'{ty} [{i0},{i1}]'
    else:
        return f'{ty} [{rna.hard_min},{rna.hard_max}]'

class RNA:
    __slots__ = (
        'w',
        'rna',
        'rim',
        'bo',
        'ti',
        'da',
        'get',
        'set',
        'is_enable',
        'is_title_left',
        'key_start',
        'key_end',
    )
class SUBTI:
    __slots__ = ()
    def init(self, sub_ti):
        self.sub_ti = BLF(P.color_font_darker, sub_ti[0])
    def enable(self):

        self.is_enable = True
        self.rim.color = P.color_bu_3_off
        self.da.color = P.color_font
        self.sub_ti.color = P.color_font_darker
    def disable(self):

        self.is_enable = False
        self.rim.color = P.color_bu_3_ignore
        self.da.color = P.color_font_ignore
        self.sub_ti.color = P.color_font_ignore

    def draw_blf(self):
        self.da.draw_color_pos()
        self.ti.draw_pos()
        blf_size(font_0, F[8])
        self.sub_ti.draw_color_pos()
        blf_size(font_0, F[9])
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)
        self.sub_ti.dxy(x, y)

    def get_bo(self, L, R, B, T): # need set_size if title left
        self.rim.LRBT_upd(L, R, B, T)
        self.da.xy(L + F[self.offset_x_key], B + F[5])
        ti_y = B + F[5]
        self.ti.y = ti_y
        self.sub_ti.y = ti_y

        if self.is_title_left is True:
            self.ti.align_R(L - F[10])
            blf_size(font_0, F[8])
            self.sub_ti.align_R(L - F[5])
            wi = round(self.sub_ti.R_dimen()) + F[8]
            blf_size(font_0, F[9])
            self.ti.x -= wi
        else:
            self.ti.x = R + F[7]
            blf_size(font_0, F[8])
            self.sub_ti.align_R(L - F[5])
            blf_size(font_0, F[9])
        return B
class SUBTI_ARRAY:
    __slots__ = ()
    def init(self, sub_ti):
        self.sub_ti = [BLF(text=sub_ti[r])  for r in range(self.l)]
        self.sub_ti[0].color = P.color_font_darker
    def enable(self):

        self.is_enable = True
        for e in self.rim:  e.color = P.color_bu_3_off
        for e in self.da:   e.color = P.color_font
        self.sub_ti[0].color = P.color_font_darker
    def disable(self):

        self.is_enable = False
        for e in self.rim:  e.color = P.color_bu_3_ignore
        for e in self.da:   e.color = P.color_font_ignore
        self.sub_ti[0].color = P.color_font_ignore

    def draw_blf(self):
        for e in self.da:   e.draw_color_pos()
        self.ti.draw_pos()
        blf_size(font_0, F[8])
        self.sub_ti[0].set_color()
        for e in self.sub_ti:   e.draw_pos()
        blf_size(font_0, F[9])
    def dxy(self, x, y):
        for e in self.rim:  e.dxy_upd(x, y)
        self.ti.dxy(x, y)
        for e in self.da:   e.dxy(x, y)
        for e in self.sub_ti:   e.dxy(x, y)

    def get_bo(self, L, R, B, T): # need set_size if title left
        h = T - B
        _1 = F[1]
        _5 = F[5]
        ti_y = B + _5
        self.ti.y = ti_y

        for rim, da in zip(self.rim, self.da):
            rim.LRBT_upd(L, R, B, T)
            da.xy(L + F[self.offset_x_key], B + _5)
            T = B - _1
            B = T - h

        L0 = L - F[5]
        if self.is_title_left is True:
            self.ti.align_R(L - F[10])
            blf_size(font_0, F[8])
            max_wi = 0
            for sub_ti, da in zip(self.sub_ti, self.da):
                sub_ti.y = da.y
                sub_ti.align_R(L0)
                wi = round(sub_ti.R_dimen()) + F[8]
                if wi > max_wi: max_wi = wi
            blf_size(font_0, F[9])
            self.ti.x -= wi
        else:
            self.ti.x = R + F[7]
            blf_size(font_0, F[8])
            for sub_ti, da in zip(self.sub_ti, self.da):
                sub_ti.y = da.y
                sub_ti.align_R(L0)
            blf_size(font_0, F[9])
        return rim.B

class TITLE(RNA):
    __slots__ = 'dxy'
    def __init__(self, w, name=""):
        self.w = w
        self.is_enable = True

        self.ti = BLF(P.color_font, name)
        self.is_title_left = True
        self.dxy = self.ti.dxy

    def enable(self):
        TODO
    def disable(self):
        TODO

    def draw_box(self): pass
    def draw_blf(self):
        self.ti.draw_color_pos()

    def set_da(self, v): pass
    def da_upd(self): pass

    def is_inside(self, x, y): return False
    def outside(self): pass
    def inside(self, evt): pass
    def I_modal_main(self, evt): pass

class BOOLEAN(RNA):
    __slots__ = 'is_allow', 'use_22'
    def __init__(self, w, rna, fn_get, fn_set):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set

        self.rim = BOX(P.color_bu_3_off)
        self.ti = BLF(P.color_font, rna.name)
        self.da = BLF(P.color_bu_2)
        self.da.name = None
        self.is_title_left = False
        self.use_22 = True

    def enable(self):

        self.is_enable = True
        self.rim.color = P.color_bu_3_off
        self.ti.color = P.color_font
        self.da.color = P.color_bu_2
    def disable(self):

        self.is_enable = False
        self.rim.color = P.color_bu_3_ignore
        self.ti.color = P.color_font_ignore
        self.da.color = P.color_bu_2_ignore

    def draw_box(self):
        self.rim.bind_draw()
    def draw_blf(self):
        self.ti.draw_color_pos()
        blf_size(font_0, F[22])
        self.da.draw_color_pos()
        blf_size(font_0, F[9])

    def set_da(self, v):
        self.da.name = v
        self.da.text = "■"  if v else ""
    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            self.da.name = v
            self.da.text = "■"  if v else ""
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

    def get_bo(self, L, R, B, T): # need set_size if title left
        self.rim.LRBT_upd(L, R, B, T)
        self.da.xy(L + F[1.5], B)
        if self.is_title_left is True:
            self.ti.align_R(L - F[10])
            self.ti.y = B + F[5]
        else:
            self.ti.xy(R + F[7], B + F[5])
        return B

    def is_inside(self, x, y): return self.rim.inbox_xy(x, y)
    def outside(self):
        if self.is_enable is True:
            self.rim.color = P.color_bu_3_off
            m.redraw()
        self.w.to_modal_default()
    def inside(self, evt):
        if self.is_enable is None: return
        self.is_allow = True
        if self.is_enable is True:
            self.rim.color = P.color_bu_3_fo
            m.redraw()
        self.w.to_modal(self.I_modal_main)
        self.I_modal_main(evt)

    def I_modal_main(self, evt):
        # /* 0ui_is_out
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.is_inside(x, y) is False:
            self.outside()
            return
        # */
        if evt.value == 'RELEASE': self.is_allow = True
        if K["sel_fast0"].true() or K["sel_fast1"].true():
            if self.is_allow is False: return True
            self.is_allow = False
            self.fn()
            return True
        # /* 0ui_rm_base_evt
        if K["rm0"].true() or K["rm1"].true():
            self.fn_rm(evt)
            return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            if hasattr(self, "fn_copy_array"):
                self.fn_copy_array()
            else:
                self.fn_copy()
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.fn_reset()
            return True
        # */

    def fn(self):
        try:
            self.set(not self.get())
            m.refresh()
            m.redraw()

        except: pass
    def fn_copy(self):
        bpy.context.window_manager.clipboard = str(self.get())
    def fn_paste(self):
        v = bpy.context.window_manager.clipboard
        if v in {"True", "TRUE", "true", "1", "1.0"}: v = True
        elif v in {"False", "FALSE", "false", "0", "0.0"}: v = False
        else: return
        self.set(v)
        m.refresh()
        m.redraw()
    def fn_reset(self):
        self.set(self.rna.default)
        m.refresh()
        m.redraw()
    def fn_detail(self):
        # /* 0ui_fn_detail
        if not hasattr(self.rna, "description"): return
        name = self.rna.name
        if not name: name = " "
        description = self.rna.description
        if not isinstance(description, str):    description = description()
        if not description: description = "No description."
        details = INFO(name, description)
        evt = m.EVT.evt
        blf_size(font_0, F[9])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, F[480])
        e = BLF(text=details.body)
        hi = round(e.R_dimen_y()) + F[-1] + F[46]
        e.text = details.title
        hi += round(e.R_dimen_y())
        wi = F[480]
        blf_disable(font_0, WORD_WRAP)
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), details)
        # */
    def fn_rm(self, evt):
        # /* 0ui_BOOLEAN_fn_rm
        # <<< 1copy (ui_fn_rm_head,, $$)
        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y, [
        # >>>
            # <<< 1copy (ui_fn_rm_copy,, $$)
            {9: "fn_copy", 0: "Copy Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_paste,, $$)
            {9: "fn_paste", 0: "Paste Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_reset,, $$)
            {9: "fn_reset", 0: "Reset to Default Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_detail,, $$)
            {9: "fn_detail", 0: "Details"},
            # >>>
        # <<< 1copy (ui_fn_rm_end,, $$)
        ])
        # >>>
        # */
    #
    #
class BOOLEAN_ENUM(BOOLEAN):
    __slots__ = 'offset_x', 'offset_y'
    def __init__(self, w, rna, fn_get, fn_set):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set

        self.rim = BOX(P.color_bu_1_rim)
        self.bo = BOX(P.color_bu_1_off)
        self.ti = BLF()
        self.da = BLF(P.color_font, rna.name)
        self.da.name = None
        self.is_title_left = True
        self.offset_x = 0
        self.offset_y = 0

    def enable(self):

        self.is_enable = True
        self.rim.color = P.color_bu_1_rim
        self.bo.color = P.color_bu_1_off  if self.bo.L > self.rim.L else P.color_bu_1_on
        self.da.color = P.color_font
    def disable(self):

        self.is_enable = False
        self.rim.color = P.color_bu_1_rim_ignore
        self.bo.color = P.color_bu_1_ignore  if self.bo.L > self.rim.L else P.color_bu_1_ignore_on
        self.da.color = P.color_font_ignore

    def draw_box(self):
        self.rim.bind_draw()
        self.bo.bind_draw()
    def draw_blf(self):
        self.da.draw_color_pos()
        if self.ti.text:    self.ti.draw_pos()

    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            da = self.da
            da.name = v
            rim = self.rim
            bo = self.bo
            if v is True:
                bo.LRBT_upd(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
                bo.color = P.color_bu_1_on
            else:
                bo.LRBT_upd(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
                bo.color = P.color_bu_1_off
            da.xy(bo.L + self.offset_x, bo.B + self.offset_y)
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bo.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

    # /* 0BOOLEAN_ENUM_get_bo
    def get_bo(self, L, R, B, T): # need set_size
        self.rim.LRBT_upd(L, R, B, T)
        bo = self.bo
        bo.LRBT_upd(L + F[1], R, B, T - F[1])
        da = self.da
        da.y = B + F[4]
        da.set_x_by_bo(bo)
        if self.ti.text:
            if self.is_title_left is True:
                self.ti.align_R(L - F[10])
                self.ti.y = B + F[5]
            else:
                self.ti.xy(R + F[7], B + F[5])

        self.offset_x = da.x - bo.L
        self.offset_y = da.y - bo.B
        return B
    # */

    def outside(self):
        if self.is_enable is True:
            self.bo.color = P.color_bu_1_on  if self.da.name is True else P.color_bu_1_off
            m.redraw()
        self.w.to_modal_default()
    def inside(self, evt):
        if self.is_enable is None: return
        self.is_allow = True
        if self.is_enable is True:
            if self.da.name is False:
                self.bo.color = P.color_bu_1_fo
                m.redraw()
        self.w.to_modal(self.I_modal_main)
        self.I_modal_main(evt)
    #
    #
class BOOL_INT_ENUM(BOOLEAN_ENUM):
    __slots__ = ()
    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            da = self.da
            da.name = v
            rim = self.rim
            bo = self.bo
            if v == 0:
                bo.LRBT_upd(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
                bo.color = P.color_bu_1_off
            else:
                bo.LRBT_upd(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
                bo.color = P.color_bu_1_on
            da.xy(bo.L + self.offset_x, bo.B + self.offset_y)
    def outside(self):
        if self.is_enable is True:
            self.bo.color = P.color_bu_1_off  if self.da.name == 0 else P.color_bu_1_on
            m.redraw()
        self.w.to_modal_default()
    def inside(self, evt):
        if self.is_enable is None: return
        self.is_allow = True
        if self.is_enable is True:
            if self.da.name == 0:
                self.bo.color = P.color_bu_1_fo
                m.redraw()
        self.w.to_modal(self.I_modal_main)
        self.I_modal_main(evt)
class BUTTON(BOOLEAN_ENUM):
    __slots__ = 'first_press', 'rm_data', 'fx'
    def __init__(self, w, rna, rm_data=None):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.rm_data = rm_data

        self.rim = BOX(P.color_bu_1_rim)
        self.bo = BOX(P.color_bu_1_off)
        self.ti = BLF()
        self.da = BLF(P.color_font, rna.default)
        self.da.name = None
        self.is_title_left = True
        self.offset_x = 0
        self.offset_y = 0

    def da_upd(self): pass
    def outside(self):
        rim = self.rim
        bo = self.bo
        bo.LRBT_upd(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
        bo.color = P.color_bu_1_off  if self.is_enable is True else P.color_bu_1_ignore
        self.da.xy(bo.L + self.offset_x, bo.B + self.offset_y)
        m.redraw()
        self.w.to_modal_default()
    def inside(self, evt):
        if self.is_enable is not True: return
        self.is_allow = True
        self.first_press = False
        if self.is_enable is True:
            self.bo.color = P.color_bu_1_fo
            m.redraw()
        self.w.to_modal(self.I_modal_main)
        self.I_modal_main(evt)

    def I_modal_main(self, evt):
        # <<< || 1copy (0ui_is_out, 0, ${}$)
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.is_inside(x, y) is False:
            self.outside()
            return
        # >>>

        if evt.value == 'PRESS':
            self.first_press = True
            rim = self.rim
            bo = self.bo
            bo.LRBT_upd(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
            bo.color = P.color_bu_1_on
            self.da.xy(bo.L + self.offset_x, bo.B + self.offset_y)
            m.redraw()
        elif evt.value == 'RELEASE':
            self.is_allow = True
            rim = self.rim
            bo = self.bo
            bo.LRBT_upd(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
            bo.color = P.color_bu_1_fo  if self.is_enable else P.color_bu_1_ignore
            self.da.xy(bo.L + self.offset_x, bo.B + self.offset_y)
            m.redraw()
        if K["bu_sel0"].true():
            if self.is_allow is False: return True
            if K["bu_sel0"].value != "RELEASE": self.is_allow = False
            if self.first_press:    self.fn()
            return True
        if K["bu_sel1"].true():
            if self.is_allow is False: return True
            if K["bu_sel1"].value != "RELEASE": self.is_allow = False
            if self.first_press:    self.fn()
            return True
        # <<< || 1copy (0ui_rm_base_evt, 0, ${}$)
        if K["rm0"].true() or K["rm1"].true():
            self.fn_rm(evt)
            return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            if hasattr(self, "fn_copy_array"):
                self.fn_copy_array()
            else:
                self.fn_copy()
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.fn_reset()
            return True
        # >>>

    def fn(self):
        if hasattr(self, "fx"): self.fx()
        else:
            self.rna.fx()
    def fn_copy(self): pass
    def fn_paste(self): pass
    def fn_reset(self): pass
    def fn_rm(self, evt):
        li = [
            # <<< 1copy (ui_fn_rm_detail,, $$)
            {9: "fn_detail", 0: "Details"},
            # >>>
        ]
        if self.rm_data is not None:
            li += self.rm_data
        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y, li)
class BUTTON17(BUTTON):
    __slots__ = ()
    # <<< || 1copy (0BOOLEAN_ENUM_get_bo,, ${'da.y = B + F[4]':'da.y = B + F[5]'}$)
    def get_bo(self, L, R, B, T): # need set_size
        self.rim.LRBT_upd(L, R, B, T)
        bo = self.bo
        bo.LRBT_upd(L + F[1], R, B, T - F[1])
        da = self.da
        da.y = B + F[5]
        da.set_x_by_bo(bo)
        if self.ti.text:
            if self.is_title_left is True:
                self.ti.align_R(L - F[10])
                self.ti.y = B + F[5]
            else:
                self.ti.xy(R + F[7], B + F[5])

        self.offset_x = da.x - bo.L
        self.offset_y = da.y - bo.B
        return B
    # >>>
class BUTTON20(BUTTON):
    __slots__ = ()
    # <<< || 1copy (0BOOLEAN_ENUM_get_bo,, ${'da.y = B + F[4]':'da.y = B + F[-5.6]'}$)
    def get_bo(self, L, R, B, T): # need set_size
        self.rim.LRBT_upd(L, R, B, T)
        bo = self.bo
        bo.LRBT_upd(L + F[1], R, B, T - F[1])
        da = self.da
        da.y = B + F[-5.6]
        da.set_x_by_bo(bo)
        if self.ti.text:
            if self.is_title_left is True:
                self.ti.align_R(L - F[10])
                self.ti.y = B + F[5]
            else:
                self.ti.xy(R + F[7], B + F[5])

        self.offset_x = da.x - bo.L
        self.offset_y = da.y - bo.B
        return B
    # >>>

class STRING(RNA):
    __slots__ = 'is_fix_long_text', 'offset_x_key'
    def __init__(self, w, rna, fn_get, fn_set, is_fix_long_text=True, offset_x_key=5):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set
        self.offset_x_key = offset_x_key

        self.rim = BOX(P.color_bu_3_off)
        self.ti = BLF(text=rna.name)
        self.da = BLF(P.color_font)
        self.da.name = None
        self.is_title_left = True
        self.is_fix_long_text = is_fix_long_text

    def enable(self):

        self.is_enable = True
        self.rim.color = P.color_bu_3_off
        self.da.color = P.color_font
    def disable(self):

        self.is_enable = False
        self.rim.color = P.color_bu_3_ignore
        self.da.color = P.color_font_ignore

    def draw_box(self):
        self.rim.bind_draw()
    def draw_blf(self):
        self.da.draw_color_pos()
        self.ti.draw_pos()

    def set_da(self, v):
        self.da.name = v
        self.da.text = v
        # <<< 1copy (0ui_da_upd_fix_long_text, -4, $$)
        if self.is_fix_long_text is True:
            blf_size(font_0, F[9])
            self.da.fix_long_text(self.rim.R - F[12], F[8])
        # >>>
    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            self.da.name = v
            self.da.text = v
            # /* 0ui_da_upd_fix_long_text
            if self.is_fix_long_text is True:
                blf_size(font_0, F[9])
                self.da.fix_long_text(self.rim.R - F[12], F[8])
            # */
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

    def get_bo(self, L, R, B, T): # need set_size if title left
        self.rim.LRBT_upd(L, R, B, T)
        self.da.xy(L + F[self.offset_x_key], B + F[5])
        if self.is_title_left is True:
            self.ti.align_R(L - F[10])
            self.ti.y = B + F[5]
        else:
            self.ti.xy(R + F[7], B + F[5])
        return B

    def is_inside(self, x, y): return self.rim.inbox_xy(x, y)
    def outside(self):
        if self.is_enable is True:
            self.rim.color = P.color_bu_3_off
            m.redraw()
        self.w.to_modal_default()
    def inside(self, evt):
        if self.is_enable is None: return
        if self.is_enable is True:
            self.rim.color = P.color_bu_3_fo
            m.redraw()
        self.w.to_modal(self.I_modal_main)
        self.I_modal_main(evt)

    def I_modal_main(self, evt):
        # <<< || 1copy (0ui_is_out, 0, ${}$)
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.is_inside(x, y) is False:
            self.outside()
            return
        # >>>

        if K["sel_fast0"].true() or K["sel_fast1"].true():
            self.fn()
            return True
        # <<< || 1copy (0ui_rm_base_evt, 0, ${}$)
        if K["rm0"].true() or K["rm1"].true():
            self.fn_rm(evt)
            return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            if hasattr(self, "fn_copy_array"):
                self.fn_copy_array()
            else:
                self.fn_copy()
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.fn_reset()
            return True
        # >>>

    def fn(self):
        def end_fn():
            if menu.is_dd_confirm is False: return
            self.set(menu.confirm_text)
            m.refresh()
            m.redraw()

        rna = self.rna
        if hasattr(rna, "filter_enums"):
            e = FIL(rna.filter_enums()  if callable(rna.filter_enums) else rna.filter_enums)
        elif hasattr(rna, "enum_items") and rna.enum_items:
            e = FIL(o  for o in rna.enum_items)
        else: e = None
        menu = DDTX(self, e, tx_clear=e is not None, end_fn=end_fn)
    # <<< || 1copy (ui_def_fn_copy,, $$)
    def fn_copy(self):
        bpy.context.window_manager.clipboard = str(self.get())
    # >>>
    def fn_paste(self):
        self.set(bpy.context.window_manager.clipboard)
        m.refresh()
        m.redraw()
    def fn_reset(self):
        self.set(self.rna.default)
        m.refresh()
        m.redraw()
    def fn_detail(self):
        # <<< 1copy (0ui_fn_detail,, $$)
        if not hasattr(self.rna, "description"): return
        name = self.rna.name
        if not name: name = " "
        description = self.rna.description
        if not isinstance(description, str):    description = description()
        if not description: description = "No description."
        details = INFO(name, description)
        evt = m.EVT.evt
        blf_size(font_0, F[9])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, F[480])
        e = BLF(text=details.body)
        hi = round(e.R_dimen_y()) + F[-1] + F[46]
        e.text = details.title
        hi += round(e.R_dimen_y())
        wi = F[480]
        blf_disable(font_0, WORD_WRAP)
        DETAILS((wi, hi), (evt.mouse_region_x - wi // 2, evt.mouse_region_y + hi // 2), details)
        # >>>
    def fn_rm(self, evt):
        # <<< 1copy (0ui_BOOLEAN_fn_rm,, $$)
        # <<< 1copy (ui_fn_rm_head,, $$)
        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y, [
        # >>>
            # <<< 1copy (ui_fn_rm_copy,, $$)
            {9: "fn_copy", 0: "Copy Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_paste,, $$)
            {9: "fn_paste", 0: "Paste Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_reset,, $$)
            {9: "fn_reset", 0: "Reset to Default Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_detail,, $$)
            {9: "fn_detail", 0: "Details"},
            # >>>
        # <<< 1copy (ui_fn_rm_end,, $$)
        ])
        # >>>
        # >>>
    #
    #
class STRING_SUBTI(SUBTI, STRING):
    __slots__ = 'sub_ti'
class STRING_COLOR_HEX(STRING_SUBTI):
    __slots__ = 'tx_format'
    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            self.da.name = v
            self.da.text = self.tx_format(v)
class STRING_ENUM(STRING):
    __slots__ = ()
    def set_da(self, v):
        self.da.name = v
        self.da.text = v
        # <<< 1copy (0ui_da_upd_fix_long_text, -4, $$)
        if self.is_fix_long_text is True:
            blf_size(font_0, F[9])
            self.da.fix_long_text(self.rim.R - F[12], F[8])
        # >>>
    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            self.da.name = v
            self.da.text = self.rna.enum_items[v].name  if v in self.rna.enum_items else v
            # <<< 1copy (0ui_da_upd_fix_long_text,, $$)
            if self.is_fix_long_text is True:
                blf_size(font_0, F[9])
                self.da.fix_long_text(self.rim.R - F[12], F[8])
            # >>>
class POINTER(STRING_ENUM):
    __slots__ = ()
    def fn(self):
        def end_fn():
            if menu.is_dd_confirm is False: return
            self.set(menu.confirm_text)
            m.refresh()
            m.redraw()

        e = FIL_TYPE_EXC(getattr(bpy.data, self.rna.fixed_type))
        prop = self.get()
        name = prop[0]
        if not isinstance(name, str):
            name = f'"{name[0]}", "{name[1]}"'
        menu = DDTX({"name": name, "LRBT": self.rim.R_LRBT()}, e, tx_clear=e is not None, end_fn=end_fn)
    def da_upd(self):
        prop = self.get()
        name = prop[0]
        if prop[1] == None:
            if self.rna.is_check and prop[0]: prop[0] = ""
        else:
            try:    prop[1].name
            except:
                collections = getattr(bpy.data, self.rna.fixed_type)
                prop[1] = collections[name]  if name in collections else None

            if prop[1] == None:
                if self.rna.is_check and prop[0]: prop[0] = ""
            else:
                if isinstance(name, str):
                    if name != prop[1].name:

                        v = prop[1].name
                        prop[0] = v
                        self.da.name = prop[:]
                        self.da.text = v
                        # <<< 1copy (0ui_da_upd_fix_long_text,, $$)
                        if self.is_fix_long_text is True:
                            blf_size(font_0, F[9])
                            self.da.fix_long_text(self.rim.R - F[12], F[8])
                        # >>>
                        return

        if self.da.name != prop:

            name = prop[0]
            v = name  if isinstance(name, str) else f'"{name[0]}", "{name[1]}"'
            self.da.name = prop[:]
            self.da.text = v
            # <<< 1copy (0ui_da_upd_fix_long_text,, $$)
            if self.is_fix_long_text is True:
                blf_size(font_0, F[9])
                self.da.fix_long_text(self.rim.R - F[12], F[8])
            # >>>

    def fn_copy(self):
        prop = self.get()
        if prop[1] == None:
            name = prop[0]
            s = name  if isinstance(name, str) else f'"{name[0]}", "{name[1]}"'
        else:
            s = R_lib_str(prop[1])
        bpy.context.window_manager.clipboard = s
class KEYMAP_TYPE(STRING):
    __slots__ = 'offset_x', 'offset_y', 'is_timer_type', 'enum'
    def __init__(self, w, rna, fn_get, fn_set, enum, is_fix_long_text=True):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set

        self.rim = BOX(P.color_bu_1_rim)
        self.bo = BOX(P.color_bu_1_off)
        self.ti = BLF()
        self.da = BLF(P.color_font)
        self.da.name = None
        self.is_title_left = True
        self.enum = enum
        self.is_fix_long_text = is_fix_long_text
        self.is_timer_type = False
        self.offset_x = 0
        self.offset_y = 0

    def enable(self):

        self.is_enable = True
        self.rim.color = P.color_bu_1_rim
        self.bo.color = P.color_bu_1_off  if self.bo.L > self.rim.L else P.color_bu_1_on
        self.da.color = P.color_font
    def disable(self):

        self.is_enable = False
        self.rim.color = P.color_bu_1_rim_ignore
        self.bo.color = P.color_bu_1_ignore  if self.bo.L > self.rim.L else P.color_bu_1_ignore_on
        self.da.color = P.color_font_ignore

    def draw_box(self):
        self.rim.bind_draw()
        self.bo.bind_draw()

    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            da = self.da
            da.name = v
            da.text = self.enum[v]  if v in self.enum else v
            rim = self.rim
            bo = self.bo
            if v == "NONE":
                bo.LRBT_upd(rim.L + F[1], rim.R, rim.B, rim.T - F[1])
                bo.color = P.color_bu_1_off
            else:
                bo.LRBT_upd(rim.L, rim.R - F[1], rim.B + F[1], rim.T)
                bo.color = P.color_bu_1_on
            da.xy(bo.L + self.offset_x, bo.B + self.offset_y)
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bo.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

    def get_bo(self, L, R, B, T): # need set_size
        self.rim.LRBT_upd(L, R, B, T)
        bo = self.bo
        bo.LRBT_upd(L + F[1], R, B, T - F[1])
        da = self.da
        da.xy(L + F[5], B + F[4])
        if self.ti.text:
            self.ti.align_R(L - F[10])
            self.ti.y = B + F[5]
        self.offset_x = da.x - bo.L
        self.offset_y = da.y - bo.B
        if self.da.name is not None:
            self.da.name = None
        return B

    def outside(self):
        if self.is_enable is True:
            self.bo.color = P.color_bu_1_off  if self.da.name == "NONE" else P.color_bu_1_on
            m.redraw()
        self.w.to_modal_default()
    def inside(self, evt):
        if self.is_enable is None: return
        if self.is_enable is True:
            if self.da.name == "NONE":
                self.bo.color = P.color_bu_1_fo
                m.redraw()
        self.w.to_modal(self.I_modal_main)
        self.I_modal_main(evt)

    def fn(self):
        if self.is_timer_type is False:
            def end_fn(ks):
                v = ks[0]  if ks else "NONE"
                self.set(v)
                m.refresh()
                m.redraw()

            KEY_ED_SINGLE(self, m.EVT.evt, end_fn, f" :  {self.rna.name}")
        elif self.is_timer_type is True:
            def end_fn():
                if menu.is_dd_confirm is False: return
                self.set(menu.confirm_text)
                m.refresh()
                m.redraw()

            e = FIL(NAME(o)  for o in D_timer_type_rev)
            menu = DDTX(self, e, tx_clear=True, end_fn=end_fn)

class INT(STRING):
    __slots__ = 'tx_format', 'step', 'area', 'R_qe_dx', 'key_slow', 'key_fast', 'qe_fn', 'qe_value', 'qe_org', 'qe_unit', 'qe_unit_slow', 'qe_unit_fast'
    def __init__(self, w, rna, fn_get, fn_set, offset_x_key=5):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set
        self.offset_x_key = offset_x_key

        self.rim = BOX(P.color_bu_3_off)
        self.ti = BLF(text=rna.name)
        self.da = BLF(P.color_font)
        self.da.name = None
        self.is_title_left = True
        self.tx_format = m.U_format_i
        self.step = 1
        self.area = None

    def set_da(self, v):
        self.da.name = v
        self.da.text = self.tx_format(v)
    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            self.da.name = v
            self.da.text = self.tx_format(v)

    def outside(self):
        if self.is_enable is True:
            self.rim.color = P.color_bu_3_off
            m.redraw()
            self.area = None
            m.M.set_mou_ic('DEFAULT')
        self.w.to_modal_default()
    def inside(self, evt):
        if self.is_enable is None: return
        if self.is_enable is True:
            self.rim.color = P.color_bu_3_fo
            m.redraw()
            if evt.mouse_region_x <= self.rim.L + F[16]:
                self.area = False
                m.M.set_mou_ic('SCROLL_X')
            elif evt.mouse_region_x >= self.rim.R - F[16]:
                self.area = True
                m.M.set_mou_ic('SCROLL_X')
            else:
                self.area = None
                m.M.set_mou_ic('DEFAULT')
        else:
            self.area = None
        self.w.to_modal(self.I_modal_main)
        self.I_modal_main(evt)

    def I_modal_main(self, evt):
        # <<< || 1copy (0ui_is_out, 0, ${}$)
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.is_inside(x, y) is False:
            self.outside()
            return
        # >>>

        if self.is_enable is True:
            if evt.mouse_region_x <= self.rim.L + F[16]:
                if self.area is not False:
                    self.area = False
                    m.M.set_mou_ic('SCROLL_X')
            elif evt.mouse_region_x >= self.rim.R - F[16]:
                if self.area is not True:
                    self.area = True
                    m.M.set_mou_ic('SCROLL_X')
            else:
                if self.area is not None:
                    self.area = None
                    m.M.set_mou_ic('DEFAULT')

        # /* 0ui_int_evt
        if K["bu_qe0"].true():
            self.to_modal_qe(evt, K["bu_qe0"], K["bu_qe_E0"])
            return True
        if K["bu_qe1"].true():
            self.to_modal_qe(evt, K["bu_qe1"], K["bu_qe_E1"])
            return True
        if K["bu_sel0"].true() or K["bu_sel1"].true():
            if self.area is False:  self.fn_step(-self.step)
            elif self.area is True: self.fn_step(self.step)
            else: self.fn()
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.fn_rm(evt)
            return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            self.fn_copy_array()
            return True
        if K["bu_reset_all0"].true() or K["bu_reset_all1"].true():
            self.fn_reset_all()
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.fn_reset()
            return True
        if K["bu_left0"].true() or K["bu_left1"].true():
            self.fn_step(-self.step)
            return True
        if K["bu_right0"].true() or K["bu_right1"].true():
            self.fn_step(self.step)
            return True
        if K["bu_up0"].true() or K["bu_up1"].true():
            self.fn_step(10*self.step)
            return True
        if K["bu_down0"].true() or K["bu_down1"].true():
            self.fn_step(-10*self.step)
            return True
        # */

    def is_alt(self, evt):    return evt.alt
    def is_ctrl(self, evt):   return evt.ctrl
    def is_shift(self, evt):  return evt.shift
    def is_oskey(self, evt):  return evt.oskey
    def NF(self, evt):        return False
    def modal_qe_end(self, cancel=False):

        m.upd_enable()
        del m.head_modal[-1]

        QE.state = -2
        m.EVT.kill()
        m.I_end_pan_hide(self)

        v = self.qe_org
        if hasattr(v, "__len__"):
            da = self.da
            for r, v0 in zip(self.qe_range, v):
                e = da[r]
                e.name = v0
                e.text = self.tx_format(v0)
            self.set(v, undo_push=False, ind=self.qe_ind)
            if cancel is False:
                QE.state = -1
                qe_v = self.qe_value  if hasattr(self, "unit") else round(self.qe_value)
                self.set([qe_v] * self.qe_l, ind=self.qe_ind)

            for e in self.rim:  e.color = P.color_bu_3_off
            self.act_ind = -1
        elif hasattr(self, 'act_ind'):
            ind = self.act_ind
            da = self.da[ind]
            da.name = v
            da.text = self.tx_format(v)
            self.set(v, undo_push=False, ind=ind)
            if cancel is False:
                QE.state = -1
                qe_v = self.qe_value  if hasattr(self, "unit") else round(self.qe_value)
                self.set(qe_v, ind=ind)
        else:
            self.da.name = v
            self.da.text = self.tx_format(v)
            self.set(v, undo_push=False)
            if cancel is False:
                QE.state = -1
                qe_v = self.qe_value  if hasattr(self, "unit") else round(self.qe_value)
                self.set(qe_v)

        QE.kill()
        m.refresh()
    def to_modal_qe(self, evt, key_start, key_end):

        self.da_upd()
        m.upd_disable()
        self.key_start = key_start
        self.key_end = key_end
        key_end.true()

        r = m.region_data
        m.get_loop_mou_info_region(evt, r.L, r.R, r.B, r.T)
        m.get_mou(evt)
        tm = m.tm
        tm["x"] = evt.mouse_x
        tm["y"] = evt.mouse_y
        tm["bu"] = self
        try:    m.M.set_mou_ic(P.quick_edit_cursor)
        except: pass

        if P.quick_edit_method == 'HORIZONTAL':
            self.R_qe_dx = lambda: m.dx
        else:
            self.R_qe_dx = lambda: m.dy
        dic = m.dic_hold_key
        slow0 = K["bu_qe_slow0"].type0
        self.key_slow = getattr(self, f"is_{dic[slow0]}") if slow0 in dic else self.NF
        fast0 = K["bu_qe_fast0"].type0
        self.key_fast = getattr(self, f"is_{dic[fast0]}") if fast0 in dic else self.NF
        self.qe_fn = getattr(self, f"I_qe_{P.quick_edit_operation}")
        self.qe_value = self.da[self.act_ind].name  if hasattr(self, 'act_ind') else self.da.name
        self.qe_org = self.qe_value
        self.qe_unit = getattr(P, f'{m.R_calc_attr(R_rna_ty(self.rna))}qe')
        self.qe_unit_slow = P.quick_edit_fac_slow * self.qe_unit
        self.qe_unit_fast = P.quick_edit_fac_fast * self.qe_unit

        QE.state = 0
        if self.is_to_modal_multi(evt, key_start): return
        m.head_modal.append(self.I_modal_qe)
    def is_to_modal_multi(self, evt, mk): return False
    def I_modal_qe(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true() or evt.type == "ESC":
            self.modal_qe_end(True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_qe_end()
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_qe_end()
                return

        m.I_pan(evt)
        if self.key_slow(evt):      self.qe_fn(self.R_qe_dx() * self.qe_unit_slow)
        elif self.key_fast(evt):    self.qe_fn(self.R_qe_dx() * self.qe_unit_fast)
        else:                       self.qe_fn(self.R_qe_dx() * self.qe_unit)
        m.loop_mou(evt)

    def I_qe_REAL_TIME(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.set(v, undo_push=False)
        self.da.text = self.tx_format(v)
    def I_qe_PERFORMANCE(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.da.text = self.tx_format(v)

    def fn_step(self, step):
        self.set(self.get() + step)
        m.refresh()
        m.redraw()
    def fn(self, end_fn=None, multi_edit=None):
        rna = self.rna
        DDVAL(self, R_rna_ty(rna), end_fn=end_fn, local_undo=m.N, multi_edit=multi_edit)
    def fn_copy_array(self): self.fn_copy()
    def fn_reset_all(self): self.fn_reset()
    def fn_paste(self):
        try:

            vv = calc_vec(bpy.context.window_manager.clipboard)
            self.set(vv[0])
            m.refresh()
            m.redraw()
        except: pass
    #
    #
class INT_ARRAY(INT):
    __slots__ = 'act_ind', 'l', 'qe_ind', 'qe_range', 'qe_l'
    def __init__(self, w, rna, fn_get, fn_set, offset_x_key=5):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set
        self.offset_x_key = offset_x_key
        self.act_ind = None
        l = rna.array_length
        self.l = l

        self.rim = [BOX(P.color_bu_3_off)  for r in range(l)]
        self.ti = BLF(text=rna.name)
        self.da = [BLF(P.color_font)  for r in range(l)]
        for e in self.da:   e.name = None
        self.is_title_left = True
        self.tx_format = m.U_format_i
        self.step = 1
        self.area = None

    def enable(self):

        self.is_enable = True
        for e in self.rim:  e.color = P.color_bu_3_off
        for e in self.da:   e.color = P.color_font
    def disable(self):

        self.is_enable = False
        for e in self.rim:  e.color = P.color_bu_3_ignore
        for e in self.da:   e.color = P.color_font_ignore

    def draw_box(self):
        for e in self.rim:  e.bind_draw()
    def draw_blf(self):
        for e in self.da:   e.draw_color_pos()
        self.ti.draw_pos()

    def da_upd(self):
        vs = self.get()
        for e, v in zip(self.da, vs):
            if e.name != v:
                e.name = v
                e.text = self.tx_format(v)
    def dxy(self, x, y):
        for e in self.rim:  e.dxy_upd(x, y)
        self.ti.dxy(x, y)
        for e in self.da:   e.dxy(x, y)

    def get_bo(self, L, R, B, T): # need set_size if title left
        h = T - B
        _1 = F[1]
        _5 = F[5]
        self.ti.y = B + _5

        for rim, da in zip(self.rim, self.da):
            rim.LRBT_upd(L, R, B, T)
            da.xy(L + F[self.offset_x_key], B + _5)
            T = B - _1
            B = T - h

        if self.is_title_left is True:
            self.ti.align_R(L - F[10])
        else:
            self.ti.x = R + F[7]
        return rim.B

    def is_inside(self, x, y):
        if self.rim[0].in_LR_x(x):
            ind = -1
            for r, e in enumerate(self.rim):
                if y >= e.B:
                    ind = r
                    break
            if ind == -1: return False
            if y <= self.rim[0].T:
                self.act_ind = ind
                return True
        return False
    def outside(self):
        if self.is_enable is True:
            for e in self.rim:  e.color = P.color_bu_3_off
            m.redraw()
            self.area = None
            m.M.set_mou_ic('DEFAULT')
        self.act_ind = None
        self.w.to_modal_default()
    def inside(self, evt):
        if self.is_enable is None: return
        if self.act_ind is None: return
        if self.is_enable is True:
            e = self.rim[self.act_ind]
            e.color = P.color_bu_3_fo
            m.redraw()
            if evt.mouse_region_x <= e.L + F[16]:
                self.area = False
                m.M.set_mou_ic('SCROLL_X')
            elif evt.mouse_region_x >= e.R - F[16]:
                self.area = True
                m.M.set_mou_ic('SCROLL_X')
            else:
                self.area = None
                m.M.set_mou_ic('DEFAULT')
        self.w.to_modal(self.I_modal_main)
        self.I_modal_main(evt)

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        old_ind = self.act_ind
        if self.is_inside(x, y) is False:
            self.outside()
            return

        if self.is_enable is True:
            if evt.mouse_region_x <= self.rim[0].L + F[16]:
                if self.area is not False:
                    self.area = False
                    m.M.set_mou_ic('SCROLL_X')
            elif evt.mouse_region_x >= self.rim[0].R - F[16]:
                if self.area is not True:
                    self.area = True
                    m.M.set_mou_ic('SCROLL_X')
            else:
                if self.area is not None:
                    self.area = None
                    m.M.set_mou_ic('DEFAULT')

            if old_ind != self.act_ind:
                m.redraw()
                self.rim[old_ind].color = P.color_bu_3_off
                self.rim[self.act_ind].color = P.color_bu_3_fo

        # <<< || 1copy (0ui_int_evt, 0, ${}$)
        if K["bu_qe0"].true():
            self.to_modal_qe(evt, K["bu_qe0"], K["bu_qe_E0"])
            return True
        if K["bu_qe1"].true():
            self.to_modal_qe(evt, K["bu_qe1"], K["bu_qe_E1"])
            return True
        if K["bu_sel0"].true() or K["bu_sel1"].true():
            if self.area is False:  self.fn_step(-self.step)
            elif self.area is True: self.fn_step(self.step)
            else: self.fn()
            return True
        if K["rm0"].true() or K["rm1"].true():
            self.fn_rm(evt)
            return True
        if K["dd_copy0"].true() or K["dd_copy1"].true():
            self.fn_copy()
            return True
        if K["dd_paste0"].true() or K["dd_paste1"].true():
            self.fn_paste()
            return True
        if K["dd_cut0"].true() or K["dd_cut1"].true():
            self.fn_copy_array()
            return True
        if K["bu_reset_all0"].true() or K["bu_reset_all1"].true():
            self.fn_reset_all()
            return True
        if K["bu_reset0"].true() or K["bu_reset1"].true():
            self.fn_reset()
            return True
        if K["bu_left0"].true() or K["bu_left1"].true():
            self.fn_step(-self.step)
            return True
        if K["bu_right0"].true() or K["bu_right1"].true():
            self.fn_step(self.step)
            return True
        if K["bu_up0"].true() or K["bu_up1"].true():
            self.fn_step(10*self.step)
            return True
        if K["bu_down0"].true() or K["bu_down1"].true():
            self.fn_step(-10*self.step)
            return True
        # >>>

    def is_to_modal_multi(self, evt, mk):
        try:
            org_y = mk.org_y
            dx = evt.mouse_x - mk.org_x
            dy = evt.mouse_y - org_y
            if abs(dy) > abs(dx):
                org_y += evt.mouse_region_y - evt.mouse_y

                ind = self.act_ind
                for r, rim in enumerate(self.rim):
                    if org_y >= rim.B:
                        ind = r
                        break

                da = self.da[ind]
                self.qe_value = da.name
                self.qe_org = self.qe_value

                m.tm["ind"] = [ind, ind]

                m.head_modal.append(self.I_modal_multi)
                return True
            return False
        except:
            return False
        #
    def modal_multi_end(self, evt, cancel=False):

        m.upd_enable()
        del m.head_modal[-1]

        tm = m.tm
        QE.kill()
        m.EVT.kill()
        m.I_end_pan_hide(self)

        if cancel:
            self.fix_fo_off(evt.mouse_region_x, evt.mouse_region_y)
            self.act_ind = -1
        else:
            i0, i1 = tm["ind"]
            if i0 > i1: i0, i1 = i1, i0
            self.act_ind = i1
            da = self.da
            old_text = {}
            for r in range(i0, i1):
                e = da[r]
                old_text[r] = e.text
                e.text = "  Multiple Editing"
            def end_fn():
                for r in range(i0, i1):
                    da[r].text = old_text[r]
                if tm["is_dd_confirm"] and tm["dd_confirm_value"] is not None:
                    v = [tm["dd_confirm_value"]] * (i1 - i0 + 1)
                    self.set(v, ind=(i0, i1 + 1))
                self.fix_fo_off(evt.mouse_region_x, evt.mouse_region_y)
                self.act_ind = -1
            self.fn(end_fn=end_fn, multi_edit=True)
    def I_modal_multi(self, evt):
        m.redraw()
        if K["bu_qe_cancel0"].true() or K["bu_qe_cancel1"].true() or evt.type == "ESC":
            self.modal_multi_end(evt, True)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_multi_end(evt)
                return
        if self.key_end.value == 'PRESS':
            if K["sel_fast0"].true() or K["sel_fast1"].true():
                self.modal_multi_end(evt)
                return

        m.I_pan(evt)
        tm_ind = m.tm["ind"]

        i0 = self.R_ind_by_y(evt.mouse_region_y)
        i1 = tm_ind[0]
        tm_ind[1] = i0
        if i0 > i1: i0, i1 = i1, i0
        for r, e in enumerate(self.rim):
            if i0 <= r <= i1:
                if e.color != P.color_bu_3_fo:  e.color = P.color_bu_3_fo
            else:
                if e.color != P.color_bu_3_off: e.color = P.color_bu_3_off

        if abs(evt.mouse_region_x - m.tm["x"]) >= P.th_multi_drag:

            self.qe_fn = getattr(self, f"I_qe_multi_{P.quick_edit_operation}")
            self.qe_ind = (i0, i1 + 1)
            self.qe_range = range(*self.qe_ind)
            self.qe_l = i1 - i0 + 1
            da = self.da
            self.qe_org = [da[r].name  for r in self.qe_range]
            m.head_modal[-1] = self.I_modal_qe

    def fix_fo_off(self, x, y):
        if self.is_inside(x, y):
            i = self.act_ind
            for r, e in enumerate(self.rim):
                e.color = P.color_bu_3_fo  if r == i else P.color_bu_3_off
        else:
            for e in self.rim:  e.color = P.color_bu_3_off
    def R_ind_by_y(self, y): # never None
        for r, e in enumerate(self.rim):
            if y >= e.B: return r
        return r
    def I_qe_REAL_TIME(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        ind = self.act_ind
        self.set(v, undo_push=False, ind=ind)
        self.da[ind].text = self.tx_format(v)
    def I_qe_PERFORMANCE(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.da[self.act_ind].text = self.tx_format(v)
    def I_qe_multi_REAL_TIME(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        self.set([v] * self.qe_l, undo_push=False, ind=self.qe_ind)
        tx = self.tx_format(v)
        for r in self.qe_range:
            self.da[r].text = tx
    def I_qe_multi_PERFORMANCE(self, dx):
        self.qe_value += dx
        v = round(self.qe_value)
        tx = self.tx_format(v)
        for r in self.qe_range:
            self.da[r].text = tx

    def fn_step(self, step):
        ind = self.act_ind
        self.set(self.get()[ind] + step, ind=ind)
        m.refresh()
        m.redraw()
    # /* 0dd_array_rm_code
    def fn_copy(self):
        if hasattr(self, "act_ind") and self.act_ind != None:
            v = self.get(self.act_ind)
            bpy.context.window_manager.clipboard = m.R_str_by_float(v)  if isinstance(v, float) else f"{v}"
        else:
            self.fn_copy_array()
    def fn_copy_array(self):
        lis = [v  for v in self.get()]
        s = ""
        for v in lis:
            s += m.R_str_by_float(v) if isinstance(v, float) else f"{v}"
            s += ","
        bpy.context.window_manager.clipboard = s[: -1]
    def fn_paste(self):
        try:

            vv = calc_vec(bpy.context.window_manager.clipboard)
            if len(vv) == 1:
                self.set(vv[0], ind=self.act_ind)
            else:
                v = vv[0 : self.l]
                self.set(v, ind=(0, len(v)))
            m.refresh()
            m.redraw()
        except: pass
    def fn_reset(self):
        if hasattr(self, "act_ind") and self.act_ind != None:
            self.set(self.rna.default_array[self.act_ind], ind=self.act_ind)
            m.refresh()
            m.redraw()
        else:
            self.fn_reset_all()
    def fn_reset_all(self):
        self.set(self.rna.default_array)
        m.refresh()
        m.redraw()
    def fn_rm(self, evt):
        # <<< 1copy (ui_fn_rm_head,, $$)
        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y, [
        # >>>
            # <<< 1copy (ui_fn_rm_copy,, $$)
            {9: "fn_copy", 0: "Copy Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_paste,, $$)
            {9: "fn_paste", 0: "Paste Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_reset,, $$)
            {9: "fn_reset", 0: "Reset to Default Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_detail,, $$)
            {9: "fn_detail", 0: "Details"},
            # >>>
            # <<< 1copy (ui_fn_rm_copy_array,, $$)
            {9: "fn_copy_array", 0: "Copy Array"},
            # >>>
            # <<< 1copy (ui_fn_rm_reset_all,, $$)
            {9: "fn_reset_all", 0: "Reset Array to Default"},
            # >>>
        # <<< 1copy (ui_fn_rm_end,, $$)
        ])
        # >>>
    # */
    #
    #
class INT_SUBTI(SUBTI, INT):
    __slots__ = 'sub_ti'
class INT_ARRAY_SUBTI(SUBTI_ARRAY, INT_ARRAY):
    __slots__ = 'sub_ti'
class FLOAT(INT):
    __slots__ = 'unit'
    def __init__(self, w, rna, fn_get, fn_set, offset_x_key=5):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set
        self.offset_x_key = offset_x_key

        self.rim = BOX(P.color_bu_3_off)
        self.ti = BLF(text=rna.name)
        self.da = BLF(P.color_font)
        self.da.name = None
        self.is_title_left = True
        self.area = None
        # <<< || 1copy (init_unit_format_step, 4, $$)
        self.step = rna.step / 100.0
        u = rna.unit
        if u in {"LENGTH", "VELOCITY"}:
            self.tx_format = m.U_FORMAT_F
            self.unit = 1
        elif u == "AREA":
            self.tx_format = m.U_FORMAT_F2
            self.unit = 2
        elif u == "VOLUME":
            self.tx_format = m.U_FORMAT_F3
            self.unit = 3
        else:
            self.tx_format = m.U_format_f
            self.unit = 0
        # >>>

    def fn_copy(self):
        v = self.get()
        bpy.context.window_manager.clipboard = m.R_str_by_float(v)

    def I_qe_REAL_TIME(self, dx):
        self.qe_value += dx
        v = self.qe_value
        self.set(v, undo_push=False)
        self.da.text = self.tx_format(v)
    def I_qe_PERFORMANCE(self, dx):
        self.qe_value += dx
        v = self.qe_value
        self.da.text = self.tx_format(v)
class FLOAT_ARRAY(INT_ARRAY):
    __slots__ = 'unit'
    def __init__(self, w, rna, fn_get, fn_set, offset_x_key=5):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set
        self.offset_x_key = offset_x_key
        self.act_ind = None
        l = rna.array_length
        self.l = l

        self.rim = [BOX(P.color_bu_3_off)  for r in range(l)]
        self.ti = BLF(text=rna.name)
        self.da = [BLF(P.color_font)  for r in range(l)]
        for e in self.da:   e.name = None
        self.is_title_left = True
        self.area = None
        # <<< || 1copy (init_unit_format_step, 4, $$)
        self.step = rna.step / 100.0
        u = rna.unit
        if u in {"LENGTH", "VELOCITY"}:
            self.tx_format = m.U_FORMAT_F
            self.unit = 1
        elif u == "AREA":
            self.tx_format = m.U_FORMAT_F2
            self.unit = 2
        elif u == "VOLUME":
            self.tx_format = m.U_FORMAT_F3
            self.unit = 3
        else:
            self.tx_format = m.U_format_f
            self.unit = 0
        # >>>

    def fn_copy(self):
        v = self.get(self.act_ind)
        bpy.context.window_manager.clipboard = m.R_str_by_float(v)

    def I_qe_REAL_TIME(self, dx):
        self.qe_value += dx
        v = self.qe_value
        ind = self.act_ind
        self.set(v, undo_push=False, ind=ind)
        self.da[ind].text = self.tx_format(v)
    def I_qe_PERFORMANCE(self, dx):
        self.qe_value += dx
        v = self.qe_value
        self.da[self.act_ind].text = self.tx_format(v)
    def I_qe_multi_REAL_TIME(self, dx):
        self.qe_value += dx
        v = self.qe_value
        self.set([v] * self.qe_l, undo_push=False, ind=self.qe_ind)
        tx = self.tx_format(v)
        for r in self.qe_range:
            self.da[r].text = tx
    def I_qe_multi_PERFORMANCE(self, dx):
        self.qe_value += dx
        v = self.qe_value
        tx = self.tx_format(v)
        for r in self.qe_range:
            self.da[r].text = tx
class FLOAT_SUBTI(SUBTI, FLOAT):
    __slots__ = 'sub_ti'
class FLOAT_ARRAY_SUBTI(SUBTI_ARRAY, FLOAT_ARRAY):
    __slots__ = 'sub_ti'
class FLOAT_RAD(FLOAT):
    __slots__ = ()
    def __init__(self, w, rna, fn_get, fn_set, offset_x_key=5):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set
        self.offset_x_key = offset_x_key

        self.rim = BOX(P.color_bu_3_off)
        self.ti = BLF(text=rna.name)
        self.da = BLF(P.color_font)
        self.da.name = None
        self.is_title_left = True
        self.area = None
        self.step = rna.step / 100.0
        self.tx_format = m.U_format_f
        self.unit = 0
    def fn(self, end_fn=None, multi_edit=None):
        rna = self.rna
        DDVAL(self, R_rna_ty(rna), end_fn=end_fn, local_undo=m.N, override_ty="calc_0pf")
class FLOAT_DEG(FLOAT):
    __slots__ = ()
    def __init__(self, w, rna, fn_get, fn_set, offset_x_key=5):
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set
        self.offset_x_key = offset_x_key

        self.rim = BOX(P.color_bu_3_off)
        self.ti = BLF()
        self.da = BLF(P.color_font)
        self.da.name = None
        self.is_title_left = False
        self.area = None
        self.step = rna.step / 100.0
        self.tx_format = R_str_by_deg
        self.unit = 0
    def fn(self, end_fn=None, multi_edit=None):
        rna = self.rna
        DDVAL(self, R_rna_ty(rna), end_fn=end_fn, local_undo=m.N, override_ty="calc_0df")

class COLOR3(STRING):
    __slots__ = 'space', 'l'
    # /* 0ui_COLOR3_init
    def __init__(self, w, rna, fn_get, fn_set):
        self.l = 4
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set

        self.rim = BOX(P.color_bu_3_off)
        self.ti = BLF(P.color_font, rna.name)
        self.da = BLF()
        self.da.name = None
        self.is_title_left = True
        if rna.step == -2.200000047683716:
            self.space = "GLSL-C"
            self.bo = [
                #1
                #2
                #BOX_C(),
                BOX_C(fn_get()),
            ]
        elif rna.step == -1.0:
            self.space = "GLSL-B"
            self.bo = [
                #1
                #2
                #BOX(),
                BOX(fn_get()),
            ]
        else:
            self.space = "DEFAULT"
            TODO
    # */

    def enable(self): pass
    def disable(self): pass

    # /* 0ui_COLOR3_draw_box
    def draw_box(self):
        self.rim.bind_draw()
        #1
        e = self.bo[-1]
        c3 = e.color
        e.bind_color((*c3, 1.0))
        e.draw()

    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.bo[0].dxy_upd(x, y)
        self.ti.dxy(x, y)
    # */
    def draw_blf(self):
        self.ti.draw_color_pos()

    def da_upd(self): pass

    # /* 0ui_COLOR3_get_bo
    def get_bo(self, L, R, B, T): # need set_size if title left
        self.rim.LRBT_upd(L, R, B, T)
        if self.is_title_left is True:
            self.ti.align_R(L - F[10])
            self.ti.y = B + F[5]
        else:
            self.ti.xy(R + F[7], B + F[5])
        _1 = F[1]
        self.bo[0].LRBT_upd(L + _1, R - _1, B + _1, T - _1)
        return B
    # */
    def fn(self):
        def end_fn():
            if menu.is_dd_confirm is False: return
            v = tuple(menu.color)
            menu.color[:] = menu.color_org
            self.set(v)
        menu = DD_COLOR(self, self.rna, end_fn=end_fn)

    # <<< 1copy (0dd_array_rm_code, 0, $$)
    def fn_copy(self):
        if hasattr(self, "act_ind") and self.act_ind != None:
            v = self.get(self.act_ind)
            bpy.context.window_manager.clipboard = m.R_str_by_float(v)  if isinstance(v, float) else f"{v}"
        else:
            self.fn_copy_array()
    def fn_copy_array(self):
        lis = [v  for v in self.get()]
        s = ""
        for v in lis:
            s += m.R_str_by_float(v) if isinstance(v, float) else f"{v}"
            s += ","
        bpy.context.window_manager.clipboard = s[: -1]
    def fn_paste(self):
        try:

            vv = calc_vec(bpy.context.window_manager.clipboard)
            if len(vv) == 1:
                self.set(vv[0], ind=self.act_ind)
            else:
                v = vv[0 : self.l]
                self.set(v, ind=(0, len(v)))
            m.refresh()
            m.redraw()
        except: pass
    def fn_reset(self):
        if hasattr(self, "act_ind") and self.act_ind != None:
            self.set(self.rna.default_array[self.act_ind], ind=self.act_ind)
            m.refresh()
            m.redraw()
        else:
            self.fn_reset_all()
    def fn_reset_all(self):
        self.set(self.rna.default_array)
        m.refresh()
        m.redraw()
    def fn_rm(self, evt):
        # <<< 1copy (ui_fn_rm_head,, $$)
        m.tm["top_win"] = RM(self, evt.mouse_region_x, evt.mouse_region_y, [
        # >>>
            # <<< 1copy (ui_fn_rm_copy,, $$)
            {9: "fn_copy", 0: "Copy Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_paste,, $$)
            {9: "fn_paste", 0: "Paste Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_reset,, $$)
            {9: "fn_reset", 0: "Reset to Default Value"},
            # >>>
            # <<< 1copy (ui_fn_rm_detail,, $$)
            {9: "fn_detail", 0: "Details"},
            # >>>
            # <<< 1copy (ui_fn_rm_copy_array,, $$)
            {9: "fn_copy_array", 0: "Copy Array"},
            # >>>
            # <<< 1copy (ui_fn_rm_reset_all,, $$)
            {9: "fn_reset_all", 0: "Reset Array to Default"},
            # >>>
        # <<< 1copy (ui_fn_rm_end,, $$)
        ])
        # >>>
    # >>>
class COLOR4(COLOR3):
    __slots__ = ()
    # <<< ||* 1copy (0ui_COLOR3_init, 0, ${
    #    'self.l = 4': 'self.l = 3',
    #    '#1': 'BOX(color_black),',
    #    '#2': 'BOX(color_white),',
    #    '#BOX_C(),': 'BOX_C(),',
    #    '#BOX(),': 'BOX(),',
    #    }$) ?
    #    1copy (0ui_COLOR3_draw_box, 0, ${
    #    '#1': 'bo = self.bo\n        bo[0].bind_draw()\n        bo[1].bind_draw()',
    #    '*c3': 'c3[0], c3[1], c3[2]',
    #    'e.draw()': 'bo[2].draw()\n        e.bind_draw()',
    #    'self.bo[0].dxy_upd(x, y)': 'for e in self.bo:   e.dxy_upd(x, y)'
    #    }$) ?
    #    1copy (0ui_COLOR3_get_bo, 0, ${'self.bo[0].LRBT_upd(L + _1, R - _1, B + _1, T - _1)':
    #            '_16 = F[16]\n'+
    #    '        bo = self.bo\n'+
    #    '        TT = T - _1\n'+
    #    '        BB = B + _1\n'+
    #    '        RR = R - _1\n'+
    #    '        L1 = RR - _16\n'+
    #    '        L0 = L1 - _16\n'+
    #    '        bo[1].LRBT_upd(L1, RR, BB, TT)\n'+
    #    '        bo[0].LRBT_upd(L0, L1, BB, TT)\n'+
    #    '        bo[2].LRBT_upd(L + _1, L0, BB, TT)\n'+
    #    '        bo[3].LRBT_upd(L0, RR, BB, TT)'
    #    }$)
    def __init__(self, w, rna, fn_get, fn_set):
        self.l = 3
        self.w = w
        self.is_enable = True
        self.rna = rna
        self.get = fn_get
        self.set = fn_set

        self.rim = BOX(P.color_bu_3_off)
        self.ti = BLF(P.color_font, rna.name)
        self.da = BLF()
        self.da.name = None
        self.is_title_left = True
        if rna.step == -2.200000047683716:
            self.space = "GLSL-C"
            self.bo = [
                BOX(color_black),
                BOX(color_white),
                BOX_C(),
                BOX_C(fn_get()),
            ]
        elif rna.step == -1.0:
            self.space = "GLSL-B"
            self.bo = [
                BOX(color_black),
                BOX(color_white),
                BOX(),
                BOX(fn_get()),
            ]
        else:
            self.space = "DEFAULT"
            TODO
    def draw_box(self):
        self.rim.bind_draw()
        bo = self.bo
        bo[0].bind_draw()
        bo[1].bind_draw()
        e = self.bo[-1]
        c3 = e.color
        e.bind_color((c3[0], c3[1], c3[2], 1.0))
        bo[2].draw()
        e.bind_draw()

    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        for e in self.bo:   e.dxy_upd(x, y)
        self.ti.dxy(x, y)
    def get_bo(self, L, R, B, T): # need set_size if title left
        self.rim.LRBT_upd(L, R, B, T)
        if self.is_title_left is True:
            self.ti.align_R(L - F[10])
            self.ti.y = B + F[5]
        else:
            self.ti.xy(R + F[7], B + F[5])
        _1 = F[1]
        _16 = F[16]
        bo = self.bo
        TT = T - _1
        BB = B + _1
        RR = R - _1
        L1 = RR - _16
        L0 = L1 - _16
        bo[1].LRBT_upd(L1, RR, BB, TT)
        bo[0].LRBT_upd(L0, L1, BB, TT)
        bo[2].LRBT_upd(L + _1, L0, BB, TT)
        bo[3].LRBT_upd(L0, RR, BB, TT)
        return B
    # >>>

class VEC3(STRING):
    __slots__ = ()
    def da_upd(self):
        if self.da.name != self.get():
            v = self.get()
            self.da.name = v.copy()
            self.da.text = m.U_format_vec(v)
    def fn(self):
        def end_fn():
            if menu.is_dd_confirm is False: return
            # /* 0ui_VEC3_fn
            ans = calc_vec_3(menu.confirm_text)
            if isinstance(ans, str):
                m.admin.report({'INFO'}, ans)
                return
            self.set(ans)
            m.refresh()
            m.redraw()
            # */

        menu = DDTX({"name": m.R_str_by_float_array(self.da.name), "LRBT": self.rim.R_LRBT()}, None, tx_clear=False, end_fn=end_fn)
    def fn_copy(self):
        bpy.context.window_manager.clipboard = m.R_str_by_float_array(self.da.name)
    def fn_paste(self):

        # <<< 1copy (0ui_VEC3_fn,, ${'menu.confirm_text': 'bpy.context.window_manager.clipboard'}$)
        ans = calc_vec_3(bpy.context.window_manager.clipboard)
        if isinstance(ans, str):
            m.admin.report({'INFO'}, ans)
            return
        self.set(ans)
        m.refresh()
        m.redraw()
        # >>>


def R_ui_pref_INT(self, rna):
    identifier = rna.identifier
    if rna.is_array:
        # /* 0bu_block_R_ui_INT_array
        full_range = (0, rna.array_length)
        def fn_get(ind=None):
            if ind is None: return getattr(P, identifier)
            if isinstance(ind, int): return getattr(P, identifier)[ind]
            return getattr(P, identifier)[ind[0] : ind[1]]
        def fn_set(v, undo_push=True, ind=None):
            if ind is None: ind = full_range
            if isinstance(ind, int):
                old_v = getattr(P, identifier)[ind]
                try:
                    v = round(v)
                    getattr(P, identifier)[ind] = v
                except: return
                if undo_push is True:
                    m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}[{ind}]= {v}'
                    def old_fn():
                        getattr(P, identifier)[ind] = old_v
                    def new_fn():
                        getattr(P, identifier)[ind] = v
                    m.undo_push(old_fn, new_fn)
            else:
                i0 = ind[0]
                i1 = ind[1]
                old_v = getattr(P, identifier)[i0 : i1]
                try:
                    v = [round(e)  for e in v]
                    getattr(P, identifier)[i0 : i1] = v
                except: return
                if undo_push is True:
                    m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}[{i0}:{i1}]= {v}'
                    def old_fn():
                        getattr(P, identifier)[i0 : i1] = old_v
                    def new_fn():
                        getattr(P, identifier)[i0 : i1] = v
                    m.undo_push(old_fn, new_fn)
        #check_subtype
        if identifier in D_PREF_SUBTYPES:
            o = INT_ARRAY_SUBTI(self, rna, fn_get, fn_set, offset_x_key=12)
            o.init(D_PREF_SUBTYPES[identifier])
            return o
        if rna.subtype == "TRANSLATION":
            o = INT_ARRAY_SUBTI(self, rna, fn_get, fn_set, offset_x_key=12)
            o.init(tuple_XYZ)
            return o
        #if_color
        return INT_ARRAY(self, rna, fn_get, fn_set, offset_x_key=12)
        # */
    else:
        # /* 0bu_block_R_ui_INT_0
        def fn_set(v, undo_push=True):
            old_v = getattr(P, identifier)
            #;enum
            try:
                v = round(v)
                setattr(P, identifier, v)
            except: return
            if undo_push is True:
                m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}= {v}'
                def old_fn():
                    setattr(P, identifier, old_v)
                def new_fn():
                    setattr(P, identifier, v)
                m.undo_push(old_fn, new_fn)
        # */
        # /* 0bu_block_R_ui_INT_1
        if identifier in D_PREF_SUBTYPES:
            o = INT_SUBTI(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
            o.init(D_PREF_SUBTYPES[identifier])
            return o
        if rna.subtype == "TRANSLATION":
            o = INT_SUBTI(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
            o.init(tuple_XYZ)
            return o
        return INT(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
        # */
def R_ui_pref_FLOAT(self, rna):
    # /* 0ui_R_ui_pref_FLOAT
    identifier = rna.identifier
    if rna.is_array:
        # <<< ||* 1copy (0bu_block_R_ui_INT_array, 0, ${
        #    'v = round(v)': '',
        #    'v = [round(e)  for e in v]': '',
        #    'INT_ARRAY_SUBTI': 'FLOAT_ARRAY_SUBTI',
        #    'INT_ARRAY': 'FLOAT_ARRAY',
        #    'INT_SUBTI': 'FLOAT_SUBTI',
        #    'INT': 'FLOAT',
        #    '#if_color': 'if rna.subtype == "COLOR":  return COLOR4(self, rna, fn_get, fn_set)  if rna.array_length == 4 else COLOR3(self, rna, fn_get, fn_set)',
        #}$)
        full_range = (0, rna.array_length)
        def fn_get(ind=None):
            if ind is None: return getattr(P, identifier)
            if isinstance(ind, int): return getattr(P, identifier)[ind]
            return getattr(P, identifier)[ind[0] : ind[1]]
        def fn_set(v, undo_push=True, ind=None):
            if ind is None: ind = full_range
            if isinstance(ind, int):
                old_v = getattr(P, identifier)[ind]
                try:
                    
                    getattr(P, identifier)[ind] = v
                except: return
                if undo_push is True:
                    m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}[{ind}]= {v}'
                    def old_fn():
                        getattr(P, identifier)[ind] = old_v
                    def new_fn():
                        getattr(P, identifier)[ind] = v
                    m.undo_push(old_fn, new_fn)
            else:
                i0 = ind[0]
                i1 = ind[1]
                old_v = getattr(P, identifier)[i0 : i1]
                try:
                    
                    getattr(P, identifier)[i0 : i1] = v
                except: return
                if undo_push is True:
                    m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}[{i0}:{i1}]= {v}'
                    def old_fn():
                        getattr(P, identifier)[i0 : i1] = old_v
                    def new_fn():
                        getattr(P, identifier)[i0 : i1] = v
                    m.undo_push(old_fn, new_fn)
        #check_subtype
        if identifier in D_PREF_SUBTYPES:
            o = FLOAT_ARRAY_SUBTI(self, rna, fn_get, fn_set, offset_x_key=12)
            o.init(D_PREF_SUBTYPES[identifier])
            return o
        if rna.subtype == "TRANSLATION":
            o = FLOAT_ARRAY_SUBTI(self, rna, fn_get, fn_set, offset_x_key=12)
            o.init(tuple_XYZ)
            return o
        if rna.subtype == "COLOR":  return COLOR4(self, rna, fn_get, fn_set)  if rna.array_length == 4 else COLOR3(self, rna, fn_get, fn_set)
        return FLOAT_ARRAY(self, rna, fn_get, fn_set, offset_x_key=12)
        # >>>
    else:
        # <<< ||* 1copy (0bu_block_R_ui_INT_0, 0, ${
        #    'v = round(v)': '',
        #    'v = [round(e)  for e in v]': '',
        #    'INT_ARRAY_SUBTI': 'FLOAT_ARRAY_SUBTI',
        #    'INT_ARRAY': 'FLOAT_ARRAY',
        #    'INT_SUBTI': 'FLOAT_SUBTI',
        #    'INT': 'FLOAT',
        #}$) ?
        #    1copy (0bu_block_R_ui_INT_1, 0, ${
        #    'v = round(v)': '',
        #    'v = [round(e)  for e in v]': '',
        #    'INT_ARRAY_SUBTI': 'FLOAT_ARRAY_SUBTI',
        #    'INT_ARRAY': 'FLOAT_ARRAY',
        #    'INT_SUBTI': 'FLOAT_SUBTI',
        #    'INT': 'FLOAT',
        #}$)
        def fn_set(v, undo_push=True):
            old_v = getattr(P, identifier)
            #;enum
            try:
                
                setattr(P, identifier, v)
            except: return
            if undo_push is True:
                m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}= {v}'
                def old_fn():
                    setattr(P, identifier, old_v)
                def new_fn():
                    setattr(P, identifier, v)
                m.undo_push(old_fn, new_fn)
        if identifier in D_PREF_SUBTYPES:
            o = FLOAT_SUBTI(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
            o.init(D_PREF_SUBTYPES[identifier])
            return o
        if rna.subtype == "TRANSLATION":
            o = FLOAT_SUBTI(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
            o.init(tuple_XYZ)
            return o
        return FLOAT(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
        # >>>
    # */
def R_ui_pref_BOOLEAN(self, rna):
    identifier = rna.identifier
    if rna.is_array:
        TODO
    else:
        # <<< || 1copy (0bu_block_R_ui_INT_0, 0, ${'v = round(v)':''}$)
        def fn_set(v, undo_push=True):
            old_v = getattr(P, identifier)
            #;enum
            try:
                
                setattr(P, identifier, v)
            except: return
            if undo_push is True:
                m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}= {v}'
                def old_fn():
                    setattr(P, identifier, old_v)
                def new_fn():
                    setattr(P, identifier, v)
                m.undo_push(old_fn, new_fn)
        # >>>
        return BOOLEAN(self, rna, lambda: getattr(P, identifier), fn_set)
def R_ui_pref_STRING(self, rna):
    identifier = rna.identifier
    # <<< || 1copy (0bu_block_R_ui_INT_0, -4, ${'v = round(v)':''}$)
    def fn_set(v, undo_push=True):
        old_v = getattr(P, identifier)
        #;enum
        try:
            
            setattr(P, identifier, v)
        except: return
        if undo_push is True:
            m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}= {v}'
            def old_fn():
                setattr(P, identifier, old_v)
            def new_fn():
                setattr(P, identifier, v)
            m.undo_push(old_fn, new_fn)
    # >>>
    return STRING(self, rna, lambda: getattr(P, identifier), fn_set)
def R_ui_pref_ENUM(self, rna):
    identifier = rna.identifier
    dic = {e.name : k  for k, e in rna.enum_items.items()}
    # <<< || 1copy (0bu_block_R_ui_INT_0, -4, ${'v = round(v)':'', '#;enum':'if v in dic:    v = dic[v]'}$)
    def fn_set(v, undo_push=True):
        old_v = getattr(P, identifier)
        if v in dic:    v = dic[v]
        try:
            
            setattr(P, identifier, v)
        except: return
        if undo_push is True:
            m.undo_str = f'[Settings] Preference: {self.ti.text} - {identifier}= {v}'
            def old_fn():
                setattr(P, identifier, old_v)
            def new_fn():
                setattr(P, identifier, v)
            m.undo_push(old_fn, new_fn)
    # >>>
    return STRING_ENUM(self, rna, lambda: getattr(P, identifier), fn_set)
def R_ui_pref_STR_SIM(self, rna):
    return STRING(self, rna, lambda: rna.default, m.N)
def R_ui_pref_BUTTON(self, rna):
    return BUTTON(self, rna)
D_ui_pref = {
    'INT': R_ui_pref_INT,
    'FLOAT': R_ui_pref_FLOAT,
    'BOOLEAN': R_ui_pref_BOOLEAN,
    'STRING': R_ui_pref_STRING,
    'ENUM': R_ui_pref_ENUM,
    'STR_SIM': R_ui_pref_STR_SIM,
    'BUTTON': R_ui_pref_BUTTON,
}

# //* 0ui_ids_replace_dict $
# *//

def R_ui_ids_INT(self, rna):
    P, identifier = rna.ids
    if rna.is_array:
        # <<< 1copy (0bu_block_R_ui_INT_array,, $vars["0ui_ids_replace_dict"]$)
        full_range = (0, rna.array_length)
        def fn_get(ind=None):
            if ind is None: return getattr(P, identifier)
            if isinstance(ind, int): return getattr(P, identifier)[ind]
            return getattr(P, identifier)[ind[0] : ind[1]]
        def fn_set(v, undo_push=True, ind=None):
            if ind is None: ind = full_range
            if isinstance(ind, int):
                old_v = getattr(P, identifier)[ind]
                try:
                    v = round(v)
                    getattr(P, identifier)[ind] = v
                except: return
                if undo_push is True:
                    m.undo_str = f'{rna.undo_ti} {self.ti.text} - {identifier}[{ind}]= {v}'
                    def old_fn():
                        getattr(P, identifier)[ind] = old_v
                    def new_fn():
                        getattr(P, identifier)[ind] = v
                    m.undo_push(old_fn, new_fn)
            else:
                i0 = ind[0]
                i1 = ind[1]
                old_v = getattr(P, identifier)[i0 : i1]
                try:
                    v = [round(e)  for e in v]
                    getattr(P, identifier)[i0 : i1] = v
                except: return
                if undo_push is True:
                    m.undo_str = f'{rna.undo_ti} {self.ti.text} - {identifier}[{i0}:{i1}]= {v}'
                    def old_fn():
                        getattr(P, identifier)[i0 : i1] = old_v
                    def new_fn():
                        getattr(P, identifier)[i0 : i1] = v
                    m.undo_push(old_fn, new_fn)
        #check_subtype
        if hasattr(rna, "subti"):
            o = INT_ARRAY_SUBTI(self, rna, fn_get, fn_set, offset_x_key=12)
            o.init(rna.subti)
            return o
        if rna.subtype == "TRANSLATION":
            o = INT_ARRAY_SUBTI(self, rna, fn_get, fn_set, offset_x_key=12)
            o.init(tuple_XYZ)
            return o
        #if_color
        return INT_ARRAY(self, rna, fn_get, fn_set, offset_x_key=12)
        # >>>
    else:
        # <<< 1copy (0bu_block_R_ui_INT_0 ,, $vars["0ui_ids_replace_dict"]$)
        def fn_set(v, undo_push=True):
            old_v = getattr(P, identifier)
            #;enum
            try:
                v = round(v)
                setattr(P, identifier, v)
            except: return
            if undo_push is True:
                m.undo_str = f'{rna.undo_ti} {self.ti.text} - {identifier}= {v}'
                def old_fn():
                    setattr(P, identifier, old_v)
                def new_fn():
                    setattr(P, identifier, v)
                m.undo_push(old_fn, new_fn)
        # >>>
        # <<< 1copy (0bu_block_R_ui_INT_1 ,, $vars["0ui_ids_replace_dict"]$)
        if hasattr(rna, "subti"):
            o = INT_SUBTI(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
            o.init(rna.subti)
            return o
        if rna.subtype == "TRANSLATION":
            o = INT_SUBTI(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
            o.init(tuple_XYZ)
            return o
        return INT(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
        # >>>
def R_ui_ids_FLOAT(self, rna):
    # <<< 1copy (0ui_R_ui_pref_FLOAT,, $vars["0ui_ids_replace_dict"]$)
    P, identifier = rna.ids
    if rna.is_array:
        # <<< ||* 1copy (0bu_block_R_ui_INT_array, 0, ${
        #    'v = round(v)': '',
        #    'v = [round(e)  for e in v]': '',
        #    'INT_ARRAY_SUBTI': 'FLOAT_ARRAY_SUBTI',
        #    'INT_ARRAY': 'FLOAT_ARRAY',
        #    'INT_SUBTI': 'FLOAT_SUBTI',
        #    'INT': 'FLOAT',
        #    '#if_color': 'if rna.subtype == "COLOR":  return COLOR4(self, rna, fn_get, fn_set)  if rna.array_length == 4 else COLOR3(self, rna, fn_get, fn_set)',
        #}$)
        full_range = (0, rna.array_length)
        def fn_get(ind=None):
            if ind is None: return getattr(P, identifier)
            if isinstance(ind, int): return getattr(P, identifier)[ind]
            return getattr(P, identifier)[ind[0] : ind[1]]
        def fn_set(v, undo_push=True, ind=None):
            if ind is None: ind = full_range
            if isinstance(ind, int):
                old_v = getattr(P, identifier)[ind]
                try:
                    
                    getattr(P, identifier)[ind] = v
                except: return
                if undo_push is True:
                    m.undo_str = f'{rna.undo_ti} {self.ti.text} - {identifier}[{ind}]= {v}'
                    def old_fn():
                        getattr(P, identifier)[ind] = old_v
                    def new_fn():
                        getattr(P, identifier)[ind] = v
                    m.undo_push(old_fn, new_fn)
            else:
                i0 = ind[0]
                i1 = ind[1]
                old_v = getattr(P, identifier)[i0 : i1]
                try:
                    
                    getattr(P, identifier)[i0 : i1] = v
                except: return
                if undo_push is True:
                    m.undo_str = f'{rna.undo_ti} {self.ti.text} - {identifier}[{i0}:{i1}]= {v}'
                    def old_fn():
                        getattr(P, identifier)[i0 : i1] = old_v
                    def new_fn():
                        getattr(P, identifier)[i0 : i1] = v
                    m.undo_push(old_fn, new_fn)
        #check_subtype
        if hasattr(rna, "subti"):
            o = FLOAT_ARRAY_SUBTI(self, rna, fn_get, fn_set, offset_x_key=12)
            o.init(rna.subti)
            return o
        if rna.subtype == "TRANSLATION":
            o = FLOAT_ARRAY_SUBTI(self, rna, fn_get, fn_set, offset_x_key=12)
            o.init(tuple_XYZ)
            return o
        if rna.subtype == "COLOR":  return COLOR4(self, rna, fn_get, fn_set)  if rna.array_length == 4 else COLOR3(self, rna, fn_get, fn_set)
        return FLOAT_ARRAY(self, rna, fn_get, fn_set, offset_x_key=12)
        # >>>
    else:
        # <<< ||* 1copy (0bu_block_R_ui_INT_0, 0, ${
        #    'v = round(v)': '',
        #    'v = [round(e)  for e in v]': '',
        #    'INT_ARRAY_SUBTI': 'FLOAT_ARRAY_SUBTI',
        #    'INT_ARRAY': 'FLOAT_ARRAY',
        #    'INT_SUBTI': 'FLOAT_SUBTI',
        #    'INT': 'FLOAT',
        #}$) ?
        #    1copy (0bu_block_R_ui_INT_1, 0, ${
        #    'v = round(v)': '',
        #    'v = [round(e)  for e in v]': '',
        #    'INT_ARRAY_SUBTI': 'FLOAT_ARRAY_SUBTI',
        #    'INT_ARRAY': 'FLOAT_ARRAY',
        #    'INT_SUBTI': 'FLOAT_SUBTI',
        #    'INT': 'FLOAT',
        #}$)
        def fn_set(v, undo_push=True):
            old_v = getattr(P, identifier)
            #;enum
            try:
                
                setattr(P, identifier, v)
            except: return
            if undo_push is True:
                m.undo_str = f'{rna.undo_ti} {self.ti.text} - {identifier}= {v}'
                def old_fn():
                    setattr(P, identifier, old_v)
                def new_fn():
                    setattr(P, identifier, v)
                m.undo_push(old_fn, new_fn)
        if hasattr(rna, "subti"):
            o = FLOAT_SUBTI(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
            o.init(rna.subti)
            return o
        if rna.subtype == "TRANSLATION":
            o = FLOAT_SUBTI(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
            o.init(tuple_XYZ)
            return o
        return FLOAT(self, rna, lambda: getattr(P, identifier), fn_set, offset_x_key=12)
        # >>>
    # >>>

D_ui_ids = {
    'INT': R_ui_ids_INT,
    'FLOAT': R_ui_ids_FLOAT,
}