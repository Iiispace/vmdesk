import bpy
from bpy.app.timers import register as thread_reg
from bpy.app.timers import unregister as thread_unreg

from . import m
from . fn import append_descend

P = None
F = None
K = None
N = None
BOX = None
BLF = None
font_1 = None
DISABLE_SCISSOR = None
BLEND = None

class WIN:
    __slots__ = (
        'RET',
        'tm',
        'mou_ic',
        'sci',
        'cv',
        'is_min',
        'is_undo',
        'is_redo',
        'U_modal',
        'U_draw',
        'U_draw_ti_bu',
        'U_sw_draw_ti_bu',
        'U_sw_draw_ti_bu_N',
        'U_title_evt',
        'U_main_area_evt',
        'is_out_region',
        'color',
        'resize_rim',
        'box',
        'tit',
        'bo',
        'ti',
        'da',
        'U_to_outside',
        'U_to_main',
        'unact',
        'task',
        'upd_data',
        'base_win',
        'U_init_thread',
        'U_kill_thread',
        'U_init_thread_2',
        'U_kill_thread_2',
        'frame_time',
        'U_modal_thread',
        'U_modal_thread_2',
        'key_end',
        'tm_dx',
        'tm_dy',
        'bu_x_fn',
        'callfront',
    )
    name = "WIN"

    @classmethod
    def get_win(cls, blf_title):
        if not cls.W:   blf_title.name = 1 ;cls.IND.clear()
        elif cls.IND:
            if cls.IND[-1] == 1:    blf_title.name = 1
            else:                   blf_title.name = cls.IND[-1]
            del cls.IND[-1]
        else:   blf_title.name = len(cls.W) + 1

    def kill_cls(self):
        cls = self.__class__
        if hasattr(cls, "IND"):
            if cls.IND: cls.IND.clear()

        if hasattr(cls, "W"):
            if cls.W:   cls.W.clear()

    def fin(self):
        cls = self.__class__
        if hasattr(cls, "IND"):
            i = self.tit["ti"].name
            if cls.IND:
                if i != len(cls.W):  append_descend(cls.IND, i)
            else: cls.IND.append(i)

        m.M.restore_mou_ic()

        if m.W_act == self:             m.W_act = None
        m.W_A.remove(self)
        m.W_D.remove(self)
        m.W_M.remove(self)

        cls.W.remove(self)
        m.admin.tb.task_end(self)

        if len(m.W_A) == 0:
            if P.sys_auto_off:
                m.kill_admin()
                self.RET = {'FINISHED'}
            else:
                m.pref_off()
                self.RET = None
        else:
            self.RET = None

        m.is_outside = True
        if bpy.context.region:          m.redraw()
        # m.init_wait_release()
        m.EVT.kill()

    def init_D1(self):  pass
    def __init__(self,
            multi_task          = True,
            base_win            = None,
            region              = None,
            bu_x_fn             = None,
            size_xy             = None, #int
            pos_xy              = None, #int
            bo_ti_color         = "color_ti_bar",
            bo_main_color       = "color_win",
            init_fit            = False,
        ):
        if region is None:
            if bpy.context.region.type != 'WINDOW':     return

        m.call_admin()

        tm          = m.EMPTY()
        self.tm     = tm
        tm.offset_x = 0
        tm.offset_y = 0

        pos_x, pos_y    = P.win_pos_init  if pos_xy is None else pos_xy
        if m.W_M:
            e = m.W_M[-1]
            if hasattr(e, "box"):
                if e.box["rim"].L == pos_x: pos_x += P.win_offset_init[0]
                if e.box["rim"].T == pos_y: pos_y += P.win_offset_init[1]

        m.W_A.append(self)  ;m.W_D.append(self)  ;m.W_M.append(self)

        m.is_outside    = False
        self.RET        = {'RUNNING_MODAL'}
        self.mou_ic     = 'DEFAULT'
        self.sci        = m.SCISSOR()
        self.cv         = m.CANVAS()
        self.is_min     = False
        self.is_undo    = False
        self.is_redo    = False
        self.bu_x_fn    = self.fin  if bu_x_fn is None else bu_x_fn
        self.callfront  = None

        self.U_modal            = self.I_modal_main
        self.U_draw             = self.I_draw
        self.U_sw_draw_ti_bu    = self.I_sw_draw_ti_bu
        self.U_title_evt        = self.I_title_evt
        self.U_main_area_evt    = self.I_main_area_evt
        self.is_out_region      = m.region_data.outside

        c               = m.EMPTY()
        self.color      = c
        c.ti_bar        = getattr(P, bo_ti_color)
        c.win_bg        = getattr(P, bo_main_color)
        c.win_rim       = P.color_win_rim
        c.ti_bu         = P.color_ti_bu
        c.ti_bar_tx     = P.color_font_ti
        c.ti_bu_sh      = P.color_ti_bu_sh

        self.resize_rim = m.RIM()
        self.box = {
            "shade":    m.SHADE(P.win_shade_color) if P.win_shade_on else m.BOX_FAKE(),
            "rim":      m.RIM(c.win_rim),
            "ti":       BOX(c.ti_bar),
            "main":     BOX(c.win_bg),
            "bu_x":     BOX(c.ti_bu),
            "bu_fit":   BOX(c.ti_bu),
            "bu_min":   BOX(c.ti_bu),
        }
        self.tit = {
            "ti":       BLF(c.ti_bar_tx),
            "bu_x":     BLF(c.ti_bu_sh, "✕"),
            "bu_fit":   BLF(c.ti_bu_sh, "⌜"),
            "bu_min":   BLF(c.ti_bu_sh, "﹣"),
        }

        size_x, size_y  = P.win_size_init  if size_xy is None else size_xy
        self.box["rim"].LRBTd(pos_x, pos_x + size_x, pos_y - size_y, pos_y, F[1])
        new_x, new_y    = m.UR_protect_pos(self.box["rim"], F[-1])
        self.box["rim"].dxy(new_x - pos_x, new_y - pos_y)
        self.upd_prefs()
        self.I_sw_draw_ti_bu()

        if multi_task is True:
            if m.W_act != None:   m.W_act.unact()
            m.W_act = self

            self.U_to_outside = self.I_to_outside_through
            self.U_to_main = self.I_to_main_through
            self.unact = self.I_unact

            cls = self.__class__
            cls.get_win(self.tit["ti"])
            cls.W.append(self)
            self.init_D1()
            self.get_bo()
            m.pref_on()

            self.task = m.admin.tb.task_init(self)
            self.I_upd_data()
        else:
            self.U_to_outside = self.I_to_outside_block
            self.U_to_main = self.I_to_main_block
            self.unact = N

            self.base_win = base_win
            self.init_D1(multi_task)
            self.get_bo()
            self.upd_data = N
        m.redraw()
        m.EVT.kill()

        if init_fit is True:  self.fit_win()

# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo(self):
        box, tit = self.box, self.tit
        rim = box["rim"]
        L = rim.L
        R = rim.R
        B = rim.B
        T = rim.T

        if P.win_shade_on:
            box["shade"].get_by_rim(
                L, R, B, T,
                P.win_shade_softness, P.win_shade_offset, P.scale[0]
            )

        self.resize_rim.LRBTd(L - 1, R + 1, B - 1, T + 1, 3)

        box["ti"].L = rim.L2           ;box["ti"].R = rim.R2
        box["ti"].depth_T(rim.T2, F[-1])
        if box["ti"].B < rim.B2:   box["ti"].B = rim.B2
        box["main"].L = box["ti"].L           ;box["main"].R = box["ti"].R
        box["main"].T = box["ti"].B           ;box["main"].B = rim.B2
        self.sci.box(box["main"])
        if self.sci.h < 0: self.sci.h = 0
        box["bu_x"].depth_R(box["ti"].R - F[-2], F[-3])
        box["bu_x"].depth_T(box["ti"].T - F[-2], F[-3])
        box["bu_fit"].depth_R(box["bu_x"].L - F[-2], F[-3])
        box["bu_fit"].T, box["bu_fit"].B = box["bu_x"].T, box["bu_x"].B
        box["bu_min"].depth_R(box["bu_fit"].L - F[-2], F[-3])
        box["bu_min"].T, box["bu_min"].B = box["bu_x"].T, box["bu_x"].B

        tit["bu_x"].LBs(box["bu_x"], F[-8], F[-9], F[-7])
        tit["bu_fit"].LBs(box["bu_fit"], F[-11], F[-12], F[-10])
        tit["bu_min"].LBs(box["bu_min"], F[-14], F[-15], F[-13])
        tit["ti"].LBs(box["ti"], F[-5], F[-6], F[-4])

        self.check_ti_text()    ;self.check_ti_bu()

        self.get_bo_main()
        for e in self.box.values():     e.upd()
        for e in self.bo.values():      e.upd()
    def check_ti_bu(self):
        if self.box["bu_min"].L < self.box["rim"].L2 or P.scale_ti_bu == 0.0 or self.box["main"].R_h() == 0:
            self.U_sw_draw_ti_bu_N()
            self.box["bu_x"].T, self.box["bu_x"].B = self.box["bu_x"].B, self.box["bu_x"].T
        else:   self.U_sw_draw_ti_bu()
# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd(self, x, y):
        for e in self.box.values():     e.dxy_upd(x, y)
        for e in self.tit.values():     e.dxy(x, y)
        self.sci.x += x  ;self.sci.y += y
        self.dxy_upd_main(x, y)
        self.resize_rim.dxy(x, y)
    def dxy_upd_main(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)

    def react(self, evt):
        self.RET = {'RUNNING_MODAL'}
        m.M.set_mou_ic('DEFAULT')
        m.set_W_act(self)
        tb = m.admin.tb
        tb.actbox.upd_by_mi(self.task)
        self.box["ti"].color = self.color.ti_bar
        self.box["main"].color = self.color.win_bg

        self.U_to_main()
        self.upd_prefs()

        self.U_modal = self.I_modal_main
        self.I_upd_data()
        self.I_modal_main(evt)

        m.redraw()
    def I_unact(self):
        self.U_modal = self.I_modal_waitact
        self.box["ti"].color = P.color_ti_bar_unfo
        self.box["main"].color = P.color_win_unfo
        self.RET = None
        m.redraw()

    def check_ti_text(self):
        self.tit["ti"].set_size()
        if self.tit["ti"].R_end_x() >= self.box["bu_min"].L or P.ti_font_size == 0 or self.box["main"].R_h() == 0:
            self.tit["ti"].color = m.color_empty
        else:   self.tit["ti"].color = self.color.ti_bar_tx

    def upd_prefs(self):
        m.prefs.U_upd_pos = N
        pref = bpy.context.workspace.tm_pref
        pref.win_pos[:] = self.box["rim"].L, self.box["rim"].T
        pref.win_size[:] = self.box["rim"].R - self.box["rim"].L, self.box["rim"].T - self.box["rim"].B
        m.prefs.U_upd_pos = m.prefs.I_upd_pos
        self.upd_prefs_cv()
    def upd_prefs_pos(self):
        pref = bpy.context.workspace.tm_pref
        m.prefs.U_upd_pos = N
        pref.win_pos[:] = self.box["rim"].L, self.box["rim"].T
        m.prefs.U_upd_pos = m.prefs.I_upd_pos
    def upd_prefs_size(self):
        pref = bpy.context.workspace.tm_pref
        m.prefs.U_upd_pos = N
        pref.win_size[:] = self.box["rim"].R - self.box["rim"].L, self.box["rim"].T - self.box["rim"].B
        m.prefs.U_upd_pos = m.prefs.I_upd_pos
    def upd_prefs_cv(self):
        pref = bpy.context.workspace.tm_pref
        m.prefs.U_upd_cv = N
        pref.win_canvas_pos[:] = self.cv.x, self.cv.y
        m.prefs.U_upd_cv = m.prefs.I_upd_cv

    def fit_win(self, border=None):
        rim     = self.box["rim"]
        f1      = F[1]
        rd      = m.region_data
        if border is None:  border = P.win_border

        if rim.L < rd.L:       rim.L = rd.L
        R = rim.L + self.cv.R_w() + 2 * (border + f1)
        dR = rd.R - R
        if dR < 0:
            rim.R = rd.R
            rim.L += dR
            if rim.L < rd.L:    rim.L = rd.L
        else:           rim.R = R

        rdB     = m.admin.tb.bo["bg"].T
        if rim.T > rd.T:  rim.T = rd.T
        B = rim.T - F[-1] - self.cv.R_h() - 2 * (border + f1)
        if B < rdB:
            rim.B = rdB
            rim.T += rdB - B
            if rim.T > rd.T:    rim.T = rd.T
        else:           rim.B = B
        self.cv.x   = 0
        self.cv.y   = 0
        rim.L2      = rim.L + f1
        rim.R2      = rim.R - f1
        rim.B2      = rim.B + f1
        rim.T2      = rim.T - f1
        self.get_bo()
        self.upd_prefs()

    def min_action(self):
#
        if m.W_act == self:     m.W_act = None
        m.W_D.remove(self)
        m.W_M.remove(self)
        self.RET = None
        m.is_outside = True
        self.is_min = True
        if P.anim_win_min:    ANIM_MIN(self)
        self.task.upd_color()
        m.redraw()
    def unmin_action(self):
        if P.anim_win_min:    ANIM_UNMIN(self)
        else:   self.do_unmin()
    def do_unmin(self):
        if m.W_act != None:     m.W_act.unact()
        m.W_act = self
        self.RET = None
        m.W_D.append(self)
        m.W_M.append(self)
        self.box["ti"].color = self.color.ti_bar
        self.box["main"].color = self.color.win_bg
        self.U_to_main()
        self.upd_prefs()
        self.U_modal = self.I_modal_main
        self.box["bu_min"].color = self.color.ti_bu
        self.tit["bu_min"].color = self.color.ti_bu_sh
        self.is_min = False
        m.admin.tb.actbox.upd_by_mi(self.task)
        m.redraw()

    def default_modal(self, evt):
        if self.is_out_region(evt.mouse_region_x, evt.mouse_region_y):
            self.U_to_outside()
            self.U_modal = self.I_modal_outside
            return
        if self.resize_rim.inbox(evt):
            m.M.set_mou_ic('DEFAULT')
            self.U_to_main()
            self.U_modal = self.I_modal_main
            self.I_modal_main(evt)  ;m.redraw()
            return
        self.U_to_outside()
        self.U_modal = self.I_modal_outside

    def I_init_thread(self, frame_time):
        self.U_init_thread  = N
        self.U_kill_thread  = self.I_kill_thread
        self.frame_time     = frame_time
        thread_reg(self.U_modal_thread)
    def I_kill_thread(self):
        self.U_init_thread  = self.I_init_thread
        self.U_kill_thread  = N
        thread_unreg(self.U_modal_thread)
#
    def I_init_thread_2(self, frame_time):
        self.U_init_thread_2    = N
        self.U_kill_thread_2    = self.I_kill_thread_2
        self.frame_time_2       = frame_time
        thread_reg(self.U_modal_thread_2)
    def I_kill_thread_2(self):
        self.U_init_thread_2    = self.I_init_thread_2
        self.U_kill_thread_2    = N
        thread_unreg(self.U_modal_thread_2)

    def is_win_same_type(self, e, name="Modifier Editor"):
        cl = e.__class__
        if hasattr(cl, "name"):
            if cl.name == name:
                if e is self:   return False
                return True
        return False

    def upd_cv_lim(self):
        border2 = P.win_border * 2
        self.cv.lim_x = self.cv.R_w() + border2 - self.box["main"].R_w()
        self.cv.lim_y = self.cv.R_h() + border2 - self.box["main"].R_h()
        if self.cv.lim_x < 0:   self.cv.lim_x = 0
        if self.cv.lim_y < 0:   self.cv.lim_y = 0

    def R_center_pos(self):
        bo = self.box["rim"]
        return bo.L + (bo.R - bo.L) // 2, bo.B + (bo.T - bo.B) // 2
# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def run_modal(self, evt):   self.U_modal(evt)
    def I_to_outside_through(self):
#
        self.RET = None
        m.M.restore_mou_ic()
        m.is_outside = True
    def I_to_outside_block(self):
        pass

    def I_to_main_through(self):
        self.RET = {'RUNNING_MODAL'}
        self.I_upd_data()
        # m.EVT.kill()
#
    def I_to_main_block(self):
        self.I_upd_data()
        m.EVT.kill()

    def outside_evt(self, evt):
        pass
#
    def title_evt(self, evt):
        pass
#
    def I_title_evt(self, evt):
        self.U_main_area_evt    = self.I_main_area_evt
        self.U_title_evt        = N
        self.title_evt(evt)
    def main_area_evt(self, evt):
        pass
#
    def I_main_area_evt(self, evt):
        self.U_main_area_evt    = N
        self.U_title_evt        = self.I_title_evt
        self.main_area_evt(evt)
    def I_modal_main(self, evt):
        if self.callfront is not None:
            self.callfront(evt)
            self.callfront = None

        if not self.resize_rim.inbox(evt):
            self.outside_evt(evt)
            self.U_to_outside()
            self.U_modal = self.I_modal_outside
            return
        if self.is_out_region(evt.mouse_region_x, evt.mouse_region_y):
            self.outside_evt(evt)
            self.U_to_outside()
            self.U_modal = self.I_modal_outside
            return
        #in main
        if self.box["ti"].in_B(evt):
            self.U_title_evt(evt)
            if self.box["bu_x"].in_BT(evt):
                if self.box["bu_x"].in_LR(evt):
                    #in x
                    self.U_modal = self.I_modal_x
                    self.modal_x(evt)
                    self.box["bu_x"].color = P.color_ti_bu_x
                    m.redraw()
                elif self.box["bu_fit"].in_LR(evt):
                    #in fit
                    self.U_modal = self.I_modal_fit
                    self.modal_fit(evt)
                    self.box["bu_fit"].color = P.color_ti_bu_fo
                    m.redraw()
                elif self.box["bu_min"].in_LR(evt):
                    #in min
                    self.U_modal = self.I_modal_min
                    self.modal_min(evt)
                    self.box["bu_min"].color = P.color_ti_bu_fo
                    m.redraw()
                else:
                    self.evt_ti_free_area(evt)
            else:
                self.evt_ti_free_area(evt)
        else:   #below title
            self.U_main_area_evt(evt)
            self.evt_free_area(evt)

    def I_modal_outside(self, evt):
        if self.resize_rim.inbox(evt):
            m.region_data.upd()
            if self.is_out_region(evt.mouse_region_x, evt.mouse_region_y): return
            m.M.set_mou_ic('DEFAULT')
            self.U_to_main()
            self.U_modal = self.I_modal_main
            self.I_modal_main(evt)
            m.redraw()

    def I_modal_x(self, evt):
        if not self.box["bu_x"].inbox(evt):
            self.box["bu_x"].color = self.color.ti_bu
            self.U_modal = self.I_modal_main
            m.redraw()
            return
        self.modal_x(evt)
    def modal_x(self, evt):
        if K["cancel0"].true():   self.bu_x_fn()   ;return
        if K["cancel1"].true():   self.bu_x_fn()   ;return
        if K["ti_bu0"].true():
            self.U_modal = self.evt_x
            m.tm["fn"] = self.evt_x_inbox
            self.tit["bu_x"].color = P.color_ti_bu_sh_hold  ;m.redraw()
            self.key_end = K["ti_bu_E0"]  ;self.key_end.true()
            self.evt_x(evt)                 ;return
        if K["ti_bu1"].true():
            self.U_modal = self.evt_x
            m.tm["fn"] = self.evt_x_inbox
            self.tit["bu_x"].color = P.color_ti_bu_sh_hold  ;m.redraw()
            self.key_end = K["ti_bu_E1"]  ;self.key_end.true()
            self.evt_x(evt)                 ;return

    def I_modal_fit(self, evt):
        if not self.box["bu_fit"].inbox(evt):
            self.box["bu_fit"].color = self.color.ti_bu
            self.U_modal = self.I_modal_main
            m.redraw()
            return
        self.modal_fit(evt)
    def modal_fit(self, evt):
        if K["cancel0"].true():   self.bu_x_fn()   ;return
        if K["cancel1"].true():   self.bu_x_fn()   ;return
        if K["ti_bu0"].true():
            self.U_modal = self.evt_fit
            m.tm["fn"] = self.evt_fit_inbox
            self.tit["bu_fit"].color = P.color_ti_bu_sh_hold  ;m.redraw()
            self.key_end = K["ti_bu_E0"]  ;self.key_end.true()
            self.evt_fit(evt)           ;return
        if K["ti_bu1"].true():
            self.U_modal = self.evt_fit
            m.tm["fn"] = self.evt_fit_inbox
            self.tit["bu_fit"].color = P.color_ti_bu_sh_hold  ;m.redraw()
            self.key_end = K["ti_bu_E1"]  ;self.key_end.true()
            self.evt_fit(evt)           ;return

    def I_modal_min(self, evt):
        if not self.box["bu_min"].inbox(evt):
            self.box["bu_min"].color = self.color.ti_bu
            self.U_modal = self.I_modal_main
            m.redraw()
            return
        self.modal_min(evt)
    def modal_min(self, evt):
        if K["cancel0"].true():   self.bu_x_fn()   ;return
        if K["cancel1"].true():   self.bu_x_fn()   ;return
        if K["ti_bu0"].true():
            self.U_modal = self.evt_min
            m.tm["fn"] = self.evt_min_inbox
            self.tit["bu_min"].color = P.color_ti_bu_sh_hold  ;m.redraw()
            self.key_end = K["ti_bu_E0"]  ;self.key_end.true()
            self.evt_min(evt)           ;return
        if K["ti_bu1"].true():
            self.U_modal = self.evt_min
            m.tm["fn"] = self.evt_min_inbox
            self.tit["bu_min"].color = P.color_ti_bu_sh_hold  ;m.redraw()
            self.key_end = K["ti_bu_E1"]  ;self.key_end.true()
            self.evt_min(evt)           ;return

    def I_modal_waitact(self, evt):
        if m.is_outside == False:       return
        if m.W_act == None:             pass
        elif self.resize_rim.inbox(evt):
            if evt.value not in {'PRESS', 'RELEASE'}:
                self.RET = {'RUNNING_MODAL'}
                m.M.set_mou_ic('DEFAULT')
                return
        else:
            self.RET = None
            m.M.restore_mou_ic()
            return

        self.react(evt)

    def I_modal_resize(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
#
                m.head_modal.clear()
                self.upd_prefs()
                self.U_modal = self.default_modal
                self.I_upd_data()
                m.redraw()
                m.init_wait_release()
                return
        self.tm_dx = 0
        self.tm_dy = 0
        m.dx = evt.mouse_x - m.mou_x
        m.dy = evt.mouse_y - m.mou_y
        m.tm["fn"](m.dx)
        m.tm["fn2"](m.dy)
        self.dxy_upd(self.tm_dx, self.tm_dy)
        self.check_ti_text()
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()
    def dy_win_T(self, dy):
        box = self.box
        y = box["rim"].B2 - dy
        d = box["ti"].B - y
        if d < 0:
            dy -= d
            box["rim"].B2 -= dy
            box["main"].B -= dy
        else:
            box["rim"].B2 = y
            box["main"].B = y
        self.sci.h += dy                ;self.sci.y -= dy
        box["rim"].B -= dy
        box["shade"].B -= dy            ;box["shade"].B2 -= dy
        self.resize_rim.B -= dy         ;self.resize_rim.B2 -= dy
        self.tm_dy = dy
    def dy_win_B(self, dy):
        box = self.box
        y = box["rim"].B2 + dy
        d = box["ti"].B - y
        if d < 0:
            dy += d
            box["rim"].B2 += dy
            box["main"].B += dy
        else:
            box["rim"].B2 = y
            box["main"].B = y
        box["rim"].B += dy
        box["shade"].B += dy            ;box["shade"].B2 += dy
        self.resize_rim.B += dy         ;self.resize_rim.B2 += dy
        self.sci.y += dy                ;self.sci.h -= dy
    def dx_win_L(self, dx):
        box = self.box
        x = box["rim"].L2 + dx
        d = box["bu_min"].L - x - F[-2]
        if d < 0:   dx += d
        box["shade"].R -= dx            ;box["shade"].R2 -= dx
        box["rim"].R -= dx              ;box["rim"].R2 -= dx
        box["main"].R -= dx             ;box["ti"].R -= dx
        self.resize_rim.R -= dx         ;self.resize_rim.R2 -= dx
        box["bu_x"].dx(-dx)             ;self.tit["bu_x"].x -= dx
        box["bu_fit"].dx(-dx)           ;self.tit["bu_fit"].x -= dx
        box["bu_min"].dx(-dx)           ;self.tit["bu_min"].x -= dx
        self.sci.w -= dx
        self.tm_dx = dx
    def dx_win_R(self, dx):
        box = self.box
        x = box["bu_min"].L + dx
        d = x - box["ti"].L - F[-2]
        if d < 0:   dx -= d
        box["shade"].R += dx            ;box["shade"].R2 += dx
        box["rim"].R += dx              ;box["rim"].R2 += dx
        box["main"].R += dx             ;box["ti"].R += dx
        box["bu_x"].dx(dx)              ;self.tit["bu_x"].x += dx
        box["bu_fit"].dx(dx)            ;self.tit["bu_fit"].x += dx
        box["bu_min"].dx(dx)            ;self.tit["bu_min"].x += dx
        self.resize_rim.R += dx         ;self.resize_rim.R2 += dx
        self.sci.w += dx

    def I_modal_glopan_end_D1(self):    pass
    def I_modal_glopan_end(self):
#
        m.head_modal.clear()            ;self.U_modal = self.I_modal_main
        self.upd_prefs_cv()             ;m.U_end_pan(self)
        self.I_modal_glopan_end_D1()    ;m.init_wait_release()
    def I_modal_glopan(self, evt):
        if evt.type == 'ESC' and evt.value == 'RELEASE':
            self.I_modal_glopan_end()
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.I_modal_glopan_end()
                return
        m.U_pan(evt)
        x = self.cv.x - m.dx
        y = self.cv.y + m.dy

        if x < 0:               m.dx += x
        elif x > self.cv.lim_x: m.dx += x - self.cv.lim_x
        if y < 0:               m.dy -= y
        elif y > self.cv.lim_y: m.dy -= y - self.cv.lim_y

        self.dxy_upd_main(m.dx, m.dy)
        self.glopan_upd()
        self.cv.x -= m.dx
        self.cv.y += m.dy
        m.loop_mou(evt)
        m.redraw()
    def glopan_upd(self): pass

    def evt_free_area(self, evt):
        if K["cancel0"].true():   self.bu_x_fn()   ;return
        if K["cancel1"].true():   self.bu_x_fn()   ;return
        if m.U_resize_evt(self, evt):   return
        if self.modal_main_area(evt):   return
        if K["glopan0"].true():
            self.key_end = K["glopan_E0"]
            self.to_glopan(evt)
            return
        if K["glopan1"].true():
            self.key_end = K["glopan_E1"]
            self.to_glopan(evt)
            return
    def evt_ti_free_area(self, evt):
        if K["cancel0"].true():   self.bu_x_fn()   ;return
        if K["cancel1"].true():   self.bu_x_fn()   ;return
        if m.U_resize_evt(self, evt):   return
        if K["glopan0"].true():
            self.key_end = K["glopan_E0"]
            self.to_glopan(evt)
            return
        if K["glopan1"].true():
            self.key_end = K["glopan_E1"]
            self.to_glopan(evt)
            return
        if K["ti_mov0"].true():
            self.key_end = K["ti_mov_E0"]
            self.to_modal_mov(evt)
            return
        if K["ti_mov1"].true():
            self.key_end = K["ti_mov_E1"]
            self.to_modal_mov(evt)
            return
    def to_modal_mov(self, evt):
        self.key_end.true()
        m.head_modal.append(self.I_modal_mov)
        m.get_mou(evt)
    def to_glopan(self, evt):
        self.key_end.true()
        m.head_modal.append(self.I_modal_glopan)
        m.U_pan_cursor(self, evt)
        rim = self.resize_rim
        dx = evt.mouse_x - evt.mouse_region_x
        dy = evt.mouse_y - evt.mouse_region_y
        m.get_loop_mou_info(rim.L + dx, rim.R + dx, rim.B + dy, rim.T + dy)
        m.get_mou(evt)
        self.upd_cv_lim()
    def to_modal_resize(self):
        m.head_modal.append(self.I_modal_resize)

    def modal_mov_end_D1(self): pass
    def modal_mov_end(self):
#
        del m.head_modal[-1]
        new_x, new_y = m.UR_protect_pos(self.box["rim"], F[-1])
        self.dxy_upd(new_x - self.box["rim"].L, new_y - self.box["rim"].T)
        self.upd_prefs_pos()
        self.modal_mov_end_D1()
        m.EVT.kill()
        m.EVT.U_ENABLE_evt()
        m.redraw()
    def I_modal_mov(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_mov_end()
                return
        m.dx    = evt.mouse_x - m.mou_x
        m.dy    = evt.mouse_y - m.mou_y
        self.dxy_upd(m.dx, m.dy)
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()

    def evt_resize_N(self, evt):
        if not self.resize_rim.inbox(evt):      self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_y >= self.resize_rim.T2:
            self.end_evt_resize(evt)  ;return
        if evt.mouse_region_x <= self.resize_rim.L2:
            self.end_evt_resize(evt)  ;return
        if evt.mouse_region_x >= self.resize_rim.R2:
            self.end_evt_resize(evt)  ;return
        if K["resize0"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = N                ;m.tm["fn2"] = self.dy_win_T
            self.key_end = K["resize_E0"] ;self.key_end.true()
        elif K["resize1"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = N                ;m.tm["fn2"] = self.dy_win_T
            self.key_end = K["resize_E1"] ;self.key_end.true()
    def evt_resize_E(self, evt):
        if not self.resize_rim.inbox(evt):      self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_x >= self.resize_rim.R2:
            self.end_evt_resize(evt)  ;return
        if evt.mouse_region_y >= self.resize_rim.T2:
            self.end_evt_resize(evt)  ;return
        if evt.mouse_region_y <= self.resize_rim.B2:
            self.end_evt_resize(evt)  ;return
        if K["resize0"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_R      ;m.tm["fn2"] = N
            self.key_end = K["resize_E0"] ;self.key_end.true()
        elif K["resize1"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_R      ;m.tm["fn2"] = N
            self.key_end = K["resize_E1"] ;self.key_end.true()
    def evt_resize_S(self, evt):
        if not self.resize_rim.inbox(evt):      self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_y <= self.resize_rim.B2:
            self.end_evt_resize(evt)  ;return
        if evt.mouse_region_x <= self.resize_rim.L2:
            self.end_evt_resize(evt)  ;return
        if evt.mouse_region_x >= self.resize_rim.R2:
            self.end_evt_resize(evt)  ;return
        if K["resize0"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = N                ;m.tm["fn2"] = self.dy_win_B
            self.key_end = K["resize_E0"] ;self.key_end.true()
        elif K["resize1"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = N                ;m.tm["fn2"] = self.dy_win_B
            self.key_end = K["resize_E1"] ;self.key_end.true()
    def evt_resize_W(self, evt):
        if not self.resize_rim.inbox(evt):      self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_x <= self.resize_rim.L2:
            self.end_evt_resize(evt)  ;return
        if evt.mouse_region_y >= self.resize_rim.T2:
            self.end_evt_resize(evt)  ;return
        if evt.mouse_region_y <= self.resize_rim.B2:
            self.end_evt_resize(evt)  ;return
        if K["resize0"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_L      ;m.tm["fn2"] = N
            self.key_end = K["resize_E0"] ;self.key_end.true()
        elif K["resize1"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_L      ;m.tm["fn2"] = N
            self.key_end = K["resize_E1"] ;self.key_end.true()
    def evt_resize_NE(self, evt):
        if not self.resize_rim.inbox(evt):      self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_x >= self.resize_rim.R2:
            self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_y >= self.resize_rim.T2:
            self.end_evt_resize(evt)  ;return
        if K["resize0"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_R      ;m.tm["fn2"] = self.dy_win_T
            self.key_end = K["resize_E0"] ;self.key_end.true()
        elif K["resize1"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_R      ;m.tm["fn2"] = self.dy_win_T
            self.key_end = K["resize_E1"] ;self.key_end.true()
    def evt_resize_SE(self, evt):
        if not self.resize_rim.inbox(evt):      self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_x >= self.resize_rim.R2:
            self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_y <= self.resize_rim.B2:
            self.end_evt_resize(evt)  ;return
        if K["resize0"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_R      ;m.tm["fn2"] = self.dy_win_B
            self.key_end = K["resize_E0"] ;self.key_end.true()
        elif K["resize1"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_R      ;m.tm["fn2"] = self.dy_win_B
            self.key_end = K["resize_E1"] ;self.key_end.true()
    def evt_resize_SW(self, evt):
        if not self.resize_rim.inbox(evt):      self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_x <= self.resize_rim.L2:
            self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_y <= self.resize_rim.B2:
            self.end_evt_resize(evt)  ;return
        if K["resize0"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_L      ;m.tm["fn2"] = self.dy_win_B
            self.key_end = K["resize_E0"] ;self.key_end.true()
        elif K["resize1"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_L      ;m.tm["fn2"] = self.dy_win_B
            self.key_end = K["resize_E1"] ;self.key_end.true()
    def evt_resize_NW(self, evt):
        if not self.resize_rim.inbox(evt):      self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_x <= self.resize_rim.L2:
            self.end_evt_resize(evt)  ;return
        if not evt.mouse_region_y >= self.resize_rim.T2:
            self.end_evt_resize(evt)  ;return
        if K["resize0"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_L      ;m.tm["fn2"] = self.dy_win_T
            self.key_end = K["resize_E0"] ;self.key_end.true()
        elif K["resize1"].true():
            self.to_modal_resize()          ;m.get_mou(evt)
            m.tm["fn"] = self.dx_win_L      ;m.tm["fn2"] = self.dy_win_T
            self.key_end = K["resize_E1"] ;self.key_end.true()
    def end_evt_resize(self, evt):
#
        m.M.set_mou_ic('DEFAULT')
        self.U_modal = self.I_modal_main

    def evt_x(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                if self.box["bu_x"].inbox(evt):  self.bu_x_fn()  ;return
                self.box["bu_x"].color = self.color.ti_bu
                self.tit["bu_x"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.EVT.kill()
                return
        m.tm["fn"](evt)
    def evt_x_inbox(self, evt):
        if not self.box["bu_x"].inbox(evt):
            m.tm["fn"] = self.evt_x_outbox
            self.tit["bu_x"].color = self.color.ti_bu_sh
            self.box["bu_x"].color = self.color.ti_bu
            m.redraw()
    def evt_x_outbox(self, evt):
        if self.box["bu_x"].inbox(evt):
            m.tm["fn"] = self.evt_x_inbox
            self.tit["bu_x"].color = P.color_ti_bu_sh_hold
            self.box["bu_x"].color = P.color_ti_bu_x
            m.redraw()

    def evt_fit(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                if self.box["bu_fit"].inbox(evt):
                    self.fit_win()
                self.box["bu_fit"].color = self.color.ti_bu
                self.tit["bu_fit"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.init_wait_release()
                return
        m.tm["fn"](evt)
    def evt_fit_inbox(self, evt):
        if not self.box["bu_fit"].inbox(evt):
            m.tm["fn"] = self.evt_fit_outbox
            self.tit["bu_fit"].color = self.color.ti_bu_sh
            self.box["bu_fit"].color = self.color.ti_bu
            m.redraw()
    def evt_fit_outbox(self, evt):
        if self.box["bu_fit"].inbox(evt):
            m.tm["fn"] = self.evt_fit_inbox
            self.tit["bu_fit"].color = P.color_ti_bu_sh_hold
            self.box["bu_fit"].color = P.color_ti_bu_fo
            m.redraw()

    def evt_min(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                if self.box["bu_min"].inbox(evt):
                    #min event
                    m.M.restore_mou_ic()
                    self.min_action()
                    m.init_wait_release()
                    return
                self.box["bu_min"].color = self.color.ti_bu
                self.tit["bu_min"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.init_wait_release()
                return
        m.tm["fn"](evt)
    def evt_min_inbox(self, evt):
        if not self.box["bu_min"].inbox(evt):
            m.tm["fn"] = self.evt_min_outbox
            self.tit["bu_min"].color = self.color.ti_bu_sh
            self.box["bu_min"].color = self.color.ti_bu
            m.redraw()
    def evt_min_outbox(self, evt):
        if self.box["bu_min"].inbox(evt):
            m.tm["fn"] = self.evt_min_inbox
            self.tit["bu_min"].color = P.color_ti_bu_sh_hold
            self.box["bu_min"].color = P.color_ti_bu_fo
            m.redraw()
# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        box = self.box
        tit = self.tit
        BLEND()
        box["shade"].draw()

        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;self.U_draw_ti_bu()

        self.sci.ENABLE()
        self.draw_main()
        DISABLE_SCISSOR()

        tit["bu_x"].set_draw_id(font_1)         ;tit["bu_fit"].set_draw_id(font_1)
        tit["bu_min"].set_draw_id(font_1)       ;tit["ti"].set_draw()
    def I_draw_ti_bu(self):
        self.box["bu_x"].bind_draw()
        self.box["bu_fit"].bind_draw()       ;self.box["bu_min"].bind_draw()
    def I_sw_draw_ti_bu(self):
#
        self.U_sw_draw_ti_bu        = N
        self.U_sw_draw_ti_bu_N      = self.I_sw_draw_ti_bu_N
        self.U_draw_ti_bu           = self.I_draw_ti_bu
        self.tit["bu_x"].text       = "✕"
        self.tit["bu_fit"].text     = "⌜"
        self.tit["bu_min"].text     = "﹣"
    def I_sw_draw_ti_bu_N(self):
#
        self.U_sw_draw_ti_bu_N      = N
        self.U_sw_draw_ti_bu        = self.I_sw_draw_ti_bu
        self.U_draw_ti_bu           = N
        self.tit["bu_x"].text       = ""
        self.tit["bu_fit"].text     = ""
        self.tit["bu_min"].text     = ""


class DES:
    __slots__ = "x", "y", "wi", "hi"
    def __init__(self, x, y, wi, hi):
        self.x      = x
        self.y      = y
        self.wi     = wi
        self.hi     = hi

class ANIM_MIN:
    __slots__ = (
        "U_draw",
        "U_thread",
        "frame_time",
        "bo",
        "des",
        "vx",
        "vy",
        "vh",
        "vw",
        "hi",
        "wi",
    )
    def __init__(self, w):
        self.U_draw         = self.I_draw
        self.U_thread       = self.I_thread
        self.frame_time     = P.anim_frame_time

        tb          = m.admin.tb
        boxes       = {"main", "ti"}
        bo          = {
            k : BOX(e.color, e.L, e.R, e.B, e.T) for k, e in w.box.items() if k in boxes
        }
        self.bo     = bo
        for e in bo.values():  e.upd()

        task_bg     = w.task.bo["bg"]
        task_wi     = task_bg.R_w()
        hi          = bo["main"].R_h()
        wi          = bo["ti"].R_w()
        self.hi     = hi
        self.wi     = wi - task_wi
        des         = DES(task_bg.L, task_bg.T, task_wi, bo["ti"].R_h())
        self.des    = des
        t           = pow(2, P.anim_speed * 6) - 1
        self.vh     = max(0.00001, hi / t)
        self.vw     = max(0.00001, (wi - des.wi) / t)
        dx          = des.x - bo["ti"].L
        dy          = des.y - bo["ti"].T
        self.vx     = - max(0.00001, -dx / t) if dx < 0 else max(0.00001, dx / t)
        self.vy     = - max(0.00001, -dy / t) if dy < 0 else max(0.00001, dy / t)

        tb.draw_back.append(self)
        thread_reg(self.U_thread)
#

    def I_thread(self):
        m.T_redraw()
        des         = self.des
        bo_ti       = self.bo["ti"]
        bo_main     = self.bo["main"]
        vx          = self.vx
        vy          = self.vy
        self.hi     -= self.vh
        self.wi     -= self.vw

        if self.hi < 0:     self.hi = 0
        else:               self.vh *= 2

        if self.wi < 0:     self.wi = 0
        else:               self.vw *= 2

        if self.vx < 0:
            if bo_ti.L + vx <= des.x:   vx = des.x - bo_ti.L
        elif bo_ti.L + vx >= des.x:     vx = des.x - bo_ti.L

        if self.vy < 0:
            if bo_ti.T + vy <= des.y:   vy = des.y - bo_ti.T
        elif bo_ti.T + vy >= des.y:     vy = des.y - bo_ti.T

        self.vx *= 2
        self.vy *= 2

        bo_ti.L     += vx
        bo_ti.T     += vy
        bo_ti.R     = bo_ti.L + des.wi + self.wi
        bo_ti.B     = bo_ti.T - des.hi

        bo_ti.upd()
        bo_main.upd_bat(bo_ti.L, bo_ti.R, bo_ti.B - self.hi, bo_ti.B)

        if self.hi == 0:
            thread_unreg(self.U_thread)
            m.admin.tb.draw_back.remove(self)
#
            return

        return self.frame_time

    def I_draw(self):
        BLEND()
        self.bo["main"].bind_draw()
        self.bo["ti"].bind_draw()

class ANIM_UNMIN:
    __slots__ = (
        "w",
        "U_draw",
        "U_thread",
        "frame_time",
        "bo",
        "des",
        "vx",
        "vy",
        "vh",
        "vw",
        "hi",
        "wi",
        "ti_hi"
    )
    def __init__(self, w):
        self.w              = w
        self.U_draw         = self.I_draw
        self.U_thread       = self.I_thread
        self.frame_time     = P.anim_frame_time

        tb          = m.admin.tb
        task_bg     = w.task.bo["bg"]
        bo          = {
            "ti" :      BOX(w.box["ti"].color, task_bg.L, task_bg.R, task_bg.B, task_bg.T),
            "main" :    BOX(w.box["main"].color, task_bg.L, task_bg.R, task_bg.B, task_bg.B)
        }
        self.bo     = bo
        for e in bo.values():  e.upd()

        task_wi     = task_bg.R_w()
        bo_main     = w.box["main"]
        bo_ti       = w.box["ti"]
        hi          = bo_main.R_h()
        wi          = bo_ti.R_w()
        self.ti_hi  = bo_ti.R_h()
        self.hi     = 0
        self.wi     = task_wi
        des         = DES(bo_ti.L, bo_ti.T, wi, hi)
        self.des    = des
        t           = pow(2, P.anim_speed * 6) - 1
        self.vh     = max(0.00001, hi / t)
        self.vw     = max(0.00001, (wi - task_wi) / t)
        dx          = des.x - bo["ti"].L
        dy          = des.y - bo["ti"].T
        self.vx     = - max(0.00001, -dx / t) if dx < 0 else max(0.00001, dx / t)
        self.vy     = - max(0.00001, -dy / t) if dy < 0 else max(0.00001, dy / t)

        tb.draw_back.append(self)
        thread_reg(self.U_thread)
        m.head_modal.append(self.U_modal)
        m.EVT.kill()
#

    def I_thread(self):
        m.T_redraw()
        des         = self.des
        bo_ti       = self.bo["ti"]
        bo_main     = self.bo["main"]
        vx          = self.vx
        vy          = self.vy
        self.hi     += self.vh
        self.wi     += self.vw

        if self.hi > des.hi:    self.hi = des.hi
        else:                   self.vh *= 2

        if self.wi > des.wi:    self.wi = des.wi
        else:                   self.vw *= 2

        if self.vx < 0:
            if bo_ti.L + vx <= des.x:   vx = des.x - bo_ti.L
        elif bo_ti.L + vx >= des.x:     vx = des.x - bo_ti.L

        if self.vy < 0:
            if bo_ti.T + vy <= des.y:   vy = des.y - bo_ti.T
        elif bo_ti.T + vy >= des.y:     vy = des.y - bo_ti.T

        self.vx *= 2
        self.vy *= 2

        bo_ti.L     += vx
        bo_ti.T     += vy
        bo_ti.R     = bo_ti.L + self.wi
        bo_ti.B     = bo_ti.T - self.ti_hi

        bo_ti.upd()
        bo_main.upd_bat(bo_ti.L, bo_ti.R, bo_ti.B - self.hi, bo_ti.B)

        if self.hi == des.hi:
            thread_unreg(self.U_thread)
            m.admin.tb.draw_back.remove(self)
            del m.head_modal[-1]
            self.w.do_unmin()
#
            return

        return self.frame_time

    def U_modal(self, evt):
        if evt.value == 'PRESS':
            thread_unreg(self.U_thread)
            m.admin.tb.draw_back.remove(self)
            del m.head_modal[-1]
            self.w.do_unmin()
            if m.admin.U_modal(evt) == {'FINISHED'}:
                pass
#
#

    def I_draw(self):
        BLEND()
        self.bo["main"].bind_draw()
        self.bo["ti"].bind_draw()
