from blf import size as blf_size
from blf import color as blf_color
from blf import position as blf_pos
from blf import draw as blf_draw

from .. import m, ic, win_mess

from .. m import BOX, BLF
from .. ic import UNKNOWN
from .. dd import DDTX_RENAME
from .. filt import FIL
from .. win_mess import MESS_BOOL, MENU, PROGRESS
from .. ED_md.mods import BU_FOCUS
from .. ll import LL, AN_AUTOKILL_ALL, AN_color_0
from .. link_data import dr_var_move_to_ind, copyVariable
from .. fn import R_str_by_num3

P = None
F = None
K = None
N = None
BIND = None
UNFL = None
font_0 = None
BLEND = None

class MD_POP:
    __slots__ = (
        'x',
        'y',
        'bg',
        'rim',
        'ic',
        'name',
        'ind',
        'U_draw'
    )
    def __init__(self, e, ref, bg_color, L, R, B, T):
        _1 = F[1]
        self.x          = L + F[8]
        self.y          = e.y

        self.bg         = e.bg
        self.bg.color   = bg_color
        self.bg.LRBT(L, R, B, T)
        self.rim        = BOX(P.color_bg_mod, L - _1, R + _1, B - _1, T + _1)
        self.rim.upd()
        self.ic         = e.ic
        self.name       = e.name
        self.name.x     = ref.name
        self.name.color = P.color_font_mod_name
        self.name.size  = self.name.text
        self.ind        = e.ind
        self.ind.x      = ref.ind
        self.ind.color  = P.color_font_mod_num
        self.U_draw     = self.I_draw

    def dxy_upd(self, x, y):
        self.x += x
        self.y += y
        self.bg.dxy_upd(x, y)
        self.rim.dxy_upd(x, y)
        self.name.dxy(x, y)
        self.ind.x += x
        self.ic.upd(self.x, self.y)

    def I_draw(self):
        BLEND()
        self.rim.bind_draw()
        self.bg.bind_draw()
        self.ic.bind_draw()

        blf_size(font_0, F[9])
        self.name.set_color()
        self.name.draw_pos()
        blf_size(font_0, F[7])
        blf_pos(font_0, self.ind.x, self.name.y, 0)
        self.ind.set_color()
        self.ind.draw()

    def thread_color(self, thread_li, speed):   # speed < 0
        self.rim.color      = [*self.rim.color]
        self.bg.color       = [*self.bg.color]
        self.ic.color       = [*self.ic.color]
        self.name.color     = [*self.name.color]
        self.ind.color      = [*self.ind.color]

        colors = [
            self.rim.color,
            self.bg.color,
            self.ic.color,
            self.name.color,
            self.ind.color
        ]
        if hasattr(self.ic, "color2"):
            self.ic.color2  = [*self.ic.color2]
            colors.append(self.ic.color2)

        thread_li["pop_color"] = AN_color_0(colors, 0.0, speed * 0.05)


class REF:
    __slots__ = (
        'ic',
        'name',
        'ind',
        'txR',
    )
    def __init__(self, x):  self.get(x)
    def get(self, x):
        self.ic = x + F[8]
        self.name = self.ic + F[12]
        self.ind = x + round(160 * P.scale[0])

        self.txR = self.ind - F[6]
    def dx(self, x):
        self.ic += x
        self.name += x
        self.ind += x
    def upd(self):
        self.txR = self.ind - F[6]


class VARS(LL):
    __slots__ = ()
    def __init__(self, w, L, R, T):


        super().__init__(w, L, R, T, F[-999] * 15, 16)

        cv          = self.cv
        actbox      = self.actbox
        ref         = REF(cv.L)
        self.ref    = ref
        actbox.init(ref.name - F[3], ref.txR)

        self.drivers = None
        self.fcurves = None

# INS CLASS
        class DRVAR:
            __slots__ = (
                'y',
                'bg',
                'ic',
                'name',
                'ind',
            )
            def __init__(self):
                self.y      = 0
                self.bg     = BOX(None, None, None, None, None)
                self.name   = BLF(P.color_font_mod_name, x=None)
                self.ind    = BLF(size=-1, x=None, y=None)

            def get_ic(self, v):    self.ic = getattr(ic, v.type, UNKNOWN)()
            def get_pos(self, L, R, B, T, cy, ref_ic):
                self.y      = cy
                self.name.y = cy - F[3]
                self.bg.upd_bat(L, R, B, T)
                self.ic.upd(ref_ic, cy)
            def upd_blf_y(self, y):
                self.y      = y
                self.name.y = y - F[3]
            def dy_blf(self, y):
                self.y += y
                self.name.y += y
            def dy_upd(self, y):
                self.y += y
                self.name.y += y
                T = self.y + F[-997]
                self.bg.upd_bat(cv.L, cv.R, T - F[-911], T)
                self.ic.upd(ref.ic, self.y)

            def get_name(self, v, ref_name, txR): # blf_size
                self.name.size = self.name.text = v.name
                self.name.fix_long_text_by_x(ref_name, txR, F[8])
            def get_ind(self, i):
                self.ind.size = i
                self.ind.text = R_str_by_num3(i + 1)
            def get_data(self, v):
                self.ic.upd_ic_color(v)
            def init(self, L, R, B, T, cy, ref_ic, ref_name, txR, ind, v): # blf_size
                new_ic = getattr(ic, v.type, UNKNOWN)()
                self.ic = new_ic

                self.y      = cy
                self.name.y = cy - F[3]
                self.bg.upd_bat(L, R, B, T)
                new_ic.upd(ref_ic, cy)

                self.ind.size = ind
                self.ind.text = R_str_by_num3(ind + 1)

                self.name.size = self.name.text = v.name
                self.name.fix_long_text_by_x(ref_name, txR, F[8])

                new_ic.upd_ic_color(v)

# INS CLASS END
        self.li_type = DRVAR
        act_dr = w.act_dr

        if act_dr is None:
            self.li = {}
            self.kill_data()
        else:
            obs             = act_dr.driver.variables
            self.obs        = obs
            self.ll_bpy     = len(obs)
            self.ll_li      = min(self.max_ll, self.ll_bpy)
            self.ind_desel  = {r : None for r in range(self.ll_li)}
            li              = {k : DRVAR() for k in self.ind_desel}
            self.li         = li

            blf_size(font_0, F[9])
            hi  = self.md_hi
            L   = cv.L
            R   = cv.R
            T   = cv.T
            B   = T - self.md_h
            cy  = T - self.d_cy

            txR     = ref.txR
            ref_ic      = ref.ic
            ref_name    = ref.name

            for r in range(self.ll_li):
                li[r].init(L, R, B, T, cy, ref_ic, ref_name, txR, r, obs[r])

                T -= hi
                B -= hi
                cy -= hi

            cv.B = cv.T - self.md_hi * self.ll_bpy
            i = self.R_act_ind()
            if i == -1:
                actbox.disable()
                self.headkey    = 0
                self.endkey     = None
            else:
                self.sel_range = {i: None}
                if i in li:
                    self.ind_sel[i] = self.ind_desel.pop(i)
                    actbox.get(cv, i)
                else:   actbox.disable()
                self.headkey    = 0
                self.endkey     = self.ll_li - 1
        cv.upd()

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def set_act(self, i):   self.w.A_var.oo["da_name"].da.text = self.obs[i].name
    def R_act_ind(self):
        try:    return self.obs.find(self.w.A_var.oo["da_name"].da.text)
        except: return -1

    def R_bpy_obs(self):    return self.w.act_dr.driver.variables
    def R_y_default(self):
        return self.w.bo["dr_var"].T - F[21]

    def glopan_end(self):
        pass

    def dxy_upd(self, x, y):
        self.ref.dx(x)
        d_cy    = self.d_cy
        h       = self.md_h
        self.cv.dxy_upd(x, y)
        L       = self.cv.L
        R       = self.cv.R
        ref_ic  = self.ref.ic
        for e in self.li.values():  e.dy_upd(y)

        self.y += y
        self.upd_sci()
        self.actbox.rim.dxy_upd(x, y)
        self.actbox.bg.dxy_upd(x, y)

    def R_tm_pop(self):     return MD_POP

    def upd_li_data(self, i, e, drivers=None, fcurves=None): #blf_size, self.obs
        v = self.obs[i]
        if e.ic.R_name() != v.type:     e.get_ic(v) ;e.ic.upd(self.ref.ic, e.y)
        if e.ind.size != i:             e.get_ind(i)
        if e.name.size != v.name:       e.get_name(v, self.ref.name, self.ref.txR)
        e.get_data(v)
    def upd_li_data_all(self): #blf_size, self.obs
        obs = self.obs
        for i, e in self.li.items():
            v = obs[i]
            if e.ic.R_name() != v.type:     e.get_ic(v) ;e.ic.upd(self.ref.ic, e.y)
            if e.ind.size != i:             e.get_ind(i)
            if e.name.size != v.name:       e.get_name(v, self.ref.name, self.ref.txR)
            e.get_data(v)
    def init_li_data(self, i, e, drivers=None, fcurves=None): #blf_size, self.obs
        md = self.obs[i]
        e.get_ic(md) ;e.ic.upd(self.ref.ic, e.y)
        e.get_ind(i)
        e.get_name(md, self.ref.name, self.ref.txR)
        e.get_data(md)

# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def upd_data(self):
        act_dr      = self.w.act_dr
        if act_dr is None:
            self.kill_data()
            return
        obs         = act_dr.driver.variables
        if not obs:
            self.kill_data()
            self.obs    = obs
            return
        self.obs    = obs
        li          = self.li
        ll          = len(obs)
        ref         = self.ref
        cv          = self.cv
        act_ind     = self.R_act_ind()
        self.actbox.upd_check(self, cv, act_ind)
        blf_size(font_0, F[9])

        if ll < self.ll_bpy: # reget all
            cv.T        = self.y
            self.ll_li  = min(16, ll)
            MD          = self.li_type
            li          = {k : MD() for k in range(self.ll_li)}
            self.li     = li
            hi          = self.md_hi
            L           = cv.L
            R           = cv.R
            T           = cv.T
            B           = T - self.md_h
            cy          = T - self.d_cy
            txR         = ref.txR
            ref_ic      = ref.ic
            ref_name    = ref.name

            for r in range(self.ll_li):
                li[r].init(L, R, B, T, cy, ref_ic, ref_name, txR, r, obs[r])

                T -= hi
                B -= hi
                cy -= hi

            cv.B = cv.T - self.md_hi * ll
            cv.upd()
            self.sel_range = {k : None  for k in self.sel_range if k < ll}
            self.get_draw_ind_by_sel_range()
            self.actbox.get(cv, act_ind)

            self.headkey    = 0
            self.endkey     = self.ll_li - 1
        else:
            if self.ll_li < 16:
                d = min(16, ll) - self.ll_li
                if d > 0:
                    hi          = self.md_hi
                    L           = cv.L
                    R           = cv.R
                    T           = cv.T - self.ll_li * hi
                    B           = T - self.md_h
                    cy          = T - self.d_cy
                    txR         = ref.txR
                    ref_ic      = ref.ic
                    ref_name    = ref.name
                    MD          = self.li_type

                    for r in range(self.ll_li, self.ll_li + d):
                        e = MD()
                        e.init(L, R, B, T, cy, ref_ic, ref_name, txR, r, obs[r])
                        li[r] = e

                        T -= hi
                        B -= hi
                        cy -= hi

                    self.ll_li = len(li)
                    cv.B = cv.T - self.md_hi * ll
                    cv.upd()
                    self.get_draw_ind_by_sel_range()
                    self.endkey = self.ll_li - 1
            elif self.ll_bpy != ll:
                cv.B = cv.T - self.md_hi * ll
                cv.upd()

            self.upd_li_data_all()

        self.ll_bpy = ll
        cvh = cv.R_h()
        syslimdn = self.sci.R_T()
        syslimup = syslimdn + max(0, min(cvh, self.hi) - self.sci.h)

        if self.y < syslimdn:

            dy = syslimdn - self.y
            self.y += dy
        elif self.y > syslimup:

            dy = syslimup - self.y
            self.y += dy
        else: return


        d_cy    = self.d_cy
        h       = self.md_h
        cv.dy_upd(dy)
        L       = cv.L
        R       = cv.R
        ref_ic  = ref.ic
        for e in li.values():
            e.y += dy
            e.name.y += dy
            e.view += dy
            e.rend += dy
            T = e.y + d_cy
            e.bg.upd_bat(L, R, T - h, T)
            e.ic.upd(ref_ic, e.y)

        self.actbox.get(cv, act_ind)

    def kill_data(self):

        self.obs        = None  if self.w.act_dr is None else self.w.act_dr.driver.variables
        self.cv.B = self.cv.T = self.y = self.R_y_default()
        self.cv.upd()
        self.ll_bpy     = 0
        self.ll_li      = 0
        self.li.clear()
        self.sel_range.clear()
        self.ind_sel.clear()
        self.ind_desel.clear()
        self.actbox.disable()
        self.headkey    = 0
        self.endkey     = None

    def kill_mods(self):
        self.w.get_bo_main()

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def sub_modal(self, evt):
        ref = self.ref
        if evt.mouse_region_x >= ref.ind:
            if K["me_sort0"].true():
                self.is_draw_bu_focus = False
                self.key_end = K["me_sort_E0"]
                self.to_modal_sort(evt)
                return True
            if K["me_sort1"].true():
                self.is_draw_bu_focus = False
                self.key_end = K["me_sort_E1"]
                self.to_modal_sort(evt)
                return True

            i = self.R_ind_by_mou_safe(evt.mouse_region_y)
            if i in self.li:
                self.is_draw_bu_focus   = True
                e = self.li[i]
                BU_FOCUS.get_ti(ref.ind, e.name.y, e.ind.text)
                m.redraw()
            elif self.is_draw_bu_focus:
                self.is_draw_bu_focus = False
                m.redraw()
        else:
            if self.is_draw_bu_focus:   self.is_draw_bu_focus = False  ;m.redraw()
        return False

    def to_region_mt_link(self):

        self.tm_evt_region = self.evt_region_mt_link
        e = self.tm_pop.name
        e.text = " MOVE COPY"
        e.color = P.color_font
    def modal_sort_exit(self, evt):
        m.head_modal[-1]    = N

        li          = self.li
        hi          = self.md_hi
        v           = self.tm_an_speed
        cv          = self.cv
        d_cy        = self.d_cy
        tm_pop      = self.tm_pop
        region      = self.tm_evt_region
        pop_ind     = self.tm_pop_ind
        pop_ind_org = self.tm_pop_ind_org

        tm_pop.name.text    = tm_pop.name.size
        tm_pop.name.color   = P.color_font_mod_name

        if region == self.evt_region_sort:

            if self.mt_win is not None: self.end_mt_sort()

            if pop_ind != pop_ind_org:
                name = self.obs[pop_ind_org].name

                dr_var_move_to_ind(self.w.act_dr.driver.variables, name, self.tm_pop_ind)
                m.undo_str = f'[Driver Editor] DriverVariable sort'
                m.undo_push()

            self.thread_sep_add_pop(tm_pop, cv.L + F[8], cv.T - d_cy - pop_ind * hi)
            self.thread_sep[self] = AN_AUTOKILL_ALL(self.threads, self.exit_fn_sort)
        elif region in {self.evt_region_del, self.evt_region_mt_del}:

            self.obs.remove(self.obs[pop_ind_org])
            m.undo_str = '[Driver Editor] DriverVariable delete'
            m.undo_push()
            self.anim_del(v, hi, d_cy, cv, li, tm_pop, pop_ind)
        elif region == self.evt_region_mt_link:

            mt_act_dr = self.mt_win.act_dr
            if mt_act_dr is None:
                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                return

            self.w.U_modal = N
            del m.head_modal[-1]
            self.tm_mouse = evt.mouse_region_x, evt.mouse_region_y

            self.top_win = MENU(
                evt.mouse_region_x, evt.mouse_region_y,
                [
                    ("bu_move", "Move"),
                    ("bu_copy", "Copy"),
                ],
                self.link_menu_end
            )
        else:
            self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
    def modal_sort_exit_multi(self, evt):
        m.head_modal[-1]    = N
        blf_size(font_0, F[9])

        tm_pop          = self.tm_pop
        cv              = self.cv
        md_hi           = self.md_hi
        region          = self.tm_evt_region
        pop_ind         = self.tm_pop_ind
        pop_ind_org     = self.tm_pop_ind_org

        variables       = self.w.act_dr.driver.variables
        self.job_ind    = 0
        self.tm_mouse   = evt.mouse_region_x, evt.mouse_region_y

        if region == self.evt_region_sort:
            li_sort         = self.sort_end_multi_R_li_sort(pop_ind, pop_ind_org)
            l               = len(li_sort)

            def job_fn(i):
                dr_var_move_to_ind(variables, li_sort[i], i)
                self.job_ind += 1
                return self.job_ind
            def call_progress():
                m.upd_disable()
                self.top_win = PROGRESS(*self.tm_mouse, self, l,
                    (job_fn(r) for r in range(l -1, -1, -1)),
                    self.job_fn_end_sort_uncheck, m.undo_push, self.job_fn_undo, N
                )

            TM = win_mess.TM
            TM["md_sels"]   = {md.name for i, md in enumerate(variables) if i in self.sel_range}
            TM["li_match"]  = li_sort
            TM["modifiers"] = variables
            self.modal_sort_fin_D1      = call_progress
            m.undo_str = '[Driver Editor] DriverVariable sort Start'
            m.undo_push()
            m.undo_str = '[Driver Editor] DriverVariable sort End'
        elif region in {self.evt_region_del, self.evt_region_mt_del}:
            tm_obs  = self.tm_obs
            job_li  = [tm_obs[r] for r in range(len(tm_obs)-1,-1,-1) if r in self.sel_range]
            l       = len(job_li)

            def job_fn(e):
                variables.remove(e)
                self.job_ind += 1
                return self.job_ind
            def job_fn_final():
                self.top_win.when_job_done()
                m.undo_push()
                m.upd_enable()
                m.refresh()
                job_li.clear()
                win_mess.TM.clear()
                self.modal_sort_desel_all()
            def call_progress():
                m.upd_disable()
                try:
                    self.bpy_ops_init()
                except:
                    m.upd_enable()
                    m.admin.report({'INFO'}, "Object is hidden")
                    return
                self.top_win = PROGRESS(*self.tm_mouse, self, l,
                    (job_fn(e) for e in job_li),
                    job_fn_final, m.undo_push, self.job_fn_undo, N
                )

            self.modal_sort_fin_D1      = call_progress
            m.undo_str = '[Driver Editor] DriverVariable remove Start'
            m.undo_push()
            m.undo_str = '[Driver Editor] DriverVariable remove End'
        elif region == self.evt_region_mt_link:
            mt_act_dr = self.mt_win.act_dr
            if mt_act_dr is None:   self.modal_sort_fin_D1 = N
            else:
                self.tm_mouse = evt.mouse_region_x, evt.mouse_region_y
                def call_mess():
                    self.top_win = MENU(
                        *self.tm_mouse,
                        [
                            ("bu_move", "Move"),
                            ("bu_copy", "Copy"),
                        ],
                        self.link_menu_end_multi
                    )
                self.modal_sort_fin_D1 = call_mess
                TM = win_mess.TM
                TM["mt_win"]        = self.mt_win
                TM["sel_range"]     = self.sel_range.copy()
                TM["obs"]           = self.obs
                TM["ll_bpy"]        = self.ll_bpy
        else:   self.modal_sort_fin_D1 = N

        self.anim_cancel_multi(tm_pop)

    def link_menu_end(self):

        m.head_modal.append(N)
        self.w.U_modal = self.w.default_modal

        job         = win_mess.TM["job"]
        mt          = self.mt_win
        mt_mods     = mt.R_A_ll()

        if job is False:
            self.tm_evt_region = self.evt_region_mt_cancel
            self.modal_sort_exit(None)
            del self.top_win
            return

        li          = self.li
        hi          = self.md_hi
        v           = self.tm_an_speed
        cv          = self.cv
        d_cy        = self.d_cy
        tm_pop      = self.tm_pop
        fc          = self.w.act_dr
        mt_fc       = mt.act_dr
        pop_name    = self.obs[self.tm_pop_ind_org].name
        mt_obs      = mt_mods.obs
        mt_sel_name = {mt_obs[i].name for i in mt_mods.sel_range}

        tm_pop.name.text    = tm_pop.name.size
        tm_pop.name.color   = P.color_font_mod_name

        if fc == mt_fc:

            if job == 'bu_move':
                if mt_mods.tm_pop_ind > self.tm_pop_ind_org: mt_mods.tm_pop_ind -= 1
                dr_var_move_to_ind(fc.driver.variables, pop_name, mt_mods.tm_pop_ind)
                m.undo_str = f'[Driver Editor] DriverVariable sort'
                m.undo_push()
            else:
                new_var = mt_obs.new()
                copyVariable(fc.driver.variables[pop_name], new_var)
                dr_var_move_to_ind(mt_obs, new_var.name, mt_mods.tm_pop_ind)
                m.undo_str = f'[Driver Editor] DriverVariable copy'
                m.undo_push()
        else:
            new_var = mt_obs.new()
            copyVariable(fc.driver.variables[pop_name], new_var)
            dr_var_move_to_ind(mt_obs, new_var.name, mt_mods.tm_pop_ind)

            if job == 'bu_move':
                variables = fc.driver.variables
                variables.remove(variables[pop_name])
                m.undo_str = f'[Driver Editor] DriverVariable move'
            else:
                m.undo_str = f'[Driver Editor] DriverVariable copy'
            m.undo_push()

        self.kill_mt_sort()
        self.thread_li_y.clear()
        self.thread_sep.clear()
        self.threads.clear()
        self.U_draw = self.I_draw
        self.kill_mods()

        self.modal_sort_fin(init_wait_release = False)
        dict_ind            = {e.name : i  for i, e in enumerate(mt_mods.obs)}
        mt_mods.sel_range   = {dict_ind[name] : None for name in mt_sel_name if name in dict_ind}
        mt_mods.sel_range[mt_mods.R_act_ind()] = None
        mt_mods.get_draw_ind_by_sel_range()
        del self.top_win
    def link_menu_end_multi(self):

        TM          = win_mess.TM
        job         = TM["job"]

        if job is False:    return

        mt          = TM["mt_win"]
        mt_mods     = mt.R_A_ll()
        fc          = self.w.act_dr
        mt_fc       = mt.act_dr
        sel_range   = TM["sel_range"]
        ind         = mt_mods.tm_pop_ind
        obs         = TM["obs"]
        tm_obs      = fc.driver.variables
        mt_obs      = mt_fc.driver.variables

        m.upd_disable()

        m.undo_str = f'[Driver Editor] DriverVariable {job[3:]} Start'
        m.undo_push()
        m.undo_str = f'[Driver Editor] DriverVariable {job[3:]} End'

        is_same_oj      = fc == mt_fc
        self.job_ind    = 0
        if is_same_oj and job == 'bu_move':

            pop_ind         = ind - sum(e < ind for e in sel_range)
            pop_ind_org     = self.tm_pop_ind_org

            li_sort         = self.sort_end_multi_R_li_sort(pop_ind, pop_ind_org,
                (tm_obs, obs, sel_range, TM["ll_bpy"]))

            l               = len(li_sort)

            def job_fn(i):
                dr_var_move_to_ind(tm_obs, li_sort[i], i)
                self.job_ind += 1
                return self.job_ind

            TM["md_sels"]      = {md.name for i, md in enumerate(tm_obs) if i in sel_range}
            TM["li_match"]     = li_sort
            TM["modifiers"]    = tm_obs

            self.top_win = PROGRESS(*self.tm_mouse, self, l,
                (job_fn(r) for r in range(l -1, -1, -1)),
                self.job_fn_end_sort_uncheck, m.undo_push, self.job_fn_undo, N
            )
            return

        job_li          = [e for r, e in enumerate(tm_obs) if r in sel_range]
        md_table        = {md.name : md for md in job_li}
        l               = len(job_li)
        md_copied       = []

        def job_fn_copy(name):
            new_var = mt_obs.new()
            copyVariable(tm_obs[name], new_var)
            md_copied.append(new_var.name)

            self.job_ind += 1
            return self.job_ind
        def job_next():

            self.top_win.gen = (job_fn_move(name) for name in reversed(md_copied))
            self.top_win.end_fn = job_fn_done  if job == "bu_copy" else job_next_del
        def job_fn_move(name):
            dr_var_move_to_ind(mt_obs, name, ind)
            self.job_ind += 1
            return self.job_ind
        def job_fn_done():
            self.top_win.when_job_done()
            m.undo_push()
            m.upd_enable()
            m.refresh()

            if md_copied:
                act_ind = mt_mods.R_act_ind()
                if act_ind != -1:
                    mt_sel_range = mt_mods.sel_range
                    mt_sel_range.clear()
                    mt_sel_range[act_ind] = None
                    for i, md in enumerate(mt_obs):
                        if md.name in md_copied:    mt_sel_range[i] = None
                    mt_mods.get_draw_ind_by_sel_range()
            if "desel" in TM:
                act_ind = self.R_act_ind()
                if act_ind != -1:
                    sel_range = self.sel_range
                    sel_range.clear()
                    sel_range[act_ind] = None
                    self.get_draw_ind_by_sel_range()
                    m.refresh()

            md_copied.clear()
            job_li.clear()
            md_table.clear()
            TM.clear()
        def job_next_del():

            self.top_win.gen = (job_fn_del_org(e) for e in reversed(job_li))
            self.top_win.end_fn = job_fn_done
            TM["desel"] = None
        def job_fn_del_org(e):
            tm_obs.remove(e)

            self.job_ind += 1
            return self.job_ind

        if job == "bu_copy":
            self.top_win = PROGRESS(*self.tm_mouse, self, l*2,
                (job_fn_copy(md.name) for md in job_li),
                job_next, m.undo_push, self.job_fn_undo, N
            )
        else:
            self.top_win = PROGRESS(*self.tm_mouse, self, l*3,
                (job_fn_copy(md.name) for md in job_li),
                job_next, m.undo_push, self.job_fn_undo, N
            )

    def pan_y(self): # self.ll_li != 0, self.headkey, self.endkey
        y       = m.dy
        li      = self.li
        d_cy    = self.d_cy
        h       = self.md_h
        L       = self.cv.L
        R       = self.cv.R
        self.cv.dy(y)
        headkey = self.R_headkey()

        if self.tm_dif != 0:
            new_y = min(max(self.y - self.tm_dif, self.tm_syslimdn), self.tm_syslimup)
            dif = new_y - self.y
            self.y = new_y
            self.tm_limyup += dif
            y += dif
            self.cv.dy(dif)
        self.cv.upd()

        if self.headkey != headkey:
            blf_size(font_0, F[9])
            dn = headkey - self.headkey
            upd_li_data     = self.upd_li_data
            if dn > 0:
                if dn >= self.max_ll:   dn = self.max_ll - 1

                hi = self.md_hi
                li_y = li[self.endkey].y - hi
                newkey = self.endkey + 1
                newhead = self.headkey + dn
                for r in range(self.headkey, newhead):
                    li[newkey] = li.pop(r)
                    e = li[newkey]
                    upd_li_data(newkey, e)
                    e.upd_blf_y(li_y)
                    li_y -= hi
                    newkey += 1

                self.headkey    = newhead
                self.endkey     = newkey - 1
            else:
                if -dn >= self.max_ll:  dn = 1 - self.max_ll

                hi = self.md_hi
                li_y = li[self.headkey].y + hi
                newkey = self.headkey - 1
                newend = self.endkey + dn
                for r in range(self.endkey, newend, -1):
                    li[newkey] = li.pop(r)
                    e = li[newkey]
                    upd_li_data(newkey, e)
                    e.upd_blf_y(li_y)
                    li_y += hi
                    newkey -= 1

                self.headkey    = newkey + 1
                self.endkey     = newend

            self.get_draw_ind_by_sel_range()

        ref_ic = self.ref.ic
        for e in li.values():
            e.dy_blf(y)
            T = e.y + d_cy
            e.bg.upd_bat(L, R, T - h, T)
            e.ic.upd(ref_ic, e.y)
        self.actbox.rim.dy_upd(y)
        self.actbox.bg.dy_upd(y)

    def modal_del(self, evt):

        m.EVT.kill_except(evt)
        if self.poll(): return

        def do_del():
            m.upd_disable()
            obs = self.obs
            for r in range(self.ll_bpy -1,-1,-1):
                if r in self.sel_range:
                    obs.remove(obs[r])

            m.upd_enable()
            m.refresh()
            m.undo_str = '[Driver Editor] DriverVariable delete'
            m.undo_push()

        if P.confirm_del:
            MESS_BOOL(evt.mouse_region_x, evt.mouse_region_y,
                "Do you want to delete the variable(s)?", do_del, N)
        else: do_del()

    def evt_rename(self, evt):

        if self.poll(): return

        n = self.R_ind_by_mou_safe(evt.mouse_region_y)
        if n is None:   return

        w = self.w
        v = self.obs[n]
        tx = v.name
        act_dr = w.act_dr

        def confirm_fn(name):

            old_name = v.name
            v.name = name
            if v.name != old_name:
                w.A_var.oo["da_name"].da.text = v.name
                m.undo_str = f'[Driver Editor] DriverVariable.name = "{v.name}"'
                m.undo_push()

        DDTX_RENAME(
            evt,
            tx,
            confirm_fn,
            FIL(self.obs),
            target          = f"animation_data.drivers.find('{act_dr.data_path}', index={act_dr.array_index}).driver.variables['{tx}'].name",
            full_path_head  = f'bpy.data.objects["{w.oj.name}"].',
        )
        m.redraw()
# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        li  = self.li
        ref = self.ref

        self.cv.bind_draw()
        BIND()  ;UNFL("color", self.color_bg_desel)
        for k in self.ind_desel:    li[k].bg.draw()
        BIND()  ;UNFL("color", self.color_bg_sel)
        for k in self.ind_sel:      li[k].bg.draw()
        self.actbox.U_draw()
        for e in li.values():       e.ic.bind_draw()

        ref_name    = ref.name
        ref_ind     = ref.ind

        blf_size(font_0, F[9])
        for e in li.values():
            blf_pos(font_0, ref_name, e.name.y, 0)
            e.name.set_color()
            e.name.draw()
        blf_size(font_0, F[7])
        blf_color(font_0, *self.color_num)
        for e in li.values():
            blf_pos(font_0, ref_ind, e.name.y, 0)
            e.ind.draw()

        if self.is_draw_bu_focus:   BU_FOCUS.U_draw()

    def I_draw_modal_sort(self):
        li  = self.li
        ref = self.ref

        self.cv.bind_draw()
        BIND()  ;UNFL("color", self.color_bg_desel)
        for e in li.values():       e.bg.draw()
        for e in li.values():       e.ic.bind_draw()

        ref_name    = ref.name
        ref_ind     = ref.ind

        blf_size(font_0, F[9])
        for e in li.values():
            blf_pos(font_0, ref_name, e.name.y, 0)
            e.name.set_color()
            e.name.draw()
        blf_size(font_0, F[7])
        blf_color(font_0, *self.color_num)
        for e in li.values():
            blf_pos(font_0, ref_ind, e.name.y, 0)
            e.ind.draw()