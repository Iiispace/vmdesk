import bpy
from blf import size as blf_size
from blf import color as blf_color

from .. import m, win

from .. props import EDITOR
from .. m import BOX, BLF
from .. bu import BU4, ENUM_SET
from .. det import INFO

from . light_tool_data import DATA_DEFAULT

P = None
F = None
K = None
N = None
font_0 = None
BLEND = None

class OP_LIGHT_TOOL(EDITOR):
    __slots__ = ()
    bl_idname = "wm.light_tool_editor_operator"
    bl_label = "Light Tool"

    def R_cls(self): return LIGHT_TOOL_ED
    def R_size(self): return P.win_size_init_LT


class LIGHT_TOOL_ED(win.WIN):
    __slots__ = (
        'oo',
        'A_data',
        # 'A_bu',
        'props',
        'obj_mode',
    )
    name = "Light Tool"
    W = []
    IND = []

    def init_D1(self):
        c = self.color
        c.font = P.color_font
        c.dr_info = P.color_oj_info
        self.obj_mode = None

        self.bo = {
            "me_info":  BOX(c.dr_info),
        }
        self.ti = {
            "info":     BLF(),
        }
        self.da = {

        }
        # A_bu = FAKE_AREA(self)
        # self.A_bu = A_bu

        self.oo = {
        }
        self.props = {
            "light_tool_ed_is_parent":              P.light_tool_ed_is_parent,
            "light_tool_ed_is_selected_objects":    P.light_tool_ed_is_selected_objects,
            "light_tool_ed_flip":                   P.light_tool_ed_flip,
            "light_tool_ed_is_link":                P.light_tool_ed_is_link,
            "light_tool_ed_use_collection":         P.light_tool_ed_use_collection,
            "light_tool_ed_collection_name":        [P.light_tool_ed_collection_name, None],
            "light_profile":                        ["", None],
            "light_tool_ed_dis":                    P.light_tool_ed_dis,
        }

        blf_title = self.tit["ti"]
        ind = blf_title.name
        if ind == 1:
            blf_title.text = "Light Tool"
        else:
            blf_title.text = f"Light Tool {ind}"

        self.cv.R_w = self.bo["me_info"].R_w
        self.cv.R_h = self.cv_R_h
        self.upd_data = self.I_upd_data

        self.A_data = DATA_DEFAULT(self)


# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo_main(self):
        inn = P.win_border_inner
        bo  = self.bo
        ti  = self.ti
        da  = self.da
        x   = self.box["main"].L + P.win_border - self.cv.x
        y   = self.box["main"].T - P.win_border + self.cv.y
        u   = P.scale[0]
        depth = inn - 3

        bo_info = bo["me_info"]
        bo_info.depth_L(x, round(308 * u) + depth)
        bo_info.depth_T(y - F[21], round(320 * u))

        ti["info"].xy(bo_info.L + F[5], y - F[13])

        blf_size(font_0, F[9])
        # bu_wi = round(40 * u)
        # bu_hi = F[16]
        # T = y - F[1]
        # R = bo_info.R

        self.A_data.__init__(self)

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd_main(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)

        self.A_data.dxy_upd(x, y)

    def glopan_upd(self):
        self.A_data.upd_sci()
    def I_modal_glopan_end_D1(self):

        self.I_upd_data()
    def modal_mov_end_D1(self):

        pass

    def cv_R_h(self):
        return self.bo["me_info"].R_h() + F[21]

    def bufn_space(self):

        self.props["mesh_ed_local"] = False if m.tm["ind"] == 0 else True
        self.I_upd_data()

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def modal_main_area(self, evt):
        # if self.A_bu.U_modal(evt):  return True

        if self.bo["me_info"].inbox(evt):
            if self.A_data.U_modal(evt):    return True
        else:
            self.A_data.unfocus()

        if K["undo0"].true() or K["undo1"].true():
            m.undo()
            m.EVT.kill_except(evt)
            return True
        if K["redo0"].true() or K["redo1"].true():
            m.redo()
            m.EVT.kill_except(evt)
            return True

        return False

    def outside_evt(self, evt):
        self.A_data.unfocus()
    def title_evt(self, evt):
        self.A_data.unfocus()

# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def draw_main(self):
        bo = self.bo
        ti = self.ti
        bo["me_info"].bind_draw()

        for e in self.oo.values():  e.draw_bo()

        blf_size(font_0, F[11])
        blf_color(font_0, *self.color.font)
        ti["info"].draw_pos()

        blf_size(font_0, F[9])
        for e in self.oo.values():  e.draw_ti()

        BLEND()
        self.A_data.U_draw()

# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_upd_data(self):

        # oo = self.oo
        oj = bpy.context.object
        obj_mode = oj.mode  if oj else None
        if obj_mode != self.obj_mode:

            self.obj_mode = obj_mode
            if obj_mode == "EDIT":
                self.ti["info"].text = "Edit Mode"
            elif obj_mode == "OBJECT":
                self.ti["info"].text = "Object Mode"
            else:
                self.ti["info"].text = "Object / Edit Mode requires"

        self.A_data.upd_data()

    def kill_data(self):    pass

