import bpy
from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP

from .. import m
from .. win_cls import A_DATA_PAN
from .. bu_block import P_BLOCK, P_BLOCK_GROUP, TI_DATA, KM, KM2, KM_SEL, KM_OPS
from .. bpy_ops import all_user_operator
from .. props import RNA_STR, RNA_BUTTON, prefs_np, prefs_km, prefs_km2, prefs_km_sel
from .. ui import D_PREF_SUBTYPES

P = None
F = None
K = None
BOX = None
BLF = None
font_0 = None
BLEND = None

button_gaps = (1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,16)
button_subtitle = (
    "Name 1",
    "Expression 1",
    "Name 2",
    "Expression 2",
    "Name 3",
    "Expression 3",
    "Name 4",
    "Expression 4",
    "Name 5",
    "Expression 5",
    "Name 6",
    "Expression 6",
    "Name 7",
    "Expression 7",
    "Name 8",
    "Expression 8",
    "Name 9",
    "Expression 9",
    "Name 10",
    "Expression 10",
    "Name 11",
    "Expression 11",
    "Name 12",
    "Expression 12",
)


class FOBOX:
    __slots__ = 'w', 'act_bo'
    def __init__(self, w):
        self.w = w
        self.act_bo = None
    def draw(self):
        m.bind_color_setting_bo_fo()
        self.act_bo.draw()


class SYSTEM:
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'key_end',
        'bo',
        'ti',
        'da',
        'sci',
        'color_ti',
        'color_da',
        'fobox',
        'tm_L',
        'tm_R',
        'tm_B',
        'tm_T',
        'bo_keys',
    )
    def R_name(self): return "System", SYSTEM
    def get_data(self):
        bo_keys = [
            "Display",
            "Control",
            "Menu",
            "Expression",
            "About",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Display":      BLF(text="Window position, Task bar, Enable function", size=DISPLAY),
            "Control":      BLF(text="Scroll speed, Drag threshold, Auto Pan speed", size=CONTROL),
            "Menu":         BLF(text="Drop Down Menu behavior, Format, Text Box", size=MENU),
            "Expression":   BLF(text="Calculator expressions and button functions", size=EXPRESSION),
            "About":        BLF(text="Information, Support and help", size=ABOUT),
        }
    def __init__(self, w):
        self.w = w
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.U_draw         = self.I_draw
        self.color_ti       = P.color_font
        self.color_da       = P.color_font_darker
        self.sci            = m.SCISSOR()
        self.upd_sci()

        self.get_data()
        bo = self.bo
        ti = self.ti
        da = self.da
        self.fobox = FOBOX(self)

        d       = F[2]
        dT      = F[17]
        dB      = F[8]
        # dL      = F[8]
        bo_wi   = F[38]
        L0, R0, B0, T0  = w.bo["data"].R_LRBT()
        L1  = L0 + d
        R1  = R0 - d
        T   = T0 - d

        for k in self.bo_keys:
            e = bo[k]
            e.LRBT(L1, R1, T - bo_wi, T)
            e.upd()
            ti[k].LT(e, dB, dT)
            da[k].LB(e, dB, dB)
            T = e.B - d

        paths = w.paths
        paths.kill()
        if hasattr(self, "R_names"):
            for e in self.R_names():    paths.new(*e)
        else:
            paths.new(*self.R_name())

        self.upd_data()

    def dxy_upd(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)

        self.upd_sci()

    def upd_sci(self):
        sci         = self.sci
        wsci        = self.w.sci
        L, R, B, T  = self.w.bo["data"].R_LRBT()
        sci.x       = max(L, wsci.x)
        sci.w       = max(0, min(R, wsci.x + wsci.w) - sci.x)
        sci.y       = max(B, wsci.y)
        sci.h       = max(0, min(T, wsci.y + wsci.h) - sci.y)

    def unfocus(self):
        if self.fobox.act_bo != None:
            self.fobox.act_bo = None
            m.redraw()

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y

        if K["me_pan0"].true():
            self.key_end = K["me_pan_E0"]
            self.to_modal_pan(evt)
            return True
        if K["me_pan1"].true():
            self.key_end = K["me_pan_E1"]
            self.to_modal_pan(evt)
            return True

        for k, e in self.bo.items():
            if e.inbox_xy(x, y):
                if self.fobox.act_bo != e:
                    self.fobox.act_bo = e
                    m.redraw()
                if K["sel_fast0"].true() or K["sel_fast1"].true():
                    self.to_subtab(k)
                    return True
                return False

        self.unfocus()
        return False

    def to_subtab(self, name):

        m.EVT.kill()
        m.redraw()
        w = self.w
        w.A_data = self.da[name].size(w)
        w.A_data.upd_data()

    def to_modal_pan(self, evt):

        self.fobox.act_bo = None
        m.redraw()

        _2 = F[2]
        sci = self.sci
        bo = self.bo[self.bo_keys[0]]
        self.tm_L = sci.x + _2
        self.tm_R = sci.x + sci.w - _2 - bo.R_w()
        self.tm_T = sci.y + sci.h - _2
        self.tm_B = sci.y + len(self.bo) * (bo.R_h() + _2)
        if self.tm_B < self.tm_T:   self.tm_B = self.tm_T

        self.key_end.true()
        m.head_modal.append(self.I_modal_pan)
        m.U_pan_cursor(self, evt)
        rim = self.w.resize_rim
        m.get_loop_mou_info_region(evt, rim.L, rim.R, rim.B, rim.T)
        m.get_mou(evt)
    def I_modal_pan(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':

                del m.head_modal[-1]
                m.U_end_pan(self)
                m.init_wait_release()
                self.w.I_upd_data()
                m.redraw()
                return
        m.U_pan(evt)

        dx = m.dx
        dy = m.dy
        bo = self.bo[self.bo_keys[0]]

        L = bo.L + dx
        T = bo.T + dy
        if L > self.tm_L:   dx = self.tm_L - bo.L
        elif L < self.tm_R: dx = self.tm_R - bo.L

        if T > self.tm_B:   dy = self.tm_B - bo.T
        elif T < self.tm_T: dy = self.tm_T - bo.T

        for e in self.bo.values():  e.dxy_upd(dx, dy)
        for e in self.ti.values():  e.dxy(dx, dy)
        for e in self.da.values():  e.dxy(dx, dy)

        m.loop_mou(evt)
        m.redraw()

    def I_draw(self):
        BLEND()
        self.sci.use()
        m.bind_color_setting_bo()
        for e in self.bo.values():  e.draw()
        if self.fobox.act_bo is not None:   self.fobox.draw()

        blf_size(font_0, F[12])
        blf_color(font_0, *self.color_ti)
        for e in self.ti.values():  e.draw_pos()
        blf_size(font_0, F[8])
        blf_color(font_0, *self.color_da)
        for e in self.da.values():  e.draw_pos()

    def upd_data(self):
        _2 = F[2]
        sci = self.sci
        bo = self.bo[self.bo_keys[0]]
        self.tm_L = sci.x + _2
        self.tm_R = sci.x + sci.w - _2 - bo.R_w()
        self.tm_T = sci.y + sci.h - _2
        self.tm_B = sci.y + len(self.bo) * (bo.R_h() + _2)
        if self.tm_B < self.tm_T:   self.tm_B = self.tm_T

        dx = 0
        dy = 0
        L = bo.L
        T = bo.T
        if L > self.tm_L:   dx = self.tm_L - L
        elif L < self.tm_R: dx = self.tm_R - L

        if T > self.tm_B:   dy = self.tm_B - T
        elif T < self.tm_T: dy = self.tm_T - T

        if dx or dy:
            for e in self.bo.values():  e.dxy_upd(dx, dy)
            for e in self.ti.values():  e.dxy(dx, dy)
            for e in self.da.values():  e.dxy(dx, dy)
        #
class EXPRESSION(SYSTEM):
    __slots__ = ()
    def R_names(self): return ("System", SYSTEM), self.R_name()
    def R_name(self): return "Expression", EXPRESSION
    def get_data(self):
        bo_keys = [
            "Buttons",
            "Function",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Buttons":      BLF(text="Calculator button names and expressions", size=BUTTONS),
            "Function":     BLF(text="Definition and information", size=FUNCTION),
        }
class PERSONALIZATION(SYSTEM):
    __slots__ = ()
    def R_name(self): return "Personalization", PERSONALIZATION
    def get_data(self):
        bo_keys = [
            "Taskbar",
            "Windows",
            "Icon",
            "Font",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Taskbar":      BLF(text="Taskbar appearance and color", size=TASKBAR),
            "Windows":      BLF(text="Windows appearance and color", size=WINDOWS),
            "Icon":         BLF(text="Icon appearance and color", size=ICON),
            "Font":         BLF(text="Font appearance and color", size=FONT),
        }
class APPS(SYSTEM):
    __slots__ = ()
    def R_name(self): return "Apps", APPS
    def get_data(self):
        bo_keys = [
            "Modifier Editor",
            "Driver Editor",
            "Mesh Editor",
            "Light Tool",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Modifier Editor":  BLF(text="Editor settings", size=MODIFIER_EDITOR),
            "Driver Editor":    BLF(text="Editor settings", size=DRIVER_EDITOR),
            "Mesh Editor":      BLF(text="Editor settings", size=MESH_EDITOR),
            "Light Tool":       BLF(text="Editor settings", size=LIGHT_TOOL),
        }
class ADDON_KEYMAP(SYSTEM):
    __slots__ = ()
    def R_name(self): return "Addon Keymap", ADDON_KEYMAP
    def get_data(self):
        bo_keys = [
            "Global",
            "Modifier Editor",
            "Dropdown Menu",
            "Color Panel",
            "Context Menu",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Global":           BLF(text="Global keys", size=GLOBAL),
            "Modifier Editor":  BLF(text="Built-in application", size=MD_EDITOR),
            "Dropdown Menu":    BLF(text="Dropdown Menu and Text", size=DROPDOWN_MENU),
            "Color Panel":      BLF(text="Color Panel and Picker", size=COLOR_PANEL),
            "Context Menu":     BLF(text="Right click Menu", size=CONTEXT_MENU),
        }
class BLENDER_KEYMAP(SYSTEM):
    __slots__ = ()
    def R_name(self): return "Blender Keymap", BLENDER_KEYMAP
    def get_data(self):
        bo_keys = [
            "Addon Operator",
        ]
        self.bo_keys = bo_keys

        self.bo = {name: BOX()  for name in bo_keys}
        self.ti = {name: BLF(text=name)  for name in bo_keys}
        self.da = {
            "Addon Operator":  BLF(text="Call operators directly in the viewport", size=ADDON_OPERATOR),
        }


class DISPLAY(A_DATA_PAN):
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'sci',
        'oo',
        'li',
        'max_ind',
        'headkey',
        'endkey',
        'key_end',
        'pref_keys',
        'description_wi',
        'ref_L',
        'ref_R',
        'hi',
        'li_h',
    )
    def R_names(self): return ("System", SYSTEM), self.R_name()
    def R_name(self): return "Display", DISPLAY
    def get_data(self):
        self.pref_keys = [
            "win_pos_init",
            "win_size_init",
            "win_size_init_DE",
            "win_size_init_ME",
            "win_size_init_LT",
            "win_size_init_SETTING",
            "scale",
            "scale_ti_bu",
            "ti_font_size",
            "tb_offset",
            "win_border",
            "win_border_inner",
            "win_offset_init",
            "win_offset_top",
            "win_shade_on",
            "win_shade_offset",
            "win_shade_softness",
            "win_shade_color",
            "dd_shade_offset",
            "dd_shade_softness",
            "dd_shade_color",
            "anim_tb_task",
            "anim_win_min",
            "anim_win_fit",
            "anim_win_x",
            "cursor_thickness",
            "cursor_flash_rate",
            "quick_edit_cursor",
            "dd_num_type",
            "dd_width",
            "anim_frame_time",
            "anim_speed",
        ]
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.sci            = m.SCISSOR()
        self.upd_sci()
        self.description_wi = self.R_description_wi()

        self.get_data()

        blf_size(font_0, F[9])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.description_wi)

        self.init_oo()
        blf_disable(font_0, WORD_WRAP)

        li = {}
        self.li = li

        bo_data = w.bo["data"]
        _1 = F[1]

        L = bo_data.L + _1
        R = bo_data.R - _1
        T = bo_data.T - _1
        self.ref_L = L
        self.ref_R = R

        hi_max = bo_data.R_h()
        self.hi = hi_max
        hi = _1
        oo = self.oo
        for r in range(len(oo)):
            # /* 0setting_data_for_li
            e = oo[r]
            e.get_bo(L, R, T)
            li[r] = e
            hi += e.hi + _1
            if hi >= hi_max:    break
            T = e.rim.B - _1
            # */

        self.li_h = hi - _1 - _1
        self.max_ind = len(oo) - 1
        self.headkey = 0
        self.endkey = r

        paths = w.paths
        paths.kill()
        if hasattr(self, "R_names"):
            l = self.R_names()
            if l is not None:
                for e in l:     paths.new(*e)
        else:
            e = self.R_name()
            if e is not None:   paths.new(*e)

        self.upd_data()

    def get_bo_from_head(self):
        oo = self.oo
        li = self.li
        hi_max = self.hi
        rim = li[self.headkey].rim
        T = rim.T
        L = rim.L
        R = rim.R
        li.clear()
        _1 = F[1]
        hi = _1

        for r in range(self.headkey, len(oo)):
            # <<< 1copy (0setting_data_for_li,, $$)
            e = oo[r]
            e.get_bo(L, R, T)
            li[r] = e
            hi += e.hi + _1
            if hi >= hi_max:    break
            T = e.rim.B - _1
            # >>>
        self.endkey = r
        self.upd_data()

    def R_description_wi(self): return F[110] * 2
    def R_li_hi(self):
        hi = 0
        _1 = F[1]
        for e in self.li.values():
            hi += e.hi + _1
        return hi - _1
    def dxy_upd(self, x, y):
        for e in self.li.values():  e.dxy(x, y)

        self.upd_sci()
    def upd_sci(self):
        sci         = self.sci
        wsci        = self.w.sci
        L, R, B, T  = self.w.bo["data"].R_LRBT()
        sci.x       = max(L, wsci.x)
        sci.w       = max(0, min(R, wsci.x + wsci.w) - sci.x)
        sci.y       = max(B, wsci.y)
        sci.h       = max(0, min(T, wsci.y + wsci.h) - sci.y)
    def init_oo(self):
        rnas = P.bl_rna.properties
        self.oo = {r: P_BLOCK(self, rnas[e])  for r, e in enumerate(self.pref_keys)}

    def unfocus(self):
        if self.U_modal == self.default_modal: return
        self.U_modal.__self__.outside()
        self.U_modal = self.default_modal


    def I_modal_main(self, evt):
        y = evt.mouse_region_y

        if K["pan0"].true():
            self.key_end = K["pan_E0"]
            self.to_modal_pan(evt)
            return True
        if K["pan1"].true():
            self.key_end = K["pan_E1"]
            self.to_modal_pan(evt)
            return True

        for e in self.li.values():
            if e.rim.in_BT_y(y):
                return e.I_modal_main(evt)
        self.unfocus()
        return False

    def I_draw(self):
        BLEND()
        self.sci.use()
        values = self.li.values()

        for e in values:    e.draw_box()

        blf_size(font_0, F[8])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.description_wi)
        blf_color(font_0, *P.color_font_darker)
        for e in values:    e.da.draw_pos()
        blf_disable(font_0, WORD_WRAP)

        for e in values:    e.draw_blf()

    def upd_data(self):

        self.fix_pan()
        for e in self.li.values():
            e.upd_oo()

class CONTROL(DISPLAY):
    __slots__ = ()
    def R_name(self): return "Control", CONTROL
    def get_data(self):
        self.pref_keys = [
            "lock_win_size",
            "sys_auto_off",
            "sync_act_oj",
            "sync_act_md",
            "auto_sel_text",
            "auto_del_text",
            "confirm_rename",
            "confirm_del",
            "confirm_apply",
            "pan_method",
            "auto_pan_speed",
            "win_pos_protect",
            "quick_edit_method",
            "quick_edit_operation",
            "quick_edit_fac_slow",
            "quick_edit_fac_fast",
            "calc_13iqe",
            "calc_01fqe",
            "calc_0ifqe",
            "calc_0pfqe",
            "calc_0dfqe",
            "quick_edit_fac_slow_hue",
            "quick_edit_fac_fast_hue",
            "filter_algorithm",
            "th_drag",
            "th_multi_drag",
            "scroll_fac",
            "bu_auto_speed",
            "bu_auto_time",
        ]
class MENU(DISPLAY):
    __slots__ = ()
    def R_name(self): return "Menu", MENU
    def get_data(self):
        self.pref_keys = [
            "dd_shade_offset",
            "dd_shade_softness",
            "dd_shade_color",
            "auto_sel_text",
            "auto_del_text",
            "cursor_thickness",
            "cursor_flash_rate",
            "dd_num_type",
            "dd_width",
            "quick_edit_method",
            "quick_edit_operation",
            "quick_edit_cursor",
            "quick_edit_fac_slow",
            "quick_edit_fac_fast",
            "calc_13iqe",
            "calc_01fqe",
            "calc_0ifqe",
            "calc_0pfqe",
            "calc_0dfqe",
            "quick_edit_fac_slow_hue",
            "quick_edit_fac_fast_hue",
            "filter_algorithm",
            "format_tx_f",
            "format_tx_i",
            "format_tx_h",
            "format_tx_vec",
            "vbox_precise_mode",
        ]
class ABOUT(DISPLAY):
    __slots__ = ()
    def R_name(self): return "About", ABOUT
    def get_data(self):
        hi = F[38]
        blf_size(font_0, F[8])
        e0, e1, e2 = m.addon_version
        ver = f'{e0}.{e1}.{e2}{" Trial" if m.is_trial else ""}'

        self.pref_keys = [
            P_BLOCK(self, RNA_STR("Addon Version", ver, ver, is_readonly=True)),
            P_BLOCK(self, RNA_BUTTON("Get Preferences Data", "", "Copy to Clipboard", bpy.ops.wm.vpp_r_pref)),
            P_BLOCK(self, RNA_STR("Bug Report", "E-mail", "oorcer.gmail.com", is_readonly=True)),
            P_BLOCK(self, RNA_STR("Donations", "PayPal", "paypal.me/oorc", is_readonly=True)),
        ]
    # /* 0setting_data_ABOUT_init_oo
    def init_oo(self):
        self.oo = {r: e  for r, e in enumerate(self.pref_keys)}
    # */
class BUTTONS(DISPLAY):
    __slots__ = ()
    def R_names(self): return ("System", SYSTEM), ("Expression", EXPRESSION), self.R_name()
    def R_name(self): return "Buttons", BUTTONS
    def get_data(self):
        rnas = P.bl_rna.properties
        self.pref_keys = [
            P_BLOCK_GROUP(self, [
                rnas["calc_13i1"],
                rnas["calc_13i1ex"],
                rnas["calc_13i2"],
                rnas["calc_13i2ex"],
                rnas["calc_13i3"],
                rnas["calc_13i3ex"],
                rnas["calc_13i4"],
                rnas["calc_13i4ex"],
                rnas["calc_13i5"],
                rnas["calc_13i5ex"],
                rnas["calc_13i6"],
                rnas["calc_13i6ex"],
                rnas["calc_13i7"],
                rnas["calc_13i7ex"],
                rnas["calc_13i8"],
                rnas["calc_13i8ex"],
                rnas["calc_13i9"],
                rnas["calc_13i9ex"],
                rnas["calc_13i10"],
                rnas["calc_13i10ex"],
                rnas["calc_13i11"],
                rnas["calc_13i11ex"],
                rnas["calc_13i12"],
                rnas["calc_13i12ex"],
            ], "Calculator Buttons : int", rnas["calc_13iqe"].description, button_subtitle, gaps=button_gaps),
            P_BLOCK_GROUP(self, [
                rnas["calc_0if1"],
                rnas["calc_0if1ex"],
                rnas["calc_0if2"],
                rnas["calc_0if2ex"],
                rnas["calc_0if3"],
                rnas["calc_0if3ex"],
                rnas["calc_0if4"],
                rnas["calc_0if4ex"],
                rnas["calc_0if5"],
                rnas["calc_0if5ex"],
                rnas["calc_0if6"],
                rnas["calc_0if6ex"],
                rnas["calc_0if7"],
                rnas["calc_0if7ex"],
                rnas["calc_0if8"],
                rnas["calc_0if8ex"],
                rnas["calc_0if9"],
                rnas["calc_0if9ex"],
                rnas["calc_0if10"],
                rnas["calc_0if10ex"],
                rnas["calc_0if11"],
                rnas["calc_0if11ex"],
                rnas["calc_0if12"],
                rnas["calc_0if12ex"],
            ], "Calculator Buttons : float", rnas["calc_0ifqe"].description, button_subtitle, gaps=button_gaps),
            P_BLOCK_GROUP(self, [
                rnas["calc_01f1"],
                rnas["calc_01f1ex"],
                rnas["calc_01f2"],
                rnas["calc_01f2ex"],
                rnas["calc_01f3"],
                rnas["calc_01f3ex"],
                rnas["calc_01f4"],
                rnas["calc_01f4ex"],
                rnas["calc_01f5"],
                rnas["calc_01f5ex"],
                rnas["calc_01f6"],
                rnas["calc_01f6ex"],
                rnas["calc_01f7"],
                rnas["calc_01f7ex"],
                rnas["calc_01f8"],
                rnas["calc_01f8ex"],
                rnas["calc_01f9"],
                rnas["calc_01f9ex"],
                rnas["calc_01f10"],
                rnas["calc_01f10ex"],
                rnas["calc_01f11"],
                rnas["calc_01f11ex"],
                rnas["calc_01f12"],
                rnas["calc_01f12ex"],
            ], "Calculator Buttons : float [0,1]", rnas["calc_01fqe"].description, button_subtitle, gaps=button_gaps),
            P_BLOCK_GROUP(self, [
                rnas["calc_0pf1"],
                rnas["calc_0pf1ex"],
                rnas["calc_0pf2"],
                rnas["calc_0pf2ex"],
                rnas["calc_0pf3"],
                rnas["calc_0pf3ex"],
                rnas["calc_0pf4"],
                rnas["calc_0pf4ex"],
                rnas["calc_0pf5"],
                rnas["calc_0pf5ex"],
                rnas["calc_0pf6"],
                rnas["calc_0pf6ex"],
                rnas["calc_0pf7"],
                rnas["calc_0pf7ex"],
                rnas["calc_0pf8"],
                rnas["calc_0pf8ex"],
                rnas["calc_0pf9"],
                rnas["calc_0pf9ex"],
                rnas["calc_0pf10"],
                rnas["calc_0pf10ex"],
                rnas["calc_0pf11"],
                rnas["calc_0pf11ex"],
                rnas["calc_0pf12"],
                rnas["calc_0pf12ex"],
            ], "Calculator Buttons : radians", rnas["calc_0pfqe"].description, button_subtitle, gaps=button_gaps),
            P_BLOCK_GROUP(self, [
                rnas["calc_0df1"],
                rnas["calc_0df1ex"],
                rnas["calc_0df2"],
                rnas["calc_0df2ex"],
                rnas["calc_0df3"],
                rnas["calc_0df3ex"],
                rnas["calc_0df4"],
                rnas["calc_0df4ex"],
                rnas["calc_0df5"],
                rnas["calc_0df5ex"],
                rnas["calc_0df6"],
                rnas["calc_0df6ex"],
                rnas["calc_0df7"],
                rnas["calc_0df7ex"],
                rnas["calc_0df8"],
                rnas["calc_0df8ex"],
                rnas["calc_0df9"],
                rnas["calc_0df9ex"],
                rnas["calc_0df10"],
                rnas["calc_0df10ex"],
                rnas["calc_0df11"],
                rnas["calc_0df11ex"],
                rnas["calc_0df12"],
                rnas["calc_0df12ex"],
            ], "Calculator Buttons : degrees", rnas["calc_0dfqe"].description, button_subtitle, gaps=button_gaps),
        ]
    def init_oo(self):
        self.oo = {r: e  for r, e in enumerate(self.pref_keys)}
    def R_description_wi(self): return F[93] * 2
class FUNCTION(BUTTONS):
    __slots__ = ()
    def R_name(self): return "Function", FUNCTION
    def get_data(self):
        self.pref_keys = [
            TI_DATA(self, F[46], "In development", ""),
        ]
class TASKBAR(DISPLAY):
    __slots__ = ()
    def R_names(self): return ("Personalization", PERSONALIZATION), self.R_name()
    def R_name(self): return "Taskbar", TASKBAR
    def get_data(self):
        self.pref_keys = [
            "color_tb_bg",
            "color_menu_start_bg",
            "color_mi_act",
            "color_mi_bg",
            "color_mi_bg_fo",
            "color_mi_ti",
            "color_mi_ti_off",
            "color_icon_start",
            "color_icon_start_fo",
        ]
class WINDOWS(TASKBAR):
    __slots__= ()
    def R_name(self): return "Windows", WINDOWS
    def get_data(self):
        self.pref_keys = [
            "color_win_rim",
            "color_win",
            "color_win_unfo",
            "color_bg_fo",
            "color_ti_bar",
            "color_ti_bar_warn",
            "color_ti_bar_unfo",
            "color_ti_bu",
            "color_ti_bu_fo",
            "color_ti_bu_sh",
            "color_ti_bu_sh_hold",
            "color_ti_bu_x",
            "color_oj_info",
            "color_bg_mod",
            "color_box_mod",
            "color_box_mod_sel",
            "color_box_mod_act",
            "color_box_mod_act_rim",
            "color_mod_bu_fo",
            "color_selbox",
            "color_selbox_rim",
            "color_bu_bg",
            "color_bu_1_off",
            "color_bu_1_on",
            "color_bu_1_rim",
            "color_bu_1_fo",
            "color_bu_1_ignore",
            "color_bu_1_rim_ignore",
            "color_bu_1_ignore_on",
            "color_bu_2",
            "color_bu_2_ignore",
            "color_bu_3_off",
            "color_bu_3_on",
            "color_bu_3_fo",
            "color_bu_3_ignore",
            "color_bu_4_off",
            "color_bu_4_on",
            "color_bu_4_rim",
            "color_bu_4_fo",
            "color_bu_4_ignore",
            "color_bu_media",
            "color_bu_media_fo",
            "color_bu_media_on",
            "color_bu_media_ignore",
            "color_setting_act",
            "color_setting_bo",
            "color_setting_bo_fo",
            "color_picker_bg",
            "color_picker_bg_hue",
            "color_picker_bg_hue_fo",
            "color_picker_bu",
            "color_ddmenu",
            "color_dd_actbox",
            "color_filter",
            "color_calc_bu",
            "color_scroll_rim",
            "color_scroll_rim_fo",
            "color_scroll_bar_rim",
            "color_scroll_bar_bg",
            "color_scroll_bar_fo",
            "color_tx_cursor",
            "color_tx_sel",
            "color_tx_copy",
            "color_r_menu_bg",
            "color_r_menu",
            "color_flash_box",
            "color_rm_bg",
            "color_rm_fobox",
            "color_tex_bg",
            "color_tex_main",
            "color_status_bar_bg",
            "color_mesh_ed_block",
            "color_mded_data_bg",
            "color_mded_data_rim",
        ]
class ICON(TASKBAR):
    __slots__= ()
    def R_name(self): return "Icon", ICON
    def get_data(self):
        self.pref_keys = [
            "color_icon_1",
            "color_icon_2",
            "color_icon_3",
            "color_icon_4",
            "color_icon_5",
            "color_icon_6",
            "color_icon_7",
            "color_icon_8",
            "color_icon_ignore",
            "color_icon_ignore2",
            "color_icon_light",
            "color_icon_start",
            "color_icon_start_fo",

            "color_bu_kf_fo",
            "color_bu_kf_yellow",
            "color_bu_kf_yellow_fo",
            "color_bu_kf_yellow_ignore",
            "color_bu_kf_green",
            "color_bu_kf_green_fo",
            "color_bu_kf_green_ignore",
            "color_bu_kf_orange",
            "color_bu_kf_orange_fo",
            "color_bu_kf_orange_ignore",
            "color_bu_dr",
            "color_bu_dr_fo",
            "color_bu_dr_ignore",
            "color_mdicon_kf_off",
            "color_mdicon_dr_off",
            "color_font_rm",
            "color_font_rm_ignore",
        ]
class FONT(TASKBAR):
    __slots__= ()
    def R_name(self): return "Font", FONT
    def get_data(self):
        self.pref_keys = [
            "color_font",
            "color_font_red",
            "color_font_fo",
            "color_font_ti",
            "color_font_sub_ti",
            "color_font_sub_ti_fo",
            "color_font_sub_ti_2",
            "color_font_sub_ti_2_fo",
            "color_font_mod_num",
            "color_font_mod_num_fo",
            "color_font_mod_name",
            "color_font_darker",
            "color_font_ignore",

            "color_bu_kf_fo",
            "color_bu_kf_yellow",
            "color_bu_kf_yellow_fo",
            "color_bu_kf_green",
            "color_bu_kf_green_fo",
            "color_bu_kf_orange",
            "color_bu_kf_orange_fo",
            "color_bu_dr",
            "color_bu_dr_fo",
            "color_mdicon_kf_off",
            "color_mdicon_dr_off",
            "color_font_rm",
            "color_font_rm_ignore",
        ]
class MODIFIER_EDITOR(DISPLAY):
    __slots__ = ()
    def R_names(self): return ("Apps", APPS), self.R_name()
    def R_name(self): return "Modifier Editor", MODIFIER_EDITOR
    def get_data(self):
        self.pref_keys = [
            "win_size_init",
            "sync_act_oj",
            "sync_act_md",
            "confirm_rename",
            "confirm_del",
            "confirm_apply",
            "mded_x",
            "color_mded_data_bg",
            "color_mded_data_rim",
            "color_box_mod",
            "color_box_mod_sel",
            "color_box_mod_act",
            "color_box_mod_act_rim",
            "color_mod_bu_fo",
            "color_icon_1",
            "color_icon_2",
            "color_icon_3",
            "color_icon_4",
            "color_icon_5",
            "color_icon_6",
            "color_icon_7",
            "color_icon_8",
            "color_icon_ignore",
            "color_icon_ignore2",
            "color_icon_light",
            "color_bu_kf_fo",
            "color_bu_kf_yellow",
            "color_bu_kf_yellow_fo",
            "color_bu_kf_green",
            "color_bu_kf_green_fo",
            "color_bu_kf_orange",
            "color_bu_kf_orange_fo",
            "color_bu_dr",
            "color_bu_dr_fo",
        ]
class DRIVER_EDITOR(MODIFIER_EDITOR):
    __slots__ = ()
    def R_name(self): return "Driver Editor", DRIVER_EDITOR
    def get_data(self):
        self.pref_keys = [
            "win_size_init_DE",
        ]
    #
    #
class MESH_EDITOR(MODIFIER_EDITOR):
    __slots__ = ()
    def R_name(self): return "Mesh Editor", MESH_EDITOR
    def get_data(self):
        self.pref_keys = [
            "mesh_ed_local",
            "mesh_ed_dis_invert",
            "mesh_ed_face_nor_keep_act",
            "mesh_ed_face_nor_keep_nor",
            "mesh_ed_cop_vert",
            "mesh_ed_vert_lim",
        ]
class LIGHT_TOOL(MODIFIER_EDITOR):
    __slots__ = ()
    def R_name(self): return "Light Tool", LIGHT_TOOL
    def get_data(self):
        self.pref_keys = [
            "light_tool_ed_is_parent",
            "light_tool_ed_is_selected_objects",
            "light_tool_ed_is_link",
            "light_tool_ed_use_collection",
            "light_tool_ed_collection_name",
            "light_tool_ed_flip",
            "light_tool_ed_dis",
        ]
    #
    #
class GLOBAL(DISPLAY):
    __slots__ = ()
    def R_names(self): return ("Addon Keymap", ADDON_KEYMAP), self.R_name()
    def R_name(self): return "Global", GLOBAL
    def get_data(self):
        rnas = P.bl_rna.properties
        self.pref_keys = [
            KM2(self, rnas["keys_sys_pass"], rnas["keys_sys_pass_E"]),
            KM_SEL(self, rnas["keys_sel_fast"], rnas["keys_sel"]),
            KM(self, rnas["keys_sel_ext"]),
            KM(self, rnas["keys_bu_sel"]),
            KM2(self, rnas["keys_bu_qe"], rnas["keys_bu_qe_E"]),
            KM(self, rnas["keys_bu_qe_cancel"]),
            KM(self, rnas["keys_bu_qe_slow"]),
            KM(self, rnas["keys_bu_qe_fast"]),
            KM(self, rnas["keys_bu_reset"]),
            KM(self, rnas["keys_bu_reset_all"]),
            KM(self, rnas["keys_bu_sel_ext"]),
            KM(self, rnas["keys_bu_left"]),
            KM(self, rnas["keys_bu_right"]),
            KM(self, rnas["keys_bu_up"]),
            KM(self, rnas["keys_bu_down"]),
            KM(self, rnas["keys_bu_insert_kf"]),
            KM(self, rnas["keys_bu_del_kf"]),
            KM(self, rnas["keys_bu_clear_kf"]),
            KM(self, rnas["keys_bu_add_dr"]),
            KM(self, rnas["keys_bu_del_dr"]),
            KM(self, rnas["keys_bu_dp"]),
            KM(self, rnas["keys_bu_dp_full"]),
            KM(self, rnas["keys_bu_dp_paste"]),
            KM(self, rnas["keys_bu_add_keying_set"]),
            KM(self, rnas["keys_bu_del_keying_set"]),
            KM(self, rnas["keys_bu_batch_kf"]),
            KM(self, rnas["keys_bu_batch_dr"]),
            KM(self, rnas["keys_bu_batch_value"]),
            KM(self, rnas["keys_rm"]),
            KM(self, rnas["keys_cancel"]),
            KM(self, rnas["keys_confirm"]),
            KM2(self, rnas["keys_pan"], rnas["keys_pan_E"]),
            KM2(self, rnas["keys_glopan"], rnas["keys_glopan_E"]),
            KM2(self, rnas["keys_ti_bu"], rnas["keys_ti_bu_E"]),
            KM2(self, rnas["keys_ti_mov"], rnas["keys_ti_mov_E"]),
            KM2(self, rnas["keys_resize"], rnas["keys_resize_E"]),
            KM(self, rnas["keys_undo"]),
            KM(self, rnas["keys_redo"]),
        ]
    # <<< || 1copy (0setting_data_ABOUT_init_oo,, $$)
    def init_oo(self):
        self.oo = {r: e  for r, e in enumerate(self.pref_keys)}
    # >>>
class MD_EDITOR(GLOBAL):
    __slots__ = ()
    def R_name(self): return "Modifier Editor", MD_EDITOR
    def get_data(self):
        rnas = P.bl_rna.properties
        self.pref_keys = [
            KM(self, rnas["keys_me_all"]),
            KM(self, rnas["keys_me_act_up"]),
            KM(self, rnas["keys_me_act_dn"]),
            KM(self, rnas["keys_me_act_up_ext"]),
            KM(self, rnas["keys_me_act_dn_ext"]),
            KM(self, rnas["keys_me_mod_up"]),
            KM(self, rnas["keys_me_mod_dn"]),
            KM(self, rnas["keys_me_del"]),
            KM(self, rnas["keys_me_apply"]),
            KM2(self, rnas["keys_me_pan"], rnas["keys_me_pan_E"]),
            KM2(self, rnas["keys_me_sort"], rnas["keys_me_sort_E"]),
            KM(self, rnas["keys_me_rename"]),
            KM(self, rnas["keys_me_sel_ext"]),
            KM(self, rnas["keys_me_sel"]),
            KM2(self, rnas["keys_me_box_ext"], rnas["keys_me_box_ext_E"]),
            KM2(self, rnas["keys_me_box"], rnas["keys_me_box_E"]),
        ]
class DROPDOWN_MENU(GLOBAL):
    __slots__ = ()
    def R_name(self): return "Dropdown Menu", DROPDOWN_MENU
    def get_data(self):
        rnas = P.bl_rna.properties
        self.pref_keys = [
            KM2(self, rnas["keys_dd_bar"], rnas["keys_dd_bar_E"]),
            KM(self, rnas["keys_dd_cancel"]),
            KM(self, rnas["keys_dd_confirm"]),
            KM(self, rnas["keys_dd_del_all"]),
            KM(self, rnas["keys_dd_del_word"]),
            KM(self, rnas["keys_dd_del_alp"]),
            KM(self, rnas["keys_dd_shift_left"]),
            KM(self, rnas["keys_dd_shift_right"]),
            KM(self, rnas["keys_dd_shift_up"]),
            KM(self, rnas["keys_dd_shift_down"]),
            KM(self, rnas["keys_dd_left"]),
            KM(self, rnas["keys_dd_right"]),
            KM(self, rnas["keys_dd_up"]),
            KM(self, rnas["keys_dd_down"]),
            KM2(self, rnas["keys_dd_box"], rnas["keys_dd_box_E"]),
            KM2(self, rnas["keys_dd_pan"], rnas["keys_dd_pan_E"]),
            KM(self, rnas["keys_dd_copy"]),
            KM(self, rnas["keys_dd_paste"]),
            KM(self, rnas["keys_dd_cut"]),
            KM(self, rnas["keys_dd_sel_all"]),
            KM(self, rnas["keys_dd_sel"]),
            KM(self, rnas["keys_dd_tab"]),
            KM(self, rnas["keys_dd_scroll_up"]),
            KM(self, rnas["keys_dd_scroll_down"]),
        ]
class COLOR_PANEL(GLOBAL):
    __slots__ = ()
    def R_name(self): return "Color Panel", COLOR_PANEL
    def get_data(self):
        rnas = P.bl_rna.properties
        self.pref_keys = [
            KM(self, rnas["keys_cp_hue_sel"]),
            KM2(self, rnas["keys_cp_hue"], rnas["keys_cp_hue_E"]),
            KM(self, rnas["keys_pk_cancel"]),
            KM(self, rnas["keys_pk_confirm"]),
        ]
class CONTEXT_MENU(GLOBAL):
    __slots__ = ()
    def R_name(self): return "Context Menu", CONTEXT_MENU
    def get_data(self):
        rnas = P.bl_rna.properties
        self.pref_keys = [
            KM(self, rnas["keys_rm_1"]),
            KM(self, rnas["keys_rm_2"]),
            KM(self, rnas["keys_rm_3"]),
            KM(self, rnas["keys_rm_4"]),
            KM(self, rnas["keys_rm_5"]),
            KM(self, rnas["keys_rm_6"]),
            KM(self, rnas["keys_rm_7"]),
            KM(self, rnas["keys_rm_8"]),
            KM(self, rnas["keys_rm_9"]),
            KM(self, rnas["keys_rm_0"]),
            KM(self, rnas["keys_rm_back"]),
            KM(self, rnas["keys_rm_next"]),
        ]
class ADDON_OPERATOR(GLOBAL):
    __slots__ = ()
    def R_names(self): return ("Blender Keymap", BLENDER_KEYMAP), self.R_name()
    def R_name(self): return "Addon Operator", ADDON_OPERATOR
    def R_cats(self): return bpy.context.window_manager.keyconfigs.addon.keymaps
    def get_data(self):
        li = []
        for cat in self.R_cats():
            for km in cat.keymap_items:
                if km.idname in all_user_operator:
                    li.append(KM_OPS(self, cat, km))

        self.pref_keys = li

    def upd_data(self):

        self.fix_pan()

        cats = self.R_cats()
        for e in self.li.values():
            try:
                e.km = e.cat.keymap_items.from_id(e.id)
                if e.km is None:
                    self.__init__(self.w)

                    return
            except:
                self.__init__(self.w)

                return
            e.upd_oo()

class FIND(GLOBAL):
    __slots__ = ()
    def R_pref_keys_by_tx(self, tx):
        tx = tx.lower()
        tx_len = len(tx)
        rnas = P.bl_rna.properties
        name_exp = ("Name", "Expression")
        wi = F[110] + F[150]
        tx_pass = "（）()[]{}.=; :-\n"
        pref_keys = []
        km = []
        km2 = []
        km_sel = []

        # //* 0setting_data_find_tx
        # *//

        for e in prefs_np:
            # /* 0setting_data_find_loop
            rna = rnas[e]
            if tx == rna.identifier:
                pref_keys.append(e)
                continue

            name = rna.name.lower()
            # <<< 1copy (0setting_data_find_tx,, $$)
            ind = name.find(tx)
            if ind != -1:
                i1 = ind + tx_len
                if i1 >= len(name): is_pass = True
                elif name[i1] in tx_pass: is_pass = True
                else: is_pass = False
    
                if is_pass:
                    if ind == 0 or name[ind - 1] in tx_pass:
                        pref_keys.append(e)
                        continue
            # >>>

            name = rna.description.lower()
            # <<< 1copy (0setting_data_find_tx,, $$)
            ind = name.find(tx)
            if ind != -1:
                i1 = ind + tx_len
                if i1 >= len(name): is_pass = True
                elif name[i1] in tx_pass: is_pass = True
                else: is_pass = False
    
                if is_pass:
                    if ind == 0 or name[ind - 1] in tx_pass:
                        pref_keys.append(e)
                        continue
            # >>>
            # */

        for e in prefs_km:
            # <<< 1copy (0setting_data_find_loop,, ${'pref_keys':'km'}$)
            rna = rnas[e]
            if tx == rna.identifier:
                km.append(e)
                continue

            name = rna.name.lower()
            # <<< 1copy (0setting_data_find_tx,, $$)
            ind = name.find(tx)
            if ind != -1:
                i1 = ind + tx_len
                if i1 >= len(name): is_pass = True
                elif name[i1] in tx_pass: is_pass = True
                else: is_pass = False
    
                if is_pass:
                    if ind == 0 or name[ind - 1] in tx_pass:
                        km.append(e)
                        continue
            # >>>

            name = rna.description.lower()
            # <<< 1copy (0setting_data_find_tx,, $$)
            ind = name.find(tx)
            if ind != -1:
                i1 = ind + tx_len
                if i1 >= len(name): is_pass = True
                elif name[i1] in tx_pass: is_pass = True
                else: is_pass = False
    
                if is_pass:
                    if ind == 0 or name[ind - 1] in tx_pass:
                        km.append(e)
                        continue
            # >>>
            # >>>

        for e in prefs_km2:
            # <<< 1copy (0setting_data_find_loop,, ${'pref_keys':'km2'}$)
            rna = rnas[e]
            if tx == rna.identifier:
                km2.append(e)
                continue

            name = rna.name.lower()
            # <<< 1copy (0setting_data_find_tx,, $$)
            ind = name.find(tx)
            if ind != -1:
                i1 = ind + tx_len
                if i1 >= len(name): is_pass = True
                elif name[i1] in tx_pass: is_pass = True
                else: is_pass = False
    
                if is_pass:
                    if ind == 0 or name[ind - 1] in tx_pass:
                        km2.append(e)
                        continue
            # >>>

            name = rna.description.lower()
            # <<< 1copy (0setting_data_find_tx,, $$)
            ind = name.find(tx)
            if ind != -1:
                i1 = ind + tx_len
                if i1 >= len(name): is_pass = True
                elif name[i1] in tx_pass: is_pass = True
                else: is_pass = False
    
                if is_pass:
                    if ind == 0 or name[ind - 1] in tx_pass:
                        km2.append(e)
                        continue
            # >>>
            # >>>

        for e in prefs_km_sel:
            # <<< 1copy (0setting_data_find_loop,, ${'pref_keys':'km_sel'}$)
            rna = rnas[e]
            if tx == rna.identifier:
                km_sel.append(e)
                continue

            name = rna.name.lower()
            # <<< 1copy (0setting_data_find_tx,, $$)
            ind = name.find(tx)
            if ind != -1:
                i1 = ind + tx_len
                if i1 >= len(name): is_pass = True
                elif name[i1] in tx_pass: is_pass = True
                else: is_pass = False
    
                if is_pass:
                    if ind == 0 or name[ind - 1] in tx_pass:
                        km_sel.append(e)
                        continue
            # >>>

            name = rna.description.lower()
            # <<< 1copy (0setting_data_find_tx,, $$)
            ind = name.find(tx)
            if ind != -1:
                i1 = ind + tx_len
                if i1 >= len(name): is_pass = True
                elif name[i1] in tx_pass: is_pass = True
                else: is_pass = False
    
                if is_pass:
                    if ind == 0 or name[ind - 1] in tx_pass:
                        km_sel.append(e)
                        continue
            # >>>
            # >>>

        pref_keys.sort()
        km.sort()
        km2.sort()
        km_sel.sort()

        blf_size(font_0, F[9])
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.R_description_wi())

        pref_keys = [P_BLOCK(self, rnas[e])  for e in pref_keys] + [KM(self, rnas[e])  for e in km_sel] + [KM(self, rnas[e])  for e in km2] + [KM(self, rnas[e])  for e in km]

        blf_disable(font_0, WORD_WRAP)
        return pref_keys
    def R_names(self): return None
    def R_name(self): return None
    def get_data(self): pass
    def __init__(self, w, tx):
        self.pref_keys = self.R_pref_keys_by_tx(tx)
        if not self.pref_keys:
            self.pref_keys.append(TI_DATA(self, F[24]+F[2], "No Results.", ""))
        super().__init__(w)