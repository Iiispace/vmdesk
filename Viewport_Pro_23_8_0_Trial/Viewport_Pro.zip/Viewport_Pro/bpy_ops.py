import bpy, base64
from ast import literal_eval
from pathlib import Path
from bpy.types import Operator
from mathutils import Vector
# from math import pi as math_pi
# from math import tau as math_tau

from blf import size as blf_size
from blf import position as blf_pos
from blf import color as blf_color
from blf import draw as blf_draw
from gpu_extras.batch import batch_for_shader

from . import m

class VPP_FACTORY(Operator):
    bl_idname = "wm.vpp_factory"
    bl_label = "Restore to Factory settings"
    bl_options = {'REGISTER'}

    @staticmethod
    def main(reset_keymap=True):
        P = m.P
        props = P.bl_rna.properties

        for at in props:
            if hasattr(at, "default"):
                if at.identifier in {"bl_idname", "refresh"}: continue
                if getattr(at, "is_array", False):
                    getattr(P, at.identifier)[:] = at.default_array
                else:
                    setattr(P, at.identifier, at.default)

        if reset_keymap:
            try:
                wm = bpy.context.window_manager
                kc = wm.keyconfigs.addon
                if kc:
                    kms = kc.keymaps
                    if "Screen" in kms:
                        kms["Screen"].restore_to_default()
                    else:
                        km = kms.new(name="Screen")
                        kmi = km.keymap_items
                        cls_ops_kms = getattr(m, "cls_ops_kms", None)

                        if cls_ops_kms:
                            r = 3
                            for cls in cls_ops_kms:
                                kmi.new(cls.bl_idname, type=f'F1{r}', value='PRESS')
                                r += 1
            except: pass

        try:
            m.get_K()
            m.refresh()
            m.redraw()
            P.scale[0] = P.scale[0]
        except: pass

    def execute(self, context):
        self.__class__.main()
        return {'FINISHED'}
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    #
    #
class VPP_BEVEL_PROFILE(Operator):
    bl_idname = "wm.vpp_bevel_profile"
    bl_label = "Custom Profile"
    bl_options = {'INTERNAL'}

    md = None

    def execute(self, context): return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.template_curveprofile(VPP_BEVEL_PROFILE.md, "custom_profile")
    #
    #
class VPP_FALLOFF_CURVE(Operator):
    bl_idname = "wm.vpp_falloff_curve"
    bl_label = "Falloff Curve"
    bl_options = {'INTERNAL'}

    md = None
    attr = ""

    def execute(self, context): return {'FINISHED'}

    def invoke(self, context, event):
        self.md = VPP_FALLOFF_CURVE.md
        self.attr = VPP_FALLOFF_CURVE.attr
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.template_curve_mapping(self.md, self.attr)
    #
    #
class VPP_SCAN_FILE(Operator):
    bl_idname = "wm.vpp_scan_file"
    bl_label = "Accept"
    bl_options = {'INTERNAL'}
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    end_fn = None

    def execute(self, context):
        try:    self.fin(self.filepath)
        except: pass
        return {'FINISHED'}

    def invoke(self, context, event):
        self.filepath = ""
        self.fin = VPP_SCAN_FILE.end_fn
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
class VPP_R_PREF(Operator):
    bl_idname = "wm.vpp_r_pref"
    bl_label = "Get Preferences Data"
    bl_options = {'REGISTER'}

    @staticmethod
    def decode(s):
        out = {}
        if s == "DEFAULT": return out
        try:
            b64decode = base64.b64decode
            D_en0_rev = VPP_R_PREF.D_en0_rev

            while s:
                i0 = s.find(":")
                if i0 == -1: break
                attr = s[:i0]
                if attr in D_en0_rev:   attr = D_en0_rev[attr]
                s = s[i0 + 1 :]
                c = s[0]
                if c == "[":
                    i1 = s.find("]")
                    if i1 == -1: break
                    out[attr] = literal_eval(s[: i1 + 1])
                    s = s[i1 + 2 :]
                elif c == "b":
                    i1 = s.find("'", 2)
                    if i1 == -1: break
                    out[attr] = b64decode(literal_eval(s[: i1 + 1])).decode()
                    s = s[i1 + 2 :]
                else:
                    i1 = s.find(",")
                    if i1 == -1: break
                    out[attr] = literal_eval(s[: i1])
                    s = s[i1 + 1 :]
            return out
        except: return out

    @staticmethod
    def main():
        P = m.P
        props = P.bl_rna.properties
        b64encode = base64.b64encode
        out = ""

        for at in props:
            if hasattr(at, "default"):
                attr = at.identifier
                if attr in {"bl_idname", "refresh"}: continue

                if getattr(at, "is_array", False):
                    vv = getattr(P, attr)
                    if any(e0 != e1 for e0, e1 in zip(at.default_array, vv)): pass
                    else: continue

                    s = "["
                    for e in vv:  s += f'{e},'
                    s = f'{s[:-1]}]'

                    out += f'{attr}:{s},'
                else:
                    v0 = getattr(P, attr)
                    if at.default == v0: continue

                    if isinstance(v0, str):
                        s = b64encode(v0.encode())
                    else:
                        s = v0
                    out += f'{attr}:{s},'

        return out if out else "DEFAULT"
    def execute(self, context):
        try:
            out = self.__class__.main()
            context.window_manager.clipboard = out
            self.report({'INFO'}, "Preferences data has been copied to the clipboard.")
        except: pass
        return {'FINISHED'}
    #
    #

class OPS_MOVE_FRONT(Operator):
    __slots__ = (
        'r3d',
        'mat',
        'mou_org',
        'old_cursor_warp',
    )
    bl_idname = "view3d.vpp_move_front"
    bl_label = "Move Front"
    bl_options = {'REGISTER'}

    def fin(self, context):
        self.r3d.update()
        context.window.cursor_warp(*self.mou_org)
        context.window.cursor_modal_restore()
        context.area.tag_redraw()
        m.cursor_warp = self.old_cursor_warp
    def modal(self, context, event):
        if event.value == 'RELEASE' or event.type == "ESC":
            self.fin(context)
            return {'FINISHED'}

        if event.type == 'MOUSEMOVE':
            m.I_pan(event)
            d = m.dx + m.dy
            if d != 0:

                mat = self.mat.copy()
                mat[2][3] = self.r3d.view_matrix[2][3] + d * 0.1
                self.r3d.view_matrix = mat

            m.loop_mou(event)

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}

        r3d = context.space_data.region_3d
        r3d.update()

        self.r3d = r3d
        self.mat = r3d.view_matrix.copy()
        context.window.cursor_modal_set("NONE")
        context.area.tag_redraw()
        self.old_cursor_warp = m.cursor_warp
        m.cursor_warp = context.window.cursor_warp
        m.get_loop_mou_info()
        m.get_mou(event)
        self.mou_org = (event.mouse_x, event.mouse_y)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
class OPS_IMG_GET(Operator):
    __slots__ = (
        'mat',
        'nodes',
        'folders',
        'han',
        'blfs',
        'boxes',
    )
    bl_idname = "node.vpp_img_get"
    bl_label = "Get Image"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    @classmethod
    def poll(cls, context):
        if context.area.type != "NODE_EDITOR": return False
        return True

    def fin(self, cancel=False):

        bpy.types.SpaceNodeEditor.draw_handler_remove(self.han, 'WINDOW')
        return {'CANCELLED'}  if cancel else {'FINISHED'}

    def invoke(self, context, event):
        mat = context.material
        if mat is None:
            self.report({'WARNING'}, "Material is None")
            return {'CANCELLED'}

        nodes = [e for e in context.selected_nodes  if e.type == "TEX_IMAGE" and e.image]
        if not nodes:
            self.report({'WARNING'}, "No Valid Image Node")
            return {'CANCELLED'}

        self.mat = mat
        self.nodes = nodes
        self.han = bpy.types.SpaceNodeEditor.draw_handler_add(
            self.draw_callback_px, (), 'WINDOW', 'POST_PIXEL')

        LL = event.mouse_region_x - 100
        L0 = LL + 10
        L1 = L0 + 30
        T = event.mouse_region_y + 50
        BLF = m.BLF
        color_font = m.P.color_font
        font_size = 16

        blfs = []
        self.blfs = blfs
        node = nodes[0]
        img = node.image
        path = Path(img.filepath)
        # name = path.stem
        # i = name.rfind("_")
        # name = name[: i]
        folders = [e for e in path.parents[1].glob('*/') if e.is_dir()]
        self.folders = folders

        y = T - 22
        blf_size(m.font_0, font_size)
        RR = LL
        for r, folder in enumerate(folders):
            blfs.append(BLF(color_font, str(r), font_size, L0, y))
            e = BLF(color_font, folder.stem, font_size, L1, y)
            blfs.append(e)
            R = e.R_end_x()
            if R > RR: RR = R
            y -= 22

            # for ee in e.glob('*/'):
            #     if ee.is_file():
            #         img_name = ee.stem
            #         img_name = img_name[: img_name.rfind("_")]
            #         if img_name == name:
            #             pass

        B = blfs[-1].y - 10  if blfs else T - 16
        self.boxes = [
            m.BOX([0.1, 0.1, 0.1, 1.0], LL, RR + 10, B, T)
        ]
        self.boxes[0].upd()

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        context.area.tag_redraw()
        evt_type = event.type
        if evt_type in {"ESC", "RIGHTMOUSE"}:
            return self.fin(cancel=True)

        if event.value != "RELEASE": return {'RUNNING_MODAL'}

        if evt_type in {"ZERO", "NUMPAD_0"}:    return self.do_main(0)
        if evt_type in {"ONE", "NUMPAD_1"}:     return self.do_main(1)
        if evt_type in {"TWO", "NUMPAD_2"}:     return self.do_main(2)
        if evt_type in {"THREE", "NUMPAD_3"}:   return self.do_main(3)
        if evt_type in {"FOUR", "NUMPAD_4"}:    return self.do_main(4)
        if evt_type in {"FIVE", "NUMPAD_5"}:    return self.do_main(5)
        if evt_type in {"SIX", "NUMPAD_6"}:     return self.do_main(6)
        if evt_type in {"SEVEN", "NUMPAD_7"}:   return self.do_main(7)
        if evt_type in {"EIGHT", "NUMPAD_8"}:   return self.do_main(8)
        if evt_type in {"NINE", "NUMPAD_9"}:    return self.do_main(9)
        return {'RUNNING_MODAL'}

    def draw_callback_px(self):
        self.boxes[0].bind_draw()
        for e in self.blfs: e.set_draw()

    def do_main(self, ind):
        folder_name = self.folders[ind].stem
        for node in self.nodes:
            img_path = Path(node.image.filepath)
            img_name = img_path.stem
            name0 = img_name[: img_name.rfind("_")]
            folder = None
            for e in img_path.parents[1].glob('*/'):
                if e.is_dir() and e.stem == folder_name:
                    folder = e
                    break

            if folder is not None:
                for img in folder.glob('*/'):
                    if img.is_file():
                        name = img.stem
                        name = name[: name.rfind("_")]
                        if name == name0:
                            try:
                                old_img = node.image
                                path = str(img.absolute())
                                new_img = None
                                for o in bpy.data.images:
                                    if o.filepath == path:
                                        new_img = o

                                        break

                                if new_img is None:
                                    new_img = bpy.data.images.load(filepath=path)
                                    node.image = new_img
                                    new_img.source = old_img.source
                                    new_img.colorspace_settings.name = old_img.colorspace_settings.name
                                    new_img.alpha_mode = old_img.alpha_mode
                                    if old_img.users == 0:
                                        bpy.data.images.remove(old_img)
                                else:
                                    node.image = new_img
                            except: pass

        return self.fin()


all_operator_internal = {e.bl_idname  for e in globals().values() if hasattr(e, "bl_options") and "INTERNAL" in e.bl_options}
all_operator = {e.bl_idname  for e in globals().values() if hasattr(e, "bl_idname")}
all_operator.add("wm.md_editor_operator")
all_operator.add("wm.dr_editor_operator")
all_operator.add("wm.mesh_editor_operator")
all_operator.add("wm.light_tool_editor_operator")
all_operator.add("wm.setting_editor_operator")
all_user_operator = {e for e in all_operator if e not in all_operator_internal}

def R_operators_all():
    bpy_ops = bpy.ops
    NAME = m.NAME
    li = []
    for e in dir(bpy_ops):
        li += [NAME(f'{e}.{ee}') for ee in dir(getattr(bpy_ops, e))]
    return li
def R_operators_vpp():
    NAME = m.NAME
    return [NAME(e)  for e in all_user_operator]