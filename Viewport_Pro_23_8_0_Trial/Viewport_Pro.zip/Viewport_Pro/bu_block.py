import bpy
from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP
from colorsys import rgb_to_hsv, hsv_to_rgb
from struct import pack as struct_pack

from . import m
from . keys import (
    key_value_to_title,
    key_title_to_value,
    time_keys,
    R_tx_comb,
    dict_value,
    value_dict,
    key_value_set,
    key_title_set,
    dict_type,
    type_dict,
    non_release,
)
from . fn import bin_search, TR_ind, TR_ind_ex, R_str_by_deg, rgb_to_hex, hex_to_rgb, R_rgb_by_str, is_ind_0, R_sign32, R_unsign32
from . dd import DDTX, DDVAL, DD_COLOR
from . filt import FIL
from . rm import RM
from . color_list import L_rgb_to_glc, L_rgb_to_glb, D_null
from . ED_setting.setting_key_edit import KEY_ED, KEY_ED_SINGLE
from . calc import calc_vec
from . bpy_ops import R_operators_vpp, all_user_operator
from . props import RNA_STR, RNA_BUTTON, RNA_FLOAT_ARRAY, rna_km_duration, rna_km_value, rna_km_exact, rna_km_repeat, rna_km_value_press, rna_km_value_release
from . ui import D_ui_pref, D_ui_ids, tuple_XYZ, BOOLEAN, BOOLEAN_ENUM, BOOL_INT_ENUM, STRING, STRING_COLOR_HEX, STRING_ENUM, KEYMAP_TYPE, INT, INT_ARRAY, INT_SUBTI, INT_ARRAY_SUBTI, FLOAT, FLOAT_ARRAY, FLOAT_SUBTI, FLOAT_ARRAY_SUBTI, BUTTON, BUTTONKF, COLOR3, COLOR4, FLOAT_ARRAY_GEO_RGBA

P = None
F = None
K = None
N = None
BOX = None
BLF = None
BOX_C = None
font_0 = None

color_black = (0.0, 0.0, 0.0, 1.0)
color_white = (1.0, 1.0, 1.0, 1.0)
tuple_RGBA = ('R', 'G', 'B', 'A')
tuple_HSV = ('H', 'S', 'V')
tuple_hex = ('#',)
tuple_sec = ('sec',)


D_map_type = {
    'KEYBOARD': 'Keyboard',
    'MOUSE': 'Mouse',
    'NDOF': 'NDOF',
    'TEXTINPUT': 'Text Input',
    'TIMER': 'Timer'}
D_map_type_rev = {
    'Keyboard': 'KEYBOARD',
    'Mouse': 'MOUSE',
    'NDOF': 'NDOF',
    'Text Input': 'TEXTINPUT',
    'Timer': 'TIMER'}
D_value = {
    'ANY': 'Any',
    'PRESS': 'Press',
    'RELEASE': 'Release',
    'CLICK': 'Click',
    'DOUBLE_CLICK': 'Double Click',
    'CLICK_DRAG': 'Click Drag',
    'NOTHING': 'Nothing'}
D_value_rev = {
    'Any': 'ANY',
    'Press': 'PRESS',
    'Release': 'RELEASE',
    'Click': 'CLICK',
    'Double Click': 'DOUBLE_CLICK',
    'Click Drag': 'CLICK_DRAG',
    'Nothing': 'NOTHING'}
D_type = {
    'NONE': '',
    'LEFTMOUSE': 'Left Mouse',
    'MIDDLEMOUSE': 'Middle Mouse',
    'RIGHTMOUSE': 'Right Mouse',
    'BUTTON4MOUSE': 'Button4 Mouse',
    'BUTTON5MOUSE': 'Button5 Mouse',
    'BUTTON6MOUSE': 'Button6 Mouse',
    'BUTTON7MOUSE': 'Button7 Mouse',
    'PEN': 'Pen',
    'ERASER': 'Eraser',
    'MOUSEMOVE': 'Mouse Move',
    'INBETWEEN_MOUSEMOVE': 'In-between Move',
    'TRACKPADPAN': 'Mouse/Trackpad Pan',
    'TRACKPADZOOM': 'Mouse/Trackpad Zoom',
    'MOUSEROTATE': 'Mouse/Trackpad Rotate',
    'MOUSESMARTZOOM': 'Mouse/Trackpad Smart Zoom',
    'WHEELUPMOUSE': 'Wheel Up',
    'WHEELDOWNMOUSE': 'Wheel Down',
    'WHEELINMOUSE': 'Wheel In',
    'WHEELOUTMOUSE': 'Wheel Out',
    'A': 'A',
    'B': 'B',
    'C': 'C',
    'D': 'D',
    'E': 'E',
    'F': 'F',
    'G': 'G',
    'H': 'H',
    'I': 'I',
    'J': 'J',
    'K': 'K',
    'L': 'L',
    'M': 'M',
    'N': 'N',
    'O': 'O',
    'P': 'P',
    'Q': 'Q',
    'R': 'R',
    'S': 'S',
    'T': 'T',
    'U': 'U',
    'V': 'V',
    'W': 'W',
    'X': 'X',
    'Y': 'Y',
    'Z': 'Z',
    'ZERO': '0',
    'ONE': '1',
    'TWO': '2',
    'THREE': '3',
    'FOUR': '4',
    'FIVE': '5',
    'SIX': '6',
    'SEVEN': '7',
    'EIGHT': '8',
    'NINE': '9',
    'LEFT_CTRL': 'Left Ctrl',
    'LEFT_ALT': 'Left Alt',
    'LEFT_SHIFT': 'Left Shift',
    'RIGHT_ALT': 'Right Alt',
    'RIGHT_CTRL': 'Right Ctrl',
    'RIGHT_SHIFT': 'Right Shift',
    'OSKEY': 'OS Key',
    'APP': 'Application',
    'GRLESS': 'Grless',
    'ESC': 'Esc',
    'TAB': 'Tab',
    'RET': 'Return',
    'SPACE': 'Spacebar',
    'LINE_FEED': 'Line Feed',
    'BACK_SPACE': 'Backspace',
    'DEL': 'Delete',
    'SEMI_COLON': ';',
    'PERIOD': '.',
    'COMMA': ',',
    'QUOTE': '"',
    'ACCENT_GRAVE': '`',
    'MINUS': '-',
    'PLUS': '+',
    'SLASH': '/',
    'BACK_SLASH': '\\',
    'EQUAL': '=',
    'LEFT_BRACKET': '[',
    'RIGHT_BRACKET': ']',
    'LEFT_ARROW': 'Left Arrow',
    'DOWN_ARROW': 'Down Arrow',
    'RIGHT_ARROW': 'Right Arrow',
    'UP_ARROW': 'Up Arrow',
    'NUMPAD_2': 'Numpad 2',
    'NUMPAD_4': 'Numpad 4',
    'NUMPAD_6': 'Numpad 6',
    'NUMPAD_8': 'Numpad 8',
    'NUMPAD_1': 'Numpad 1',
    'NUMPAD_3': 'Numpad 3',
    'NUMPAD_5': 'Numpad 5',
    'NUMPAD_7': 'Numpad 7',
    'NUMPAD_9': 'Numpad 9',
    'NUMPAD_PERIOD': 'Numpad .',
    'NUMPAD_SLASH': 'Numpad /',
    'NUMPAD_ASTERIX': 'Numpad *',
    'NUMPAD_0': 'Numpad 0',
    'NUMPAD_MINUS': 'Numpad -',
    'NUMPAD_ENTER': 'Numpad Enter',
    'NUMPAD_PLUS': 'Numpad +',
    'F1': 'F1',
    'F2': 'F2',
    'F3': 'F3',
    'F4': 'F4',
    'F5': 'F5',
    'F6': 'F6',
    'F7': 'F7',
    'F8': 'F8',
    'F9': 'F9',
    'F10': 'F10',
    'F11': 'F11',
    'F12': 'F12',
    'F13': 'F13',
    'F14': 'F14',
    'F15': 'F15',
    'F16': 'F16',
    'F17': 'F17',
    'F18': 'F18',
    'F19': 'F19',
    'F20': 'F20',
    'F21': 'F21',
    'F22': 'F22',
    'F23': 'F23',
    'F24': 'F24',
    'PAUSE': 'Pause',
    'INSERT': 'Insert',
    'HOME': 'Home',
    'PAGE_UP': 'Page Up',
    'PAGE_DOWN': 'Page Down',
    'END': 'End',
    'MEDIA_PLAY': 'Media Play/Pause',
    'MEDIA_STOP': 'Media Stop',
    'MEDIA_FIRST': 'Media First',
    'MEDIA_LAST': 'Media Last',
    'TEXTINPUT': 'Text Input',
    'WINDOW_DEACTIVATE': 'Window Deactivate',
    'TIMER': 'Timer',
    'TIMER0': 'Timer 0',
    'TIMER1': 'Timer 1',
    'TIMER2': 'Timer 2',
    'TIMER_JOBS': 'Timer Jobs',
    'TIMER_AUTOSAVE': 'Timer Autosave',
    'TIMER_REPORT': 'Timer Report',
    'TIMERREGION': 'Timer Region',
    'NDOF_MOTION': 'NDOF Motion',
    'NDOF_BUTTON_MENU': 'NDOF Menu',
    'NDOF_BUTTON_FIT': 'NDOF Fit',
    'NDOF_BUTTON_TOP': 'NDOF Top',
    'NDOF_BUTTON_BOTTOM': 'NDOF Bottom',
    'NDOF_BUTTON_LEFT': 'NDOF Left',
    'NDOF_BUTTON_RIGHT': 'NDOF Right',
    'NDOF_BUTTON_FRONT': 'NDOF Front',
    'NDOF_BUTTON_BACK': 'NDOF Back',
    'NDOF_BUTTON_ISO1': 'NDOF Isometric 1',
    'NDOF_BUTTON_ISO2': 'NDOF Isometric 2',
    'NDOF_BUTTON_ROLL_CW': 'NDOF Roll CW',
    'NDOF_BUTTON_ROLL_CCW': 'NDOF Roll CCW',
    'NDOF_BUTTON_SPIN_CW': 'NDOF Spin CW',
    'NDOF_BUTTON_SPIN_CCW': 'NDOF Spin CCW',
    'NDOF_BUTTON_TILT_CW': 'NDOF Tilt CW',
    'NDOF_BUTTON_TILT_CCW': 'NDOF Tilt CCW',
    'NDOF_BUTTON_ROTATE': 'NDOF Rotate',
    'NDOF_BUTTON_PANZOOM': 'NDOF Pan/Zoom',
    'NDOF_BUTTON_DOMINANT': 'NDOF Dominant',
    'NDOF_BUTTON_PLUS': 'NDOF Plus',
    'NDOF_BUTTON_MINUS': 'NDOF Minus',
    'NDOF_BUTTON_V1': 'NDOF View 1',
    'NDOF_BUTTON_V2': 'NDOF View 2',
    'NDOF_BUTTON_V3': 'NDOF View 3',
    'NDOF_BUTTON_1': 'NDOF Button 1',
    'NDOF_BUTTON_2': 'NDOF Button 2',
    'NDOF_BUTTON_3': 'NDOF Button 3',
    'NDOF_BUTTON_4': 'NDOF Button 4',
    'NDOF_BUTTON_5': 'NDOF Button 5',
    'NDOF_BUTTON_6': 'NDOF Button 6',
    'NDOF_BUTTON_7': 'NDOF Button 7',
    'NDOF_BUTTON_8': 'NDOF Button 8',
    'NDOF_BUTTON_9': 'NDOF Button 9',
    'NDOF_BUTTON_10': 'NDOF Button 10',
    'NDOF_BUTTON_A': 'NDOF Button A',
    'NDOF_BUTTON_B': 'NDOF Button B',
    'NDOF_BUTTON_C': 'NDOF Button C',
    'ACTIONZONE_AREA': 'ActionZone Area',
    'ACTIONZONE_REGION': 'ActionZone Region',
    'ACTIONZONE_FULLSCREEN': 'ActionZone Fullscreen',
    'XR_ACTION': 'XR Action'}
D_type_rev = {
    '': 'NONE',
    'None': 'NONE',
    'Left Mouse': 'LEFTMOUSE',
    'Middle Mouse': 'MIDDLEMOUSE',
    'Right Mouse': 'RIGHTMOUSE',
    'Button4 Mouse': 'BUTTON4MOUSE',
    'Button5 Mouse': 'BUTTON5MOUSE',
    'Button6 Mouse': 'BUTTON6MOUSE',
    'Button7 Mouse': 'BUTTON7MOUSE',
    'Pen': 'PEN',
    'Eraser': 'ERASER',
    'Mouse Move': 'MOUSEMOVE',
    'In-between Move': 'INBETWEEN_MOUSEMOVE',
    'Mouse/Trackpad Pan': 'TRACKPADPAN',
    'Mouse/Trackpad Zoom': 'TRACKPADZOOM',
    'Mouse/Trackpad Rotate': 'MOUSEROTATE',
    'Mouse/Trackpad Smart Zoom': 'MOUSESMARTZOOM',
    'Wheel Up': 'WHEELUPMOUSE',
    'Wheel Down': 'WHEELDOWNMOUSE',
    'Wheel In': 'WHEELINMOUSE',
    'Wheel Out': 'WHEELOUTMOUSE',
    'A': 'A',
    'B': 'B',
    'C': 'C',
    'D': 'D',
    'E': 'E',
    'F': 'F',
    'G': 'G',
    'H': 'H',
    'I': 'I',
    'J': 'J',
    'K': 'K',
    'L': 'L',
    'M': 'M',
    'N': 'N',
    'O': 'O',
    'P': 'P',
    'Q': 'Q',
    'R': 'R',
    'S': 'S',
    'T': 'T',
    'U': 'U',
    'V': 'V',
    'W': 'W',
    'X': 'X',
    'Y': 'Y',
    'Z': 'Z',
    '0': 'ZERO',
    '1': 'ONE',
    '2': 'TWO',
    '3': 'THREE',
    '4': 'FOUR',
    '5': 'FIVE',
    '6': 'SIX',
    '7': 'SEVEN',
    '8': 'EIGHT',
    '9': 'NINE',
    'Left Ctrl': 'LEFT_CTRL',
    'Left Alt': 'LEFT_ALT',
    'Left Shift': 'LEFT_SHIFT',
    'Right Alt': 'RIGHT_ALT',
    'Right Ctrl': 'RIGHT_CTRL',
    'Right Shift': 'RIGHT_SHIFT',
    'OS Key': 'OSKEY',
    'Application': 'APP',
    'Grless': 'GRLESS',
    'Esc': 'ESC',
    'Tab': 'TAB',
    'Return': 'RET',
    'Spacebar': 'SPACE',
    'Line Feed': 'LINE_FEED',
    'Backspace': 'BACK_SPACE',
    'Delete': 'DEL',
    ';': 'SEMI_COLON',
    '.': 'PERIOD',
    ',': 'COMMA',
    '"': 'QUOTE',
    '`': 'ACCENT_GRAVE',
    '-': 'MINUS',
    '+': 'PLUS',
    '/': 'SLASH',
    '\\': 'BACK_SLASH',
    '=': 'EQUAL',
    '[': 'LEFT_BRACKET',
    ']': 'RIGHT_BRACKET',
    'Left Arrow': 'LEFT_ARROW',
    'Down Arrow': 'DOWN_ARROW',
    'Right Arrow': 'RIGHT_ARROW',
    'Up Arrow': 'UP_ARROW',
    'Numpad 2': 'NUMPAD_2',
    'Numpad 4': 'NUMPAD_4',
    'Numpad 6': 'NUMPAD_6',
    'Numpad 8': 'NUMPAD_8',
    'Numpad 1': 'NUMPAD_1',
    'Numpad 3': 'NUMPAD_3',
    'Numpad 5': 'NUMPAD_5',
    'Numpad 7': 'NUMPAD_7',
    'Numpad 9': 'NUMPAD_9',
    'Numpad .': 'NUMPAD_PERIOD',
    'Numpad /': 'NUMPAD_SLASH',
    'Numpad *': 'NUMPAD_ASTERIX',
    'Numpad 0': 'NUMPAD_0',
    'Numpad -': 'NUMPAD_MINUS',
    'Numpad Enter': 'NUMPAD_ENTER',
    'Numpad +': 'NUMPAD_PLUS',
    'F1': 'F1',
    'F2': 'F2',
    'F3': 'F3',
    'F4': 'F4',
    'F5': 'F5',
    'F6': 'F6',
    'F7': 'F7',
    'F8': 'F8',
    'F9': 'F9',
    'F10': 'F10',
    'F11': 'F11',
    'F12': 'F12',
    'F13': 'F13',
    'F14': 'F14',
    'F15': 'F15',
    'F16': 'F16',
    'F17': 'F17',
    'F18': 'F18',
    'F19': 'F19',
    'F20': 'F20',
    'F21': 'F21',
    'F22': 'F22',
    'F23': 'F23',
    'F24': 'F24',
    'Pause': 'PAUSE',
    'Insert': 'INSERT',
    'Home': 'HOME',
    'Page Up': 'PAGE_UP',
    'Page Down': 'PAGE_DOWN',
    'End': 'END',
    'Media Play/Pause': 'MEDIA_PLAY',
    'Media Stop': 'MEDIA_STOP',
    'Media First': 'MEDIA_FIRST',
    'Media Last': 'MEDIA_LAST',
    'Text Input': 'TEXTINPUT',
    'Window Deactivate': 'WINDOW_DEACTIVATE',
    'Timer': 'TIMER',
    'Timer 0': 'TIMER0',
    'Timer 1': 'TIMER1',
    'Timer 2': 'TIMER2',
    'Timer Jobs': 'TIMER_JOBS',
    'Timer Autosave': 'TIMER_AUTOSAVE',
    'Timer Report': 'TIMER_REPORT',
    'Timer Region': 'TIMERREGION',
    'NDOF Motion': 'NDOF_MOTION',
    'NDOF Menu': 'NDOF_BUTTON_MENU',
    'NDOF Fit': 'NDOF_BUTTON_FIT',
    'NDOF Top': 'NDOF_BUTTON_TOP',
    'NDOF Bottom': 'NDOF_BUTTON_BOTTOM',
    'NDOF Left': 'NDOF_BUTTON_LEFT',
    'NDOF Right': 'NDOF_BUTTON_RIGHT',
    'NDOF Front': 'NDOF_BUTTON_FRONT',
    'NDOF Back': 'NDOF_BUTTON_BACK',
    'NDOF Isometric 1': 'NDOF_BUTTON_ISO1',
    'NDOF Isometric 2': 'NDOF_BUTTON_ISO2',
    'NDOF Roll CW': 'NDOF_BUTTON_ROLL_CW',
    'NDOF Roll CCW': 'NDOF_BUTTON_ROLL_CCW',
    'NDOF Spin CW': 'NDOF_BUTTON_SPIN_CW',
    'NDOF Spin CCW': 'NDOF_BUTTON_SPIN_CCW',
    'NDOF Tilt CW': 'NDOF_BUTTON_TILT_CW',
    'NDOF Tilt CCW': 'NDOF_BUTTON_TILT_CCW',
    'NDOF Rotate': 'NDOF_BUTTON_ROTATE',
    'NDOF Pan/Zoom': 'NDOF_BUTTON_PANZOOM',
    'NDOF Dominant': 'NDOF_BUTTON_DOMINANT',
    'NDOF Plus': 'NDOF_BUTTON_PLUS',
    'NDOF Minus': 'NDOF_BUTTON_MINUS',
    'NDOF View 1': 'NDOF_BUTTON_V1',
    'NDOF View 2': 'NDOF_BUTTON_V2',
    'NDOF View 3': 'NDOF_BUTTON_V3',
    'NDOF Button 1': 'NDOF_BUTTON_1',
    'NDOF Button 2': 'NDOF_BUTTON_2',
    'NDOF Button 3': 'NDOF_BUTTON_3',
    'NDOF Button 4': 'NDOF_BUTTON_4',
    'NDOF Button 5': 'NDOF_BUTTON_5',
    'NDOF Button 6': 'NDOF_BUTTON_6',
    'NDOF Button 7': 'NDOF_BUTTON_7',
    'NDOF Button 8': 'NDOF_BUTTON_8',
    'NDOF Button 9': 'NDOF_BUTTON_9',
    'NDOF Button 10': 'NDOF_BUTTON_10',
    'NDOF Button A': 'NDOF_BUTTON_A',
    'NDOF Button B': 'NDOF_BUTTON_B',
    'NDOF Button C': 'NDOF_BUTTON_C',
    'ActionZone Area': 'ACTIONZONE_AREA',
    'ActionZone Region': 'ACTIONZONE_REGION',
    'ActionZone Fullscreen': 'ACTIONZONE_FULLSCREEN',
    'XR Action': 'XR_ACTION'}
D_direction = {
    'ANY': 'Any',
    'NORTH': 'North',
    'NORTH_EAST': 'North-East',
    'EAST': 'East',
    'SOUTH_EAST': 'South-East',
    'SOUTH': 'South',
    'SOUTH_WEST': 'South-West',
    'WEST': 'West',
    'NORTH_WEST': 'North-West'}
D_direction_rev = {
    'Any': 'ANY',
    'North': 'NORTH',
    'North-East': 'NORTH_EAST',
    'East': 'EAST',
    'South-East': 'SOUTH_EAST',
    'South': 'SOUTH',
    'South-West': 'SOUTH_WEST',
    'West': 'WEST',
    'North-West': 'NORTH_WEST'}

# ▅▅▅  Setting                     ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
class P_BLOCK:
    __slots__ = (
        'w',
        'oo',
        'rim',
        'ti',
        'da',
        'hi',
    )
    def __init__(self, w, rna):
        self.w = w
        self.rim = BOX()
        self.ti = BLF(text=rna.name)
        e = D_ui_pref[rna.type](self, rna)
        e.ti.text = ""
        self.oo = [e]
        self.da = BLF(text=rna.description)
        blf_size(font_0, F[8])
        self.da.size = round(self.da.R_dimen_y())
        blf_size(font_0, F[9])

    def draw_box(self):
        m.bind_color_setting_bo()
        self.rim.draw()
        self.oo[0].draw_box()
    def draw_blf(self):
        blf_color(font_0, *P.color_font)
        blf_size(font_0, F[12])
        self.ti.draw_pos()
        blf_size(font_0, F[9])
        self.oo[0].draw_blf()
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.oo[0].dxy(x, y)
        self.da.dxy(x, y)

    def to_modal_default(self):
        self.w.U_modal = self.w.default_modal
    def to_modal(self, e):
        self.w.U_modal = e
    def I_modal_main(self, evt):
        if self.oo[0].is_inside(evt.mouse_region_x, evt.mouse_region_y):
            self.oo[0].inside(evt)
            return True
        return False

    def get_bo(self, L0, R0, T0):
        x = L0 + F[8]
        y = T0 - F[17]
        self.ti.xy(x, y)
        self.da.xy(x, y - F[13])
        R = R0 - F[6]
        T = T0 - F[7]
        o = self.oo[0]
        B = o.get_bo(R - F[16  if hasattr(o, "use_22") else 101], R, T - F[16], T) - F[7]
        self.hi = max(F[31] + self.da.size, T0 - B)
        self.rim.LRBT_upd(L0, R0, T0 - self.hi, T0)

    def upd_oo(self): self.oo[0].da_upd()
class P_BLOCK_GROUP(P_BLOCK):
    __slots__ = 'gaps'
    def __init__(self, w, rna, title, description, subtype, gaps=None):
        self.w = w
        self.rim = BOX()
        self.ti = BLF(text=title)
        oo = []
        self.oo = oo
        for rn, subty in zip(rna, subtype):
            e = D_ui_pref[rn.type](self, rn)
            e.ti.text = subty
            e.is_title_left = True
            oo.append(e)
        self.da = BLF(text=description)
        blf_size(font_0, F[8])
        self.da.size = round(self.da.R_dimen_y())
        blf_size(font_0, F[9])
        self.gaps = gaps

    def draw_box(self):
        m.bind_color_setting_bo()
        self.rim.draw()
        for e in self.oo:   e.draw_box()
    def draw_blf(self):
        blf_color(font_0, *P.color_font)
        blf_size(font_0, F[12])
        self.ti.draw_pos()
        blf_size(font_0, F[9])
        for e in self.oo:   e.draw_blf()
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        for e in self.oo:   e.dxy(x, y)
        self.da.dxy(x, y)

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        for e in self.oo:
            if e.is_inside(x, y):
                e.inside(evt)
                return True
        return False

    def get_bo(self, L0, R0, T0):
        x = L0 + F[8]
        y = T0 - F[17]
        self.ti.xy(x, y)
        self.da.xy(x, y - F[13])
        R = R0 - F[6]
        T = T0 - F[7]
        _1 = F[1]
        _16 = F[16]
        if self.gaps is None:
            for o in self.oo:
                T = o.get_bo(R - F[16  if hasattr(o, "use_22") else 101], R, T - _16, T) - _1
                B = T - _16
        else:
            for o, gap in zip(self.oo, self.gaps):
                T = o.get_bo(R - F[16  if hasattr(o, "use_22") else 101], R, T - _16, T) - F[gap]
                B = T - _16
        self.hi = max(F[31] + self.da.size, T0 - T - _1 + F[7])
        self.rim.LRBT_upd(L0, R0, T0 - self.hi, T0)

    def upd_oo(self):
        for e in self.oo:   e.da_upd()
class VAL_COLOR(P_BLOCK):
    __slots__ = 'array', 'min_max', 'bu_pick', 'oo_hex', 'oo_rgb', 'oo_hsv', 'float_hsv', 'str_hex'
    #
    def __init__(self, w, rna, color, fn_get, fn_set, min_max=(0,1)):
        self.w = w
        self.array = color
        self.min_max = min_max

        self.rim = BOX()
        self.float_hsv = [0.0, 0.0, 0.0]
        self.str_hex = ""

        rna_hsv = RNA_FLOAT_ARRAY('', 'HSV', (0,0,0), hard_min=min_max[0], hard_max=min_max[1], subtype="HSV")
        rna_hex = RNA_STR('', 'Gamma Corrected hexadecimal color value', '0')
        self.oo_rgb = self.R_ui_rgb(rna)
        self.oo_hsv = self.R_ui_hsv(rna_hsv)
        self.oo_hex = self.R_ui_hex(rna_hex)
        oo = [self.oo_rgb, self.oo_hsv, self.oo_hex]
        self.oo = oo
        rna_pick = RNA_BUTTON('', 'Color Picker', '⊕', self.bufn_pick)
        self.bu_pick = BUTTON(self, rna_pick)

    def draw_box(self):
        m.bind_color_setting_bo()
        self.rim.draw()
        self.oo_rgb.draw_box()
        self.oo_hsv.draw_box()
        self.oo_hex.draw_box()
        self.bu_pick.draw_box()
    def draw_blf(self):
        # /* 0bu_block_VAL_COLOR_draw_blf
        blf_color(font_0, *P.color_font)
        self.oo_rgb.draw_blf()
        self.oo_hsv.draw_blf()
        self.oo_hex.draw_blf()
        self.bu_pick.draw_blf()
        # */
    def dxy(self, x, y):
        # /* 0bu_block_VAL_COLOR_dxy
        self.rim.dxy_upd(x, y)
        self.oo_rgb.dxy(x, y)
        self.oo_hsv.dxy(x, y)
        self.oo_hex.dxy(x, y)
        self.bu_pick.dxy(x, y)
        # */

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        # /* 0bu_block_oo_rgb
        if self.oo_rgb.is_inside(x, y):
            self.oo_rgb.inside(evt)
            return True
        # */
        # <<< 1for (0bu_block_oo_rgb,, $[{'oo_rgb':'oo_hsv'}, {'oo_rgb':'oo_hex'}, {'oo_rgb':'bu_pick'}]$)
        if self.oo_hsv.is_inside(x, y):
            self.oo_hsv.inside(evt)
            return True
        if self.oo_hex.is_inside(x, y):
            self.oo_hex.inside(evt)
            return True
        if self.bu_pick.is_inside(x, y):
            self.bu_pick.inside(evt)
            return True
        # >>>

        return False

    def get_bo(self, L0, R0, T0):
        # /* 0bu_block_VAL_COLOR_get_bo
        _1 = F[1]
        _16 = F[16]
        dx = F[6]
        dy = F[7]
        R = R0 - dx
        T = T0 - dy
        bu_wi = F[101] - dx - _1 - _1
        L = R - bu_wi
        L1 = L0 + F[12] + dx
        R1 = L1 + bu_wi
        B = T - _16
        self.oo_rgb.get_bo(L, R, B, T)
        T = self.oo_hsv.get_bo(L1, R1, B, T) -_1 - _16 -_1
        B = T - _16
        self.oo_hex.get_bo(L1, R1, B, T)
        R1 += F[2]
        e = self.bu_pick
        B = e.get_bo(R1, R1 + _16 + _1, B, T) - dy
        e.offset_x += 1
        e.da.x += 1

        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)
        # */

    def bufn_pick(self):

        self.w.to_modal_pick(m.EVT.evt)
        return

    def R_ui_rgb(self, rna):
        # /* 0R_ui_rgb
        full_range = (0, rna.array_length)
        def fn_get(ind=None):
            if ind is None: return self.array
            if isinstance(ind, int): return self.array[ind]
            return self.array[ind[0] : ind[1]]
        def fn_set(v, undo_push=True, ind=None):
            if ind is None: ind = full_range
            if isinstance(ind, int):
                try:    self.array[ind] = v
                except: return
            else:
                i0 = ind[0]
                i1 = ind[1]
                try:    self.array[i0 : i1] = v
                except: return

            if undo_push is True:

                self.w.upd_by_rgb()

        o = FLOAT_ARRAY_SUBTI(self, rna, fn_get, fn_set)
        o.init(tuple_RGBA)
        o.ti.text = ""
        return o
        # */
    def R_ui_hsv(self, rna):
        # <<< 1copy (0R_ui_rgb, 0, ${
        #     'rna.array_length': '3',
        #     'self.array':       'self.float_hsv',
        #     '[ind] = v':        '[ind] = max(min(v, self.min_max[1]), self.min_max[0])',
        #     'i1 = ind[1]':      'i1 = ind[1]\n                _min, _max = self.min_max',
        #     '[i0 : i1] = v':    '[i0 : i1] = [max(min(v, _max), _min)  for v in v]',
        #     'by RGB':           'by HSV',
        #     'upd_by_rgb':       'upd_by_hsv',
        #     'tuple_RGBA':       'tuple_HSV',
        #     'o.ti.text = ""':   '',
        # }$)
        full_range = (0, 3)
        def fn_get(ind=None):
            if ind is None: return self.float_hsv
            if isinstance(ind, int): return self.float_hsv[ind]
            return self.float_hsv[ind[0] : ind[1]]
        def fn_set(v, undo_push=True, ind=None):
            if ind is None: ind = full_range
            if isinstance(ind, int):
                try:    self.float_hsv[ind] = max(min(v, self.min_max[1]), self.min_max[0])
                except: return
            else:
                i0 = ind[0]
                i1 = ind[1]
                _min, _max = self.min_max
                try:    self.float_hsv[i0 : i1] = [max(min(v, _max), _min)  for v in v]
                except: return

            if undo_push is True:

                self.w.upd_by_hsv()

        o = FLOAT_ARRAY_SUBTI(self, rna, fn_get, fn_set)
        o.init(tuple_HSV)
        
        return o
        # >>>
    def R_ui_hex(self, rna):
        def fn_set(v, undo_push=None):
            rgb = R_rgb_by_str(v)
            if rgb is not None: self.w.set_colors(*rgb)

        o = STRING_COLOR_HEX(self, rna, lambda: self.str_hex, fn_set, is_fix_long_text=False, offset_x_key=24)
        o.init(tuple_hex)
        o.tx_format = m.U_format_h
        return o

    def upd_oo(self):
        self.oo_rgb.da_upd()
        self.oo_hsv.da_upd()
        self.oo_hex.da_upd()
    #
    #
class VAL_GEORGBA(VAL_COLOR):
    __slots__ = 'oo_kf'
    def __init__(self, w, rna, color, fn_get, fn_set, min_max=(0,1)):
        super().__init__(w, rna, color, fn_get, fn_set, min_max=min_max)

        rna_kf0 = RNA_BUTTON('', 'Keyframe Button', '•', self.R_bufn_kf(0))
        rna_kf1 = RNA_BUTTON('', 'Keyframe Button', '•', self.R_bufn_kf(1))
        rna_kf2 = RNA_BUTTON('', 'Keyframe Button', '•', self.R_bufn_kf(2))
        rna_kf3 = RNA_BUTTON('', 'Keyframe Button', '•', self.R_bufn_kf(3))
        self.oo_kf = [
            BUTTONKF(self, rna_kf0, index=0),
            BUTTONKF(self, rna_kf1, index=1),
            BUTTONKF(self, rna_kf2, index=2),
            BUTTONKF(self, rna_kf3, index=3),
        ]

    def R_ui_rgb(self, rna):
        # <<< 1copy (0R_ui_rgb,, ${
        #     'rna.array_length'      :'4',
        #     'if undo_push is True:' :'if True:',
        #     'self.w.upd_by_rgb()'   :'self.w.upd_by_rgb() ;m.power_upd()',
        #     'FLOAT_ARRAY_SUBTI'     :'FLOAT_ARRAY_GEO_RGBA',
        # }$)
        full_range = (0, 4)
        def fn_get(ind=None):
            if ind is None: return self.array
            if isinstance(ind, int): return self.array[ind]
            return self.array[ind[0] : ind[1]]
        def fn_set(v, undo_push=True, ind=None):
            if ind is None: ind = full_range
            if isinstance(ind, int):
                try:    self.array[ind] = v
                except: return
            else:
                i0 = ind[0]
                i1 = ind[1]
                try:    self.array[i0 : i1] = v
                except: return

            if True:

                self.w.upd_by_rgb() ;m.power_upd()

        o = FLOAT_ARRAY_GEO_RGBA(self, rna, fn_get, fn_set)
        o.init(tuple_RGBA)
        o.ti.text = ""
        return o
        # >>>
    def R_ui_hsv(self, rna):
        # <<< 1copy (0R_ui_rgb, 0, ${
        #     'rna.array_length': '3',
        #     'self.array':       'self.float_hsv',
        #     '[ind] = v':        '[ind] = max(min(v, self.min_max[1]), self.min_max[0])',
        #     'i1 = ind[1]':      'i1 = ind[1]\n                _min, _max = self.min_max',
        #     '[i0 : i1] = v':    '[i0 : i1] = [max(min(v, _max), _min)  for v in v]',
        #     'by RGB':           'by HSV',
        #     'tuple_RGBA':       'tuple_HSV',
        #     'o.ti.text = ""':   '',
        #     'if undo_push is True:' :'if True:',
        #     'self.w.upd_by_rgb()'   :'self.w.upd_by_hsv() ;m.power_upd()',
        # }$)
        full_range = (0, 3)
        def fn_get(ind=None):
            if ind is None: return self.float_hsv
            if isinstance(ind, int): return self.float_hsv[ind]
            return self.float_hsv[ind[0] : ind[1]]
        def fn_set(v, undo_push=True, ind=None):
            if ind is None: ind = full_range
            if isinstance(ind, int):
                try:    self.float_hsv[ind] = max(min(v, self.min_max[1]), self.min_max[0])
                except: return
            else:
                i0 = ind[0]
                i1 = ind[1]
                _min, _max = self.min_max
                try:    self.float_hsv[i0 : i1] = [max(min(v, _max), _min)  for v in v]
                except: return

            if True:

                self.w.upd_by_hsv() ;m.power_upd()

        o = FLOAT_ARRAY_SUBTI(self, rna, fn_get, fn_set)
        o.init(tuple_HSV)
        
        return o
        # >>>
    def R_ui_hex(self, rna):
        def fn_set(v, undo_push=None):
            rgb = R_rgb_by_str(v)
            if rgb is not None:
                self.w.set_colors(*rgb)
                m.power_upd()

        o = STRING_COLOR_HEX(self, rna, lambda: self.str_hex, fn_set, is_fix_long_text=False, offset_x_key=24)
        o.init(tuple_hex)
        o.tx_format = m.U_format_h
        return o

    def R_bufn_kf(self, index):
        def bufn_kf():

            ww = self.w.w
            fcurves = ww.R_fcurves()
            path = ww.R_dp()
            obj = ww.R_obj()
            if fcurves:
                v = ww.R_bpy_value()
                r = bpy.context.scene.frame_current

                fc = fcurves.find(path, index=index)
                if fc:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if fc.evaluate(r) == v[index]:
                            obj.keyframe_insert(path, index=index)
                        else:
                            obj.keyframe_insert(path, index=index)
                    else:
                        if fc.evaluate(r) == v[index]:
                            obj.keyframe_delete(path, index=index)
                        else:
                            obj.keyframe_delete(path, index=index)
                else:
                    obj.keyframe_insert(path, index=index)
            else:
                obj.keyframe_insert(path, index=index)
            self.upd_keyframe()
            m.undo_str = f'[Color Panel] Keyframe event'
            m.undo_push()
        return bufn_kf

    def R_rm_data(self, index):
        if index == None: return []
        ww = self.w.w
        fcurves = ww.R_fcurves()
        path = ww.R_dp()
        obj = ww.R_obj()
        li = []
        has_kf = False
        is_fit = False
        is_match = False
        if fcurves:
            v = ww.R_bpy_value()
            r = bpy.context.scene.frame_current

            fc = fcurves.find(path, index=index)
            if fc:
                has_kf = True
                kp = fc.keyframe_points
                ind_E = len(kp) -1
                if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                    if fc.evaluate(r) == v[index]:  is_match = True
                else:
                    is_fit = True
                    if fc.evaluate(r) == v[index]:  is_match = True

        if has_kf == False:
            li.append({9: lambda: self.insert_keyframe(index), 0: "Insert Keyframe"})
            li.append({9: lambda: self.delete_keyframe(index), 0: "Delete Keyframe", 1: 0})
            li.append({9: lambda: self.clear_keyframe(index), 0: "Clear Keyframe", 1: 0})
        else:
            if is_fit:
                if is_match:
                    li.append({9: lambda: self.insert_keyframe(index), 0: "Insert Keyframe", 1: 0})
                    li.append({9: lambda: self.delete_keyframe(index), 0: "Delete Keyframe"})
                    li.append({9: lambda: self.clear_keyframe(index), 0: "Clear Keyframe"})
                else:
                    li.append({9: lambda: self.insert_keyframe(index), 0: "Replace Keyframe"})
                    li.append({9: lambda: self.delete_keyframe(index), 0: "Delete Keyframe"})
                    li.append({9: lambda: self.clear_keyframe(index), 0: "Clear Keyframe"})
            else:
                li.append({9: lambda: self.insert_keyframe(index), 0: "Insert Keyframe"})
                li.append({9: lambda: self.delete_keyframe(index), 0: "Delete Keyframe", 1: 0})
                li.append({9: lambda: self.clear_keyframe(index), 0: "Clear Keyframe"})

        return li

    def insert_keyframe(self, index, undo_push=True):
        try:
            ww = self.w.w
            path = ww.R_dp()
            obj = ww.R_obj()
            obj.keyframe_insert(path, index=index)
            self.upd_keyframe()
            if undo_push:
                m.undo_str = f'[Color Panel] Keyframe event'
                m.undo_push()
        except: pass
    def delete_keyframe(self, index, undo_push=True):
        try:
            ww = self.w.w
            path = ww.R_dp()
            obj = ww.R_obj()
            obj.keyframe_delete(path, index=index)
            self.upd_keyframe()
            if undo_push:
                m.undo_str = f'[Color Panel] Keyframe event'
                m.undo_push()
        except: pass
    def clear_keyframe(self, index, undo_push=True):
        try:
            ww = self.w.w
            path = ww.R_dp()
            obj = ww.R_obj()
            fcurves = ww.R_fcurves()
            if not fcurves: return
            fc = fcurves.find(path, index=index)
            if not fc: return
            fcurves.remove(fc)
            self.upd_keyframe()
            if undo_push:
                m.undo_str = f'[Color Panel] Keyframe event'
                m.undo_push()
        except: pass

    def draw_blf(self):
        # <<< 1copy (0bu_block_VAL_COLOR_draw_blf,, $$)
        blf_color(font_0, *P.color_font)
        self.oo_rgb.draw_blf()
        self.oo_hsv.draw_blf()
        self.oo_hex.draw_blf()
        self.bu_pick.draw_blf()
        # >>>
        for e in self.oo_kf: e.da.draw_color_pos()
    def dxy(self, x, y):
        # <<< 1copy (0bu_block_VAL_COLOR_dxy,, $$)
        self.rim.dxy_upd(x, y)
        self.oo_rgb.dxy(x, y)
        self.oo_hsv.dxy(x, y)
        self.oo_hex.dxy(x, y)
        self.bu_pick.dxy(x, y)
        # >>>
        for e in self.oo_kf:
            e.rim.dxy(x, y)
            e.da.dxy(x, y)
    def get_bo(self, L0, R0, T0):
        # <<< 1copy (0bu_block_VAL_COLOR_get_bo,, $$)
        _1 = F[1]
        _16 = F[16]
        dx = F[6]
        dy = F[7]
        R = R0 - dx
        T = T0 - dy
        bu_wi = F[101] - dx - _1 - _1
        L = R - bu_wi
        L1 = L0 + F[12] + dx
        R1 = L1 + bu_wi
        B = T - _16
        self.oo_rgb.get_bo(L, R, B, T)
        T = self.oo_hsv.get_bo(L1, R1, B, T) -_1 - _16 -_1
        B = T - _16
        self.oo_hex.get_bo(L1, R1, B, T)
        R1 += F[2]
        e = self.bu_pick
        B = e.get_bo(R1, R1 + _16 + _1, B, T) - dy
        e.offset_x += 1
        e.da.x += 1

        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)
        # >>>
        x = L - F[24]
        L = x - F[4]
        R = L + F[17]
        for e, o, rim in zip(self.oo_kf, self.oo_rgb.da, self.oo_rgb.rim):
            e.rim.LRBT(L, R, rim.B, rim.T)
            e.da.xy(x, o.y)
        self.upd_keyframe()
    def upd_keyframe(self):

        ww = self.w.w
        fcurves = ww.R_fcurves()
        if fcurves:
            v = ww.R_bpy_value()
            path = ww.R_dp()
            r = bpy.context.scene.frame_current

            for ind, e in enumerate(self.oo_kf):
                fc = fcurves.find(path, index=ind)
                if fc:
                    kp = fc.keyframe_points
                    ind_E = len(kp) -1
                    if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                        if fc.evaluate(r) == v[ind]:
                            e.da.color_tx(P.color_bu_kf_green, "◇")
                        else:
                            e.da.color_tx(P.color_bu_kf_orange, "◇")
                    else:
                        if fc.evaluate(r) == v[ind]:
                            e.da.color_tx(P.color_bu_kf_yellow, "◆")
                        else:
                            e.da.color_tx(P.color_bu_kf_orange, "◆")
                else:
                    e.da.color_tx(P.color_font, "•")
        else:
            for e in self.oo_kf:
                e.da.color_tx(P.color_font, "•")

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        oo_kf = self.oo_kf
        # <<< 1for (0bu_block_oo_rgb,, $[
        #     {'oo_rgb':'oo_rgb'},
        #     {'oo_rgb':'oo_hsv'},
        #     {'oo_rgb':'oo_hex'},
        #     {'oo_rgb':'bu_pick'},
        #     {'oo_rgb':'oo_kf[0]'},
        #     {'oo_rgb':'oo_kf[1]'},
        #     {'oo_rgb':'oo_kf[2]'},
        #     {'oo_rgb':'oo_kf[3]'},
        # ]$)
        if self.oo_rgb.is_inside(x, y):
            self.oo_rgb.inside(evt)
            return True
        if self.oo_hsv.is_inside(x, y):
            self.oo_hsv.inside(evt)
            return True
        if self.oo_hex.is_inside(x, y):
            self.oo_hex.inside(evt)
            return True
        if self.bu_pick.is_inside(x, y):
            self.bu_pick.inside(evt)
            return True
        if self.oo_kf[0].is_inside(x, y):
            self.oo_kf[0].inside(evt)
            return True
        if self.oo_kf[1].is_inside(x, y):
            self.oo_kf[1].inside(evt)
            return True
        if self.oo_kf[2].is_inside(x, y):
            self.oo_kf[2].inside(evt)
            return True
        if self.oo_kf[3].is_inside(x, y):
            self.oo_kf[3].inside(evt)
            return True
        # >>>

    def upd_oo(self):
        self.oo_rgb.da_upd()
        self.oo_hsv.da_upd()
        self.oo_hex.da_upd()
        self.upd_keyframe()
    #
    #

class KM(P_BLOCK_GROUP):
    __slots__ = 'array', 'last_data', 'rna'
    def __init__(self, w, rna):
        self.w = w
        self.rim = BOX()
        self.ti = BLF(text=rna.name)
        self.da = BLF()
        self.array = getattr(P, rna.identifier)
        self.last_data = [None]
        self.rna = rna

        # /* 0bu_block_KM_init
        edit_comb_1 = BUTTON(self, RNA_BUTTON("Edit Combination 1", self.R_description_button, "Edit Combination 1", self.bufn_edit_comb_1), rm_data=(
            {9: self.rm_reset_type_1, 0: "Reset"},
            {9: self.rm_reset_all, 0: "Reset Properties for both keys"},
        ))
        edit_comb_1.is_title_left = False
        edit_comb_1.ti.text = "None"
        value_1 = STRING_ENUM(self, rna_km_value, self.fn_get_value_1, self.fn_set_value_1)
        exact_1 = BOOLEAN(self, rna_km_exact, self.fn_get_exact_1, self.fn_set_exact_1)
        exact_1.is_title_left = True
        duration_1 = FLOAT_SUBTI(self, rna_km_duration, self.fn_get_duration_1, self.fn_set_duration_1)
        duration_1.init(tuple_sec)
        repeat_1 = BOOLEAN(self, rna_km_repeat, self.fn_get_repeat_1, self.fn_set_repeat_1)
        repeat_1.is_title_left = True
        # */
        # <<< 1copy (0bu_block_KM_init,, ${'1':'2'}$)
        edit_comb_2 = BUTTON(self, RNA_BUTTON("Edit Combination 2", self.R_description_button, "Edit Combination 2", self.bufn_edit_comb_2), rm_data=(
            {9: self.rm_reset_type_2, 0: "Reset"},
            {9: self.rm_reset_all, 0: "Reset Properties for both keys"},
        ))
        edit_comb_2.is_title_left = False
        edit_comb_2.ti.text = "None"
        value_2 = STRING_ENUM(self, rna_km_value, self.fn_get_value_2, self.fn_set_value_2)
        exact_2 = BOOLEAN(self, rna_km_exact, self.fn_get_exact_2, self.fn_set_exact_2)
        exact_2.is_title_left = True
        duration_2 = FLOAT_SUBTI(self, rna_km_duration, self.fn_get_duration_2, self.fn_set_duration_2)
        duration_2.init(tuple_sec)
        repeat_2 = BOOLEAN(self, rna_km_repeat, self.fn_get_repeat_2, self.fn_set_repeat_2)
        repeat_2.is_title_left = True
        # >>>
        self.oo = [
            # /* 0bu_block_KM_init2
            edit_comb_1,
            value_1,
            exact_1,
            duration_1,
            repeat_1,
            # */
            # <<< 1copy (0bu_block_KM_init2,, ${'1':'2'}$)
            edit_comb_2,
            value_2,
            exact_2,
            duration_2,
            repeat_2,
            # >>>
        ]

    def get_bo(self, L0, R0, T0):
        x = L0 + F[8]
        y = T0 - F[17]
        self.ti.xy(x, y)

        _6 = F[6]
        _16 = F[16]
        _93 = F[93]
        oo = self.oo
        R = x + _93
        T = y - F[8]
        B = T - _16
        oo[0].get_bo(x, R, B, T)

        L3 = R + _6
        R3 = L3 + _93
        T = B - _6
        B = T - _16
        oo[1].get_bo(L3, R3, B, T)
        RR = R0 - _6
        L8 = RR - _16
        oo[2].get_bo(L8, RR, B, T)

        T = B - F[2]
        B = T - _16
        oo[3].get_bo(L3, R3, B, T)
        oo[4].get_bo(L8, RR, B, T)
        #
        T = B - F[8]
        B = T - _16
        oo[5].get_bo(x, R, B, T)
        T = B - _6
        B = T - _16
        oo[6].get_bo(L3, R3, B, T)
        oo[7].get_bo(L8, RR, B, T)
        T = B - F[2]
        B = T - _16
        oo[8].get_bo(L3, R3, B, T)
        oo[9].get_bo(L8, RR, B, T)

        B -= F[20]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def fn_get_value_1(self):
        return self.oo[1].da.name
    def fn_set_value_1(self, v, undo_push=True):
        # /* 0bu_block_fn_set_value_1
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[4]
        try:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111111111111100000000 | dict_value[key_title_to_value[v]  if v in key_title_to_value else v])
        except:
            v = self.rna.default_array[4] & 0b11111111
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111111111111100000000 | v)
            v = "DEFAULT"
        array[4] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Value1= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # */
    def fn_get_value_2(self):
        return self.oo[6].da.name
    def fn_set_value_2(self, v, undo_push=True):
        # /* 0bu_block_fn_set_value_2
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[4]
        try:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111110000000011111111 | dict_value[key_title_to_value[v]  if v in key_title_to_value else v] << 8)
        except:
            v = self.rna.default_array[4] & 0b1111111100000000
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111110000000011111111 | v)
            v = "DEFAULT"
        array[4] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Value2= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # */
    def fn_get_exact_1(self):
        return self.oo[2].da.name
    def fn_set_exact_1(self, v, undo_push=True):
        # /* 0bu_block_fn_set_exact_1
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[4]
        if v is None:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111110111111111111111111 | (self.rna.default_array[4] & 0b1000000000000000000))
            v = "DEFAULT"
        else:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111110111111111111111111 | (1 if v == True else 0) << 18)
        array[4] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Exact1= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # */
    def fn_get_exact_2(self):
        return self.oo[7].da.name
    def fn_set_exact_2(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_exact_1,, ${
        #     '0b11111111111110111111111111111111': '0b11111111111101111111111111111111',
        #     '0b1000000000000000000': '0b10000000000000000000',
        #     '<< 18': '<< 19',
        #     'Exact1': 'Exact2',
        # }$)
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[4]
        if v is None:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111101111111111111111111 | (self.rna.default_array[4] & 0b10000000000000000000))
            v = "DEFAULT"
        else:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111101111111111111111111 | (1 if v == True else 0) << 19)
        array[4] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Exact2= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
    def fn_get_duration_1(self):
        # /* 0bu_block_fn_get_duration_1
        return K[f'{self.rna.identifier[5:]}0'].hold
        # */
    def fn_set_duration_1(self, v, undo_push=True):
        # /* 0bu_block_fn_set_duration_1
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[1]
        try:
            e = struct_pack('!f', min(max(0.0, v), 9.0))
            new_v = R_sign32(e[3] | e[2] << 8 | e[1] << 16 | e[0] << 24)
        except:
            new_v = self.rna.default_array[1]
            v = "DEFAULT"
        array[1] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Duration1= {v}'
            def old_fn():
                getattr(P, identifier)[1] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[1] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # */
    def fn_get_duration_2(self):
        # <<< 1copy (0bu_block_fn_get_duration_1,, ${'0':'1'}$)
        return K[f'{self.rna.identifier[5:]}1'].hold
        # >>>
    def fn_set_duration_2(self, v, undo_push=True):
        # /* 0bu_block_fn_set_duration_2
        # <<< 1copy (0bu_block_fn_set_duration_1,, ${
        #     'array[1]': 'array[3]',
        #     'default_array[1]': 'default_array[3]',
        #     'Duration1': 'Duration2',
        #     'identifier)[1]': 'identifier)[3]',
        # }$)
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[3]
        try:
            e = struct_pack('!f', min(max(0.0, v), 9.0))
            new_v = R_sign32(e[3] | e[2] << 8 | e[1] << 16 | e[0] << 24)
        except:
            new_v = self.rna.default_array[3]
            v = "DEFAULT"
        array[3] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Duration2= {v}'
            def old_fn():
                getattr(P, identifier)[3] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[3] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
        # */
    def fn_get_repeat_1(self):
        return self.oo[4].da.name
    def fn_set_repeat_1(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_exact_1,, ${
        #     '0b11111111111110111111111111111111': '0b11111111111111101111111111111111',
        #     '0b1000000000000000000': '0b10000000000000000',
        #     '<< 18': '<< 16',
        #     'Exact1': 'Repeat1',
        # }$)
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[4]
        if v is None:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111101111111111111111 | (self.rna.default_array[4] & 0b10000000000000000))
            v = "DEFAULT"
        else:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111101111111111111111 | (1 if v == True else 0) << 16)
        array[4] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Repeat1= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
    def fn_get_repeat_2(self):
        return self.oo[9].da.name
    def fn_set_repeat_2(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_exact_1,, ${
        #     '0b11111111111110111111111111111111': '0b11111111111111011111111111111111',
        #     '0b1000000000000000000': '0b100000000000000000',
        #     '<< 18': '<< 17',
        #     'Exact1': 'Repeat2',
        # }$)
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[4]
        if v is None:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111011111111111111111 | (self.rna.default_array[4] & 0b100000000000000000))
            v = "DEFAULT"
        else:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111011111111111111111 | (1 if v == True else 0) << 17)
        array[4] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Repeat2= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>

    def bufn_edit_comb_1(self):
        KEY_ED(self.oo[0], m.EVT.evt)
    def bufn_edit_comb_2(self):
        KEY_ED(self.oo[5], m.EVT.evt)
    def write_type(self, lis, bu_oo):
        ind = 0  if self.oo.index(bu_oo) == 0 else 2
        for r in range(len(lis), 4):    lis.append(False)

        k1, k2, k3, k4 = lis
        v = dict_type[k1]  if k1 in dict_type else non_release[k1]
        v |= (dict_type[k2]  if k2 in dict_type else non_release[k2]) << 8
        v |= (dict_type[k3]  if k3 in dict_type else non_release[k3]) << 16
        v |= (dict_type[k4]  if k4 in dict_type else non_release[k4]) << 24
        v = R_sign32(v)

        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[ind]
        array[ind] = v
        m.get_K_by(identifier)
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Combination {1 if ind == 0 else 2}'
        def old_fn():
            getattr(P, identifier)[ind] = old_v
            m.get_K_by(identifier)
        def new_fn():
            getattr(P, identifier)[ind] = v
            m.get_K_by(identifier)
        m.undo_push(old_fn, new_fn)
        m.refresh()

    def R_description_button(self):
        s = "Supported Keys :\n"
        for e in type_dict: s += f"    {e}\n"
        return s

    def rm_reset_type_1(self):
        # /* 0bu_block_rm_reset_type_1
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[0]
        new_v = self.rna.default_array[0]
        array[0] = new_v
        m.get_K_by(identifier)
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Reset Combination 1'
        def old_fn():
            getattr(P, identifier)[0] = old_v
            m.get_K_by(identifier)
        def new_fn():
            getattr(P, identifier)[0] = new_v
            m.get_K_by(identifier)
        m.undo_push(old_fn, new_fn)
        m.refresh()
        # */
    def rm_reset_type_2(self):
        # <<< 1copy (0bu_block_rm_reset_type_1,, ${'0':'2', '1':'2'}$)
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = array[2]
        new_v = self.rna.default_array[2]
        array[2] = new_v
        m.get_K_by(identifier)
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Reset Combination 2'
        def old_fn():
            getattr(P, identifier)[2] = old_v
            m.get_K_by(identifier)
        def new_fn():
            getattr(P, identifier)[2] = new_v
            m.get_K_by(identifier)
        m.undo_push(old_fn, new_fn)
        m.refresh()
        # >>>
    def rm_reset_all(self):
        identifier = self.rna.identifier
        array = getattr(P, identifier)
        old_v = tuple(array)
        new_v = self.rna.default_array
        array[:] = new_v
        m.get_K_by(identifier)
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Reset Properties'
        def old_fn():
            getattr(P, identifier)[:] = old_v
            m.get_K_by(identifier)
        def new_fn():
            getattr(P, identifier)[:] = new_v
            m.get_K_by(identifier)
        m.undo_push(old_fn, new_fn)
        m.refresh()

    def upd_oo(self):

        if any((e != o  for e, o in zip(self.array, self.last_data))):
            self.last_data = tuple(self.array)

            oo = self.oo
            s = self.rna.identifier[5:]
            km0 = K[f'{s}0']
            km1 = K[f'{s}1']

            oo[0].ti.text = R_tx_comb(km0)
            oo[5].ti.text = R_tx_comb(km1)
            oo[1].set_da(key_value_to_title[km0.value])
            oo[6].set_da(key_value_to_title[km1.value])
            oo[3].set_da(km0.hold)
            oo[8].set_da(km1.hold)
            oo[2].set_da(km0.ll is not None)
            oo[7].set_da(km1.ll is not None)
            oo[4].set_da(km0.repeat)
            oo[9].set_da(km1.repeat)
            # /* 0bu_block_KM_upd_oo
            if oo[1].da.name in time_keys:
                if oo[3].is_enable is False:    oo[3].enable()
            else:
                if oo[3].is_enable is True:     oo[3].disable()
            # */
            # <<< 1copy (0bu_block_KM_upd_oo,, ${'1':'6', '3':'8'}$)
            if oo[6].da.name in time_keys:
                if oo[8].is_enable is False:    oo[8].enable()
            else:
                if oo[8].is_enable is True:     oo[8].disable()
            # >>>
class KM2(KM):
    __slots__ = 'array2', 'last_data2', 'rna2'
    def __init__(self, w, rna, rna2):
        super().__init__(w, rna)
        self.array2 = getattr(P, rna2.identifier)
        self.last_data2 = [None]
        self.rna2 = rna2
        oo = self.oo
        oo[1].ti.text = oo[6].ti.text = "Start / End Value"

        # /* 0bu_block_KM2_init
        value_e1 = STRING_ENUM(self, rna_km_value, self.fn_get_value_e1, self.fn_set_value_e1)
        value_e1.ti.text = ""
        duration_e1 = FLOAT(self, rna_km_duration, self.fn_get_duration_e1, self.fn_set_duration_e1)
        duration_e1.ti.text = ""
        oo.append(value_e1)
        oo.append(duration_e1)
        # */
        # <<< 1copy (0bu_block_KM2_init,, ${'1':'2'}$)
        value_e2 = STRING_ENUM(self, rna_km_value, self.fn_get_value_e2, self.fn_set_value_e2)
        value_e2.ti.text = ""
        duration_e2 = FLOAT(self, rna_km_duration, self.fn_get_duration_e2, self.fn_set_duration_e2)
        duration_e2.ti.text = ""
        oo.append(value_e2)
        oo.append(duration_e2)
        # >>>

    def get_bo(self, L0, R0, T0):
        x = L0 + F[8]
        y = T0 - F[17]
        self.ti.xy(x, y)

        _2 = F[2]
        _6 = F[6]
        _16 = F[16]
        _93 = F[93]
        oo = self.oo
        R = x + _93
        T = y - F[8]
        B = T - _16
        oo[0].get_bo(x, R, B, T)

        L3 = R - F[10]
        R3 = L3 + _93
        L4 = R3 + _2
        R4 = L4 + _93
        T = B - _6
        B = T - _16
        oo[1].get_bo(L3, R3, B, T)
        oo[10].get_bo(L4, R4, B, T)
        RR = R0 - _6
        L8 = RR - _16
        oo[2].get_bo(L8, RR, B, T)

        T = B - _2
        B = T - _16
        oo[3].get_bo(L3, R3, B, T)
        oo[11].get_bo(L4, R4, B, T)
        oo[4].get_bo(L8, RR, B, T)
        #
        T = B - F[8]
        B = T - _16
        oo[5].get_bo(x, R, B, T)
        T = B - _6
        B = T - _16
        oo[6].get_bo(L3, R3, B, T)
        oo[12].get_bo(L4, R4, B, T)
        oo[7].get_bo(L8, RR, B, T)
        T = B - _2
        B = T - _16
        oo[8].get_bo(L3, R3, B, T)
        oo[13].get_bo(L4, R4, B, T)
        oo[9].get_bo(L8, RR, B, T)

        B -= F[20]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def fn_get_value_e1(self):
        return self.oo[10].da.name
    def fn_set_value_e1(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_value_1,, ${'rna':'rna2', 'Value1':'End Value1'}$)
        identifier = self.rna2.identifier
        array = getattr(P, identifier)
        old_v = array[4]
        try:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111111111111100000000 | dict_value[key_title_to_value[v]  if v in key_title_to_value else v])
        except:
            v = self.rna2.default_array[4] & 0b11111111
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111111111111100000000 | v)
            v = "DEFAULT"
        array[4] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - End Value1= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
    def fn_get_value_e2(self):
        return self.oo[12].da.name
    def fn_set_value_e2(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_value_2,, ${'rna':'rna2', 'Value2':'End Value2'}$)
        identifier = self.rna2.identifier
        array = getattr(P, identifier)
        old_v = array[4]
        try:
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111110000000011111111 | dict_value[key_title_to_value[v]  if v in key_title_to_value else v] << 8)
        except:
            v = self.rna2.default_array[4] & 0b1111111100000000
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111110000000011111111 | v)
            v = "DEFAULT"
        array[4] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - End Value2= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
    def fn_get_duration_e1(self):
        return self.oo[11].da.name
    def fn_set_duration_e1(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_duration_1,, ${'rna':'rna2', 'Duration1':'End Duration1'}$)
        identifier = self.rna2.identifier
        array = getattr(P, identifier)
        old_v = array[1]
        try:
            e = struct_pack('!f', min(max(0.0, v), 9.0))
            new_v = R_sign32(e[3] | e[2] << 8 | e[1] << 16 | e[0] << 24)
        except:
            new_v = self.rna2.default_array[1]
            v = "DEFAULT"
        array[1] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - End Duration1= {v}'
            def old_fn():
                getattr(P, identifier)[1] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[1] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
    def fn_get_duration_e2(self):
        return self.oo[13].da.name
    def fn_set_duration_e2(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_duration_2,, ${'rna':'rna2', 'Duration2':'End Duration2'}$)
        # <<< 1copy (0bu_block_fn_set_duration_1,, ${
        #     'array[1]': 'array[3]',
        #     'default_array[1]': 'default_array[3]',
        #     'Duration1': 'End Duration2',
        #     'identifier)[1]': 'identifier)[3]',
        # }$)
        identifier = self.rna2.identifier
        array = getattr(P, identifier)
        old_v = array[3]
        try:
            e = struct_pack('!f', min(max(0.0, v), 9.0))
            new_v = R_sign32(e[3] | e[2] << 8 | e[1] << 16 | e[0] << 24)
        except:
            new_v = self.rna2.default_array[3]
            v = "DEFAULT"
        array[3] = new_v
        m.get_K_by(identifier)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - End Duration2= {v}'
            def old_fn():
                getattr(P, identifier)[3] = old_v
                m.get_K_by(identifier)
            def new_fn():
                getattr(P, identifier)[3] = new_v
                m.get_K_by(identifier)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
        # >>>

    def fn_set_exact_1(self, v, undo_push=True):
        # /* 0bu_block_fn_set_exact_e1
        identifier = self.rna.identifier
        identifier2 = self.rna2.identifier
        array = getattr(P, identifier)
        array2 = getattr(P, identifier2)
        old_v = array[4]
        old_v2 = array2[4]
        if v is None:
            i = self.rna.default_array[4] & 0b1000000000000000000
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111110111111111111111111 | i)
            new_v2 = R_sign32(R_unsign32(old_v2) & 0b11111111111110111111111111111111 | i)
            v = "DEFAULT"
        else:
            i = (1 if v == True else 0) << 18
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111110111111111111111111 | i)
            new_v2 = R_sign32(R_unsign32(old_v2) & 0b11111111111110111111111111111111 | i)
        array[4] = new_v
        array2[4] = new_v2
        m.get_K_by(identifier)
        m.get_K_by(identifier2)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Exact1= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                getattr(P, identifier2)[4] = old_v2
                m.get_K_by(identifier)
                m.get_K_by(identifier2)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                getattr(P, identifier2)[4] = new_v2
                m.get_K_by(identifier)
                m.get_K_by(identifier2)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # */
    def fn_set_exact_2(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_exact_e1,, ${
        #     '0b11111111111110111111111111111111': '0b11111111111101111111111111111111',
        #     '0b1000000000000000000': '0b10000000000000000000',
        #     '<< 18': '<< 19',
        #     'Exact1': 'Exact2',
        # }$)
        identifier = self.rna.identifier
        identifier2 = self.rna2.identifier
        array = getattr(P, identifier)
        array2 = getattr(P, identifier2)
        old_v = array[4]
        old_v2 = array2[4]
        if v is None:
            i = self.rna.default_array[4] & 0b10000000000000000000
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111101111111111111111111 | i)
            new_v2 = R_sign32(R_unsign32(old_v2) & 0b11111111111101111111111111111111 | i)
            v = "DEFAULT"
        else:
            i = (1 if v == True else 0) << 19
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111101111111111111111111 | i)
            new_v2 = R_sign32(R_unsign32(old_v2) & 0b11111111111101111111111111111111 | i)
        array[4] = new_v
        array2[4] = new_v2
        m.get_K_by(identifier)
        m.get_K_by(identifier2)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Exact2= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                getattr(P, identifier2)[4] = old_v2
                m.get_K_by(identifier)
                m.get_K_by(identifier2)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                getattr(P, identifier2)[4] = new_v2
                m.get_K_by(identifier)
                m.get_K_by(identifier2)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
    def fn_set_repeat_1(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_exact_e1,, ${
        #     '0b11111111111110111111111111111111': '0b11111111111111101111111111111111',
        #     '0b1000000000000000000': '0b10000000000000000',
        #     '<< 18': '<< 16',
        #     'Exact1': 'Repeat1',
        # }$)
        identifier = self.rna.identifier
        identifier2 = self.rna2.identifier
        array = getattr(P, identifier)
        array2 = getattr(P, identifier2)
        old_v = array[4]
        old_v2 = array2[4]
        if v is None:
            i = self.rna.default_array[4] & 0b10000000000000000
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111101111111111111111 | i)
            new_v2 = R_sign32(R_unsign32(old_v2) & 0b11111111111111101111111111111111 | i)
            v = "DEFAULT"
        else:
            i = (1 if v == True else 0) << 16
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111101111111111111111 | i)
            new_v2 = R_sign32(R_unsign32(old_v2) & 0b11111111111111101111111111111111 | i)
        array[4] = new_v
        array2[4] = new_v2
        m.get_K_by(identifier)
        m.get_K_by(identifier2)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Repeat1= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                getattr(P, identifier2)[4] = old_v2
                m.get_K_by(identifier)
                m.get_K_by(identifier2)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                getattr(P, identifier2)[4] = new_v2
                m.get_K_by(identifier)
                m.get_K_by(identifier2)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
    def fn_set_repeat_2(self, v, undo_push=True):
        # <<< 1copy (0bu_block_fn_set_exact_e1,, ${
        #     '0b11111111111110111111111111111111': '0b11111111111111011111111111111111',
        #     '0b1000000000000000000': '0b100000000000000000',
        #     '<< 18': '<< 17',
        #     'Exact1': 'Repeat2',
        # }$)
        identifier = self.rna.identifier
        identifier2 = self.rna2.identifier
        array = getattr(P, identifier)
        array2 = getattr(P, identifier2)
        old_v = array[4]
        old_v2 = array2[4]
        if v is None:
            i = self.rna.default_array[4] & 0b100000000000000000
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111011111111111111111 | i)
            new_v2 = R_sign32(R_unsign32(old_v2) & 0b11111111111111011111111111111111 | i)
            v = "DEFAULT"
        else:
            i = (1 if v == True else 0) << 17
            new_v = R_sign32(R_unsign32(old_v) & 0b11111111111111011111111111111111 | i)
            new_v2 = R_sign32(R_unsign32(old_v2) & 0b11111111111111011111111111111111 | i)
        array[4] = new_v
        array2[4] = new_v2
        m.get_K_by(identifier)
        m.get_K_by(identifier2)
        if undo_push is True:
            m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Repeat2= {v}'
            def old_fn():
                getattr(P, identifier)[4] = old_v
                getattr(P, identifier2)[4] = old_v2
                m.get_K_by(identifier)
                m.get_K_by(identifier2)
            def new_fn():
                getattr(P, identifier)[4] = new_v
                getattr(P, identifier2)[4] = new_v2
                m.get_K_by(identifier)
                m.get_K_by(identifier2)
            m.undo_push(old_fn, new_fn)
            m.refresh()
        # >>>
    def write_type(self, lis, bu_oo):
        ind = 0  if self.oo.index(bu_oo) == 0 else 2
        for r in range(len(lis), 4):    lis.append(False)

        k1, k2, k3, k4 = lis
        v = dict_type[k1]  if k1 in dict_type else non_release[k1]
        v |= (dict_type[k2]  if k2 in dict_type else non_release[k2]) << 8
        v |= (dict_type[k3]  if k3 in dict_type else non_release[k3]) << 16
        v |= (dict_type[k4]  if k4 in dict_type else non_release[k4]) << 24
        v = R_sign32(v)

        identifier = self.rna.identifier
        identifier2 = self.rna2.identifier
        array = getattr(P, identifier)
        array2 = getattr(P, identifier2)
        old_v = array[ind]
        array[ind] = v
        array2[ind] = v
        m.get_K_by(identifier)
        m.get_K_by(identifier2)
        m.undo_str = f'[Settings] Addon Keymap: {self.ti.text} - Combination {1 if ind == 0 else 2}'
        def old_fn():
            getattr(P, identifier)[ind] = old_v
            getattr(P, identifier2)[ind] = old_v
            m.get_K_by(identifier)
            m.get_K_by(identifier2)
        def new_fn():
            getattr(P, identifier)[ind] = v
            getattr(P, identifier2)[ind] = v
            m.get_K_by(identifier)
            m.get_K_by(identifier2)
        m.undo_push(old_fn, new_fn)
        m.refresh()

    def upd_oo(self):
        super().upd_oo()
        if any((e != o  for e, o in zip(self.array2, self.last_data2))):
            self.last_data2 = tuple(self.array2)

            oo = self.oo
            s = self.rna2.identifier[5:]
            km0 = K[f'{s}0']
            km1 = K[f'{s}1']

            oo[10].set_da(key_value_to_title[km0.value])
            oo[12].set_da(key_value_to_title[km1.value])
            oo[11].set_da(km0.hold)
            oo[13].set_da(km1.hold)
            # <<< 1copy (0bu_block_KM_upd_oo,, ${'1':'10', '3':'11'}$)
            if oo[10].da.name in time_keys:
                if oo[11].is_enable is False:    oo[11].enable()
            else:
                if oo[11].is_enable is True:     oo[11].disable()
            # >>>
            # <<< 1copy (0bu_block_KM_upd_oo,, ${'1':'12', '3':'13'}$)
            if oo[12].da.name in time_keys:
                if oo[13].is_enable is False:    oo[13].enable()
            else:
                if oo[13].is_enable is True:     oo[13].disable()
            # >>>
class KM_SEL(KM2):
    __slots__ = ()
    def __init__(self, w, rna, rna2):
        super().__init__(w, rna, rna2)
        oo = self.oo
        oo[1].rna = rna_km_value_press
        oo[6].rna = rna_km_value_press
        oo[10].rna = rna_km_value_release
        oo[12].rna = rna_km_value_release
    def write_type(self, lis, bu_oo):
        if self.oo.index(bu_oo) == 0 and not lis:
            m.admin.report({'INFO'}, "This key cannot None.")
            return
        super().write_type(lis, bu_oo)

class KM_OPS(P_BLOCK_GROUP):
    __slots__ = 'cat', 'km', 'id', 'properties_range', 'oo_active', 'oo_idname', 'oo_map_type', 'oo_value', 'oo_any', 'oo_shift', 'oo_ctrl', 'oo_alt', 'oo_oskey', 'oo_key_modifier', 'oo_type', 'oo_repeat', 'oo_direction'
    def __init__(self, w, cat, km):
        self.w = w
        self.cat = cat
        self.km = km
        self.id = km.id
        self.rim = BOX()
        self.ti = BLF(text=km.name)
        self.da = BLF()
        rnas = km.bl_rna.properties

        oo_active = BOOLEAN(self, rnas["active"], lambda: self.km.active, self.fn_set_active)
        oo_active.ti.text = ""
        rna_idname = RNA_STR("", "ID name", km.idname)
        rna_idname.filter_enums = R_operators_vpp
        oo_idname = STRING(self, rna_idname, lambda: self.km.idname, self.fn_set_idname)
        oo_map_type = STRING_ENUM(self, rnas["map_type"], lambda: self.km.map_type, self.fn_set_map_type)
        oo_map_type.ti.text = ""
        oo_value = STRING_ENUM(self, rnas["value"], lambda: self.km.value, self.fn_set_value)
        oo_value.ti.text = ""
        oo_any = BOOLEAN_ENUM(self, rnas["any"], lambda: self.km.any, self.fn_set_any)
        oo_shift = BOOL_INT_ENUM(self, rnas["shift"], lambda: self.km.shift, self.fn_set_shift)
        oo_ctrl = BOOL_INT_ENUM(self, rnas["ctrl"], lambda: self.km.ctrl, self.fn_set_ctrl)
        oo_alt = BOOL_INT_ENUM(self, rnas["alt"], lambda: self.km.alt, self.fn_set_alt)
        oo_oskey = BOOL_INT_ENUM(self, rnas["oskey"], lambda: self.km.oskey, self.fn_set_oskey)
        oo_oskey.da.text = "Cmd"
        oo_key_modifier = KEYMAP_TYPE(self, rnas["key_modifier"], lambda: self.km.key_modifier, self.fn_set_key_modifier, D_type)
        oo_type = KEYMAP_TYPE(self, rnas["type"], lambda: self.km.type, self.fn_set_type, D_type)
        oo_repeat = BOOLEAN(self, rnas["repeat"], lambda: self.km.repeat, self.fn_set_repeat)
        oo_direction = STRING_ENUM(self, rnas["direction"], lambda: self.km.direction, self.fn_set_direction)

        self.oo_active = oo_active
        self.oo_idname = oo_idname
        self.oo_map_type = oo_map_type
        self.oo_value = oo_value
        self.oo_any = oo_any
        self.oo_shift = oo_shift
        self.oo_ctrl = oo_ctrl
        self.oo_alt = oo_alt
        self.oo_oskey = oo_oskey
        self.oo_key_modifier = oo_key_modifier
        self.oo_type = oo_type
        self.oo_repeat = oo_repeat
        self.oo_direction = oo_direction
        oo = [
            oo_active,
            oo_idname,
            oo_map_type,
            oo_value,
            oo_any,
            oo_shift,
            oo_ctrl,
            oo_alt,
            oo_oskey,
            oo_key_modifier,
            oo_type,
            oo_repeat,
            oo_direction,
        ]
        self.oo = oo
        # /* 0bu_block_KM_OPS_get_oo_prop
        for rna in km.properties.bl_rna.properties:
            if rna.identifier == "rna_type": continue
            oo.append(getattr(self, f"R_ui_{rna.type}")(rna))

        self.properties_range = range(13, len(oo))
        # */
    def R_ui_BOOLEAN(self, rna):
        def fn_set(v, undo_push=True):
            props = self.km.properties
            identifier = rna.identifier
            old_v = getattr(props, identifier)
            try:    setattr(props, identifier, v)
            except: return
            if undo_push is True:
                km_id = self.km.id
                cat_name = self.cat.name
                m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - {identifier}= {v}'
                def old_fn():
                    k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                    setattr(k.properties, identifier, old_v)
                    k.map_type = k.map_type
                def new_fn():
                    k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                    setattr(k.properties, identifier, v)
                    k.map_type = k.map_type
                m.undo_push(old_fn, new_fn)
                m.power_upd()
                self.km.map_type = self.km.map_type
        return BOOLEAN(self, rna, lambda: getattr(self.km.properties, rna.identifier), fn_set)
    def R_ui_INT(self, rna):
        if rna.is_array:
            full_range = (0, rna.array_length)
            def fn_get(ind=None):
                if ind is None: return getattr(self.km.properties, rna.identifier)
                if isinstance(ind, int): return getattr(self.km.properties, rna.identifier)[ind]
                return getattr(self.km.properties, rna.identifier)[ind[0] : ind[1]]
            def fn_set(v, undo_push=True, ind=None):
                props = self.km.properties
                identifier = rna.identifier
                if ind is None: ind = full_range
                if isinstance(ind, int):
                    old_v = getattr(props, identifier)[ind]
                    try:
                        v = round(v)
                        getattr(props, identifier)[ind] = v
                    except: return
                    if undo_push is True:
                        km_id = self.km.id
                        cat_name = self.cat.name
                        m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - {identifier}[{ind}]= {v}'
                        def old_fn():
                            k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                            getattr(k.properties, identifier)[ind] = old_v
                            k.map_type = k.map_type
                        def new_fn():
                            k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                            getattr(k.properties, identifier)[ind] = v
                            k.map_type = k.map_type
                        m.undo_push(old_fn, new_fn)
                        m.power_upd()
                        self.km.map_type = self.km.map_type
                else:
                    i0 = ind[0]
                    i1 = ind[1]
                    old_v = getattr(props, identifier)[i0 : i1]
                    try:
                        v = [round(e)  for e in v]
                        getattr(props, identifier)[i0 : i1] = v
                    except: return
                    if undo_push is True:
                        km_id = self.km.id
                        cat_name = self.cat.name
                        m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - {identifier}[{i0}:{i1}]= {v}'
                        def old_fn():
                            k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                            getattr(k.properties, identifier)[i0 : i1] = old_v
                            k.map_type = k.map_type
                        def new_fn():
                            k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                            getattr(k.properties, identifier)[i0 : i1] = v
                            k.map_type = k.map_type
                        m.undo_push(old_fn, new_fn)
                        m.power_upd()
                        self.km.map_type = self.km.map_type
            if rna.subtype == "TRANSLATION":
                o = INT_ARRAY_SUBTI(self, rna, fn_get, fn_set)
                o.init(tuple_XYZ)
                return o
            return INT_ARRAY(self, rna, fn_get, fn_set)
        else:
            def fn_set(v, undo_push=True):
                props = self.km.properties
                identifier = rna.identifier
                old_v = getattr(props, identifier)
                try:
                    v = round(v)
                    setattr(props, identifier, v)
                except: return
                if undo_push is True:
                    km_id = self.km.id
                    cat_name = self.cat.name
                    m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - {identifier}= {v}'
                    def old_fn():
                        k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                        setattr(k.properties, identifier, old_v)
                        k.map_type = k.map_type
                    def new_fn():
                        k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                        setattr(k.properties, identifier, v)
                        k.map_type = k.map_type
                    m.undo_push(old_fn, new_fn)
                    m.power_upd()
                    self.km.map_type = self.km.map_type
            return INT(self, rna, lambda: getattr(self.km.properties, rna.identifier), fn_set)

    def get_bo(self, L0, R0, T0):
        oo = self.oo
        _2 = F[2]
        _3 = F[3]
        _4 = F[4]
        _16 = F[16]
        L8 = L0 + F[5]
        R8 = L8 + _16
        LL = R8 + F[8]
        T = T0 - F[5]
        B = T - _16
        self.oo_active.get_bo(L8, R8, B, T)
        self.ti.xy(LL, T0 - F[17])

        T = B - _4
        B = T - _16
        R8 = R0 - _4
        L8 = R8 - F[76]
        R7 = L8 - _2
        L7 = R7 - F[61]
        R6 = L7 - _2
        self.oo_idname.get_bo(LL, R6, B, T)
        self.oo_map_type.get_bo(L7, R7, B, T)
        self.oo_value.get_bo(L8, R8, B, T)

        blf_size(font_0, F[9])
        wi = (R6 - LL - 4 * _2) // 5
        R = LL + wi
        T = B - _3
        B = T - _16
        self.oo_any.get_bo(LL, R, B, T)
        L = R + _2
        R = L + wi
        self.oo_shift.get_bo(L, R, B, T)
        L = R + _2
        R = L + wi
        self.oo_ctrl.get_bo(L, R, B, T)
        L = R + _2
        R = L + wi
        self.oo_alt.get_bo(L, R, B, T)
        L = R + _2
        self.oo_oskey.get_bo(L, R6, B, T)
        self.oo_key_modifier.get_bo(L7, R7, B, T)
        self.oo_type.get_bo(L8, R8, B, T)

        T = B - _3
        B = T - _16
        self.oo_repeat.get_bo(R7 - _16, R7, B, T)
        self.oo_direction.get_bo(self.oo_ctrl.rim.L, self.oo_oskey.rim.R, B, T)

        L = self.oo_alt.rim.L
        R = L + F[93]
        Rb = L + _16
        T = B - _4
        B = T - _16
        for r in range(13, len(oo)):
            T = oo[r].get_bo(L, (Rb  if hasattr(oo[r], "use_22") else R), B, T) - _3
            B = T - _16

        B -= _16
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def upd_oo(self):
        km = self.km
        if self.ti.text != km.name: self.ti.text = km.name
        self.oo_active.da_upd()
        self.oo_idname.da_upd()
        self.oo_map_type.da_upd()
        self.oo_value.da_upd()
        self.oo_any.da_upd()
        self.oo_shift.da_upd()
        self.oo_ctrl.da_upd()
        self.oo_alt.da_upd()
        self.oo_oskey.da_upd()
        self.oo_key_modifier.da_upd()
        self.oo_type.da_upd()
        self.oo_repeat.da_upd()
        self.oo_direction.da_upd()
        oo = self.oo
        for r in self.properties_range:
            oo[r].da_upd()

        if km.map_type == "KEYBOARD":
            if self.oo_repeat.is_enable is False:   self.oo_repeat.enable()
        else:
            if self.oo_repeat.is_enable is True:    self.oo_repeat.disable()
        if km.map_type in {"TEXTINPUT", "TIMER"}:
            if self.oo_any.is_enable is True:
                self.oo_any.disable()
                self.oo_shift.disable()
                self.oo_ctrl.disable()
                self.oo_alt.disable()
                self.oo_oskey.disable()
                self.oo_key_modifier.disable()
            if km.map_type == "TEXTINPUT":
                self.oo_type.is_timer_type = None
                if self.oo_type.is_enable is True:  self.oo_type.disable()
            else:
                self.oo_type.is_timer_type = True
                if self.oo_type.is_enable is False: self.oo_type.enable()

            if self.oo_value.is_enable is True:     self.oo_value.disable()
            if self.oo_direction.is_enable is True:     self.oo_direction.disable()
        else:
            self.oo_type.is_timer_type = False
            if self.oo_any.is_enable is False:
                self.oo_any.enable()
                self.oo_shift.enable()
                self.oo_ctrl.enable()
                self.oo_alt.enable()
                self.oo_oskey.enable()
                self.oo_key_modifier.enable()
            if self.oo_type.is_enable is False:     self.oo_type.enable()
            if self.oo_value.is_enable is False:    self.oo_value.enable()
            if km.value == "CLICK_DRAG":
                if self.oo_direction.is_enable is False:    self.oo_direction.enable()
            else:
                if self.oo_direction.is_enable is True:     self.oo_direction.disable()

    # /* 0bu_block_fn_set_active
    def fn_set_active(self, v, undo_push=True):
        km = self.km
        old_v = km.active
        try:    km.active = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - active: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).active = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).active = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # */
    def fn_set_idname(self, v, undo_push=True):
        km = self.km
        old_v = km.idname
        if v not in all_user_operator: return
        km.idname = v

        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - idname: {v}'
            def old_fn():
                km = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                km.idname = old_v
                oo = self.oo
                oo[13 :] = []
                # <<< 1copy (0bu_block_KM_OPS_get_oo_prop,, $$)
                for rna in km.properties.bl_rna.properties:
                    if rna.identifier == "rna_type": continue
                    oo.append(getattr(self, f"R_ui_{rna.type}")(rna))
        
                self.properties_range = range(13, len(oo))
                # >>>
                self.w.get_bo_from_head()
            def new_fn():
                km = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                km.idname = v
                oo = self.oo
                oo[13 :] = []
                # <<< 1copy (0bu_block_KM_OPS_get_oo_prop,, $$)
                for rna in km.properties.bl_rna.properties:
                    if rna.identifier == "rna_type": continue
                    oo.append(getattr(self, f"R_ui_{rna.type}")(rna))
        
                self.properties_range = range(13, len(oo))
                # >>>
                self.w.get_bo_from_head()
            m.undo_push(old_fn, new_fn)
            oo = self.oo
            oo[13 :] = []
            # <<< 1copy (0bu_block_KM_OPS_get_oo_prop,, $$)
            for rna in km.properties.bl_rna.properties:
                if rna.identifier == "rna_type": continue
                oo.append(getattr(self, f"R_ui_{rna.type}")(rna))
    
            self.properties_range = range(13, len(oo))
            # >>>
            self.w.get_bo_from_head()
            m.power_upd()

    def fn_set_map_type(self, v, undo_push=True):
        km = self.km
        old_v = km.map_type
        old_type = km.type
        old_value = km.value
        if v in D_map_type_rev: v = D_map_type_rev[v]
        try:    km.map_type = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            new_type = km.type
            new_value = km.value
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - map_type: {v}'
            def old_fn():
                k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                k.map_type = old_v
                k.type = old_type
                k.value = old_value
            def new_fn():
                k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                k.map_type = v
                k.type = new_type
                k.value = new_value
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    def fn_set_value(self, v, undo_push=True):
        km = self.km
        old_v = km.value
        old_map_type = km.map_type
        old_type = km.type
        if v in D_value_rev: v = D_value_rev[v]
        try:    km.value = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            new_map_type = km.map_type
            new_type = km.type
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - value: {v}'
            def old_fn():
                k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                k.map_type = old_map_type
                k.type = old_type
                k.value = old_v
            def new_fn():
                k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                k.map_type = new_map_type
                k.type = new_type
                k.value = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # <<< || 1copy (0bu_block_fn_set_active,, ${'active':'any'}$)
    def fn_set_any(self, v, undo_push=True):
        km = self.km
        old_v = km.any
        try:    km.any = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - any: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).any = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).any = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # >>>
    # <<< || 1copy (0bu_block_fn_set_active,, ${'active':'shift'}$)
    def fn_set_shift(self, v, undo_push=True):
        km = self.km
        old_v = km.shift
        try:    km.shift = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - shift: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).shift = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).shift = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # >>>
    # <<< || 1copy (0bu_block_fn_set_active,, ${'active':'ctrl'}$)
    def fn_set_ctrl(self, v, undo_push=True):
        km = self.km
        old_v = km.ctrl
        try:    km.ctrl = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - ctrl: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).ctrl = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).ctrl = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # >>>
    # <<< || 1copy (0bu_block_fn_set_active,, ${'active':'alt'}$)
    def fn_set_alt(self, v, undo_push=True):
        km = self.km
        old_v = km.alt
        try:    km.alt = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - alt: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).alt = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).alt = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # >>>
    # <<< || 1copy (0bu_block_fn_set_active,, ${'active':'oskey'}$)
    def fn_set_oskey(self, v, undo_push=True):
        km = self.km
        old_v = km.oskey
        try:    km.oskey = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - oskey: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).oskey = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).oskey = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # >>>

    def fn_set_key_modifier(self, v, undo_push=True):
        km = self.km
        old_v = km.key_modifier
        if v in D_type_rev: v = D_type_rev[v]
        try:    km.key_modifier = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - key_modifier: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).key_modifier = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).key_modifier = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    def fn_set_type(self, v, undo_push=True):
        km = self.km
        old_v = km.type
        old_map_type = km.map_type
        old_value = km.value
        if v in D_type_rev: v = D_type_rev[v]
        try:    km.type = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            new_map_type = km.map_type
            new_value = km.value
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - type: {v}'
            def old_fn():
                k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                k.map_type = old_map_type
                k.type = old_v
                k.value = old_value
            def new_fn():
                k = self.w.R_cats()[cat_name].keymap_items.from_id(km_id)
                k.map_type = new_map_type
                k.type = v
                k.value = new_value
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # <<< || 1copy (0bu_block_fn_set_active,, ${'active':'repeat'}$)
    def fn_set_repeat(self, v, undo_push=True):
        km = self.km
        old_v = km.repeat
        try:    km.repeat = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - repeat: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).repeat = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).repeat = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()
    # >>>
    def fn_set_direction(self, v, undo_push=True):
        km = self.km
        old_v = km.direction
        if v in D_direction_rev: v = D_direction_rev[v]
        try:    km.direction = v
        except: return
        if undo_push is True:
            km_id = km.id
            cat_name = self.cat.name
            m.undo_str = f'[Settings] Addon Operator: {self.ti.text} - direction: {v}'
            def old_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).direction = old_v
            def new_fn():
                self.w.R_cats()[cat_name].keymap_items.from_id(km_id).direction = v
            m.undo_push(old_fn, new_fn)
            m.power_upd()

# ▅▅▅  Global                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
class TI_DATA:
    __slots__ = (
        'w',
        'rim',
        'ti',
        'da',
        'oo',
        'hi',
    )
    def __init__(self, w, hi, name="", description=""):
        self.w = w
        self.rim = BOX()
        self.ti = BLF(text=name)
        self.da = BLF(text=description)
        self.oo = ()
        self.hi = hi

    def get_bo(self, L, R, T):
        rim = self.rim
        rim.LRBT_upd(L, R, T - self.hi, T)

        ti = self.ti
        ti.LT(rim, F[8], F[17])
        self.da.xy(ti.x, ti.y - F[13])

    def draw_box(self):
        m.bind_color_setting_bo()
        self.rim.draw()
    def draw_blf(self):
        blf_color(font_0, *P.color_font)
        blf_size(font_0, F[12])
        self.ti.draw_pos()
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        self.ti.dxy(x, y)
        self.da.dxy(x, y)

    def I_modal_main(self, evt):
        return False
    def upd_oo(self): pass
    #
    #

class BLOCK:
    __slots__ = (
        'w',
        'oo',
        'rim',
        'hi',
        'props',
    )
    def get_bo(self, L0, R0, T0):
        R = R0 - F[3] - F[101] - F[2]
        T = T0 - F[3]
        B = self.oo[0].get_bo(R - F[101], R, T - F[16], T) - F[3]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def draw_box(self):
        m.bind_color_setting_bo()
        self.rim.draw()
        # /* 0bu_block_BLOCK_draw_box
        self.oo[0].draw_box()
        # */
    def draw_blf(self):
        # /* 0bu_block_BLOCK_draw_blf
        self.oo[0].draw_blf()
        # */
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        # /* 0bu_block_BLOCK_dxy
        self.oo[0].dxy(x, y)
        # */

    def to_modal_default(self):
        self.w.U_modal = self.w.default_modal
    def to_modal(self, e):
        self.w.U_modal = e
    def I_modal_main(self, evt):
        # /* 0bu_block_BLOCK_I_modal_main
        if self.oo[0].is_inside(evt.mouse_region_x, evt.mouse_region_y):
            self.oo[0].inside(evt)
            return True
        # */
        return False
    def upd_oo(self):
        # /* 0bu_block_BLOCK_upd_oo
        self.oo[0].da_upd()
        # */
    #
    #
class BLOCK2(BLOCK):
    __slots__ = ()
    def get_bo(self, L0, R0, T0):
        R = R0 - F[3]
        T = T0 - F[3]
        L = R - F[101]
        B = self.oo[1].get_bo(L, R, T - F[16], T)
        R = L - F[2]
        self.oo[0].get_bo(R - F[101], R, B, T)
        B -= F[3]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

    def draw_box(self):
        m.bind_color_setting_bo()
        self.rim.draw()
        # <<< 1for (0bu_block_BLOCK_draw_box,, $[{'oo[0]': f'oo[{r}]'}  for r in range(2)]$)
        self.oo[0].draw_box()
        self.oo[1].draw_box()
        # >>>
    def draw_blf(self):
        # <<< 1for (0bu_block_BLOCK_draw_blf,, $[{'oo[0]': f'oo[{r}]'}  for r in range(2)]$)
        self.oo[0].draw_blf()
        self.oo[1].draw_blf()
        # >>>
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        # <<< 1for (0bu_block_BLOCK_dxy,, $[{'oo[0]': f'oo[{r}]'}  for r in range(2)]$)
        self.oo[0].dxy(x, y)
        self.oo[1].dxy(x, y)
        # >>>

    def I_modal_main(self, evt):
        # <<< 1for (0bu_block_BLOCK_I_modal_main,, $[{'oo[0]': f'oo[{r}]'}  for r in range(2)]$)
        if self.oo[0].is_inside(evt.mouse_region_x, evt.mouse_region_y):
            self.oo[0].inside(evt)
            return True
        if self.oo[1].is_inside(evt.mouse_region_x, evt.mouse_region_y):
            self.oo[1].inside(evt)
            return True
        # >>>
        return False
    def upd_oo(self):
        # <<< 1for (0bu_block_BLOCK_upd_oo,, $[{'oo[0]': f'oo[{r}]'}  for r in range(2)]$)
        self.oo[0].da_upd()
        self.oo[1].da_upd()
        # >>>
    #
    #
class BLOCK3(BLOCK):
    __slots__ = ()
    def draw_box(self):
        m.bind_color_setting_bo()
        self.rim.draw()
        # <<< 1for (0bu_block_BLOCK_draw_box,, $[{'oo[0]': f'oo[{r}]'}  for r in range(3)]$)
        self.oo[0].draw_box()
        self.oo[1].draw_box()
        self.oo[2].draw_box()
        # >>>
    def draw_blf(self):
        # <<< 1for (0bu_block_BLOCK_draw_blf,, $[{'oo[0]': f'oo[{r}]'}  for r in range(3)]$)
        self.oo[0].draw_blf()
        self.oo[1].draw_blf()
        self.oo[2].draw_blf()
        # >>>
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        # <<< 1for (0bu_block_BLOCK_dxy,, $[{'oo[0]': f'oo[{r}]'}  for r in range(3)]$)
        self.oo[0].dxy(x, y)
        self.oo[1].dxy(x, y)
        self.oo[2].dxy(x, y)
        # >>>

    def I_modal_main(self, evt):
        # <<< 1for (0bu_block_BLOCK_I_modal_main,, $[{'oo[0]': f'oo[{r}]'}  for r in range(3)]$)
        if self.oo[0].is_inside(evt.mouse_region_x, evt.mouse_region_y):
            self.oo[0].inside(evt)
            return True
        if self.oo[1].is_inside(evt.mouse_region_x, evt.mouse_region_y):
            self.oo[1].inside(evt)
            return True
        if self.oo[2].is_inside(evt.mouse_region_x, evt.mouse_region_y):
            self.oo[2].inside(evt)
            return True
        # >>>
        return False
    def upd_oo(self):
        # <<< 1for (0bu_block_BLOCK_upd_oo,, $[{'oo[0]': f'oo[{r}]'}  for r in range(3)]$)
        self.oo[0].da_upd()
        self.oo[1].da_upd()
        self.oo[2].da_upd()
        # >>>
class BLOCKS(BLOCK):
    __slots__ = ()
    def draw_box(self):
        m.bind_color_setting_bo()
        self.rim.draw()
        for e in self.oo: e.draw_box()
    def draw_blf(self):
        for e in self.oo: e.draw_blf()
    def dxy(self, x, y):
        self.rim.dxy_upd(x, y)
        for e in self.oo: e.dxy(x, y)

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        for e in self.oo:
            if e.is_inside(x, y):
                e.inside(evt)
                return True
        return False
    def upd_oo(self):
        for e in self.oo: e.da_upd()

class BLOCK_STR(BLOCK):
    __slots__ = ()
    def get_bo(self, L0, R0, T0):
        R = R0 - F[3]
        T = T0 - F[3]
        B = self.oo[0].get_bo(R - F[101] - F[101] - F[2], R, T - F[16], T) - F[3]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)

class BLOCK_INT_BOOL(BLOCK2):
    __slots__ = ()
    def get_bo(self, L0, R0, T0):
        R = R0 - F[3]
        T = T0 - F[3]
        B = self.oo[1].get_bo(R - F[16], R, T - F[16], T)
        R -= F[101] + F[2]
        B = self.oo[0].get_bo(R - F[101], R, B, T) - F[3]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)
class BLOCK_STR_BOOL(BLOCK2):
    __slots__ = ()
    def get_bo(self, L0, R0, T0):
        R = R0 - F[3]
        T = T0 - F[3]
        T = self.oo[0].get_bo(R - F[101] - F[101] - F[2], R, T - F[16], T) - F[4]
        B = self.oo[1].get_bo(R - F[16], R, T - F[16], T) - F[3]
        self.hi = T0 - B
        self.rim.LRBT_upd(L0, R0, B, T0)
