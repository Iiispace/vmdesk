import bpy
from bpy.types import DriverTarget

D_blendData_id = {
    "actions":          "ACTION",
    "armatures":        "ARMATURE",
    "brushes":          "BRUSH",
    "cache_files":      "CACHEFILE",
    "cameras":          "CAMERA",
    "collections":      "COLLECTION",
    "curves":           "CURVE",
    "fonts":            "FONT",
    "grease_pencils":   "GREASEPENCIL",
    "hair_curves":      "CURVES",
    "images":           "IMAGE",
    "lattices":         "LATTICE",
    "libraries":        "LIBRARY",
    "lightprobes":      "LIGHT_PROBE",
    "lights":           "LIGHT",
    "linestyles":       "LINESTYLE",
    "masks":            "MASK",
    "materials":        "MATERIAL",
    "meshes":           "MESH",
    "metaballs":        "META",
    "movieclips":       "MOVIECLIP",
    "node_groups":      "NODETREE",
    "objects":          "OBJECT",
    "paint_curves":     "PAINTCURVE",
    "palettes":         "PALETTE",
    "particles":        "PARTICLE",
    "pointclouds":      "POINTCLOUD",
    "scenes":           "SCENE",
    "screens":          "",
    "shape_keys":       "KEY",
    "simulations":      "SIMULATION",
    "sounds":           "SOUND",
    "speakers":         "SPEAKER",
    "texts":            "TEXT",
    "textures":         "TEXTURE",
    "volumes":          "VOLUME",
    "window_managers":  "WINDOWMANAGER",
    "workspaces":       "WORKSPACE",
    "worlds":           "WORLD",
}
D_id_blendData = {k: e for e, k in D_blendData_id.items()}

D_blendData_rna = {
    "actions":          "Action",
    "armatures":        "Armature",
    "brushes":          "Brush",
    "cache_files":      "CacheFile",
    "cameras":          "Camera",
    "collections":      "Collection",
    "curves":           "Curve",
    "fonts":            "VectorFont",
    "grease_pencils":   "GreasePencil",
    "hair_curves":      "Curves",
    "images":           "Image",
    "lattices":         "Lattice",
    "libraries":        "Library",
    "lightprobes":      "LightProbe",
    "lights":           "Light",
    "linestyles":       "FreestyleLineStyle",
    "masks":            "Mask",
    "materials":        "Material",
    "meshes":           "Mesh",
    "metaballs":        "MetaBall",
    "movieclips":       "MovieClip",
    "node_groups":      "NodeTree",
    "objects":          "Object",
    "paint_curves":     "PaintCurve",
    "palettes":         "Palette",
    "particles":        "ParticleSettings",
    "pointclouds":      "PointCloud",
    "scenes":           "Scene",
    "screens":          "Screen",
    "shape_keys":       "Key",
    "simulations":      "Simulation",
    "sounds":           "Sound",
    "speakers":         "Speaker",
    "texts":            "Text",
    "textures":         "Texture",
    "volumes":          "Volume",
    "window_managers":  "WindowManager",
    "workspaces":       "WorkSpace",
    "worlds":           "World",
}
D_rna_blendData = {k: e for e, k in D_blendData_rna.items()}

def R_id_type(obj):
    try:
        return D_blendData_id[D_rna_blendData[obj.rna_type.identifier]]
    except: return None

def R_drfc_add(tar, tar_dp, index):
    try:    return tar.driver_add(tar_dp, index)
    except: return tar.driver_add(tar_dp)
def R_kffc_add(tar_fcs, tar_dp, index, action_group):
    try:    return tar_fcs.new(tar_dp, index, action_group)
    except: pass
    try:    return tar_fcs.new(tar_dp, index)
    except: return tar_fcs.new(tar_dp)

def TR_drivers(oj):
    try:    return oj.animation_data.drivers
    except: return None
def TR_driver(oj, data_path, index=0):
    try:    return oj.animation_data.drivers.find(data_path, index=index)
    except: return None
def TR_action_fcurves(oj):
    try:    return oj.animation_data.action.fcurves
    except: return None

def TR_dr_add(oj, dp):
    try:    return oj.driver_add(dp)
    except: return None
def TR_dr_add_index(oj, dp, index):
    try:    return oj.driver_add(dp, index=index)
    except: return None

def is_target_path_valid(obj, path):
    try:
        eval(f'obj.{path}')
        return True
    except:
        return False

def is_custom_path_valid(obj, path):
    try:
        eval(f'obj{path}')
        return True
    except:
        return False

def copyFcAttr(fc_from, dr_to):
    dr_to.auto_smoothing    = fc_from.auto_smoothing
    dr_to.color             = fc_from.color
    dr_to.color_mode        = fc_from.color_mode
    dr_to.extrapolation     = fc_from.extrapolation
    dr_to.hide              = fc_from.hide
    dr_to.is_valid          = fc_from.is_valid
    dr_to.lock              = fc_from.lock
    dr_to.mute              = fc_from.mute

def copyVariable(v_from, v_to):
    v_to.type   = v_from.type
    v_to.name   = v_from.name
    tar_to      = v_to.targets[0]
    tar_from    = v_from.targets[0]

    try:
        tar_to.id_type          = tar_from.id_type
    except: pass
    tar_to.id               = tar_from.id
    tar_to.data_path        = tar_from.data_path
    tar_to.rotation_mode    = tar_from.rotation_mode
    tar_to.transform_type   = tar_from.transform_type
    tar_to.transform_space  = tar_from.transform_space
    tar_to.bone_target      = tar_from.bone_target

    if len(v_from.targets) == 2:
        tar_to      = v_to.targets[1]
        tar_from    = v_from.targets[1]

        try:
            tar_to.id_type          = tar_from.id_type
        except: pass
        tar_to.id               = tar_from.id
        tar_to.data_path        = tar_from.data_path
        tar_to.rotation_mode    = tar_from.rotation_mode
        tar_to.transform_type   = tar_from.transform_type
        tar_to.transform_space  = tar_from.transform_space
        tar_to.bone_target      = tar_from.bone_target

def copy_md_driver(fc_from, tar, tar_dp):
    fc = R_drfc_add(tar, tar_dp, fc_from.array_index)
    if type(fc) == list:    fc = fc[fc_from.array_index]
    fc.data_path = tar_dp
    copyFcAttr(fc_from, fc)

    dr_to   = fc.driver
    dr_from = fc_from.driver
    dr_to.type          = dr_from.type
    dr_to.expression    = dr_from.expression
    dr_to.is_valid      = dr_from.is_valid
    dr_to.use_self      = dr_from.use_self

    variables = dr_to.variables
    for v in dr_from.variables:
        var = variables.new()
        copyVariable(v, var)

def copy_md_kf(fc_from, tar, tar_dp): # fc must not exist
    is_empty = False
    if tar.animation_data:
        if tar.animation_data.action is None:           is_empty = True
        elif tar.animation_data.action.fcurves is None: is_empty = True
    else: is_empty = True

    if is_empty:
        if tar.keyframe_insert(data_path = tar_dp) == False: return
        fcs     = tar.animation_data.action.fcurves
        fc      = fcs.find(tar_dp)
        fcs.remove(fc)
    else:
        fcs     = tar.animation_data.action.fcurves

    fc = R_kffc_add(fcs, tar_dp, fc_from.array_index, fc_from.group)
    fc.data_path = tar_dp
    copyFcAttr(fc_from, fc)

    kps = fc.keyframe_points
    for kp in fc_from.keyframe_points:
        kp_new = kps.insert(*kp.co, keyframe_type = kp.type)
        kp_new.amplitude            = kp.amplitude
        kp_new.back                 = kp.back
        kp_new.easing               = kp.easing
        kp_new.handle_left_type     = kp.handle_left_type
        kp_new.handle_left[0]       = kp.handle_left[0]
        kp_new.handle_left[1]       = kp.handle_left[1]
        kp_new.handle_right_type    = kp.handle_right_type
        kp_new.handle_right[0]      = kp.handle_right[0]
        kp_new.handle_right[1]      = kp.handle_right[1]
        kp_new.interpolation        = kp.interpolation
        kp_new.period               = kp.period
        kp_new.select_control_point = kp.select_control_point
        kp_new.select_left_handle   = kp.select_left_handle
        kp_new.select_right_handle  = kp.select_right_handle

def is_dead(obj):
    try:    obj.name; return False
    except: return True

def link_modifier(obj_from, obj_to, md_from, md_to): # md_to must clean
    link_mds    = bpy.data.link_mds
    attrs       = getattr(MOD_ATTR, md_to.type, None)
    if attrs is None:   attr0, attr1 = dir(md_to), {}
    else:
        attr0 = [e for e in attrs] + [e for e in getattr(MOD_EX_ATTR, md_to.type)]
        attr1 = getattr(MOD_REF_ATTR, md_to.type)

    for attr in attr0:
        fc              = TR_dr_add(md_to, attr)
        if fc is None:  continue
        if isinstance(fc, list):
            for ind, fc in enumerate(fc):
                dr              = fc.driver
                if dr.variables:
                    obj_to.animation_data.drivers.remove(fc)
                    fc = TR_dr_add_index(md_to, attr, ind)
                    dr = fc.driver
                v               = dr.variables.new()
                tar             = v.targets[0]
                tar.id          = obj_from
                tar.data_path   = f'modifiers["{md_from.name}"].{attr}'
                dr.expression   = f"var[{ind}]"
        else:
            dr              = fc.driver
            if dr.variables:
                obj_to.animation_data.drivers.remove(fc)
                fc = TR_dr_add(md_to, attr)
                dr = fc.driver
            v               = dr.variables.new()
            tar             = v.targets[0]
            tar.id          = obj_from
            tar.data_path   = f'modifiers["{md_from.name}"].{attr}'
            dr.expression   = "var"

    s0 = f'modifiers[{md_to.name}].'
    for attr in attr1:
        path            = s0 + attr
        obj_to[path]    = True
        fc              = obj_to.driver_add(f'["{path}"]')
        dr              = fc.driver
        if dr.variables:
            obj_to.animation_data.drivers.remove(fc)
            fc = obj_to.driver_add(f'["{path}"]')
            dr = fc.driver
        v               = dr.variables.new()
        tar             = v.targets[0]
        tar.id          = obj_from
        v.name          = md_from.name

        link_mds[fc] = obj_to

def deep_link_modifier(obj_from, obj_to, md_from, md_to): # md_to must clean
    link_mds    = bpy.data.link_mds
    attrs       = getattr(MOD_ATTR, md_to.type, None)
    if attrs is None:     attr0, attr1 = dir(md_to), {}
    else:
        attr0 = [e for e in attrs] + [e for e in getattr(MOD_EX_ATTR, md_to.type)]
        attr1 = getattr(MOD_REF_ATTR, md_to.type)

    for attr in attr0:
        fc              = TR_dr_add(md_to, attr)
        if fc is None:  continue
        if isinstance(fc, list):
            for ind, fc in enumerate(fc):
                dr              = fc.driver
                if dr.variables:
                    obj_to.animation_data.drivers.remove(fc)
                    fc = TR_dr_add_index(md_to, attr, ind)
                    dr = fc.driver
                v               = dr.variables.new()
                tar             = v.targets[0]

                obj             = obj_from
                path_link       = f'modifiers["{md_from.name}"].{attr}'

                for r in range(999):
                    fc_next     = TR_driver(obj, path_link, ind)
                    if fc_next is not None:
                        if fc_next.driver.type == 'SCRIPTED':
                            vs  = fc_next.driver.variables
                            if len(vs) == 1:
                                v0      = vs[0]
                                if fc_next.driver.expression == f'{v0.name}[{ind}]':
                                    tar0        = v0.targets[0]
                                    if tar0.id_type == 'OBJECT':
                                        if is_target_path_valid(tar0.id, tar0.data_path):
                                            obj         = tar0.id
                                            path_link   = tar0.data_path
                                            continue

                    break

                tar.id          = obj
                tar.data_path   = path_link
                dr.expression   = f"var[{ind}]"
        else:
            dr              = fc.driver
            if dr.variables:
                obj_to.animation_data.drivers.remove(fc)
                fc = TR_dr_add(md_to, attr)
                dr = fc.driver
            v               = dr.variables.new()
            tar             = v.targets[0]

            obj             = obj_from
            path_link       = f'modifiers["{md_from.name}"].{attr}'

            for r in range(999):
                fc_next     = TR_driver(obj, path_link)
                if fc_next is not None:
                    if fc_next.driver.type == 'SCRIPTED':
                        vs  = fc_next.driver.variables
                        if len(vs) == 1:
                            v0      = vs[0]
                            if fc_next.driver.expression == v0.name:
                                tar0        = v0.targets[0]
                                if tar0.id_type == 'OBJECT':
                                    if is_target_path_valid(tar0.id, tar0.data_path):
                                        obj         = tar0.id
                                        path_link   = tar0.data_path
                                        continue

                break

            tar.id          = obj
            tar.data_path   = path_link
            dr.expression   = "var"

    s0 = f'modifiers[{md_to.name}].'
    for attr in attr1:
        path            = s0 + attr
        obj_to[path]    = True
        fc              = obj_to.driver_add(f'["{path}"]')
        dr              = fc.driver
        if dr.variables:
            obj_to.animation_data.drivers.remove(fc)
            fc = obj_to.driver_add(f'["{path}"]')
            dr = fc.driver
        v               = dr.variables.new()
        tar             = v.targets[0]

        obj             = obj_from
        md_name         = md_from.name

        for r in range(999):
            fc_next     = TR_driver(obj, f'["modifiers[{md_name}].{attr}"]')

            if fc_next is not None:
                if fc_next.driver.type == 'SCRIPTED':
                    vs  = fc_next.driver.variables
                    if len(vs) == 1:
                        v0      = vs[0]
                        tar0    = v0.targets[0]
                        if tar0.id_type == 'OBJECT':
                            obj     = tar0.id
                            md_name = v0.name
                            continue
            break

        tar.id          = obj
        v.name          = md_name

        link_mds[fc] = obj_to

def R_md_driver_add(oj, md_name, attr, exp="var", index=None):
    try:
        if index is None:
            old_dr = TR_driver(oj, f'modifiers["{md_name}"].{attr}')
            if old_dr is not None: return old_dr
            dr = oj.modifiers[md_name].driver_add(attr)
        else:
            old_dr = TR_driver(oj, f'modifiers["{md_name}"].{attr}', index)
            if old_dr is not None: return old_dr
            dr = oj.modifiers[md_name].driver_add(attr, index)
        driver = dr.driver
        v = driver.variables.new()

        driver.expression = exp
        return dr
    except: # not animatable
        path = f'modifiers[{md_name}].{attr}'
        old_fc = TR_driver(oj, f'["{path}"]')
        if old_fc is not None: return old_fc

        oj[path]  = True
        fc = oj.driver_add(f'["{path}"]')
        bpy.data.link_mds[fc] = oj
        v = fc.driver.variables.new()
        v.name = md_name
        return fc
def R_md_driver_remove(oj, md_name, attr, index=None): # need refresh
    if index is None:
        success = oj.modifiers[md_name].driver_remove(attr)
    else:
        success = oj.modifiers[md_name].driver_remove(attr, index)

    if not success:
        try:
            if not oj.animation_data:           return False
            if not oj.animation_data.drivers:   return False
            path = f'modifiers[{md_name}].{attr}'
            dr = oj.animation_data.drivers.find(f'["{path}"]')
            if dr is None: return False
            if dr in bpy.data.link_mds:
                del bpy.data.link_mds[dr]

            if path in oj:
                del oj[path]

            oj.animation_data.drivers.remove(dr)
            return True
        except:
            return False
    return True


class DrTar:
    __slots__ = 'id_type', 'id', 'transform_type', 'transform_space', 'rotation_mode', 'data_path', 'bone_target',
    def __init__(self, tar):
        self.id_type = tar.id_type
        self.id = tar.id
        self.transform_type = tar.transform_type
        self.transform_space = tar.transform_space
        self.rotation_mode = tar.rotation_mode
        self.data_path = tar.data_path
        self.bone_target = tar.bone_target
class DrVar:
    __slots__ = 'name', 'type', 'tar0', 'tar1'
    def __init__(self, v):
        self.name = v.name
        self.type = v.type
        self.tar0 = DrTar(v.targets[0])
        self.tar1 = DrTar(v.targets[1])  if len(v.targets) == 2 else None

    def write(self, v):
        v.name = self.name
        v.type = self.type
        e = v.targets[0]
        o = self.tar0
        if e.id_type != o.id_type:  e.id_type = o.id_type
        e.id = o.id
        e.transform_type = o.transform_type
        e.transform_space = o.transform_space
        e.rotation_mode = o.rotation_mode
        e.data_path = o.data_path
        e.bone_target = o.bone_target
        if self.tar1 is not None:
            e = v.targets[1]
            o = self.tar1
            if e.id_type != o.id_type:  e.id_type = o.id_type
            e.id = o.id
            e.transform_type = o.transform_type
            e.transform_space = o.transform_space
            e.rotation_mode = o.rotation_mode
            e.data_path = o.data_path
            e.bone_target = o.bone_target


def dr_var_move_to_ind(variables, name, ind):
    old_ind = variables.find(name)
    v = variables[name]
    names = {v.name for v in variables}
    tm_dic = {}
    i = 0
    if old_ind < ind:
        for r in range(old_ind, ind + 1):
            e = variables[r]
            tm_dic[r] = DrVar(e)
            while True:
                if str(i) in names: i += 1
                else:
                    e.name = str(i)
                    break
            i += 1

        for r in range(old_ind, ind):
            tm_dic[r + 1].write(variables[r])

        tm_dic[old_ind].write(variables[ind])
    else:
        for r in range(ind, old_ind + 1):
            e = variables[r]
            tm_dic[r] = DrVar(e)
            while True:
                if str(i) in names: i += 1
                else:
                    e.name = str(i)
                    break
            i += 1

        tm_dic[old_ind].write(variables[ind])
        for r in range(ind + 1, old_ind + 1):
            tm_dic[r - 1].write(variables[r])

    del names
    del tm_dic


class MOD_ARRAY_ATTR:
    __slots__ = ()
    ARMATURE = ()
    ARRAY = ('constant_offset_displace', 'relative_offset_displace')
    BOOLEAN = ()
    BEVEL = ()
    BUILD = ()
    CAST = ()


    CORRECTIVE_SMOOTH = ()
    CURVE = ()
    DATA_TRANSFER = ()
    DECIMATE = ()
    DISPLACE = ()
    EDGE_SPLIT = ()
    EXPLODE = ()
    HOOK = ('center',)
    LAPLACIANDEFORM = ()
    LAPLACIANSMOOTH = ()
    LATTICE = ()
    MASK = ()
    MESH_CACHE = ()
    MESH_DEFORM = ()
    MESH_SEQUENCE_CACHE = ()
    MIRROR = ('use_axis', 'use_bisect_axis', 'use_bisect_flip_axis')
    MULTIRES = ()
    NODES = ()
    NORMAL_EDIT = ('offset',)
    OCEAN = ()
    PARTICLE_INSTANCE = ()
    REMESH = ()
    SCREW = ()
    SHRINKWRAP = ()
    SIMPLE_DEFORM = ('limits',)
    SKIN = ()
    SMOOTH = ()
    SOLIDIFY = ()
    SUBSURF = ()
    SURFACE_DEFORM = ()
    TRIANGULATE = ()
    UV_PROJECT = ()
    UV_WARP = ('center', 'offset', 'scale')
    VERTEX_WEIGHT_EDIT = ()
    VERTEX_WEIGHT_MIX = ()
    VERTEX_WEIGHT_PROXIMITY = ()
    VOLUME_TO_MESH = ()
    WARP = ()
    WAVE = ()
    WEIGHTED_NORMAL = ()
    WELD = ()
    WIREFRAME = ()
    #
    #
class MOD_REF_ATTR:
    __slots__ = ()
    ARMATURE = ('object', 'use_bone_envelopes', 'use_vertex_groups', 'vertex_group',)
    ARRAY = ('curve', 'end_cap', 'offset_object', 'start_cap',)
    BOOLEAN = ('object',)
    BEVEL = ('vertex_group',)
    BUILD = ()
    CAST = ('object', 'vertex_group',)


    CORRECTIVE_SMOOTH = ('vertex_group',)
    CURVE = ('object', 'vertex_group',)
    DATA_TRANSFER = ('object', 'vertex_group',)
    DECIMATE = ('vertex_group',)
    DISPLACE = ('texture', 'texture_coords_bone', 'texture_coords_object', 'uv_layer', 'vertex_group',)
    EDGE_SPLIT = ()
    EXPLODE = ('particle_uv', 'vertex_group',)
    HOOK = ('object', 'subtarget', 'vertex_group',)
    LAPLACIANDEFORM = ('vertex_group',)
    LAPLACIANSMOOTH = ('vertex_group',)
    LATTICE = ('object', 'vertex_group',)
    MASK = ('armature', 'vertex_group',)
    MESH_CACHE = ('filepath', 'vertex_group',)
    MESH_DEFORM = ('object', 'vertex_group',)
    MESH_SEQUENCE_CACHE = ('cache_file', 'object_path',)
    MIRROR = ('mirror_object',)
    MULTIRES = ('filepath',)
    NODES = ('node_group',)
    NORMAL_EDIT = ('target', 'vertex_group',)
    OCEAN = (
        'bake_foam_fade',
        'damping',
        'depth',
        'fetch_jonswap',
        'filepath',
        'foam_layer_name',
        'frame_end',
        'frame_start',
        'invert_spray',
        'random_seed',
        'repeat_x',
        'repeat_y',
        'resolution',
        'sharpen_peak_jonswap',
        'spatial_size',
        'spectrum',
        'spray_layer_name',
        'use_foam',
        'use_normals',
        'use_spray',
        'viewport_resolution',
        'wave_alignment',
        'wave_direction',
        'wave_scale_min',
        'wind_velocity',)
    PARTICLE_INSTANCE = ('index_layer_name', 'object', 'particle_system', 'value_layer_name',)
    REMESH = ()
    SCREW = ('object',)
    SHRINKWRAP = ('auxiliary_target', 'target', 'vertex_group',)
    SIMPLE_DEFORM = ('origin', 'vertex_group',)
    SKIN = ()
    SMOOTH = ('vertex_group',)
    SOLIDIFY = ('rim_vertex_group', 'shell_vertex_group', 'vertex_group',)
    SUBSURF = ()
    SURFACE_DEFORM = ('target', 'use_sparse_bind', 'vertex_group',)
    TRIANGULATE = ()
    UV_PROJECT = ('uv_layer',)
    UV_WARP = (
        'bone_from',
        'bone_to',
        'object_from',
        'object_to',
        'uv_layer',
        'vertex_group',)
    VERTEX_WEIGHT_EDIT = (
        'mask_tex_map_bone',
        'mask_tex_map_object',
        'mask_tex_uv_layer',
        'mask_texture',
        'mask_vertex_group',
        'vertex_group',)
    VERTEX_WEIGHT_MIX = (
        'mask_tex_map_bone',
        'mask_tex_map_object',
        'mask_tex_uv_layer',
        'mask_texture',
        'mask_vertex_group',
        'vertex_group_a',
        'vertex_group_b',)
    VERTEX_WEIGHT_PROXIMITY = (
        'mask_tex_map_bone',
        'mask_tex_map_object',
        'mask_tex_uv_layer',
        'mask_texture',
        'mask_vertex_group',
        'target',
        'vertex_group',)
    VOLUME_TO_MESH = ('grid_name', 'object',)
    WARP = (
        'bone_from',
        'bone_to',
        'object_from',
        'object_to',
        'texture',
        'texture_coords_bone',
        'texture_coords_object',
        'uv_layer',
        'vertex_group',)
    WAVE = (
        'start_position_object',
        'texture',
        'texture_coords_bone',
        'texture_coords_object',
        'uv_layer',
        'vertex_group',)
    WEIGHTED_NORMAL = ('vertex_group',)
    WELD = ('vertex_group',)
    WIREFRAME = ('vertex_group',)
    #
    #
class MOD_EX_ATTR:
    __slots__ = ()
    EX2 = ('show_viewport', 'show_render')
    EX3 = ('show_in_editmode', 'show_viewport', 'show_render')
    EX4 = ('show_on_cage', 'show_in_editmode', 'show_viewport', 'show_render')

    ARMATURE = EX4
    ARRAY = EX4
    BOOLEAN = EX3
    BEVEL = EX3
    BUILD = EX2
    CAST = EX4


    CORRECTIVE_SMOOTH = EX4
    CURVE = EX4
    DATA_TRANSFER = EX4
    DECIMATE = EX2
    DISPLACE = EX4
    EDGE_SPLIT = EX4
    EXPLODE = EX2
    HOOK = EX4
    LAPLACIANDEFORM = EX4
    LAPLACIANSMOOTH = EX4
    LATTICE = EX4
    MASK = EX4
    MESH_CACHE = EX3
    MESH_DEFORM = EX4
    MESH_SEQUENCE_CACHE = EX2
    MIRROR = EX4
    MULTIRES = EX2
    NODES = EX3
    NORMAL_EDIT = EX4
    OCEAN = EX3
    PARTICLE_INSTANCE = EX3
    REMESH = EX3
    SCREW = EX3
    SHRINKWRAP = EX4
    SIMPLE_DEFORM = EX4
    SKIN = EX3
    SMOOTH = EX4
    SOLIDIFY = EX4
    SUBSURF = EX4
    SURFACE_DEFORM = EX4
    TRIANGULATE = EX4
    UV_PROJECT = EX4
    UV_WARP = EX3
    VERTEX_WEIGHT_EDIT = EX4
    VERTEX_WEIGHT_MIX = EX4
    VERTEX_WEIGHT_PROXIMITY = EX4
    VOLUME_TO_MESH = EX2
    WARP = EX4
    WAVE = EX4
    WEIGHTED_NORMAL = EX4
    WELD = EX4
    WIREFRAME = EX3
    #
    #
class MOD_ATTR:
    __slots__ = ()
    ARMATURE = (
        'invert_vertex_group',
        'use_deform_preserve_volume',
        'use_multi_modifier',)
    ARRAY = (
        'constant_offset_displace',
        'count',
        'fit_length',
        'fit_type',
        'merge_threshold',
        'offset_u',
        'offset_v',
        'relative_offset_displace',
        'use_constant_offset',
        'use_merge_vertices',
        'use_merge_vertices_cap',
        'use_object_offset',
        'use_relative_offset',)
    BOOLEAN = (
        'double_threshold',
        'material_mode',
        'operand_type',
        'operation',
        'solver',
        'use_hole_tolerant',
        'use_self',)
    BEVEL = (
        'affect',
        'angle_limit',
        'face_strength_mode',
        'harden_normals',
        'invert_vertex_group',
        'limit_method',
        'loop_slide',
        'mark_seam',
        'mark_sharp',
        'material',
        'miter_inner',
        'miter_outer',
        'offset_type',
        'profile',
        'profile_type',
        'segments',
        'spread',
        'use_clamp_overlap',
        'vmesh_method',
        'width',
        'width_pct',)
    BUILD = (
        'frame_duration',
        'frame_start',
        'seed',
        'use_random_order',
        'use_reverse',)
    CAST = (
        'cast_type',
        'factor',
        'invert_vertex_group',
        'radius',
        'size',
        'use_radius_as_size',
        'use_transform',
        'use_x',
        'use_y',
        'use_z',)


    CORRECTIVE_SMOOTH = (
        'factor',
        'invert_vertex_group',
        'iterations',
        'rest_source',
        'scale',
        'smooth_type',
        'use_only_smooth',
        'use_pin_boundary',)
    CURVE = (
        'deform_axis',
        'invert_vertex_group',)
    DATA_TRANSFER = (
        'data_types_edges',
        'data_types_loops',
        'data_types_polys',
        'data_types_verts',
        'edge_mapping',
        'invert_vertex_group',
        'islands_precision',
        'layers_uv_select_dst',
        'layers_uv_select_src',
        'layers_vcol_loop_select_dst',
        'layers_vcol_loop_select_src',
        'layers_vcol_vert_select_dst',
        'layers_vcol_vert_select_src',
        'layers_vgroup_select_dst',
        'layers_vgroup_select_src',
        'loop_mapping',
        'max_distance',
        'mix_factor',
        'mix_mode',
        'poly_mapping',
        'ray_radius',
        'use_edge_data',
        'use_loop_data',
        'use_max_distance',
        'use_object_transform',
        'use_poly_data',
        'use_vert_data',
        'vert_mapping',)
    DECIMATE = (
        'angle_limit',
        'decimate_type',
        'delimit',
        'invert_vertex_group',
        'iterations',
        'ratio',
        'symmetry_axis',
        'use_collapse_triangulate',
        'use_dissolve_boundaries',
        'use_symmetry',
        'vertex_group_factor',)
    DISPLACE = (
        'direction',
        'invert_vertex_group',
        'mid_level',
        'space',
        'strength',
        'texture_coords',)
    EDGE_SPLIT = (
        'split_angle',
        'use_edge_angle',
        'use_edge_sharp',)
    EXPLODE = (
        'invert_vertex_group',
        'protect',
        'show_alive',
        'show_dead',
        'show_unborn',
        'use_edge_cut',
        'use_size',)
    HOOK = (
        'center',
        'falloff_radius',
        'falloff_type',
        'invert_vertex_group',
        'strength',
        'use_falloff_uniform',)
    LAPLACIANDEFORM = (
        'invert_vertex_group',
        'iterations',)
    LAPLACIANSMOOTH = (
        'invert_vertex_group',
        'iterations',
        'lambda_border',
        'lambda_factor',
        'use_normalized',
        'use_volume_preserve',
        'use_x',
        'use_y',
        'use_z',)
    LATTICE = (
        'invert_vertex_group',
        'strength',)
    MASK = (
        'invert_vertex_group',
        'mode',
        'threshold',
        'use_smooth',)
    MESH_CACHE = (
        'cache_format',
        'deform_mode',
        'eval_factor',
        'eval_frame',
        'eval_time',
        'factor',
        'flip_axis',
        'forward_axis',
        'frame_scale',
        'frame_start',
        'interpolation',
        'invert_vertex_group',
        'play_mode',
        'time_mode',
        'up_axis',)
    MESH_DEFORM = (
        'invert_vertex_group',
        'precision',
        'use_dynamic_bind',)
    MESH_SEQUENCE_CACHE = (
        'read_data',
        'use_vertex_interpolation',
        'velocity_scale',)
    MIRROR = (
        'bisect_threshold',
        'merge_threshold',
        'mirror_offset_u',
        'mirror_offset_v',
        'offset_u',
        'offset_v',
        'use_axis',
        'use_bisect_axis',
        'use_bisect_flip_axis',
        'use_clip',
        'use_mirror_merge',
        'use_mirror_u',
        'use_mirror_udim',
        'use_mirror_v',
        'use_mirror_vertex_groups',)
    MULTIRES = (
        'boundary_smooth',
        'levels',
        'quality',
        'render_levels',
        'sculpt_levels',
        'show_only_control_edges',
        'use_creases',
        'use_custom_normals',
        'use_sculpt_base_mesh',
        'uv_smooth',)
    NODES = ()
    NORMAL_EDIT = (
        'invert_vertex_group',
        'mix_factor',
        'mix_limit',
        'mix_mode',
        'mode',
        'no_polynors_fix',
        'offset',
        'use_direction_parallel',)
    OCEAN = (
        'choppiness',
        'foam_coverage',
        'geometry_mode',
        'size',
        'time',
        'wave_scale',)
    PARTICLE_INSTANCE = (
        'axis',
        'particle_amount',
        'particle_offset',
        'particle_system_index',
        'position',
        'random_position',
        'random_rotation',
        'rotation',
        'show_alive',
        'show_dead',
        'show_unborn',
        'space',
        'use_children',
        'use_normal',
        'use_path',
        'use_preserve_shape',
        'use_size',)
    REMESH = (
        'adaptivity',
        'mode',
        'octree_depth',
        'scale',
        'sharpness',
        'threshold',
        'use_remove_disconnected',
        'use_smooth_shade',
        'voxel_size',)
    SCREW = (
        'angle',
        'axis',
        'iterations',
        'merge_threshold',
        'render_steps',
        'screw_offset',
        'steps',
        'use_merge_vertices',
        'use_normal_calculate',
        'use_normal_flip',
        'use_object_screw_offset',
        'use_smooth_shade',
        'use_stretch_u',
        'use_stretch_v',)
    SHRINKWRAP = (
        'cull_face',
        'invert_vertex_group',
        'offset',
        'project_limit',
        'subsurf_levels',
        'use_invert_cull',
        'use_negative_direction',
        'use_positive_direction',
        'use_project_x',
        'use_project_y',
        'use_project_z',
        'wrap_method',
        'wrap_mode',)
    SIMPLE_DEFORM = (
        'angle',
        'deform_axis',
        'deform_method',
        'factor',
        'invert_vertex_group',
        'limits',
        'lock_x',
        'lock_y',
        'lock_z',)
    SKIN = (
        'branch_smoothing',
        'use_smooth_shade',
        'use_x_symmetry',
        'use_y_symmetry',
        'use_z_symmetry',)
    SMOOTH = (
        'factor',
        'invert_vertex_group',
        'iterations',
        'use_x',
        'use_y',
        'use_z',)
    SOLIDIFY = (
        'bevel_convex',
        'edge_crease_inner',
        'edge_crease_outer',
        'edge_crease_rim',
        'invert_vertex_group',
        'material_offset',
        'material_offset_rim',
        'nonmanifold_boundary_mode',
        'nonmanifold_merge_threshold',
        'nonmanifold_thickness_mode',
        'offset',
        'solidify_mode',
        'thickness',
        'thickness_clamp',
        'thickness_vertex_group',
        'use_even_offset',
        'use_flat_faces',
        'use_flip_normals',
        'use_quality_normals',
        'use_rim',
        'use_rim_only',
        'use_thickness_angle_clamp',)
    SUBSURF = (
        'boundary_smooth',
        'levels',
        'quality',
        'render_levels',
        'show_only_control_edges',
        'subdivision_type',
        'use_creases',
        'use_custom_normals',
        'use_limit_surface',
        'uv_smooth',)
    SURFACE_DEFORM = (
        'falloff',
        'invert_vertex_group',
        'strength',)
    TRIANGULATE = (
        'keep_custom_normals',
        'min_vertices',
        'ngon_method',
        'quad_method',)
    UV_PROJECT = (
        'aspect_x',
        'aspect_y',
        'projector_count',
        'scale_x',
        'scale_y',)
    UV_WARP = (
        'axis_u',
        'axis_v',
        'center',
        'invert_vertex_group',
        'offset',
        'rotation',
        'scale',)
    VERTEX_WEIGHT_EDIT = (
        'add_threshold',
        'default_weight',
        'falloff_type',
        'invert_falloff',
        'invert_mask_vertex_group',
        'mask_constant',
        'mask_tex_mapping',
        'mask_tex_use_channel',
        'normalize',
        'remove_threshold',
        'use_add',
        'use_remove',)
    VERTEX_WEIGHT_MIX = (
        'default_weight_a',
        'default_weight_b',
        'invert_mask_vertex_group',
        'invert_vertex_group_a',
        'invert_vertex_group_b',
        'mask_constant',
        'mask_tex_mapping',
        'mask_tex_use_channel',
        'mix_mode',
        'mix_set',
        'normalize',)
    VERTEX_WEIGHT_PROXIMITY = (
        'falloff_type',
        'invert_falloff',
        'invert_mask_vertex_group',
        'mask_constant',
        'mask_tex_mapping',
        'mask_tex_use_channel',
        'max_dist',
        'min_dist',
        'normalize',
        'proximity_geometry',
        'proximity_mode',)
    VOLUME_TO_MESH = (
        'adaptivity',
        'resolution_mode',
        'threshold',
        'use_smooth_shade',
        'voxel_amount',
        'voxel_size',)
    WARP = (
        'falloff_radius',
        'falloff_type',
        'invert_vertex_group',
        'strength',
        'texture_coords',
        'use_volume_preserve',)
    WAVE = (
        'damping_time',
        'falloff_radius',
        'height',
        'invert_vertex_group',
        'lifetime',
        'narrowness',
        'speed',
        'start_position_x',
        'start_position_y',
        'texture_coords',
        'time_offset',
        'use_cyclic',
        'use_normal',
        'use_normal_x',
        'use_normal_y',
        'use_normal_z',
        'use_x',
        'use_y',
        'width',)
    WEIGHTED_NORMAL = (
        'invert_vertex_group',
        'keep_sharp',
        'mode',
        'thresh',
        'use_face_influence',
        'weight',)
    WELD = (
        'invert_vertex_group',
        'loose_edges',
        'merge_threshold',
        'mode',)
    WIREFRAME = (
        'crease_weight',
        'invert_vertex_group',
        'material_offset',
        'offset',
        'thickness',
        'thickness_vertex_group',
        'use_boundary',
        'use_crease',
        'use_even_offset',
        'use_relative_offset',
        'use_replace',)


D_apply_as = {
    'ARMATURE': 0,
    'CAST': 1,
    'CLOTH': 2,
    'COLLISION': 3,
    'CORRECTIVE_SMOOTH': 4,
    'CURVE': 5,
    'DISPLACE': 6,
    'HOOK': 7,
    'LAPLACIANDEFORM': 8,
    'LAPLACIANSMOOTH': 9,
    'LATTICE': 10,
    'MESH_CACHE': 11,
    'MESH_DEFORM': 12,
    'PARTICLE_SYSTEM': 13,
    'SHRINKWRAP': 14,
    'SIMPLE_DEFORM': 15,
    'SMOOTH': 16,
    'SOFT_BODY': 17,
    'SURFACE': 18,
    'SURFACE_DEFORM': 19,
    'WARP': 20,
    'WAVE': 21,
}
D_apply_on_spline = {
    'ARMATURE': 0,
    'CAST': 1,
    'CURVE': 2,
    'LATTICE': 3,
    'SHRINKWRAP': 4,
    'SIMPLE_DEFORM': 5,
    'SMOOTH': 6,
    'WARP': 7,
    'WAVE': 8,
}
D_only_one = {
    'CLOTH',
    'COLLISION',
    'FLUID',
    'SOFT_BODY',
}