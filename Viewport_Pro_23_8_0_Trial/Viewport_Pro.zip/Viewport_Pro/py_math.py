import bpy
from math import *

def TR_eval(s):
    try:    return eval(s)
    except: return None