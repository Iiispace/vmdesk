import bpy
from blf import size as blf_size
from blf import color as blf_color
from blf import enable as blf_enable
from blf import disable as blf_disable
from blf import word_wrap as blf_wrap
from blf import WORD_WRAP
from bpy.app.timers import register as thread_reg
from bpy.app.timers import unregister as thread_unreg
from bpy.app.timers import is_registered

from . import m, win, bu
from . win_cls import AREA
from . props import RNA_STR
from . fn import R_str_by_num3

P = None
F = None
K = None
N = None
BOX = None
BLF = None
font_0 = None
font_1 = None
DISABLE_SCISSOR = None
BLEND = None

BUTTON20 = None

TM = {}

class A_MAIN:
    __slots__ = (
        'U_modal',
        'default_modal',
        'RET',
        'sci',
        'fin',
        'oo',
        'li',
        'outside',
        'props',
    )
    def get_oo(self):
        self.oo = {e.name: e  for e in self.li}
    def to_modal(self, e):
        self.U_modal = e
    def to_default_modal(self):
        self.U_modal = self.default_modal

class MESS(win.WIN):
    __slots__ = (
        'bg_fo',
        'hide_tb',
        'main_area',
        'oo',
        'default_modal',
        'tx_wi',
        'width',
        'height',
    )
    name = "Message Box"

    def __init__(self, x, y, tx,
            offset      = True,
            hide_tb     = True,
            width       = None,
            height      = None,
            bu_x_fn     = None,
        ):
        self.hide_tb    = hide_tb
        self.width      = width
        self.height     = height

        if offset:
            o = P.win_offset_top
            x += o[0]
            y += o[1]

        super().__init__((x, y, tx), region = False, bu_x_fn = bu_x_fn)
        if hide_tb:     m.admin.tb.disable()
        m.admin.tb.U_modal = m.NF
        self.da["tx"].set_size()
        self.tx_wi      = round(self.box["main"].R_w() - F[20])
        bpy.context.window.cursor_modal_set('DEFAULT')
    def fin(self):

        m.M.restore_mou_ic()
        m.W_A.remove(self)
        m.W_D.remove(self)
        m.W_M.remove(self)
        m.FLASH_BOX.kill()
        self.U_kill_thread()

        self.fin_D1()

        m.EVT.kill()
        if self.hide_tb:    m.admin.tb.enable()
        m.admin.tb.U_modal = m.admin.tb.I_modal_outside
        m.redraw()
    def fin_D1(self):   pass
    def init_D1(self, evt):
        rd  = m.region_data

        self.bg_fo  = BOX(P.color_bg_fo, 0, rd.R - rd.border.R, 0, rd.T - rd.border.T)
        self.bg_fo.upd()
        self.bo     = {"bg": BOX(P.color_oj_info)}
        self.ti     = {}
        self.da     = {"tx": BLF(P.color_font, size = F[12])}

        x, y, self.da["tx"].text    = evt
        dx = F[150]  if self.width is None else self.width // 2
        dy = F[61]  if self.height is None else self.height // 2
        self.width  = dx * 2
        self.height = dy * 2

        self.box["rim"].LRBTd(x - dx, x + dx, y - dy, y + dy, F[1])
        x, y = m.IR_protect_pos(self.box["rim"], F[-1])
        self.box["rim"].LRBTd(x, x + self.width, y - self.height, y, F[1])

        self.default_modal  = self.I_modal_main
        self.U_init_thread  = self.I_init_thread
        self.U_kill_thread  = N
        self.tit["ti"].text = "Message"
        ma                  = A_MAIN()
        self.main_area      = ma
        ma.U_modal          = self.I_modal_main_area
        ma.default_modal    = self.I_modal_main_area
        ma.sci              = self.sci
        ma.fin              = self.bu_x_fn
        self.oo = {"bu_ok": bu.BURE(ma, "bu_ok", "OK", self.bu_x_fn, -5.6)}

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd_main(self, x, y):
        super().dxy_upd_main(x, y)
        for e in self.oo.values():   e.dxy_upd(x, y)
# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo_main(self):
        bo      = self.bo
        da      = self.da

        bo["bg"].inset_with_depth(self.box["main"], F[2])
        cx      = bo["bg"].R_center_x()
        y       = bo["bg"].B + F[10]
        blf_size(font_0, F[12])
        self.oo["bu_ok"].LRBT(cx - F[24], cx + F[24], y, y + F[20])

        da["tx"].LT(bo["bg"], F[12], F[19.1])

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_modal_main(self, evt):
        if self.callfront is not None:
            self.callfront(evt)
            self.callfront = None

        if K["cancel0"].true():   self.bu_x_fn()  ;return
        if K["cancel1"].true():   self.bu_x_fn()  ;return
        if K["confirm0"].true():  self.bu_x_fn()  ;return
        if K["confirm1"].true():  self.bu_x_fn()  ;return
        self.main_area.U_modal(evt)

    def I_modal_main_area(self, evt):
        if self.box["ti"].inbox(evt):
            if self.box["bu_x"].inbox(evt):
                self.U_modal = self.I_modal_x
                self.modal_x(evt)
                self.box["bu_x"].color = P.color_ti_bu_x
                m.redraw()  ;return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
                return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
                return
        elif self.box["main"].inbox(evt):
            for e in self.oo.values():
                if e.rim.inbox(evt):    e.inside(evt) ;return
        else:
            if evt.value == 'PRESS':
                if m.thread_isreg(m.flash_box_thread_fn):   return
                r = self.box["rim"]
                m.FLASH_BOX.init(r.L, r.R, r.B, r.T)

    def modal_mov_end(self):
        dx, dy = m.R_protect_dxy_LT(self.box["rim"], F[-1])
        if dx != 0 or dy != 0:  self.dxy_upd(dx, dy)
        del m.head_modal[-1]

        m.EVT.kill()
        m.EVT.U_ENABLE_evt()
        m.redraw()

    def evt_x(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.box["bu_x"].color = self.color.ti_bu
                self.tit["bu_x"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.EVT.kill()
                if self.box["bu_x"].inbox(evt):  self.bu_x_fn()
                return
        m.tm["fn"](evt)
    def evt_fit(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                if self.box["bu_fit"].inbox(evt):
                    self.fit_win(F[2])
                self.box["bu_fit"].color = self.color.ti_bu
                self.tit["bu_fit"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.init_wait_release()
                return
        m.tm["fn"](evt)
# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        BLEND()
        box = self.box

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()

        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        self.tit["bu_x"].set_draw_id(font_1)
        self.tit["ti"].set_draw()
        blf_enable(font_0, WORD_WRAP)
        blf_wrap(font_0, self.tx_wi)
        self.da["tx"].set_draw()
        blf_disable(font_0, WORD_WRAP)

        blf_size(font_0, F[12])
        for e in self.oo.values():   e.draw_ti()

        m.FLASH_BOX.U_draw()

class MESS_BOOL(MESS):
    __slots__ = ()
    name = "Confirm Box"

    def __init__(self, x, y, tx, fn_yes, fn_no,
            offset      = True,
            hide_tb     = True,
            width       = None,
            height      = None,
        ):
        super().__init__(x, y, tx, offset=offset, hide_tb=hide_tb, width=width, height=height)
        oo      = self.oo
        bu_ok   = oo["bu_ok"]

        def bu_fn_yes():
            self.fin()
            fn_yes()
        def bu_fn_no():
            self.fin()
            fn_no()

        self.bu_x_fn = bu_fn_no
        oo["bu_no"] = bu.BURE(self.main_area, "bu_no", "No", self.bu_x_fn, -5.6)

        blf_size(font_0, F[12])
        rim             = bu_ok.rim
        bu_ok.ti.text   = "Yes"
        bu_ok.fn        = bu_fn_yes
        L   = rim.L - F[52]
        B   = rim.B
        T   = rim.T
        wi  = rim.R - rim.L
        bu_ok.LRBT(L, L + wi, B, T)

        L   += F[110]
        oo["bu_no"].LRBT(L, L + wi, B, T)

    def I_modal_main(self, evt):
        if K["cancel0"].true() or K["cancel1"].true():
            self.bu_x_fn()
            return
        if K["confirm0"].true() or K["confirm1"].true():
            self.oo["bu_ok"].fn()
            return
        self.main_area.U_modal(evt)


class PROGRESS(MESS):
    __slots__ = (
        'w',
        'U_thread',
        'da_tx',
        'gen',
        'job_amt',
        'end_fn',
        'abort_fn',
        'undo_fn',
        'job_done',
        'fin_D2',
    )
    name = "Progress"

    def __init__(self, x, y, w, amt, gen, end_fn, abort_fn, undo_fn, fin_D2,
            offset      = True,
            hide_tb     = True
        ):


        super().__init__(x, y, "", offset = offset, hide_tb = hide_tb)

        m.upd_disable()

        bo  = self.bo
        da  = self.da
        bg  = bo["bg"]

        self.tit["ti"].text = f"Progress"

        self.w          = w
        bu_ok           = self.oo["bu_ok"]
        bu_ok.ti.text   = "Abort "
        bu_ok.fn        = self.when_abort
        _d              = F[10]
        R               = bg.R - _d
        B               = bg.B + _d
        bu_ok.LRBT(R - F[61], R, B, B + F[20])

        da["tx"].text   = f"Completed :  {R_str_by_num3(0)} %    ( 0 / {amt} )"

        self.U_thread   = self.I_thread

        self.da_tx      = da["tx"]
        self.gen        = gen
        self.job_amt    = amt
        self.job_done   = False
        self.end_fn     = end_fn
        self.abort_fn   = abort_fn
        self.undo_fn    = undo_fn
        self.bu_x_fn    = self.when_abort
        self.fin_D2     = fin_D2

        m.admin.U_modal = m.admin.I_modal_progress
        m.M.set_mou_ic('DEFAULT')
        m.M.U_add_timer()

    def fin_D1(self):
        self.fin_D2()
        m.upd_enable()
        m.M.U_kill_timer()
        m.admin.U_modal = m.admin.I_modal
        m.M.set_mou_ic('DEFAULT')
        TM.clear()

    def I_modal_main(self, evt):
        if self.callfront is not None:
            self.callfront(evt)
            self.callfront = None

        if K["cancel0"].true() or K["cancel1"].true():
            m.EVT.kill()
            self.bu_x_fn()
            return

        if evt.type == 'TIMER': self.U_thread()
        else: self.main_area.U_modal(evt)

    def I_thread(self):
        try:
            i = next(self.gen)
            self.da_tx.text = f"Completed :  {R_str_by_num3(i * 100 // self.job_amt)} %    ( {i} / {self.job_amt} )"
        except StopIteration:
            self.end_fn()

    def when_job_done(self):
        self.job_done   = True
        self.U_thread   = N
        bu_ok           = self.oo["bu_ok"]

        bu_ok.ti.text   = "Undo"
        bu_ok.ti.x      += F[1]
        bu_ok.offset_x  = bu_ok.ti.x - bu_ok.bg.L
        bu_ok.fn        = self.undo_fn
        bu_ok.off()
        self.bu_x_fn    = self.fin
    def when_abort(self):
        def fn_yes():
            self.abort_fn()
            self.job_done   = True
            self.U_thread   = N
            self.da_tx.text = "Cancelled"
            self.oo["bu_ok"].disable()
            self.bu_x_fn    = self.fin
            m.undo()
            m.M.set_mou_ic('DEFAULT')

        box = self.box["main"]
        MESS_BOOL(
            box.R_center_x(),
            box.R_center_y(),
            "It will undo the operation.",
            fn_yes,
            N,
            hide_tb = False
        )
    def when_undo(self):
        self.oo["bu_ok"].disable()
        m.undo()


class MENU(MESS):
    __slots__ = (
        'line',
        'bu_hi',
        'bu_border',
        'bu_tx_si',
        'bu_dist',
    )
    name = "Menu"

    def __init__(self, x, y, lis_bu, bu_x_fn,
            title       = "Menu",
            offset      = True,
            hide_tb     = True,
            width       = None,
            bu_hi       = None,
            bu_border   = None,
            bu_tx_si    = None,
            bu_dist     = None,
        ):
        TM["title"]     = title
        TM["lis_bu"]    = lis_bu
        TM["bu_x_fn"]   = bu_x_fn
        TM["job"]       = False
        self.bu_hi      = F[20]     if bu_hi is None else bu_hi
        self.bu_border  = F[8]      if bu_border is None else bu_border
        self.bu_tx_si   = F[10]     if bu_tx_si is None else bu_tx_si
        self.bu_dist    = F[6]      if bu_dist is None else bu_dist

        super().__init__(x, y, "",
            offset      = offset,
            hide_tb     = hide_tb,
            width       = width,
            height      = len(lis_bu) * (self.bu_hi + self.bu_dist) + (
                self.bu_border + F[2] + F[1]) * 2 + F[-1] - self.bu_dist
        )
    def init_D1(self, evt):
        super().init_D1(evt)

        end_fn = TM["bu_x_fn"]

        def bu_x_fn():
            self.fin()
            end_fn()

        self.bu_x_fn    = bu_x_fn

        ma      = self.main_area

        BURE        = bu.BURE
        oo          = self.oo
        oo.clear()
        line        = []
        self.line   = line
        R_bu_fn     = self.R_bu_fn

        self.tit["ti"].text = TM["title"]
        for e in TM["lis_bu"]:
            name = e[0]
            o = BURE(ma, name, e[1], R_bu_fn(end_fn, name), -5.6, is_fin = True)
            oo[name] = o
            line.append(o)

    def get_bo_main(self):
        bg      = self.bo["bg"]
        d       = self.bu_border
        h       = self.bu_hi
        dist    = self.bu_dist

        bg.inset_with_depth(self.box["main"], F[2])
        L   = bg.L + d
        R   = bg.R - d
        T   = bg.T - d
        B   = T - h

        blf_size(font_0, self.bu_tx_si)
        for o in self.line:
            o.LRBT(L, R, B, T)
            T = B - dist
            B = T - h

    def R_bu_fn(self, func, name):
        def bu_fn():
            TM["job"] = name
            func()
        return bu_fn

    def I_draw(self):
        BLEND()
        box = self.box

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()

        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        self.tit["bu_x"].set_draw_id(font_1)
        self.tit["ti"].set_draw()

        blf_size(font_0, self.bu_tx_si)
        for e in self.oo.values():   e.draw_ti()

        m.FLASH_BOX.U_draw()


class MENU_MOD_LINK(MESS):
    __slots__ = (
        'line',
        'bu_hi',
        'bu_border',
        'bu_tx_si',
        'bu_dist',
    )
    name = "Menu Mod Link"

    def __init__(self, x, y, lis_bu, bu_x_fn):
        TM["lis_bu"]    = lis_bu
        TM["bu_x_fn"]   = bu_x_fn
        TM["job"]       = False
        self.bu_hi      = F[20]
        self.bu_border  = F[8]
        self.bu_tx_si   = F[10]
        self.bu_dist    = F[6]

        super().__init__(x, y, "",
            offset      = True,
            hide_tb     = True,
            width       = P.scale[0] * 250,
            height      = 6 * (self.bu_hi + self.bu_dist) + (
                self.bu_border + F[2] + F[1]) * 2 + F[-1] - self.bu_dist
        )
    def init_D1(self, evt):
        super().init_D1(evt)

        end_fn = TM["bu_x_fn"]

        def bu_x_fn():
            self.fin()
            end_fn()

        self.bu_x_fn    = bu_x_fn

        ma      = self.main_area

        BURE        = bu.BURE
        BU_BOOL     = bu.BU_BOOL
        oo          = self.oo
        oo.clear()
        line        = []
        self.line   = line
        R_bu_fn     = self.R_bu_fn

        self.tit["ti"].text = "Menu"
        for e in TM["lis_bu"]:
            name = e[0]
            o = BURE(ma, name, e[1], R_bu_fn(end_fn, name), -5.6, is_fin = True)
            oo[name] = o
            line.append(o)

        o = BU_BOOL(ma, "bu_kf", "Keep Keyframe")
        o.set_da(True)
        oo["bu_kf"] = o

        o = BU_BOOL(ma, "bu_dr", "Keep Driver")
        o.set_da(True)
        oo["bu_dr"] = o

    def get_bo_main(self):
        bg      = self.bo["bg"]
        d       = self.bu_border
        h       = self.bu_hi
        dist    = self.bu_dist

        bg.inset_with_depth(self.box["main"], F[2])
        L   = bg.L + d
        R   = bg.R - d
        T   = bg.T - d
        B   = T - h

        blf_size(font_0, self.bu_tx_si)
        for o in self.line:
            o.LRBT(L, R, B, T)
            T = B - dist
            B = T - h
        
        o = self.oo["bu_kf"]
        o.ti.set_size()
        R = self.line[0].rim.R
        B -= F[2]
        o.RB(R, B)

        B -= h
        o = self.oo["bu_dr"]
        o.RB(R, B)

    def R_bu_fn(self, func, name):
        def bu_fn():
            TM["job"] = name
            func()
        return bu_fn

    def I_draw(self):
        BLEND()
        box = self.box
        oo = self.oo

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()

        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in oo.values():   e.draw_rim()
        for e in oo.values():   e.draw_bg()

        self.tit["bu_x"].set_draw_id(font_1)
        self.tit["ti"].set_draw()

        blf_size(font_0, self.bu_tx_si)
        oo["bu_move"].draw_ti()
        oo["bu_copy"].draw_ti()
        oo["bu_link"].draw_ti()
        oo["bu_dlink"].draw_ti()
        oo["bu_kf"].draw_ti()
        oo["bu_dr"].draw_ti()

        m.FLASH_BOX.U_draw()


class A_STATUS:
    __slots__ = (
        'w',
        'bo',
        'ti',
        'oo',
        'oo_ok',
        'U_draw',
        'U_modal',
    )
    def __init__(self, w):
        self.w = w
        self.bo = {}
        self.ti = {}
        self.oo = {}
        self.U_draw = self.I_draw
        self.U_modal = self.I_modal_main

    def to_modal(self, e):
        self.U_modal = e
    def to_modal_default(self):
        self.U_modal = self.I_modal_main
    def dxy(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.oo.values():  e.dxy(x, y)
        self.oo_ok.dxy(x, y)
        self.ti["info"].dxy(x, y)
    def unfocus(self):
        if self.U_modal == self.I_modal_main: return
        self.U_modal.__self__.outside()
        self.U_modal = self.I_modal_main

    def I_modal_main(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        e = self.oo_ok
        if e.is_inside(x, y):
            e.inside(evt)
            return True
        return False

    def I_draw(self):
        oo = self.oo
        oo_values = oo.values()

        BLEND()
        self.bo["bg"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in oo_values:     e.draw_box()
        self.oo_ok.draw_box()

        blf_size(font_0, F[9])
        for e in oo_values:     e.draw_blf()
        self.ti["info"].draw_color_pos()

        blf_size(font_0, F[12])
        self.oo_ok.draw_blf()
    #
    #
class A_DATA(AREA):
    __slots__ = ()
    def R_bo_data(self): return self.w.bo["bg"]
    def get_data(self): self.oo_keys = [cls(self)  for cls in TM["oo_keys"]]
    def upd_data(self): pass
class MENU_STANDARD(win.WIN):
    __slots__ = (
        'w',
        'oo',
        'A_data',
        'is_confirm',
        'A_status',
        'wi_max',
        'bg_wi',
        'hide_tb',
        'bg_fo',
        'tx_wi',
    )
    name = "Standard Menu"

    def __init__(self, w, oo_keys,
        title="Menu",
        x=None,
        y=None,
        high=None,
        wi_max=None,
        end_fn=None,
        hide_tb=False,
    ):
        self.w              = w
        self.is_confirm     = False
        self.hide_tb        = hide_tb
        self.A_status       = A_STATUS(self)
        TM["bu_x_fn"]       = end_fn
        TM["title"]         = title
        TM["high"]          = high
        TM["oo_keys"]       = oo_keys
        self.wi_max         = F[300]  if wi_max is None else wi_max

        evt = m.EVT.evt
        if x is None:   x = evt.mouse_region_x
        if y is None:   y = evt.mouse_region_y

        super().__init__((x, y), region=False)
        if hide_tb:     m.admin.tb.disable()
        m.admin.tb.U_modal = m.NF
        self.tx_wi      = round(self.box["main"].R_w() - F[20])
        bpy.context.window.cursor_modal_set('DEFAULT')

        # self.default_modal = self.I_default_modal
        self.fit_win(F[2])
    def fin(self):

        m.M.restore_mou_ic()
        m.W_A.remove(self)
        m.W_D.remove(self)
        m.W_M.remove(self)
        m.FLASH_BOX.kill()
        self.U_kill_thread()

        self.fin_D1()

        m.EVT.kill()
        if self.hide_tb:    m.admin.tb.enable()
        m.admin.tb.U_modal = m.admin.tb.I_modal_outside
        m.redraw()
    def fin_D1(self):   pass
    def init_D1(self, evt):
        end_fn = TM["bu_x_fn"]
        def bu_x_fn():
            self.fin()
            if end_fn is not None:  end_fn()
        def bu_x_fn_ok():
            self.is_confirm = True
            bu_x_fn()

        self.bu_x_fn = bu_x_fn
        rd  = m.region_data

        self.bg_fo  = BOX(P.color_bg_fo, 0, rd.R - rd.border.R, 0, rd.T - rd.border.T)
        self.bg_fo.upd()
        self.bo     = {"bg": BOX(P.color_oj_info)}
        self.ti     = {}
        self.da     = {}
        self.oo     = {}

        x, y = evt
        dx = F[150]
        dy = F[61]
        width = dx * 2
        height = dy * 2

        self.box["rim"].LRBTd(x - dx, x + dx, y - dy, y + dy, F[1])
        x, y = m.IR_protect_pos(self.box["rim"], F[-1])
        self.box["rim"].LRBTd(x, x + width, y - height, y, F[1])

        self.U_init_thread  = self.I_init_thread
        self.U_kill_thread  = N
        self.tit["ti"].text = TM["title"]

        self.cv.R_w = self.bo["bg"].R_w
        self.cv.R_h = self.cv_R_h
        self.upd_data = self.I_upd_data

        self.A_data = A_DATA(self)

        A_status    = self.A_status
        st_bo       = A_status.bo
        st_ti       = A_status.ti
        st_oo       = A_status.oo

        oo_ok = BUTTON20(A_status, rna_ok)
        oo_ok.fx = bu_x_fn_ok
        A_status.oo_ok = oo_ok

        st_bo["bg"] = BOX(P.color_status_bar_bg)
        st_ti["info"] = BLF(P.color_font_darker)

        blf_size(font_0, F[9])
        self.bg_wi = self.wi_max + F[46] if self.wi_max > F[300] - F[46] else F[300]

    def get_bo_main(self):
        bo      = self.bo
        da      = self.da
        _2      = F[2]
        _3      = F[3]
        _12     = F[12]
        _16     = F[16]

        A_status    = self.A_status
        st_bo       = A_status.bo
        st_ti       = A_status.ti
        st_oo       = A_status.oo
        box_main    = self.box["main"]

        x = box_main.L + _2 - self.cv.x
        y = box_main.T - _2 + self.cv.y

        high = TM["high"]
        if high == None:    high = 2147483647
        bo["bg"].LRBT(x, x + self.bg_wi, y - high, y)
        blf_size(font_0, F[9])
        A_data = self.A_data
        A_data.__init__(self)
        if TM["high"] == None:
            bo["bg"].B = A_data.li[A_data.endkey].rim.B

        blf_size(font_0, _12)
        cx = box_main.R_center_x()
        BB = box_main.B
        B = BB + F[10]
        T = B + F[20]
        A_status.oo_ok.get_bo(cx - F[34], cx + F[34], B, T)
        blf_size(font_0, F[9])
        B = T + F[6]
        T = B + _16
        L = box_main.L + _12
        R = L + F[61]

        bg = st_bo["bg"]
        bg.LRBT_upd(box_main.L, box_main.R, BB, T + _12)
        st_ti["info"].xy(bg.L + F[12], bg.T - F[17])

    def dxy_upd_main(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.da.values():  e.dxy(x, y)
        # for e in self.oo.values():  e.dxy_upd(x, y)

        self.A_data.dxy_upd(x, y)

        A_status = self.A_status
        e = A_status.bo["bg"]
        o = self.box["main"]
        A_status.dxy(o.L - e.L, o.B - e.B)

    def glopan_upd(self):
        self.A_data.upd_sci()
    def I_modal_glopan_end_D1(self):

        self.I_upd_data()
    def modal_mov_end_D1(self):

        pass
    def cv_R_h(self):
        return self.bo["bg"].R_h() + self.A_status.bo["bg"].R_h()
    def upd_cv_lim(self):
        border2 = F[2] * 2
        self.cv.lim_x = self.cv.R_w() + border2 - self.box["main"].R_w()
        self.cv.lim_y = self.cv.R_h() + border2 - self.box["main"].R_h()
        if self.cv.lim_x < 0:   self.cv.lim_x = 0
        if self.cv.lim_y < 0:   self.cv.lim_y = 0

    def I_modal_main(self, evt):
        if K["cancel0"].true() or K["cancel1"].true():  self.bu_x_fn()  ;return
        if K["confirm0"].true() or K["confirm1"].true():
            self.is_confirm = True
            self.bu_x_fn()
            return

        if self.box["ti"].inbox(evt):
            if self.box["bu_x"].inbox(evt):
                self.U_modal = self.I_modal_x
                self.modal_x(evt)
                self.box["bu_x"].color = P.color_ti_bu_x
                m.redraw()  ;return
            if self.box["bu_fit"].inbox(evt):
                self.U_modal = self.I_modal_fit
                self.modal_fit(evt)
                self.box["bu_fit"].color = P.color_ti_bu_fo
                m.redraw()  ;return
            if m.U_resize_evt(self, evt):   return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.to_modal_mov(evt)
                return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.to_modal_mov(evt)
                return

            self.outside_evt(evt)
        elif self.box["main"].inbox(evt):
            if m.U_resize_evt(self, evt):   return
            if evt.mouse_region_y <= self.A_status.bo["bg"].T:
                self.A_status.U_modal(evt)
                return
            self.A_data.U_modal(evt)
        else:
            self.outside_evt(evt)
            if evt.value == 'PRESS':
                if m.thread_isreg(m.flash_box_thread_fn):   return
                box = self.box
                m.FLASH_BOX.init(box["rim"].L, box["rim"].R, box["rim"].B, box["rim"].T)
    def modal_main_area(self, evt):
        return False

    def modal_mov_end(self):
        dx, dy = m.R_protect_dxy_LT(self.box["rim"], F[-1])
        if dx != 0 or dy != 0:  self.dxy_upd(dx, dy)
        del m.head_modal[-1]

        m.EVT.kill()
        m.EVT.U_ENABLE_evt()
        m.redraw()

    def evt_x(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.box["bu_x"].color = self.color.ti_bu
                self.tit["bu_x"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.EVT.kill()
                if self.box["bu_x"].inbox(evt):  self.bu_x_fn()
                return
        m.tm["fn"](evt)
    def evt_fit(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                if self.box["bu_fit"].inbox(evt):
                    self.fit_win(F[2])
                self.box["bu_fit"].color = self.color.ti_bu
                self.tit["bu_fit"].color = self.color.ti_bu_sh
                self.U_modal = self.I_modal_main
                m.redraw()
                m.init_wait_release()
                return
        m.tm["fn"](evt)

    def outside_evt(self, evt):
        self.A_data.unfocus()
        self.A_status.unfocus()
    def title_evt(self, evt):
        self.A_data.unfocus()
        self.A_status.unfocus()

    def I_draw(self):
        BLEND()
        box = self.box
        tit = self.tit

        self.bg_fo.bind_draw()
        box["shade"].draw()
        box["rim"].bind_draw()          ;box["ti"].bind_draw()
        box["main"].bind_draw()         ;box["bu_x"].bind_draw()
        box["bu_fit"].bind_draw()

        self.sci.ENABLE()
        self.bo["bg"].bind_draw()
        self.A_data.U_draw()
        # m.bind_color_bu_1_rim()
        # oo_values = self.main_area.oo.values()
        # for e in oo_values:     e.draw_box()

        # blf_size(font_0, F[9])
        # for e in oo_values:     e.draw_blf()

        # for e in self.da.values():  e.set_draw()

        self.sci.ENABLE()
        self.A_status.U_draw()

        DISABLE_SCISSOR()
        tit["bu_x"].set_draw_id(font_1)
        tit["bu_fit"].set_draw_id(font_1)
        tit["ti"].set_draw()
        m.FLASH_BOX.U_draw()

    def I_upd_data(self): pass


rna_ok = RNA_STR("Confirm", "Confirm Button", "Confirm")
