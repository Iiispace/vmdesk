_info = {
    "name" : "vmdesk",
    "author" : "LAW.Y.T",
    "version" : (1, 2, 1),
    "blender" : (4, 2),
    "location" : "View3d > Tool",
    "warning" : "",
    "description" : "Requirement: blender 4.2",
    "wiki_url" : "",
    "category" : "3D View",
}

if "bpy" in locals():
    _is_reload = True


    #######
    from importlib import reload
    from ..  import VMD
    reload(VMD)
    # 1forfile (_allfile_,, $lambda _file_, _cls_: f'{"#" if _file_[1] == "_" else "reload"}(VMD.{_file_[ 1 : -3].replace(chr(92), ".")})\n'$)

    reload(VMD.api)
    reload(VMD.util.txt)
    reload(VMD.util.types)
    reload(VMD.util.num)
    reload(VMD.util.deco)
    reload(VMD.util.const)
    reload(VMD.util.com)
    reload(VMD.util.dirlib)
    reload(VMD.util.filtexp)
    reload(VMD.util.algebra)

    reload(VMD.utilbl.glshader)
    reload(VMD.utilbl.pymath)
    reload(VMD.utilbl.ops)
    reload(VMD.utilbl.calc)
    reload(VMD.utilbl.general)
    reload(VMD.utilbl.md)
    reload(VMD.utilbl.mesh)
    reload(VMD.utilbl.blg)

    reload(VMD.evals.evalbatchoperation)
    reload(VMD.evals.evalcopytoselected)
    reload(VMD.evals.evalmdlib)
    reload(VMD.evals.evalutil)

    reload(VMD.colorlist)
    reload(VMD.keysys)
    reload(VMD.prefs)
    reload(VMD.npanel)
    reload(VMD.userops)
    reload(VMD.rna)
    reload(VMD.handle)
    reload(VMD.win)
    reload(VMD.area)
    reload(VMD.block)
    reload(VMD.dd)
    reload(VMD.m)

    reload(VMD.apps.dreditor.ed)
    reload(VMD.apps.dreditor.prop)
    reload(VMD.apps.mdeditor.areas)
    reload(VMD.apps.mdeditor.ed)
    reload(VMD.apps.mesheditor.ed)
    reload(VMD.apps.mesheditor.ops)
    reload(VMD.apps.mesheditor.prop)
    reload(VMD.apps.settingeditor.areas)
    reload(VMD.apps.settingeditor.ed)













    #######
else:
    _is_reload = False

import bpy
# from bpy.app.handlers import persistent
from ..  import VMD

# //* 0__init__reg
# *//
# <<< 1copy (0__init__reg,, ${'NAME':'mesheditor'}$)
def reg_mesheditor():
    try:
        from . apps.mesheditor.ops import register_ops
    except: return

    for e in register_ops:
        register_class(e)
        OPERATORS.append(e)
def unreg_mesheditor():
    try:
        from . apps.mesheditor.ops import register_ops
    except: return

    for e in register_ops:
        unregister_class(e)
# >>>

def register():
    if _is_reload is True:
        bpy.app.timers.register(late_register)
    else:
        bpy.app.handlers.version_update.append(late_register)

def late_register(*k, **kw):
    (print("register()"))
    #|
    from bpy.utils import register_class, unregister_class
    from bpy.props import (
        BoolProperty,
        IntProperty,
        FloatProperty,
        StringProperty,
        FloatVectorProperty,
        PointerProperty)
    from bpy.types import (
        Object,
        NodeTreeInterfaceSocket,
        NodeTreeInterfaceSocketColor,
        NodeTreeInterfaceSocketRotation)

    ## /* clear_repeat
    from .  import m
    from .  import userops
    from .  import handle
    from .  import keysys
    from .  import rna, userops, prefs, npanel, area, dd, block, win
    from . handle import load_post, load_pre, bl_unload, BL_INFO
    from . util.const import FLOAT_min, FLOAT_max
    from . utilbl import blg, general, md

    # <<< 1forfile (_reg_,, $lambda _file_, _cls_: f'from . {_file_[1 : _file_.rfind(chr(92))].replace(".py", ""
    #     ).replace(chr(92), ".")} import {_file_[_file_.rfind(chr(92)) + 1 :].replace(".py", "")}\n'$)
    from .  import prefs
    from . utilbl import ops
    # >>>
    from . apps.mesheditor.ed import MeshEditor
    # <<< 1forfile (_import_first_,, $lambda _file_, _cls_: 'from . ' + _file_[1 : _file_.rfind("\\")].replace(".py", ""
    #     ).replace("\\", ".") + ' import ' + _file_[_file_.rfind("\\") + 1 :].replace(".py", ""
    #     ) + '\n    ' + _file_[_file_.rfind("\\") + 1 :].replace(".py", ""
    #     ) + '._import_first_()\n'$)
    userops._import_first_()
    ## */
    OPERATORS = []

    globals().update(locals())

    for k, e in _info.items(): BL_INFO[k] = e

    # <<< 1forfile (_reg_,, $lambda _file_, _cls_: f'register_class({_file_[_file_.rfind(
    #     chr(92)) + 1 :].replace(".py", "")}.{_cls_})\n'$)
    register_class(m.Blocking)
    register_class(m.Admin)
    register_class(prefs.PrefsModifierEditor)
    register_class(prefs.PrefsDriverEditor)
    register_class(prefs.PrefsSettingEditor)
    register_class(prefs.PrefsMeshEditor)
    register_class(prefs.PrefsKey)
    register_class(prefs.PrefsSize)
    register_class(prefs.PrefsColor)
    register_class(prefs.PrefsTemp)
    register_class(prefs.Prefs)
    register_class(ops.OpInternal)
    register_class(ops.OpBevelProfile)
    register_class(ops.OpFalloffCurve)
    register_class(ops.OpColorRamp)
    register_class(ops.OpScanFile)
    register_class(ops.OpScanFolder)
    register_class(ops.OpsIDPreview)
    register_class(ops.OpsWrapperRelease)
    # >>>

    # <<< 1copy (assignP,, $$)
    P = bpy.context.preferences.addons[__package__].preferences
    # >>>
    if P.npanel_reg_settings:
        registered_classes_npanel = [
            npanel.VmdPanel,
            npanel.VmdPanelTemp,
            npanel.VmdPanelGeneral,
            npanel.VmdPanelSize,
            npanel.VmdPanelColor,
            npanel.VmdPanelModifierEditor,
            npanel.VmdPanelSettingEditor,
        ]
    else:
        registered_classes_npanel = [
            npanel.VmdPanel,
            npanel.VmdPanelTemp,
        ]
    late_register.registered_classes_npanel = registered_classes_npanel
    for e in registered_classes_npanel:
        register_class(e)

    for e in userops.register_ops:
        register_class(e)
        OPERATORS.append(e)

    reg_mesheditor()

    m.OPERATORS[:] = OPERATORS

    # ---------------------------------------------------------------------------------------------------------














    # ---------------------------------------------------------------------------------------------------------

    handlers = bpy.app.handlers
    if load_post not in handlers.load_post: handlers.load_post.append(load_post)
    if load_pre not in handlers.load_pre: handlers.load_pre.append(load_pre)

    # Object.vmd_offset = FloatVectorProperty(name="Distance", options=set(), subtype="TRANSLATION", unit="LENGTH")
    NodeTreeInterfaceSocket.vmd_is_radian = BoolProperty(name="Is Radian", options=set())
    NodeTreeInterfaceSocketColor.min_value = FloatProperty(default=0.0, options=set())
    NodeTreeInterfaceSocketColor.max_value = FloatProperty(default=FLOAT_max, options=set())
    NodeTreeInterfaceSocketColor.subtype = StringProperty(default="NONE", options=set())
    NodeTreeInterfaceSocketRotation.min_value = FloatProperty(default=FLOAT_min, options=set())
    NodeTreeInterfaceSocketRotation.max_value = FloatProperty(default=FLOAT_max, options=set())
    NodeTreeInterfaceSocketRotation.subtype = StringProperty(default="EULER", options=set())

    # m.REFDRIVERS = {}
    handle._import_()
    handle.bl_load()
    m._import_()
    handle.TAG_UPDATE = m.TAG_UPDATE

    keysys._import_()
    keysys.init_keymaps(m.P)
    keysys.init_calc_exp(m.P)
    m.UnitSystem.update()

    blg._import_()
    m._import_size_()

    rna._import_()
    general._import_()
    userops._import_()
    prefs._import_()
    npanel._import_()
    md._import_()
    area._import_()
    block._import_()
    dd._import_()
    win._import_()

    m._import_lv2_()
    from . apps.settingeditor import areas, ed
    areas._import_lv2_()
    ed._import_lv2_()
    from . apps.mdeditor import areas, ed
    areas._import_lv2_()
    ed._import_lv2_()
    from . apps.dreditor import ed, prop
    ed._import_lv2_()
    prop._import_lv2_()

    from . apps.mesheditor import prop, ops, ed
    ed._import_lv2_standard_()
    ops._import_lv2_standard_()
    prop._import_lv2_standard_()

    handle.newfile_event()












    #|

def unregister():

    #|
    from bpy.utils import unregister_class

    # <<< 1forfile (_reg_,, $lambda _file_, _cls_: f'unregister_class({_file_[_file_.rfind(
    #     chr(92)) + 1 :].replace(".py", "")}.{_cls_})\n'$)
    unregister_class(m.Blocking)
    unregister_class(m.Admin)
    unregister_class(prefs.PrefsModifierEditor)
    unregister_class(prefs.PrefsDriverEditor)
    unregister_class(prefs.PrefsSettingEditor)
    unregister_class(prefs.PrefsMeshEditor)
    unregister_class(prefs.PrefsKey)
    unregister_class(prefs.PrefsSize)
    unregister_class(prefs.PrefsColor)
    unregister_class(prefs.PrefsTemp)
    unregister_class(prefs.Prefs)
    unregister_class(ops.OpInternal)
    unregister_class(ops.OpBevelProfile)
    unregister_class(ops.OpFalloffCurve)
    unregister_class(ops.OpColorRamp)
    unregister_class(ops.OpScanFile)
    unregister_class(ops.OpScanFolder)
    unregister_class(ops.OpsIDPreview)
    unregister_class(ops.OpsWrapperRelease)
    # >>>

    for e in late_register.registered_classes_npanel:
        unregister_class(e)
    for e in userops.register_ops:
        unregister_class(e)

    unreg_mesheditor()

    # ---------------------------------------------------------------------------------------------------------












    # ---------------------------------------------------------------------------------------------------------

    handlers = bpy.app.handlers
    if load_post in handlers.load_post: handlers.load_post.remove(load_post)
    if load_pre in handlers.load_pre: handlers.load_pre.remove(load_pre)

    bl_unload()
    m.P = None
    m.ADMIN = None
    #|

