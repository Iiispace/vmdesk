











import bpy
from bpy.utils import escape_identifier
from blf import size as blfSize
from blf import color as blfColor
from blf import position as blfPos
from blf import draw as blfDraw
from blf import dimensions as blfDimen
from bpy.types import (
    CacheFile,
    UVProjector,
    GreasePencilTimeModifierSegment,
    GreasePencilDashModifierSegment)
from math import ceil

from ... area import StructAreaModal, AreaBlockTab
from ... util.types import RnaButton

ed_undo_push = bpy.ops.ed.undo_push
UVProjector_bl_rnas = UVProjector.bl_rna.properties

def update_scene_and_ref():
    update_scene()
    upd_link_data()
    #|

def gn_format(format_codes):
    indent = None
    sep = None
    align = None

    for code in format_codes[1 : ]:
        code = code.strip()
        if code[ : 1] == "#" and code[-1 :] in STR_09:
            indent = int(code[-1 :])
        elif code[ : 4] == "sep(" and code[-1 :] == ")":
            try: sep = float(code[4 : -1])
            except: pass
        elif code[ : 6] == "align(" and code[-1 :] == ")":
            align = code[6 : -1].strip()

    return indent, sep, align
    #|


class AreaBlockTabModifierEditor(AreaBlockTab):
    __slots__ = 'object_fcurves', 'object_drivers', 'upd_data_callback', 'evalcode'

    def rr_fcurve_driver(self, attr):
        def r_fcurve():
            if self.object_fcurves:
                return self.object_fcurves.find(f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].{attr}')
            return None
        def r_driver():
            if self.object_drivers:
                return self.object_drivers.find(f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].{attr}')
            return None
        return r_fcurve, r_driver
        #|
    def rr_fcurve_driver_array(self, attr, array_range):
        array_length = len(array_range)

        def r_fcurve():
            if self.object_fcurves:
                dp = f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].{attr}'
                return [self.object_fcurves.find(dp, index=r)  for r in array_range]
            return [None] * array_length
        def r_driver():
            if self.object_drivers:
                dp = f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].{attr}'
                return [self.object_drivers.find(dp, index=r)  for r in array_range]
            return [None] * array_length
        return r_fcurve, r_driver
        #|
    def rr_fcurve_driver_gn(self, attr, array_range=False):
        if array_range:
            array_length = len(array_range)

            def r_fcurve():
                if self.object_fcurves:
                    dp = f'modifiers["{escape_identifier(self.w.active_modifier_name)}"]["{escape_identifier(attr)}"]'
                    return [self.object_fcurves.find(dp, index=r)  for r in array_range]
                return [None] * array_length
            def r_driver():
                if self.object_drivers:
                    dp = f'modifiers["{escape_identifier(self.w.active_modifier_name)}"]["{escape_identifier(attr)}"]'
                    return [self.object_drivers.find(dp, index=r)  for r in array_range]
                return [None] * array_length
        else:
            def r_fcurve():
                if self.object_fcurves:
                    return self.object_fcurves.find(f'modifiers["{escape_identifier(self.w.active_modifier_name)}"]["{escape_identifier(attr)}"]')
                return None
            def r_driver():
                if self.object_drivers:
                    return self.object_drivers.find(f'modifiers["{escape_identifier(self.w.active_modifier_name)}"]["{escape_identifier(attr)}"]')
                return None
        return r_fcurve, r_driver
        #|
    def rr_fcurve_driver_object(self, attr):
        def r_fcurve():
            if self.object_fcurves:
                return self.object_fcurves.find(attr)
            return None
        def r_driver():
            if self.object_drivers:
                return self.object_drivers.find(attr)
            return None
        return r_fcurve, r_driver
        #|
    def rr_refdriver(self, attr):
        def r_refdriver():
            if self.object_drivers:
                return self.object_drivers.find(f'["modifiers[\\\"{escape_identifier(self.w.active_modifier_name)}\\\"].{attr}"]')
            return None
        return r_refdriver
        #|
    def r_datapath_head(self, full=False):
        if full:
            return f'{r_ID_dp(self.w.active_object)}.modifiers["{escape_identifier(self.w.active_modifier_name)}"].'
        return f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].'
        #|
    def r_datapath_head_gn(self, full=False):
        if full:
            return f'{r_ID_dp(self.w.active_object)}.modifiers["{escape_identifier(self.w.active_modifier_name)}"]'
        return f'modifiers["{escape_identifier(self.w.active_modifier_name)}"]'
        #|
    def r_datapath_head_object(self, full=False):
        if full:
            return f'{r_ID_dp(self.w.active_object)}.'
        return ""
        #|
    def r_modifier(self): return self.w.active_modifier
    def r_object(self): return self.w.active_object
    def r_object_set(self): return {self.w.active_object}

    def init_tab_ARMATURE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0_buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"ARMATURE"}), rr_refdriver("object")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            ButtonSep(2),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_deform_preserve_volume"], pp), *rr_fcdr("use_deform_preserve_volume")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_multi_modifier"], pp), *rr_fcdr("use_multi_modifier")),
            ButtonSep(2),
            ButtonGroupAnimRefAlignLR(b0, ButtonBoolPush(None, rnas["use_vertex_groups"], pp), rr_refdriver("use_vertex_groups"), title="Vertex Groups", title_head="Bind To"),
            ButtonGroupAnimRefAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_bone_envelopes"], pp), rr_refdriver("use_bone_envelopes"), title="Bone Envelopes"),
        ]
        b0.buttons = b0_buttons

        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_ARRAY(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_relative_offset"], pp), *rr_fcdr("use_relative_offset"))
        )
        g_relative_offset_displace = ButtonGroupAnimVector(b1, ButtonFloatVectorPush(None, rnas["relative_offset_displace"], pp), *rr_fcdr_array("relative_offset_displace", RANGE_3), title="Factor")
        b1.items = [g_relative_offset_displace]

        b2 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_constant_offset"], pp), *rr_fcdr("use_constant_offset"))
        )
        g_constant_offset_displace = ButtonGroupAnimVector(b2, ButtonFloatVectorPush(None, rnas["constant_offset_displace"], pp), *rr_fcdr_array("constant_offset_displace", RANGE_3), title="Distance")
        b2.items = [g_constant_offset_displace]

        b3 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_object_offset"], pp), *rr_fcdr("use_object_offset"))
        )
        g_offset_object = ButtonGroupAnimRef(b3, ButtonEnumObjectPush(None, rnas["offset_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("offset_object"), title="Object")
        b3.items = [g_offset_object]

        b4 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_merge_vertices"], pp), *rr_fcdr("use_merge_vertices"), title="Merge")
        )
        g_merge_threshold = ButtonGroupAnim(b4, ButtonFloatPush(None, rnas["merge_threshold"], pp), *rr_fcdr("merge_threshold"), title="Distance")
        g_use_merge_vertices_cap = ButtonGroupAnim(b4, ButtonBoolPush(None, rnas["use_merge_vertices_cap"], pp), *rr_fcdr("use_merge_vertices_cap"), title="First and Last Copies")
        b4.items = [g_merge_threshold, g_use_merge_vertices_cap]

        b5 = BlockUtil(self, None, Title("UVs"))
        b5.items = [
            ButtonGroupAnim(b5, ButtonFloatPush(None, rnas["offset_u"], pp), *rr_fcdr("offset_u"), title="Offset U"),
            ButtonGroupAnim(b5, ButtonFloatPush(None, rnas["offset_v"], pp), *rr_fcdr("offset_v"), title="Offset V"),
        ]

        b6 = BlockUtil(self, None, Title("Caps"))
        b6.items = [
            ButtonGroupAnimRef(b6, ButtonEnumObjectPush(None, rnas["start_cap"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("start_cap")),
            ButtonGroupAnimRef(b6, ButtonEnumObjectPush(None, rnas["end_cap"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("end_cap"))
        ]

        self.items[:] = [b0, b1, b2, b3, b4, b5, b6]

        bu_fit_type = ButtonEnumPush(None, rnas["fit_type"], pp)
        g_count = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["count"], pp), *rr_fcdr("count"))
        g_fit_length = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["fit_length"], pp), *rr_fcdr("fit_length"))
        g_curve = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["curve"], pp, {"CURVE"}), rr_refdriver("curve"))

        b0_buttons = [
            ButtonGroupAnim(b0, bu_fit_type, *rr_fcdr("fit_type")),
            g_count
        ]
        b0.buttons = b0_buttons

        def upd_data_callback():
            modifier = self.w.active_modifier
            if modifier.fit_type == "FIXED_COUNT":
                if b0_buttons[1] != g_count:
                    b0_buttons[1] = g_count
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            elif modifier.fit_type == "FIT_LENGTH":
                if b0_buttons[1] != g_fit_length:
                    b0_buttons[1] = g_fit_length
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            elif modifier.fit_type == "FIT_CURVE":
                if b0_buttons[1] != g_curve:
                    b0_buttons[1] = g_curve
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

            if modifier.use_relative_offset:
                if g_relative_offset_displace.is_dark() is True: g_relative_offset_displace.light()
            else:
                if g_relative_offset_displace.is_dark() is False: g_relative_offset_displace.dark()

            if modifier.use_constant_offset:
                if g_constant_offset_displace.is_dark() is True: g_constant_offset_displace.light()
            else:
                if g_constant_offset_displace.is_dark() is False: g_constant_offset_displace.dark()

            if modifier.use_object_offset:
                if g_offset_object.is_dark() is True: g_offset_object.light()
            else:
                if g_offset_object.is_dark() is False: g_offset_object.dark()

            if modifier.use_merge_vertices:
                if g_merge_threshold.is_dark() is True:
                    g_merge_threshold.light()
                    g_use_merge_vertices_cap.light()
            else:
                if g_merge_threshold.is_dark() is False:
                    g_merge_threshold.dark()
                    g_use_merge_vertices_cap.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_BEVEL(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_width = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["width"], pp), *rr_fcdr("width"))
        g_width_pct = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["width_pct"], pp), *rr_fcdr("width_pct"))
        g_angle_limit = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["angle_limit"], pp), *rr_fcdr("angle_limit"))
        g_vertex_group = ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_invert_vertex_group_fake = ButtonSep(0)
        b0_buttons = [
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["affect"], pp, row_length=2), *rr_fcdr("affect")),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["offset_type"], pp), *rr_fcdr("offset_type")),
            g_width,
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["segments"], pp), *rr_fcdr("segments")),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["limit_method"], pp), *rr_fcdr("limit_method")),
            g_angle_limit,
            g_invert_vertex_group_fake,
        ]
        b0.buttons = b0_buttons
        bu_affect_box = b0_buttons[0].button0.box_button[0]

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonEnumXYPush(None, rnas["profile_type"], pp, row_length=2), *rr_fcdr("profile_type"))
        )
        g_profile = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["profile"], pp), *rr_fcdr("profile"), title="Shape")
        g_edit_profile = ButtonFnPush(b1, RNA_edit_profile, self.bufn_BEVEL_edit_profile)
        b1.items = [ButtonSplit(b1, g_edit_profile, g_profile, gap=r_button_h, factor=0.35)]
        bu_profile_type_box = b1.button0.button0.box_button[0]

        b2 = BlockUtil(self, None, Title("Geometry"))
        g_miter_outer = ButtonGroupAnim(b2, ButtonEnumPush(None, rnas["miter_outer"], pp), *rr_fcdr("miter_outer"), title="Miter Outer")
        g_miter_inner = ButtonGroupAnim(b2, ButtonEnumPush(None, rnas["miter_inner"], pp), *rr_fcdr("miter_inner"), title="Inner")
        g_spread = ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["spread"], pp), *rr_fcdr("spread"))
        g_vmesh_method = ButtonGroupAnim(b2, ButtonEnumPush(None, rnas["vmesh_method"], pp), *rr_fcdr("vmesh_method"), title="Intersections")
        g_loop_slide = ButtonGroupAnimAlignTitleLeft(b2, ButtonBoolPush(None, rnas["loop_slide"], pp), *rr_fcdr("loop_slide"))
        b2.items = [
            g_miter_outer,
            g_miter_inner,
            g_spread,
            ButtonSep(2),
            g_vmesh_method,
            ButtonGroupAnimAlignTitleLeft(b2, ButtonBoolPush(None, rnas["use_clamp_overlap"], pp), *rr_fcdr("use_clamp_overlap")),
            g_loop_slide
        ]

        b3 = BlockUtil(self, None, Title("Shading"))
        g_mark_seam = ButtonGroupAnimAlignLR(b3, ButtonBoolPush(None, rnas["mark_seam"], pp), *rr_fcdr("mark_seam"), title="Seam", title_head="Mark")
        g_mark_sharp = ButtonGroupAnimAlignTitleLeft(b3, ButtonBoolPush(None, rnas["mark_sharp"], pp), *rr_fcdr("mark_sharp"), title="Sharp")
        b3.items = [
            ButtonGroupAnimAlignTitleLeft(b3, ButtonBoolPush(None, rnas["harden_normals"], pp), *rr_fcdr("harden_normals")),
            ButtonSep(2),
            g_mark_seam,
            g_mark_sharp,
            ButtonSep(2),
            ButtonGroupAnim(b3, ButtonIntPush(None, rnas["material"], pp), *rr_fcdr("material")),
            ButtonGroupAnim(b3, ButtonEnumPush(None, rnas["face_strength_mode"], pp), *rr_fcdr("face_strength_mode")),
        ]

        self.items[:] = [b0, b1, b2, b3]

        def upd_data_callback():
            modifier = self.w.active_modifier
            if modifier.offset_type == "PERCENT":
                if b0_buttons[2] != g_width_pct:
                    b0_buttons[2] = g_width_pct
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            else:
                if b0_buttons[2] != g_width:
                    b0_buttons[2] = g_width
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

            if modifier.limit_method == "VGROUP":
                if b0_buttons[6] != g_vertex_group:
                    b0_buttons[6] = g_vertex_group
                    b0_buttons[7] = g_invert_vertex_group
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            else:
                if b0_buttons[6] != g_angle_limit:
                    b0_buttons[6] = g_angle_limit
                    b0_buttons[7] = g_invert_vertex_group_fake
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

                if modifier.limit_method == "ANGLE":
                    if g_angle_limit.is_dark() is True: g_angle_limit.light()
                else:
                    if g_angle_limit.is_dark() is False: g_angle_limit.dark()

            if modifier.profile_type == "CUSTOM":
                # if g_profile.blf_title.unclip_text != "Miter Shape":
                #     g_profile.blf_title.unclip_text = "Miter Shape"
                #     tag = True

                if modifier.affect == "VERTICES" or (modifier.miter_inner == "MITER_SHARP" and modifier.miter_outer == "MITER_SHARP"):
                    if g_profile.is_dark() is False: g_profile.dark()
                else:
                    if g_profile.is_dark() is True: g_profile.light()

                if g_edit_profile.is_dark() is True: g_edit_profile.light()
            else:
                # if g_profile.blf_title.unclip_text != "Shape":
                #     g_profile.blf_title.unclip_text = "Shape"
                #     tag = True

                if g_profile.is_dark() is True: g_profile.light()
                if g_edit_profile.is_dark() is False: g_edit_profile.dark()

            if modifier.affect == "VERTICES":
                if g_miter_outer.is_dark() is False:
                    g_miter_outer.dark()
                    g_miter_inner.dark()
                    g_vmesh_method.dark()
                    g_loop_slide.dark()
                    g_mark_seam.dark()
                    g_mark_sharp.dark()
                if g_spread.is_dark() is False: g_spread.dark()
            else:
                if g_miter_outer.is_dark() is True:
                    g_miter_outer.light()
                    g_miter_inner.light()
                    g_vmesh_method.light()
                    g_loop_slide.light()
                    g_mark_seam.light()
                    g_mark_sharp.light()
                if modifier.miter_inner == "MITER_ARC":
                    if g_spread.is_dark() is True: g_spread.light()
                else:
                    if g_spread.is_dark() is False: g_spread.dark()

            blfSize(FONT0, D_SIZE['font_main'])
            width = max(bu_affect_box.inner[0] - bu_profile_type_box.L, round(blfDimen(FONT0, "XSuperellipseX")[0]))
            if bu_profile_type_box.R - bu_profile_type_box.L != width:

                L = bu_profile_type_box.L
                T = bu_profile_type_box.T
                R = L + width * 2
                b1.button0.button0.init_bat(L, R, T)
                L = R + SIZE_border[3]
                b1.button0.button1.init_bat(L, L + SIZE_widget[0], T - SIZE_border[3])

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_BOOLEAN(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_button_width(): return g_operation_boxes[2].R - g_operation_boxes[1].L

        b0 = Blocks(self)
        g_object = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("object"))
        g_collection = ButtonGroupAnimRef(b0, ButtonEnumCollectionPush(None, rnas["collection"], pp), rr_refdriver("collection"))
        b0_buttons = [
            ButtonGroupAnimFull(b0, ButtonEnumXYPush(None, rnas["operation"], pp, row_length=3), *rr_fcdr("operation")),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["operand_type"], pp, row_length=2), *rr_fcdr("operand_type")),
            g_object,
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["solver"], pp, row_length=2), *rr_fcdr("solver")),
        ]
        b0.buttons = b0_buttons
        g_operation_boxes = b0_buttons[0].button0.box_button
        b0_buttons[2].r_button_width = r_button_width
        g_object.r_button_width = r_button_width
        g_collection.r_button_width = r_button_width
        b0_buttons[4].r_button_width = r_button_width

        b1 = BlockUtil(self, None, Title("Solver Options"))
        g_double_threshold = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["double_threshold"], pp), *rr_fcdr("double_threshold"))
        g_material_mode = ButtonGroupAnim(b1, ButtonEnumXYPush(None, rnas["material_mode"], pp, row_length=2), *rr_fcdr("material_mode"))
        g_use_self = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_self"], pp), *rr_fcdr("use_self"))
        g_use_hole_tolerant = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_hole_tolerant"], pp), *rr_fcdr("use_hole_tolerant"))
        b1.items = [
            g_double_threshold,
            g_material_mode,
            ButtonSep(2),
            g_use_self,
            g_use_hole_tolerant,
        ]
        g_double_threshold.r_button_width = r_button_width
        g_material_mode.r_button_width = r_button_width
        g_use_self.r_button_width = r_button_width
        g_use_hole_tolerant.r_button_width = r_button_width

        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.operand_type == "COLLECTION":
                if b0_buttons[3] != g_collection:
                    b0_buttons[3] = g_collection
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

                if modifier.solver == "EXACT":
                    if g_double_threshold.is_dark() is False: g_double_threshold.dark()
                    if g_use_self.is_dark() is False: g_use_self.dark()
                    if g_use_hole_tolerant.is_dark() is True: g_use_hole_tolerant.light()
                    if g_material_mode.is_dark() is True: g_material_mode.light()
                else:
                    if g_double_threshold.is_dark() is True: g_double_threshold.light()
                    if g_use_self.is_dark() is False: g_use_self.dark()
                    if g_use_hole_tolerant.is_dark() is False: g_use_hole_tolerant.dark()
                    if g_material_mode.is_dark() is False: g_material_mode.dark()
            else:
                if b0_buttons[3] != g_object:
                    b0_buttons[3] = g_object
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

                if modifier.solver == "EXACT":
                    if g_double_threshold.is_dark() is False: g_double_threshold.dark()
                    if g_use_self.is_dark() is True: g_use_self.light()
                    if g_use_hole_tolerant.is_dark() is True: g_use_hole_tolerant.light()
                    if g_material_mode.is_dark() is True: g_material_mode.light()
                else:
                    if g_double_threshold.is_dark() is True: g_double_threshold.light()
                    if g_use_self.is_dark() is False: g_use_self.dark()
                    if g_use_hole_tolerant.is_dark() is False: g_use_hole_tolerant.dark()
                    if g_material_mode.is_dark() is False: g_material_mode.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_BUILD(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["frame_start"], pp), *rr_fcdr("frame_start")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["frame_duration"], pp), *rr_fcdr("frame_duration")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_reverse"], pp), *rr_fcdr("use_reverse"))
        ]

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_random_order"], pp), *rr_fcdr("use_random_order"), title="Randomize")
        )
        g_seed = ButtonGroupAnim(b1, ButtonIntPush(None, rnas["seed"], pp), *rr_fcdr("seed"))
        b1.items = [g_seed]

        self.items[:] = [b0, b1]

        def upd_data_callback():
            if self.w.active_modifier.use_random_order:
                if g_seed.is_dark() is True: g_seed.light()
            else:
                if g_seed.is_dark() is False: g_seed.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_CAST(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_object = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object"))
        g_use_transform = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_transform"], pp), *rr_fcdr("use_transform"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["cast_type"], pp), *rr_fcdr("cast_type")),
            ButtonSep(),
            ButtonGroupAnimBoolArray(b0, [rnas["use_x"], rnas["use_y"], rnas["use_z"]], pp, self.r_fcurve_use_xyz, self.r_driver_use_xyz, title="Axis", button_text=TUP_XYZ),
            ButtonSep(),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["radius"], pp), *rr_fcdr("radius")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["size"], pp), *rr_fcdr("size")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_radius_as_size"], pp), *rr_fcdr("use_radius_as_size")),
            ButtonSep(2),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            ButtonSep(2),
            g_object,
            g_use_transform
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier
            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.object:
                if g_use_transform.is_dark() is True: g_use_transform.light()
            else:
                if g_use_transform.is_dark() is False: g_use_transform.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_CLOTH(self):

        b0 = Blocks(self)
        b0.buttons = [Title("  Settings are inside the Physics tab")]
        self.items[:] = [b0]
        #|
    def init_tab_COLLISION(self):

        b0 = Blocks(self)
        b0.buttons = [Title("  Settings are inside the Physics tab")]
        self.items[:] = [b0]
        #|
    def init_tab_CORRECTIVE_SMOOTH(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_bind = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_CORRECTIVE_SMOOTH_bind, self.bufn_CORRECTIVE_SMOOTH_bind), title="")
        bu_info = Title("")
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor"), title="Factor"),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["iterations"], pp), *rr_fcdr("iterations")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["scale"], pp), *rr_fcdr("scale")),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["smooth_type"], pp), *rr_fcdr("smooth_type")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_only_smooth"], pp), *rr_fcdr("use_only_smooth")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_pin_boundary"], pp), *rr_fcdr("use_pin_boundary")),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["rest_source"], pp), *rr_fcdr("rest_source")),
            ButtonSep(),
            g_bind,
            bu_info
        ]
        bu_info_blf = bu_info.blf_title
        bu_info_blf.color = COL_box_val_fg_error
        bu_bind_blf = g_bind.button0.blf_value

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier
            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.rest_source == "BIND":
                if g_bind.is_dark() is True: g_bind.light()

                bu_info_blf.text = ""  if modifier.is_bind else "   Bind data required"
            else:
                if g_bind.is_dark() is False: g_bind.dark()

                bu_info_blf.text = ""

            if modifier.is_bind:
                if bu_bind_blf.text == "Bind": g_bind.button0.set_button_text("Unbind")
            else:
                if bu_bind_blf.text == "Unbind": g_bind.button0.set_button_text("Bind")

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_CURVE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"CURVE"}), rr_refdriver("object")),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["deform_axis"], pp), *rr_fcdr("deform_axis")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_DATA_TRANSFER(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_button_width(): return D_SIZE['widget_width'] * 2

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_gen = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_DATA_TRANSFER_gen, self.bufn_DATA_TRANSFER_gen), title="")
        bu_info = Title("")
        b0.buttons= [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("object")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_object_transform"], pp), *rr_fcdr("use_object_transform")),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mix_mode"], pp), *rr_fcdr("mix_mode")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["mix_factor"], pp), *rr_fcdr("mix_factor")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            ButtonSep(2),
            g_gen,
            bu_info
        ]
        bu_info_blf = bu_info.blf_title
        bu_info_blf.color = COL_box_val_fg_error

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_vert_data"], pp), *rr_fcdr("use_vert_data"))
        )
        g_data_types_verts = ButtonGroupAnim(b1, ButtonEnumXYFlagPush(None, rnas["data_types_verts"], pp, row_length=1), *rr_fcdr("data_types_verts"), title="Types")
        g_vert_mapping = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["vert_mapping"], pp), *rr_fcdr("vert_mapping"))
        g_layers_vgroup_select_src = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["layers_vgroup_select_src"], pp), *rr_fcdr("layers_vgroup_select_src"), title="Layer Selection")
        g_layers_vgroup_select_dst = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["layers_vgroup_select_dst"], pp), *rr_fcdr("layers_vgroup_select_dst"), title="Layer Mapping")
        g_layers_vcol_vert_select_src = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["layers_vcol_vert_select_src"], pp), *rr_fcdr("layers_vcol_vert_select_src"), title="Layer Selection")
        g_layers_vcol_vert_select_dst = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["layers_vcol_vert_select_dst"], pp), *rr_fcdr("layers_vcol_vert_select_dst"), title="Layer Mapping")
        b1.items = [
            g_data_types_verts,
            ButtonSep(),
            g_vert_mapping,
            ButtonSep(2),
            Title("      Vertex Groups"),
            g_layers_vgroup_select_src,
            g_layers_vgroup_select_dst,
            ButtonSep(2),
            Title("      Colors"),
            g_layers_vcol_vert_select_src,
            g_layers_vcol_vert_select_dst
        ]

        b2 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_edge_data"], pp), *rr_fcdr("use_edge_data"))
        )
        g_data_types_edges = ButtonGroupAnim(b2, ButtonEnumXYFlagPush(None, rnas["data_types_edges"], pp, row_length=2), *rr_fcdr("data_types_edges"), title="Types")
        g_edge_mapping = ButtonGroupAnim(b2, ButtonEnumPush(None, rnas["edge_mapping"], pp), *rr_fcdr("edge_mapping"))
        b2.items = [
            g_data_types_edges,
            ButtonSep(),
            g_edge_mapping
        ]
        g_data_types_edges.r_button_width = r_button_width

        b3 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_loop_data"], pp), *rr_fcdr("use_loop_data"))
        )
        g_data_types_loops = ButtonGroupAnim(b3, ButtonEnumXYFlagPush(None, rnas["data_types_loops"], pp, row_length=1), *rr_fcdr("data_types_loops"), title="Types")
        g_loop_mapping = ButtonGroupAnim(b3, ButtonEnumPush(None, rnas["loop_mapping"], pp), *rr_fcdr("loop_mapping"))
        g_layers_vcol_loop_select_src = ButtonGroupAnim(b3, ButtonEnumPush(None, rnas["layers_vcol_loop_select_src"], pp), *rr_fcdr("layers_vcol_loop_select_src"), title="Layer Selection")
        g_layers_vcol_loop_select_dst = ButtonGroupAnim(b3, ButtonEnumPush(None, rnas["layers_vcol_loop_select_dst"], pp), *rr_fcdr("layers_vcol_loop_select_dst"), title="Layer Mapping")
        g_layers_uv_select_src = ButtonGroupAnim(b3, ButtonEnumPush(None, rnas["layers_uv_select_src"], pp), *rr_fcdr("layers_uv_select_src"), title="Layer Selection")
        g_layers_uv_select_dst = ButtonGroupAnim(b3, ButtonEnumPush(None, rnas["layers_uv_select_dst"], pp), *rr_fcdr("layers_uv_select_dst"), title="Layer Mapping")
        g_islands_precision = ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["islands_precision"], pp), *rr_fcdr("islands_precision"))
        b3.items = [
            g_data_types_loops,
            ButtonSep(),
            g_loop_mapping,
            ButtonSep(2),
            Title("      Colors"),
            g_layers_vcol_loop_select_src,
            g_layers_vcol_loop_select_dst,
            Title("      UVs"),
            g_layers_uv_select_src,
            g_layers_uv_select_dst,
            g_islands_precision
        ]

        b4 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_poly_data"], pp), *rr_fcdr("use_poly_data"))
        )
        g_data_types_polys = ButtonGroupAnim(b4, ButtonEnumXYFlagPush(None, rnas["data_types_polys"], pp, row_length=2), *rr_fcdr("data_types_polys"), title="Types")
        g_poly_mapping = ButtonGroupAnim(b4, ButtonEnumPush(None, rnas["poly_mapping"], pp), *rr_fcdr("poly_mapping"))
        b4.items = [
            g_data_types_polys,
            ButtonSep(),
            g_poly_mapping,
        ]
        g_data_types_polys.r_button_width = r_button_width

        b5 = BlockUtil(self, None, Title("Topology Mapping"))
        g_max_distance = ButtonGroupAnim(b5, ButtonFloatPush(None, rnas["max_distance"], pp), *rr_fcdr("max_distance"))
        b5.items = [
            ButtonGroupAnimAlignTitleLeft(b5, ButtonBoolPush(None, rnas["use_max_distance"], pp), *rr_fcdr("use_max_distance"), title="Use Max Distance"),
            g_max_distance,
            ButtonGroupAnim(b5, ButtonFloatPush(None, rnas["ray_radius"], pp), *rr_fcdr("ray_radius")),
        ]

        self.items[:] = [b0, b1, b2, b3, b4, b5]

        def upd_data_callback():
            modifier = self.w.active_modifier
            data_types_verts = modifier.data_types_verts
            data_types_loops = modifier.data_types_loops
            tx_info = ""

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.use_vert_data:
                if g_data_types_verts.is_dark() is True:
                    g_data_types_verts.light()
                    g_vert_mapping.light()

                if "VGROUP_WEIGHTS" in data_types_verts:
                    if g_layers_vgroup_select_src.is_dark() is True:
                        g_layers_vgroup_select_src.light()
                        g_layers_vgroup_select_dst.light()
                else:
                    if g_layers_vgroup_select_src.is_dark() is False:
                        g_layers_vgroup_select_src.dark()
                        g_layers_vgroup_select_dst.dark()

                if "COLOR_VERTEX" in data_types_verts:
                    if g_layers_vcol_vert_select_src.is_dark() is True:
                        g_layers_vcol_vert_select_src.light()
                        g_layers_vcol_vert_select_dst.light()
                else:
                    if g_layers_vcol_vert_select_src.is_dark() is False:
                        g_layers_vcol_vert_select_src.dark()
                        g_layers_vcol_vert_select_dst.dark()

                if data_types_verts:
                    if modifier.object:
                        ll_v0 = len(modifier.object.data.vertices)
                        ll_v1 = len(self.w.active_object.data.vertices)
                        if ll_v0 == 0 or ll_v1 == 0:
                            tx_info = "   Source / target meshes do not have any vertices"
                        else:
                            vert_mapping = modifier.vert_mapping
                            if vert_mapping == "TOPOLOGY":
                                if ll_v0 != ll_v1:
                                    tx_info = "   Source and target meshes have different vertex counts"
                            elif vert_mapping in {"POLY_NEAREST", "POLYINTERP_NEAREST", "POLYINTERP_VNORPROJ"}:
                                if not modifier.object.data.polygons:
                                    tx_info = "   Source mesh doesn't have any faces"
                            elif vert_mapping in {"EDGE_NEAREST", "EDGEINTERP_NEAREST"}:
                                if not modifier.object.data.edges:
                                    tx_info = "   Source mesh doesn't have any edges"
            else:
                if g_data_types_verts.is_dark() is False:
                    g_data_types_verts.dark()
                    g_vert_mapping.dark()
                if g_layers_vgroup_select_src.is_dark() is False:
                    g_layers_vgroup_select_src.dark()
                    g_layers_vgroup_select_dst.dark()
                if g_layers_vcol_vert_select_src.is_dark() is False:
                    g_layers_vcol_vert_select_src.dark()
                    g_layers_vcol_vert_select_dst.dark()

            if modifier.use_edge_data:
                if g_data_types_edges.is_dark() is True:
                    g_data_types_edges.light()
                    g_edge_mapping.light()

                if modifier.data_types_edges:
                    if modifier.object:
                        ll_e0 = len(modifier.object.data.edges)
                        ll_e1 = len(self.w.active_object.data.edges)
                        edge_mapping = modifier.edge_mapping
                        if edge_mapping == "TOPOLOGY":
                            if ll_e0 != ll_e1:
                                tx_info = "   Source and target meshes have different edge counts"
                            elif ll_e0 == 0 or ll_e1 == 0:
                                tx_info = "   Source / target meshes do not have any edges"
                        elif edge_mapping in {"VERT_NEAREST", "NEAREST", "EDGEINTERP_VNORPROJ"}:
                            if ll_e0 == 0 or ll_e1 == 0:
                                tx_info = "   Source / target meshes do not have any edges"
                        elif edge_mapping == "POLY_NEAREST":
                            if not modifier.object.data.polygons:
                                tx_info = "   Source mesh doesn't have any faces"
            else:
                if g_data_types_edges.is_dark() is False:
                    g_data_types_edges.dark()
                    g_edge_mapping.dark()

            if modifier.use_loop_data:
                if g_data_types_loops.is_dark() is True:
                    g_data_types_loops.light()
                    g_loop_mapping.light()

                if "COLOR_CORNER" in data_types_loops:
                    if g_layers_vcol_loop_select_src.is_dark() is True:
                        g_layers_vcol_loop_select_src.light()
                        g_layers_vcol_loop_select_dst.light()
                else:
                    if g_layers_vcol_loop_select_src.is_dark() is False:
                        g_layers_vcol_loop_select_src.dark()
                        g_layers_vcol_loop_select_dst.dark()

                if "UV" in data_types_loops:
                    if g_layers_uv_select_src.is_dark() is True:
                        g_layers_uv_select_src.light()
                        g_layers_uv_select_dst.light()
                        g_islands_precision.light()
                else:
                    if g_layers_uv_select_src.is_dark() is False:
                        g_layers_uv_select_src.dark()
                        g_layers_uv_select_dst.dark()
                        g_islands_precision.dark()

                if data_types_loops:
                    if modifier.object:
                        ll_l0 = len(modifier.object.data.loops)
                        ll_l1 = len(self.w.active_object.data.loops)

                        if modifier.loop_mapping == "TOPOLOGY":
                            if ll_l0 != ll_l1:
                                tx_info = "   Source mesh has different amount of face corners"
                            elif len(modifier.object.data.polygons) == 0 or len(self.w.active_object.data.polygons) == 0:
                                tx_info = "   Source / target meshes do not have any faces"
                        elif modifier.loop_mapping in {"NEAREST_POLYNOR", "NEAREST_POLY", "POLYINTERP_NEAREST", "POLYINTERP_LNORPROJ"}:
                            if len(modifier.object.data.polygons) == 0 or len(self.w.active_object.data.polygons) == 0:
                                tx_info = "   Source / target meshes do not have any faces"
            else:
                if g_data_types_loops.is_dark() is False:
                    g_data_types_loops.dark()
                    g_loop_mapping.dark()
                    g_layers_vcol_loop_select_src.dark()
                    g_layers_vcol_loop_select_dst.dark()
                    g_layers_uv_select_src.dark()
                    g_layers_uv_select_dst.dark()
                    g_islands_precision.dark()

            if modifier.use_poly_data:
                if g_data_types_polys.is_dark() is True:
                    g_data_types_polys.light()
                    g_poly_mapping.light()

                if modifier.data_types_polys:
                    if modifier.object:
                        ll_f0 = len(modifier.object.data.polygons)
                        ll_f1 = len(self.w.active_object.data.polygons)
                        if modifier.poly_mapping == "TOPOLOGY":
                            if ll_f0 != ll_f1:
                                tx_info = "   Source mesh has different amount of faces"
                            elif ll_f0 == 0 or ll_f1 == 0:
                                tx_info = "   Source / target meshes do not have any faces"
                        elif modifier.poly_mapping in {"NEAREST", "NORMAL", "POLYINTERP_PNORPROJ"}:
                            if ll_f0 == 0 or ll_f1 == 0:
                                tx_info = "   Source / target meshes do not have any faces"
            else:
                if g_data_types_polys.is_dark() is False:
                    g_data_types_polys.dark()
                    g_poly_mapping.dark()

            if modifier.use_max_distance:
                if g_max_distance.is_dark() is True: g_max_distance.light()
            else:
                if g_max_distance.is_dark() is False: g_max_distance.dark()

            bu_info_blf.text = tx_info

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_DECIMATE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_decimate_type = ButtonGroupAnimFull(b0, ButtonEnumXYPush(None, rnas["decimate_type"], pp, row_length=3), *rr_fcdr("decimate_type"))
        g_ratio = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["ratio"], pp), *rr_fcdr("ratio"))
        g_use_symmetry = ButtonGroupAnimBoolAlignR(b0, ButtonBoolPush(None, rnas["use_symmetry"], pp), *rr_fcdr("use_symmetry"))
        g_symmetry_axis = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["symmetry_axis"], pp, row_length=3), *rr_fcdr("symmetry_axis"), title="")
        g_use_collapse_triangulate = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_collapse_triangulate"], pp), *rr_fcdr("use_collapse_triangulate"))
        g_vertex_group = ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_vertex_group_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["vertex_group_factor"], pp), *rr_fcdr("vertex_group_factor"))

        g_iterations = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["iterations"], pp), *rr_fcdr("iterations"))
        g_angle_limit = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["angle_limit"], pp), *rr_fcdr("angle_limit"))
        g_use_dissolve_boundaries = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_dissolve_boundaries"], pp), *rr_fcdr("use_dissolve_boundaries"))
        g_delimit = ButtonGroupAnim(b0, ButtonEnumXYFlagPush(None, rnas["delimit"], pp, row_length=1), *rr_fcdr("delimit"))
        bu_info = Title("")
        bu_info_blf = bu_info.blf_title
        g_symmetry_axis_box_button = g_symmetry_axis.button0.box_button[0]
        gs_symmetry_axis = ButtonSplitBool(b0, g_use_symmetry, g_symmetry_axis, lambda: g_symmetry_axis_box_button.L, gap=lambda: SIZE_widget[0] // 4)
        b0_buttons = [
            g_decimate_type,
            ButtonSep(2),
            g_ratio,
            gs_symmetry_axis,
            g_use_collapse_triangulate,
            ButtonSep(2),
            g_vertex_group,
            g_invert_vertex_group,
            ButtonSep(),
            g_vertex_group_factor,
            bu_info
        ]
        b0.buttons = b0_buttons
        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier
            bu_info_blf.text = f'   Face Count :  {modifier.face_count}'

            if modifier.decimate_type == "COLLAPSE":
                if b0_buttons[2] == g_ratio:
                    if modifier.use_symmetry:
                        if g_symmetry_axis.is_dark() is True: g_symmetry_axis.light()
                    else:
                        if g_symmetry_axis.is_dark() is False: g_symmetry_axis.dark()

                    if modifier.vertex_group:
                        if g_invert_vertex_group.is_dark() is True:
                            g_invert_vertex_group.light()
                            g_vertex_group_factor.light()
                    else:
                        if g_invert_vertex_group.is_dark() is False:
                            g_invert_vertex_group.dark()
                            g_vertex_group_factor.dark()
                else:
                    b0_buttons[:] = [
                        g_decimate_type,
                        ButtonSep(2),
                        g_ratio,
                        gs_symmetry_axis,
                        g_use_collapse_triangulate,
                        ButtonSep(2),
                        g_vertex_group,
                        g_invert_vertex_group,
                        ButtonSep(),
                        g_vertex_group_factor,
                        bu_info
                    ]
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            elif modifier.decimate_type == "UNSUBDIV":
                if b0_buttons[2] == g_iterations: pass
                else:
                    b0_buttons[:] = [
                        g_decimate_type,
                        ButtonSep(2),
                        g_iterations,
                        bu_info
                    ]
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            else:
                if b0_buttons[2] == g_angle_limit: pass
                else:
                    b0_buttons[:] = [
                        g_decimate_type,
                        ButtonSep(2),
                        g_angle_limit,
                        ButtonSep(2),
                        g_delimit,
                        ButtonSep(2),
                        g_use_dissolve_boundaries,
                        bu_info
                    ]
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_DISPLACE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_button_width(): return D_SIZE['widget_width'] + SIZE_widget[0] * 3
        def r_armature(): return self.r_modifier().texture_coords_object

        b0 = Blocks(self)
        g_texture = ButtonGroupAnimRef(b0, ButtonEnumTexturePush(None, rnas["texture"], pp), rr_refdriver("texture"))
        g_texture_coords = ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["texture_coords"], pp), *rr_fcdr("texture_coords"), title="Coordinates")
        g_texture_coords_object = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["texture_coords_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("texture_coords_object"), title="Object")
        g_texture_coords_bone = ButtonGroupAnimRef(b0, ButtonEnumBonePush(None, rnas["texture_coords_bone"], pp, r_armature), rr_refdriver("texture_coords_bone"), title="Bone")
        g_uv_layer = ButtonGroupAnimRef(b0, ButtonEnumUVPush(None, rnas["uv_layer"], pp), rr_refdriver("uv_layer"))
        g_space = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["space"], pp, row_length=2), *rr_fcdr("space"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            g_texture,
            ButtonSep(2),
            g_texture_coords,
            g_texture_coords_object,
            g_texture_coords_bone,
            g_uv_layer,
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["direction"], pp), *rr_fcdr("direction")),
            g_space,
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["mid_level"], pp), *rr_fcdr("mid_level")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group
        ]
        g_texture.r_button_width = r_button_width

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.texture:
                if g_texture_coords.is_dark() is True:
                    g_texture_coords.light()

                if modifier.texture_coords == "OBJECT":
                    if g_texture_coords_object.is_dark() is True: g_texture_coords_object.light()
                    if g_uv_layer.is_dark() is False: g_uv_layer.dark()
                    if modifier.texture_coords_object and modifier.texture_coords_object.type == "ARMATURE":
                        if g_texture_coords_bone.is_dark() is True: g_texture_coords_bone.light()
                    else:
                        if g_texture_coords_bone.is_dark() is False: g_texture_coords_bone.dark()
                elif modifier.texture_coords == "UV":
                    if g_texture_coords_object.is_dark() is False: g_texture_coords_object.dark()
                    if g_uv_layer.is_dark() is True: g_uv_layer.light()
                    if g_texture_coords_bone.is_dark() is False: g_texture_coords_bone.dark()
                else:
                    if g_texture_coords_object.is_dark() is False: g_texture_coords_object.dark()
                    if g_uv_layer.is_dark() is False: g_uv_layer.dark()
                    if g_texture_coords_bone.is_dark() is False: g_texture_coords_bone.dark()
            else:
                if g_texture_coords.is_dark() is False:
                    g_texture_coords.dark()
                    g_texture_coords_object.dark()
                    g_texture_coords_bone.dark()
                    g_uv_layer.dark()

            if modifier.direction in {"NORMAL", "CUSTOM_NORMAL"}:
                if g_space.is_dark() is False: g_space.dark()
            else:
                if g_space.is_dark() is True: g_space.light()

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_DYNAMIC_PAINT(self):

        b0 = Blocks(self)
        b0.buttons = [Title("  Settings are inside the Physics tab")]
        self.items[:] = [b0]
        #|
    def init_tab_EDGE_SPLIT(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_split_angle = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["split_angle"], pp), *rr_fcdr("split_angle"))
        b0.buttons = [
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_edge_angle"], pp), *rr_fcdr("use_edge_angle")),
            g_split_angle,
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_edge_sharp"], pp), *rr_fcdr("use_edge_sharp"))
        ]
        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.use_edge_angle:
                if g_split_angle.is_dark() is True: g_split_angle.light()
            else:
                if g_split_angle.is_dark() is False: g_split_angle.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_EXPLODE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_vertex_group = ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_protect = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["protect"], pp), *rr_fcdr("protect"))
        g_refresh = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_EXPLODE_refresh, self.bnfn_EXPLODE_refresh), title="")
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumUVPush(None, rnas["particle_uv"], pp), rr_refdriver("particle_uv")),
            ButtonSep(2),
            ButtonGroupAnimAlignLR(b0, ButtonBoolPush(None, rnas["show_alive"], pp), *rr_fcdr("show_alive"), title_head="Show"),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["show_dead"], pp), *rr_fcdr("show_dead")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["show_unborn"], pp), *rr_fcdr("show_unborn")),
            ButtonSep(2),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_edge_cut"], pp), *rr_fcdr("use_edge_cut")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_size"], pp), *rr_fcdr("use_size")),
            ButtonSep(2),
            g_vertex_group,
            g_invert_vertex_group,
            g_protect,
            ButtonSep(2),
            g_refresh
        ]
        g_vertex_group.button0.set_callback = update_scene_and_ref

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True:
                    g_invert_vertex_group.light()
                    g_protect.light()
            else:
                if g_invert_vertex_group.is_dark() is False:
                    g_invert_vertex_group.dark()
                    g_protect.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_FLUID(self):

        b0 = Blocks(self)
        b0.buttons = [Title("  Settings are inside the Physics tab")]
        self.items[:] = [b0]
        #|
    def init_tab_HOOK(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_armature(): return self.r_modifier().object

        b0 = Blocks(self)
        g_subtarget = ButtonGroupAnimRef(b0, ButtonEnumBonePush(None, rnas["subtarget"], pp, r_armature), rr_refdriver("subtarget"), title="Bone")
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object")),
            g_subtarget,
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength")),
            ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["center"], pp), *rr_fcdr_array("center", RANGE_3)),
        ]

        b1 = BlockUtil(self, None, Title("Falloff"))
        g_edit_curve = ButtonFnPush(b1, RNA_edit_curve, self.bufn_HOOK_edit_curve)
        g_falloff_type = ButtonGroupAnim(b1, ButtonEnumFalloffPush(None, rnas["falloff_type"], pp), *rr_fcdr("falloff_type"), title="Type")
        g_falloff_radius = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["falloff_radius"], pp), *rr_fcdr("falloff_radius"))
        b1.items = [
            ButtonSplit(b1, g_edit_curve, g_falloff_type, gap=r_button_h, factor=0.35),
            g_falloff_radius,
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_falloff_uniform"], pp), *rr_fcdr("use_falloff_uniform")),
        ]

        # falloff_curve: POINTER
        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.object and modifier.object.type == "ARMATURE":
                if g_subtarget.is_dark() is True: g_subtarget.light()
            else:
                if g_subtarget.is_dark() is False: g_subtarget.dark()

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.falloff_type == "CURVE":
                if g_edit_curve.is_dark() is True: g_edit_curve.light()
                if g_falloff_radius.is_dark() is True:
                    g_falloff_radius.light()
            else:
                if g_edit_curve.is_dark() is False: g_edit_curve.dark()

                if modifier.falloff_type == "NONE":
                    if g_falloff_radius.is_dark() is False:
                        g_falloff_radius.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_LAPLACIANDEFORM(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_vertex_group = ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_bind = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_LAPLACIANDEFORM_bind, self.bufn_LAPLACIANDEFORM_bind), title="")
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["iterations"], pp), *rr_fcdr("iterations")),
            g_vertex_group,
            g_invert_vertex_group,
            ButtonSep(),
            g_bind
        ]
        g_vertex_group.button0.set_callback = update_scene_and_ref
        bu_bind_blf = g_bind.button0.blf_value

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier
            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True:
                    g_invert_vertex_group.light()
                    g_bind.light()
            else:
                if g_invert_vertex_group.is_dark() is False:
                    g_invert_vertex_group.dark()
                    g_bind.dark()

            if modifier.is_bind:
                if bu_bind_blf.text == "Bind": g_bind.button0.set_button_text("Unbind")
            else:
                if bu_bind_blf.text == "Unbind": g_bind.button0.set_button_text("Bind")

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_LAPLACIANSMOOTH(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["iterations"], pp), *rr_fcdr("iterations")),
            ButtonGroupAnimBoolArray(b0, [rnas["use_x"], rnas["use_y"], rnas["use_z"]], pp, self.r_fcurve_use_xyz, self.r_driver_use_xyz, title="Axis", button_text=TUP_XYZ),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["lambda_factor"], pp), *rr_fcdr("lambda_factor")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["lambda_border"], pp), *rr_fcdr("lambda_border")),
            ButtonSep(2),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_volume_preserve"], pp), *rr_fcdr("use_volume_preserve")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_normalized"], pp), *rr_fcdr("use_normalized")),
            ButtonSep(2),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_LATTICE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"LATTICE"}), rr_refdriver("object")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength"))
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_MASK(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_mode = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["mode"], pp, row_length=2), *rr_fcdr("mode"))
        g_vertex_group = ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_use_smooth = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_smooth"], pp), *rr_fcdr("use_smooth"))
        g_armature = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["armature"], pp, {"ARMATURE"}), rr_refdriver("armature"))
        b0.buttons = [
            g_mode,
            ButtonSep(2),
            g_vertex_group,
            g_invert_vertex_group,
            g_use_smooth,
            g_armature,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["threshold"], pp), *rr_fcdr("threshold"))
        ]
        g_mode.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.5)
        g_armature.dark()

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.mode == "ARMATURE":
                if g_vertex_group.is_dark() is False:
                    g_vertex_group.dark()
                    g_invert_vertex_group.dark()
                    g_use_smooth.dark()
                    g_armature.light()
            else:
                if g_vertex_group.is_dark() is True:
                    g_vertex_group.light()
                    g_use_smooth.light()
                    g_armature.dark()

                if modifier.vertex_group:
                    if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
                else:
                    if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_MESH_CACHE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_button_width(): return round(D_SIZE['widget_width'] * 1.8)
        def r_button_width_2(): return round(D_SIZE['widget_width'] * 1.5)

        b0 = Blocks(self)
        g_filepath = ButtonGroupAnimRef(b0, ButtonStringFilePush(None, rnas["filepath"], pp), rr_refdriver("filepath"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["cache_format"], pp, row_length=2), *rr_fcdr("cache_format")),
            ButtonSep(),
            g_filepath,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor")),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["deform_mode"], pp, row_length=2), *rr_fcdr("deform_mode")),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["interpolation"], pp, row_length=2), *rr_fcdr("interpolation")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
        ]
        g_filepath.r_button_width = r_button_width

        b1 = BlockUtil(self, None, Title("Time Remapping"))
        g_time_mode = ButtonGroupAnim(b1, ButtonEnumXYPush(None, rnas["time_mode"], pp, row_length=3), *rr_fcdr("time_mode"))
        g_frame_start = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["frame_start"], pp), *rr_fcdr("frame_start"))
        g_frame_scale = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["frame_scale"], pp), *rr_fcdr("frame_scale"))
        g_eval_frame = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["eval_frame"], pp), *rr_fcdr("eval_frame"))
        g_eval_time = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["eval_time"], pp), *rr_fcdr("eval_time"))
        g_eval_factor = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["eval_factor"], pp), *rr_fcdr("eval_factor"))
        b1.items = [
            g_time_mode,
            ButtonGroupAnim(b1, ButtonEnumXYPush(None, rnas["play_mode"], pp, row_length=2), *rr_fcdr("play_mode")),
            g_frame_start,
            g_frame_scale,
            g_eval_frame,
            g_eval_time,
            g_eval_factor
        ]
        g_time_mode.r_button_width = r_button_width_2
        g_eval_frame.dark()
        g_eval_time.dark()
        g_eval_factor.dark()

        b2 = BlockUtil(self, None, Title("Axis Mapping"))
        g_forward_axis = ButtonGroupAnim(b2, ButtonEnumXYPush(None, rnas["forward_axis"], pp, row_length=6), *rr_fcdr("forward_axis"))
        g_up_axis = ButtonGroupAnim(b2, ButtonEnumXYPush(None, rnas["up_axis"], pp, row_length=6), *rr_fcdr("up_axis"))
        g_flip_axis = ButtonGroupAnim(b2, ButtonEnumXYFlagPush(None, rnas["flip_axis"], pp, row_length=3), *rr_fcdr("flip_axis"))
        b2.items = [
            g_forward_axis,
            g_up_axis,
            g_flip_axis
        ]
        g_forward_axis.r_button_width = r_button_width
        g_up_axis.r_button_width = r_button_width
        g_flip_axis.r_button_width = r_button_width

        self.items[:] = [b0, b1, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.play_mode == "SCENE":
                if g_frame_start.is_dark() is True:
                    g_frame_start.light()
                    g_frame_scale.light()
                if g_eval_frame.is_dark() is False: g_eval_frame.dark()
                if g_eval_time.is_dark() is False: g_eval_time.dark()
                if g_eval_factor.is_dark() is False: g_eval_factor.dark()
            else:
                if g_frame_start.is_dark() is False:
                    g_frame_start.dark()
                    g_frame_scale.dark()
                if modifier.time_mode == "FRAME":
                    if g_eval_frame.is_dark() is True:
                        g_eval_frame.light()
                        g_eval_time.dark()
                        g_eval_factor.dark()
                elif modifier.time_mode == "TIME":
                    if g_eval_time.is_dark() is True:
                        g_eval_frame.dark()
                        g_eval_time.light()
                        g_eval_factor.dark()
                else:
                    if g_eval_factor.is_dark() is True:
                        g_eval_frame.dark()
                        g_eval_time.dark()
                        g_eval_factor.light()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_MESH_DEFORM(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_object = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("object"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_precision = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["precision"], pp), *rr_fcdr("precision"))
        g_use_dynamic_bind = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_dynamic_bind"], pp), *rr_fcdr("use_dynamic_bind"))
        g_bind = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_MESH_DEFORM_bind, self.bufn_MESH_DEFORM_bind), title="")
        b0.buttons = [
            g_object,
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            g_precision,
            g_use_dynamic_bind,
            ButtonSep(),
            g_bind
        ]
        g_object.button0.poll = poll_hard_disable
        g_precision.button0.poll = poll_hard_disable
        g_use_dynamic_bind.button0.poll = poll_hard_disable

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.is_bound:
                if g_object.is_dark() is False:
                    g_object.dark()
                    g_precision.dark()
                    g_use_dynamic_bind.dark()
                    g_bind.button0.set_button_text("Unbind")
            else:
                if g_object.is_dark() is True:
                    g_object.light()
                    g_precision.light()
                    g_use_dynamic_bind.light()
                    g_bind.button0.set_button_text("Bind")

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_MESH_SEQUENCE_CACHE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_button_width(): return round(D_SIZE['widget_width'] * 1.7)
        def r_cache_file(): return self.w.active_modifier.cache_file

        b0 = Blocks(self)
        g_object_path = ButtonGroupAnimRef(b0, ButtonStringObjectPathPush(None, rnas["object_path"], pp, r_cache_file), rr_refdriver("object_path"))
        g_read_data = ButtonGroupAnim(b0, ButtonEnumXYFlagPush(None, rnas["read_data"], pp, row_length=4), *rr_fcdr("read_data"))
        b0.buttons = [
            g_read_data,
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_vertex_interpolation"], pp), *rr_fcdr("use_vertex_interpolation")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["velocity_scale"], pp), *rr_fcdr("velocity_scale")),
            ButtonSep(),
            g_object_path
        ]
        g_object_path.r_button_width = r_button_width
        g_read_data.r_button_width = r_button_width

        cache_rnas = CacheFile.bl_rna.properties
        def rr_fcdr_cache(attr):
            def r_fcurve():
                if self.w.active_modifier.cache_file:
                    animation_data = self.w.active_modifier.cache_file.animation_data
                    if animation_data and animation_data.action and animation_data.action.fcurves:
                        return animation_data.action.fcurves.find(attr)
                return None
            def r_driver():
                if self.w.active_modifier.cache_file:
                    animation_data = self.w.active_modifier.cache_file.animation_data
                    if animation_data and animation_data.drivers:
                        return animation_data.drivers.find(attr)
                return None
            return r_fcurve, r_driver
        def rr_refdriver_cache(attr):
            def r_refdriver():
                if self.w.active_modifier.cache_file:
                    animation_data = self.w.active_modifier.cache_file.animation_data
                    if animation_data and animation_data.drivers:
                        return animation_data.drivers.find(f'["{escape_identifier(attr)}"]')
                return None
            return r_refdriver
        def r_datapath_head_cache_file(full=False):
            cac = r_cache_file()
            if cac:
                if full: return f'{r_ID_dp(cac)}.'
            return ""
        def r_layers():
            cache_file = self.w.active_modifier.cache_file
            if cache_file: return cache_file.layers
            return None
        def r_active_index():
            cache_file = self.w.active_modifier.cache_file
            if hasattr(cache_file, "active_index"):
                return cache_file.active_index
            return -1
        def set_active_index(i, push=True):
            cache_file = self.w.active_modifier.cache_file
            if hasattr(cache_file, "active_index"):
                cache_file.active_index = i
                if push: update_scene()

        ppp = r_cache_file, r_cache_file, r_datapath_head_cache_file

        b1 = BlockUtil(self, [],
            ButtonGroupAnimRefFull(None, ButtonEnumCacheFilePush(None, rnas["cache_file"], pp), rr_refdriver("cache_file"))
        )

        bb0 = BlockUtil(b1, [], Title("Time"))
        bb1 = BlockUtil(b1, [], Title("Render Procedural"))
        bb2 = BlockUtil(b1, [], Title("Velocity"))
        bb3 = BlockUtil(b1, [], Title("Override Layers"))

        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier
            cache_file = modifier.cache_file

            if cache_file:
                if not b1.items:
                    b1.items += [bb0, bb1, bb2, bb3]
                    bb0.items = [
                        ButtonGroupAnimAlignTitleLeft(bb0, ButtonBoolPush(None, cache_rnas["is_sequence"], ppp), *rr_fcdr_cache("is_sequence")),
                        ButtonGroupAnimAlignTitleLeft(bb0, ButtonBoolPush(None, cache_rnas["override_frame"], ppp), *rr_fcdr_cache("override_frame")),
                        ButtonGroupAnim(bb0, ButtonFloatPush(None, cache_rnas["frame"], ppp), *rr_fcdr_cache("frame")),
                        ButtonGroupAnim(bb0, ButtonFloatPush(None, cache_rnas["frame_offset"], ppp), *rr_fcdr_cache("frame_offset")),
                    ]
                    g_use_prefetch = ButtonGroupAnimAlignTitleLeft(bb1, ButtonBoolPush(None, cache_rnas["use_prefetch"], ppp), *rr_fcdr_cache("use_prefetch"))
                    g_prefetch_cache_size = ButtonGroupAnim(bb1, ButtonIntPush(None, cache_rnas["prefetch_cache_size"], ppp), *rr_fcdr_cache("prefetch_cache_size"))
                    bb1.items = [
                        ButtonSep(0),
                        ButtonGroupAnim(bb1, ButtonBoolPush(None, cache_rnas["use_render_procedural"], ppp), *rr_fcdr_cache("use_render_procedural")),
                        g_use_prefetch,
                        g_prefetch_cache_size,
                    ]
                    g_use_prefetch.button0.poll = poll_hard_disable
                    g_prefetch_cache_size.button0.poll = poll_hard_disable

                    bb2.items = [
                        ButtonGroupAnimRef(bb2, ButtonStringPush(None, cache_rnas["velocity_name"], ppp), rr_refdriver_cache("velocity_name")),
                        ButtonGroupAnimRef(bb2, ButtonEnumXYPush(None, cache_rnas["velocity_unit"], ppp, row_length=2), rr_refdriver_cache("velocity_unit"))
                    ]

                    button_media = ButtonListLayerMedia(bb3, r_layers, r_active_index, set_active_index)
                    bb3.items = [
                        button_media,
                        ButtonListLayer(bb3, r_layers, lambda e: e.filepath, r_active_index, set_active_index, button_media)
                    ]

                    self.redraw_from_headkey()
                    self.upd_data()
                    return

                if bb3.items[-1].upd_collection():
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

                bb1_items = bb1.items

                if cache_file.override_frame:
                    if bb0.items[2].is_dark() is True: bb0.items[2].light()
                else:
                    if bb0.items[2].is_dark() is False: bb0.items[2].dark()

                if bpy.context.scene.cycles.feature_set == "EXPERIMENTAL":
                    if type(bb1_items[0]) != ButtonSep:
                        bb1_items[0] = ButtonSep(0)
                        self.redraw_from_headkey()
                        self.upd_data()
                        return

                    if bb1_items[1].is_dark() is True: bb1_items[1].light()

                    if cache_file.use_render_procedural:
                        if bb1_items[2].is_dark() is True: bb1_items[2].light()
                    else:
                        if bb1_items[2].is_dark() is False: bb1_items[2].dark()

                    if cache_file.use_prefetch:
                        if bb1_items[3].is_dark() is True: bb1_items[3].light()
                    else:
                        if bb1_items[3].is_dark() is False: bb1_items[3].dark()
                else:
                    if type(bb1_items[0]) != Title:
                        bb1_items[0] = Title("   Cycles experimental feature require")
                        self.redraw_from_headkey()
                        self.upd_data()
                        return

                    if bb1_items[1].is_dark() is False:
                        bb1_items[1].dark()
                        bb1_items[2].dark()
                        bb1_items[3].dark()
            else:
                if b1.items:
                    b1.items.clear()
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_MIRROR(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_use_bisect_flip_axis = ButtonGroupAnimBoolXYZ(b0, ButtonBoolXYZPush(None, rnas["use_bisect_flip_axis"], pp), *rr_fcdr_array("use_bisect_flip_axis", RANGE_3), title="Flip")
        g_use_mirror_merge = ButtonGroupAnimBoolAlignR(b0, ButtonBoolPush(None, rnas["use_mirror_merge"], pp), *rr_fcdr("use_mirror_merge"), title="Merge Vertices")
        g_merge_threshold = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["merge_threshold"], pp), *rr_fcdr("merge_threshold"), title="")
        g_merge_threshold_box_button = g_merge_threshold.button0.box_button
        b0.buttons = [
            ButtonGroupAnimBoolXYZ(b0, ButtonBoolXYZPush(None, rnas["use_axis"], pp), *rr_fcdr_array("use_axis", RANGE_3), title="Axis"),
            ButtonGroupAnimBoolXYZ(b0, ButtonBoolXYZPush(None, rnas["use_bisect_axis"], pp), *rr_fcdr_array("use_bisect_axis", RANGE_3), title="Bisect"),
            g_use_bisect_flip_axis,
            ButtonSep(2),
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["mirror_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("mirror_object")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_clip"], pp), *rr_fcdr("use_clip"), title="Clipping"),
            ButtonSplitBool(b0, g_use_mirror_merge, g_merge_threshold, lambda: g_merge_threshold_box_button.L, gap=lambda: SIZE_widget[0] // 4),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["bisect_threshold"], pp), *rr_fcdr("bisect_threshold")),
        ]

        b1 = BlockUtil(self, None, Title("Data"))
        g_use_mirror_u = ButtonGroupAnimBoolAlignR(b1, ButtonBoolPush(None, rnas["use_mirror_u"], pp), *rr_fcdr("use_mirror_u"))
        g_use_mirror_v = ButtonGroupAnimBoolAlignR(b1, ButtonBoolPush(None, rnas["use_mirror_v"], pp), *rr_fcdr("use_mirror_v"))
        g_mirror_offset_u = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["mirror_offset_u"], pp), *rr_fcdr("mirror_offset_u"), title="")
        g_mirror_offset_v = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["mirror_offset_v"], pp), *rr_fcdr("mirror_offset_v"), title="")
        g_mirror_offset_u_box_button = g_mirror_offset_u.button0.box_button
        g_mirror_offset_v_box_button = g_mirror_offset_v.button0.box_button
        b1.items = [
            ButtonSplitBool(b1, g_use_mirror_u, g_mirror_offset_u, lambda: g_mirror_offset_u_box_button.L, gap=lambda: SIZE_widget[0] // 4),
            ButtonSplitBool(b1, g_use_mirror_v, g_mirror_offset_v, lambda: g_mirror_offset_v_box_button.L, gap=lambda: SIZE_widget[0] // 4),
            ButtonSep(2),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["offset_u"], pp), *rr_fcdr("offset_u")),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["offset_v"], pp), *rr_fcdr("offset_v")),
            ButtonSep(2),
            ButtonGroupAnimAlignLR(b1, ButtonBoolPush(None, rnas["use_mirror_vertex_groups"], pp), *rr_fcdr("use_mirror_vertex_groups"), title="Vertex Group", title_head="Mirror"),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_mirror_udim"], pp), *rr_fcdr("use_mirror_udim"), title="UDIM"),
        ]

        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_mirror_merge:
                if g_merge_threshold.is_dark() is True: g_merge_threshold.light()
            else:
                if g_merge_threshold.is_dark() is False: g_merge_threshold.dark()

            if modifier.use_mirror_u:
                if g_mirror_offset_u.is_dark() is True: g_mirror_offset_u.light()
            else:
                if g_mirror_offset_u.is_dark() is False: g_mirror_offset_u.dark()

            if modifier.use_mirror_v:
                if g_mirror_offset_v.is_dark() is True: g_mirror_offset_v.light()
            else:
                if g_mirror_offset_v.is_dark() is False: g_mirror_offset_v.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_MULTIRES(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_button_width_R(): return D_SIZE['widget_width'] // 2
        def r_button_width_L(): return D_SIZE['widget_width'] - D_SIZE['widget_width'] // 2 - SIZE_border[3]

        b0 = Blocks(self)
        g_use_sculpt_base_mesh = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_sculpt_base_mesh"], pp), *rr_fcdr("use_sculpt_base_mesh"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["levels"], pp), *rr_fcdr("levels")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["sculpt_levels"], pp), *rr_fcdr("sculpt_levels")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["render_levels"], pp), *rr_fcdr("render_levels")),
            g_use_sculpt_base_mesh,
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["show_only_control_edges"], pp), *rr_fcdr("show_only_control_edges")),
        ]

        b1 = BlockUtil(self, None, Title("Subdivide"))
        bu_subdivide = ButtonGroupAnimFn(b1, ButtonFnPush(None, RNA_MULTIRES_subdivide, self.bufn_MULTIRES_subdivide), title="")
        bu_simple = ButtonGroupAnimFn(b1, ButtonFnPush(None, RNA_MULTIRES_simple, self.bufn_MULTIRES_simple), title="")
        bu_linear = ButtonGroupAnimFn(b1, ButtonFnPush(None, RNA_MULTIRES_linear, self.bufn_MULTIRES_linear), title="")
        bu_unsubdivide = ButtonGroupAnimFn(b1, ButtonFnPush(None, RNA_MULTIRES_unsubdivide, self.bufn_MULTIRES_unsubdivide), title="")
        bu_delete_higher = ButtonGroupAnimFn(b1, ButtonFnPush(None, RNA_MULTIRES_delete_higher, self.bufn_MULTIRES_delete_higher), title="")
        b1.items = [
            bu_subdivide,
            ButtonSplitBool(b1, bu_simple, bu_linear, lambda: bu_linear.button0.box_button.L + SIZE_widget[0]),
            ButtonSep(2),
            bu_unsubdivide,
            bu_delete_higher
        ]
        bu_linear.r_button_width = r_button_width_R
        bu_simple.r_button_width = r_button_width_L

        b2 = BlockUtil(self, None, Title("Shape"))
        bu_reshape = ButtonGroupAnimFn(b2, ButtonFnPush(None, RNA_MULTIRES_reshape, self.bufn_MULTIRES_reshape), title="")
        bu_apply_base = ButtonGroupAnimFn(b2, ButtonFnPush(None, RNA_MULTIRES_apply_base, self.bufn_MULTIRES_apply_base), title="")
        b2.items = [
            bu_reshape,
            bu_apply_base
        ]

        b3 = BlockUtil(self, None, Title("Generate"))
        bu_rebuild = ButtonGroupAnimFn(b3, ButtonFnPush(None, RNA_MULTIRES_rebuild, self.bufn_MULTIRES_rebuild), title="")
        bu_save_external = ButtonGroupAnimFn(b3, ButtonFnPush(None, RNA_MULTIRES_save_external, self.bufn_MULTIRES_save_external), title="")
        g_filepath = ButtonGroupAnimRef(b0, ButtonStringFilePush(None, rnas["filepath"], pp), rr_refdriver("filepath"))
        b3.items = [
            bu_rebuild,
            bu_save_external,
            g_filepath
        ]
        g_filepath.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.8)

        b4 = BlockUtil(self, None, Title("Advanced"))
        g_quality = ButtonGroupAnim(b4, ButtonIntPush(None, rnas["quality"], pp), *rr_fcdr("quality"))
        g_uv_smooth = ButtonGroupAnim(b4, ButtonEnumPush(None, rnas["uv_smooth"], pp), *rr_fcdr("uv_smooth"))
        g_boundary_smooth = ButtonGroupAnim(b4, ButtonEnumPush(None, rnas["boundary_smooth"], pp), *rr_fcdr("boundary_smooth"))
        g_use_creases = ButtonGroupAnimAlignTitleLeft(b4, ButtonBoolPush(None, rnas["use_creases"], pp), *rr_fcdr("use_creases"))
        g_use_custom_normals = ButtonGroupAnimAlignTitleLeft(b4, ButtonBoolPush(None, rnas["use_custom_normals"], pp), *rr_fcdr("use_custom_normals"))
        b4.items = [
            g_quality,
            g_uv_smooth,
            g_boundary_smooth,
            g_use_creases,
            g_use_custom_normals,
        ]

        self.items[:] = [b0, b1, b2, b3, b4]

        def upd_data_callback():
            modifier = self.w.active_modifier
            oj_mode = self.w.active_object.mode

            if modifier.total_levels == 0:
                if g_boundary_smooth.is_dark() is True:
                    g_quality.light()
                    g_uv_smooth.light()
                    g_boundary_smooth.light()
                    g_use_creases.light()
                    g_use_custom_normals.light()
                    bu_rebuild.light()
            else:
                if g_boundary_smooth.is_dark() is False:
                    g_quality.dark()
                    g_uv_smooth.dark()
                    g_boundary_smooth.dark()
                    g_use_creases.dark()
                    g_use_custom_normals.dark()
                    bu_rebuild.dark()

            if oj_mode == 'SCULPT':
                if g_use_sculpt_base_mesh.is_dark() is True: g_use_sculpt_base_mesh.light()
            else:
                if g_use_sculpt_base_mesh.is_dark() is False: g_use_sculpt_base_mesh.dark()

            if oj_mode == 'EDIT':
                if bu_subdivide.is_dark() is False:
                    bu_subdivide.dark()
                    bu_simple.dark()
                    bu_linear.dark()
                    bu_unsubdivide.dark()
                    bu_delete_higher.dark()
                    bu_reshape.dark()
                    bu_apply_base.dark()
            else:
                if bu_subdivide.is_dark() is True:
                    bu_subdivide.light()
                    bu_simple.light()
                    bu_linear.light()
                    bu_unsubdivide.light()
                    bu_delete_higher.light()
                    bu_reshape.light()
                    bu_apply_base.light()

            if modifier.is_external:
                if g_filepath.is_dark() is True:
                    g_filepath.light()
                    bu_save_external.button0.blf_value.text = "Pack External File"
            else:
                if g_filepath.is_dark() is False:
                    g_filepath.dark()
                    bu_save_external.button0.blf_value.text = "Save External File"

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_NODES(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        self.evalcode = ""
        old_node_group = self.w.active_modifier.node_group

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnimRefFull(None, ButtonEnumNodeTreePush(None, rnas["node_group"], pp, {"GEOMETRY"}), rr_refdriver("node_group"), title="")
        ]
        b1 = Blocks(self)
        b1.buttons = []
        b1.area = self
        b1.level = -1

        b2 = BlockUtil(self, [], Title("Output Attributes"))
        b3 = BlockUtil(self, None, Title("Internal Dependencies"))
        g_simulation_bake_directory = ButtonGroupAnimRef(b3, ButtonStringFilePush(None, rnas[attr_NodesModifier_bake_directory], pp), rr_refdriver(attr_NodesModifier_bake_directory), title="Bake")
        b3.items = [
            g_simulation_bake_directory
        ]
        g_simulation_bake_directory.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.8)
        g_simulation_bake_directory.button0.set_callback = update_scene_and_ref

        # bakes: COLLECTION
        # ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["show_group_selector"], pp), *rr_fcdr("show_group_selector")),
        self.items[:] = [b0, b1, b2, b3]

        def upd_data_callback():
            # <<< 1copy (_gn_upd_data_callback,, $$)
            nonlocal old_node_group
            modifier = self.w.active_modifier
            node_group = modifier.node_group

            if old_node_group is not node_group:

                old_node_group = node_group
                self.evalcode = ""
                self.init_tab(self.active_tab, push=False, evtkill=False)
                self.upd_data()
                return

            if node_group:
                evalcode = ""
                for e in node_group.interface.items_tree:
                    if hasattr(e, "in_out"):
                        if e.in_out == "INPUT":
                            if e.bl_socket_idname in D_gn_ui and e.hide_in_modifier == False:
                                use_attr = f'{e.identifier}_use_attribute'
                                if use_attr in modifier and modifier[use_attr]:
                                    evalcode += f'a{e.name}{e.hide_value}{e.description},'
                                else:
                                    if hasattr(e, "subtype"):
                                        evalcode += f'{e.bl_socket_idname}{e.name}{e.hide_value}{e.subtype}{e.description},'
                                    else:
                                        evalcode += f'{e.bl_socket_idname}{e.name}{e.hide_value}{e.description},'
                        else:
                            evalcode += "o,"

                if evalcode != self.evalcode:
                    self.evalcode = evalcode


                    rr_fcdr_gn = self.rr_fcurve_driver_gn
                    ppp = self.r_modifier, self.r_object, self.r_datapath_head_gn

                    b1_buttons = b1.buttons
                    b1_buttons.clear()
                    indent_stack = [b1]
                    active_list = b1_buttons

                    b2_items = b2.items
                    b2_items.clear()

                    for e in node_group.interface.items_tree:
                        if hasattr(e, "in_out"):
                            if e.in_out == "INPUT":
                                if e.bl_socket_idname in D_gn_ui and e.hide_in_modifier == False:
                                    use_attr = f'{e.identifier}_use_attribute'

                                    if use_attr in modifier and modifier[use_attr]:
                                        group = gn_ui_AttrName(b1, e, ppp, rr_fcdr_gn)
                                    else:
                                        group = D_gn_ui[e.bl_socket_idname](b1, e, ppp, rr_fcdr_gn)

                                    format_code = e.description

                                    if format_code[ : 1] == ";":
                                        format_codes = format_code.split(";")
                                        indent, sep, align = gn_format(format_codes)

                                        if indent is not None and indent <= len(indent_stack):
                                            if indent == len(indent_stack):
                                                # <<< 1copy (_gn_new_stack,, $$)
                                                if e.hide_value:
                                                    b_i = BlockUtil(indent_stack[-1], [], Title(e.name))
                                                else:
                                                    if e.bl_socket_idname == "NodeSocketBool":
                                                        if use_attr in modifier and modifier[use_attr]: pass
                                                        else:
                                                            if align == "right": pass
                                                            else:
                                                                group.__class__ = GnGroupBoolStack

                                                    b_i = BlockUtil(indent_stack[-1], [], group)
                                                indent_stack.append(b_i)
                                                active_list.append(b_i)
                                                if sep is not None: active_list.append(ButtonSep(sep))
                                                active_list = b_i.items
                                                # >>>
                                            elif indent == len(indent_stack) - 1:
                                                del indent_stack[indent : ]
                                                active_list = indent_stack[-1].items  if hasattr(indent_stack[-1], "items") else indent_stack[-1].buttons

                                                # <<< 1copy (_gn_new_stack,, $$)
                                                if e.hide_value:
                                                    b_i = BlockUtil(indent_stack[-1], [], Title(e.name))
                                                else:
                                                    if e.bl_socket_idname == "NodeSocketBool":
                                                        if use_attr in modifier and modifier[use_attr]: pass
                                                        else:
                                                            if align == "right": pass
                                                            else:
                                                                group.__class__ = GnGroupBoolStack

                                                    b_i = BlockUtil(indent_stack[-1], [], group)
                                                indent_stack.append(b_i)
                                                active_list.append(b_i)
                                                if sep is not None: active_list.append(ButtonSep(sep))
                                                active_list = b_i.items
                                                # >>>
                                            else:
                                                del indent_stack[indent + 1 : ]
                                                active_list = indent_stack[-1].items  if hasattr(indent_stack[-1], "items") else indent_stack[-1].buttons
                                                # <<< 1copy (_gn_append_active_list_align,, $$)
                                                if align == "hide": pass
                                                elif align == "title" and e.bl_socket_idname == "NodeSocketBool" and not (use_attr in modifier and modifier[use_attr]):
                                                    group.__class__ = GnGroupBoolStack
                                                    active_list.append(group)
                                                else:
                                                    active_list.append(group)
                                                if sep is not None: active_list.append(ButtonSep(sep))
                                                # >>>
                                        else:
                                            # <<< 1copy (_gn_append_active_list_align,, $$)
                                            if align == "hide": pass
                                            elif align == "title" and e.bl_socket_idname == "NodeSocketBool" and not (use_attr in modifier and modifier[use_attr]):
                                                group.__class__ = GnGroupBoolStack
                                                active_list.append(group)
                                            else:
                                                active_list.append(group)
                                            if sep is not None: active_list.append(ButtonSep(sep))
                                            # >>>
                                        continue

                                    active_list.append(group)
                            else:
                                if e.bl_socket_idname in S_gn_output_sockets:
                                    b2_items.append(GnGroupRef(b2, GnOutputAttrName(None, e, ppp), lambda: ""))

                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            else:
                if self.evalcode:
                    self.evalcode = ""
                    b1.buttons.clear()
                    b2.items.clear()
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

            if r_library_editable(self.r_object()) is True:
                if b0.buttons[0].is_dark() is True:
                    b0.buttons[0].light()
                    b3.items[0].light()
            else:
                if b0.buttons[0].is_dark() is False:
                    b0.buttons[0].dark()
                    b3.items[0].dark()

            for e in self.items: e.upd_data()
            # >>>

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_NORMAL_EDIT(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        bu_offset = ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["offset"], pp), *rr_fcdr_array("offset", RANGE_3))
        g_use_direction_parallel = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_direction_parallel"], pp), *rr_fcdr("use_direction_parallel"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mode"], pp), *rr_fcdr("mode")),
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["target"], pp, r_except_objects=self.r_object_set), rr_refdriver("target")),
            g_use_direction_parallel,
            bu_offset
        ]

        b1 = BlockUtil(self, None, Title("Mix"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b1.items = [
            ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["mix_mode"], pp), *rr_fcdr("mix_mode")),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["mix_factor"], pp), *rr_fcdr("mix_factor")),
            ButtonGroupAnimRef(b1, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["mix_limit"], pp), *rr_fcdr("mix_limit")),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["no_polynors_fix"], pp), *rr_fcdr("no_polynors_fix"))
        ]

        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if ((modifier.mode == 'RADIAL') and not modifier.target) or ((modifier.mode == 'DIRECTIONAL') and modifier.use_direction_parallel):
                if bu_offset.is_dark() is True: bu_offset.light()
            else:
                if bu_offset.is_dark() is False: bu_offset.dark()

            if modifier.mode == 'DIRECTIONAL':
                if g_use_direction_parallel.is_dark() is True: g_use_direction_parallel.light()
            else:
                if g_use_direction_parallel.is_dark() is False: g_use_direction_parallel.dark()

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_OCEAN(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["geometry_mode"], pp), *rr_fcdr("geometry_mode")),
            ButtonGroupAnimRef(b0, ButtonIntPush(None, rnas["repeat_x"], pp), rr_refdriver("repeat_x")),
            ButtonGroupAnimRef(b0, ButtonIntPush(None, rnas["repeat_y"], pp), rr_refdriver("repeat_y")),
            ButtonGroupAnimRef(b0, ButtonIntPush(None, rnas["viewport_resolution"], pp), rr_refdriver("viewport_resolution")),
            ButtonGroupAnimRef(b0, ButtonIntPush(None, rnas["resolution"], pp), rr_refdriver("resolution")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["time"], pp), *rr_fcdr("time")),
            ButtonGroupAnimRef(b0, ButtonFloatPush(None, rnas["depth"], pp), rr_refdriver("depth")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["size"], pp), *rr_fcdr("size")),
            ButtonGroupAnimRef(b0, ButtonIntPush(None, rnas["spatial_size"], pp), rr_refdriver("spatial_size")),
            ButtonGroupAnimRef(b0, ButtonIntPush(None, rnas["random_seed"], pp), rr_refdriver("random_seed")),
            ButtonGroupAnimRefAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_normals"], pp), rr_refdriver("use_normals")),
        ]

        b1 = BlockUtil(self, None, Title("Waves"))
        g_wave_direction = ButtonGroupAnimRef(b1, ButtonFloatPush(None, rnas["wave_direction"], pp), rr_refdriver("wave_direction"))
        g_damping = ButtonGroupAnimRef(b1, ButtonFloatPush(None, rnas["damping"], pp), rr_refdriver("damping"))
        b1.items = [
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["wave_scale"], pp), *rr_fcdr("wave_scale")),
            ButtonGroupAnimRef(b1, ButtonFloatPush(None, rnas["wave_scale_min"], pp), rr_refdriver("wave_scale_min")),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["choppiness"], pp), *rr_fcdr("choppiness")),
            ButtonGroupAnimRef(b1, ButtonFloatPush(None, rnas["wind_velocity"], pp), rr_refdriver("wind_velocity")),
            ButtonSep(3),
            ButtonGroupAnimRef(b1, ButtonFloatPush(None, rnas["wave_alignment"], pp), rr_refdriver("wave_alignment")),
            g_wave_direction,
            g_damping,
        ]

        b2 = BlockUtil(self, None,
            ButtonGroupAnimRefAlignL(None, ButtonBoolPush(None, rnas["use_foam"], pp), rr_refdriver("use_foam"), title="Foam")
        )
        g_use_spray = ButtonGroupAnimRefAlignL(None, ButtonBoolPush(None, rnas["use_spray"], pp), rr_refdriver("use_spray"), title="Spray")
        b20 = BlockUtil(b2, None, g_use_spray)
        g_spray_layer_name = ButtonGroupAnimRef(b20, ButtonStringPush(None, rnas["spray_layer_name"], pp), rr_refdriver("spray_layer_name"))
        g_invert_spray = ButtonGroupAnimRefAlignTitleLeft(b20, ButtonBoolPush(None, rnas["invert_spray"], pp), rr_refdriver("invert_spray"))
        b20.items = [
            g_spray_layer_name,
            g_invert_spray
        ]
        g_foam_layer_name = ButtonGroupAnimRef(b2, ButtonStringPush(None, rnas["foam_layer_name"], pp), rr_refdriver("foam_layer_name"))
        g_foam_coverage = ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["foam_coverage"], pp), *rr_fcdr("foam_coverage"))
        b2.items = [
            g_foam_layer_name,
            g_foam_coverage,
            b20,
        ]

        b3 = BlockUtil(self, None, Title("Spectrum"))
        b3.items = [
            ButtonGroupAnimRef(b3, ButtonEnumPush(None, rnas["spectrum"], pp), rr_refdriver("spectrum")),
            ButtonGroupAnimRef(b3, ButtonFloatPush(None, rnas["sharpen_peak_jonswap"], pp), rr_refdriver("sharpen_peak_jonswap")),
            ButtonGroupAnimRef(b3, ButtonFloatPush(None, rnas["fetch_jonswap"], pp), rr_refdriver("fetch_jonswap"))
        ]

        b4 = BlockUtil(self, None, Title("Bake"))
        g_bake_foam_fade = ButtonGroupAnimRef(b4, ButtonFloatPush(None, rnas["bake_foam_fade"], pp), rr_refdriver("bake_foam_fade"))
        g_bake = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_OCEAN_bake, self.bufn_OCEAN_bake), title="")
        g_filepath = ButtonGroupAnimRef(b4, ButtonStringFilePush(None, rnas["filepath"], pp), rr_refdriver("filepath"))
        b4.items = [
            g_bake,
            g_filepath,
            ButtonGroupAnimRef(b4, ButtonIntPush(None, rnas["frame_start"], pp), rr_refdriver("frame_start")),
            ButtonGroupAnimRef(b4, ButtonIntPush(None, rnas["frame_end"], pp), rr_refdriver("frame_end")),
            g_bake_foam_fade,
        ]
        bu_bake_blf = g_bake.button0.blf_value
        g_filepath.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.8)
        g_filepath.button0.set_callback = update_scene_and_ref
        g_bake_foam_fade.button0.set_callback = update_scene_and_ref

        self.items[:] = [b0, b1, b2, b3, b4]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.wave_alignment > 0.0:
                if g_wave_direction.is_dark() is True:
                    g_wave_direction.light()
                    g_damping.light()
            else:
                if g_wave_direction.is_dark() is False:
                    g_wave_direction.dark()
                    g_damping.dark()

            if modifier.use_foam:
                if g_bake_foam_fade.is_dark() is True: g_bake_foam_fade.light()

                if g_foam_layer_name.is_dark() is True:
                    g_foam_layer_name.light()
                    g_foam_coverage.light()
                    g_use_spray.light()

                if modifier.use_spray:
                    if g_spray_layer_name.is_dark() is True:
                        g_spray_layer_name.light()
                        g_invert_spray.light()
                else:
                    if g_spray_layer_name.is_dark() is False:
                        g_spray_layer_name.dark()
                        g_invert_spray.dark()
            else:
                if g_bake_foam_fade.is_dark() is False: g_bake_foam_fade.dark()

                if g_foam_layer_name.is_dark() is False:
                    g_foam_layer_name.dark()
                    g_foam_coverage.dark()
                    g_use_spray.dark()

                if g_spray_layer_name.is_dark() is False:
                    g_spray_layer_name.dark()
                    g_invert_spray.dark()

            bu_bake_blf.text = "Free Cache"  if modifier.is_cached else "Bake Ocean"

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_PARTICLE_INSTANCE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        def r_fcurve_use_ins():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_normal'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_children'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_size')
                ]
            return [None] * 3
            #|
        def r_driver_use_ins():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_normal'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_children'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_size')
                ]
            return [None] * 3
            #|
        def r_fcurve_show():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].show_alive'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].show_dead'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].show_unborn')
                ]
            return [None] * 3
            #|
        def r_driver_show():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].show_alive'),
                    self.object_drivers.find(f'modifiers["{escapename}"].show_dead'),
                    self.object_drivers.find(f'modifiers["{escapename}"].show_unborn')
                ]
            return [None] * 3
            #|

        def r_button_width(): return round(D_SIZE['widget_width'] * 1.55)

        g_particle_system = ButtonGroupAnimRef(b0, ButtonEnumParticlePush(None, rnas["particle_system"], pp, lambda: self.w.active_modifier.object), rr_refdriver("particle_system"))
        g_particle_system_index = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["particle_system_index"], pp), *rr_fcdr("particle_system_index"))
        g_use = ButtonGroupAnimBoolArray(b0, [rnas["use_normal"], rnas["use_children"], rnas["use_size"]], pp, r_fcurve_use_ins, r_driver_use_ins, title="Create Instances")
        g_show = ButtonGroupAnimBoolArray(b0, [rnas["show_alive"], rnas["show_dead"], rnas["show_unborn"]], pp, r_fcurve_show, r_driver_show, title="Show")
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("object")),
            g_particle_system,
            g_particle_system_index,
            ButtonSep(3),
            g_use,
            g_show,
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["particle_amount"], pp), *rr_fcdr("particle_amount")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["particle_offset"], pp), *rr_fcdr("particle_offset")),
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["space"], pp, row_length=2), *rr_fcdr("space")),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["axis"], pp, row_length=3), *rr_fcdr("axis")),
        ]
        g_use.r_button_width = r_button_width
        g_show.r_button_width = r_button_width

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_path"], pp), *rr_fcdr("use_path"), title="Create Along Paths")
        )
        g_position = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["position"], pp), *rr_fcdr("position"))
        g_random_position = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["random_position"], pp), *rr_fcdr("random_position"))
        g_rotation = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["rotation"], pp), *rr_fcdr("rotation"))
        g_random_rotation = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["random_rotation"], pp), *rr_fcdr("random_rotation"))
        g_use_preserve_shape = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_preserve_shape"], pp), *rr_fcdr("use_preserve_shape"))
        b1.items = [
            g_position,
            g_random_position,
            g_rotation,
            g_random_rotation,
            g_use_preserve_shape,
        ]

        b2 = BlockUtil(self, None, Title("Layers"))
        b2.items = [
            ButtonGroupAnimRef(b2, ButtonEnumVertexColorPush(None, rnas["index_layer_name"], pp), rr_refdriver("index_layer_name"), title="Index"),
            ButtonGroupAnimRef(b2, ButtonEnumVertexColorPush(None, rnas["value_layer_name"], pp), rr_refdriver("value_layer_name"), title="Value"),
        ]

        self.items[:] = [b0, b1, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.object:
                if g_particle_system.is_dark() is True:
                    g_particle_system.light()
                    g_particle_system_index.dark()
            else:
                if g_particle_system.is_dark() is False:
                    g_particle_system.dark()
                    g_particle_system_index.light()

            if modifier.use_path:
                if g_position.is_dark() is True:
                    g_position.light()
                    g_random_position.light()
                    g_rotation.light()
                    g_random_rotation.light()
                    g_use_preserve_shape.light()
            else:
                if g_position.is_dark() is False:
                    g_position.dark()
                    g_random_position.dark()
                    g_rotation.dark()
                    g_random_rotation.dark()
                    g_use_preserve_shape.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_PARTICLE_SYSTEM(self):

        b0 = Blocks(self)
        b0.buttons = [Title("  Settings are inside the Physics tab")]
        self.items[:] = [b0]
        #|
    def init_tab_REMESH(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_mode = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["mode"], pp, row_length=4), *rr_fcdr("mode"))
        g_use_smooth_shade = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_smooth_shade"], pp), *rr_fcdr("use_smooth_shade"))
        g_voxel_size = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["voxel_size"], pp), *rr_fcdr("voxel_size"))
        g_adaptivity = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["adaptivity"], pp), *rr_fcdr("adaptivity"))
        g_octree_depth = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["octree_depth"], pp), *rr_fcdr("octree_depth"))
        g_scale = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["scale"], pp), *rr_fcdr("scale"))
        g_sharpness = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["sharpness"], pp), *rr_fcdr("sharpness"))
        g_use_remove_disconnected = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_remove_disconnected"], pp), *rr_fcdr("use_remove_disconnected"))
        g_threshold = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["threshold"], pp), *rr_fcdr("threshold"))
        b0.buttons = [
            g_mode,
            g_use_smooth_shade,
            g_voxel_size,
            g_adaptivity,
            ButtonSep(2),
            g_octree_depth,
            g_scale,
            g_sharpness,
            g_use_remove_disconnected,
            g_threshold
        ]
        g_mode.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.8)
        def r_button_width(): return round(D_SIZE['widget_width'] * 1.1)
        g_use_smooth_shade.r_button_width = r_button_width
        g_voxel_size.r_button_width = r_button_width
        g_adaptivity.r_button_width = r_button_width
        g_octree_depth.r_button_width = r_button_width
        g_scale.r_button_width = r_button_width
        g_sharpness.r_button_width = r_button_width
        g_use_remove_disconnected.r_button_width = r_button_width
        g_threshold.r_button_width = r_button_width

        g_octree_depth.dark()
        g_scale.dark()
        g_sharpness.dark()
        g_use_remove_disconnected.dark()
        g_threshold.dark()

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.mode == "VOXEL":
                if g_voxel_size.is_dark() is True:
                    g_voxel_size.light()
                    g_adaptivity.light()
                    g_octree_depth.dark()
                    g_scale.dark()
                    g_sharpness.dark()
                    g_use_remove_disconnected.dark()
                    g_threshold.dark()
            else:
                if g_voxel_size.is_dark() is False:
                    g_voxel_size.dark()
                    g_sharpness.dark()
                    g_adaptivity.dark()
                    g_octree_depth.light()
                    g_scale.light()
                    g_use_remove_disconnected.light()
                    g_threshold.light()

                if modifier.mode == "SHARP":
                    if g_sharpness.is_dark() is True: g_sharpness.light()
                else:
                    if g_sharpness.is_dark() is False: g_sharpness.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_SCREW(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_fcurve_use():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_stretch_u'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_stretch_v')
                ]
            return [None] * 2
        def r_driver_use():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_stretch_u'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_stretch_v')
                ]
            return [None] * 2

        b0 = Blocks(self)
        g_screw_offset = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["screw_offset"], pp), *rr_fcdr("screw_offset"))
        g_use_object_screw_offset = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_object_screw_offset"], pp), *rr_fcdr("use_object_screw_offset"))
        g_use_merge_vertices = ButtonGroupAnimBoolAlignR(b0, ButtonBoolPush(None, rnas["use_merge_vertices"], pp), *rr_fcdr("use_merge_vertices"))
        g_merge_threshold = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["merge_threshold"], pp), *rr_fcdr("merge_threshold"), title="")
        g_merge_threshold_box_button = g_merge_threshold.button0.box_button
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["angle"], pp), *rr_fcdr("angle")),
            g_screw_offset,
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["iterations"], pp), *rr_fcdr("iterations")),
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["axis"], pp, row_length=3), *rr_fcdr("axis")),
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object")),
            g_use_object_screw_offset,
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["steps"], pp), *rr_fcdr("steps"), title="Viewport Steps"),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["render_steps"], pp), *rr_fcdr("render_steps")),
            ButtonSep(3),
            ButtonSplitBool(b0, g_use_merge_vertices, g_merge_threshold, lambda: g_merge_threshold_box_button.L, gap=lambda: SIZE_widget[0] // 4),
            ButtonSep(3),
            ButtonGroupAnimBoolArray(b0, [rnas["use_stretch_u"], rnas["use_stretch_v"]], pp, r_fcurve_use, r_driver_use, title="Stretch UVs", button_text=("U", "V")),
        ]

        b1 = BlockUtil(self, None, Title("Normals"))
        b1.items = [
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_smooth_shade"], pp), *rr_fcdr("use_smooth_shade")),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_normal_calculate"], pp), *rr_fcdr("use_normal_calculate")),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_normal_flip"], pp), *rr_fcdr("use_normal_flip")),
        ]

        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.object:
                if g_use_object_screw_offset.is_dark() is True: g_use_object_screw_offset.light()

                if modifier.use_object_screw_offset:
                    if g_screw_offset.is_dark() is False: g_screw_offset.dark()
                else:
                    if g_screw_offset.is_dark() is True: g_screw_offset.light()
            else:
                if g_use_object_screw_offset.is_dark() is False: g_use_object_screw_offset.dark()

                if g_screw_offset.is_dark() is True: g_screw_offset.light()

            if modifier.use_merge_vertices:
                if g_merge_threshold.is_dark() is True: g_merge_threshold.light()
            else:
                if g_merge_threshold.is_dark() is False: g_merge_threshold.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_SHRINKWRAP(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_fcurve_use():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_project_x'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_project_y'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_project_z')
                ]
            return [None] * 3
        def r_driver_use():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_project_x'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_project_y'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_project_z')
                ]
            return [None] * 3

        b0 = Blocks(self)
        g_wrap_method = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["wrap_method"], pp, row_length=2), *rr_fcdr("wrap_method"), title="Wrap")
        g_wrap_mode = ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["wrap_mode"], pp), *rr_fcdr("wrap_mode"))
        g_auxiliary_target = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["auxiliary_target"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("auxiliary_target"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_project_limit = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["project_limit"], pp), *rr_fcdr("project_limit"))
        g_subsurf_levels = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["subsurf_levels"], pp), *rr_fcdr("subsurf_levels"))
        g_use_project = ButtonGroupAnimBoolArray(b0, [rnas["use_project_x"], rnas["use_project_y"], rnas["use_project_z"]], pp, r_fcurve_use, r_driver_use, title="Axis", button_text=TUP_XYZ)
        g_use_negative_direction = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_negative_direction"], pp), *rr_fcdr("use_negative_direction"))
        g_use_positive_direction = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_positive_direction"], pp), *rr_fcdr("use_positive_direction"))
        g_cull_face = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["cull_face"], pp, row_length=3), *rr_fcdr("cull_face"))
        g_use_invert_cull = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_invert_cull"], pp), *rr_fcdr("use_invert_cull"))
        b0.buttons = [
            g_wrap_method,
            ButtonSep(3),
            g_wrap_mode,
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["target"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("target")),
            g_auxiliary_target,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["offset"], pp), *rr_fcdr("offset")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            ButtonSep(3),
            g_project_limit,
            g_subsurf_levels,
            ButtonSep(3),
            g_use_project,
            g_use_negative_direction,
            g_use_positive_direction,
            ButtonSep(3),
            g_cull_face,
            g_use_invert_cull,
        ]
        g_wrap_method.r_button_width = lambda: round(D_SIZE['widget_width'] * 2.0)

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.wrap_method == "PROJECT":
                if g_project_limit.is_dark() is True:
                    g_project_limit.light()
                    g_subsurf_levels.light()
                    g_use_project.light()
                    g_use_negative_direction.light()
                    g_use_positive_direction.light()
                    g_cull_face.light()
                    g_auxiliary_target.light()

                if g_wrap_mode.is_dark() is True: g_wrap_mode.light()

                if modifier.use_negative_direction and modifier.cull_face in {"FRONT", "BACK"}:
                    if g_use_invert_cull.is_dark() is True: g_use_invert_cull.light()
                else:
                    if g_use_invert_cull.is_dark() is False: g_use_invert_cull.dark()
            else:
                if g_project_limit.is_dark() is False:
                    g_project_limit.dark()
                    g_subsurf_levels.dark()
                    g_use_project.dark()
                    g_use_negative_direction.dark()
                    g_use_positive_direction.dark()
                    g_cull_face.dark()
                    g_use_invert_cull.dark()
                    g_auxiliary_target.dark()

                if modifier.wrap_method == "NEAREST_VERTEX":
                    if g_wrap_mode.is_dark() is False: g_wrap_mode.dark()
                else:
                    if g_wrap_mode.is_dark() is True: g_wrap_mode.light()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_SIMPLE_DEFORM(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_fcurve_use():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].lock_x'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].lock_y'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].lock_z')
                ]
            return [None] * 3
        def r_driver_use():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].lock_x'),
                    self.object_drivers.find(f'modifiers["{escapename}"].lock_y'),
                    self.object_drivers.find(f'modifiers["{escapename}"].lock_z')
                ]
            return [None] * 3

        b0 = Blocks(self)
        g_deform_method = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["deform_method"], pp, row_length=4), *rr_fcdr("deform_method"))
        g_angle = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["angle"], pp), *rr_fcdr("angle"))
        g_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor"))
        b0.buttons = [
            g_deform_method,
            ButtonSep(3),
            g_angle,
            g_factor,
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["origin"], pp, r_except_objects=self.r_object_set), rr_refdriver("origin")),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["deform_axis"], pp, row_length=3), *rr_fcdr("deform_axis")),
        ]
        g_deform_method.r_button_width = lambda: round(D_SIZE['widget_width'] * 2.0)

        b1 = BlockUtil(self, None, Title("Restrictions"))
        g_lock = ButtonGroupAnimBoolArray(b1, [rnas["lock_x"], rnas["lock_y"], rnas["lock_z"]], pp, r_fcurve_use, r_driver_use, title="Axis", button_text=TUP_XYZ)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b1.items = [
            ButtonGroupAnimVector(b1, ButtonFloatVectorPush(None, rnas["limits"], pp), *rr_fcdr_array("limits", RANGE_3)),
            ButtonSep(),
            g_lock,
            ButtonSep(),
            ButtonGroupAnimRef(b1, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group
        ]
        g_lock_button0 = g_lock.buttons[-1]
        bu_lock_x, bu_lock_y, bu_lock_z = g_lock_button0.box_button

        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.deform_method in {"TAPER", "STRETCH"}:
                if g_factor.is_dark() is True:
                    g_factor.light()
                    g_angle.dark()
            else:
                if g_factor.is_dark() is False:
                    g_factor.dark()
                    g_angle.light()

            if modifier.deform_method == "BEND":
                g_lock.dark_title()
                if bu_lock_x.is_dark() is False: g_lock_button0.dark_index(0)
                if bu_lock_y.is_dark() is False: g_lock_button0.dark_index(1)
                if bu_lock_z.is_dark() is False: g_lock_button0.dark_index(2)
            else:
                deform_axis = modifier.deform_axis
                if deform_axis == "X":
                    g_lock.light_title()
                    if bu_lock_x.is_dark() is False: g_lock_button0.dark_index(0)
                    if bu_lock_y.is_dark() is True: g_lock_button0.light_index(1)
                    if bu_lock_z.is_dark() is True: g_lock_button0.light_index(2)
                elif deform_axis == "Y":
                    g_lock.light_title()
                    if bu_lock_x.is_dark() is True: g_lock_button0.light_index(0)
                    if bu_lock_y.is_dark() is False: g_lock_button0.dark_index(1)
                    if bu_lock_z.is_dark() is True: g_lock_button0.light_index(2)
                elif deform_axis == "Z":
                    g_lock.light_title()
                    if bu_lock_x.is_dark() is True: g_lock_button0.light_index(0)
                    if bu_lock_y.is_dark() is True: g_lock_button0.light_index(1)
                    if bu_lock_z.is_dark() is False: g_lock_button0.dark_index(2)
                else:
                    g_lock.dark_title()
                    if bu_lock_x.is_dark() is False: g_lock_button0.dark_index(0)
                    if bu_lock_y.is_dark() is False: g_lock_button0.dark_index(1)
                    if bu_lock_z.is_dark() is False: g_lock_button0.dark_index(2)

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_SKIN(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_fcurve_use():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_x_symmetry'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_y_symmetry'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_z_symmetry')
                ]
            return [None] * 3
        def r_driver_use():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_x_symmetry'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_y_symmetry'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_z_symmetry')
                ]
            return [None] * 3

        b0 = Blocks(self)
        bu_create_armature = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_SKIN_create_armature, self.bufn_SKIN_create_armature), title="")
        bu_add_skin_data = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_SKIN_add_skin_data, self.bufn_SKIN_add_skin_data), title="")
        bu_mark_loose = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_SKIN_mark_loose, self.bufn_SKIN_mark_loose), title="")
        bu_clear_loose = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_SKIN_clear_loose, self.bufn_SKIN_clear_loose), title="")
        bu_mark_root = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_SKIN_mark_root, self.bufn_SKIN_mark_root), title="")
        bu_equalize_radii = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_SKIN_equalize_radii, self.bufn_SKIN_equalize_radii), title="")
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["branch_smoothing"], pp), *rr_fcdr("branch_smoothing")),
            ButtonGroupAnimBoolArray(b0, [rnas["use_x_symmetry"], rnas["use_y_symmetry"], rnas["use_z_symmetry"]], pp, r_fcurve_use, r_driver_use, title="Symmetry", button_text=TUP_XYZ),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_smooth_shade"], pp), *rr_fcdr("use_smooth_shade")),
            ButtonSep(3),
            ButtonSplitBool(b0, bu_create_armature, bu_add_skin_data, lambda: bu_add_skin_data.button0.box_button.L + SIZE_widget[0]),
            ButtonSplitBool(b0, bu_mark_loose, bu_clear_loose, lambda: bu_clear_loose.button0.box_button.L + SIZE_widget[0]),
            ButtonSep(2),
            bu_mark_root,
            bu_equalize_radii
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier
            ob = self.w.active_object
            has_skin_data = True  if ob.data.skin_vertices else False

            if ob.mode == "EDIT":
                if bu_mark_loose.is_dark() is True:
                    bu_mark_loose.light()
                    bu_clear_loose.light()
                    bu_mark_root.light()
                    bu_equalize_radii.light()

                if bu_create_armature.is_dark() is False: bu_create_armature.dark()
            else:
                if bu_mark_loose.is_dark() is False:
                    bu_mark_loose.dark()
                    bu_clear_loose.dark()
                    bu_mark_root.dark()
                    bu_equalize_radii.dark()

                if has_skin_data:
                    if bu_create_armature.is_dark() is True: bu_create_armature.light()
                else:
                    if bu_create_armature.is_dark() is False: bu_create_armature.dark()

            if has_skin_data:
                if bu_add_skin_data.is_dark() is False: bu_add_skin_data.dark()
            else:
                if bu_add_skin_data.is_dark() is True: bu_add_skin_data.light()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_SMOOTH(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnimBoolArray(b0, [rnas["use_x"], rnas["use_y"], rnas["use_z"]], pp, self.r_fcurve_use_xyz, self.r_driver_use_xyz, title="Axis", button_text=TUP_XYZ),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["iterations"], pp), *rr_fcdr("iterations")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_SOFT_BODY(self):

        b0 = Blocks(self)
        b0.buttons = [Title("  Settings are inside the Physics tab")]
        self.items[:] = [b0]
        #|
    def init_tab_SOLIDIFY(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_nonmanifold_thickness_mode = ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["nonmanifold_thickness_mode"], pp), *rr_fcdr("nonmanifold_thickness_mode"))
        g_nonmanifold_boundary_mode = ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["nonmanifold_boundary_mode"], pp), *rr_fcdr("nonmanifold_boundary_mode"))
        g_use_even_offset = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_even_offset"], pp), *rr_fcdr("use_even_offset"))
        g_use_rim_only = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_rim_only"], pp), *rr_fcdr("use_rim_only"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        g_thickness_vertex_group = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["thickness_vertex_group"], pp), *rr_fcdr("thickness_vertex_group"))
        g_use_flat_faces = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_flat_faces"], pp), *rr_fcdr("use_flat_faces"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["solidify_mode"], pp, row_length=2), *rr_fcdr("solidify_mode")),
            g_nonmanifold_thickness_mode,
            g_nonmanifold_boundary_mode,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["thickness"], pp), *rr_fcdr("thickness")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["offset"], pp), *rr_fcdr("offset")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["nonmanifold_merge_threshold"], pp), *rr_fcdr("nonmanifold_merge_threshold")),
            g_use_even_offset,
            ButtonSep(2),
            ButtonGroupAnimAlignLR(b0, ButtonBoolPush(None, rnas["use_rim"], pp), *rr_fcdr("use_rim"), title="Fill", title_head="Rim"),
            g_use_rim_only,
            ButtonSep(2),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            g_thickness_vertex_group,
            g_use_flat_faces,
        ]

        b1 = BlockUtil(self, None, Title("Normals"))
        g_use_quality_normals = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_quality_normals"], pp), *rr_fcdr("use_quality_normals"), title="High Quality")
        b1.items = [
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_flip_normals"], pp), *rr_fcdr("use_flip_normals"), title="Flip"),
            g_use_quality_normals,
        ]

        b2 = BlockUtil(self, None, Title("Materials"))
        g_material_offset_rim = ButtonGroupAnim(b2, ButtonIntPush(None, rnas["material_offset_rim"], pp), *rr_fcdr("material_offset_rim"), title="Rim Offset")
        b2.items = [
            ButtonGroupAnim(b2, ButtonIntPush(None, rnas["material_offset"], pp), *rr_fcdr("material_offset"), title="Offset"),
            g_material_offset_rim,
        ]

        b3 = BlockUtil(self, None, Title("Edge Data"))
        g_edge_crease_inner = ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["edge_crease_inner"], pp), *rr_fcdr("edge_crease_inner"))
        g_edge_crease_outer = ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["edge_crease_outer"], pp), *rr_fcdr("edge_crease_outer"))
        g_edge_crease_rim = ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["edge_crease_rim"], pp), *rr_fcdr("edge_crease_rim"))
        b3.items = [
            g_edge_crease_inner,
            g_edge_crease_outer,
            g_edge_crease_rim,
            ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["bevel_convex"], pp), *rr_fcdr("bevel_convex")),
        ]

        b4 = BlockUtil(self, None, Title("Thickness Clamp"))
        g_use_thickness_angle_clamp = ButtonGroupAnimAlignTitleLeft(b4, ButtonBoolPush(None, rnas["use_thickness_angle_clamp"], pp), *rr_fcdr("use_thickness_angle_clamp"))
        b4.items = [
            ButtonGroupAnim(b4, ButtonFloatPush(None, rnas["thickness_clamp"], pp), *rr_fcdr("thickness_clamp")),
            g_use_thickness_angle_clamp,
        ]

        b5 = BlockUtil(self, None, Title("Output Vertex Groups"))
        b5.items = [
            ButtonGroupAnimRef(b5, ButtonEnumVertexGroupPush(None, rnas["shell_vertex_group"], pp), rr_refdriver("shell_vertex_group"), title="Shell"),
            ButtonGroupAnimRef(b5, ButtonEnumVertexGroupPush(None, rnas["rim_vertex_group"], pp), rr_refdriver("rim_vertex_group"), title="Rim"),
        ]

        self.items[:] = [b0, b1, b2, b3, b4, b5]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.thickness_clamp > 0.0:
                if g_use_thickness_angle_clamp.is_dark() is True: g_use_thickness_angle_clamp.light()
            else:
                if g_use_thickness_angle_clamp.is_dark() is False: g_use_thickness_angle_clamp.dark()

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True:
                    g_invert_vertex_group.light()
                    g_thickness_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False:
                    g_invert_vertex_group.dark()
                    g_thickness_vertex_group.dark()

            if modifier.solidify_mode == 'NON_MANIFOLD':
                if modifier.vertex_group:
                    if g_use_flat_faces.is_dark() is True: g_use_flat_faces.light()
                else:
                    if g_use_flat_faces.is_dark() is False: g_use_flat_faces.dark()

                if g_use_quality_normals.is_dark() is False:
                    g_use_quality_normals.dark()
                    g_use_even_offset.dark()
                    g_edge_crease_inner.dark()
                    g_edge_crease_outer.dark()
                    g_edge_crease_rim.dark()

                if g_nonmanifold_thickness_mode.is_dark() is True:
                    g_nonmanifold_thickness_mode.light()
                    g_nonmanifold_boundary_mode.light()
            else:
                if g_use_flat_faces.is_dark() is False: g_use_flat_faces.dark()

                if g_use_quality_normals.is_dark() is True:
                    g_use_quality_normals.light()
                    g_use_even_offset.light()
                    g_edge_crease_inner.light()
                    g_edge_crease_outer.light()
                    g_edge_crease_rim.light()

                if g_nonmanifold_thickness_mode.is_dark() is False:
                    g_nonmanifold_thickness_mode.dark()
                    g_nonmanifold_boundary_mode.dark()

            if modifier.use_rim:
                if g_use_rim_only.is_dark() is True:
                    g_use_rim_only.light()
                    g_material_offset_rim.light()
            else:
                if g_use_rim_only.is_dark() is False:
                    g_use_rim_only.dark()
                    g_material_offset_rim.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_SUBSURF(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_cycles(): return self.w.active_object.cycles
        def r_datapath_head_cycles(full=False):
            if full:
                return f'{r_ID_dp(self.w.active_object)}.cycles.'
            return 'cycles.'
        def rr_fcdr_cycles(attr):
            def r_fcurve():
                if self.object_fcurves:
                    return self.object_fcurves.find(f'cycles.{attr}')
                return None
            def r_driver():
                if self.object_drivers:
                    return self.object_drivers.find(f'cycles.{attr}')
                return None
            return r_fcurve, r_driver

        b0 = Blocks(self)
        g_subdivision_type = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["subdivision_type"], pp, row_length=2), *rr_fcdr("subdivision_type"), title="Type")
        g_render_levels = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["render_levels"], pp), *rr_fcdr("render_levels"), title="Render")
        b0.buttons = [
            g_subdivision_type,
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["levels"], pp), *rr_fcdr("levels"), title="Levels Viewport"),
            g_render_levels,
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["show_only_control_edges"], pp), *rr_fcdr("show_only_control_edges")),
        ]
        g_subdivision_type.r_button_width = lambda: round(D_SIZE['widget_width'] * 2.0)
        g_render_levels.button0.set_callback = update_scene_and_ref

        b1 = BlockUtil(self, None, Title("Advanced"))
        g_use_limit_surface = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_limit_surface"], pp), *rr_fcdr("use_limit_surface"))
        g_quality = ButtonGroupAnim(b1, ButtonIntPush(None, rnas["quality"], pp), *rr_fcdr("quality"))
        g_uv_smooth = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["uv_smooth"], pp), *rr_fcdr("uv_smooth"))
        g_boundary_smooth = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["boundary_smooth"], pp), *rr_fcdr("boundary_smooth"))
        g_use_creases = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_creases"], pp), *rr_fcdr("use_creases"))
        g_use_custom_normals = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_custom_normals"], pp), *rr_fcdr("use_custom_normals"))
        b1.items = [
            g_use_limit_surface,
            g_quality,
            g_uv_smooth,
            g_boundary_smooth,
            g_use_creases,
            g_use_custom_normals,
        ]

        ppp = r_cycles, self.r_object, r_datapath_head_cycles
        rnas_cycles = self.w.active_object.cycles.bl_rna.properties
        g_use_adaptive_subdivision = ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas_cycles["use_adaptive_subdivision"], ppp), *rr_fcdr_cycles("use_adaptive_subdivision"))
        b2 = BlockUtil(self, None, g_use_adaptive_subdivision)
        g_dicing_rate = ButtonGroupAnim(b2, ButtonFloatPush(None, rnas_cycles["dicing_rate"], ppp), *rr_fcdr_cycles("dicing_rate"))
        bu_info = Title("")
        bu_info_blf = bu_info.blf_title
        b2.items = [
            g_dicing_rate,
            bu_info
        ]
        g_use_adaptive_subdivision.button0.set_callback = update_scene_and_ref
        g_dicing_rate.button0.set_callback = update_scene_and_ref

        self.items[:] = [b0, b1, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier
            cycles = self.w.active_object.cycles
            show_adaptive_options = (
                bpy.context.engine == 'CYCLES' and modifier == self.w.active_object.modifiers[-1]
                and bpy.context.scene.cycles.feature_set == 'EXPERIMENTAL' and modifier.use_limit_surface
            )
            if show_adaptive_options is True:
                if g_use_adaptive_subdivision.is_dark() is True: g_use_adaptive_subdivision.light()

                if cycles.use_adaptive_subdivision:
                    scene_cycles = bpy.context.scene.cycles
                    bu_info_blf.text = f"   Final Scale :  Render {max(scene_cycles.dicing_rate * cycles.dicing_rate, 0.1):.2f} px    Viewport {max(scene_cycles.preview_dicing_rate * cycles.dicing_rate, 0.1):.2f} px"

                    if g_dicing_rate.is_dark() is True: g_dicing_rate.light()

                    if g_use_limit_surface.is_dark() is False:
                        g_use_limit_surface.dark()
                        g_render_levels.dark()
                        g_quality.dark()
                        g_uv_smooth.dark()
                        g_boundary_smooth.dark()
                        g_use_creases.dark()
                        g_use_custom_normals.dark()
                else:
                    bu_info_blf.text = ""

                    if g_dicing_rate.is_dark() is False: g_dicing_rate.dark()

                    if g_use_limit_surface.is_dark() is True:
                        g_use_limit_surface.light()
                        g_render_levels.light()
                        g_uv_smooth.light()
                        g_boundary_smooth.light()
                        g_use_creases.light()
                        g_use_custom_normals.light()

                    if modifier.use_limit_surface:
                        if g_quality.is_dark() is True: g_quality.light()
                    else:
                        if g_quality.is_dark() is False: g_quality.dark()
            else:
                if g_use_adaptive_subdivision.is_dark() is False: g_use_adaptive_subdivision.dark()

                bu_info_blf.text = ""

                if g_dicing_rate.is_dark() is False: g_dicing_rate.dark()

                if g_use_limit_surface.is_dark() is True:
                    g_use_limit_surface.light()
                    g_render_levels.light()
                    g_uv_smooth.light()
                    g_boundary_smooth.light()
                    g_use_creases.light()
                    g_use_custom_normals.light()

                if modifier.use_limit_surface:
                    if g_quality.is_dark() is True: g_quality.light()
                else:
                    if g_quality.is_dark() is False: g_quality.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_SURFACE(self):

        b0 = Blocks(self)
        b0.buttons = [Title("  Settings are inside the Physics tab")]
        self.items[:] = [b0]
        #|
    def init_tab_SURFACE_DEFORM(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_target = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["target"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("target"))
        g_falloff = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["falloff"], pp), *rr_fcdr("falloff"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_use_sparse_bind = ButtonGroupAnimRef(b0, ButtonBoolPush(None, rnas["use_sparse_bind"], pp), rr_refdriver("use_sparse_bind"))
        g_bind = ButtonGroupAnimFn(b0, ButtonFnPush(None, RNA_SURFACE_DEFORM_bind, self.bufn_SURFACE_DEFORM_bind), title="")
        b0.buttons = [
            g_target,
            g_falloff,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            g_use_sparse_bind,
            ButtonSep(3),
            g_bind
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.is_bound:
                if g_bind.is_dark() is True: g_bind.light()

                if g_use_sparse_bind.is_dark() is False: g_use_sparse_bind.dark()

                if g_target.is_dark() is False:
                    g_target.dark()
                    g_falloff.dark()
                    g_bind.button0.set_button_text("Unbind")
            else:
                if modifier.target:
                    if g_bind.is_dark() is True: g_bind.light()
                else:
                    if g_bind.is_dark() is False: g_bind.dark()

                if modifier.vertex_group:
                    if g_use_sparse_bind.is_dark() is True: g_use_sparse_bind.light()
                else:
                    if g_use_sparse_bind.is_dark() is False: g_use_sparse_bind.dark()

                if g_target.is_dark() is True:
                    g_target.light()
                    g_falloff.light()
                    g_bind.button0.set_button_text("Bind")

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_TRIANGULATE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["quad_method"], pp), *rr_fcdr("quad_method")),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["ngon_method"], pp, row_length=2), *rr_fcdr("ngon_method")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["min_vertices"], pp), *rr_fcdr("min_vertices")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["keep_custom_normals"], pp), *rr_fcdr("keep_custom_normals"))  if "keep_custom_normals" in rnas else ButtonSep(0),
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_UV_PROJECT(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_aspect_x = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["aspect_x"], pp), *rr_fcdr("aspect_x"))
        g_aspect_y = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["aspect_y"], pp), *rr_fcdr("aspect_y"))
        g_scale_x = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["scale_x"], pp), *rr_fcdr("scale_x"))
        g_scale_y = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["scale_y"], pp), *rr_fcdr("scale_y"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumUVPush(None, rnas["uv_layer"], pp), rr_refdriver("uv_layer")),
            g_aspect_x,
            g_aspect_y,
            g_scale_x,
            g_scale_y,
        ]

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonIntPush(None, rnas["projector_count"], pp), *rr_fcdr("projector_count"), title="Projectors")
        )
        b1_items = []
        b1.items = b1_items

        self.items[:] = [b0, b1]

        def rr_projector(r):
            def r_projector():
                projectors = self.w.active_modifier.projectors
                if r < len(projectors): return projectors[r]
                return None
            return r_projector
        def rr_datapath_head(r):
            def r_datapath_head(full=False):
                if full:
                    return f'{r_ID_dp(self.w.active_object)}.modifiers["{escape_identifier(self.w.active_modifier_name)}"].projectors[{r}].'
                return f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].projectors[{r}].'
            return r_datapath_head

        def upd_data_callback():
            modifier = self.w.active_modifier
            projectors = modifier.projectors

            if any([e.object and e.object.type == 'CAMERA' for e in projectors]):
                if g_aspect_x.is_dark() is True:
                    g_aspect_x.light()
                    g_aspect_y.light()
                    g_scale_x.light()
                    g_scale_y.light()
            else:
                if g_aspect_x.is_dark() is False:
                    g_aspect_x.dark()
                    g_aspect_y.dark()
                    g_scale_x.dark()
                    g_scale_y.dark()

            if len(b1_items) != len(projectors):
                b1_items.clear()
                b1_items[:] = [
                    ButtonGroupAnimRef(b1, ButtonEnumObjectPush(None, UVProjector_bl_rnas["object"],
                        (
                            rr_projector(r),
                            self.r_object,
                            rr_datapath_head(r)
                        ),
                        r_except_objects=self.r_object_set), lambda: None)  for r in range(len(projectors))]
                self.redraw_from_headkey()
                self.upd_data()
                return

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_UV_WARP(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_bone_from = ButtonGroupAnimRef(b0, ButtonEnumBonePush(None, rnas["bone_from"], pp, lambda: self.r_modifier().object_from), rr_refdriver("bone_from"))
        g_bone_to = ButtonGroupAnimRef(b0, ButtonEnumBonePush(None, rnas["bone_to"], pp, lambda: self.r_modifier().object_to), rr_refdriver("bone_to"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumUVPush(None, rnas["uv_layer"], pp), rr_refdriver("uv_layer")),
            ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["center"], pp), *rr_fcdr_array("center", RANGE_2)),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["axis_u"], pp, row_length=3), *rr_fcdr("axis_u"), title="Axis U"),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["axis_v"], pp, row_length=3), *rr_fcdr("axis_v"), title="V"),
            ButtonSep(2),
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object_from"], pp, r_except_objects=self.r_object_set), rr_refdriver("object_from")),
            g_bone_from,
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object_to"], pp, r_except_objects=self.r_object_set), rr_refdriver("object_to")),
            g_bone_to,
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
        ]

        b1 = BlockUtil(self, None, Title("Transform"))
        b1.items = [
            ButtonGroupAnimVector(b1, ButtonFloatVectorPush(None, rnas["offset"], pp), *rr_fcdr_array("offset", RANGE_2)),
            ButtonGroupAnimVector(b1, ButtonFloatVectorPush(None, rnas["scale"], pp), *rr_fcdr_array("scale", RANGE_2)),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["rotation"], pp), *rr_fcdr("rotation")),
        ]

        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.object_from:
                if modifier.object_from.type == "ARMATURE":
                    if g_bone_from.is_dark() is True: g_bone_from.light()
                else:
                    if g_bone_from.is_dark() is False: g_bone_from.dark()
            else:
                if g_bone_from.is_dark() is False: g_bone_from.dark()
                

            if modifier.object_to:
                if modifier.object_to.type == "ARMATURE":
                    if g_bone_to.is_dark() is True: g_bone_to.light()
                else:
                    if g_bone_to.is_dark() is False: g_bone_to.dark()
            else:
                if g_bone_to.is_dark() is False: g_bone_to.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_VERTEX_WEIGHT_EDIT(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_use_add = ButtonGroupAnimBoolAlignR(b0, ButtonBoolPush(None, rnas["use_add"], pp), *rr_fcdr("use_add"))
        g_add_threshold = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["add_threshold"], pp), *rr_fcdr("add_threshold"), title="")
        g_add_threshold_box_button = g_add_threshold.button0.box_button
        g_use_remove = ButtonGroupAnimBoolAlignR(b0, ButtonBoolPush(None, rnas["use_remove"], pp), *rr_fcdr("use_remove"))
        g_remove_threshold = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["remove_threshold"], pp), *rr_fcdr("remove_threshold"), title="")
        g_remove_threshold_box_button = g_remove_threshold.button0.box_button
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["default_weight"], pp), *rr_fcdr("default_weight")),
            ButtonSplitBool(b0, g_use_add, g_add_threshold, lambda: g_add_threshold_box_button.L, gap=lambda: SIZE_widget[0] // 4),
            ButtonSplitBool(b0, g_use_remove, g_remove_threshold, lambda: g_remove_threshold_box_button.L, gap=lambda: SIZE_widget[0] // 4),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["normalize"], pp), *rr_fcdr("normalize")),
        ]

        b1 = BlockUtil(self, None, Title("Falloff"))
        g_falloff_type = ButtonGroupAnim(b1, ButtonEnumFalloffPush(None, rnas["falloff_type"], pp), *rr_fcdr("falloff_type"), title="Type")
        g_edit_curve = ButtonFnPush(b1, RNA_edit_curve, self.bufn_VERTEX_WEIGHT_EDIT_edit_curve)
        b1.items = [
            ButtonSplit(b1, g_edit_curve, g_falloff_type, gap=r_button_h, factor=0.35),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["invert_falloff"], pp), *rr_fcdr("invert_falloff")),
        ]

        b2 = BlockUtil(self, None, Title("Influence"))
        g_mask_vertex_group = ButtonGroupAnimRef(b2, ButtonEnumVertexGroupPush(None, rnas["mask_vertex_group"], pp), rr_refdriver("mask_vertex_group"))
        g_invert_mask_vertex_group = ButtonGroupAnimAlignTitleLeft(b2, ButtonBoolPush(None, rnas["invert_mask_vertex_group"], pp), *rr_fcdr("invert_mask_vertex_group"))
        g_mask_texture = ButtonGroupAnimRef(b2, ButtonEnumTexturePush(None, rnas["mask_texture"], pp), rr_refdriver("mask_texture"), title="Mask Texture")
        g_mask_tex_use_channel = ButtonGroupAnim(b2, ButtonEnumPush(None, rnas["mask_tex_use_channel"], pp), *rr_fcdr("mask_tex_use_channel"), title="Channel")
        g_mask_tex_mapping = ButtonGroupAnim(b2, ButtonEnumXYPush(None, rnas["mask_tex_mapping"], pp, row_length=4), *rr_fcdr("mask_tex_mapping"), title="Texture Coords")
        g_mask_tex_map_object = ButtonGroupAnimRef(b2, ButtonEnumObjectPush(None, rnas["mask_tex_map_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("mask_tex_map_object"), title="Object")
        g_mask_tex_uv_layer = ButtonGroupAnimRef(b2, ButtonEnumUVPush(None, rnas["mask_tex_uv_layer"], pp), rr_refdriver("mask_tex_uv_layer"))
        g_mask_tex_map_bone = ButtonGroupAnimRef(b2, ButtonEnumBonePush(None, rnas["mask_tex_map_bone"], pp, lambda: self.w.active_modifier.mask_tex_map_object), rr_refdriver("mask_tex_map_bone"), title="Bone")
        b2.items = [
            ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["mask_constant"], pp), *rr_fcdr("mask_constant"), title="Global Influence"),
            g_mask_vertex_group,
            g_invert_mask_vertex_group,
            ButtonSep(3),
            g_mask_texture,
            g_mask_tex_use_channel,
            ButtonSep(),
            g_mask_tex_mapping,
            ButtonSep(),
            g_mask_tex_map_object,
            g_mask_tex_map_bone,
            g_mask_tex_uv_layer,
        ]
        def r_button_width(): return round(D_SIZE['widget_width'] * 1.6)
        g_mask_texture.r_button_width = r_button_width
        g_mask_tex_use_channel.r_button_width = r_button_width
        g_mask_tex_mapping.r_button_width = r_button_width
        g_mask_tex_map_object.r_button_width = r_button_width
        g_mask_tex_map_bone.r_button_width = r_button_width
        g_mask_tex_uv_layer.r_button_width = r_button_width

        self.items[:] = [b0, b1, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier
            texture = modifier.mask_texture

            if modifier.use_add:
                if g_add_threshold.is_dark() is True: g_add_threshold.light()
            else:
                if g_add_threshold.is_dark() is False: g_add_threshold.dark()

            if modifier.use_remove:
                if g_remove_threshold.is_dark() is True: g_remove_threshold.light()
            else:
                if g_remove_threshold.is_dark() is False: g_remove_threshold.dark()

            if modifier.falloff_type == "CURVE":
                if g_edit_curve.is_dark() is True: g_edit_curve.light()
            else:
                if g_edit_curve.is_dark() is False: g_edit_curve.dark()

            if modifier.mask_vertex_group:
                if texture:
                    if g_mask_vertex_group.is_dark() is False: g_mask_vertex_group.dark()
                    if g_invert_mask_vertex_group.is_dark() is False: g_invert_mask_vertex_group.dark()
                    if g_mask_texture.is_dark() is False: g_mask_texture.dark()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                else:
                    if g_mask_vertex_group.is_dark() is True: g_mask_vertex_group.light()
                    if g_invert_mask_vertex_group.is_dark() is True: g_invert_mask_vertex_group.light()
                    if g_mask_texture.is_dark() is False: g_mask_texture.dark()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
            else:
                if g_invert_mask_vertex_group.is_dark() is False: g_invert_mask_vertex_group.dark()
                if g_mask_texture.is_dark() is True: g_mask_texture.light()
                if texture:
                    if g_mask_vertex_group.is_dark() is False: g_mask_vertex_group.dark()
                    if g_mask_tex_use_channel.is_dark() is True: g_mask_tex_use_channel.light()
                    if g_mask_tex_mapping.is_dark() is True: g_mask_tex_mapping.light()
                    if modifier.mask_tex_mapping == "OBJECT":
                        if g_mask_tex_map_object.is_dark() is True: g_mask_tex_map_object.light()
                        if modifier.mask_tex_map_object and modifier.mask_tex_map_object.type == "ARMATURE":
                            if g_mask_tex_map_bone.is_dark() is True: g_mask_tex_map_bone.light()
                        else:
                            if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                    elif modifier.mask_tex_mapping == "UV":
                        if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                        if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is True: g_mask_tex_uv_layer.light()
                    else:
                        if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                        if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                else:
                    if g_mask_vertex_group.is_dark() is True: g_mask_vertex_group.light()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_VERTEX_WEIGHT_MIX(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group_a = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group_a"], pp), *rr_fcdr("invert_vertex_group_a"), title="Invert")
        g_invert_vertex_group_b = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group_b"], pp), *rr_fcdr("invert_vertex_group_b"), title="Invert")
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group_a"], pp), rr_refdriver("vertex_group_a")),
            g_invert_vertex_group_a,
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group_b"], pp), rr_refdriver("vertex_group_b")),
            g_invert_vertex_group_b,
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["default_weight_a"], pp), *rr_fcdr("default_weight_a")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["default_weight_b"], pp), *rr_fcdr("default_weight_b"), title="B"),
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mix_set"], pp), *rr_fcdr("mix_set")),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mix_mode"], pp), *rr_fcdr("mix_mode")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["normalize"], pp), *rr_fcdr("normalize")),
        ]

        b2 = BlockUtil(self, None, Title("Influence"))
        g_mask_vertex_group = ButtonGroupAnimRef(b2, ButtonEnumVertexGroupPush(None, rnas["mask_vertex_group"], pp), rr_refdriver("mask_vertex_group"))
        g_invert_mask_vertex_group = ButtonGroupAnimAlignTitleLeft(b2, ButtonBoolPush(None, rnas["invert_mask_vertex_group"], pp), *rr_fcdr("invert_mask_vertex_group"))
        g_mask_texture = ButtonGroupAnimRef(b2, ButtonEnumTexturePush(None, rnas["mask_texture"], pp), rr_refdriver("mask_texture"), title="Mask Texture")
        g_mask_tex_use_channel = ButtonGroupAnim(b2, ButtonEnumPush(None, rnas["mask_tex_use_channel"], pp), *rr_fcdr("mask_tex_use_channel"), title="Channel")
        g_mask_tex_mapping = ButtonGroupAnim(b2, ButtonEnumXYPush(None, rnas["mask_tex_mapping"], pp, row_length=4), *rr_fcdr("mask_tex_mapping"), title="Texture Coords")
        g_mask_tex_map_object = ButtonGroupAnimRef(b2, ButtonEnumObjectPush(None, rnas["mask_tex_map_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("mask_tex_map_object"), title="Object")
        g_mask_tex_uv_layer = ButtonGroupAnimRef(b2, ButtonEnumUVPush(None, rnas["mask_tex_uv_layer"], pp), rr_refdriver("mask_tex_uv_layer"))
        g_mask_tex_map_bone = ButtonGroupAnimRef(b2, ButtonEnumBonePush(None, rnas["mask_tex_map_bone"], pp, lambda: self.w.active_modifier.mask_tex_map_object), rr_refdriver("mask_tex_map_bone"), title="Bone")
        b2.items = [
            ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["mask_constant"], pp), *rr_fcdr("mask_constant"), title="Global Influence"),
            g_mask_vertex_group,
            g_invert_mask_vertex_group,
            ButtonSep(3),
            g_mask_texture,
            g_mask_tex_use_channel,
            ButtonSep(),
            g_mask_tex_mapping,
            ButtonSep(),
            g_mask_tex_map_object,
            g_mask_tex_map_bone,
            g_mask_tex_uv_layer,
        ]
        def r_button_width(): return round(D_SIZE['widget_width'] * 1.6)
        g_mask_texture.r_button_width = r_button_width
        g_mask_tex_use_channel.r_button_width = r_button_width
        g_mask_tex_mapping.r_button_width = r_button_width
        g_mask_tex_map_object.r_button_width = r_button_width
        g_mask_tex_map_bone.r_button_width = r_button_width
        g_mask_tex_uv_layer.r_button_width = r_button_width

        self.items[:] = [b0, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier
            texture = modifier.mask_texture

            if modifier.vertex_group_a:
                if g_invert_vertex_group_a.is_dark() is True: g_invert_vertex_group_a.light()
            else:
                if g_invert_vertex_group_a.is_dark() is False: g_invert_vertex_group_a.dark()

            if modifier.vertex_group_b:
                if g_invert_vertex_group_b.is_dark() is True: g_invert_vertex_group_b.light()
            else:
                if g_invert_vertex_group_b.is_dark() is False: g_invert_vertex_group_b.dark()

            if modifier.mask_vertex_group:
                if texture:
                    if g_mask_vertex_group.is_dark() is False: g_mask_vertex_group.dark()
                    if g_invert_mask_vertex_group.is_dark() is False: g_invert_mask_vertex_group.dark()
                    if g_mask_texture.is_dark() is False: g_mask_texture.dark()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                else:
                    if g_mask_vertex_group.is_dark() is True: g_mask_vertex_group.light()
                    if g_invert_mask_vertex_group.is_dark() is True: g_invert_mask_vertex_group.light()
                    if g_mask_texture.is_dark() is False: g_mask_texture.dark()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
            else:
                if g_invert_mask_vertex_group.is_dark() is False: g_invert_mask_vertex_group.dark()
                if g_mask_texture.is_dark() is True: g_mask_texture.light()
                if texture:
                    if g_mask_vertex_group.is_dark() is False: g_mask_vertex_group.dark()
                    if g_mask_tex_use_channel.is_dark() is True: g_mask_tex_use_channel.light()
                    if g_mask_tex_mapping.is_dark() is True: g_mask_tex_mapping.light()
                    if modifier.mask_tex_mapping == "OBJECT":
                        if g_mask_tex_map_object.is_dark() is True: g_mask_tex_map_object.light()
                        if modifier.mask_tex_map_object and modifier.mask_tex_map_object.type == "ARMATURE":
                            if g_mask_tex_map_bone.is_dark() is True: g_mask_tex_map_bone.light()
                        else:
                            if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                    elif modifier.mask_tex_mapping == "UV":
                        if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                        if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is True: g_mask_tex_uv_layer.light()
                    else:
                        if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                        if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                else:
                    if g_mask_vertex_group.is_dark() is True: g_mask_vertex_group.light()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_VERTEX_WEIGHT_PROXIMITY(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_target = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["target"], pp, r_except_objects=self.r_object_set), rr_refdriver("target"))
        g_proximity_mode = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["proximity_mode"], pp, row_length=2), *rr_fcdr("proximity_mode"))
        g_proximity_geometry = ButtonGroupAnim(b0, ButtonEnumXYFlagPush(None, rnas["proximity_geometry"], pp, row_length=3), *rr_fcdr("proximity_geometry"), title="Geometry")
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_target,
            ButtonSep(3),
            g_proximity_mode,
            g_proximity_geometry,
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["min_dist"], pp), *rr_fcdr("min_dist")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["max_dist"], pp), *rr_fcdr("max_dist")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["normalize"], pp), *rr_fcdr("normalize")),
        ]
        g_proximity_mode.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.5)
        g_proximity_geometry.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.5)

        b1 = BlockUtil(self, None, Title("Falloff"))
        g_falloff_type = ButtonGroupAnim(b1, ButtonEnumFalloffPush(None, rnas["falloff_type"], pp), *rr_fcdr("falloff_type"), title="Type")
        g_edit_curve = ButtonFnPush(b1, RNA_edit_curve, self.bufn_VERTEX_WEIGHT_EDIT_edit_curve)
        b1.items = [
            ButtonSplit(b1, g_edit_curve, g_falloff_type, gap=r_button_h, factor=0.35),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["invert_falloff"], pp), *rr_fcdr("invert_falloff")),
        ]

        b2 = BlockUtil(self, None, Title("Influence"))
        g_mask_vertex_group = ButtonGroupAnimRef(b2, ButtonEnumVertexGroupPush(None, rnas["mask_vertex_group"], pp), rr_refdriver("mask_vertex_group"))
        g_invert_mask_vertex_group = ButtonGroupAnimAlignTitleLeft(b2, ButtonBoolPush(None, rnas["invert_mask_vertex_group"], pp), *rr_fcdr("invert_mask_vertex_group"))
        g_mask_texture = ButtonGroupAnimRef(b2, ButtonEnumTexturePush(None, rnas["mask_texture"], pp), rr_refdriver("mask_texture"), title="Mask Texture")
        g_mask_tex_use_channel = ButtonGroupAnim(b2, ButtonEnumPush(None, rnas["mask_tex_use_channel"], pp), *rr_fcdr("mask_tex_use_channel"), title="Channel")
        g_mask_tex_mapping = ButtonGroupAnim(b2, ButtonEnumXYPush(None, rnas["mask_tex_mapping"], pp, row_length=4), *rr_fcdr("mask_tex_mapping"), title="Texture Coords")
        g_mask_tex_map_object = ButtonGroupAnimRef(b2, ButtonEnumObjectPush(None, rnas["mask_tex_map_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("mask_tex_map_object"), title="Object")
        g_mask_tex_uv_layer = ButtonGroupAnimRef(b2, ButtonEnumUVPush(None, rnas["mask_tex_uv_layer"], pp), rr_refdriver("mask_tex_uv_layer"))
        g_mask_tex_map_bone = ButtonGroupAnimRef(b2, ButtonEnumBonePush(None, rnas["mask_tex_map_bone"], pp, lambda: self.w.active_modifier.mask_tex_map_object), rr_refdriver("mask_tex_map_bone"), title="Bone")
        b2.items = [
            ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["mask_constant"], pp), *rr_fcdr("mask_constant"), title="Global Influence"),
            g_mask_vertex_group,
            g_invert_mask_vertex_group,
            ButtonSep(3),
            g_mask_texture,
            g_mask_tex_use_channel,
            ButtonSep(),
            g_mask_tex_mapping,
            ButtonSep(),
            g_mask_tex_map_object,
            g_mask_tex_map_bone,
            g_mask_tex_uv_layer,
        ]
        def r_button_width(): return round(D_SIZE['widget_width'] * 1.6)
        g_mask_texture.r_button_width = r_button_width
        g_mask_tex_use_channel.r_button_width = r_button_width
        g_mask_tex_mapping.r_button_width = r_button_width
        g_mask_tex_map_object.r_button_width = r_button_width
        g_mask_tex_map_bone.r_button_width = r_button_width
        g_mask_tex_uv_layer.r_button_width = r_button_width

        self.items[:] = [b0, b1, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier
            texture = modifier.mask_texture

            if modifier.proximity_mode == "GEOMETRY":
                if g_proximity_geometry.is_dark() is True: g_proximity_geometry.light()
            else:
                if g_proximity_geometry.is_dark() is False: g_proximity_geometry.dark()

            if modifier.falloff_type == "CURVE":
                if g_edit_curve.is_dark() is True: g_edit_curve.light()
            else:
                if g_edit_curve.is_dark() is False: g_edit_curve.dark()

            if modifier.mask_vertex_group:
                if texture:
                    if g_mask_vertex_group.is_dark() is False: g_mask_vertex_group.dark()
                    if g_invert_mask_vertex_group.is_dark() is False: g_invert_mask_vertex_group.dark()
                    if g_mask_texture.is_dark() is False: g_mask_texture.dark()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                else:
                    if g_mask_vertex_group.is_dark() is True: g_mask_vertex_group.light()
                    if g_invert_mask_vertex_group.is_dark() is True: g_invert_mask_vertex_group.light()
                    if g_mask_texture.is_dark() is False: g_mask_texture.dark()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
            else:
                if g_invert_mask_vertex_group.is_dark() is False: g_invert_mask_vertex_group.dark()
                if g_mask_texture.is_dark() is True: g_mask_texture.light()
                if texture:
                    if g_mask_vertex_group.is_dark() is False: g_mask_vertex_group.dark()
                    if g_mask_tex_use_channel.is_dark() is True: g_mask_tex_use_channel.light()
                    if g_mask_tex_mapping.is_dark() is True: g_mask_tex_mapping.light()
                    if modifier.mask_tex_mapping == "OBJECT":
                        if g_mask_tex_map_object.is_dark() is True: g_mask_tex_map_object.light()
                        if modifier.mask_tex_map_object and modifier.mask_tex_map_object.type == "ARMATURE":
                            if g_mask_tex_map_bone.is_dark() is True: g_mask_tex_map_bone.light()
                        else:
                            if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                    elif modifier.mask_tex_mapping == "UV":
                        if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                        if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is True: g_mask_tex_uv_layer.light()
                    else:
                        if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                        if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                        if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()
                else:
                    if g_mask_vertex_group.is_dark() is True: g_mask_vertex_group.light()
                    if g_mask_tex_use_channel.is_dark() is False: g_mask_tex_use_channel.dark()
                    if g_mask_tex_mapping.is_dark() is False: g_mask_tex_mapping.dark()
                    if g_mask_tex_map_object.is_dark() is False: g_mask_tex_map_object.dark()
                    if g_mask_tex_map_bone.is_dark() is False: g_mask_tex_map_bone.dark()
                    if g_mask_tex_uv_layer.is_dark() is False: g_mask_tex_uv_layer.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_VOLUME_TO_MESH(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_voxel_amount = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["voxel_amount"], pp), *rr_fcdr("voxel_amount"))
        g_voxel_size = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["voxel_size"], pp), *rr_fcdr("voxel_size"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object")),
            ButtonGroupAnimRef(b0, ButtonStringPush(None, rnas["grid_name"], pp), rr_refdriver("grid_name")),
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["resolution_mode"], pp), *rr_fcdr("resolution_mode")),
            g_voxel_amount,
            g_voxel_size,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["threshold"], pp), *rr_fcdr("threshold")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["adaptivity"], pp), *rr_fcdr("adaptivity")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_smooth_shade"], pp), *rr_fcdr("use_smooth_shade")),
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.resolution_mode == "VOXEL_AMOUNT":
                if g_voxel_amount.is_dark() is True: g_voxel_amount.light()
                if g_voxel_size.is_dark() is False: g_voxel_size.dark()
            elif modifier.resolution_mode == "VOXEL_SIZE":
                if g_voxel_amount.is_dark() is False: g_voxel_amount.dark()
                if g_voxel_size.is_dark() is True: g_voxel_size.light()
            else:
                if g_voxel_amount.is_dark() is False: g_voxel_amount.dark()
                if g_voxel_size.is_dark() is False: g_voxel_size.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_WARP(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_bone_from = ButtonGroupAnimRef(b0, ButtonEnumBonePush(None, rnas["bone_from"], pp, lambda: self.r_modifier().object_from), rr_refdriver("bone_from"))
        g_bone_to = ButtonGroupAnimRef(b0, ButtonEnumBonePush(None, rnas["bone_to"], pp, lambda: self.r_modifier().object_to), rr_refdriver("bone_to"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object_from"], pp, r_except_objects=self.r_object_set), rr_refdriver("object_from")),
            g_bone_from,
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object_to"], pp, r_except_objects=self.r_object_set), rr_refdriver("object_to")),
            g_bone_to,
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_volume_preserve"], pp), *rr_fcdr("use_volume_preserve")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength")),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
        ]

        b1 = BlockUtil(self, None, Title("Falloff"))
        g_falloff_type = ButtonGroupAnim(b1, ButtonEnumFalloffPush(None, rnas["falloff_type"], pp), *rr_fcdr("falloff_type"), title="Type")
        g_edit_curve = ButtonFnPush(b1, RNA_edit_curve, self.bufn_HOOK_edit_curve)
        g_falloff_radius = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["falloff_radius"], pp), *rr_fcdr("falloff_radius"))
        b1.items = [
            ButtonSplit(b1, g_edit_curve, g_falloff_type, gap=r_button_h, factor=0.35),
            g_falloff_radius,
        ]

        b2 = BlockUtil(self, None, Title("Texture"))
        g_texture = ButtonGroupAnimRef(b2, ButtonEnumTexturePush(None, rnas["texture"], pp), rr_refdriver("texture"), title="")
        g_texture_coords = ButtonGroupAnim(b2, ButtonEnumXYPush(None, rnas["texture_coords"], pp, row_length=4), *rr_fcdr("texture_coords"), title="Coordinates")
        g_texture_coords_object = ButtonGroupAnimRef(b2, ButtonEnumObjectPush(None, rnas["texture_coords_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("texture_coords_object"), title="Object")
        g_texture_coords_bone = ButtonGroupAnimRef(b2, ButtonEnumBonePush(None, rnas["texture_coords_bone"], pp, lambda: self.w.active_modifier.texture_coords_object), rr_refdriver("texture_coords_bone"), title="Bone")
        g_uv_layer = ButtonGroupAnimRef(b2, ButtonEnumUVPush(None, rnas["uv_layer"], pp), rr_refdriver("uv_layer"))
        b2.items = [
            g_texture,
            ButtonSep(),
            g_texture_coords,
            ButtonSep(),
            g_texture_coords_object,
            g_texture_coords_bone,
            g_uv_layer
        ]
        def r_button_width(): return round(D_SIZE['widget_width'] * 1.7)
        g_texture.r_button_width = r_button_width
        g_texture_coords.r_button_width = r_button_width
        g_texture_coords_object.r_button_width = r_button_width
        g_texture_coords_bone.r_button_width = r_button_width
        g_uv_layer.r_button_width = r_button_width

        self.items[:] = [b0, b1, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.object_from:
                if modifier.object_from.type == "ARMATURE":
                    if g_bone_from.is_dark() is True: g_bone_from.light()
                else:
                    if g_bone_from.is_dark() is False: g_bone_from.dark()
            else:
                if g_bone_from.is_dark() is False: g_bone_from.dark()

            if modifier.object_to:
                if modifier.object_to.type == "ARMATURE":
                    if g_bone_to.is_dark() is True: g_bone_to.light()
                else:
                    if g_bone_to.is_dark() is False: g_bone_to.dark()
            else:
                if g_bone_to.is_dark() is False: g_bone_to.dark()

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.falloff_type == "CURVE":
                if g_edit_curve.is_dark() is True: g_edit_curve.light()
                if g_falloff_radius.is_dark() is True: g_falloff_radius.light()
            else:
                if g_edit_curve.is_dark() is False: g_edit_curve.dark()
                if modifier.falloff_type == "NONE":
                    if g_falloff_radius.is_dark() is False: g_falloff_radius.dark()
                else:
                    if g_falloff_radius.is_dark() is True: g_falloff_radius.light()

            if modifier.texture_coords == "OBJECT":
                if g_texture_coords_object.is_dark() is True: g_texture_coords_object.light()
                if modifier.texture_coords_object and modifier.texture_coords_object.type == "ARMATURE":
                    if g_texture_coords_bone.is_dark() is True: g_texture_coords_bone.light()
                else:
                    if g_texture_coords_bone.is_dark() is False: g_texture_coords_bone.dark()
                if g_uv_layer.is_dark() is False: g_uv_layer.dark()
            else:
                if g_texture_coords_object.is_dark() is False: g_texture_coords_object.dark()
                if g_texture_coords_bone.is_dark() is False: g_texture_coords_bone.dark()
                if modifier.texture_coords == "UV":
                    if g_uv_layer.is_dark() is True: g_uv_layer.light()
                else:
                    if g_uv_layer.is_dark() is False: g_uv_layer.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_WAVE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_fcurve_use():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_x'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_y')
                ]
            return [None] * 2
        def r_driver_use():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_x'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_y')
                ]
            return [None] * 2
        def r_fcurve_use_normal():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_normal_x'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_normal_y'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_normal_z')
                ]
            return [None] * 3
        def r_driver_use_normal():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_normal_x'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_normal_y'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_normal_z')
                ]
            return [None] * 3

        b0 = Blocks(self)
        g_use_normal = ButtonGroupAnimBoolAlignR(b0, ButtonBoolPush(None, rnas["use_normal"], pp), *rr_fcdr("use_normal"), title="Along Normals")
        gs_use_normal = ButtonGroupAnimBoolArray(b0, [rnas["use_normal_x"], rnas["use_normal_y"], rnas["use_normal_z"]], pp, r_fcurve_use_normal, r_driver_use_normal, title="", button_text=TUP_XYZ)
        gs_use_normal_box_button = gs_use_normal.buttons[-1].box_button[0]
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnimBoolArray(b0, [rnas["use_x"], rnas["use_y"]], pp, r_fcurve_use, r_driver_use, title="Motion"),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_cyclic"], pp), *rr_fcdr("use_cyclic")),
            ButtonSep(3),
            ButtonSplitBool(b0, g_use_normal, gs_use_normal, lambda: gs_use_normal_box_button.L, gap=lambda: SIZE_widget[0] // 4),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["falloff_radius"], pp), *rr_fcdr("falloff_radius")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["height"], pp), *rr_fcdr("height")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["width"], pp), *rr_fcdr("width")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["narrowness"], pp), *rr_fcdr("narrowness")),
            ButtonSep(3),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group
        ]

        b1 = BlockUtil(self, None, Title("Start Position"))
        b1.items = [
            ButtonGroupAnimRef(b1, ButtonEnumObjectPush(None, rnas["start_position_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("start_position_object")),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["start_position_x"], pp), *rr_fcdr("start_position_x")),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["start_position_y"], pp), *rr_fcdr("start_position_y")),
        ]

        b3 = BlockUtil(self, None, Title("Time"))
        b3.items = [
            ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["time_offset"], pp), *rr_fcdr("time_offset")),
            ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["lifetime"], pp), *rr_fcdr("lifetime")),
            ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["damping_time"], pp), *rr_fcdr("damping_time")),
            ButtonGroupAnim(b3, ButtonFloatPush(None, rnas["speed"], pp), *rr_fcdr("speed")),
        ]

        b2 = BlockUtil(self, None, Title("Texture"))
        g_texture = ButtonGroupAnimRef(b2, ButtonEnumTexturePush(None, rnas["texture"], pp), rr_refdriver("texture"), title="")
        g_texture_coords = ButtonGroupAnim(b2, ButtonEnumXYPush(None, rnas["texture_coords"], pp, row_length=4), *rr_fcdr("texture_coords"), title="Coordinates")
        g_texture_coords_object = ButtonGroupAnimRef(b2, ButtonEnumObjectPush(None, rnas["texture_coords_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("texture_coords_object"), title="Object")
        g_texture_coords_bone = ButtonGroupAnimRef(b2, ButtonEnumBonePush(None, rnas["texture_coords_bone"], pp, lambda: self.w.active_modifier.texture_coords_object), rr_refdriver("texture_coords_bone"), title="Bone")
        g_uv_layer = ButtonGroupAnimRef(b2, ButtonEnumUVPush(None, rnas["uv_layer"], pp), rr_refdriver("uv_layer"))
        b2.items = [
            g_texture,
            ButtonSep(),
            g_texture_coords,
            ButtonSep(),
            g_texture_coords_object,
            g_texture_coords_bone,
            g_uv_layer
        ]
        def r_button_width(): return round(D_SIZE['widget_width'] * 1.7)
        g_texture.r_button_width = r_button_width
        g_texture_coords.r_button_width = r_button_width
        g_texture_coords_object.r_button_width = r_button_width
        g_texture_coords_bone.r_button_width = r_button_width
        g_uv_layer.r_button_width = r_button_width

        self.items[:] = [b0, b1, b3, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_normal:
                if gs_use_normal.is_dark() is True: gs_use_normal.light()
            else:
                if gs_use_normal.is_dark() is False: gs_use_normal.dark()

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.texture_coords == "OBJECT":
                if g_texture_coords_object.is_dark() is True: g_texture_coords_object.light()
                if modifier.texture_coords_object and modifier.texture_coords_object.type == "ARMATURE":
                    if g_texture_coords_bone.is_dark() is True: g_texture_coords_bone.light()
                else:
                    if g_texture_coords_bone.is_dark() is False: g_texture_coords_bone.dark()
                if g_uv_layer.is_dark() is False: g_uv_layer.dark()
            else:
                if g_texture_coords_object.is_dark() is False: g_texture_coords_object.dark()
                if g_texture_coords_bone.is_dark() is False: g_texture_coords_bone.dark()
                if modifier.texture_coords == "UV":
                    if g_uv_layer.is_dark() is True: g_uv_layer.light()
                else:
                    if g_uv_layer.is_dark() is False: g_uv_layer.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_WEIGHTED_NORMAL(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["mode"], pp, row_length=1), *rr_fcdr("mode")),
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["weight"], pp), *rr_fcdr("weight")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["thresh"], pp), *rr_fcdr("thresh")),
            ButtonSep(3),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["keep_sharp"], pp), *rr_fcdr("keep_sharp")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_face_influence"], pp), *rr_fcdr("use_face_influence")),
            ButtonSep(3),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_WELD(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_mode = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["mode"], pp, row_length=2), *rr_fcdr("mode"))
        g_loose_edges = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["loose_edges"], pp), *rr_fcdr("loose_edges"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        b0.buttons = [
            g_mode,
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["merge_threshold"], pp), *rr_fcdr("merge_threshold")),
            g_loose_edges,
            ButtonSep(3),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group
        ]
        g_mode.r_button_width = lambda: round(D_SIZE['widget_width'] * 2.0)

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            if modifier.mode == "CONNECTED":
                if g_loose_edges.is_dark() is True: g_loose_edges.light()
            else:
                if g_loose_edges.is_dark() is False: g_loose_edges.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_WIREFRAME(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_use_crease = ButtonGroupAnimBoolAlignR(b0, ButtonBoolPush(None, rnas["use_crease"], pp), *rr_fcdr("use_crease"), title="Crease Edges")
        g_crease_weight = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["crease_weight"], pp), *rr_fcdr("crease_weight"), title="")
        g_crease_weight_box_button = g_crease_weight.button0.box_button
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["thickness"], pp), *rr_fcdr("thickness")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["offset"], pp), *rr_fcdr("offset")),
            ButtonSep(3),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_boundary"], pp), *rr_fcdr("use_boundary")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_replace"], pp), *rr_fcdr("use_replace")),
            ButtonSep(3),
            ButtonGroupAnimAlignLR(b0, ButtonBoolPush(None, rnas["use_even_offset"], pp), *rr_fcdr("use_even_offset"), title="Even", title_head="Thickness"),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_relative_offset"], pp), *rr_fcdr("use_relative_offset"), title="Relative"),
            ButtonSep(3),
            ButtonSplitBool(b0, g_use_crease, g_crease_weight, lambda: g_crease_weight_box_button.L, gap=lambda: SIZE_widget[0] // 4),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["material_offset"], pp), *rr_fcdr("material_offset")),
        ]

        b1 = BlockUtil(self, None, Title("Vertex Group"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"))
        g_thickness_vertex_group = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["thickness_vertex_group"], pp), *rr_fcdr("thickness_vertex_group"))
        b1.items = [
            ButtonGroupAnimRef(b1, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group")),
            g_invert_vertex_group,
            g_thickness_vertex_group,
        ]

        self.items[:] = [b0, b1]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group:
                if g_invert_vertex_group.is_dark() is True:
                    g_invert_vertex_group.light()
                    g_thickness_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False:
                    g_invert_vertex_group.dark()
                    g_thickness_vertex_group.dark()

            if modifier.use_crease:
                if g_crease_weight.is_dark() is True: g_crease_weight.light()
            else:
                if g_crease_weight.is_dark() is False: g_crease_weight.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|

    def init_tab_MESH_TO_VOLUME(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_voxel_amount = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["voxel_amount"], pp), *rr_fcdr("voxel_amount"))
        g_voxel_size = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["voxel_size"], pp), *rr_fcdr("voxel_size"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["density"], pp), *rr_fcdr("density")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["interior_band_width"], pp), *rr_fcdr("interior_band_width")),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["resolution_mode"], pp, row_length=1), *rr_fcdr("resolution_mode")),
            ButtonSep(2),
            g_voxel_amount,
            g_voxel_size,
        ]
        g_voxel_size.dark()

        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.resolution_mode == "VOXEL_SIZE":
                if g_voxel_size.is_dark() is True:
                    g_voxel_size.light()
                    g_voxel_amount.dark()
            else:
                if g_voxel_amount.is_dark() is True:
                    g_voxel_size.dark()
                    g_voxel_amount.light()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_VOLUME_DISPLACE(self):

        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_button_width(): return round(D_SIZE['widget_width'] * 1.7)

        b0 = Blocks(self)
        g_texture = ButtonGroupAnimRef(b0, ButtonEnumTexturePush(None, rnas["texture"], pp), rr_refdriver("texture"))
        g_texture_map_object = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["texture_map_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("texture_map_object"))
        g_strength = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength"))
        b0.buttons = [
            g_texture,
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["texture_map_mode"], pp, row_length=1), *rr_fcdr("texture_map_mode"), title="Texture Mapping"),
            ButtonSep(2),
            g_texture_map_object,
            g_strength,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["texture_sample_radius"], pp), *rr_fcdr("texture_sample_radius"), title="Sample Radius"),
            ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["texture_mid_level"], pp), *rr_fcdr_array("texture_mid_level", RANGE_3), title="Mid Level"),
        ]
        g_texture.r_button_width = r_button_width

        self.items[:] = [b0]

        def upd_data_callback():
            if self.w.active_modifier.texture_map_mode == "OBJECT":
                if g_texture_map_object.is_dark() is True:
                    g_texture_map_object.light()
            else:
                if g_texture_map_object.is_dark() is False:
                    g_texture_map_object.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|

    def init_tab_GREASE_PENCIL_TEXTURE(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_fit_method = ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["fit_method"], pp), *rr_fcdr("fit_method"))
        g_uv_offset = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["uv_offset"], pp), *rr_fcdr("uv_offset"))
        g_alignment_rotation = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["alignment_rotation"], pp), *rr_fcdr("alignment_rotation"))
        g_uv_scale = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["uv_scale"], pp), *rr_fcdr("uv_scale"))
        g_fill_rotation = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["fill_rotation"], pp), *rr_fcdr("fill_rotation"))
        g_fill_offset = ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["fill_offset"], pp), *rr_fcdr_array("fill_offset", RANGE_2))
        g_fill_scale = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["fill_scale"], pp), *rr_fcdr("fill_scale"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mode"], pp), *rr_fcdr("mode")),
            ButtonSep(2),
            g_fit_method,
            g_uv_offset,
            g_alignment_rotation,
            g_uv_scale,
            ButtonSep(2),
            g_fill_rotation,
            g_fill_offset,
            g_fill_scale,
        ]
        # /* 0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # */
        g_fill_rotation.dark()
        g_fill_offset.dark()
        g_fill_scale.dark()

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.mode == "STROKE":
                if g_fill_rotation.is_dark() is False:
                    g_fill_rotation.dark()
                    g_fill_offset.dark()
                    g_fill_scale.dark()

                if g_fit_method.is_dark() is True:
                    g_fit_method.light()
                    g_uv_offset.light()
                    g_alignment_rotation.light()
                    g_uv_scale.light()
            elif modifier.mode == "FILL":
                if g_fill_rotation.is_dark() is True:
                    g_fill_rotation.light()
                    g_fill_offset.light()
                    g_fill_scale.light()

                if g_fit_method.is_dark() is False:
                    g_fit_method.dark()
                    g_uv_offset.dark()
                    g_alignment_rotation.dark()
                    g_uv_scale.dark()
            else:
                if g_fill_rotation.is_dark() is True:
                    g_fill_rotation.light()
                    g_fill_offset.light()
                    g_fill_scale.light()

                if g_fit_method.is_dark() is True:
                    g_fit_method.light()
                    g_uv_offset.light()
                    g_alignment_rotation.light()
                    g_uv_scale.light()

            # /* 0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # */

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_TIME(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_frame_scale = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["frame_scale"], pp), *rr_fcdr("frame_scale"), title="Scale")
        g_use_keep_loop = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_keep_loop"], pp), *rr_fcdr("use_keep_loop"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mode"], pp), *rr_fcdr("mode")),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["offset"], pp), *rr_fcdr("offset")),
            g_frame_scale,
            g_use_keep_loop,
        ]

        g_use_custom_frame_range = ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_custom_frame_range"], pp), *rr_fcdr("use_custom_frame_range"))
        b1 = BlockUtil(self, None, g_use_custom_frame_range)
        g_frame_start = ButtonGroupAnimRef(b1, ButtonIntPush(None, rnas["frame_start"], pp), rr_refdriver("frame_start"))
        g_frame_end = ButtonGroupAnimRef(b1, ButtonIntPush(None, rnas["frame_end"], pp), rr_refdriver("frame_end"), title="End")
        b1.items = [
            g_frame_start,
            g_frame_end,
        ]

        b2 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b2, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b2, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        b20 = BlockUtil(b2, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b20, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b20, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"))
        b20.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b2.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b20,
        ]

        b3 = BlockUtil(self, None, Title("Segments"))
        # /* 0areas_gp_segment_fns
        def r_segments():
            if hasattr(self.w.active_modifier, "segments"):
                return self.w.active_modifier.segments
            return None
            #|
        def r_segment():
            try:
                modifier = self.w.active_modifier
                return modifier.segments[modifier.segment_active_index]
            except:
                return None
            #|
        def r_active_index():
            modifier = self.w.active_modifier
            if hasattr(modifier, "segment_active_index"):
                ind = modifier.segment_active_index
                if ind is None: return -1
                if 0 <= ind < len(modifier.segments): return ind
            return -1
            #|
        def set_active_index(i, push=True):
            modifier = self.w.active_modifier
            if hasattr(modifier, "segment_active_index"):
                if modifier.segment_active_index != i:
                    modifier.segment_active_index = i
                    if push: update_scene()
            #|
        def r_segment_datapath_head(full=False):
            modifier = self.w.active_modifier
            if hasattr(modifier, "segments"):
                if hasattr(modifier, "segment_active_index"):
                    ind = modifier.segment_active_index
                    if ind is None or ind == -1: return ""
                    if ind >= len(modifier.segments): return ""
                else: return ""
            else: return ""

            if full:
                return f'{r_ID_dp(self.w.active_object)}.modifiers["{escape_identifier(self.w.active_modifier_name)}"].segments["{escape_identifier(modifier.segments[ind].name)}"].'
            return f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].segments["{escape_identifier(modifier.segments[ind].name)}"].'
            #|
        def rr_fcdr_segment(attr):
            def r_fcurve():
                if self.object_fcurves:
                    modifier = self.w.active_modifier
                    if hasattr(modifier, "segment_active_index"):
                        ind = modifier.segment_active_index
                        if ind is None: return None
                        if 0 <= ind < len(modifier.segments):
                            return self.object_fcurves.find(f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].segments["{escape_identifier(modifier.segments[ind].name)}"].{attr}')
                return None
            def r_driver():
                if self.object_drivers:
                    modifier = self.w.active_modifier
                    if hasattr(modifier, "segment_active_index"):
                        ind = modifier.segment_active_index
                        if ind is None: return None
                        if 0 <= ind < len(modifier.segments):
                            return self.object_drivers.find(f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].segments["{escape_identifier(modifier.segments[ind].name)}"].{attr}')
                return None
            return r_fcurve, r_driver
            #|
        # */
        ppp = r_segment, self.r_object, r_segment_datapath_head
        rnas_segment = GreasePencilTimeModifierSegment.bl_rna.properties
        button_media = ButtonListSegmentMedia(b3, r_segments, r_active_index, set_active_index, self.r_object, self.r_modifier)
        g_list_segments = ButtonListSegment(b3, r_segments, lambda e: e.name, r_active_index, set_active_index, button_media)
        gY = ButtonGroupY(b3, None, gap=SIZE_button[1])
        g_segment_mode = ButtonGroupAnim(gY, ButtonEnumPush(None, rnas_segment["segment_mode"], ppp), *rr_fcdr_segment("segment_mode"))
        g_segment_start = ButtonGroupAnim(gY, ButtonIntPush(None, rnas_segment["segment_start"], ppp), *rr_fcdr_segment("segment_start"), title="Start")
        g_segment_end = ButtonGroupAnim(gY, ButtonIntPush(None, rnas_segment["segment_end"], ppp), *rr_fcdr_segment("segment_end"), title="End")
        g_segment_repeat = ButtonGroupAnim(gY, ButtonIntPush(None, rnas_segment["segment_repeat"], ppp), *rr_fcdr_segment("segment_repeat"))
        g_segment_mode.button0.poll = poll_hard_disable
        g_segment_start.button0.poll = poll_hard_disable
        g_segment_end.button0.poll = poll_hard_disable
        g_segment_repeat.button0.poll = poll_hard_disable
        t_frame = Title("    Frame :")
        gY.buttons = [
            g_segment_mode,
            t_frame,
            g_segment_start,
            g_segment_end,
            g_segment_repeat,
        ]
        b3.items = [
            button_media,
            ButtonSplit(b3, gY, g_list_segments, gap=lambda: SIZE_border[3], factor=0.66),
        ]

        self.items[:] = [b0, b1, b2]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.mode == "FIX":
                if g_frame_scale.is_dark() is False:
                    g_frame_scale.dark()
                    g_use_keep_loop.dark()

                if g_use_custom_frame_range.is_dark() is False:
                    g_use_custom_frame_range.dark()

                if g_frame_start.is_dark() is False:
                    g_frame_start.dark()
                    g_frame_end.dark()

                if self.items[-1] == b3:
                    del self.items[-1]
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            elif modifier.mode == "CHAIN":
                if g_frame_scale.is_dark() is True:
                    g_frame_scale.light()
                    g_use_keep_loop.light()

                if g_use_custom_frame_range.is_dark() is False:
                    g_use_custom_frame_range.dark()

                if g_frame_start.is_dark() is False:
                    g_frame_start.dark()
                    g_frame_end.dark()

                if self.items[-1] == b3:
                    if g_list_segments.upd_collection():
                        self.redraw_from_headkey()
                        self.upd_data()
                        return

                    if modifier.segment_active_index is not None and 0 <= modifier.segment_active_index < len(modifier.segments):
                        if g_segment_mode.is_dark() is True:
                            g_segment_mode.light()
                            g_segment_start.light()
                            g_segment_end.light()
                            g_segment_repeat.light()
                            t_frame.light()
                    else:
                        if g_segment_mode.is_dark() is False:
                            g_segment_mode.dark()
                            g_segment_start.dark()
                            g_segment_end.dark()
                            g_segment_repeat.dark()
                            t_frame.dark()
                else:
                    self.items.append(b3)
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            else:
                if g_frame_scale.is_dark() is True:
                    g_frame_scale.light()
                    g_use_keep_loop.light()

                if g_use_custom_frame_range.is_dark() is True:
                    g_use_custom_frame_range.light()

                if modifier.use_custom_frame_range:
                    if g_frame_start.is_dark() is True:
                        g_frame_start.light()
                        g_frame_end.light()
                else:
                    if g_frame_start.is_dark() is False:
                        g_frame_start.dark()
                        g_frame_end.dark()

                if self.items[-1] == b3:
                    del self.items[-1]
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_VERTEX_WEIGHT_PROXIMITY(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_use_invert_output = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_invert_output"], pp), *rr_fcdr("use_invert_output"))
        g_object = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["target_vertex_group"], pp), rr_refdriver("target_vertex_group")),
            g_use_invert_output,
            g_object,
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["distance_start"], pp), *rr_fcdr("distance_start")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["distance_end"], pp), *rr_fcdr("distance_end")),
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["minimum_weight"], pp), *rr_fcdr("minimum_weight")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_multiply"], pp), *rr_fcdr("use_multiply")),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.target_vertex_group:
                if g_use_invert_output.is_dark() is True:
                    g_use_invert_output.light()
            else:
                if g_use_invert_output.is_dark() is False:
                    g_use_invert_output.dark()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_VERTEX_WEIGHT_ANGLE(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_use_invert_output = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_invert_output"], pp), *rr_fcdr("use_invert_output"))
        g_space = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["space"], pp, row_length=2), *rr_fcdr("space"))
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["target_vertex_group"], pp), rr_refdriver("target_vertex_group")),
            g_use_invert_output,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["angle"], pp), *rr_fcdr("angle")),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["axis"], pp, row_length=3), *rr_fcdr("axis")),
            g_space,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["minimum_weight"], pp), *rr_fcdr("minimum_weight")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_multiply"], pp), *rr_fcdr("use_multiply")),
        ]
        g_space.button0.blf_value[0].text = "Local"
        g_space.button0.blf_value[1].text = "World"

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.target_vertex_group:
                if g_use_invert_output.is_dark() is True:
                    g_use_invert_output.light()
            else:
                if g_use_invert_output.is_dark() is False:
                    g_use_invert_output.dark()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_ARRAY(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["count"], pp), *rr_fcdr("count")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["replace_material"], pp), *rr_fcdr("replace_material"), title="Material Override"),
        ]

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_relative_offset"], pp), *rr_fcdr("use_relative_offset"), title="Relative Offset")
        )
        g_relative_offset = ButtonGroupAnimVector(b1, ButtonFloatVectorPush(None, rnas["relative_offset"], pp), *rr_fcdr_array("relative_offset", RANGE_3), title="Factor")
        b1.items = [g_relative_offset]

        b2 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_constant_offset"], pp), *rr_fcdr("use_constant_offset"), title="Constant Offset")
        )
        g_constant_offset = ButtonGroupAnimVector(b2, ButtonFloatVectorPush(None, rnas["constant_offset"], pp), *rr_fcdr_array("constant_offset", RANGE_3), title="Distance")
        b2.items = [g_constant_offset]

        b3 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_object_offset"], pp), *rr_fcdr("use_object_offset"), title="Object Offset")
        )
        g_offset_object = ButtonGroupAnimRef(b3, ButtonEnumObjectPush(None, rnas["offset_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("offset_object"), title="Object")
        b3.items = [g_offset_object]

        b4 = BlockUtil(self, None, Title("Randomize"))
        b4.items = [
            ButtonGroupAnimVector(b4, ButtonFloatVectorPush(None, rnas["random_offset"], pp), *rr_fcdr_array("random_offset", RANGE_3), title="Offset"),
            ButtonGroupAnimVector(b4, ButtonFloatVectorPush(None, rnas["random_rotation"], pp), *rr_fcdr_array("random_rotation", RANGE_3), title="Rotation"),
            ButtonGroupAnimVector(b4, ButtonFloatVectorPush(None, rnas["random_scale"], pp), *rr_fcdr_array("random_scale", RANGE_3), title="Scale"),
            ButtonGroupAnimAlignTitleLeft(b4, ButtonBoolPush(None, rnas["use_uniform_random_scale"], pp), *rr_fcdr("use_uniform_random_scale")),
            ButtonGroupAnim(b4, ButtonIntPush(None, rnas["seed"], pp), *rr_fcdr("seed")),
        ]

        # /* 0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # */

        self.items[:] = [b0, b1, b2, b3, b4, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_relative_offset:
                if g_relative_offset.is_dark() is True:
                    g_relative_offset.light()
            else:
                if g_relative_offset.is_dark() is False:
                    g_relative_offset.dark()

            if modifier.use_constant_offset:
                if g_constant_offset.is_dark() is True:
                    g_constant_offset.light()
            else:
                if g_constant_offset.is_dark() is False:
                    g_constant_offset.dark()

            if modifier.use_object_offset:
                if g_offset_object.is_dark() is True:
                    g_offset_object.light()
            else:
                if g_offset_object.is_dark() is False:
                    g_offset_object.dark()

            # /* 0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # */

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_BUILD(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_transition = ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["transition"], pp), *rr_fcdr("transition"))
        g_concurrent_time_alignment = ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["concurrent_time_alignment"], pp), *rr_fcdr("concurrent_time_alignment"))
        g_length = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["length"], pp), *rr_fcdr("length"), title="Frames")
        g_start_delay = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["start_delay"], pp), *rr_fcdr("start_delay"))
        g_speed_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["speed_factor"], pp), *rr_fcdr("speed_factor"))
        g_speed_maxgap = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["speed_maxgap"], pp), *rr_fcdr("speed_maxgap"))
        g_percentage_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["percentage_factor"], pp), *rr_fcdr("percentage_factor"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mode"], pp), *rr_fcdr("mode")),
            g_transition,
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["time_mode"], pp), *rr_fcdr("time_mode")),
            g_concurrent_time_alignment,
            g_length,
            g_start_delay,
            g_speed_factor,
            g_speed_maxgap,
            g_percentage_factor,
            ButtonSep(2),
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object"))
        ]

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_restrict_frame_range"], pp), *rr_fcdr("use_restrict_frame_range"), title="Effective Range")
        )
        g_frame_start = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["frame_start"], pp), *rr_fcdr("frame_start"), title="Start")
        g_frame_end = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["frame_end"], pp), *rr_fcdr("frame_end"), title="End")
        b1.items = [g_frame_start, g_frame_end]

        b2 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_fading"], pp), *rr_fcdr("use_fading"), title="Fading")
        )
        g_fade_factor = ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["fade_factor"], pp), *rr_fcdr("fade_factor"), title="Factor")
        b2.items = [
            g_fade_factor,
            ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["fade_thickness_strength"], pp), *rr_fcdr("fade_thickness_strength"), title="Thickness"),
            ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["fade_opacity_strength"], pp), *rr_fcdr("fade_opacity_strength"), title="Opacity"),
            ButtonGroupAnimRef(b2, ButtonEnumVertexGroupPush(None, rnas["target_vertex_group"], pp), rr_refdriver("target_vertex_group"), title="Weight Output"),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b1, b2, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.mode == "SEQUENTIAL":
                use_delay = True
                if g_transition.is_dark() is True:
                    g_transition.light()
                if g_concurrent_time_alignment.is_dark() is False:
                    g_concurrent_time_alignment.dark()
            elif modifier.mode == "CONCURRENT":
                use_delay = True
                if g_transition.is_dark() is True:
                    g_transition.light()
                if g_concurrent_time_alignment.is_dark() is True:
                    g_concurrent_time_alignment.light()
            else:
                use_delay = False
                if g_transition.is_dark() is False:
                    g_transition.dark()
                if g_concurrent_time_alignment.is_dark() is False:
                    g_concurrent_time_alignment.dark()

            if modifier.time_mode == "DRAWSPEED":
                if g_speed_factor.is_dark() is True:
                    g_speed_factor.light()
                    g_speed_maxgap.light()
                if g_length.is_dark() is False:
                    g_length.dark()
                if g_start_delay.is_dark() is False:
                    g_start_delay.dark()
                if g_percentage_factor.is_dark() is False:
                    g_percentage_factor.dark()
            elif modifier.time_mode == "FRAMES":
                if g_speed_factor.is_dark() is False:
                    g_speed_factor.dark()
                    g_speed_maxgap.dark()
                if g_length.is_dark() is True:
                    g_length.light()
                if use_delay is True:
                    if g_start_delay.is_dark() is True:
                        g_start_delay.light()
                else:
                    if g_start_delay.is_dark() is False:
                        g_start_delay.dark()
                if g_percentage_factor.is_dark() is False:
                    g_percentage_factor.dark()
            else:
                if g_speed_factor.is_dark() is False:
                    g_speed_factor.dark()
                    g_speed_maxgap.dark()
                if g_length.is_dark() is False:
                    g_length.dark()
                if g_start_delay.is_dark() is False:
                    g_start_delay.dark()
                if g_percentage_factor.is_dark() is True:
                    g_percentage_factor.light()

            if modifier.use_restrict_frame_range:
                if g_frame_start.is_dark() is True:
                    b1.light()
            else:
                if g_frame_start.is_dark() is False:
                    b1.dark()

            if modifier.use_fading:
                if g_fade_factor.is_dark() is True:
                    b2.light()
            else:
                if g_fade_factor.is_dark() is False:
                    b2.dark()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_DASH(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["dash_offset"], pp), *rr_fcdr("dash_offset"))
        ]

        b3 = BlockUtil(self, None, Title("Segments"))
        # <<< 1copy (0areas_gp_segment_fns,, $$)
        def r_segments():
            if hasattr(self.w.active_modifier, "segments"):
                return self.w.active_modifier.segments
            return None
            #|
        def r_segment():
            try:
                modifier = self.w.active_modifier
                return modifier.segments[modifier.segment_active_index]
            except:
                return None
            #|
        def r_active_index():
            modifier = self.w.active_modifier
            if hasattr(modifier, "segment_active_index"):
                ind = modifier.segment_active_index
                if ind is None: return -1
                if 0 <= ind < len(modifier.segments): return ind
            return -1
            #|
        def set_active_index(i, push=True):
            modifier = self.w.active_modifier
            if hasattr(modifier, "segment_active_index"):
                if modifier.segment_active_index != i:
                    modifier.segment_active_index = i
                    if push: update_scene()
            #|
        def r_segment_datapath_head(full=False):
            modifier = self.w.active_modifier
            if hasattr(modifier, "segments"):
                if hasattr(modifier, "segment_active_index"):
                    ind = modifier.segment_active_index
                    if ind is None or ind == -1: return ""
                    if ind >= len(modifier.segments): return ""
                else: return ""
            else: return ""

            if full:
                return f'{r_ID_dp(self.w.active_object)}.modifiers["{escape_identifier(self.w.active_modifier_name)}"].segments["{escape_identifier(modifier.segments[ind].name)}"].'
            return f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].segments["{escape_identifier(modifier.segments[ind].name)}"].'
            #|
        def rr_fcdr_segment(attr):
            def r_fcurve():
                if self.object_fcurves:
                    modifier = self.w.active_modifier
                    if hasattr(modifier, "segment_active_index"):
                        ind = modifier.segment_active_index
                        if ind is None: return None
                        if 0 <= ind < len(modifier.segments):
                            return self.object_fcurves.find(f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].segments["{escape_identifier(modifier.segments[ind].name)}"].{attr}')
                return None
            def r_driver():
                if self.object_drivers:
                    modifier = self.w.active_modifier
                    if hasattr(modifier, "segment_active_index"):
                        ind = modifier.segment_active_index
                        if ind is None: return None
                        if 0 <= ind < len(modifier.segments):
                            return self.object_drivers.find(f'modifiers["{escape_identifier(self.w.active_modifier_name)}"].segments["{escape_identifier(modifier.segments[ind].name)}"].{attr}')
                return None
            return r_fcurve, r_driver
            #|
        # >>>
        ppp = r_segment, self.r_object, r_segment_datapath_head
        rnas_segment = GreasePencilDashModifierSegment.bl_rna.properties
        button_media = ButtonListSegmentMedia(b3, r_segments, r_active_index, set_active_index, self.r_object, self.r_modifier)
        g_list_segments = ButtonListSegment(b3, r_segments, lambda e: e.name, r_active_index, set_active_index, button_media)
        gY = ButtonGroupY(b3, None, gap=SIZE_button[1])
        g_dash = ButtonGroupAnim(gY, ButtonIntPush(None, rnas_segment["dash"], ppp), *rr_fcdr_segment("dash"))
        g_gap = ButtonGroupAnim(gY, ButtonIntPush(None, rnas_segment["gap"], ppp), *rr_fcdr_segment("gap"))
        g_radius = ButtonGroupAnim(gY, ButtonFloatPush(None, rnas_segment["radius"], ppp), *rr_fcdr_segment("radius"))
        g_opacity = ButtonGroupAnim(gY, ButtonFloatPush(None, rnas_segment["opacity"], ppp), *rr_fcdr_segment("opacity"))
        g_material_index = ButtonGroupAnim(gY, ButtonIntPush(None, rnas_segment["material_index"], ppp), *rr_fcdr_segment("material_index"), title="Material")
        g_use_cyclic = ButtonGroupAnimAlignTitleLeft(gY, ButtonBoolPush(None, rnas_segment["use_cyclic"], ppp), *rr_fcdr_segment("use_cyclic"))
        g_dash.button0.poll = poll_hard_disable
        g_gap.button0.poll = poll_hard_disable
        g_radius.button0.poll = poll_hard_disable
        g_opacity.button0.poll = poll_hard_disable
        g_material_index.button0.poll = poll_hard_disable
        g_use_cyclic.button0.poll = poll_hard_disable
        gY.buttons = [
            g_dash,
            g_gap,
            ButtonSep(1),
            g_radius,
            g_opacity,
            g_material_index,
            g_use_cyclic,
            ButtonSep(1),
        ]
        b3.items = [
            button_media,
            ButtonSplit(b3, gY, g_list_segments, gap=lambda: SIZE_border[3], factor=0.66),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b3, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if g_list_segments.upd_collection():
                self.redraw_from_headkey()
                self.upd_data()
                return

            if modifier.segment_active_index is not None and 0 <= modifier.segment_active_index < len(modifier.segments):
                if g_dash.is_dark() is True:
                    gY.light()
            else:
                if g_dash.is_dark() is False:
                    gY.dark()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_ENVELOPE(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_strength = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength"))
        g_mat_nr = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["mat_nr"], pp), *rr_fcdr("mat_nr"))
        g_skip = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["skip"], pp), *rr_fcdr("skip"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mode"], pp), *rr_fcdr("mode")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["spread"], pp), *rr_fcdr("spread")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["thickness"], pp), *rr_fcdr("thickness")),
            g_strength,
            g_mat_nr,
            g_skip,
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.mode == "DEFORM":
                if g_strength.is_dark() is False:
                    g_strength.dark()
                    g_mat_nr.dark()
                    g_skip.dark()
            else:
                if g_strength.is_dark() is True:
                    g_strength.light()
                    g_mat_nr.light()
                    g_skip.light()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_LENGTH(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_start_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["start_factor"], pp), *rr_fcdr("start_factor"))
        g_end_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["end_factor"], pp), *rr_fcdr("end_factor"))
        g_start_length = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["start_length"], pp), *rr_fcdr("start_length"), title="Start Length")
        g_end_length = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["end_length"], pp), *rr_fcdr("end_length"), title="End Length")
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["mode"], pp), *rr_fcdr("mode")),
            ButtonSep(1),
            g_start_factor,
            g_end_factor,
            g_start_length,
            g_end_length,
            ButtonSep(1),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["overshoot_factor"], pp), *rr_fcdr("overshoot_factor")),
        ]
        g_start_length.dark()
        g_end_length.dark()

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_random"], pp), *rr_fcdr("use_random"), title="Randomize")
        )
        g_step = ButtonGroupAnim(b1, ButtonIntPush(None, rnas["step"], pp), *rr_fcdr("step"))
        b1.items = [
            g_step,
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["random_start_factor"], pp), *rr_fcdr("random_start_factor"), title="Offset Start"),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["random_end_factor"], pp), *rr_fcdr("random_end_factor"), title="End"),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["random_offset"], pp), *rr_fcdr("random_offset"), title="Noise Offset"),
            ButtonGroupAnim(b1, ButtonIntPush(None, rnas["seed"], pp), *rr_fcdr("seed")),
        ]

        b2 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_curvature"], pp), *rr_fcdr("use_curvature"), title="Curvature")
        )
        g_point_density = ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["point_density"], pp), *rr_fcdr("point_density"))
        b2.items = [
            g_point_density,
            ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["segment_influence"], pp), *rr_fcdr("segment_influence")),
            ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["max_angle"], pp), *rr_fcdr("max_angle")),
            ButtonGroupAnimAlignTitleLeft(b2, ButtonBoolPush(None, rnas["invert_curvature"], pp), *rr_fcdr("invert_curvature"), title="Invert")
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b1, b2, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_random:
                if g_step.is_dark() is True:
                    b1.light()
            else:
                if g_step.is_dark() is False:
                    b1.dark()

            if modifier.use_curvature:
                if g_point_density.is_dark() is True:
                    b2.light()
            else:
                if g_point_density.is_dark() is False:
                    b2.dark()

            if modifier.mode == "RELATIVE":
                if g_start_factor.is_dark() is True:
                    g_start_factor.light()
                    g_end_factor.light()
                    g_start_length.dark()
                    g_end_length.dark()
            else:
                if g_start_factor.is_dark() is False:
                    g_start_factor.dark()
                    g_end_factor.dark()
                    g_start_length.light()
                    g_end_length.light()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_MIRROR(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonSep(1),
            ButtonGroupAnimBoolArray(b0, [rnas["use_axis_x"], rnas["use_axis_y"], rnas["use_axis_z"]], pp, self.r_fcurve_use_axis_xyz, self.r_driver_use_axis_xyz, title="Axis", button_text=TUP_XYZ),
            ButtonSep(1),
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object")),
            ButtonSep(1),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_MULTIPLY(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["duplicates"], pp), *rr_fcdr("duplicates")),
            ButtonSep(1),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["distance"], pp), *rr_fcdr("distance")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["offset"], pp), *rr_fcdr("offset")),
        ]

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_fade"], pp), *rr_fcdr("use_fade"), title="Fade")
        )
        g_fading_center = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["fading_center"], pp), *rr_fcdr("fading_center"))
        b1.items = [
            g_fading_center,
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["fading_thickness"], pp), *rr_fcdr("fading_thickness")),
            ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["fading_opacity"], pp), *rr_fcdr("fading_opacity")),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b1, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_fade:
                if g_fading_center.is_dark() is True:
                    b1.light()
            else:
                if g_fading_center.is_dark() is False:
                    b1.dark()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_OUTLINE(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_outline_material = ButtonGroupAnimRef(b0, ButtonEnumIDPush(None, rnas["outline_material"], pp, idtype="MATERIAL"), rr_refdriver("outline_material"))
        bu_info = Title("")
        bu_info_blf = bu_info.blf_title
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["thickness"], pp), *rr_fcdr("thickness")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_keep_shape"], pp), *rr_fcdr("use_keep_shape")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["subdivision"], pp), *rr_fcdr("subdivision")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["sample_length"], pp), *rr_fcdr("sample_length")),
            g_outline_material,
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object")),
            ButtonSep(1),
            bu_info,
        ]
        g_outline_material.button0.update_icon()

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if bpy.context.scene.camera:
                bu_info_blf.text = ""
            else:
                bu_info_blf.text = "  ⚠ Outline requires an active camera"

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_SIMPLIFY(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_step = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["step"], pp), *rr_fcdr("step"))
        g_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor"))
        g_length = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["length"], pp), *rr_fcdr("length"))
        g_sharp_threshold = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["sharp_threshold"], pp), *rr_fcdr("sharp_threshold"))
        g_distance = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["distance"], pp), *rr_fcdr("distance"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["mode"], pp, row_length=2), *rr_fcdr("mode")),
            ButtonSep(2),
            g_step,
            g_factor,
            g_length,
            g_sharp_threshold,
            g_distance,
        ]
        g_factor.dark()
        g_length.dark()
        g_sharp_threshold.dark()
        g_distance.dark()

        self.items[:] = [b0]

        def upd_data_callback():
            mode = self.w.active_modifier.mode

            if mode == "FIXED":
                if g_step.is_dark() is True:
                    g_step.light()
                    g_factor.dark()
                    g_length.dark()
                    g_sharp_threshold.dark()
                    g_distance.dark()
            elif mode == "ADAPTIVE":
                if g_factor.is_dark() is True:
                    g_step.dark()
                    g_factor.light()
                    g_length.dark()
                    g_sharp_threshold.dark()
                    g_distance.dark()
            elif mode == "SAMPLE":
                if g_length.is_dark() is True:
                    g_step.dark()
                    g_factor.dark()
                    g_length.light()
                    g_sharp_threshold.light()
                    g_distance.dark()
            else:
                if g_distance.is_dark() is True:
                    g_step.dark()
                    g_factor.dark()
                    g_length.dark()
                    g_sharp_threshold.dark()
                    g_distance.light()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_SUBDIV(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_subdivision_type = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["subdivision_type"], pp, row_length=2), *rr_fcdr("subdivision_type"), title="Type")
        g_level = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["level"], pp), *rr_fcdr("level"))
        b0.buttons = [
            g_subdivision_type,
            g_level,
        ]
        g_subdivision_type.r_button_width = lambda: round(D_SIZE['widget_width'] * 2.0)
        g_level.button0.set_callback = update_scene_and_ref

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_LINEART(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_gap(): return SIZE_widget[0] // 4
        def r_button_width(): return round(D_SIZE['widget_width'] * 1.5)

        b0 = Blocks(self)
        g_use_cache = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_cache"], pp), *rr_fcdr("use_cache"))
        g_source_object = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["source_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("source_object"))
        g_source_collection = ButtonGroupAnimRef(b0, ButtonEnumCollectionPush(None, rnas["source_collection"], pp), rr_refdriver("source_collection"))
        g_use_invert_collection = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_invert_collection"], pp), *rr_fcdr("use_invert_collection"), title="Invert Collection")
        g_target_material = ButtonGroupAnimRef(b0, ButtonEnumIDPush(None, rnas["target_material"], pp, idtype="MATERIAL"), rr_refdriver("target_material"))
        g_opacity = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["opacity"], pp), *rr_fcdr("opacity"))
        b0.buttons = [
            g_use_cache,
            ButtonSep(1),
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["source_type"], pp), *rr_fcdr("source_type")),
            g_source_object,
            g_source_collection,
            g_use_invert_collection,
            ButtonSep(1),
            ButtonGroupAnimRef(b0, ButtonEnumGpLayerPush(None, rnas["target_layer"], pp), rr_refdriver("target_layer")),
            g_target_material,
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["thickness"], pp), *rr_fcdr("thickness"), title="Line Thickness"),
            g_opacity,
            ButtonSep(1),
        ]
        g_target_material.button0.update_icon()

        b1 = BlockUtil(self, None, Title("Edge Types"))
        g_shadow_region_filtering = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["shadow_region_filtering"], pp), *rr_fcdr("shadow_region_filtering"), title="Illumination Filtering")
        g_use_contour = ButtonGroupAnimBoolAlignR(b1, ButtonBoolPush(None, rnas["use_contour"], pp), *rr_fcdr("use_contour"), title="Create")
        g_use_invert_silhouette = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_invert_silhouette"], pp), *rr_fcdr("use_invert_silhouette"), title="Invert")
        g_silhouette_filtering = ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["silhouette_filtering"], pp), *rr_fcdr("silhouette_filtering"), title="")
        g_silhouette_filtering_box_button = g_silhouette_filtering.button0.box_button
        g_use_crease = ButtonGroupAnimBoolAlignR(b1, ButtonBoolPush(None, rnas["use_crease"], pp), *rr_fcdr("use_crease"), title="Crease Threshold")
        g_crease_threshold = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["crease_threshold"], pp), *rr_fcdr("crease_threshold"), title="")
        g_use_light_contour = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_light_contour"], pp), *rr_fcdr("use_light_contour"), title="Light Contour")
        g_use_shadow = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_shadow"], pp), *rr_fcdr("use_shadow"), title="Cast Shadow")
        g_use_overlap_edge_type_support = ButtonGroupAnim(b1, ButtonBoolPush(None, rnas["use_overlap_edge_type_support"], pp), *rr_fcdr("use_overlap_edge_type_support"))
        ti_options = Title("    Options")
        b1.items = [
            g_shadow_region_filtering,
            ButtonSplitBool(b1, g_use_contour, g_silhouette_filtering, lambda: g_silhouette_filtering_box_button.L, gap=r_gap),
            g_use_invert_silhouette,
            ButtonSep(1),
            ButtonSplitBool(b1, g_use_crease, g_crease_threshold, lambda: g_silhouette_filtering_box_button.L, gap=r_gap),
            ButtonSep(1),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_intersection"], pp), *rr_fcdr("use_intersection"), title="Intersections"),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_material"], pp), *rr_fcdr("use_material"), title="Material Borders"),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_edge_mark"], pp), *rr_fcdr("use_edge_mark"), title="Edge Marks"),
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_loose"], pp), *rr_fcdr("use_loose"), title="Loose"),
            g_use_light_contour,
            g_use_shadow,
            ti_options,
            g_use_overlap_edge_type_support,
        ]
        # g_crease_threshold.button0.poll = poll_hard_disable
        # g_use_overlap_edge_type_support.button0.poll = poll_hard_disable

        ti_light_reference = Title("Light Reference")
        b2 = BlockUtil(self, None, ti_light_reference)
        g_light_contour_object = ButtonGroupAnimRef(b2, ButtonEnumObjectPush(None, rnas["light_contour_object"], pp, r_except_objects=self.r_object_set), rr_refdriver("light_contour_object"))
        g_shadow_camera_size = ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["shadow_camera_size"], pp), *rr_fcdr("shadow_camera_size"))
        g_shadow_camera_near = ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["shadow_camera_near"], pp), *rr_fcdr("shadow_camera_near"), title="Near")
        g_shadow_camera_far = ButtonGroupAnim(b2, ButtonFloatPush(None, rnas["shadow_camera_far"], pp), *rr_fcdr("shadow_camera_far"), title="Far")
        b2.items = [
            g_light_contour_object,
            g_shadow_camera_size,
            g_shadow_camera_near,
            g_shadow_camera_far,
        ]
        g_shadow_camera_size.button0.set_callback = update_scene_and_ref
        # for e in b2.items:
        #     e.button0.poll = poll_hard_disable

        ti_geometry_processing = Title("Geometry Processing")
        b3 = BlockUtil(self, None, ti_geometry_processing)
        g_use_custom_camera = ButtonGroupAnimBoolAlignR(b3, ButtonBoolPush(None, rnas["use_custom_camera"], pp), *rr_fcdr("use_custom_camera"), title="Custom Camera")
        g_source_camera = ButtonGroupAnimRef(b3, ButtonEnumObjectPush(None, rnas["source_camera"], pp, r_except_objects=self.r_object_set), rr_refdriver("source_camera"), title="")
        b3.items = [
            ButtonSplitBool(b3, g_use_custom_camera, g_source_camera, lambda: g_silhouette_filtering_box_button.L, gap=r_gap),
            ButtonSep(2),
            ButtonGroupAnimAlignTitleLeft(b3, ButtonBoolPush(None, rnas["use_edge_overlap"], pp), *rr_fcdr("use_edge_overlap"), title="Overlapping Edges as Contour"),
            ButtonGroupAnimAlignTitleLeft(b3, ButtonBoolPush(None, rnas["use_object_instances"], pp), *rr_fcdr("use_object_instances")),
            ButtonGroupAnimAlignTitleLeft(b3, ButtonBoolPush(None, rnas["use_clip_plane_boundaries"], pp), *rr_fcdr("use_clip_plane_boundaries")),
            ButtonGroupAnimAlignTitleLeft(b3, ButtonBoolPush(None, rnas["use_crease_on_smooth"], pp), *rr_fcdr("use_crease_on_smooth")),
            ButtonGroupAnimAlignTitleLeft(b3, ButtonBoolPush(None, rnas["use_crease_on_sharp"], pp), *rr_fcdr("use_crease_on_sharp")),
            ButtonGroupAnimAlignTitleLeft(b3, ButtonBoolPush(None, rnas["use_back_face_culling"], pp), *rr_fcdr("use_back_face_culling"), title="Force Backface Culling"),
        ]
        b3_items = b3.items
        for r in range(2, 8):
            b3_items[r].r_button_width = r_button_width

        b4 = BlockUtil(self, None, Title("Occlusion"))
        ob_pp = self.r_object, self.r_object, self.r_datapath_head_object
        g_show_in_front = ButtonGroupAnimAlignLR(b4, ButtonBoolPush(None, Object_bl_rnas["show_in_front"], ob_pp), *self.rr_fcurve_driver_object("show_in_front"), title="Show in Front", title_head="Object")
        g_use_multiple_levels = ButtonGroupAnimAlignTitleLeft(b4, ButtonBoolPush(None, rnas["use_multiple_levels"], pp), *rr_fcdr("use_multiple_levels"), title="Range")
        g_level_start = ButtonGroupAnim(b4, ButtonIntPush(None, rnas["level_start"], pp), *rr_fcdr("level_start"))
        g_level_end = ButtonGroupAnim(b4, ButtonIntPush(None, rnas["level_end"], pp), *rr_fcdr("level_end"), title="End")

        g_use_material_mask = ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_mask"], pp), *rr_fcdr("use_material_mask"))
        b40 = BlockUtil(b4, None, g_use_material_mask)
        g_use_material_mask_bits = ButtonGroupAnimBoolVector(b40, ButtonBoolVectorPush(None, rnas["use_material_mask_bits"], pp, row_length=4), *rr_fcdr_array("use_material_mask_bits", range(8)))
        g_use_material_mask_match = ButtonGroupAnimAlignTitleLeft(b40, ButtonBoolPush(None, rnas["use_material_mask_match"], pp), *rr_fcdr("use_material_mask_match"), title="Exact Match")
        b40.items = [
            g_use_material_mask_bits,
            g_use_material_mask_match,
        ]
        b4.items = [
            g_show_in_front,
            g_use_multiple_levels,
            g_level_start,
            g_level_end,
            ButtonSep(2),
            b40,
        ]
        g_show_in_front.button0.set_callback = update_scene_and_ref

        b5 = BlockUtil(self, None, Title("Intersection"))
        g_use_intersection_mask = ButtonGroupAnimBoolVector(b5, ButtonBoolVectorPush(None, rnas["use_intersection_mask"], pp, row_length=4), *rr_fcdr_array("use_intersection_mask", range(8)))
        b5.items = [
            g_use_intersection_mask,
            ButtonGroupAnimAlignTitleLeft(b5, ButtonBoolPush(None, rnas["use_intersection_match"], pp), *rr_fcdr("use_intersection_match"), title="Exact Match"),
        ]

        g_use_face_mark = ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_face_mark"], pp), *rr_fcdr("use_face_mark"), title="Face Mark Filtering")
        b6 = BlockUtil(self, None, g_use_face_mark)
        g_use_face_mark_invert = ButtonGroupAnimAlignTitleLeft(b6, ButtonBoolPush(None, rnas["use_face_mark_invert"], pp), *rr_fcdr("use_face_mark_invert"), title="Invert")
        g_use_face_mark_boundaries = ButtonGroupAnimAlignTitleLeft(b6, ButtonBoolPush(None, rnas["use_face_mark_boundaries"], pp), *rr_fcdr("use_face_mark_boundaries"))
        g_use_face_mark_keep_contour = ButtonGroupAnimAlignTitleLeft(b6, ButtonBoolPush(None, rnas["use_face_mark_keep_contour"], pp), *rr_fcdr("use_face_mark_keep_contour"))
        b6.items = [
            g_use_face_mark_invert,
            g_use_face_mark_boundaries,
            g_use_face_mark_keep_contour,
        ]

        ti_chaining = Title("Chaining")
        b7 = BlockUtil(self, None, ti_chaining)
        b7.items = [
            ButtonGroupAnimAlignLR(b7, ButtonBoolPush(None, rnas["use_fuzzy_intersections"], pp), *rr_fcdr("use_fuzzy_intersections"), title_head="Chain"),
            ButtonGroupAnimAlignTitleLeft(b7, ButtonBoolPush(None, rnas["use_fuzzy_all"], pp), *rr_fcdr("use_fuzzy_all")),
            ButtonGroupAnimAlignTitleLeft(b7, ButtonBoolPush(None, rnas["use_loose_edge_chain"], pp), *rr_fcdr("use_loose_edge_chain"), title="Loose Edges"),
            ButtonGroupAnimAlignTitleLeft(b7, ButtonBoolPush(None, rnas["use_loose_as_contour"], pp), *rr_fcdr("use_loose_as_contour"), title="Loose Edges as Contour"),
            ButtonGroupAnimAlignTitleLeft(b7, ButtonBoolPush(None, rnas["use_detail_preserve"], pp), *rr_fcdr("use_detail_preserve")),
            ButtonGroupAnimAlignTitleLeft(b7, ButtonBoolPush(None, rnas["use_geometry_space_chain"], pp), *rr_fcdr("use_geometry_space_chain"), title="Geometry Space"),
            ButtonSep(2),
            ButtonGroupAnim(b7, ButtonFloatPush(None, rnas["chaining_image_threshold"], pp), *rr_fcdr("chaining_image_threshold")),
            ButtonGroupAnim(b7, ButtonFloatPush(None, rnas["smooth_tolerance"], pp), *rr_fcdr("smooth_tolerance")),
            ButtonGroupAnim(b7, ButtonFloatPush(None, rnas["split_angle"], pp), *rr_fcdr("split_angle")),
        ]
        b7_items = b7.items
        for r in range(6):
            b7_items[r].r_button_width = r_button_width

        ti_vertex_weight_transfer = Title("Vertex Weight Transfer")
        b8 = BlockUtil(self, None, ti_vertex_weight_transfer)
        b8.items = [
            ButtonGroupAnimRef(b8, ButtonEnumVertexGroupPush(None, rnas["source_vertex_group"], pp), rr_refdriver("source_vertex_group"), title="Filter Source"),
            ButtonGroupAnimAlignTitleLeft(b8, ButtonBoolPush(None, rnas["invert_source_vertex_group"], pp), *rr_fcdr("invert_source_vertex_group"), title="Invert"),
            ButtonGroupAnimAlignTitleLeft(b8, ButtonBoolPush(None, rnas["use_output_vertex_group_match_by_name"], pp), *rr_fcdr("use_output_vertex_group_match_by_name")),
            ButtonGroupAnimRef(b8, ButtonEnumVertexGroupPush(None, rnas["vertex_group"], pp), rr_refdriver("vertex_group"), title="Target"),
        ]

        b9 = BlockUtil(self, None, Title("Composition"))
        g_use_image_boundary_trimming = ButtonGroupAnim(b9, ButtonBoolPush(None, rnas["use_image_boundary_trimming"], pp), *rr_fcdr("use_image_boundary_trimming"))
        g_stroke_depth_offset = ButtonGroupAnim(b9, ButtonFloatPush(None, rnas["stroke_depth_offset"], pp), *rr_fcdr("stroke_depth_offset"))
        use_offset_towards_custom_camera = ButtonGroupAnim(b9, ButtonBoolPush(None, rnas["use_offset_towards_custom_camera"], pp), *rr_fcdr("use_offset_towards_custom_camera"), title="Towards Custom Camera")
        b9.items = [
            ButtonGroupAnim(b9, ButtonFloatPush(None, rnas["overscan"], pp), *rr_fcdr("overscan")),
            g_use_image_boundary_trimming,
            g_stroke_depth_offset,
            use_offset_towards_custom_camera,
        ]
        g_use_image_boundary_trimming.button0.set_callback = update_scene_and_ref

        b010 = BlockUtil(self, None, Title("Bake"))
        bu_bake = ButtonGroupAnimFn(b010, ButtonFnPush(None, RNA_LINEART_BAKE, self.bufn_LINEART_bake), title="")
        bu_clear = ButtonGroupAnimFn(b010, ButtonFnPush(None, RNA_LINEART_CLEAR, self.bufn_LINEART_clear), title="")
        bu_bake_all = ButtonGroupAnimFn(b010, ButtonFnPush(None, RNA_LINEART_BAKE_ALL, self.bufn_LINEART_bake_all), title="")
        bu_clear_all = ButtonGroupAnimFn(b010, ButtonFnPush(None, RNA_LINEART_CLEAR_ALL, self.bufn_LINEART_clear_all), title="")
        bu_continue = ButtonGroupAnimFn(b010, ButtonFnPush(None, RNA_LINEART_CONTINUE, self.bufn_LINEART_continue), title="")
        b010.items = [
            ButtonSplitBool(b010, bu_bake, bu_clear, lambda: bu_clear.button0.box_button.L + SIZE_widget[0]),
            ButtonSplitBool(b010, bu_bake_all, bu_clear_all, lambda: bu_clear_all.button0.box_button.L + SIZE_widget[0]),
            bu_continue,
        ]
        bu_continue.r_button_width = lambda: bu_clear_all.button0.box_button.R - bu_bake_all.button0.box_button.L

        self.items[:] = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b010]

        g_stroke_depth_offset.dark()
        use_offset_towards_custom_camera.dark()
        bu_continue.dark()

        def upd_data_callback():
            modifier = self.w.active_modifier
            gpencil_is_first_lineart_in_stack = False
            for e in self.w.active_object.modifiers:
                if e == modifier:
                    gpencil_is_first_lineart_in_stack = True
                    break
                if e.type == "LINEART":
                    break

            if modifier.is_baked:
                if g_opacity.is_dark() is False:
                    b0.dark()
                    b1.dark()
                    b2.dark()
                    b3.dark()
                    b4.dark()
                    b5.dark()
                    b6.dark()
                    b7.dark()
                    b8.dark()
                    bu_continue.light()
            else:
                if g_opacity.is_dark() is True:
                    b0.light()
                    b1.light()
                    b2.light()
                    b3.light()
                    b4.light()
                    b5.light()
                    b6.light()
                    b7.light()
                    b8.light()
                    bu_continue.dark()

                if gpencil_is_first_lineart_in_stack is True:
                    if g_use_cache.is_dark() is False:
                        g_use_cache.dark()

                    use_cache = False
                else:
                    if g_use_cache.is_dark() is True:
                        g_use_cache.light()

                    use_cache = modifier.use_cache

                if modifier.source_type == "OBJECT":
                    if g_source_object.is_dark() is True:
                        g_source_object.light()
                    if g_source_collection.is_dark() is False:
                        g_source_collection.dark()
                        g_use_invert_collection.dark()
                elif modifier.source_type == "COLLECTION":
                    if g_source_object.is_dark() is False:
                        g_source_object.dark()
                    if g_source_collection.is_dark() is True:
                        g_source_collection.light()
                        g_use_invert_collection.light()
                else:
                    if g_source_object.is_dark() is False:
                        g_source_object.dark()
                    if g_source_collection.is_dark() is False:
                        g_source_collection.dark()
                        g_use_invert_collection.dark()

                if modifier.light_contour_object:
                    if g_shadow_region_filtering.is_dark() is True:
                        g_shadow_region_filtering.light()
                        g_use_light_contour.light()
                        g_use_shadow.light()
                    if g_shadow_camera_size.is_dark() is True:
                        g_shadow_camera_size.light()
                        g_shadow_camera_near.light()
                        g_shadow_camera_far.light()
                else:
                    if g_shadow_region_filtering.is_dark() is False:
                        g_shadow_region_filtering.dark()
                        g_use_light_contour.dark()
                        g_use_shadow.dark()
                    if g_shadow_camera_size.is_dark() is False:
                        g_shadow_camera_size.dark()
                        g_shadow_camera_near.dark()
                        g_shadow_camera_far.dark()

                if modifier.use_contour:
                    if g_silhouette_filtering.is_dark() is True:
                        g_silhouette_filtering.light()
                else:
                    if g_silhouette_filtering.is_dark() is False:
                        g_silhouette_filtering.dark()

                if use_cache:
                    if g_crease_threshold.is_dark() is False:
                        g_crease_threshold.dark()
                        g_use_overlap_edge_type_support.dark()
                        g_light_contour_object.dark()
                        b3.dark()
                        g_use_face_mark.dark()
                        b6.dark()
                        b7.dark()
                        b8.dark()
                        ti_options.set_text("    Options  (Type overlapping cached)")
                        ti_light_reference.set_text("Light Reference  (Cached from first line art)")
                        ti_geometry_processing.set_text("Geometry Processing  (Cached from first line art)")
                        g_use_face_mark.set_text("Face Mark Filtering        (Cached from first line art)")
                        ti_chaining.set_text("Chaining  (Cached from first line art)")
                        ti_vertex_weight_transfer.set_text("Vertex Weight Transfer  (Cached from first line art)")

                    if g_shadow_camera_size.is_dark() is False:
                        g_shadow_camera_size.dark()
                        g_shadow_camera_near.dark()
                        g_shadow_camera_far.dark()
                    if g_source_camera.is_dark() is False:
                        g_source_camera.dark()
                else:
                    if g_crease_threshold.is_dark() is True:
                        g_crease_threshold.light()
                        g_use_overlap_edge_type_support.light()
                        g_light_contour_object.light()
                        b3.light()
                        g_use_face_mark.light()
                        b7.light()
                        b8.light()
                        ti_options.set_text("    Options")
                        ti_light_reference.set_text("Light Reference")
                        ti_geometry_processing.set_text("Geometry Processing")
                        g_use_face_mark.set_text("Face Mark Filtering")
                        ti_chaining.set_text("Chaining")
                        ti_vertex_weight_transfer.set_text("Vertex Weight Transfer")

                    if modifier.use_custom_camera:
                        if g_source_camera.is_dark() is True:
                            g_source_camera.light()
                    else:
                        if g_source_camera.is_dark() is False:
                            g_source_camera.dark()

                    if modifier.use_face_mark:
                        if g_use_face_mark_invert.is_dark() is True:
                            g_use_face_mark_invert.light()
                            g_use_face_mark_boundaries.light()
                            g_use_face_mark_keep_contour.light()
                    else:
                        if g_use_face_mark_invert.is_dark() is False:
                            g_use_face_mark_invert.dark()
                            g_use_face_mark_boundaries.dark()
                            g_use_face_mark_keep_contour.dark()

                if self.w.active_object.show_in_front:
                    if g_use_multiple_levels.is_dark() is True:
                        g_use_multiple_levels.light()
                        g_level_start.light()
                        g_stroke_depth_offset.dark()
                        use_offset_towards_custom_camera.dark()
                    if modifier.use_multiple_levels:
                        if g_level_end.is_dark() is True:
                            g_level_end.light()

                        if modifier.level_end == 0:
                            if g_use_material_mask.is_dark() is False:
                                g_use_material_mask.dark()
                            if g_use_material_mask_bits.is_dark() is False:
                                g_use_material_mask_bits.dark()
                                g_use_material_mask_match.dark()
                        else:
                            if g_use_material_mask.is_dark() is True:
                                g_use_material_mask.light()
                            if modifier.use_material_mask:
                                if g_use_material_mask_bits.is_dark() is True:
                                    g_use_material_mask_bits.light()
                                    g_use_material_mask_match.light()
                            else:
                                if g_use_material_mask_bits.is_dark() is False:
                                    g_use_material_mask_bits.dark()
                                    g_use_material_mask_match.dark()
                    else:
                        if g_level_end.is_dark() is False:
                            g_level_end.dark()

                        if modifier.level_start == 0:
                            if g_use_material_mask.is_dark() is False:
                                g_use_material_mask.dark()
                            if g_use_material_mask_bits.is_dark() is False:
                                g_use_material_mask_bits.dark()
                                g_use_material_mask_match.dark()
                        else:
                            if g_use_material_mask.is_dark() is True:
                                g_use_material_mask.light()
                            if modifier.use_material_mask:
                                if g_use_material_mask_bits.is_dark() is True:
                                    g_use_material_mask_bits.light()
                                    g_use_material_mask_match.light()
                            else:
                                if g_use_material_mask_bits.is_dark() is False:
                                    g_use_material_mask_bits.dark()
                                    g_use_material_mask_match.dark()
                else:
                    if g_use_multiple_levels.is_dark() is False:
                        g_use_multiple_levels.dark()
                        g_level_start.dark()
                        g_level_end.dark()
                        g_use_material_mask.dark()
                        b40.dark()
                        g_stroke_depth_offset.light()
                        use_offset_towards_custom_camera.light()

                if modifier.use_intersection:
                    if g_use_intersection_mask.is_dark() is True:
                        b5.light()
                else:
                    if g_use_intersection_mask.is_dark() is False:
                        b5.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_ARMATURE(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"ARMATURE"}), rr_refdriver("object")),
            ButtonSep(1),
            ButtonGroupAnimRef(b0, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
            ButtonSep(2),
            ButtonGroupAnimAlignLR(b0, ButtonBoolPush(None, rnas["use_vertex_groups"], pp), *rr_fcdr("use_vertex_groups"), title="Vertex Groups", title_head="Bind To"),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_bone_envelopes"], pp), *rr_fcdr("use_bone_envelopes"), title="Bone Envelopes"),
        ]

        self.items[:] = [b0]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_HOOK(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_armature(): return self.r_modifier().object

        b0 = Blocks(self)
        g_subtarget = ButtonGroupAnimRef(b0, ButtonEnumBonePush(None, rnas["subtarget"], pp, r_armature), rr_refdriver("subtarget"), title="Bone")
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, r_except_objects=self.r_object_set), rr_refdriver("object")),
            g_subtarget,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength")),
        ]

        b1 = BlockUtil(self, None, Title("Falloff"))
        g_edit_curve = ButtonFnPush(b1, RNA_edit_curve, self.bufn_GREASE_PENCIL_HOOK_edit_curve)
        g_falloff_type = ButtonGroupAnim(b1, ButtonEnumFalloffPush(None, rnas["falloff_type"], pp), *rr_fcdr("falloff_type"), title="Type")
        g_falloff_radius = ButtonGroupAnim(b1, ButtonFloatPush(None, rnas["falloff_radius"], pp), *rr_fcdr("falloff_radius"))
        b1.items = [
            ButtonSplit(b1, g_edit_curve, g_falloff_type, gap=r_button_h, factor=0.35),
            g_falloff_radius,
            ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_falloff_uniform"], pp), *rr_fcdr("use_falloff_uniform")),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b1, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.object and modifier.object.type == "ARMATURE":
                if g_subtarget.is_dark() is True: g_subtarget.light()
            else:
                if g_subtarget.is_dark() is False: g_subtarget.dark()

            if modifier.falloff_type == "CURVE":
                if g_edit_curve.is_dark() is True: g_edit_curve.light()

                if g_falloff_radius.is_dark() is True:
                    g_falloff_radius.light()
            else:
                if g_edit_curve.is_dark() is False: g_edit_curve.dark()

                if modifier.falloff_type == "NONE":
                    if g_falloff_radius.is_dark() is False:
                        g_falloff_radius.dark()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_LATTICE(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp, {"LATTICE"}), rr_refdriver("object")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["strength"], pp), *rr_fcdr("strength")),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_NOISE(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor"), title="Position"),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor_strength"], pp), *rr_fcdr("factor_strength"), title="Strength"),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor_thickness"], pp), *rr_fcdr("factor_thickness"), title="Thickness"),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor_uvs"], pp), *rr_fcdr("factor_uvs"), title="UV"),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["noise_scale"], pp), *rr_fcdr("noise_scale")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["noise_offset"], pp), *rr_fcdr("noise_offset")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["seed"], pp), *rr_fcdr("seed")),
        ]

        b1 = BlockUtil(self, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_random"], pp), *rr_fcdr("use_random"), title="Randomize")
        )
        g_random_mode = ButtonGroupAnim(b1, ButtonEnumXYPush(None, rnas["random_mode"], pp, row_length=2), *rr_fcdr("random_mode"))
        g_step = ButtonGroupAnim(b1, ButtonIntPush(None, rnas["step"], pp), *rr_fcdr("step"))
        b1.items = [
            g_random_mode,
            g_step,
        ]
        g_random_mode.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.3)
        g_random_mode.button0.set_callback = update_scene_and_ref

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        g_edit_curve = ButtonFnPush(b9, RNA_edit_curve, self.bufn_GREASE_PENCIL_HOOK_edit_curve)
        g_use_custom_curve = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["use_custom_curve"], pp), *rr_fcdr("use_custom_curve"))
        b9.items.append(ButtonSplit(b9, g_edit_curve, g_use_custom_curve, gap=r_button_h, factor=0.35))

        self.items[:] = [b0, b1, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_random:
                if g_random_mode.is_dark() is True:
                    g_random_mode.light()
                if modifier.random_mode == "STEP":
                    if g_step.is_dark() is True:
                        g_step.light()
                else:
                    if g_step.is_dark() is False:
                        g_step.dark()
            else:
                if g_random_mode.is_dark() is False:
                    g_random_mode.dark()
                    g_step.dark()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            if modifier.use_custom_curve:
                if g_edit_curve.is_dark() is True:
                    g_edit_curve.light()
            else:
                if g_edit_curve.is_dark() is False:
                    g_edit_curve.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_OFFSET(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = BlockUtil(self, None, Title("General"))
        b0.items = [
            ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["location"], pp), *rr_fcdr_array("location", RANGE_3)),
            ButtonSep(),
            ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["rotation"], pp), *rr_fcdr_array("rotation", RANGE_3)),
            ButtonSep(),
            ButtonGroupAnimVector(b0, ButtonFloatVectorPush(None, rnas["scale"], pp), *rr_fcdr_array("scale", RANGE_3)),
            ButtonSep(),
        ]

        b1 = BlockUtil(self, None, Title("Advanced"))
        g_use_uniform_random_scale = ButtonGroupAnimAlignTitleLeft(b1, ButtonBoolPush(None, rnas["use_uniform_random_scale"], pp), *rr_fcdr("use_uniform_random_scale"))
        g_seed = ButtonGroupAnim(b1, ButtonIntPush(None, rnas["seed"], pp), *rr_fcdr("seed"))
        g_stroke_step = ButtonGroupAnim(b1, ButtonIntPush(None, rnas["stroke_step"], pp), *rr_fcdr("stroke_step"))
        g_stroke_start_offset = ButtonGroupAnim(b1, ButtonIntPush(None, rnas["stroke_start_offset"], pp), *rr_fcdr("stroke_start_offset"))
        b1.items = [
            ButtonGroupAnim(b1, ButtonEnumPush(None, rnas["offset_mode"], pp), *rr_fcdr("offset_mode")),
            ButtonSep(),
            ButtonGroupAnimVector(b1, ButtonFloatVectorPush(None, rnas["stroke_location"], pp), *rr_fcdr_array("stroke_location", RANGE_3)),
            ButtonSep(),
            ButtonGroupAnimVector(b1, ButtonFloatVectorPush(None, rnas["stroke_rotation"], pp), *rr_fcdr_array("stroke_rotation", RANGE_3)),
            ButtonSep(),
            ButtonGroupAnimVector(b1, ButtonFloatVectorPush(None, rnas["stroke_scale"], pp), *rr_fcdr_array("stroke_scale", RANGE_3)),
            g_use_uniform_random_scale,
            g_seed,
            g_stroke_step,
            g_stroke_start_offset,
            ButtonSep(),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b1, b9]

        g_stroke_step.dark()
        g_stroke_start_offset.dark()

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.offset_mode == "RANDOM":
                if g_use_uniform_random_scale.is_dark() is True:
                    g_use_uniform_random_scale.light()
                    g_seed.light()
                    g_stroke_step.dark()
                    g_stroke_start_offset.dark()
            else:
                if g_use_uniform_random_scale.is_dark() is False:
                    g_use_uniform_random_scale.dark()
                    g_seed.dark()
                    g_stroke_step.light()
                    g_stroke_start_offset.light()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_SHRINKWRAP(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_fcurve_use():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_project_x'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_project_y'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_project_z')
                ]
            return [None] * 3
        def r_driver_use():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_project_x'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_project_y'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_project_z')
                ]
            return [None] * 3

        b0 = Blocks(self)
        g_wrap_mode = ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["wrap_mode"], pp), *rr_fcdr("wrap_mode"))
        g_auxiliary_target = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["auxiliary_target"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("auxiliary_target"))
        g_project_limit = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["project_limit"], pp), *rr_fcdr("project_limit"))
        g_subsurf_levels = ButtonGroupAnim(b0, ButtonIntPush(None, rnas["subsurf_levels"], pp), *rr_fcdr("subsurf_levels"))
        g_use_project = ButtonGroupAnimBoolArray(b0, [rnas["use_project_x"], rnas["use_project_y"], rnas["use_project_z"]], pp, r_fcurve_use, r_driver_use, title="Axis", button_text=TUP_XYZ)
        g_use_negative_direction = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_negative_direction"], pp), *rr_fcdr("use_negative_direction"))
        g_use_positive_direction = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_positive_direction"], pp), *rr_fcdr("use_positive_direction"))
        g_cull_face = ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["cull_face"], pp, row_length=3), *rr_fcdr("cull_face"))
        g_use_invert_cull = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_invert_cull"], pp), *rr_fcdr("use_invert_cull"))
        b0.buttons = [
            ButtonSep(),
            ButtonGroupAnimFull(b0, ButtonEnumXYPush(None, rnas["wrap_method"], pp, row_length=2), *rr_fcdr("wrap_method"), title=""),
            ButtonSep(3),
            g_wrap_mode,
            ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["target"], pp, {"MESH"}, r_except_objects=self.r_object_set), rr_refdriver("target")),
            g_auxiliary_target,
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["offset"], pp), *rr_fcdr("offset")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["smooth_factor"], pp), *rr_fcdr("smooth_factor")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["smooth_step"], pp), *rr_fcdr("smooth_step"), title="Repeat"),
            g_project_limit,
            g_subsurf_levels,
            g_use_project,
            g_use_negative_direction,
            g_use_positive_direction,
            g_cull_face,
            g_use_invert_cull,
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.wrap_method == "NEAREST_SURFACEPOINT":
                if g_wrap_mode.is_dark() is True:
                    g_wrap_mode.light()
                if g_project_limit.is_dark() is False:
                    g_project_limit.dark()
                    g_subsurf_levels.dark()
                    g_use_project.dark()
                    g_use_negative_direction.dark()
                    g_use_positive_direction.dark()
                    g_cull_face.dark()
                    g_auxiliary_target.dark()
                    g_use_invert_cull.dark()
            elif modifier.wrap_method == "PROJECT":
                if g_wrap_mode.is_dark() is True:
                    g_wrap_mode.light()
                if g_project_limit.is_dark() is True:
                    g_project_limit.light()
                    g_subsurf_levels.light()
                    g_use_project.light()
                    g_use_negative_direction.light()
                    g_use_positive_direction.light()
                    g_cull_face.light()
                    g_auxiliary_target.light()
                if modifier.use_negative_direction and modifier.cull_face in {"FRONT", "BACK"}:
                    if g_use_invert_cull.is_dark() is True:
                        g_use_invert_cull.light()
                else:
                    if g_use_invert_cull.is_dark() is False:
                        g_use_invert_cull.dark()
            elif modifier.wrap_method == "NEAREST_VERTEX":
                if g_wrap_mode.is_dark() is False:
                    g_wrap_mode.dark()
                if g_project_limit.is_dark() is False:
                    g_project_limit.dark()
                    g_subsurf_levels.dark()
                    g_use_project.dark()
                    g_use_negative_direction.dark()
                    g_use_positive_direction.dark()
                    g_cull_face.dark()
                    g_auxiliary_target.dark()
                    g_use_invert_cull.dark()
            else:
                if g_wrap_mode.is_dark() is True:
                    g_wrap_mode.light()
                if g_project_limit.is_dark() is False:
                    g_project_limit.dark()
                    g_subsurf_levels.dark()
                    g_use_project.dark()
                    g_use_negative_direction.dark()
                    g_use_positive_direction.dark()
                    g_cull_face.dark()
                    g_auxiliary_target.dark()
                    g_use_invert_cull.dark()
                

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_SMOOTH(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        def r_fcurve_use_edit_0():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_edit_position'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_edit_strength'),
                ]
            return [None] * 2
            #|
        def r_driver_use_edit_0():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_edit_position'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_edit_strength'),
                ]
            return [None] * 2
            #|
        def r_fcurve_use_edit_1():
            if self.object_fcurves:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_edit_thickness'),
                    self.object_fcurves.find(f'modifiers["{escapename}"].use_edit_uv')
                ]
            return [None] * 2
            #|
        def r_driver_use_edit_1():
            if self.object_drivers:
                escapename = escape_identifier(self.w.active_modifier_name)
                return [
                    self.object_drivers.find(f'modifiers["{escapename}"].use_edit_thickness'),
                    self.object_drivers.find(f'modifiers["{escapename}"].use_edit_uv')
                ]
            return [None] * 2
            #|

        b0 = Blocks(self)
        g_use_edit_0 = ButtonGroupAnimBoolArray(b0, [rnas["use_edit_position"], rnas["use_edit_strength"]], pp, r_fcurve_use_edit_0, r_driver_use_edit_0, button_text=("Position", "Strength"))
        g_use_edit_1 = ButtonGroupAnimBoolArray(b0, [rnas["use_edit_thickness"], rnas["use_edit_uv"]], pp, r_fcurve_use_edit_1, r_driver_use_edit_1, button_text=("Thickness", "UV"))
        g_use_keep_shape = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_keep_shape"], pp), *rr_fcdr("use_keep_shape"))
        g_use_smooth_ends = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_smooth_ends"], pp), *rr_fcdr("use_smooth_ends"))
        b0.buttons = [
            ButtonGroupY(b0, [g_use_edit_0, g_use_edit_1]),
            ButtonSep(3),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor")),
            ButtonGroupAnim(b0, ButtonIntPush(None, rnas["step"], pp), *rr_fcdr("step")),
            ButtonSep(1),
            g_use_keep_shape,
            g_use_smooth_ends,
        ]
        g_use_edit_0.full_size = True
        g_use_edit_1.full_size = True

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_edit_position:
                if g_use_keep_shape.is_dark() is True:
                    g_use_keep_shape.light()
                    g_use_smooth_ends.light()
            else:
                if g_use_keep_shape.is_dark() is False:
                    g_use_keep_shape.dark()
                    g_use_smooth_ends.dark()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_THICKNESS(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_use_weight_factor = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_weight_factor"], pp), *rr_fcdr("use_weight_factor"))
        g_thickness = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["thickness"], pp), *rr_fcdr("thickness"))
        g_thickness_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["thickness_factor"], pp), *rr_fcdr("thickness_factor"))
        b0.buttons = [
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_uniform_thickness"], pp), *rr_fcdr("use_uniform_thickness")),
            g_thickness,
            ButtonSep(),
            g_use_weight_factor,
            g_thickness_factor,
            ButtonSep(),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        g_invert_vertex_group = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_vertex_group"], pp), *rr_fcdr("invert_vertex_group"), title="Invert")
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
            ButtonSep(2),
            ButtonGroupAnimRef(b9, ButtonEnumVertexGroupPush(None, rnas["vertex_group_name"], pp), rr_refdriver("vertex_group_name")),
            g_invert_vertex_group,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        g_edit_curve = ButtonFnPush(b9, RNA_edit_curve, self.bufn_GREASE_PENCIL_HOOK_edit_curve)
        g_use_custom_curve = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["use_custom_curve"], pp), *rr_fcdr("use_custom_curve"))
        b9.items.append(ButtonSplit(b9, g_edit_curve, g_use_custom_curve, gap=r_button_h, factor=0.35))

        self.items[:] = [b0, b9]

        g_use_weight_factor.dark()
        g_thickness_factor.dark()

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_uniform_thickness:
                if g_thickness.is_dark() is True:
                    g_thickness.light()
                    g_thickness_factor.dark()
                    g_use_weight_factor.dark()
            else:
                if g_thickness.is_dark() is False:
                    g_thickness.dark()
                    g_use_weight_factor.light()
                if modifier.use_weight_factor:
                    if g_thickness_factor.is_dark() is False:
                        g_thickness_factor.dark()
                else:
                    if g_thickness_factor.is_dark() is True:
                        g_thickness_factor.light()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence3_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()

            if modifier.vertex_group_name:
                if g_invert_vertex_group.is_dark() is True: g_invert_vertex_group.light()
            else:
                if g_invert_vertex_group.is_dark() is False: g_invert_vertex_group.dark()
            # >>>

            if modifier.use_custom_curve:
                if g_edit_curve.is_dark() is True:
                    g_edit_curve.light()
            else:
                if g_edit_curve.is_dark() is False:
                    g_edit_curve.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_COLOR(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["color_mode"], pp), *rr_fcdr("color_mode")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["hue"], pp), *rr_fcdr("hue")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["saturation"], pp), *rr_fcdr("saturation")),
            ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["value"], pp), *rr_fcdr("value")),
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        g_edit_curve = ButtonFnPush(b9, RNA_edit_curve, self.bufn_GREASE_PENCIL_HOOK_edit_curve)
        g_use_custom_curve = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["use_custom_curve"], pp), *rr_fcdr("use_custom_curve"))
        b9.items.append(ButtonSplit(b9, g_edit_curve, g_use_custom_curve, gap=r_button_h, factor=0.35))

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            if modifier.use_custom_curve:
                if g_edit_curve.is_dark() is True:
                    g_edit_curve.light()
            else:
                if g_edit_curve.is_dark() is False:
                    g_edit_curve.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_TINT(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["factor"], pp), *rr_fcdr("factor"))
        g_object = ButtonGroupAnimRef(b0, ButtonEnumObjectPush(None, rnas["object"], pp), rr_refdriver("object"))
        g_radius = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["radius"], pp), *rr_fcdr("radius"))
        g_color = ButtonGroupAnimColor(b0, ButtonColor3Push(None, rnas["color"], pp), *rr_fcdr_array("color", RANGE_3))
        g_color_ramp = ButtonGroupAnimFn(b0, ButtonFnPush(b0, RNA_edit_color_ramp, self.bufn_GREASE_PENCIL_TINT_color_ramp), title="")
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["color_mode"], pp), *rr_fcdr("color_mode")),
            ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_weight_as_factor"], pp), *rr_fcdr("use_weight_as_factor"), title="Use Weight"),
            g_factor,
            ButtonSep(2),
            ButtonGroupAnim(b0, ButtonEnumXYPush(None, rnas["tint_mode"], pp, row_length=2), *rr_fcdr("tint_mode")),
            g_object,
            g_radius,
            g_color_ramp,
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        g_edit_curve = ButtonFnPush(b9, RNA_edit_curve, self.bufn_GREASE_PENCIL_HOOK_edit_curve)
        g_use_custom_curve = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["use_custom_curve"], pp), *rr_fcdr("use_custom_curve"))
        b9.items.append(ButtonSplit(b9, g_edit_curve, g_use_custom_curve, gap=r_button_h, factor=0.35))

        self.items[:] = [b0, b9]

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.use_weight_as_factor:
                if g_factor.is_dark() is False:
                    g_factor.dark()
            else:
                if g_factor.is_dark() is True:
                    g_factor.light()

            if modifier.tint_mode == "UNIFORM":
                if g_object.is_dark() is False:
                    g_object.dark()
                    g_radius.dark()
                    b0.buttons[-1] = g_color
                    self.redraw_from_headkey()
                    self.upd_data()
                    return
            else:
                if g_object.is_dark() is True:
                    g_object.light()
                    g_radius.light()
                    b0.buttons[-1] = g_color_ramp
                    self.redraw_from_headkey()
                    self.upd_data()
                    return

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            if modifier.use_custom_curve:
                if g_edit_curve.is_dark() is True:
                    g_edit_curve.light()
            else:
                if g_edit_curve.is_dark() is False:
                    g_edit_curve.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|
    def init_tab_GREASE_PENCIL_OPACITY(self):
        BlockUtil.DEFAULT_FOLD_STATE = P_ModifierEditor.is_fold
        pp = self.r_modifier, self.r_object, self.r_datapath_head
        rnas = self.w.active_modifier.bl_rna.properties
        rr_fcdr = self.rr_fcurve_driver
        rr_refdriver = self.rr_refdriver
        rr_fcdr_array = self.rr_fcurve_driver_array

        b0 = Blocks(self)
        g_use_uniform_opacity = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_uniform_opacity"], pp), *rr_fcdr("use_uniform_opacity"))
        g_use_weight_as_factor = ButtonGroupAnimAlignTitleLeft(b0, ButtonBoolPush(None, rnas["use_weight_as_factor"], pp), *rr_fcdr("use_weight_as_factor"), title="Use Weight")
        g_color_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["color_factor"], pp), *rr_fcdr("color_factor"), title="Opacity")
        g_hardness_factor = ButtonGroupAnim(b0, ButtonFloatPush(None, rnas["hardness_factor"], pp), *rr_fcdr("hardness_factor"))
        b0.buttons = [
            ButtonGroupAnim(b0, ButtonEnumPush(None, rnas["color_mode"], pp), *rr_fcdr("color_mode")),
            g_use_uniform_opacity,
            g_use_weight_as_factor,
            g_color_factor,
            g_hardness_factor,
        ]

        # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2,, $$)
        b9 = BlockUtil(self, None, Title("Influence"))
        g_layer_filter = ButtonGroupAnimRef(b9, ButtonEnumGpLayerPush(None, rnas["layer_filter"], pp), rr_refdriver("layer_filter"))
        g_invert_layer_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_layer_filter"], pp), *rr_fcdr("invert_layer_filter"))
        g_material_filter = ButtonGroupAnimRef(b9, ButtonEnumIDPush(None, rnas["material_filter"], pp, idtype="MATERIAL"), rr_refdriver("material_filter"))
        g_invert_material_filter = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["invert_material_filter"], pp), *rr_fcdr("invert_material_filter"))
        b90 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_layer_pass_filter"], pp), *rr_fcdr("use_layer_pass_filter"))
        )
        g_layer_pass_filter = ButtonGroupAnim(b90, ButtonIntPush(None, rnas["layer_pass_filter"], pp), *rr_fcdr("layer_pass_filter"))
        g_invert_layer_pass_filter = ButtonGroupAnimAlignTitleLeft(b90, ButtonBoolPush(None, rnas["invert_layer_pass_filter"], pp), *rr_fcdr("invert_layer_pass_filter"), title="Invert")
        b90.items = [
            g_layer_pass_filter,
            g_invert_layer_pass_filter,
        ]
        b91 = BlockUtil(b9, None,
            ButtonGroupAnimAlignL(None, ButtonBoolPush(None, rnas["use_material_pass_filter"], pp), *rr_fcdr("use_material_pass_filter"))
        )
        g_material_pass_filter = ButtonGroupAnim(b91, ButtonIntPush(None, rnas["material_pass_filter"], pp), *rr_fcdr("material_pass_filter"))
        g_invert_material_pass_filter = ButtonGroupAnimAlignTitleLeft(b91, ButtonBoolPush(None, rnas["invert_material_pass_filter"], pp), *rr_fcdr("invert_material_pass_filter"), title="Invert")
        b91.items = [
            g_material_pass_filter,
            g_invert_material_pass_filter,
        ]
        b9.items = [
            g_layer_filter,
            g_invert_layer_filter,
            b90,
            ButtonSep(2),
            g_material_filter,
            g_invert_material_filter,
            b91,
        ]
        g_material_filter.button0.update_icon()
        # >>>

        g_edit_curve = ButtonFnPush(b9, RNA_edit_curve, self.bufn_GREASE_PENCIL_HOOK_edit_curve)
        g_use_custom_curve = ButtonGroupAnimAlignTitleLeft(b9, ButtonBoolPush(None, rnas["use_custom_curve"], pp), *rr_fcdr("use_custom_curve"))
        b9.items.append(ButtonSplit(b9, g_edit_curve, g_use_custom_curve, gap=r_button_h, factor=0.35))

        self.items[:] = [b0, b9]

        g_hardness_factor.dark()

        def upd_data_callback():
            modifier = self.w.active_modifier

            if modifier.color_mode == "HARDNESS":
                if g_hardness_factor.is_dark() is True:
                    g_hardness_factor.light()
                    g_use_uniform_opacity.dark()
                    g_use_weight_as_factor.dark()
                    g_color_factor.dark()
            else:
                if g_hardness_factor.is_dark() is False:
                    g_hardness_factor.dark()
                    g_use_uniform_opacity.light()
                    g_use_weight_as_factor.light()

                if modifier.use_weight_as_factor:
                    if g_color_factor.is_dark() is False:
                        g_color_factor.dark()
                else:
                    if g_color_factor.is_dark() is True:
                        g_color_factor.light()

            # <<< 1copy (0areas_init_tab_GREASE_PENCIL_TEXTURE_influence2_callback,, $$)
            if modifier.use_layer_pass_filter:
                if g_invert_layer_pass_filter.is_dark() is True:
                    g_invert_layer_pass_filter.light()
                    g_layer_pass_filter.light()
            else:
                if g_invert_layer_pass_filter.is_dark() is False:
                    g_invert_layer_pass_filter.dark()
                    g_layer_pass_filter.dark()

            if modifier.use_material_pass_filter:
                if g_invert_material_pass_filter.is_dark() is True:
                    g_invert_material_pass_filter.light()
                    g_material_pass_filter.light()
            else:
                if g_invert_material_pass_filter.is_dark() is False:
                    g_invert_material_pass_filter.dark()
                    g_material_pass_filter.dark()
            # >>>

            if modifier.use_custom_curve:
                if g_edit_curve.is_dark() is True:
                    g_edit_curve.light()
            else:
                if g_edit_curve.is_dark() is False:
                    g_edit_curve.dark()

            for e in self.items: e.upd_data()

        self.upd_data_callback = upd_data_callback
        #|

    def catch_bufn(self, fn, evtkill=True, push_message=""):
        if evtkill: kill_evt_except()
        try:
            if r_library_editable(self.r_object()) is False: return

            with bpy.context.temp_override(object=self.w.active_object): fn()
            if push_message:
                ed_undo_push(message=push_message)
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Failed.\n{ex}')
        #|
    def bufn_BEVEL_edit_profile(self):

        kill_evt_except()
        try:
            if r_library_editable(self.r_object()) is False: return

            OpBevelProfile.md = self.w.active_modifier
            bpy.ops.wm.vmd_bevel_profile("INVOKE_DEFAULT")
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Unexpected error, please report to the author.\n{ex}')
        #|
    def bufn_HOOK_edit_curve(self):

        kill_evt_except()
        try:
            if r_library_editable(self.r_object()) is False: return

            OpFalloffCurve.md = self.w.active_modifier
            OpFalloffCurve.attr = "falloff_curve"
            bpy.ops.wm.vmd_falloff_curve("INVOKE_DEFAULT")
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Unexpected error, please report to the author.\n{ex}')
        #|
    def bufn_VERTEX_WEIGHT_EDIT_edit_curve(self):

        kill_evt_except()
        try:
            if r_library_editable(self.r_object()) is False: return

            OpFalloffCurve.md = self.w.active_modifier
            OpFalloffCurve.attr = "map_curve"
            bpy.ops.wm.vmd_falloff_curve("INVOKE_DEFAULT")
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Unexpected error, please report to the author.\n{ex}')
        #|
    def bufn_CORRECTIVE_SMOOTH_bind(self):

        self.catch_bufn(
            lambda: bpy.ops.object.correctivesmooth_bind(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Bind")
        #|
    def bufn_LAPLACIANDEFORM_bind(self):

        self.catch_bufn(
            lambda: bpy.ops.object.laplaciandeform_bind(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Bind")
        #|
    def bufn_MESH_DEFORM_bind(self):

        self.catch_bufn(
            lambda: bpy.ops.object.meshdeform_bind(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Bind")
        #|
    def bufn_SURFACE_DEFORM_bind(self):

        self.catch_bufn(
            lambda: bpy.ops.object.surfacedeform_bind(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Bind")
        #|
    def bufn_DATA_TRANSFER_gen(self):

        self.catch_bufn(
            lambda: bpy.ops.object.datalayout_transfer(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Generate Data Layers")
        #|
    def bnfn_EXPLODE_refresh(self, evtkill=True):

        self.catch_bufn(
            lambda: bpy.ops.object.explode_refresh(modifier=self.w.active_modifier.name),
            evtkill=evtkill)

        upd_link_data()
        #|
    def bufn_MULTIRES_subdivide(self):

        self.catch_bufn(
            lambda: bpy.ops.object.multires_subdivide(modifier=self.w.active_modifier.name, mode='CATMULL_CLARK'),
            push_message = "VMD MD Subdivide")
        #|
    def bufn_MULTIRES_simple(self):

        self.catch_bufn(
            lambda: bpy.ops.object.multires_subdivide(modifier=self.w.active_modifier.name, mode='SIMPLE'),
            push_message = "VMD MD Simple")
        #|
    def bufn_MULTIRES_linear(self):

        self.catch_bufn(
            lambda: bpy.ops.object.multires_subdivide(modifier=self.w.active_modifier.name, mode='LINEAR'),
            push_message = "VMD MD Linear")
        #|
    def bufn_MULTIRES_unsubdivide(self):

        self.catch_bufn(
            lambda: bpy.ops.object.multires_unsubdivide(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Unsubdivide")
        #|
    def bufn_MULTIRES_delete_higher(self):

        self.catch_bufn(
            lambda: bpy.ops.object.multires_higher_levels_delete(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Delete Higher")
        #|
    def bufn_MULTIRES_reshape(self):

        self.catch_bufn(
            lambda: bpy.ops.object.multires_reshape(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Reshape")
        #|
    def bufn_MULTIRES_apply_base(self):

        self.catch_bufn(
            lambda: bpy.ops.object.multires_base_apply(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Apply Base")
        #|
    def bufn_MULTIRES_rebuild(self):

        self.catch_bufn(
            lambda: bpy.ops.object.multires_rebuild_subdiv(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Rebuild Subdivisions")
        #|
    def bufn_MULTIRES_save_external(self):

        def fn():
            if self.w.active_modifier.is_external:
                bpy.ops.object.multires_external_pack()
            else:
                bpy.ops.object.multires_external_save("INVOKE_DEFAULT", modifier=self.w.active_modifier.name)
        self.catch_bufn(fn)
        #|
    def bufn_OCEAN_bake(self):

        self.catch_bufn(
            lambda: bpy.ops.object.ocean_bake(modifier=self.w.active_modifier.name, free=True if self.w.active_modifier.is_cached else False),
            push_message = "VMD MD Ocean Bake")
        #|
    def bufn_SKIN_create_armature(self):

        self.catch_bufn(
            lambda: bpy.ops.object.skin_armature_create(modifier=self.w.active_modifier.name),
            push_message = "VMD MD Create Armature")
        #|
    def bufn_SKIN_add_skin_data(self):

        self.catch_bufn(
            lambda: bpy.ops.mesh.customdata_skin_add(),
            push_message = "VMD MD Add Skin Data")
        #|
    def bufn_SKIN_mark_loose(self):

        self.catch_bufn(
            lambda: bpy.ops.object.skin_loose_mark_clear(action='MARK'),
            push_message = "VMD MD Mark Loose")
        #|
    def bufn_SKIN_clear_loose(self):

        self.catch_bufn(
            lambda: bpy.ops.object.skin_loose_mark_clear(action='CLEAR'),
            push_message = "VMD MD Clear Loose")
        #|
    def bufn_SKIN_mark_root(self):

        self.catch_bufn(
            lambda: bpy.ops.object.skin_root_mark(),
            push_message = "VMD MD Mark Root")
        #|
    def bufn_SKIN_equalize_radii(self):

        self.catch_bufn(
            lambda: bpy.ops.object.skin_radii_equalize(),
            push_message = "VMD MD Equalize Radii")
        #|
    def bufn_LINEART_bake(self):
        def bufn():
            bpy.ops.object.lineart_bake_strokes()
            update_scene()

        self.catch_bufn(bufn, push_message = "VMD MD Line Art Bake")
        #|
    def bufn_LINEART_bake_all(self):
        if hasattr(bpy.ops.object, "lineart_bake_strokes_all"):
            def bufn():
                bpy.ops.object.lineart_bake_strokes_all()
                update_scene()
        else:
            def bufn():
                bpy.ops.object.lineart_bake_strokes(bake_all=True)
                update_scene()

        self.catch_bufn(bufn, push_message = "VMD MD Line Art bake all")
        #|
    def bufn_LINEART_clear(self):
        def bufn():
            bpy.ops.object.lineart_clear()
            update_scene()

        self.catch_bufn(bufn, push_message = "VMD MD Line Art clear bake")
        #|
    def bufn_LINEART_clear_all(self):
        if hasattr(bpy.ops.object, "lineart_clear_all"):
            def bufn():
                bpy.ops.object.lineart_clear_all()
                update_scene()
        else:
            def bufn():
                bpy.ops.object.lineart_clear(clear_all=True)
                update_scene()

        self.catch_bufn(bufn, push_message = "VMD MD Line Art clear all bake")
        #|
    def bufn_LINEART_continue(self):
        modifier = self.w.active_modifier
        if hasattr(modifier, "type") and modifier.type == "LINEART" and modifier.is_baked:
            modifier.is_baked = False
            update_scene_push("VMD MD Line Art Continue")
        #|
    def bufn_GREASE_PENCIL_HOOK_edit_curve(self):
        kill_evt_except()
        try:
            if r_library_editable(self.r_object()) is False: return

            OpFalloffCurve.md = self.w.active_modifier
            OpFalloffCurve.attr = "custom_curve"
            bpy.ops.wm.vmd_falloff_curve("INVOKE_DEFAULT")
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Unexpected error, please report to the author.\n{ex}')
        #|
    def bufn_GREASE_PENCIL_TINT_color_ramp(self):
        kill_evt_except()
        OpColorRamp.md = self.w.active_modifier
        OpColorRamp.attr = "color_ramp"
        bpy.ops.wm.vmd_color_ramp("INVOKE_DEFAULT")
        #|

    def r_fcurve_use_xyz(self):
        if self.object_fcurves:
            escapename = escape_identifier(self.w.active_modifier_name)
            return [
                self.object_fcurves.find(f'modifiers["{escapename}"].use_x'),
                self.object_fcurves.find(f'modifiers["{escapename}"].use_y'),
                self.object_fcurves.find(f'modifiers["{escapename}"].use_z')
            ]
        return [None] * 3
        #|
    def r_driver_use_xyz(self):
        if self.object_drivers:
            escapename = escape_identifier(self.w.active_modifier_name)
            return [
                self.object_drivers.find(f'modifiers["{escapename}"].use_x'),
                self.object_drivers.find(f'modifiers["{escapename}"].use_y'),
                self.object_drivers.find(f'modifiers["{escapename}"].use_z')
            ]
        return [None] * 3
        #|
    def r_fcurve_use_axis_xyz(self):
        if self.object_fcurves:
            escapename = escape_identifier(self.w.active_modifier_name)
            return [
                self.object_fcurves.find(f'modifiers["{escapename}"].use_axis_x'),
                self.object_fcurves.find(f'modifiers["{escapename}"].use_axis_y'),
                self.object_fcurves.find(f'modifiers["{escapename}"].use_axis_z')
            ]
        return [None] * 3
        #|
    def r_driver_use_axis_xyz(self):
        if self.object_drivers:
            escapename = escape_identifier(self.w.active_modifier_name)
            return [
                self.object_drivers.find(f'modifiers["{escapename}"].use_axis_x'),
                self.object_drivers.find(f'modifiers["{escapename}"].use_axis_y'),
                self.object_drivers.find(f'modifiers["{escapename}"].use_axis_z')
            ]
        return [None] * 3
        #|

    def upd_data(self):
        ob = self.w.active_object
        object_fcurves = None
        object_drivers = None

        if hasattr(ob, "animation_data"):
            animation_data = ob.animation_data
            if hasattr(animation_data, "action"):
                if hasattr(animation_data.action, "fcurves"):
                    object_fcurves = animation_data.action.fcurves
            if hasattr(animation_data, "drivers"):
                object_drivers = animation_data.drivers

        self.object_fcurves = object_fcurves
        self.object_drivers = object_drivers

        if self.active_tab == self.w.active_tab:
            if hasattr(self, "upd_data_callback"): self.upd_data_callback()
        else:

            self.init_tab(self.w.active_tab)

            if hasattr(self, "upd_data_callback"): self.upd_data_callback()
        #|
    #|
    #|


RNA_edit_profile = RnaButton("edit_profile",
    name = "Edit Profile",
    button_text = "Edit Profile",
    description = "Edit Profile",
    size = -5)
RNA_edit_curve = RnaButton("edit_curve",
    name = "Edit Curve",
    button_text = "Edit Curve",
    description = "Edit Curve",
    size = -5)
RNA_CORRECTIVE_SMOOTH_bind = RnaButton("CORRECTIVE_SMOOTH_bind",
    name = "Bind",
    button_text = "Bind",
    description = "Bind base pose in Corrective Smooth modifier",
    size = 5)
RNA_DATA_TRANSFER_gen = RnaButton("DATA_TRANSFER_gen",
    name = "Generate Data Layers",
    button_text = "Generate Data Layers",
    description = "Transfer layout of data layer(s) from active to selected meshes")
RNA_EXPLODE_refresh = RnaButton("EXPLODE_refresh",
    name = "Refresh",
    button_text = "Refresh",
    description = "Refresh data in the Explode modifier",
    size = 5)
RNA_LAPLACIANDEFORM_bind = RnaButton("LAPLACIANDEFORM_bind",
    name = "Bind",
    button_text = "Bind",
    description = "Bind mesh to system in laplacian deform modifier",
    size = 5)
RNA_MESH_DEFORM_bind = RnaButton("MESH_DEFORM_bind",
    name = "Bind",
    button_text = "Bind",
    description = "Bind mesh to cage in mesh deform modifier",
    size = 5)
RNA_SURFACE_DEFORM_bind = RnaButton("SURFACE_DEFORM_bind",
    name = "Bind",
    button_text = "Bind",
    description = "Bind mesh to target in surface deform modifier",
    size = 5)
RNA_MULTIRES_subdivide = RnaButton("MULTIRES_subdivide",
    name = "Subdivide",
    button_text = "Subdivide",
    description = "Add a new level of subdivision")
RNA_MULTIRES_simple = RnaButton("MULTIRES_simple",
    name = "Simple",
    button_text = "Simple",
    description = "Add a new level of subdivision")
RNA_MULTIRES_linear = RnaButton("MULTIRES_linear",
    name = "Linear",
    button_text = "Linear",
    description = "Add a new level of subdivision")
RNA_MULTIRES_unsubdivide = RnaButton("MULTIRES_unsubdivide",
    name = "Unsubdivide",
    button_text = "Unsubdivide",
    description = "Rebuild a lower subdivision level of the current base mesh")
RNA_MULTIRES_delete_higher = RnaButton("MULTIRES_delete_higher",
    name = "Delete Higher",
    button_text = "Delete Higher",
    description = "Deletes the higher resolution mesh, potential loss of detail")
RNA_MULTIRES_reshape = RnaButton("MULTIRES_reshape",
    name = "Reshape",
    button_text = "Reshape",
    description = "Copy Vertex coordinates from other object")
RNA_MULTIRES_apply_base = RnaButton("MULTIRES_apply_base",
    name = "Apply Base",
    button_text = "Apply Base",
    description = "Modify the base mesh to conform to the displaced mesh")
RNA_MULTIRES_rebuild = RnaButton("MULTIRES_rebuild",
    name = "Rebuild Subdivisions",
    button_text = "Rebuild Subdivisions",
    description = "Rebuilds all possible subdivisions levels to generate a lower resolution base mesh")
RNA_MULTIRES_save_external = RnaButton("MULTIRES_save_external",
    name = "Save External File",
    button_text = "Save External File",
    description = "Save displacements to an external file")
RNA_OCEAN_bake = RnaButton("OCEAN_bake",
    name = "Bake Ocean",
    button_text = "Bake Ocean",
    description = "Bake an image sequence of ocean data")
RNA_SKIN_create_armature = RnaButton("SKIN_create_armature",
    name = "Create Armature",
    button_text = "Create Armature",
    description = "Create an armature that parallels the skin layout")
RNA_SKIN_add_skin_data = RnaButton("SKIN_add_skin_data",
    name = "Add Skin Data",
    button_text = "Add Skin Data",
    description = "Add a vertex skin layer")
RNA_SKIN_mark_loose = RnaButton("SKIN_mark_loose",
    name = "Mark Loose",
    button_text = "Mark Loose",
    description = "Mark selected vertices as loose")
RNA_SKIN_clear_loose = RnaButton("SKIN_clear_loose",
    name = "Clear Loose",
    button_text = "Clear Loose",
    description = "Clear selected vertices as loose")
RNA_SKIN_mark_root = RnaButton("SKIN_mark_root",
    name = "Mark Root",
    button_text = "Mark Root",
    description = "Mark selected vertices as roots")
RNA_SKIN_equalize_radii = RnaButton("SKIN_equalize_radii",
    name = "Equalize Radii",
    button_text = "Equalize Radii",
    description = "Make skin radii of selected vertices equal on each axis")
RNA_LINEART_BAKE = RnaButton("LINEART_BAKE",
    name = "Bake Line Art",
    button_text = "Bake Line Art",
    description = "Bake Line Art for current Grease Pencil object")
RNA_LINEART_BAKE_ALL = RnaButton("LINEART_BAKE_ALL",
    name = "Bake All",
    button_text = "Bake All",
    description = "Bake Line Art for current Grease Pencil object")
RNA_LINEART_CLEAR = RnaButton("LINEART_CLEAR",
    name = "Clear Baked Line Art",
    button_text = "Clear Baked Line Art",
    description = "Clear all strokes in current Grease Pencil object")
RNA_LINEART_CLEAR_ALL = RnaButton("LINEART_CLEAR_ALL",
    name = "Clear All",
    button_text = "Clear All",
    description = "Clear all strokes in current Grease Pencil object")
RNA_LINEART_CONTINUE = RnaButton("LINEART_CONTINUE",
    name = "Continue Without Clearing",
    button_text = "Continue Without Clearing",
    description = "Modify properties without clearing data")
RNA_edit_color_ramp = RnaButton("edit_color_ramp",
    name = "Edit Color Ramp",
    button_text = "Edit Color Ramp",
    description = "",
    size = 10)


## _import_lv2_ ##
def _import_lv2_():
    #|
    from ... api import attr_NodesModifier_bake_directory
    from ... block import (
        Blocks,
        BlockUtil,
        Title,
        ButtonSep,
        ButtonSplit,
        ButtonSplitBool,
        ButtonGroupAnim,
        ButtonGroupAnimFn,
        ButtonGroupAnimAlignL,
        ButtonGroupAnimAlignTitleLeft,
        ButtonGroupAnimAlignLR,
        ButtonGroupAnimFull,
        ButtonGroupAnimRefAlignL,
        ButtonGroupAnimRefAlignTitleLeft,
        ButtonGroupAnimRefAlignLR,
        ButtonGroupAnimRefFull,
        ButtonGroupAnimRef,
        ButtonGroupAnimVector,
        ButtonGroupAnimBoolVector,
        ButtonGroupAnimBoolArray,
        ButtonGroupAnimBoolXYZ,
        ButtonGroupAnimBoolAlignR,
        ButtonGroupY,
        ButtonGroupAnimColor,
        ButtonEnumPush,
        ButtonEnumXYPush,
        ButtonEnumXYFlagPush,
        ButtonIntPush,
        ButtonFloatPush,
        ButtonBoolPush,
        ButtonBoolXYZPush,
        ButtonFloatVectorPush,
        ButtonBoolVectorPush,
        ButtonEnumObjectPush,
        ButtonEnumParticlePush,
        ButtonEnumTexturePush,
        ButtonEnumCacheFilePush,
        ButtonEnumNodeTreePush,
        ButtonEnumCollectionPush,
        ButtonEnumVertexGroupPush,
        ButtonEnumUVPush,
        ButtonEnumGpLayerPush,
        ButtonEnumVertexColorPush,
        ButtonEnumBonePush,
        ButtonEnumFalloffPush,
        ButtonEnumIDPush,
        ButtonStringPush,
        ButtonStringObjectPathPush,
        ButtonStringFilePush,
        ButtonFnPush,
        ButtonColor3Push,
        ButtonListLayerMedia,
        ButtonListSegmentMedia,
        ButtonListLayer,
        ButtonListSegment,
        gn_ui_AttrName,
        GnOutputAttrName,
        GnGroupRef,
        GnGroupBoolStack,
        D_gn_ui,
        S_gn_output_sockets,
        poll_hard_disable,
    )
    from ... dd import DropDownOk
    from ... handle import upd_link_data
    from ... keysys import TRIGGER, EVT_TYPE, r_end_trigger, MOUSE, kill_evt_except
    from ... m import P, Admin
    from ... win import Head

    from ... util.const import RANGE_2, RANGE_3, TUP_XYZ, STR_09

    from ... utilbl import blg
    from ... utilbl.blg import (
        r_button_h,
        FONT0,
        D_SIZE,
        SIZE_border,
        SIZE_dd_border,
        SIZE_widget,
        SIZE_button,
        COL_box_val_fg_error,
    )
    from ... utilbl.general import (
        update_scene,
        update_scene_push,
        r_library_editable,
        r_ID_dp,
    )
    from ... utilbl.ops import OpBevelProfile, OpFalloffCurve, OpColorRamp

    P_ModifierEditor = P.ModifierEditor
    Object_bl_rnas = bpy.types.Object.bl_rna.properties

    globals().update(locals())
    #|
