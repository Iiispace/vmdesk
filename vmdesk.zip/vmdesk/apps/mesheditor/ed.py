











import bpy
from mathutils.geometry import normal
from numpy.linalg import matrix_rank

from ... area import (
    AreaBlock,
    AreaBlockTab,
    AreaBlockHead,
)
from ... win import Window, StructGlobalUndo

## _editor_ ##
class MeshEditor(Window, StructGlobalUndo):
    __slots__ = (
        'area_head',
        'area_tab',
        'local_space',
        'active_tab')

    name = 'Mesh Editor'

    def init(self, boxes, blfs):
        BlendDataTemp.init()

        self.local_space = "GLOBAL"

        # /* 0ed_MeshEditor_init
        PP = self.P_editor
        border_outer = SIZE_border[0]
        border_inner = SIZE_border[1]
        widget_rim = SIZE_border[3]
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        widget_full_h = D_SIZE['widget_full_h']
        d0x2h = d0 + d0 + widget_full_h
        LL = self.box_win.L + border_outer
        TT = self.box_win.title_B - border_outer
        width_min = 6 * widget_full_h

        RR = LL + round(2.612 * D_SIZE['widget_width'] * PP.area_widthfac)
        B0 = TT - AreaBlock.calc_height_by_block_len(1)
        T0 = B0 - d1
        BB = T0 - round(2.79 * D_SIZE['widget_width'] * PP.area_heightfac)
        # */

        area_head = AreaBlockHead(self, LL, RR, B0, TT)
        b0 = BlockR(area_head)
        b0.background_off()
        b0.buttons = [ButtonEnumXY(b0, RNA_local_space, self, row_length=2)]
        area_head.items.append(b0)
        area_head.init_draw_range()

        area_tab = AreaBlockTabMeshEditor(self, LL, RR, BB, T0)
        area_tab.active_tab = ("",)
        area_tab.props = r_props_by_rnas(RNAS_mesh)
        self.areas = [area_head, area_tab]
        self.area_head = area_head
        self.area_tab = area_tab

        self.upd_data()
        BlendDataTemp.kill()
        #|

    def upd_size_areas(self):
        # <<< 1copy (0ed_MeshEditor_init,, $$)
        PP = self.P_editor
        border_outer = SIZE_border[0]
        border_inner = SIZE_border[1]
        widget_rim = SIZE_border[3]
        d0 = SIZE_dd_border[0]
        d1 = SIZE_dd_border[1]
        widget_full_h = D_SIZE['widget_full_h']
        d0x2h = d0 + d0 + widget_full_h
        LL = self.box_win.L + border_outer
        TT = self.box_win.title_B - border_outer
        width_min = 6 * widget_full_h

        RR = LL + round(2.612 * D_SIZE['widget_width'] * PP.area_widthfac)
        B0 = TT - AreaBlock.calc_height_by_block_len(1)
        T0 = B0 - d1
        BB = T0 - round(2.79 * D_SIZE['widget_width'] * PP.area_heightfac)
        # >>>
        self.area_head.upd_size(LL, RR, B0, TT)
        self.area_tab.upd_size(LL, RR, BB, T0)
        #|

    def upd_data(self):
        ob = bpy.context.object
        if hasattr(ob, "mode") and ob.mode == "EDIT":
            if self.area_tab.active_tab != ("MAIN",):
                self.area_tab.init_tab(("MAIN",))
        else:
            if self.area_tab.active_tab != ("NONE",):
                self.area_tab.init_tab(("NONE",))

        self.area_head.upd_data()
        self.area_tab.upd_data()
        #|
    #|
    #|


class AreaBlockTabMeshEditor(AreaBlockTab):
    __slots__ = (
        'upd_data_callback',
        'bm_data',
        'props')

    def init_tab_NONE(self):
        self.items[:] = [BlockFull(self, ButtonGroupTitle(None, "Requires Edit Mesh"))]
        #|
    def init_tab_MAIN(self):
        layout = Layout(self)
        layout.set_fold_state(P.MeshEditor.is_fold)
        props = self.props
        rnas = RNAS_mesh
        option = {
            "r_local_space": lambda: self.w.local_space == "LOCAL"
        }

        l0 = layout.new_block()
        g_distance = l0.prop(props, rnas["distance"], set_callback=callback_distance, option=option, append=False)
        g_direction = l0.prop(props, rnas["direction"], set_callback=callback_direction, option=option, append=False)
        l01 = l0.new_block([g_distance, g_direction])
        g_distance_invert = l01.prop(props, rnas["vert_invert"], align="R", use_push=False)
        l01.sep()
        g_u_direction = l01.prop(props, rnas["u_direction"], set_callback=callback_u_direction, option=option)

        g_normal = l0.prop(props, rnas["normal"], set_callback=callback_normal, option=option, append=False)
        l02 = l0.new_block([g_normal])
        g_keep_normals_to_other_faces = l02.prop(props, rnas["keep_normals_to_other_faces"], use_push=False)
        g_lock_active_vertex = l02.prop(props, rnas["lock_active_vertex"], align="R", use_push=False)

        g_limit = l0.prop(self.bufn_limit, rnas["vert_limit"], title="", align="HL", use_push=False, append=False)
        l03 = l0.new_block([g_limit])
        g_collinear = l03.prop(self.bufn_collinear, rnas["make_collinear"], align="LC", use_push=True)
        g_coplanar = l03.prop(self.bufn_coplanar, rnas["make_coplanar"], align="LC", use_push=True)
        l03.sep(1.5)
        g_lock_active_vertex_collinear = l03.prop(props, rnas["lock_active_vertex_collinear"], align="R", use_push=False)
        l03.sep(1.5)
        g_area = l03.prop(props, rnas["area"], set_callback=callback_area, option=option)
        g_angle = l03.prop(props, rnas["angle"], set_callback=callback_angle, option=option)


        def upd_data_callback():
            ob = bpy.context.object
            if hasattr(ob, "mode") and ob.mode == "EDIT":
                bm_data = r_bm_data(bpy.context)
                self.bm_data = bm_data

                if bm_data["total_vert_sel"] == 2:
                    if g_distance.is_dark() is True:
                        g_distance.light()
                        g_direction.light()
                        g_u_direction.light()
                        g_distance_invert.light()

                    if g_normal.is_dark() is False:
                        g_normal.dark()
                        g_keep_normals_to_other_faces.dark()
                        g_lock_active_vertex.dark()
                    if g_collinear.is_dark() is False:
                        g_collinear.dark()
                        g_collinear.blf_title.text = ""
                        g_coplanar.dark()
                        g_coplanar.blf_title.text = ""
                        g_lock_active_vertex_collinear.dark()
                    if g_area.is_dark() is False:
                        g_area.dark()

                    try: act = bm_data["bms"][ob].bm.select_history.active
                    except: act = None

                    v0, v1 = bm_data["verts"]
                    if act is v1: v0, v1 = v1, v0
                    if props.vert_invert: v0, v1 = v1, v0

                    if self.w.local_space == "LOCAL":
                        vec = v0.co - v1.co
                        props.direction[:] = vec
                        props.u_direction[:] = vec.normalized()
                        props.distance = vec.length
                    else:
                        bm_dic = bm_data["bm_dic"]
                        vec = (bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)
                        props.direction[:] = vec
                        props.u_direction[:] = vec.normalized()
                        props.distance = vec.length
                else:
                    if g_distance.is_dark() is False:
                        g_distance.dark()
                        g_direction.dark()
                        g_u_direction.dark()
                        g_distance_invert.dark()

                    inlimit = bm_data["total_vert_sel"] <= P.MeshEditor.vert_limit
                    local_space = self.w.local_space == "LOCAL"

                    if bm_data["total_vert_sel"] >= 3 and inlimit:
                        if g_normal.is_dark() is True:
                            g_normal.light()
                            g_lock_active_vertex.light()
                        if g_collinear.is_dark() is True:
                            g_collinear.light()
                            g_coplanar.light()
                            g_lock_active_vertex_collinear.light()

                        if bm_data["total_face_sel"] == 1 and bm_data["total_vert_sel"] == len(bm_data["faces"][0].verts):
                            if g_keep_normals_to_other_faces.is_dark() is True:
                                g_keep_normals_to_other_faces.light()

                            plane = bm_data["faces"][0]
                            if local_space is True:
                                props.normal[:] = normal(loop.vert.co  for loop in plane.loops)
                            else:
                                mat = bm_data["bm_dic"][plane].matrix_world
                                props.normal[:] = normal(mat @ loop.vert.co  for loop in plane.loops)
                        else:
                            if g_keep_normals_to_other_faces.is_dark() is False:
                                g_keep_normals_to_other_faces.dark()

                            if local_space is True:
                                props.normal[:] = normal(v.co  for v in bm_data["verts"])
                            else:
                                bm_dic = bm_data["bm_dic"]
                                props.normal[:] = normal(bm_dic[v].matrix_world @ v.co  for v in bm_data["verts"])

                        vecs = bm_data["verts"][ : -1]
                        if local_space is True:
                            v_co = bm_data["verts"][-1].co
                            vecs = [v.co - v_co  for v in vecs]
                        else:
                            bm_dic = bm_data["bm_dic"]
                            v = bm_data["verts"][-1]
                            v_co = bm_dic[v].matrix_world @ v.co
                            vecs = [bm_dic[v].matrix_world @ v.co - v_co  for v in vecs]
                        th = bin_search_continue(lambda v: matrix_rank(vecs, v) < 2, 0, 1000)
                        g_collinear.blf_title.text = f"Collinear Threshold :  {'> 1000'  if th is None else '{:.6f}'.format(th)}"
                        th = bin_search_continue(lambda v: matrix_rank(vecs, v) < 3, 0, 1000)
                        g_coplanar.blf_title.text = f"Coplanar Threshold :  {'> 1000'  if th is None else '{:.6f}'.format(th)}"

                        if bm_data["total_vert_sel"] == 3:
                            if g_angle.is_dark() is True:
                                g_angle.light()

                            v0, v1, v2 = r_3vert_angle(bm_data)
                            if local_space is True:
                                props.angle = r_angle(v0.co, v1.co, v2.co)
                            else:
                                bm_dic = bm_data["bm_dic"]
                                props.angle = r_angle(
                                    bm_dic[v0].matrix_world @ v0.co,
                                    bm_dic[v1].matrix_world @ v1.co,
                                    bm_dic[v2].matrix_world @ v2.co)
                        else:
                            if g_angle.is_dark() is False:
                                g_angle.dark()
                    else:
                        if g_normal.is_dark() is False:
                            g_normal.dark()
                            g_keep_normals_to_other_faces.dark()
                            g_lock_active_vertex.dark()
                        if g_collinear.is_dark() is False:
                            g_collinear.dark()
                            g_collinear.blf_title.text = ""
                            g_coplanar.dark()
                            g_coplanar.blf_title.text = ""
                            g_lock_active_vertex_collinear.dark()
                        if g_angle.is_dark() is False:
                            g_angle.dark()

                    if bm_data["total_face_sel"] >= 1 and inlimit:
                        if g_area.is_dark() is True:
                            g_area.light()

                        if local_space is True:
                            props.area = sum(face.calc_area()  for face in bm_data["faces"])
                        else:
                            props.area = r_faces_area(bm_data["faces"], bm_data["bm_dic"])
                    else:
                        if g_area.is_dark() is False:
                            g_area.dark()

                for e in self.items: e.upd_data()
            else:
                self.items.clear()

        self.upd_data_callback = upd_data_callback
        #|

    def bufn_limit(self):

        D_EDITOR["SettingEditor"].open_search("vert_limit", true_ids={"id", "editor"})
        #|
    def bufn_collinear(self):

        make_collinear(r_bm_data(bpy.context), self.props.lock_active_vertex_collinear)
        #|
    def bufn_coplanar(self):

        make_coplanar(r_bm_data(bpy.context), self.props.lock_active_vertex_collinear)
        #|

    def upd_data(self):
        if hasattr(self, "upd_data_callback"): self.upd_data_callback()
        #|
    #|
    #|



## _import_lv2_standard_ ##
def _import_lv2_standard_():
    #|
    from . ops import (
        r_bm_data,
        r_3vert_angle,
        make_collinear,
        make_coplanar,
    )
    from . prop import (
        RNAS_mesh,
        callback_distance,
        callback_direction,
        callback_u_direction,
        callback_normal,
        callback_area,
        callback_angle,
    )

    from ... block import (
        Layout,
        poll_hard_disable,
        Title,
        BlockR,
        BlockFull,
        ButtonEnumXY,
        ButtonGroup,
        ButtonGroupTitle,
        EdFloat,
    )
    from ... m import (
        P,
        Admin,
        BlendDataTemp,
    )
    from ... rna import (
        RNA_local_space,
        r_props_by_rnas,
    )
    from ... userops import D_EDITOR

    from ... util.com import bin_search_continue

    from ... utilbl.blg import (
        GpuRim,
        GpuBox_area,
        FONT0,
        D_SIZE,
        SIZE_border,
        SIZE_dd_border,
    )
    from ... utilbl.mesh import r_faces_area, r_angle

    globals().update(locals())
    #|
