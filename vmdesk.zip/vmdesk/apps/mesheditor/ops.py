import bpy

from bpy.props import (
    StringProperty,
    EnumProperty,
    BoolProperty,
    IntVectorProperty,
    FloatVectorProperty,
    FloatProperty)
from mathutils import Vector
from mathutils.geometry import normal, intersect_line_plane, area_tri
from bmesh import from_edit_mesh
from math import pi, tau, sqrt

from ... userops import PollEditMesh, Bmesh


def r_bm_data(context):
    bms = {}
    bm_dic = {}
    total_vert_sel = 0
    total_edge_sel = 0
    total_face_sel = 0

    for ob in context.objects_in_mode:
        ob_data = ob.data
        total_vert_sel += ob_data.total_vert_sel
        total_edge_sel += ob_data.total_edge_sel
        total_face_sel += ob_data.total_face_sel

        bm = from_edit_mesh(ob_data)
        verts_sel = [e  for e in bm.verts if e.select]
        edges_sel = [e  for e in bm.edges if e.select]
        faces_sel = [e  for e in bm.faces if e.select]
        bms[ob] = Bmesh(bm, verts_sel, edges_sel, faces_sel)
        bm_dic.update({e: ob  for e in verts_sel})
        bm_dic.update({e: ob  for e in edges_sel})
        bm_dic.update({e: ob  for e in faces_sel})

    verts = []
    edges = []
    faces = []
    for b in bms.values():
        verts += b.verts_sel
        edges += b.edges_sel
        faces += b.faces_sel

    return {
        "bms": bms,
        "bm_dic": bm_dic,
        "total_vert_sel": total_vert_sel,
        "total_edge_sel": total_edge_sel,
        "total_face_sel": total_face_sel,
        "verts": verts,
        "edges": edges,
        "faces": faces,
    }
    #|

def set_face_or_vert3_normal(bm_data, ftd, new_normal,
                    local_space, keep_normals_to_other_faces, lock_active_vertex):

    if ftd["keep_normals_message"] == "" and keep_normals_to_other_faces:
        if local_space:
            old_origin = ftd["old_act_local"]  if lock_active_vertex else ftd["old_origin_local"]
            old_line0 = ftd["old_line0_local"]
            old_line1 = ftd["old_line1_keep_normal_local"]
        else:
            old_origin = ftd["old_act_global"]  if lock_active_vertex else ftd["old_origin_global"]
            old_line0 = ftd["old_line0_global"]
            old_line1 = ftd["old_line1_keep_normal_global"]
    else:
        if local_space:
            old_origin = ftd["old_act_local"]  if lock_active_vertex else ftd["old_origin_local"]
            old_line0 = ftd["old_line0_local"]
            old_line1 = ftd["old_line1_local"]
        else:
            old_origin = ftd["old_act_global"]  if lock_active_vertex else ftd["old_origin_global"]
            old_line0 = ftd["old_line0_global"]
            old_line1 = ftd["old_line1_global"]

    if ftd["method"] == "FACE":
        success, message = set_face_normal(
            bm_data,
            bm_data["faces"][0],
            old_origin,
            old_line0,
            old_line1,
            new_normal,
            local_space)
    else:
        success, message = set_verts_normal(
            bm_data,
            bm_data["verts"],
            old_origin,
            old_line0,
            old_line1,
            new_normal,
            local_space)

    if keep_normals_to_other_faces and not message:
        if ftd["keep_normals_message"] != "":
            message = f'Keep Normals skipped: {ftd["keep_normals_message"]}'
    return success, message
    #|
def set_face_normal(bm_data, plane, old_origin, old_line0, old_line1, new_normal, local_space):
    ob = bm_data["bm_dic"][plane]
    new_pos = []

    for line0, line1 in zip(old_line0, old_line1):
        pos = intersect_line_plane(line0, line1, old_origin, new_normal)
        if pos is None:
            return True, "The linked face of the selected face has the same normal as the selected face, abort."
        new_pos.append(pos)


    if local_space:
        for vert, pos in zip(plane.verts, new_pos): vert.co[:] = pos
    else:
        imat = ob.matrix_world.inverted_safe()
        for vert, pos in zip(plane.verts, new_pos): vert.co[:] = imat @ pos

    ob.data.update()
    return True, ""
    #|
def set_verts_normal(bm_data, verts, old_origin, old_line0, old_line1, new_normal, local_space):
    bm_dic = bm_data["bm_dic"]
    new_pos = []

    for line0, line1 in zip(old_line0, old_line1):
        pos = intersect_line_plane(line0, line1, old_origin, new_normal)
        if pos is None:
            return True, "The linked face of the selected face has the same normal as the selected face, abort."
        new_pos.append(pos)


    if local_space:
        for vert, pos in zip(verts, new_pos): vert.co[:] = pos
    else:
        imat = bm_data["bm_dic"][verts[0]].matrix_world.inverted_safe()
        for vert, pos in zip(verts, new_pos):
            vert.co[:] = (bm_dic[vert].matrix_world.inverted_safe()) @ pos

    for ob in bm_data["bms"]:
        ob.data.update()
    return True, ""
    #|

def set_distance(bm_data, v0, v1, distance, u_vec_glo, u_vec, local_space=False, invert=False):
    bm_dic = bm_data["bm_dic"]
    if invert:
        v0, v1 = v1, v0
        u_vec_glo = - u_vec_glo
        u_vec = - u_vec

    if local_space:
        v0.co[:] = v1.co + u_vec * distance
    else:
        new_loc = bm_dic[v1].matrix_world @ v1.co + u_vec_glo * distance
        v0.co[:] = bm_dic[v0].matrix_world.inverted_safe() @ new_loc

    ob0 = bm_dic[v0]
    ob1 = bm_dic[v1]
    if ob0 is ob1: ob0.data.update()
    else:
        ob0.data.update()
        ob1.data.update()
    #|

def set_direction(bm_data, v0, v1, vec3, local_space=False, invert=False):
    vec3 = Vector(vec3)
    bm_dic = bm_data["bm_dic"]
    if invert:
        v0, v1 = v1, v0
        vec3 = - vec3

    if local_space:
        v0.co[:] = v1.co + vec3
    else:
        new_loc = bm_dic[v1].matrix_world @ v1.co + vec3
        v0.co[:] = bm_dic[v0].matrix_world.inverted_safe() @ new_loc

    bm_dic[v0].data.update()
    #|

def is_single_line(bm_data):
    return bm_data["total_vert_sel"] == bm_data["total_edge_sel"] + 1
    #|

def r_3vert_by_2edge_connect(e0, e1):
    v0, v1 = e0.verts
    v2, v3 = e1.verts
    if v2 is v0: return v1, v0, v3
    if v2 is v1: return v0, v1, v3
    if v3 is v0: return v1, v0, v2
    return v0, v1, v2
    #|
def r_3vert_angle(bm_data): # total_vert_sel == 3
    ob = bpy.context.object
    try: act = bm_data["bms"][ob].bm.select_history.active
    except: act = None

    if bm_data["total_edge_sel"] == 2:
        edge0, edge1 = bm_data["edges"]
        if act is edge0: edge0, edge1 = edge1, edge0

        v0, v1, v2 = r_3vert_by_2edge_connect(edge0, edge1)
    else:
        v0, v1, v2 = bm_data["verts"]
        try: v_center = bm_data["bms"][ob].bm.select_history[-2]
        except: v_center = None

        if v_center is v0: v1, v0 = v0, v1
        elif v_center is v2: v1, v2 = v2, v1

    if act is v0: v0, v2 = v2, v0
    return v0, v1, v2
    #|

def make_collinear(bm_data, lock_active_vertex=False):
    bm_dic = bm_data["bm_dic"]
    verts = bm_data["verts"]
    verts_co = [bm_dic[v].matrix_world @ v.co  for v in verts]

    if is_single_line(bm_data):
        i0, i1 = r_outer_2vert_by_single_line(verts, bm_data["edges"])
        i0 = verts.index(i0)
        i1 = verts.index(i1)
    else:
        i0, i1 = r_outer_2vert_by_direction(verts_co, r_average_direction(verts_co))

    v0 = verts[i0]
    v1 = verts[i1]
    u_vec = (verts_co[i0] - verts_co[i1]).normalized()

    rot = u_vec.rotation_difference(VEC_00M1)
    rot_inv = rot.inverted()
    pos = rot @ verts_co[i0]
    x, y = pos[0 : 2]

    inv_matrix_dic = {ob: ob.matrix_world.inverted_safe()  for ob in bm_data["bms"]}

    act = None
    if lock_active_vertex:
        try: act = bm_data["bms"][bpy.context.object].bm.select_history.active
        except: pass
        if act not in verts: act = None

    if act is None:
        for v_co, v in zip(verts_co, verts):
            pos = rot @ v_co
            pos[0] = x
            pos[1] = y
            v.co[:] = inv_matrix_dic[bm_dic[v]] @ (rot_inv @ pos)
    else:
        old_pos = bm_dic[act].matrix_world @ act.co
        pos = rot @ old_pos
        pos[0] = x
        pos[1] = y
        pos = rot_inv @ pos
        offset = old_pos - pos

        for v_co, v in zip(verts_co, verts):
            pos = rot @ v_co
            pos[0] = x
            pos[1] = y
            pos = rot_inv @ pos
            v.co[:] = inv_matrix_dic[bm_dic[v]] @ (pos + offset)

    for ob in inv_matrix_dic: ob.data.update()
    #|

def make_coplanar(bm_data, lock_active_vertex=False):
    ftd = OpsSetNormal.r_first_time_data(bm_data)
    if ftd["method"] == "NONE": return

    set_face_or_vert3_normal(
        bm_data,
        ftd,
        ftd["old_normal_global"],
        False,
        True,
        lock_active_vertex)
    #|

def set_angle(bm_data, v0, v1, v2, angle, local_space=False, invert=False, lock_active_vertex=None):
    if invert: v0, v2 = v2, v0

    bm_dic = bm_data["bm_dic"]
    if local_space:
        verts = [v.co  for v in (v0, v1, v2)]
    else:
        verts = [bm_dic[v].matrix_world @ v.co  for v in (v0, v1, v2)]
    org_co_glo = verts

    u_pos = (verts[0] - verts[1]).normalized()
    length = (verts[1] - verts[2]).length
    u_nor = normal(verts)
    if u_nor == Vector(): u_nor = Vector((0.0, 0.0, 1.0))

    u_vec0, u_vec1 = r_u_pos_by_angle(u_pos, u_nor, angle)
    pos0 = length * u_vec0 + org_co_glo[1]
    pos1 = length * u_vec1 + org_co_glo[1]
    an_0 = r_angle(org_co_glo[2], org_co_glo[1], pos0)
    an_1 = r_angle(org_co_glo[2], org_co_glo[1], pos1)

    if angle % tau < pi:   new_pos = pos0 if an_0 < an_1 else pos1
    else:              new_pos = pos1 if an_0 < an_1 else pos0

    if local_space == False: new_pos = bm_dic[v2].matrix_world.inverted_safe() @ new_pos

    if lock_active_vertex is v2:
        offset = v2.co - new_pos
        new_pos += offset
        v0.co +=  offset
        v1.co += offset
    else:
        v2.co[:] = new_pos

    obs = {bm_dic[v0], bm_dic[v1], bm_dic[v2]}
    for ob in obs: ob.data.update()
    #|

def set_face_area(bm_data, ftd, tot_area, local_space=False, lock_active_vertex=False):
    bm_dic = bm_data["bm_dic"]
    verts = sum(([v for v in face.verts]  for face in bm_data["faces"]), [])

    if local_space:
        fac = sqrt(tot_area / ftd["old_area_local"])

        if lock_active_vertex:
            center = ftd["center_act_local"]
            for v, vec in zip(verts, ftd["vecs_act_local"]):
                v.co[:] = fac * vec + center
        else:
            center = ftd["center_local"]
            for v, vec in zip(verts, ftd["vecs_local"]):
                v.co[:] = fac * vec + center
    else:
        fac = sqrt(tot_area / ftd["old_area_global"])
        inv_matrix_dic = {ob: ob.matrix_world.inverted_safe()  for ob in bm_data["bms"]}

        if lock_active_vertex:
            center = ftd["center_act_global"]
            for v, vec in zip(verts, ftd["vecs_act_global"]):
                v.co[:] = inv_matrix_dic[bm_dic[v]] @ (fac * vec + center)
        else:
            center = ftd["center_global"]
            for v, vec in zip(verts, ftd["vecs_global"]):
                v.co[:] = inv_matrix_dic[bm_dic[v]] @ (fac * vec + center)

    for ob in bm_data["bms"]: ob.data.update()
    #|



class OpsSetDistance(PollEditMesh):
    __slots__ = 'is_first_time', 'u_vec_glo', 'u_vec'

    bl_idname = "mesh.vmd_vert_distance"
    bl_label = "VMD Set Vertex Distance"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Set distance between 2 vertices"

    distance: FloatProperty(
        name = "Distance",
        description = "Distance between 2 vertices",
        subtype = "DISTANCE")
    local_space: BoolProperty(
        name = "Local Space",
        description = "",
        default = False)
    invert: BoolProperty(
        name = "Invert",
        description = "Move another vertex",
        default = False)

    def __init__(self): self.is_first_time = True

    def execute(self, context):
        bm_data = r_bm_data(context)
        if bm_data["total_vert_sel"] != 2:
            self.report({"WARNING"}, "Need to select only 2 vertices")
            return {'CANCELLED'}

        try: act = bm_data["bms"][context.object].bm.select_history.active
        except: act = None

        v0, v1 = bm_data["verts"]
        if act is v1: v0, v1 = v1, v0

        if self.is_first_time is True:
            self.is_first_time = False
            is_first_time = True

            bm_dic = bm_data["bm_dic"]

            vec_glo = (bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)
            vec = v0.co - v1.co
            self.u_vec_glo = vec_glo.normalized()
            self.u_vec = vec.normalized()

            self.distance = vec.length  if self.local_space else vec_glo.length
        else:
            is_first_time = False

        set_distance(bm_data, v0, v1, self.distance, self.u_vec_glo, self.u_vec, self.local_space, self.invert)

        for bm in bm_data["bms"].values(): bm.bm.free()
        return {'FINISHED'}
        #|
    #|
    #|

class OpsSetDirection(PollEditMesh):
    __slots__ = 'is_first_time'

    bl_idname = "mesh.vmd_vert_direction"
    bl_label = "VMD Set Vertex Direction"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Set direction of 2 vertices"

    direction: FloatVectorProperty(
        name = "Direction",
        description = "Direction of 2 vertices",
        subtype = "TRANSLATION")
    local_space: BoolProperty(
        name = "Local Space",
        description = "",
        default = False)
    invert: BoolProperty(
        name = "Invert",
        description = "Move another vertex",
        default = False)

    def __init__(self): self.is_first_time = True

    def execute(self, context):
        bm_data = r_bm_data(context)
        if bm_data["total_vert_sel"] != 2:
            self.report({"WARNING"}, "Need to select only 2 vertices")
            return {'CANCELLED'}

        try: act = bm_data["bms"][context.object].bm.select_history.active
        except: act = None

        v0, v1 = bm_data["verts"]
        if act is v1: v0, v1 = v1, v0

        if self.is_first_time is True:
            self.is_first_time = False
            is_first_time = True

            bm_dic = bm_data["bm_dic"]

            vec_glo = (bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)
            vec = v0.co - v1.co

            self.direction = vec  if self.local_space else vec_glo
        else:
            is_first_time = False

        set_direction(bm_data, v0, v1, self.direction, self.local_space, self.invert)

        for bm in bm_data["bms"].values(): bm.bm.free()
        return {'FINISHED'}
        #|
    #|
    #|

class OpsSetNormal(PollEditMesh):
    __slots__ = 'first_time_data'

    bl_idname = "mesh.vmd_normal"
    bl_label = "VMD Set Normal"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Set normal"

    normal: FloatVectorProperty(
        name = "Normal",
        description = "",
        size = 3,
        subtype = "TRANSLATION")
    local_space: BoolProperty(
        name = "Local Space",
        description = "",
        default = False)
    keep_normals_to_other_faces: BoolProperty(
        name = "Keep Normals to Other Faces",
        description = "Keep normals of unselected faces if possible",
        default = True)
    lock_active_vertex: BoolProperty(
        name = "Lock Active Vertex",
        description = "Keep active vertex location",
        default = False)

    @staticmethod
    def r_first_time_data(bm_data):
        if bm_data["total_face_sel"] == 1 and bm_data["total_vert_sel"] == len(bm_data["faces"][0].verts):
            plane = bm_data["faces"][0]
            ob = bm_data["bm_dic"][plane]
            mat = ob.matrix_world

            old_normal_local = normal(loop.vert.co  for loop in plane.loops)
            old_normal_global = normal(mat @ loop.vert.co  for loop in plane.loops)

            bmtemp, face = r_bmface_copy(plane)
            for v in face.verts: v.co[:] = mat @ v.co
            old_origin_global = face.calc_center_median()
            old_origin_local = plane.calc_center_median()

            old_line0_global = [v.co.copy()  for v in face.verts]
            old_line0_local = [v.co.copy()  for v in plane.verts]
            old_line1_global = [v + old_normal_global  for v in old_line0_global]
            old_line1_local = [v + old_normal_local  for v in old_line0_local]
            bmtemp.free()

            act_vert = None
            try: act_vert = bm_data["bms"][ob].bm.select_history.active
            except: pass
            if act_vert not in plane.verts: act_vert = None
            if act_vert is None:
                old_act_local = old_origin_local
                old_act_global = old_origin_global
            else:
                old_act_local = act_vert.co.copy()
                old_act_global = mat @ act_vert.co

            method = "FACE"
            old_line1_keep_normal_global = []
            old_line1_keep_normal_local = []

            def r_keep_normals_message():
                plane_edges = plane.edges
                lines = {}

                for vert in plane.verts:
                    ll_faces = len(vert.link_faces)

                    if ll_faces == 1:   continue
                    if ll_faces > 3:
                        return "Some vertices in selected face have more than 3 linked faces"

                    if ll_faces == 2:
                        faces = vert.link_faces
                        face = faces[1 if faces[0] is plane else 0]
                        plane_edges = plane.edges
                        share_edge = set(plane_edges).intersection(face.edges)
                        if len(share_edge) != 1:
                            return "2 of the linked faces of the vertices in the selected face have no or more than one shared edge"

                        share_edge, = share_edge
                        v0, v1 = share_edge.verts

                        for edge in face.edges:
                            if edge == share_edge: continue
                            if v0 in edge.verts:
                                lines[v0] = edge
                            elif v1 in edge.verts:
                                lines[v1] = edge

                    elif ll_faces == 3:
                        faces = vert.link_faces
                        if faces[0] == plane:
                            face1 = faces[1]
                            face2 = faces[2]
                        elif faces[1] == plane:
                            face1 = faces[0]
                            face2 = faces[2]
                        else:
                            face1 = faces[0]
                            face2 = faces[1]

                        check_connect_plane = False
                        check_connect_other = False

                        for e in face1.edges:
                            if plane in e.link_faces:
                                check_connect_plane = True
                            elif face2 in e.link_faces:
                                check_connect_other = True
                                line = e

                        if check_connect_plane is False or check_connect_other is False:
                            return "The 3 linked faces of a vertice in the selected face are not connected, abort."

                        lines[vert] = line

                for i, vert in enumerate(plane.verts):
                    if vert in lines:
                        line = lines[vert]
                        if vert is line.verts[0]: v0, v1 = line.verts
                        else: v1, v0 = line.verts

                        old_line1_keep_normal_local.append(v1.co.copy())
                        old_line1_keep_normal_global.append(mat @ v1.co)
                    else:
                        old_line1_keep_normal_local.append(old_line1_local[i])
                        old_line1_keep_normal_global.append(old_line1_global[i])

                return ""
        else:
            if bm_data["total_vert_sel"] < 3: return {'method': "NONE"}

            verts = bm_data["verts"]
            bm_dic = bm_data["bm_dic"]

            old_normal_local = normal(v.co  for v in verts)
            old_normal_global = normal(bm_dic[v].matrix_world @ v.co  for v in verts)

            old_line0_local = [v.co.copy()  for v in verts]
            bmtemp, face = r_bmface_new(old_line0_local)
            old_origin_local = face.calc_center_median()
            old_line1_local = [v + old_normal_local  for v in old_line0_local]
            bmtemp.free()

            old_line0_global = [bm_dic[v].matrix_world @ v.co  for v in verts]
            bmtemp, face = r_bmface_new(old_line0_global)
            old_origin_global = face.calc_center_median()
            old_line1_global = [v + old_normal_global  for v in old_line0_global]
            bmtemp.free()

            act_vert = None
            try: act_vert = bm_data["bms"][bm_dic[verts[0]]].bm.select_history.active
            except: pass
            if act_vert not in verts: act_vert = None
            if act_vert is None:
                old_act_local = old_origin_local
                old_act_global = old_origin_global
            else:
                old_act_local = act_vert.co.copy()
                old_act_global = bm_dic[act_vert].matrix_world @ act_vert.co

            method = "VERT3"
            old_line1_keep_normal_global = []
            old_line1_keep_normal_local = []

            def r_keep_normals_message(): return "Available when selecting a face"

        return {
            'old_normal_local': old_normal_local,
            'old_normal_global': old_normal_global,
            'old_line0_local': old_line0_local,
            'old_line0_global': old_line0_global,
            'old_line1_local': old_line1_local,
            'old_line1_global': old_line1_global,
            'old_origin_local': old_origin_local,
            'old_origin_global': old_origin_global,
            'old_act_local': old_act_local,
            'old_act_global': old_act_global,
            'method': method,
            'keep_normals_message': r_keep_normals_message(),
            'old_line1_keep_normal_global': old_line1_keep_normal_global,
            'old_line1_keep_normal_local': old_line1_keep_normal_local,
        }
        #|

    def __init__(self): self.first_time_data = None

    def execute(self, context):
        bm_data = r_bm_data(context)

        def fin(success, message):
            if success:
                if message: self.report({"INFO"}, message)
                for bm in bm_data["bms"].values(): bm.bm.free()
                return {'FINISHED'}
            else:
                if message: self.report({"WARNING"}, message)
                for bm in bm_data["bms"].values(): bm.bm.free()
                return {'CANCELLED'}

        if self.first_time_data is None:
            ftd = self.r_first_time_data(bm_data)
            self.first_time_data = ftd

            if ftd["method"] == "NONE":
                success = False
                message = "Need select 1 face or 3 vertices, abort"
                return fin(success, message)
            if ftd["method"] == "VERT3": self.keep_normals_to_other_faces = False

            self.normal[:] = ftd["old_normal_local"  if self.local_space else "old_normal_global"]
            return fin(True, "")

        ftd = self.first_time_data
        if ftd["method"] == "NONE":
            success = False
            message = "Need select 1 face or 3 vertices, abort"
        else:
            success, message = set_face_or_vert3_normal(
                bm_data,
                ftd,
                self.normal,
                self.local_space,
                self.keep_normals_to_other_faces,
                self.lock_active_vertex)

        return fin(success, message)
        #|
    #|
    #|

class OpsCollinear(PollEditMesh):
    __slots__ = ()

    bl_idname = "mesh.vmd_collinear"
    bl_label = "VMD Collinear"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Make Collinear"

    lock_active_vertex: BoolProperty(
        name = "Lock Active Vertex",
        description = "Keep active vertex location",
        default = False)

    def execute(self, context):
        bm_data = r_bm_data(context)
        total_vert_sel = bm_data["total_vert_sel"]
        if total_vert_sel <= 2: return {'CANCELLED'}

        make_collinear(bm_data, lock_active_vertex=self.lock_active_vertex)

        for bm in bm_data["bms"].values(): bm.bm.free()
        return {'FINISHED'}
        #|
    #|
    #|

class OpsCoplanar(PollEditMesh):
    __slots__ = ()

    bl_idname = "mesh.vmd_coplanar"
    bl_label = "VMD Coplanar"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Make Coplanar"

    lock_active_vertex: BoolProperty(
        name = "Lock Active Vertex",
        description = "Keep active vertex location",
        default = False)

    def execute(self, context):
        bm_data = r_bm_data(context)
        total_vert_sel = bm_data["total_vert_sel"]
        if total_vert_sel <= 3: return {'CANCELLED'}

        make_coplanar(bm_data, self.lock_active_vertex)

        for bm in bm_data["bms"].values(): bm.bm.free()
        return {'FINISHED'}
        #|
    #|
    #|

class OpsSetAngle(PollEditMesh):
    __slots__ = 'is_first_time'

    bl_idname = "mesh.vmd_angle"
    bl_label = "VMD Set Angle"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Set included angle"

    angle: FloatProperty(
        name = "Angle",
        description = "Included angle",
        subtype = "ANGLE")
    local_space: BoolProperty(
        name = "Local Space",
        description = "",
        default = False)
    invert: BoolProperty(
        name = "Invert",
        description = "Move another vertex",
        default = False)
    lock_active_vertex: BoolProperty(
        name = "Lock Active Vertex",
        description = "Keep active vertex location",
        default = False)

    def __init__(self): self.is_first_time = True

    def execute(self, context):
        bm_data = r_bm_data(context)
        if bm_data["total_vert_sel"] != 3:
            self.report({"WARNING"}, "3 vertices need to be selected")
            return {'CANCELLED'}

        v0, v1, v2 = r_3vert_angle(bm_data)

        if self.is_first_time is True:
            self.is_first_time = False
            if self.local_space:
                self.angle = r_angle(v0.co, v1.co, v2.co)
            else:
                bm_dic = bm_data["bm_dic"]
                self.angle = r_angle(
                    bm_dic[v0].matrix_world @ v0.co,
                    bm_dic[v1].matrix_world @ v1.co,
                    bm_dic[v2].matrix_world @ v2.co)

        try: act = bm_data["bms"][context.object].bm.select_history.active
        except: act = None
        lock_active_vertex = act  if self.lock_active_vertex else None

        set_angle(bm_data, v0, v1, v2, self.angle, self.local_space, self.invert, lock_active_vertex)

        for bm in bm_data["bms"].values(): bm.bm.free()
        return {'FINISHED'}
        #|
    #|
    #|

class OpsSetArea(PollEditMesh):
    __slots__ = 'first_time_data'

    bl_idname = "mesh.vmd_area"
    bl_label = "VMD Set Area"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Set face area"

    tot_area: FloatProperty(
        name = "Area",
        description = "Total area",
        unit = "AREA",
        min = 0.0,
        precision=6)
    local_space: BoolProperty(
        name = "Local Space",
        description = "",
        default = False)
    lock_active_vertex: BoolProperty(
        name = "Lock Active Vertex",
        description = "Keep active vertex location",
        default = False)

    @staticmethod
    def r_first_time_data(bm_data):
        bm_dic = bm_data["bm_dic"]
        faces = bm_data["faces"]
        face_verts = sum(([v for v in face.verts]  for face in faces), [])
        face_verts_global_co = [bm_dic[v].matrix_world @ v.co  for v in face_verts]

        center_local = r_median([v.co  for v in face_verts])
        center_global = r_median(face_verts_global_co)

        vecs_local = [v.co - center_local  for v in face_verts]
        vecs_global = [co - center_global  for co in face_verts_global_co]

        old_area_local = sum(face.calc_area()  for face in faces)
        old_area_global = r_faces_area(faces, bm_dic)

        act_vert = None
        try: act_vert = bm_data["bms"][bpy.context.object].bm.select_history.active
        except: pass
        if act_vert not in face_verts: act_vert = None
        if act_vert is None:
            center_act_local = center_local
            center_act_global = center_global
            vecs_act_local = vecs_local
            vecs_act_global = vecs_global
        else:
            center_act_local = act_vert.co.copy()
            center_act_global = bm_dic[act_vert].matrix_world @ act_vert.co
            vecs_act_local = [v.co - center_act_local  for v in face_verts]
            vecs_act_global = [co - center_act_global  for co in face_verts_global_co]

        return {
            'center_local': center_local,
            'center_global': center_global,
            'center_act_local': center_act_local,
            'center_act_global': center_act_global,
            'vecs_local': vecs_local,
            'vecs_global': vecs_global,
            'vecs_act_local': vecs_act_local,
            'vecs_act_global': vecs_act_global,
            'old_area_local': old_area_local,
            'old_area_global': old_area_global,
        }
        #|

    def __init__(self): self.first_time_data = None

    def execute(self, context):
        bm_data = r_bm_data(context)
        if bm_data["total_face_sel"] < 1:
            self.report({"WARNING"}, "Need to select at least 1 face")
            return {'CANCELLED'}

        if self.first_time_data is None:
            ftd = self.r_first_time_data(bm_data)
            self.first_time_data = ftd
            self.tot_area = ftd["old_area_local"  if self.local_space else "old_area_global"]
        else:
            try:
                set_face_area(
                    bm_data,
                    self.first_time_data,
                    self.tot_area,
                    self.local_space,
                    self.lock_active_vertex)
            except: pass

        for bm in bm_data["bms"].values(): bm.bm.free()
        return {'FINISHED'}
        #|
    #|
    #|


register_ops = (
    OpsSetDistance,
    OpsSetDirection,
    OpsSetNormal,
    OpsCollinear,
    OpsCoplanar,
    OpsSetAngle,
    OpsSetArea,
)

## _import_lv2_standard_ ##
def _import_lv2_standard_():
    #|
    from ... util.const import VEC_00M1
    from ... utilbl.mesh import (
        r_median,
        r_average_direction,
        r_outer_2vert_by_direction,
        r_outer_2vert_by_single_line,
        r_next_vert_by_edge,
        r_angle,
        r_u_pos_by_angle,
        r_vert_area,
        r_bmface_copy,
        r_bmface_new,
        r_faces_area,
        is_2edge_connect)

    globals().update(locals())
    #|
