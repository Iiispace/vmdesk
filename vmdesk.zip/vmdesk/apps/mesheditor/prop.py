import bpy
from mathutils import Vector
from mathutils.geometry import normal

from ... util.types import (
    RnaDataOps,
    RnaFloat,
    RnaFloatVector,
    RnaBool,
    RnaString,
    RnaButton,
)


def callback_distance(option, value):
    self = option["button"]
    if MODAL_DRAG_STATE[0] == 1:
        bm_data, v0, v1, u_vec_glo, u_vec, local_space, invert = T[0]
    else:
        bm_data = r_bm_data(bpy.context)

        try: act = bm_data["bms"][bpy.context.object].bm.select_history.active
        except: act = None

        v0, v1 = bm_data["verts"]
        if act is v1: v0, v1 = v1, v0

        bm_dic = bm_data["bm_dic"]

        vec_glo = (bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)
        vec = v0.co - v1.co
        u_vec_glo = vec_glo.normalized()
        u_vec = vec.normalized()
        local_space = option["r_local_space"]()
        invert = self.pp.vert_invert

        T[0] = [bm_data, v0, v1, u_vec_glo, u_vec, local_space, invert]

    set_distance(bm_data, v0, v1, value, u_vec_glo, u_vec, local_space, invert)

    if local_space:
        self.pp.distance = (v0.co - v1.co).length
    else:
        bm_dic = bm_data["bm_dic"]
        self.pp.distance = ((bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)).length

    if value < 0: self.pp.distance *= -1
    self.upd_data()
    #|
def callback_direction(option, value):
    self = option["button"]
    if hasattr(value, "__len__"): pass
    else:
        e = self.pp.direction[:]
        e[self.active_index] = value
        value = e

    if MODAL_DRAG_STATE[0] == 1:
        bm_data, v0, v1, local_space = T[0]
    else:
        bm_data = r_bm_data(bpy.context)

        try: act = bm_data["bms"][bpy.context.object].bm.select_history.active
        except: act = None

        v0, v1 = bm_data["verts"]
        if act is v1: v0, v1 = v1, v0

        local_space = option["r_local_space"]()
        if self.pp.vert_invert: v0, v1 = v1, v0

        T[0] = [bm_data, v0, v1, local_space]

    set_direction(bm_data, v0, v1, value, local_space, False)

    if local_space:
        self.pp.direction[:] = v0.co - v1.co
    else:
        bm_dic = bm_data["bm_dic"]
        self.pp.direction[:] = (bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)

    self.upd_data()
    #|
def callback_u_direction(option, value):
    self = option["button"]

    bm_data = r_bm_data(bpy.context)

    try: act = bm_data["bms"][bpy.context.object].bm.select_history.active
    except: act = None

    v0, v1 = bm_data["verts"]
    if act is v1: v0, v1 = v1, v0

    local_space = option["r_local_space"]()
    if self.pp.vert_invert: v0, v1 = v1, v0

    if local_space:
        distance = (v0.co - v1.co).length
    else:
        bm_dic = bm_data["bm_dic"]
        distance = ((bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)).length

    set_direction(bm_data, v0, v1, Vector(value) * distance, local_space, False)

    if local_space:
        self.pp.u_direction[:] = (v0.co - v1.co).normalized()
    else:
        bm_dic = bm_data["bm_dic"]
        self.pp.u_direction[:] = ((bm_dic[v0].matrix_world @ v0.co) - (bm_dic[v1].matrix_world @ v1.co)).normalized()

    self.upd_data()
    #|

def callback_normal(option, value):
    self = option["button"]
    if hasattr(value, "__len__"):
        self.pp.normal[:] = value
    else:
        self.pp.normal[self.active_index] = value

    bm_data = r_bm_data(bpy.context)
    local_space = option["r_local_space"]()
    keep_normals_to_other_faces = self.pp.keep_normals_to_other_faces
    lock_active_vertex = self.pp.lock_active_vertex
    ftd = OpsSetNormal.r_first_time_data(bm_data)
    T[0] = [bm_data, local_space, keep_normals_to_other_faces, lock_active_vertex, ftd]

    if ftd["method"] == "NONE":
        report("Need select 1 face or 3 vertices, abort")
        return

    set_face_or_vert3_normal(
        bm_data,
        ftd,
        self.pp.normal,
        local_space,
        keep_normals_to_other_faces,
        lock_active_vertex)

    update_data()
    #|
def callback_area(option, value):
    self = option["button"]
    if MODAL_DRAG_STATE[0] == 1:
        bm_data, local_space, lock_active_vertex, ftd = T[0]
    else:
        bm_data = r_bm_data(bpy.context)
        local_space = option["r_local_space"]()
        lock_active_vertex = self.pp.lock_active_vertex_collinear
        ftd = OpsSetArea.r_first_time_data(bm_data)
        T[0] = [bm_data, local_space, lock_active_vertex, ftd]

    if self.pp.area < 0.0: self.pp.area = 0.0

    try:
        set_face_area(
            bm_data,
            ftd,
            self.pp.area,
            local_space,
            lock_active_vertex)
    except: return

    self.upd_data()
    #|
def callback_angle(option, value):
    self = option["button"]
    if MODAL_DRAG_STATE[0] == 1:
        bm_data, local_space, lock_active_vertex, org_coord = T[0]
    else:
        bm_data = r_bm_data(bpy.context)
        local_space = option["r_local_space"]()
        lock_active_vertex = self.pp.lock_active_vertex_collinear
        v0, v1, v2 = r_3vert_angle(bm_data)
        org_coord = v0.co.copy(), v1.co.copy(), v2.co.copy()
        T[0] = [bm_data, local_space, lock_active_vertex, org_coord]

    try: act = bm_data["bms"][bpy.context.object].bm.select_history.active
    except: act = None
    lock_active_vertex = act  if lock_active_vertex else None
    v0, v1, v2 = r_3vert_angle(bm_data)
    v0.co[:] = org_coord[0]
    v1.co[:] = org_coord[1]
    v2.co[:] = org_coord[2]

    set_angle(bm_data, v0, v1, v2, self.pp.angle, local_space, False, lock_active_vertex)

    self.upd_data()
    #|


#<RNAS>#
RNAS_mesh = {
"distance": RnaFloat("distance",
    name = "Distance",
    description = "Distance between 2 vertices",
    subtype = "DISTANCE",
    unit = "LENGTH"),
"direction": RnaFloatVector("direction",
    name = "Direction",
    description = "Direction of 2 vertices",
    default = (0.0, 0.0, 0.0),
    subtype = "DIRECTION",
    unit = "LENGTH"),
"u_direction": RnaFloatVector("u_direction",
    name = "Unit Vector",
    description = "Unit Direction of 2 vertices",
    default = (0.0, 0.0, 0.0),
    subtype = "STRING_VECTOR",
    unit = "LENGTH"),
"vert_invert": RnaBool("vert_invert",
    name = "Invert",
    description = "Reverse moved vertex"),
"normal": RnaFloatVector("normal",
    name = "Normal",
    description = "Normal of 3 vertices or face",
    default = (0.0, 0.0, 0.0),
    subtype = "STRING_VECTOR",
    unit = "LENGTH"),
"keep_normals_to_other_faces": RnaBool("keep_normals_to_other_faces",
    name = "Keep Normals to Other Faces",
    description = "Keep normals of unselected faces if possible"),
"lock_active_vertex": RnaBool("lock_active_vertex",
    name = "Lock Active Vertex",
    description = "Keep active vertex location"),
"vert_limit": RnaButton("vert_limit",
    name = "Vertex Limit",
    description = "Deactivate the property when the selected vertex count exceeds this value",
    button_text = "Vertex Limit"),
"make_collinear": RnaButton("make_collinear",
    name = "Make Collinear",
    description = "Make vertices collinear",
    button_text = "Make Collinear"),
"make_coplanar": RnaButton("make_coplanar",
    name = "Make Coplanar",
    description = "Make vertices coplanar",
    button_text = "Make Coplanar"),
"lock_active_vertex_collinear": RnaBool("lock_active_vertex_collinear",
    name = "Lock Active Vertex",
    description = "Keep active vertex location"),
"area": RnaFloat("area",
    name = "Area",
    description = "Faces area",
    unit = "AREA"),
"angle": RnaFloat("angle",
    name = "Included Angle",
    description = "Unsigned angle between 2 edges. If 3 vertices selected, the angle will be based on the second selected vertex.\nWhen modifying the angle, the last selected vertex will move and maintain the length from the second vertex",
    subtype = "ANGLE",
    unit = "ROTATION"),
}
#<RNAS>#

RNAS_mesh["distance"].data = RnaDataOps("mesh.vmd_vert_distance", "Mesh")
RNAS_mesh["direction"].data = RnaDataOps("mesh.vmd_vert_direction", "Mesh")
RNAS_mesh["normal"].data = RnaDataOps("mesh.vmd_normal", "Mesh")
RNAS_mesh["make_collinear"].data = RnaDataOps("mesh.vmd_collinear", "Mesh")
RNAS_mesh["make_coplanar"].data = RnaDataOps("mesh.vmd_coplanar", "Mesh")
RNAS_mesh["area"].data = RnaDataOps("mesh.vmd_area", "Mesh")
RNAS_mesh["angle"].data = RnaDataOps("mesh.vmd_angle", "Mesh")


## _import_lv2_standard_ ##
def _import_lv2_standard_():
    #|
    from . ops import (
        r_bm_data,
        r_3vert_angle,
        set_distance,
        set_direction,
        set_face_or_vert3_normal,
        set_face_area,
        set_angle,
        OpsSetNormal,
        OpsSetArea,
    )

    from ... block import MODAL_DRAG_STATE
    from ... m import (
        P,
        update_data,
    )
    from ... utilbl.blg import report

    T = [None]

    globals().update(locals())
    #|
