











import bpy
from bpy.utils import escape_identifier
from . util.deco import successResult, catch, catchBug

bpyopsobject = bpy.ops.object
grease_pencil_time_modifier_segment_add = bpyopsobject.grease_pencil_time_modifier_segment_add
grease_pencil_time_modifier_segment_remove = bpyopsobject.grease_pencil_time_modifier_segment_remove
grease_pencil_time_modifier_segment_move = bpyopsobject.grease_pencil_time_modifier_segment_move
grease_pencil_dash_modifier_segment_add = bpyopsobject.grease_pencil_dash_modifier_segment_add
grease_pencil_dash_modifier_segment_remove = bpyopsobject.grease_pencil_dash_modifier_segment_remove
grease_pencil_dash_modifier_segment_move = bpyopsobject.grease_pencil_dash_modifier_segment_move


# //* 0block_unreg_timer_hold_safe
# *//
# //* 0block_reg_timer_hold_safe
# *//
# //* 0block_unreg_timer_button_safe
# *//
# //* 0block_reg_timer_button_safe
# *//

def timer_hold():
    Admin.REDRAW()
    _timer_button_fn()
    # <<< 1copy (0block_reg_timer_button_safe,, $$)
    if timer_isreg(timer_button) == False:
        timer_reg(timer_button)

    # >>>

    #|
def timer_button():
    Admin.REDRAW()
    _timer_button_fn()
    return P.button_repeat_interval
    #|
def unreg_all_timer():
    if timer_isreg(timer_hold): timer_unreg(timer_hold)
    if timer_isreg(timer_button): timer_unreg(timer_button)

def poll_hard_disable(w): return not w.is_dark()
@ successResult
def append_rm_item_operator(items, rna):
    if hasattr(rna, "data"):
        if hasattr(rna.data, "operator"):
            operator_id = rna.data.operator
            keymap_category = rna.data.keymap_category
            keymaps = bpy.context.window_manager.keyconfigs.user.keymaps
            if keymap_category not in keymaps or keymaps[keymap_category].keymap_items.find_from_operator(operator_id) == None:
                items.append(("Assign Operator Shortcut", lambda: DropDownAddOpsShortcut(None, MOUSE, operator_id, keymap_category)))
            else:
                def remove_shortcut():
                    try:
                        keymaps = bpy.context.window_manager.keyconfigs.user.keymaps
                        if keymap_category in keymaps:
                            cat = keymaps[keymap_category].keymap_items
                            kmi = cat.find_from_operator(operator_id)
                            if kmi:
                                cat.remove(kmi)
                                report("Removed successfully. Requires manual saving of preferences")
                    except: pass

                items.append(("Edit Operator Shortcut", lambda: DropDownEditOpsShortcut(None, MOUSE, operator_id, keymap_category)))
                items.append(("Remove Operator Shortcut", remove_shortcut))
    #|
def append_rm_item_rotation_unit(self, items, rna):
    if hasattr(self, "evt_area_format") and hasattr(rna, "subtype") and rna.subtype == "EULER":
        items.append(("ui_format_toggle", self.evt_area_format))
    #|
@ catch
def append_rm_item_preview(self, items, rna):
    bpytypes = bpy.types
    v = self.get()
    if isinstance(v, bpytypes.Material) or isinstance(v, bpytypes.Image) or isinstance(v, bpytypes.Texture):
        pass
    else: return
    if hasattr(self, "evt_area_preview"): items.append(("dd_preview", self.evt_area_preview))
    #|


#_c4#_c4#_c4#_c4
def C_evt_head(self, poll_library=True, evtkill=True):
    if evtkill:
        kill_evt_except()
    if hasattr(self, "poll") and self.poll(self) == False:
        return None, None
    pp = self.r_pp()
    self.pp = pp
    if not pp:
        return None, None
    ob = self.r_object()
    if not ob:
        return None, None
    if poll_library:
        if hasattr(ob, "is_editable") and not ob.is_editable:
            report(r_library_or_override_message(ob))
            return None, ob
    return pp, ob
    #|

def C_r_dp(self, full=False):
    return f'{self.r_datapath_head(full)}{self.rna.identifier}'
    #|
def C_r_dp_gn(self, full=False):
    return f'{self.r_datapath_head(full)}["{escape_identifier(self.rna.identifier)}"]'
    #|
def C_evt_remove_from_keying_set(self, index=None):

    pp, ob = C_evt_head(self, poll_library=True)
    if pp is None: return
    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            index = "all"

    success, s = r_remove_from_keying_set(ob, self.r_dp(False), index=index)
    if s:
        DropDownOk(None, MOUSE, input_text=s)
    #|
def C_evt_add_to_keying_set(self, index=None):

    pp, ob = C_evt_head(self, poll_library=True)
    if pp is None: return
    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            index = "all"

    success, s = r_add_to_keying_set(ob, self.r_dp(False), index=index)
    if s:
        DropDownOk(None, MOUSE, input_text=s)
    #|
def C_evt_copy_full_data_path(self, index=None):

    pp, ob = C_evt_head(self, poll_library=False)
    if pp is None: return
    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            bpy.context.window_manager.clipboard = self.r_dp(True)
            report("Full Data Path is copied to the clipboard")
            return

    bpy.context.window_manager.clipboard = f'{self.r_dp(True)}[{index}]'
    report("Full Data Path is copied to the clipboard")
    #|
def C_evt_copy_data_path(self, index=None):

    pp, ob = C_evt_head(self, poll_library=False)
    if pp is None: return
    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            bpy.context.window_manager.clipboard = self.r_dp(False)
            report("Data Path is copied to the clipboard")
            return

    bpy.context.window_manager.clipboard = f'{self.r_dp(False)}[{index}]'
    report("Data Path is copied to the clipboard")
    #|
def C_evt_paste_full_data_path_as_driver(self, index=None):

    pp, ob = C_evt_head(self, poll_library=True)
    if pp is None: return
    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            fcs_index = set()
            if hasattr(self.w, "r_fcurve"):
                fcs_index = {r  for r, e in enumerate(self.w.r_fcurve()) if e}

            index = -1
            for r, e in enumerate(self.w.r_driver()):
                if r in fcs_index: continue
                if not e:
                    index = r
                    break

            if index == -1: index = len(self.get()) - 1

    if hasattr(self.w, "r_fcurve"):
        if self.w.r_fcurve()[index]:
            report("Unable to add driver when keyframe already exists")
            return

    success, ex = paste_full_data_path_as_driver_safe(
        bpy.context.window_manager.clipboard,
        self.w.r_driver()[index],
        self.r_datapath_head(),
        ob,
        self.rna,
        pp,
        index=index)

    if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to add Driver.\n{ex}')
    #|
def C_evt_delete_driver(self, index=None):

    pp, ob = C_evt_head(self, poll_library=True)
    if pp is None: return

    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            index = 0
            for r, e in enumerate(self.w.r_driver()):
                if e:
                    index = r
                    break

    dr = self.w.r_driver()[index]
    if dr: ob.animation_data.drivers.remove(dr)
    else:
        report("Driver not found")
        return

    array = self.get()
    for i, e in enumerate(array): array[i] = e
    update_scene_push("VMD Delete Driver")

    # if type(ob) != bpy.types.Object: return
    # if r_md_driver_remove(ob, pp.name, self.rna.identifier, index=index): pass
    # else:
    #     report("Driver not found")
    #     return

    # array = self.get()
    # for i, e in enumerate(array): array[i] = e
    # update_scene_push("VMD Delete Reference Driver")
    #|
def C_evt_delete_driver_all(self):

    pp, ob = C_evt_head(self, poll_library=True)
    if pp is None: return
    has_driver = False
    for dr in self.w.r_driver():
        if dr:
            has_driver = True
            ob.animation_data.drivers.remove(dr)

    if has_driver == False:
        report("Driver not found")
        return

    array = self.get()
    for i, e in enumerate(array): array[i] = e
    update_scene_push("VMD Delete Driver(s)")
    #|
def C_evt_add_driver(self, index=None, exp="var", replace=False, use_editor=False):

    pp, ob = C_evt_head(self, poll_library=True)
    if pp is None: return
    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            index = 0
            for r, e in enumerate(self.w.r_driver()):
                if not e:
                    index = r
                    break

    if self.rna.identifier == "name":
        report('Cannot add driver on "Name" attribute')
        return
    if hasattr(self.w, "r_fcurve"):
        if self.w.r_fcurve()[index]:
            report("Unable to add driver when keyframe already exists")
            return
    if self.w.r_driver()[index]:
        if not replace:
            if use_editor:
                open_driver_editor_from(ob, self.r_dp(False), index=index)
            return

        ob.animation_data.drivers.remove(self.w.r_driver()[index])

    success, ex = add_new_driver(ob, self.rna, pp, index=index, exp=exp)

    if success is False:
        DropDownOk(None, MOUSE, input_text=f'Failed to add Driver.\n{ex}')
    elif use_editor and P.is_open_driver_editor:
        open_driver_editor_from(ob, self.r_dp(False), index=index)
    #|
def C_evt_clear_keyframe(self, index=None, evtkill=True):

    pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
    if pp is None: return
    if not hasattr(self.w, "r_fcurve"): return

    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            for fc in self.w.r_fcurve():
                if fc: clear_keyframe(ob, fc, update_push=False)

            update_scene_push("VMD Clear Keyframe(s)")
            return

    fc = self.w.r_fcurve()[index]
    if not fc:
        report("Keyframe not found")
        return

    success, ex = clear_keyframe(ob, fc)

    if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to Clear Keyframe.\n{ex}')
    #|
def C_evt_delete_keyframe(self, index=None, evtkill=True):

    pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
    if pp is None: return
    if not hasattr(self.w, "r_fcurve"): return

    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            for r, fc in enumerate(self.w.r_fcurve()):
                if fc: del_keyframe(ob, self.rna, pp, index=r, update_push=False)

            update_scene_push("VMD Delete Keyframe(s)")
            return

    if not self.w.r_fcurve()[index]:
        report("Keyframe not found")
        return

    success, ex = del_keyframe(ob, self.rna, pp, index=index)

    if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to Delete Keyframe.\n{ex}')
    #|
def C_evt_insert_keyframe(self, index=None, evtkill=True):

    pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
    if pp is None: return
    if index == None:
        if hasattr(self, "active_index"):
            index = 0  if self.active_index == None else self.active_index
        else:
            is_success = False
            drs_index = set()
            if hasattr(self.w, "r_driver"):
                drs_index = {r  for r, e in enumerate(self.w.r_fcurve()) if e}
            for r in range(len(self.get())):
                if r not in drs_index:
                    success, ex = add_new_keyframe(ob, self.rna, pp, index=r, update_push=False)
                    if success: is_success = True

            if is_success is True: update_scene_push("VMD Delete Keyframe(s)")
            return

    if hasattr(self.w, "r_driver") and self.w.r_driver()[index]:
        report("Unable to Insert Keyframe when Driver already exists")
        return

    success, ex = add_new_keyframe(ob, self.rna, pp, index=index)

    if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to add Keyframe.\n{ex}')
    #|
def C_evt_area_format_gn(self):

    kill_evt_except()
    if self.unit == "ROTATION":
        if self.text_format.__name__.find("deg") == -1:
            self.text_format = UnitSystem.rs_format_deg
            self.rna.vmd_is_radian = False
        else:
            self.text_format = UnitSystem.format_float
            self.rna.vmd_is_radian = True

        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return

        for e, v in zip(self.blf_value, self.get()):
            e.unclip_text = v
            e.text = self.text_format(v)
        Admin.REDRAW()
    #|

def evtVectorAnim(cls):
    cls.evt_remove_from_keying_set = C_evt_remove_from_keying_set
    cls.evt_add_to_keying_set = C_evt_add_to_keying_set
    cls.evt_copy_full_data_path = C_evt_copy_full_data_path
    cls.evt_copy_data_path = C_evt_copy_data_path
    cls.evt_paste_full_data_path_as_driver = C_evt_paste_full_data_path_as_driver
    cls.evt_delete_driver = C_evt_delete_driver
    cls.evt_delete_driver_all = C_evt_delete_driver_all
    cls.evt_add_driver = C_evt_add_driver
    cls.evt_clear_keyframe = C_evt_clear_keyframe
    cls.evt_delete_keyframe = C_evt_delete_keyframe
    cls.evt_insert_keyframe = C_evt_insert_keyframe
    return cls
    #|
#_c4#_c4#_c4#_c4

class StructPush:
    __slots__ = ()

    def evt_undo_push(self, undo_push, oldvalue):
        if isinstance(undo_push, tuple):
            oldvalue = undo_push[0]
            undo_push = True

        if undo_push:
            newvalue = self.get()
            if oldvalue == newvalue: return

            if hasattr(newvalue, "foreach_get"):
                newvalue = tuple(newvalue)

            ed_undo_push(message=f'VMD {self.rna.name} :  {newvalue.name  if hasattr(newvalue, "name") else newvalue}')
        #|
    #|
    #|
class StructPushIndex:
    __slots__ = ()

    def evt_undo_push(self, undo_push, oldvalue, index):
        if isinstance(undo_push, tuple):
            oldvalue = undo_push[0]
            undo_push = True

        if undo_push:
            newvalue = self.get(index)
            if oldvalue == newvalue: return

            rna = self.rna[index]  if hasattr(self.rna, "__len__") else self.rna
            ed_undo_push(message=f'VMD {rna.name} :  {newvalue.name  if hasattr(newvalue, "name") else newvalue}')
        #|
    #|
    #|
class StructUndoPushPref:
    __slots__ = ()

    def evt_undo_push(self, undo_push, oldvalue):
        if isinstance(undo_push, tuple):
            oldvalue = undo_push[0]
            undo_push = True

        if undo_push:
            newvalue = getattr(self.pp, self.rna.identifier)
            if oldvalue == newvalue: return

            PREF_HISTORY.push_context = HistoryValue(oldvalue, newvalue,
                lambda v: self.set(v, refresh=True, undo_push=False),
                self.rna.name)
            PREF_HISTORY.push()
        #|
    #|
    #|
class StructUndoPushPrefVector:
    __slots__ = ()

    def evt_undo_push(self, undo_push, oldvalue):
        if isinstance(undo_push, tuple):
            oldvalue = list(undo_push)
            undo_push = True

        if undo_push:
            newvalue = [e  for e in getattr(self.pp, self.rna.identifier)]
            if oldvalue == newvalue: return
            PREF_HISTORY.push_context = HistoryValue(oldvalue, newvalue,
                lambda v: self.set(v, (0, len(newvalue)), refresh=True, undo_push=False),
                self.rna.name)
            PREF_HISTORY.push()
        #|
    #|
    #|
class StructUndoPushPrefColor:
    __slots__ = ()

    def evt_undo_push(self, undo_push, oldvalue):
        if isinstance(undo_push, tuple):
            oldvalue = list(undo_push)
            undo_push = True

        if undo_push:
            newvalue = [e  for e in getattr(self.pp, self.rna.identifier)]
            if oldvalue == newvalue: return
            def set_value(v):
                self.set(v, (0, len(newvalue)), refresh=True, undo_push=False)
                Admin.REDRAW()
                #|
            PREF_HISTORY.push_context = HistoryValue(oldvalue, newvalue,
                set_value,
                self.rna.name)
            PREF_HISTORY.push()
        #|
    #|
    #|
class StructButtonGetSetVector:
    __slots__ = ()

    def get(self, index=None):
        if index == None: return getattr(self.pp, self.rna.identifier)
        elif isinstance(index, int): return getattr(self.pp, self.rna.identifier)[index]
        else: return getattr(self.pp, self.rna.identifier)[index[0] : index[1]]
        #|
    def set(self, v, index, refresh=True, undo_push=True):
        array = getattr(self.pp, self.rna.identifier)
        oldvalue = [e  for e in array]
        if isinstance(index, int): array[index] = v
        else:
            l = list(array)
            l[index[0] : index[1]] = v
            array[:] = l
            # crash when array is EULER
            # array[index[0] : index[1]] = v
        if refresh: update_data()

        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
        #|
    def evt_undo_push(self, undo_push, oldvalue): pass
    #|
    #|
class StructPreview:
    __slots__ = ()

    def evt_area_preview(self):

        kill_evt_except()
        mat = self.get()
        if mat:
            preview_datablock(mat)
        #|
    #|
    #|

#_c4#_c4#_c4#_c4
class Title:
    __slots__ = 'blf_title', 'w'

    def __init__(self, title):
        self.blf_title = BlfClipColor(unclip_text=title, color=COL_block_fg)
        #|

    def init_bat(self, LL, RR, TT):
        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        e.x = LL + SIZE_border[3]

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, e.x, RR - D_SIZE['font_main_dx'])
        return TT - D_SIZE['widget_full_h']
        #|
    def set_text(self, s):
        e = self.blf_title
        e.unclip_text = s
        e.text = s
        #|
    def r_height(self, width): return D_SIZE['widget_full_h']

    def is_dark(self): return self.blf_title.color == COL_block_fg_ignore
    def dark(self):
        self.blf_title.color = COL_block_fg_ignore
        #|
    def light(self):
        self.blf_title.color = COL_block_fg
        #|

    def inside(self, mouse): return False
    def inside_evt(self): pass
    def outside_evt(self): pass

    def modal(self): return False

    def dxy(self, dx, dy):
        self.blf_title.x += dx
        self.blf_title.y += dy
        #|
    def draw_box(self): pass
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def get(self): pass
    def set(self, v, refresh=True, undo_push=True): pass

    def upd_data(self): pass
    #|
    #|
class ButtonSep:
    __slots__ = 'w', 'factor'

    def __init__(self, factor=1): self.factor = factor

    def init_bat(self, L, R, T): return T - round(SIZE_button[2] * self.factor)
    def r_height(self, width): return round(SIZE_button[2] * self.factor)

    def inside(self, mouse): return False
    def inside_evt(self): pass
    def outside_evt(self): pass

    def modal(self): return False

    def dxy(self, dx, dy): pass
    def draw_box(self): pass
    def draw_blf(self): pass

    def get(self): pass
    def set(self, v, refresh=True, undo_push=True): pass

    def upd_data(self): pass
    #|
    #|
class ButtonFold:
    __slots__ = (
        'w',
        'box_button',
        'is_trigger_enable')

    def __init__(self, w):
        self.w = w
        #|

    def r_height(self, width): return SIZE_widget[0]

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        self.is_trigger_enable = True

        if self.w.is_fold:
            if isinstance(self.box_button, GpuImg_fold):
                self.box_button = GpuImg_fold_focus(*self.box_button.r_LRBT())
                self.box_button.upd()
                Admin.REDRAW()
        else:
            if isinstance(self.box_button, GpuImg_unfold):
                self.box_button = GpuImg_unfold_focus(*self.box_button.r_LRBT())
                self.box_button.upd()
                Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.w.is_fold:
            if isinstance(self.box_button, GpuImg_fold_focus):
                self.box_button = GpuImg_fold(*self.box_button.r_LRBT())
                self.box_button.upd()
                Admin.REDRAW()
        else:
            if isinstance(self.box_button, GpuImg_unfold_focus):
                self.box_button = GpuImg_unfold(*self.box_button.r_LRBT())
                self.box_button.upd()
                Admin.REDRAW()
        #|

    def modal(self):
        if EVT_TYPE[1] == 'RELEASE': self.is_trigger_enable = True

        if self.is_trigger_enable is True:
            if TRIGGER['ui_fold_recursive_toggle']():
                self.is_trigger_enable = False
                if is_first_press('ui_fold_recursive_toggle') == False:
                    self.evt_fold_toggle(override=_last_bool_state[0], recursive=True)
                else:
                    self.evt_fold_toggle(recursive=True)
                return True

            if TRIGGER['ui_fold_toggle']():
                self.is_trigger_enable = False
                if is_first_press('ui_fold_toggle') == False:
                    self.evt_fold_toggle(override=_last_bool_state[0])
                else:
                    self.evt_fold_toggle()
                return True

        return False
        #|

    def evt_fold_toggle(self, override=None, recursive=False):
        if override == None:
            self.w.evt_fold_toggle(kill_evt=False, recursive=recursive)
        elif override == True:
            self.w.evt_fold(kill_evt=False, recursive=recursive)
        else:
            self.w.evt_unfold(kill_evt=False, recursive=recursive)

        if self.inside(MOUSE):
            if self.w.is_fold:
                if isinstance(self.box_button, GpuImg_fold):
                    self.box_button = GpuImg_fold_focus(*self.box_button.r_LRBT())
                    self.box_button.upd()
                    Admin.REDRAW()
            else:
                if isinstance(self.box_button, GpuImg_unfold):
                    self.box_button = GpuImg_unfold_focus(*self.box_button.r_LRBT())
                    self.box_button.upd()
                    Admin.REDRAW()
        else:
            if self.w.is_fold:
                if isinstance(self.box_button, GpuImg_fold_focus):
                    self.box_button = GpuImg_fold(*self.box_button.r_LRBT())
                    self.box_button.upd()
                    Admin.REDRAW()
            else:
                if isinstance(self.box_button, GpuImg_unfold_focus):
                    self.box_button = GpuImg_unfold(*self.box_button.r_LRBT())
                    self.box_button.upd()
                    Admin.REDRAW()
        #|
    #|
    #|
class ButtonBool:
    __slots__ = (
        'w',
        'rna',
        'pp',
        'r_pp',
        'r_object',
        'r_datapath_head',
        'box_button',
        'is_trigger_enable',
        'set_callback',
        'poll')

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuCheckbox(value=False if self.pp is None else self.get())
        #|

    def init_bat(self, L, R, T):
        B = T - D_SIZE['widget_bool_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        return B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_default_value(self): return self.rna.default

    def is_dark(self): return self.box_button.is_dark()
    def dark(self): self.box_button.dark()
    def light(self): self.box_button.light()

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        Admin.REDRAW()
        if self.is_dark() is False: self.box_button.color = COL_box_val_bool_fo
        self.is_trigger_enable = True
        #|
    def outside_evt(self):
        Admin.REDRAW()
        if self.is_dark() is False: self.box_button.color = COL_box_val_bool
        #|

    def modal(self):
        allow_trigger = self.is_trigger_enable
        if not allow_trigger:
            if EVT_TYPE[1] == 'RELEASE': self.is_trigger_enable = True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if allow_trigger:
            if TRIGGER['click']():
                if self.pp is None: return True
                self.is_trigger_enable = False
                if is_first_press('click') == False:
                    self.set(_last_bool_state[0])
                else:
                    boo = not self.get()
                    self.set(boo)
                    _last_bool_state[0] = boo
                Admin.REDRAW()
                return True
        return False
        #|

    def to_modal_rm(self):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ], override_name={
            "dd_paste": "Paste",
            "dd_copy": "Copy",
        }, title=self.rna.name)
        #|

    @ catch
    def evt_area_cut(self, is_report=True):
        self.evt_area_copy(is_report)
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        bpy.context.window_manager.clipboard = f'{self.get()}'
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        Admin.REDRAW()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        s = s.strip()
        if s in {'True', 'true', '1', '1.0'}:
            self.set(True)
            return
        elif s in {'False', 'false', '0', '0.0'}:
            self.set(False)
            return

        try:
            v = calc_vec(s)[0]
            self.set(bool(v))
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_reset_all(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_detail(self):

        kill_evt_except()
        Detail(Detail.r_rna_info(self.rna))
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        #|
    def draw_blf(self): pass

    def get(self):
        return getattr(self.pp, self.rna.identifier)
        #|
    def set(self, v, refresh=True, undo_push=True):
        oldvalue = getattr(self.pp, self.rna.identifier)
        setattr(self.pp, self.rna.identifier, v)
        if refresh: update_data()

        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
        #|
    def evt_undo_push(self, undo_push, oldvalue): pass

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        self.box_button.value = getattr(self.pp, self.rna.identifier)
        #|
    #|
    #|
class ButtonBoolXYZ(                # StructButtonGetSetVector  ButtonBool                      
    StructButtonGetSetVector, ButtonBool):
    __slots__ = 'blf_value', 'active_index', 'old_value'

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp

        self.box_button = [GpuButtonBool(), GpuButtonBool(), GpuButtonBool()]
        self.blf_value = [
            BlfColor("X", color=COL_box_button_fg),
            BlfColor("Y", color=COL_box_button_fg),
            BlfColor("Z", color=COL_box_button_fg)]

        self.old_value = None
        #|

    def init_bat(self, L, R, T):
        # <<< 1copy (0block_ButtonBoolArrayX_init_bat,, $$)
        blfSize(FONT0, D_SIZE['font_main'])
        box_button = self.box_button
        blf_value = self.blf_value
        widget_rim = SIZE_border[3]
        full_h = D_SIZE['widget_full_h']
        width = (R - L) // len(box_button)

        B = T - full_h
        y = B + widget_rim + D_SIZE['font_main_dy']

        for r in range(len(box_button) - 1):
            R0 = L + width
            box_button[r].LRBT_upd(L, R0, B, T, widget_rim)
            e = blf_value[r]
            e.y = y
            e.x = floor((R0 + L - blfDimen(FONT0, e.text)[0]) / 2)
            L = R0

        box_button[-1].LRBT_upd(L, R, B, T, widget_rim)
        e = blf_value[-1]
        e.y = y
        e.x = floor((R + L - blfDimen(FONT0, e.text)[0]) / 2)

        self.upd_data()
        return B
        # >>>
        #|
    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_default_array(self): return self.rna.default_array

    def is_dark(self): return self.box_button[0].is_dark()
    def dark(self):
        for e in self.box_button: e.dark()
        for e in self.blf_value: e.color = COL_box_button_fg_ignore
        #|
    def light(self):
        for e in self.box_button: e.light()
        for e in self.blf_value: e.color = COL_box_button_fg
        #|

    def r_focus_index(self, mouse):
        for r, e in enumerate(self.box_button):
            if e.inbox(mouse): return r
        return None
        #|
    def fn(self, i):

        Admin.REDRAW()
        if is_first_press('click') == False:
            self.set(_last_bool_state[0], i)
        else:
            boo = not self.get(i)
            self.set(boo, i)
            _last_bool_state[0] = boo
        #|

    def focus_button(self, i):
        if self.box_button[i].state == 0:
            self.box_button[i].set_state_off_focus()
        #|
    def unfocus_button(self, i):
        if self.box_button[i].state == 1:
            self.box_button[i].set_state_off()
        #|
    def turnon_button(self, i):
        if self.box_button[i].state in {0, 1}:
            self.box_button[i].set_state_on()
        #|
    def turnoff_button(self, i):
        if self.box_button[i].state == 2:
            self.box_button[i].set_state_off()
        #|

    def inside(self, mouse):
        box_button = self.box_button
        if mouse[0] < box_button[0].L: return False
        if mouse[0] > box_button[-1].R: return False
        if mouse[1] > box_button[0].T: return False
        if mouse[1] < box_button[-1].B: return False
        return True
        #|
    def inside_evt(self):
        self.active_index = self.r_focus_index(MOUSE)
        if self.active_index != None:
            self.focus_button(self.active_index)
            Admin.REDRAW()
        self.is_trigger_enable = True
        #|
    def outside_evt(self):
        if hasattr(self, "active_index"):
            if self.active_index != None:
                self.unfocus_button(self.active_index)
                Admin.REDRAW()
        #|

    def modal(self):
        allow_trigger = self.is_trigger_enable
        if not allow_trigger:
            if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                self.is_trigger_enable = True

        i = self.r_focus_index(MOUSE)
        if i != self.active_index:

            if self.active_index != None:
                self.unfocus_button(self.active_index)
                Admin.REDRAW()

            self.active_index = i
            self.is_trigger_enable = True

            if i != None:
                self.focus_button(i)
                Admin.REDRAW()

        if i == None: return False

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if allow_trigger:
            if TRIGGER['click']():
                self.is_trigger_enable = False
                self.fn(i)
                return True
        return False
        #|

    def to_modal_rm(self):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_all", self.evt_area_reset_all),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ], override_name={
            "dd_cut": "Copy Array",
            "dd_paste": "Paste",
            "dd_copy": "Copy",
        }, title=self.rna.name)
        #|

    @ catch
    def evt_area_cut(self, is_report=True):

        kill_evt_except()
        s = ""
        for e in self.get(): s += f'{value_to_display(e)}, '

        bpy.context.window_manager.clipboard = s[: -2]
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        if self.active_index == None:
            self.evt_area_cut(is_report)
            return

        kill_evt_except()
        bpy.context.window_manager.clipboard = value_to_display(self.get()[self.active_index])
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            Admin.REDRAW()
            if s.strip()[: 1] == "#":
                self.set(s, 0  if self.active_index == None else self.active_index)
                return

            array = calc_vec(s)
            ll = len(array)
            if ll == 1 and self.active_index != None:
                self.set(array[0], self.active_index)
            else:
                if ll > self.rna.array_length: array = array[: self.rna.array_length]
                self.set([int(round_dec(v))  for v in array], (0, ll))
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self):

        kill_evt_except()
        Admin.REDRAW()
        if self.active_index == None:
            self.set(self.r_default_array(), (0, self.rna.array_length))
        else:
            i = self.active_index
            self.set(self.r_default_array()[i], i)
        #|
    @ catch
    def evt_area_reset_all(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_array(), (0, self.rna.array_length))
        #|

    def dxy(self, dx, dy):
        for e in self.box_button: e.dxy_upd(dx, dy)
        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|
    def draw_box(self):
        for e in self.box_button: e.bind_draw()
        #|
    def draw_blf(self):
        blfSize(FONT0, D_SIZE['font_main'])
        for e in self.blf_value:
            blfColor(FONT0, *e.color)
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.old_value == [e for e in self.get()]: return

        v = [e for e in self.get()]

        for r, e in enumerate(v):
            self.turnon_button(r)  if e else self.turnoff_button(r)

        self.old_value = v
        #|
    #|
    #|
class ButtonInt:
    __slots__ = (
        'w',
        'rna',
        'pp',
        'r_pp',
        'r_object',
        'r_datapath_head',
        'box_button',
        'box_media',
        'blf_subtype',
        'blf_value',
        'text_format',
        'draw_box',
        'draw_blf',
        'dxy',
        'to_modal_drag_callfront',
        'end_modal_drag_callback',
        'set_callback',
        'poll')

    # /* 0block_ButtonInt_init
    def __init__(self, w, rna, pp, subtype_override=None):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_val, COL_box_val_rim)
        self.text_format = D_format["INT"]

        if self.pp is None:
            self.blf_value = BlfClipColor("", None, 0, 0, COL_box_val_fg)
        else:
            v = self.get()
            self.blf_value = BlfClipColor(self.text_format(v), v, 0, 0, COL_box_val_fg)

        if subtype_override is None:
            if rna.subtype == "PIXEL":
                self.draw_blf = self.i_draw_blf_subtype
                self.dxy = self.i_dxy_subtype
                self.blf_subtype = BlfColor("px", 0, 0, COL_box_button_fg_info)
            else:
                self.draw_blf = self.i_draw_blf
                self.dxy = self.i_dxy
        else:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = BlfColor(subtype_override[0], 0, 0, COL_box_button_fg_info)

        self.draw_box = self.i_draw_box
    # */

    def init_bat(self, L, R, T):
        widget_rim = SIZE_border[3]
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, widget_rim)
        self.blf_value.x = L + widget_rim
        self.blf_value.y = B + widget_rim + D_SIZE['font_main_dy']

        # /* 0block_ButtonInt_init_subtype
        if hasattr(self, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            self.blf_subtype.y = T - SIZE_border[3] - D_SIZE['font_label_dT']
            self.blf_subtype.x = L - D_SIZE['font_label_dx'] - ceil(blfDimen(FONT0, self.blf_subtype.text)[0])
        # */
        return B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_default_value(self): return self.rna.default

    def is_dark(self): return self.blf_value.color == COL_box_val_fg_ignore
    def dark(self):
        if self.box_button.color == COL_box_val:
            self.box_button.color = COL_box_val_ignore
            self.box_button.color_rim = COL_box_val_rim_ignore
            self.blf_value.color = COL_box_val_fg_ignore
            Admin.REDRAW()
        #|
    def light(self):
        if self.box_button.color == COL_box_val_ignore:
            self.box_button.color = COL_box_val
            self.box_button.color_rim = COL_box_val_rim
            self.blf_value.color = COL_box_val_fg
            Admin.REDRAW()
        #|

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        _valboxdata[0] = 0
        if self.is_dark(): pass
        else:
            self.box_button.color = COL_box_val_fo
            Admin.REDRAW()
        #|
    def outside_evt(self):
        self.draw_box = self.i_draw_box
        Admin.REDRAW()
        if self.is_dark(): pass
        else:
            self.box_button.color = COL_box_val
        #|

    def modal(self):
        if MOUSE[0] < self.box_button.inner[0] + SIZE_widget[0]:
            if _valboxdata[0] == 0:

                Admin.REDRAW()
                self.draw_box = self.i_draw_box_media
                self.box_media = GpuImg_valuebox_left()
                e = self.box_button.inner
                self.box_media.LRBT_upd(e[0], e[0] + SIZE_widget[0], e[2], e[3])
                _valboxdata[0] = 1
        elif MOUSE[0] >= self.box_button.inner[1] - SIZE_widget[0]:
            if _valboxdata[0] == 0:

                Admin.REDRAW()
                self.draw_box = self.i_draw_box_media
                self.box_media = GpuImg_valuebox_right()
                e = self.box_button.inner
                self.box_media.LRBT_upd(e[1] - SIZE_widget[0], e[1], e[2], e[3])
                _valboxdata[0] = 2
        else:
            if _valboxdata[0] != 0:
                Admin.REDRAW()
                self.draw_box = self.i_draw_box
                _valboxdata[0] = 0

        # /* 0block_ButtonInt_modal_trigger
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['valbox_drag']():
            self.to_modal_drag()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if TRIGGER['ui_format_toggle']():
            self.evt_area_format()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            if _valboxdata[0] == 0: self.to_modal_drag_pre()
            elif _valboxdata[0] == 1: self.to_modal_media_left()
            else: self.to_modal_media_right()
            return True
        # */
        return False
        #|

    def to_modal_drag_pre(self):

        # /* 0block_ButtonInt_to_modal_drag
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # */
    def to_modal_drag(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     "('click')": "('valbox_drag')",
        #     'self.i_modal_drag_pre': 'self.i_modal_drag'
        # }$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('valbox_drag')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('valbox_drag')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>
        #|
    def end_modal_drag(self):
        # <<< 1copy (0block_unreg_timer_button_safe,, $$)
        if timer_isreg(timer_button):
            timer_unreg(timer_button)

        # >>>
        # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold):
            timer_unreg(timer_hold)

        # >>>
        end_loop_mouse()
        kill_evt_except()
        if self.is_dark():
            self.box_button.color = COL_box_val_ignore
        else:
            self.box_button.color = COL_box_val_fo  if self.box_button.inbox(MOUSE) else COL_box_val

        if _value_data["confirm"] is None: pass
        elif _value_data["confirm"] == True:
            self.set(_blf_value.unclip_text, undo_push=_value_data["values"][0])
        else:
            e = self.blf_value
            o = _value_data["values"][0]
            e.unclip_text = o[0]
            e.text = o[1]

        if hasattr(self, "end_modal_drag_callback"): self.end_modal_drag_callback()

        MODAL_DRAG_STATE[0] = -1
        #|
    def i_modal_drag_pre(self):
        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = None
            W_HEAD[-1].fin()
            return

        if _end_trigger():
            loop_mouse()
            _value_data["confirm"] = None
            W_HEAD[-1].fin()
            self.to_dropdown()
            return

        dx, dy = r_mouse_dxy()
        _xy[0] += dx
        if abs(_xy[0]) >= P.th_drag:
            _xy[0] = 0
            Admin.REDRAW()
            W_HEAD[-1].modal = self.i_modal_drag

        loop_mouse()
        #|
    def i_modal_drag(self):
        # /* 0block_ButtonInt_i_modal_drag_head
        Admin.REDRAW()

        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = False
            W_HEAD[-1].fin()
            return
        if _end_trigger():
            W_HEAD[-1].fin()
            return

        dx, dy = r_mouse_dxy()
        if TRIGGER['valbox_drag_modal_fast'](): dx *= 10
        elif TRIGGER['valbox_drag_modal_slow'](): dx *= 0.1

        _xy[0] += dx * _valbox_drag_fac
        travel = _xy[0]
        if travel >= 1:
            dx = floor(travel)
            _xy[0] -= dx
        elif travel <= -1:
            dx = ceil(travel)
            _xy[0] -= dx
        else:
            loop_mouse()
            return
        # */
        # /* 0block_ButtonInt_i_modal_drag
        self.set(_blf_value.unclip_text + dx, undo_push=False)
        if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
        # */
        loop_mouse()
        #|

    def to_modal_media_left(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${'i_modal_drag_pre':'i_modal_media'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>

        global _timer_button_fn
        def _timer_button_fn():
            # <<< 1copy (0block_ButtonInt_i_modal_drag,, ${'+ dx':'- 1'}$)
            self.set(_blf_value.unclip_text - 1, undo_push=False)
            if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
            # >>>

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|
    def to_modal_media_right(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${'i_modal_drag_pre':'i_modal_media'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>

        global _timer_button_fn
        def _timer_button_fn():
            # <<< 1copy (0block_ButtonInt_i_modal_drag,, ${'+ dx':'+ 1'}$)
            self.set(_blf_value.unclip_text + 1, undo_push=False)
            if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
            # >>>

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|
    def i_modal_media(self):
        Admin.REDRAW()

        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']() or _end_trigger():
            W_HEAD[-1].fin()
            return

        dx, dy = r_mouse_dxy()
        _xy[0] += dx
        if abs(_xy[0]) >= P.th_drag:
            # <<< 1copy (0block_unreg_timer_button_safe,, $$)
            if timer_isreg(timer_button):
                timer_unreg(timer_button)

            # >>>
            # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
            if timer_isreg(timer_hold):
                timer_unreg(timer_hold)

            # >>>
            _xy[0] = 0
            Admin.REDRAW()
            self.draw_box = self.i_draw_box
            _valboxdata[0] = 0
            W_HEAD[-1].modal = self.i_modal_drag

        loop_mouse()
        #|

    def to_dropdown(self):

        o = self.blf_value
        DropDownVal(self, self.box_button.r_LRBT(), o.text, o.unclip_text, self.rna)
        #|

    def to_modal_rm(self):

        items = [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ]

        if hasattr(self.rna, "subtype") and self.rna.subtype == "ANGLE":
            items.append(("ui_format_toggle", self.evt_area_format))
        append_rm_item_operator(items, self.rna)

        DropDownRMKeymap(self, MOUSE, items, title=self.rna.name)
        #|

    @ catch
    def evt_area_cut(self, is_report=True):
        self.evt_area_copy(is_report)
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        bpy.context.window_manager.clipboard = value_to_display(self.blf_value.unclip_text)
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            if s.strip()[: 1] == "#":
                self.set(s)
            else:
                v = calc_vec(s)[0]
                self.set(int(round_dec(v)))
            Admin.REDRAW()
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_reset_all(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_detail(self):

        kill_evt_except()
        Detail(Detail.r_rna_info(self.rna))
        #|
    def evt_area_format(self): pass

    def i_dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        if self.draw_box == self.i_draw_box_media: self.box_media.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def i_dxy_subtype(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        if self.draw_box == self.i_draw_box_media: self.box_media.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        self.blf_subtype.x += dx
        self.blf_subtype.y += dy
        #|
    def i_draw_box(self):
        self.box_button.bind_draw()
        #|
    def i_draw_box_media(self):
        self.box_button.bind_draw()
        self.box_media.bind_draw()
        #|
    def i_draw_blf(self):
        e = self.blf_value
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|
    def i_draw_blf_subtype(self):
        e = self.blf_value
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        e = self.blf_subtype
        blfSize(FONT0, D_SIZE['font_label'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def get(self):
        return getattr(self.pp, self.rna.identifier)
        #|
    def set(self, v, refresh=True, undo_push=True):
        oldvalue = getattr(self.pp, self.rna.identifier)
        setattr(self.pp, self.rna.identifier, v)
        if refresh: update_data()

        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
        #|
    def evt_undo_push(self, undo_push, oldvalue): pass

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return


        v = getattr(self.pp, self.rna.identifier)
        self.blf_value.unclip_text = v
        self.blf_value.text = self.text_format(v)
        #|
    #|
    #|
class ButtonFloat(                  # ButtonFloat                                               
    ButtonInt):
    __slots__ = ()

    # <<< 1copy (0block_ButtonInt_init,, ${'"INT"':'rna.unit'}$)
    def __init__(self, w, rna, pp, subtype_override=None):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_val, COL_box_val_rim)
        self.text_format = D_format[rna.unit]

        if self.pp is None:
            self.blf_value = BlfClipColor("", None, 0, 0, COL_box_val_fg)
        else:
            v = self.get()
            self.blf_value = BlfClipColor(self.text_format(v), v, 0, 0, COL_box_val_fg)

        if subtype_override is None:
            if rna.subtype == "PIXEL":
                self.draw_blf = self.i_draw_blf_subtype
                self.dxy = self.i_dxy_subtype
                self.blf_subtype = BlfColor("px", 0, 0, COL_box_button_fg_info)
            else:
                self.draw_blf = self.i_draw_blf
                self.dxy = self.i_dxy
        else:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = BlfColor(subtype_override[0], 0, 0, COL_box_button_fg_info)

        self.draw_box = self.i_draw_box
    # >>>

    def i_modal_drag(self):
        # /* 0block_ButtonFloat_i_modal_drag_head
        Admin.REDRAW()

        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = False
            W_HEAD[-1].fin()
            return
        if _end_trigger():
            W_HEAD[-1].fin()
            return

        dx, dy = r_mouse_dxy()
        if TRIGGER['valbox_drag_modal_fast']():
            dx *= _valbox_drag_fac * 10
        elif TRIGGER['valbox_drag_modal_slow']():
            dx *= _valbox_drag_fac * 0.1
        else:
            dx *= _valbox_drag_fac
        # */
        # /* 0block_ButtonFloat_i_modal_drag
        try: v_float = _blf_value.unclip_text + dx
        except:
            loop_mouse()
            return
        self.set(v_float, undo_push=False)
        if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
        # */
        loop_mouse()
        #|

    def to_modal_drag_pre(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     'P.valbox_drag_fac_int': 'P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>
    def to_modal_drag(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     "('click')":"('valbox_drag')",
        #     'P.valbox_drag_fac_int': 'P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('valbox_drag')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('valbox_drag')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>
        W_HEAD[-1].modal = self.i_modal_drag
        #|
    def to_modal_media_left(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     'i_modal_drag_pre': 'i_modal_media',
        #     'P.valbox_drag_fac_int': 'P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>

        global _timer_button_fn
        def _timer_button_fn():
            # <<< 1copy (0block_ButtonFloat_i_modal_drag,, ${'+ dx':'- _valbox_drag_fac', 'loop_mouse()':''}$)
            try: v_float = _blf_value.unclip_text - _valbox_drag_fac
            except:
                
                return
            self.set(v_float, undo_push=False)
            if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
            # >>>

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|
    def to_modal_media_right(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     'i_modal_drag_pre': 'i_modal_media',
        #     'P.valbox_drag_fac_int': 'P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>

        global _timer_button_fn
        def _timer_button_fn():
            # <<< 1copy (0block_ButtonFloat_i_modal_drag,, ${'+ dx':'+ _valbox_drag_fac', 'loop_mouse()':''}$)
            try: v_float = _blf_value.unclip_text + _valbox_drag_fac
            except:
                
                return
            self.set(v_float, undo_push=False)
            if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
            # >>>

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|

    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        bpy.context.window_manager.clipboard = value_to_display(
            self.blf_value.unclip_text / r_unit_factor(self.unit  if hasattr(self, "unit") else self.rna.unit, self.text_format))
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            if s.strip()[: 1] == "#":
                self.set(s)
            else:
                self.set(calc_vec(s)[0] * r_unit_factor(self.unit  if hasattr(self, "unit") else self.rna.unit, self.text_format))
            Admin.REDRAW()
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_format(self):

        kill_evt_except()
        unit = self.unit  if hasattr(self, "unit") else self.rna.unit
        if unit == "ROTATION":
            if self.text_format.__name__.find("deg") == -1:
                self.text_format = UnitSystem.rs_format_deg
            else:
                self.text_format = UnitSystem.format_float

            if hasattr(self, "r_pp"): self.pp = self.r_pp()
            if self.pp is None: return
            v = self.get()
            self.blf_value.unclip_text = v
            self.blf_value.text = self.text_format(v)
            Admin.REDRAW()
        #|
    #|
    #|
class ButtonIntVector(              # StructButtonGetSetVector  ButtonInt                       
    StructButtonGetSetVector, ButtonInt):
    __slots__ = 'active_index', 'box_active', 'array_length'

    # /* 0block_ButtonIntVector_init
    def __init__(self, w, rna, pp, subtype_override=None):
        self.w = w
        self.rna = rna
        self.array_length = rna.array_length

        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp

        self.box_button = GpuRim(COL_box_val, COL_box_val_rim)
        self.box_active = GpuBox(COL_box_val_fo)
        self.text_format = D_format["INT"]
        vv = getattr(self.pp, rna.identifier)
        self.blf_value = [BlfClip(self.text_format(v), v)  for v in vv]
        self.blf_value[0].color = COL_box_val_fg

        if subtype_override is None:
            if rna.subtype in D_subtype_display:
                self.draw_blf = self.i_draw_blf_subtype
                self.dxy = self.i_dxy_subtype
                self.blf_subtype = [Blf(tx)  for _, tx in zip(vv, D_subtype_display[rna.subtype])]
                self.blf_subtype[0].color = COL_box_button_fg_info
            else:
                self.draw_blf = self.i_draw_blf
                self.dxy = self.i_dxy
        else:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = [Blf(tx)  for _, tx in zip(vv, subtype_override)]
            self.blf_subtype[0].color = COL_box_button_fg_info

        self.draw_box = self.i_draw_box
        self.active_index = None
    # */

    def init_bat(self, L, R, T):
        widget_rim = SIZE_border[3]
        h = SIZE_widget[0]
        x = L + widget_rim
        y = T - widget_rim - D_SIZE['font_main_dT']
        for e in self.blf_value:
            e.x = x
            e.y = y
            y -= h

        B = T - D_SIZE['widget_full_h'] - (self.array_length - 1) * h
        self.box_button.LRBT_upd(L, R, B, T, widget_rim)

        if hasattr(self, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            y = self.box_button.inner[3] - D_SIZE['font_label_dT']
            for e in self.blf_subtype:
                e.y = y
                y -= h
                e.x = L - D_SIZE['font_label_dx'] - ceil(blfDimen(FONT0, e.text)[0])
        return B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h'] + (self.array_length - 1) * SIZE_widget[0]
    def r_default_array(self): return self.rna.default_array

    def is_dark(self): return self.blf_value[0].color == COL_box_val_fg_ignore
    def dark(self):
        if self.box_button.color == COL_box_val:
            self.box_button.color = COL_box_val_ignore
            self.box_button.color_rim = COL_box_val_rim_ignore

            for e in self.blf_value:
                e.color = COL_box_val_fg_ignore
            Admin.REDRAW()
        #|
    def light(self):
        if self.box_button.color == COL_box_val_ignore:
            self.box_button.color = COL_box_val
            self.box_button.color_rim = COL_box_val_rim

            for e in self.blf_value:
                e.color = COL_box_val_fg
            Admin.REDRAW()
        #|

    def inside_evt(self):
        _valboxdata[0] = 0
        self.active_index = None
        #|
    def outside_evt(self):
        Admin.REDRAW()
        self.draw_box = self.i_draw_box
        self.active_index = None
        #|

    def modal(self):
        ind = min(max(0, (MOUSE[1] - self.box_button.inner[3]) // - SIZE_widget[0]), self.array_length - 1)

        if self.active_index != ind:

            self.draw_box = self.i_draw_box_media
            Admin.REDRAW()
            self.box_media = BoxFake()
            if self.is_dark() is True:
                self.box_active.LRBT_upd(0, 0, 0, 0)
            else:
                L, R, B, T = self.box_button.inner
                T -= SIZE_widget[0] * ind
                self.box_active.LRBT_upd(L, R, T, T - SIZE_widget[0])
            self.active_index = ind
            _valboxdata[0] = 0

        if MOUSE[0] < self.box_button.inner[0] + SIZE_widget[0]:
            if _valboxdata[0] == 0:

                Admin.REDRAW()
                self.box_media = GpuImg_valuebox_left()
                L, R, B, T = self.box_button.inner
                T -= SIZE_widget[0] * self.active_index
                self.box_media.LRBT_upd(L, L + SIZE_widget[0], T, T - SIZE_widget[0])
                _valboxdata[0] = 1
        elif MOUSE[0] >= self.box_button.inner[1] - SIZE_widget[0]:
            if _valboxdata[0] == 0:

                Admin.REDRAW()
                self.box_media = GpuImg_valuebox_right()
                L, R, B, T = self.box_button.inner
                T -= SIZE_widget[0] * self.active_index
                self.box_media.LRBT_upd(R - SIZE_widget[0], R, T, T - SIZE_widget[0])
                _valboxdata[0] = 2
        else:
            if _valboxdata[0] != 0:
                Admin.REDRAW()
                self.box_media = BoxFake()
                _valboxdata[0] = 0

        # <<< 1copy (0block_ButtonInt_modal_trigger,, $$)
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['valbox_drag']():
            self.to_modal_drag()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if TRIGGER['ui_format_toggle']():
            self.evt_area_format()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            if _valboxdata[0] == 0: self.to_modal_drag_pre()
            elif _valboxdata[0] == 1: self.to_modal_media_left()
            else: self.to_modal_media_right()
            return True
        # >>>
        return False
        #|

    def end_modal_drag(self):
        # <<< 1copy (0block_unreg_timer_button_safe,, $$)
        if timer_isreg(timer_button):
            timer_unreg(timer_button)

        # >>>
        # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold):
            timer_unreg(timer_hold)

        # >>>
        end_loop_mouse()
        kill_evt_except()
        self.box_active.color = COL_box_val_fo

        if _value_data["confirm"] is None: pass
        elif _value_data["confirm"] == True:
            if "array_range" in _value_data:
                e = _value_data["array_range"]
                self.set([_blf_value[i].unclip_text  for i in e], (e.start, e.stop),
                    undo_push=tuple(v[0]  for v in _value_data["values"]))
            else:
                i = self.active_index
                self.set(_blf_value[i].unclip_text, i,
                    undo_push=tuple(v[0]  for v in _value_data["values"]))
        else:
            for e, o in zip(self.blf_value, _value_data["values"]):
                e.unclip_text = o[0]
                e.text = o[1]

        self.active_index = None
        if hasattr(self, "end_modal_drag_callback"): self.end_modal_drag_callback()

        MODAL_DRAG_STATE[0] = -1
        #|
    def i_modal_drag_pre(self):
        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = None
            W_HEAD[-1].fin()
            return

        if _end_trigger():
            loop_mouse()
            ind = self.active_index
            _value_data["confirm"] = None
            W_HEAD[-1].fin()
            self.active_index = ind
            self.to_dropdown()
            return

        dx, dy = r_mouse_dxy()
        _xy[0] += dx
        _xy[1] += dy

        if abs(_xy[0]) >= P.th_drag:
            _xy[0] = 0
            Admin.REDRAW()
            W_HEAD[-1].modal = self.i_modal_drag
        elif abs(_xy[1]) >= P.th_drag:
            _xy[0] = 0
            _xy[1] = 0
            Admin.REDRAW()
            W_HEAD[-1].modal = self.i_modal_drag_pre_array
            _value_data["end_index"] = self.active_index

        loop_mouse()
        #|
    def i_modal_drag_pre_array(self):
        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = None
            W_HEAD[-1].fin()
            return

        if _end_trigger():
            loop_mouse()
            i0 = self.active_index
            _value_data["confirm"] = None
            W_HEAD[-1].fin()
            self.active_index = i0

            ind = _value_data["end_index"]
            if i0 > ind: i0, ind = ind, i0
            if i0 == ind:
                self.to_dropdown()
            else:
                self.to_dropdown(range(i0, ind + 1), _value_data["end_index"])
            return

        dx, dy = r_mouse_dxy()
        _xy[0] += dx
        _xy[1] += dy
        h = SIZE_widget[0]

        if _xy[1] < - h:
            d = (- _xy[1]) // h
            _xy[1] += h * d
            _xy[0] = 0
            ind = min(_value_data["end_index"] + d, self.array_length - 1)
        elif _xy[1] > h:
            d = _xy[1] // h
            _xy[1] -= h * d
            _xy[0] = 0
            ind = max(0, _value_data["end_index"] - d)
        else:
            ind = _value_data["end_index"]

        if ind != _value_data["end_index"]:
            _value_data["end_index"] = ind
            L, R, B, T = self.box_button.inner
            i0 = self.active_index
            if i0 > ind: i0, ind = ind, i0
            T -= i0 * h
            B = T - h * (ind - i0 + 1)
            Admin.REDRAW()
            self.box_active.LRBT_upd(L, R, B, T)

        if abs(_xy[0]) >= h:
            _xy[0] = 0
            Admin.REDRAW()
            i0 = self.active_index
            ind = _value_data["end_index"]
            if i0 > ind: i0, ind = ind, i0
            _value_data["array_range"] = range(i0, ind + 1)
            _value_data["array_index"] = i0, ind + 1
            W_HEAD[-1].modal = self.i_modal_drag_array

        loop_mouse()
        #|
    def i_modal_drag(self):
        # <<< 1copy (0block_ButtonInt_i_modal_drag_head,, $$)
        Admin.REDRAW()

        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = False
            W_HEAD[-1].fin()
            return
        if _end_trigger():
            W_HEAD[-1].fin()
            return

        dx, dy = r_mouse_dxy()
        if TRIGGER['valbox_drag_modal_fast'](): dx *= 10
        elif TRIGGER['valbox_drag_modal_slow'](): dx *= 0.1

        _xy[0] += dx * _valbox_drag_fac
        travel = _xy[0]
        if travel >= 1:
            dx = floor(travel)
            _xy[0] -= dx
        elif travel <= -1:
            dx = ceil(travel)
            _xy[0] -= dx
        else:
            loop_mouse()
            return
        # >>>

        # /* 0block_ButtonIntVector_i_modal_drag
        e = _blf_value[self.active_index]
        self.set(e.unclip_text + dx, self.active_index, undo_push=False)
        if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
        # */
        loop_mouse()
        #|
    def i_modal_drag_array(self):
        # <<< 1copy (0block_ButtonInt_i_modal_drag_head,, $$)
        Admin.REDRAW()

        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = False
            W_HEAD[-1].fin()
            return
        if _end_trigger():
            W_HEAD[-1].fin()
            return

        dx, dy = r_mouse_dxy()
        if TRIGGER['valbox_drag_modal_fast'](): dx *= 10
        elif TRIGGER['valbox_drag_modal_slow'](): dx *= 0.1

        _xy[0] += dx * _valbox_drag_fac
        travel = _xy[0]
        if travel >= 1:
            dx = floor(travel)
            _xy[0] -= dx
        elif travel <= -1:
            dx = ceil(travel)
            _xy[0] -= dx
        else:
            loop_mouse()
            return
        # >>>

        self.set([_blf_value[r].unclip_text + dx  for r in _value_data["array_range"]],
            _value_data["array_index"], undo_push=False)
        if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
        loop_mouse()
        #|

    def to_modal_media_left(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${'i_modal_drag_pre':'i_modal_media'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>

        global _timer_button_fn
        def _timer_button_fn():
            # <<< 1copy (0block_ButtonIntVector_i_modal_drag,, ${'+ dx':'- 1'}$)
            e = _blf_value[self.active_index]
            self.set(e.unclip_text - 1, self.active_index, undo_push=False)
            if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
            # >>>

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|
    def to_modal_media_right(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${'i_modal_drag_pre':'i_modal_media'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_int
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>

        global _timer_button_fn
        def _timer_button_fn():
            # <<< 1copy (0block_ButtonIntVector_i_modal_drag,, ${'+ dx':'+ 1'}$)
            e = _blf_value[self.active_index]
            self.set(e.unclip_text + 1, self.active_index, undo_push=False)
            if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
            # >>>

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|

    def to_dropdown(self, array_range=None, end_index=None):

        ind = self.active_index  if array_range == None else end_index

        o = self.blf_value[ind]
        h = SIZE_widget[0]
        widget_rim = SIZE_border[3]
        L, R, B, T = self.box_button.inner
        L -= widget_rim
        R += widget_rim
        T -= h * ind
        B = T - h - widget_rim
        T += widget_rim

        if array_range == None: array_range = range(ind, ind + 1)
        DropDownVal(self, (L, R, B, T), o.text, o.unclip_text, self.rna, array_range)
        #|

    def to_modal_rm(self):

        items = [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_all", self.evt_area_reset_all),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ]
        append_rm_item_rotation_unit(self, items, self.rna)
        append_rm_item_operator(items, self.rna)

        DropDownRMKeymap(self, MOUSE, items, override_name={"dd_cut":"Copy Array"}, title=self.rna.name)
        #|

    @ catch
    def evt_area_cut(self, is_report=True):

        kill_evt_except()
        s = ""
        for e in self.get(): s += f'{value_to_display(e)}, '

        bpy.context.window_manager.clipboard = s[: -2]
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        if self.active_index == None:
            self.evt_area_cut(is_report)
            return

        kill_evt_except()
        bpy.context.window_manager.clipboard = value_to_display(self.get()[self.active_index])
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            Admin.REDRAW()
            if s.strip()[: 1] == "#":
                self.set(s, 0  if self.active_index == None else self.active_index)
                return

            array = calc_vec(s)
            ll = len(array)
            if ll == 1 and self.active_index != None:
                self.set(int(round_dec(array[0])), self.active_index)
            else:
                if ll > self.array_length: array = array[: self.array_length]
                self.set([int(round_dec(v))  for v in array], (0, ll))
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self):

        kill_evt_except()
        Admin.REDRAW()
        if self.active_index == None:
            self.set(self.r_default_array(), (0, self.array_length))
        else:
            i = self.active_index
            self.set(self.r_default_array()[i], i)
        #|
    @ catch
    def evt_area_reset_all(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_array(), (0, self.array_length))
        #|

    def i_dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        if self.draw_box == self.i_draw_box_media:
            self.box_active.dxy_upd(dx, dy)
            self.box_media.dxy_upd(dx, dy)

        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|
    def i_dxy_subtype(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        if self.draw_box == self.i_draw_box_media:
            self.box_active.dxy_upd(dx, dy)
            self.box_media.dxy_upd(dx, dy)

        for e in self.blf_value:
            e.x += dx
            e.y += dy
        for e in self.blf_subtype:
            e.x += dx
            e.y += dy
        #|

    def i_draw_box_media(self):
        self.box_button.bind_draw()
        self.box_active.bind_draw()
        self.box_media.bind_draw()
        #|
    def i_draw_blf(self):
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *self.blf_value[0].color)
        for e in self.blf_value:
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|
    def i_draw_blf_subtype(self):
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *self.blf_value[0].color)
        for e in self.blf_value:
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)

        blfSize(FONT0, D_SIZE['font_label'])
        blfColor(FONT0, *self.blf_subtype[0].color)
        for e in self.blf_subtype:
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        for e, o in zip(self.blf_value, getattr(self.pp, self.rna.identifier)):
            if e.unclip_text == o: continue
            e.unclip_text = o
            e.text = self.text_format(o)
        #|
    #|
    #|
class ButtonBoolVector(             # StructButtonGetSetVector
    StructButtonGetSetVector):
    __slots__ = (
        'w',
        'rna',
        'pp',
        'r_pp',
        'r_object',
        'r_datapath_head',
        'box_button',
        'row_length',
        'active_index',
        'is_trigger_enable',
        'set_callback',
        'array_length',
        'array_tuple')

    def __init__(self, w, rna, pp, row_length=1):
        self.w = w
        self.rna = rna
        self.array_length = rna.array_length

        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.row_length = row_length
        self.box_button = [GpuButtonBool()  for r in range(self.array_length)]
        self.array_tuple = (False, ) * self.array_length
        #|

    def init_bat(self, L, R, T):
        blfSize(FONT0, D_SIZE['font_main'])
        row_length = self.row_length
        box_button = self.box_button
        widget_rim = SIZE_border[3]
        full_h = D_SIZE['widget_full_h']
        width = (R - L) // row_length
        range_row = range(row_length)
        LRs = []
        R0 = L + width
        for _ in range_row:
            LRs.append([L, R0])
            L = R0
            R0 += width
        LRs[-1][1] = R
        B = T - full_h
        y = B + widget_rim + D_SIZE['font_main_dy']

        i = 0
        amount = len(box_button) // row_length
        for _ in range(amount):
            for r in range_row:
                # /* 0block_ButtonBoolVector_initbutton
                L0, R0 = LRs[r]
                box_button[i].LRBT_upd(L0, R0, B, T, widget_rim)
                i += 1
                # */

            T = B
            B -= full_h
            y -= full_h

        for r in range(len(box_button) - amount * row_length):
            # <<< 1copy (0block_ButtonBoolVector_initbutton,, $$)
            L0, R0 = LRs[r]
            box_button[i].LRBT_upd(L0, R0, B, T, widget_rim)
            i += 1
            # >>>

        self.upd_data()
        return box_button[-1].B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h'] * ceil(len(self.box_button) / self.row_length)
    def r_default_array(self): return self.rna.default_array

    def is_dark(self): return self.box_button[0].is_dark()
    def dark(self):
        for e in self.box_button: e.dark()
        #|
    def light(self):
        for e in self.box_button: e.light()
        #|

    def r_focus_index(self, mouse):
        for r, e in enumerate(self.box_button):
            if e.inbox(mouse): return r
        return None
        #|

    def focus_button(self, i):
        if self.box_button[i].state == 0:
            self.box_button[i].set_state_off_focus()
        #|
    def unfocus_button(self, i):
        if self.box_button[i].state == 1:
            self.box_button[i].set_state_off()
        #|
    def turnon_button(self, i):
        if self.box_button[i].state in {0, 1}:
            self.box_button[i].set_state_on()
        #|
    def turnoff_button(self, i):
        if self.box_button[i].state == 2:
            self.box_button[i].set_state_off()
        #|

    def inside(self, mouse):
        box_button = self.box_button
        if mouse[0] < box_button[0].L: return False
        if mouse[0] > box_button[self.row_length - 1].R: return False
        if mouse[1] > box_button[0].T: return False
        if mouse[1] < box_button[-1].B: return False
        return True
        #|
    def inside_evt(self):
        self.active_index = self.r_focus_index(MOUSE)
        if self.active_index != None:
            self.focus_button(self.active_index)
            Admin.REDRAW()
        self.is_trigger_enable = True
        #|
    def outside_evt(self):
        if hasattr(self, "active_index"):
            if self.active_index != None:
                self.unfocus_button(self.active_index)
                Admin.REDRAW()
        #|

    def modal(self):
        i = self.r_focus_index(MOUSE)
        if i != self.active_index:

            if self.active_index != None:
                self.unfocus_button(self.active_index)
                Admin.REDRAW()

            self.active_index = i
            self.is_trigger_enable = True

            if i != None:
                self.focus_button(i)
                Admin.REDRAW()

        if i == None: return False

        allow_trigger = self.is_trigger_enable
        if not allow_trigger:
            if EVT_TYPE[0] == "TIMER_REPORT": pass
            else:
                if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                    self.is_trigger_enable = True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if allow_trigger:
            if TRIGGER['click']():
                self.is_trigger_enable = False
                if is_first_press('click') == False:
                    self.set(_last_bool_state[0], i)
                else:
                    boo = not self.get(i)
                    self.set(boo, i)
                    _last_bool_state[0] = boo
                Admin.REDRAW()
                return True
        return False
        #|

    @ catch
    def to_modal_rm(self):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_all", self.evt_area_reset_all),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ], override_name={"dd_cut":"Copy Identifier"}, title=self.rna.name)
        #|

    @ catch
    def evt_area_cut(self, is_report=True):

        kill_evt_except()
        bpy.context.window_manager.clipboard = ", ".join("1" if v else "0"  for v in self.get())
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        if self.active_index == None:
            self.evt_area_cut(is_report)
            return

        kill_evt_except()
        bpy.context.window_manager.clipboard = "1" if self.get(self.active_index) else "0"
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            array = calc_vec(s)
            ll = len(array)
            if ll == 1 and self.active_index != None:
                self.set(bool(array[0]), self.active_index)
            else:
                if ll > self.array_length: array = array[: self.array_length]
                self.set([bool(v)  for v in array], (0, ll))
            Admin.REDRAW()
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self):

        kill_evt_except()
        Admin.REDRAW()
        i = self.active_index
        if i == None:
            self.set(self.r_default_array(), (0, self.array_length))
        else:
            self.set(self.r_default_array()[i], i)
        #|
    @ catch
    def evt_area_reset_all(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_array(), (0, self.array_length))
        #|
    @ catch
    def evt_area_detail(self):

        kill_evt_except()
        Detail(Detail.r_rna_info(self.rna))
        #|

    def dxy(self, dx, dy):
        for e in self.box_button: e.dxy_upd(dx, dy)
    def draw_box(self):
        for e in self.box_button: e.bind_draw()
        #|
    def draw_blf(self): pass

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.array_tuple == tuple(self.get()): return
        array_tuple = tuple(self.get())



        for r, v in enumerate(array_tuple):
            self.turnon_button(r)  if v == True else self.turnoff_button(r)

        self.array_tuple = array_tuple
        #|
    #|
    #|
class ButtonFloatVector(            # ButtonIntVector                                           
    ButtonIntVector):
    __slots__ = ()

    # <<< 1copy (0block_ButtonIntVector_init,, ${'"INT"':'rna.unit'}$)
    def __init__(self, w, rna, pp, subtype_override=None):
        self.w = w
        self.rna = rna
        self.array_length = rna.array_length

        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp

        self.box_button = GpuRim(COL_box_val, COL_box_val_rim)
        self.box_active = GpuBox(COL_box_val_fo)
        self.text_format = D_format[rna.unit]
        vv = getattr(self.pp, rna.identifier)
        self.blf_value = [BlfClip(self.text_format(v), v)  for v in vv]
        self.blf_value[0].color = COL_box_val_fg

        if subtype_override is None:
            if rna.subtype in D_subtype_display:
                self.draw_blf = self.i_draw_blf_subtype
                self.dxy = self.i_dxy_subtype
                self.blf_subtype = [Blf(tx)  for _, tx in zip(vv, D_subtype_display[rna.subtype])]
                self.blf_subtype[0].color = COL_box_button_fg_info
            else:
                self.draw_blf = self.i_draw_blf
                self.dxy = self.i_dxy
        else:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = [Blf(tx)  for _, tx in zip(vv, subtype_override)]
            self.blf_subtype[0].color = COL_box_button_fg_info

        self.draw_box = self.i_draw_box
        self.active_index = None
    # >>>

    def i_modal_drag(self):
        # <<< 1copy (0block_ButtonFloat_i_modal_drag_head,, $$)
        Admin.REDRAW()

        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = False
            W_HEAD[-1].fin()
            return
        if _end_trigger():
            W_HEAD[-1].fin()
            return

        dx, dy = r_mouse_dxy()
        if TRIGGER['valbox_drag_modal_fast']():
            dx *= _valbox_drag_fac * 10
        elif TRIGGER['valbox_drag_modal_slow']():
            dx *= _valbox_drag_fac * 0.1
        else:
            dx *= _valbox_drag_fac
        # >>>

        # /* 0block_ButtonFloatVector_i_modal_drag
        e = _blf_value[self.active_index]
        try: v_float = e.unclip_text + dx
        except:
            loop_mouse()
            return
        self.set(v_float, self.active_index, undo_push=False)
        if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
        # */
        loop_mouse()
        #|
    def i_modal_drag_array(self):
        # <<< 1copy (0block_ButtonFloat_i_modal_drag_head,, $$)
        Admin.REDRAW()

        if (EVT_TYPE[0] == 'ESC' and EVT_TYPE[1] == 'PRESS') or TRIGGER['esc']():
            _value_data["confirm"] = False
            W_HEAD[-1].fin()
            return
        if _end_trigger():
            W_HEAD[-1].fin()
            return

        dx, dy = r_mouse_dxy()
        if TRIGGER['valbox_drag_modal_fast']():
            dx *= _valbox_drag_fac * 10
        elif TRIGGER['valbox_drag_modal_slow']():
            dx *= _valbox_drag_fac * 0.1
        else:
            dx *= _valbox_drag_fac
        # >>>

        try: v_float = [_blf_value[r].unclip_text + dx  for r in _value_data["array_range"]]
        except:
            loop_mouse()
            return
        self.set(v_float, _value_data["array_index"], undo_push=False)
        if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1

        loop_mouse()
        #|

    def to_modal_drag_pre(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     'P.valbox_drag_fac_int': 'P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>
    def to_modal_drag(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     "('click')":"('valbox_drag')",
        #     'P.valbox_drag_fac_int': 'P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('valbox_drag')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('valbox_drag')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_drag_pre, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>
        W_HEAD[-1].modal = self.i_modal_drag
        #|
    def to_modal_media_left(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     'i_modal_drag_pre': 'i_modal_media',
        #     'P.valbox_drag_fac_int': 'P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>

        global _timer_button_fn
        def _timer_button_fn():
            # <<< 1copy (0block_ButtonFloatVector_i_modal_drag,, ${'+ dx':'- _valbox_drag_fac', 'loop_mouse()':''}$)
            e = _blf_value[self.active_index]
            try: v_float = e.unclip_text - _valbox_drag_fac
            except:
                
                return
            self.set(v_float, self.active_index, undo_push=False)
            if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
            # >>>

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|
    def to_modal_media_right(self):

        # <<< 1copy (0block_ButtonInt_to_modal_drag,, ${
        #     'i_modal_drag_pre': 'i_modal_media',
        #     'P.valbox_drag_fac_int': 'P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01'}$)
        global _end_trigger, _valbox_drag_fac, _blf_value, _value_data
        blf_value = self.blf_value

        if isinstance(blf_value, list):
            if hasattr(blf_value[0], "unclip_text") and is_value(blf_value[0].unclip_text): pass
            else: return

            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            _value_data["values"] = [(e.unclip_text, e.text)  for e in self.blf_value]

            if self.is_dark() is False: self.box_active.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        elif hasattr(blf_value, "unclip_text") and is_value(blf_value.unclip_text):
            _end_trigger = r_end_trigger('click')
            init_loop_mouse('NONE')
            _xy[0] = 0
            _valbox_drag_fac = P.valbox_drag_fac_float * (self.step  if hasattr(self, "step") else self.rna.step) * 0.01
            _blf_value = blf_value
            _value_data = {'confirm': True}
            e = self.blf_value
            _value_data["values"] = [(e.unclip_text, e.text)]

            if self.is_dark() is False: self.box_button.color = COL_box_val_active
            Admin.REDRAW()
            if hasattr(self, "to_modal_drag_callfront"): self.to_modal_drag_callfront()
            Head(self, self.i_modal_media, self.end_modal_drag)
        else: return

        MODAL_DRAG_STATE[0] = 0
        # >>>

        global _timer_button_fn
        def _timer_button_fn():
            # <<< 1copy (0block_ButtonFloatVector_i_modal_drag,, ${'+ dx':'+ _valbox_drag_fac', 'loop_mouse()':''}$)
            e = _blf_value[self.active_index]
            try: v_float = e.unclip_text + _valbox_drag_fac
            except:
                
                return
            self.set(v_float, self.active_index, undo_push=False)
            if MODAL_DRAG_STATE[0] == 0: MODAL_DRAG_STATE[0] = 1
            # >>>

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|

    @ catch
    def evt_area_cut(self, is_report=True):

        kill_evt_except()
        s = ""
        fac = r_unit_factor(self.unit  if hasattr(self, "unit") else self.rna.unit, self.text_format)
        for e in self.get(): s += f'{value_to_display(e / fac)}, '

        bpy.context.window_manager.clipboard = s[: -2]
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        if self.active_index == None:
            self.evt_area_cut(is_report)
            return

        kill_evt_except()
        bpy.context.window_manager.clipboard = value_to_display(
            self.get()[self.active_index] / r_unit_factor(self.unit  if hasattr(self, "unit") else self.rna.unit, self.text_format))
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        fac = r_unit_factor(self.unit  if hasattr(self, "unit") else self.rna.unit, self.text_format)
        try:
            Admin.REDRAW()
            if s.strip()[: 1] == "#":
                self.set(s, 0  if self.active_index == None else self.active_index)
                return

            array = calc_vec(s)
            ll = len(array)
            if ll == 1 and self.active_index != None:
                self.set(float(array[0] * fac), self.active_index)
            else:
                if ll > self.array_length: array = array[: self.array_length]
                self.set([float(v * fac)  for v in array], (0, ll))
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_format(self):
        if self.rna.subtype != "EULER": return

        kill_evt_except()
        if self.text_format.__name__.find("deg") == -1:
            self.text_format = UnitSystem.rs_format_deg
            # self.rna.vmd_is_radian = False
        else:
            self.text_format = UnitSystem.format_float
            # self.rna.vmd_is_radian = True

        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return

        for e, v in zip(self.blf_value, self.get()):
            e.unclip_text = v
            e.text = self.text_format(v)
        Admin.REDRAW()
        #|
    #|
    #|
class ButtonFloatVectorColor(ButtonFloatVector):
    __slots__ = 'update_callback', 'callback_enable'

    def set(self, v, index, refresh=True, undo_push=True):
        super().set(v, index, refresh)
        self.upd_data()
        if self.callback_enable: self.update_callback()
        #|
    #|
    #|
class ButtonString:
    __slots__ = (
        'w',
        'rna',
        'pp',
        'r_pp',
        'r_object',
        'r_datapath_head',
        'box_button',
        'blf_subtype',
        'blf_value',
        'b_str',
        'row_count',
        'font_id',
        'headkey',
        'draw_blf',
        'dxy',
        'set_callback',
        'poll')

    def __init__(self, w, rna, pp, subtype_override=None):
        if subtype_override == "LINES":
            self.__class__ = ButtonStringXY
            self.__init__(w, rna, pp)
            return
        subtype = rna.subtype  if hasattr(rna, "subtype") else None
        if subtype in {"BYTE_STRING", "LINES"}:
            self.__class__ = ButtonStringXY
            self.__init__(w, rna, pp, subtype_override)
            return

        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp

        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        v = self.get()
        self.blf_value = BlfClipColor(v, v, 0, 0, COL_box_text_fg)
        self.font_id = FONT0

        if subtype_override is None:
            if subtype in D_subtype_display:
                self.draw_blf = self.i_draw_blf_subtype
                self.dxy = self.i_dxy_subtype
                self.blf_subtype = BlfColor(D_subtype_display[rna.subtype], 0, 0, COL_box_button_fg_info)
            else:
                self.draw_blf = self.i_draw_blf
                self.dxy = self.i_dxy
        else:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = BlfColor(subtype_override[0], 0, 0, COL_box_button_fg_info)
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        blf_value.x = L0 + D_SIZE['font_main_dx']
        blf_value.y = B0 + D_SIZE['font_main_dy']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(
            blf_value.unclip_text, blf_value.x, R0 - D_SIZE['font_main_dx'])

        # <<< 1copy (0block_ButtonInt_init_subtype,, $$)
        if hasattr(self, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            self.blf_subtype.y = T - SIZE_border[3] - D_SIZE['font_label_dT']
            self.blf_subtype.x = L - D_SIZE['font_label_dx'] - ceil(blfDimen(FONT0, self.blf_subtype.text)[0])
        # >>>
        return B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_default_value(self): return self.rna.default

    def is_dark(self): return self.blf_value.color == COL_box_text_fg_ignore
    def dark(self):
        if self.box_button.color != COL_box_text_ignore:
            self.box_button.color = COL_box_text_ignore
            self.box_button.color_rim = COL_box_text_rim_ignore
            self.blf_value.color = COL_box_text_fg_ignore
            Admin.REDRAW()
        #|
    def light(self):
        if self.box_button.color != COL_box_text:
            self.box_button.color = COL_box_text
            self.box_button.color_rim = COL_box_text_rim
            self.blf_value.color = COL_box_text_fg
            Admin.REDRAW()
        #|

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        if self.is_dark() is False:
            self.box_button.color = COL_box_text_active
            Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.is_dark() is False:
            self.box_button.color = COL_box_text
            Admin.REDRAW()
        #|

    def modal(self):
        # /* 0block_ButtonString_modal
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.to_dropdown()#ref
            return True
        # */
        return False
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        v = self.get()
        if isinstance(v, bytes): v = v.decode('utf-8')
        if isinstance(self.blf_value, list):
            w = DropDownStringXY(self, self.box_button.r_LRBT(), v,
                font_id=self.font_id, killevt=killevt, select_all=select_all)

            a = w.areas[0]
            e0 = self.blf_value[0]
            a.get_pan_text_data()
            a.pan_text_override(e0.x - a.line_x,
                (self.headkey - a.headkey) * SIZE_widget[0] + e0.y - a.blf_text[0].y)

            def end_dropdown():
                self.blf_value[:] = a.blf_text
                x = a.line_x
                for e in self.blf_value: e.x = x
                self.headkey = a.headkey

            w.data["fin_callfront"] = end_dropdown
            return w
        else:
            return DropDownString(self, self.box_button.r_LRBT(), v)
        #|

    def to_modal_rm(self):


        items = [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ]
        append_rm_item_operator(items, self.rna)

        DropDownRMKeymap(self, MOUSE, items, title=self.rna.name)
        #|

    def to_area_pan_text(self):

        w = self.to_dropdown(killevt=False, select_all=False)
        w.areas[0].to_modal_pan_text_from_block()
        #|

    @ catch
    def evt_area_cut(self, is_report=True):
        self.evt_area_copy(is_report)
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        v = self.get()
        bpy.context.window_manager.clipboard = v.decode('utf-8')  if isinstance(v, bytes) else f'{v}'
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            self.set(s)
            Admin.REDRAW()
        except:
            if is_report: report("Input Error")
        #|
    @ catch
    def evt_area_reset_single(self):
        kill_evt_except()

        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_reset_all(self):
        kill_evt_except()

        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_detail(self):

        kill_evt_except()
        Detail(Detail.r_rna_info(self.rna))
        #|

    def i_dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def i_dxy_subtype(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy

        self.blf_subtype.x += dx
        self.blf_subtype.y += dy
        #|

    def draw_box(self):
        self.box_button.bind_draw()
        #|
    def i_draw_blf(self):
        e = self.blf_value
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|
    def i_draw_blf_subtype(self):
        e = self.blf_value
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        e = self.blf_subtype
        blfSize(FONT0, D_SIZE['font_label'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def get(self): return getattr(self.pp, self.rna.identifier)
    def set(self, v, refresh=True, undo_push=True):
        oldvalue = getattr(self.pp, self.rna.identifier)
        if self.rna.subtype == "BYTE_STRING" and not isinstance(v, bytes): v = str.encode(v)
        setattr(self.pp, self.rna.identifier, v)
        if refresh: update_data()

        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
        #|
    def evt_undo_push(self, undo_push, oldvalue): pass

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return


        blf_value = self.blf_value
        v = getattr(self.pp, self.rna.identifier)
        blf_value.unclip_text = v
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class ButtonStringXY(               # ButtonString                                              
    ButtonString):
    __slots__ = ()

    def __init__(self, w, rna, pp, subtype_override=None):
        self.w = w
        self.rna = rna
        self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        v = getattr(pp, rna.identifier)
        self.blf_value = []
        self.b_str = v
        self.row_count = 5
        self.font_id = FONT0

        if subtype_override is None:
            if rna.subtype in D_subtype_display:
                self.draw_blf = self.i_draw_blf_subtype
                self.dxy = self.i_dxy_subtype
                self.blf_subtype = BlfColor(D_subtype_display[rna.subtype], 0, 0, COL_box_button_fg_info)
            else:
                self.draw_blf = self.i_draw_blf
                self.dxy = self.i_dxy
        else:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = BlfColor(subtype_override[0], 0, 0, COL_box_button_fg_info)
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        h = SIZE_widget[0]
        B = T - D_SIZE['widget_full_h'] - (self.row_count - 1) * h
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])

        font_dx, font_dy, font_dT = r_widget_font_dx_dy_dT(self.font_id, h)
        x = self.box_button.inner[0] + font_dx
        blf_value.clear()
        self.headkey = 0
        count = self.row_count + 1
        if isinstance(self.b_str, str):
            lines = self.b_str.split('\n', count)
        else:
            lines = self.b_str.decode('utf-8').split('\n', count)
        if len(lines) > count: del lines[-1]

        y = self.box_button.inner[3] - font_dT
        for line in lines:
            blf_value.append(Blf(line, x, y))
            y -= h

        # <<< 1copy (0block_ButtonInt_init_subtype,, $$)
        if hasattr(self, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            self.blf_subtype.y = T - SIZE_border[3] - D_SIZE['font_label_dT']
            self.blf_subtype.x = L - D_SIZE['font_label_dx'] - ceil(blfDimen(FONT0, self.blf_subtype.text)[0])
        # >>>
        return B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h'] + (self.row_count - 1) * SIZE_widget[0]

    def is_dark(self): return False

    def i_dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)

        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|
    def i_dxy_subtype(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)

        for e in self.blf_value:
            e.x += dx
            e.y += dy

        self.blf_subtype.x += dx
        self.blf_subtype.y += dy
        #|
    def i_draw_blf(self):
        font_id = self.font_id
        sci_x, sci_y, sci_w, sci_h = scissor_get()
        scissor_set(*r_intersect_scissor(sci_x, sci_y, sci_w, sci_h, *self.box_button.inner))
        blfSize(font_id, D_SIZE['font_main'])
        blfColor(font_id, *COL_box_text_fg)
        for e in self.blf_value:
            blfPos(font_id, e.x, e.y, 0)
            blfDraw(font_id, e.text)
        scissor_set(sci_x, sci_y, sci_w, sci_h)
        #|
    def i_draw_blf_subtype(self):
        font_id = self.font_id
        sci_x, sci_y, sci_w, sci_h = scissor_get()
        scissor_set(*r_intersect_scissor(sci_x, sci_y, sci_w, sci_h, *self.box_button.inner))
        blfSize(font_id, D_SIZE['font_main'])
        blfColor(font_id, *COL_box_text_fg)
        for e in self.blf_value:
            blfPos(font_id, e.x, e.y, 0)
            blfDraw(font_id, e.text)
        scissor_set(sci_x, sci_y, sci_w, sci_h)

        e = self.blf_subtype
        blfSize(FONT0, D_SIZE['font_label'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.b_str == getattr(self.pp, self.rna.identifier): return


        blf_value = self.blf_value
        v = getattr(self.pp, self.rna.identifier)
        self.b_str = v

        line_h = SIZE_widget[0]
        font_dx, font_dy, font_dT = r_widget_font_dx_dy_dT(self.font_id, line_h)
        x = self.box_button.inner[0] + font_dx
        blf_value.clear()
        self.headkey = 0
        count = self.row_count + 1
        if isinstance(v, str):
            lines = v.split('\n', count)
        else:
            lines = v.decode('utf-8').split('\n', count)
        if len(lines) > count: del lines[-1]

        y0 = self.box_button.inner[3] - font_dT
        for line in lines:
            blf_value.append(Blf(line, x, y0))
            y0 -= line_h
        #|
    #|
    #|
class ButtonStringXYRead(           # ButtonStringXY                                            
    ButtonStringXY):
    __slots__ = 'beam_index', 'box_selection', 'box_selection1', 'box_selection2'

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        self.pp = pp
        self.box_button = GpuRim(COL_box_text_read, COL_box_text_read_rim)

        self.blf_value = []
        self.b_str = getattr(pp, rna.identifier)
        self.row_count = 9
        self.font_id = FONT0

        self.draw_blf = self.i_draw_blf
        self.dxy = self.i_dxy

        self.beam_index = [(0, 0), (0, 0)]
        self.box_selection = GpuBox(COL_box_text_selection)
        self.box_selection1 = GpuBox(COL_box_text_selection)
        self.box_selection2 = GpuBox(COL_box_text_selection)
        self.box_selection.upd()
        self.box_selection1.upd()
        self.box_selection2.upd()
        #|

    def inside_evt(self): pass
    def outside_evt(self): pass

    def modal(self):
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['dd_selection_shift']():
            self.to_dropdown_selection_shift()
            return True
        if TRIGGER['dd_selection']():
            self.to_dropdown_selection()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True
        return False
        #|

    def to_modal_rm(self):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_copy", self.evt_area_copy),
            ("detail", self.evt_area_detail),
        ], title=self.rna.name)
        #|
    def to_dropdown(self, killevt=False, select_all=False):

        v = self.get()
        if isinstance(v, str): pass
        else: v = v.decode('utf-8')

        w = DropDownStringXY(self, self.box_button.r_LRBT(), v,
            font_id=self.font_id, killevt=killevt, select_all=select_all)

        a = w.areas[0]
        a.box_text.color = COL_box_text_read
        a.box_text.color_rim = COL_box_text_read_rim
        a.font_color = COL_box_text_read_fg
        e0 = self.blf_value[0]
        a.get_pan_text_data()
        a.pan_text_override(e0.x - a.line_x,
            (self.headkey - a.headkey) * SIZE_widget[0] + e0.y - a.blf_text[0].y)

        def end_dropdown():
            self.blf_value[:] = a.blf_text
            x = a.line_x
            for e in self.blf_value: e.x = x
            self.headkey = a.headkey
            y0, x0, y1, x1 = a.tex.beam
            self.beam_index[0] = y0, x0
            self.beam_index[1] = y1, x1
            self.box_selection.LRBT_upd(*a.box_selection.r_LRBT())
            self.box_selection1.LRBT_upd(*a.box_selection1.r_LRBT())
            self.box_selection2.LRBT_upd(*a.box_selection2.r_LRBT())

        w.data["fin_callfront"] = end_dropdown
        return w
        #|
    def to_dropdown_selection(self):

        w = self.to_dropdown(killevt=False, select_all=False)
        a0 = w.areas[0]
        a0.to_modal_selection(lambda: a0.evt_cancel())
        #|
    def to_dropdown_selection_shift(self):

        w = self.to_dropdown(killevt=False, select_all=False)
        a0 = w.areas[0]
        i0, i1 = self.beam_index
        a0.set_highlight(*i0, *i1)
        a0.to_modal_selection_shift(lambda: a0.evt_cancel())
        #|
    def to_area_pan_text(self):

        w = self.to_dropdown(killevt=False, select_all=False)
        a0 = w.areas[0]
        i0, i1 = self.beam_index
        a0.set_highlight(*i0, *i1)
        a0.to_modal_pan_text_from_block()
        #|

    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        v = self.get()
        v = v.decode('utf-8')  if isinstance(v, bytes) else f'{v}'
        i0, i1 = self.beam_index
        if i0 == i1:
            bpy.context.window_manager.clipboard = v
        else:
            tex = Text(v)
            bpy.context.window_manager.clipboard = tex.region_as_string()
            del tex

        if is_report: report("Copy to Clipboard")
        #|

    def i_dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_selection.dxy_upd(dx, dy)
        self.box_selection1.dxy_upd(dx, dy)
        self.box_selection2.dxy_upd(dx, dy)

        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|

    def draw_box(self):
        self.box_button.bind_draw()
        sci_x, sci_y, sci_w, sci_h = scissor_get()
        scissor_set(*r_intersect_scissor(sci_x, sci_y, sci_w, sci_h, *self.box_button.inner))
        self.box_selection.bind_draw()
        self.box_selection1.bind_draw()
        self.box_selection2.bind_draw()
        scissor_set(sci_x, sci_y, sci_w, sci_h)
        #|
    def i_draw_blf(self):
        font_id = self.font_id
        sci_x, sci_y, sci_w, sci_h = scissor_get()
        scissor_set(*r_intersect_scissor(sci_x, sci_y, sci_w, sci_h, *self.box_button.inner))
        blfSize(font_id, D_SIZE['font_main'])
        blfColor(font_id, *COL_box_text_read_fg)
        for e in self.blf_value:
            blfPos(font_id, e.x, e.y, 0)
            blfDraw(font_id, e.text)
        scissor_set(sci_x, sci_y, sci_w, sci_h)
        #|

    #|
    #|
class ButtonStringObjectPath(       # ButtonString                                              
    ButtonString):
    __slots__ = 'box_icon_arrow', 'r_file'

    def __init__(self, w, rna, pp, r_file):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        self.box_icon_arrow = GpuImg_unfold()
        v = getattr(self.pp, rna.identifier)
        self.blf_value = BlfClipColor("", "", 0, 0, COL_box_text_fg)
        self.font_id = FONT0
        self.r_file = r_file
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        self.box_icon_arrow.LRBT_upd(R0 - SIZE_widget[0], R0, B0, T0)

        blf_value.x = L0 + D_SIZE['font_main_dx']
        blf_value.y = B0 + D_SIZE['font_main_dy']
        blf_value.unclip_text = ""
        blf_value.text = ""
        self.upd_data()
        return B
        #|

    def inside_evt(self):
        # <<< 1copy (0block_ButtonEnumObject_modal_update_picker_focus,, ${
        #     'Admin.REDRAW()': '',
        #     'GpuImg_object_picker_focus': 'GpuImg_unfold',
        #     'GpuImg_object_picker': 'GpuImg_unfold'
        # }$)
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                        self.box_icon_arrow.__class__ = GpuImg_delete_focus
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    
        else:
            region = 0
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    
        # >>>
        Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.is_dark() is True: return

        self.box_button.color = COL_box_text
        if self.get():
            self.box_icon_arrow.__class__ = GpuImg_delete
        else:
            self.box_icon_arrow.__class__ = GpuImg_unfold
        Admin.REDRAW()
        #|

    def modal(self):
        # <<< 1copy (0block_ButtonEnumObject_modal_update_picker_focus,, ${
        #     'GpuImg_object_picker_focus': 'GpuImg_unfold',
        #     'GpuImg_object_picker': 'GpuImg_unfold'
        # }$)
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                        self.box_icon_arrow.__class__ = GpuImg_delete_focus
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        Admin.REDRAW()

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    Admin.REDRAW()
        else:
            region = 0
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        Admin.REDRAW()

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    Admin.REDRAW()
        # >>>

        # <<< 1copy (0block_ButtonString_modal,, ${'self.to_dropdown()#ref':'self.evt_click(region)'}$)
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.evt_click(region)
            return True
        # >>>
        return False
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        cache_file = self.r_file()
        if cache_file:
            items = [Name(e.path)  for e in cache_file.object_paths]
        else:
            items = None

        return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, items=items, fixed_width=True)
        #|

    def evt_click(self, region=0):
        if region == 0:
            self.to_dropdown()
        else:
            if getattr(self.pp, self.rna.identifier):
                self.evt_delete_object()
            else:
                self.to_dropdown()
        #|
    def evt_delete_object(self):

        kill_evt_except()
        try:
            self.set("")
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Unexpected error, please report to the author: 02\n{ex}')
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_icon_arrow.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        self.box_icon_arrow.bind_draw()
        #|
    def draw_blf(self):
        e = self.blf_value
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def set(self, v, refresh=True, undo_push=True):
        oldvalue = getattr(self.pp, self.rna.identifier)
        cache_file = self.r_file()
        if cache_file and v:
            if v not in {e.path  for e in cache_file.object_paths}: return

        setattr(self.pp, self.rna.identifier, v)
        if refresh: update_data()
        self.evt_undo_push(undo_push, oldvalue)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return


        blf_value = self.blf_value
        v = getattr(self.pp, self.rna.identifier)
        if v:
            if self.box_icon_arrow.__class__ != GpuImg_delete:
                self.box_icon_arrow.__class__ = GpuImg_delete
        else:
            if self.box_icon_arrow.__class__ != GpuImg_unfold:
                self.box_icon_arrow.__class__ = GpuImg_unfold

        blf_value.unclip_text = v

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_icon_arrow.L - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class ButtonStringFile(             # ButtonStringObjectPath                                    
    ButtonStringObjectPath):
    __slots__ = ()

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        self.box_icon_arrow = GpuImg_FILE_FOLDER()
        v = getattr(self.pp, rna.identifier)
        self.blf_value = BlfClipColor("", "", 0, 0, COL_box_text_fg)
        self.font_id = FONT0
        #|

    def inside_evt(self):
        # <<< 1copy (0block_ButtonStringFile_update_button_focus,, ${'Admin.REDRAW()':''}$)
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.box_icon_arrow.__class__ != GpuImg_FILE_FOLDER_focus:
                    self.box_icon_arrow.__class__ = GpuImg_FILE_FOLDER_focus
                    

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    
        else:
            region = 0
            if self.is_dark() is False:
                if self.box_icon_arrow.__class__ != GpuImg_FILE_FOLDER:
                    self.box_icon_arrow.__class__ = GpuImg_FILE_FOLDER
                    

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    
        # >>>
        Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.is_dark() is True: return

        self.box_button.color = COL_box_text
        self.box_icon_arrow.__class__ = GpuImg_FILE_FOLDER
        Admin.REDRAW()
        #|

    def modal(self):
        # /* 0block_ButtonStringFile_update_button_focus
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.box_icon_arrow.__class__ != GpuImg_FILE_FOLDER_focus:
                    self.box_icon_arrow.__class__ = GpuImg_FILE_FOLDER_focus
                    Admin.REDRAW()

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    Admin.REDRAW()
        else:
            region = 0
            if self.is_dark() is False:
                if self.box_icon_arrow.__class__ != GpuImg_FILE_FOLDER:
                    self.box_icon_arrow.__class__ = GpuImg_FILE_FOLDER
                    Admin.REDRAW()

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    Admin.REDRAW()
        # */

        # <<< 1copy (0block_ButtonString_modal,, ${'self.to_dropdown()#ref':'self.evt_click(region)'}$)
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.evt_click(region)
            return True
        # >>>
        return False
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        return DropDownString(self, self.box_button.r_LRBT(), self.get())
        #|
    def to_filebrowser(self):


        OpScanFile.end_fn = self.set
        bpy.ops.wm.vmd_scan_file("INVOKE_DEFAULT", filepath=self.get())
        #|

    def evt_click(self, region=0):
        if region == 0:
            self.to_dropdown()
        else:
            self.to_filebrowser()
        #|

    def set(self, v, refresh=True, undo_push=True):
        oldvalue = getattr(self.pp, self.rna.identifier)
        if self.rna.subtype == "BYTE_STRING" and not isinstance(v, bytes): v = str.encode(v)
        setattr(self.pp, self.rna.identifier, v)
        if refresh: update_data()

        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return


        blf_value = self.blf_value
        v = getattr(self.pp, self.rna.identifier)
        blf_value.unclip_text = v

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_icon_arrow.L - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class ButtonStringVector(           # ButtonString                                              
    ButtonString):
    __slots__ = ()

    def __init__(self, w, rna, pp, subtype_override=None):
        subtype = rna.subtype  if hasattr(rna, "subtype") else None
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp

        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        v = self.get()
        self.blf_value = BlfClipColor("", "", 0, 0, COL_box_text_fg)
        self.font_id = FONT0

        if subtype_override is None:
            if subtype in D_subtype_display:
                self.draw_blf = self.i_draw_blf_subtype
                self.dxy = self.i_dxy_subtype
                self.blf_subtype = BlfColor(D_subtype_display[rna.subtype], 0, 0, COL_box_button_fg_info)
            else:
                self.draw_blf = self.i_draw_blf
                self.dxy = self.i_dxy
        else:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = BlfColor(subtype_override[0], 0, 0, COL_box_button_fg_info)
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        blf_value.x = L0 + D_SIZE['font_main_dx']
        blf_value.y = B0 + D_SIZE['font_main_dy']
        v = [v  for v in getattr(self.pp, self.rna.identifier)]
        blf_value.unclip_text = v
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(rs_format_float6_vec(v),
            blf_value.x, R0 - D_SIZE['font_main_dx'])

        # <<< 1copy (0block_ButtonInt_init_subtype,, $$)
        if hasattr(self, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            self.blf_subtype.y = T - SIZE_border[3] - D_SIZE['font_label_dT']
            self.blf_subtype.x = L - D_SIZE['font_label_dx'] - ceil(blfDimen(FONT0, self.blf_subtype.text)[0])
        # >>>
        return B
        #|

    def r_default_value(self): return self.rna.default_array

    def to_dropdown(self, killevt=True, select_all=None):

        return DropDownString(self, self.box_button.r_LRBT(), ", ".join("{:.16f}".format(v)  for v in self.get()))
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        s = ""
        fac = r_unit_factor(self.unit  if hasattr(self, "unit") else self.rna.unit, None)
        for e in self.get(): s += f'{value_to_display(e / fac)}, '

        bpy.context.window_manager.clipboard = s[: -2]
        if is_report: report("Copy to Clipboard")
        #|

    def set(self, v, refresh=True, undo_push=True):
        oldvalue = getattr(self.pp, self.rna.identifier)
        array_length = self.rna.array_length
        if isinstance(v, str): v = calc_vec(v)

        le = len(v)
        if le < array_length:
            new_v = [0.0] * array_length
            new_v[ : le] = v
            v = new_v
        else:
            v = v[ : array_length]

        v = Vector(v).normalized()
        setattr(self.pp, self.rna.identifier, list(v))
        if refresh: update_data()

        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return


        blf_value = self.blf_value
        v = [v  for v in getattr(self.pp, self.rna.identifier)]
        blf_value.unclip_text = v
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(rs_format_float6_vec(v),
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class ButtonStringColorHex(ButtonString):
    __slots__ = 'set_callfront'

    def set(self, v, refresh=True, undo_push=True):
        self.set_callfront(v.strip().replace(" ", "").replace("0x", "").replace("#", ""))
        #|
    #|
    #|
class ButtonFn:
    __slots__ = (
        'w',
        'rna',
        'fn',
        'box_button',
        'blf_value',
        'is_trigger_enable',
        'is_repeat',
        'set_callback',
        'poll')

    def __init__(self, w, rna, fn):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.is_repeat = True  if hasattr(rna, "is_repeat") and rna.is_repeat else False
        self.box_button = GpuButton()
        self.blf_value = BlfClipColor("", rna.default, 0, 0, COL_box_button_fg)
        #|

    def init_bat(self, L, R, T):
        widget_rim = SIZE_border[3]
        B = T - D_SIZE['widget_full_h']
        if hasattr(self.rna, "size") and self.rna.size != 0:
            if self.rna.size < 0:
                L = max(L, round(R - widget_rim + SIZE_widget[0] * self.rna.size - widget_rim))
            else:
                R = min(R, round(L + widget_rim + SIZE_widget[0] * self.rna.size + widget_rim))

        self.box_button.LRBT_upd(L, R, B, T, widget_rim)
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        d = D_SIZE['font_main_dx'] + SIZE_border[3]
        blf_value = self.blf_value
        blf_value.text = r_blf_clipping_end(self.rna.default, d, R - L - d)

        blf_value.x = floor((R + L - blfDimen(FONT0, blf_value.text)[0]) / 2)
        blf_value.y = B + widget_rim + D_SIZE['font_main_dy']
        return B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_override_width(self): return SIZE_border[3] * 2 + round(abs(SIZE_widget[0] * self.rna.size))
    def set_button_text(self, s):
        e = self.box_button
        L = e.L
        R = e.R
        B = e.B
        self.blf_value.text = s
        blfSize(FONT0, D_SIZE['font_main'])
        self.blf_value.x = floor((R + L - blfDimen(FONT0, self.blf_value.text)[0]) / 2)
        self.blf_value.y = B + SIZE_border[3] + D_SIZE['font_main_dy']
        #|

    def is_dark(self): return self.box_button.is_dark()
    def dark(self):
        self.box_button.dark()
        self.blf_value.color = COL_box_button_fg_ignore
        #|
    def light(self):
        self.box_button.light()
        self.blf_value.color = COL_box_button_fg
        #|

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        Admin.REDRAW()
        self.box_button.set_state_focus()
        self.is_trigger_enable = True
        #|
    def outside_evt(self):
        if self.is_repeat:
            # <<< 1copy (0block_unreg_timer_button_safe,, $$)
            if timer_isreg(timer_button):
                timer_unreg(timer_button)

            # >>>
            # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
            if timer_isreg(timer_hold):
                timer_unreg(timer_hold)

            # >>>
        Admin.REDRAW()
        self.box_button.set_state_default()
        #|

    def modal(self):
        if self.is_dark(): return False
        if self.is_trigger_enable is True:
            if TRIGGER['click']():
                Admin.REDRAW()
                self.is_trigger_enable = False
                self.box_button.set_state_press()
                self.fn()  if self.fn.__defaults__ is None else self.fn(self)
                if self.is_repeat: self.reg_repeat_timer()
                return True
        elif EVT_TYPE[0] == "TIMER_REPORT": pass
        else:
            if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                if self.is_repeat:
                    # <<< 1copy (0block_unreg_timer_button_safe,, $$)
                    if timer_isreg(timer_button):
                        timer_unreg(timer_button)

                    # >>>
                    # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
                    if timer_isreg(timer_hold):
                        timer_unreg(timer_hold)

                    # >>>
                self.is_trigger_enable = True
                self.box_button.set_state_focus()
                Admin.REDRAW()

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True
        return False
        #|

    def to_modal_rm(self):

        if not self.rna: return

        items = [("detail", self.evt_area_detail)]
        append_rm_item_operator(items, self.rna)

        DropDownRMKeymap(self, MOUSE, items, title=self.rna.name)
        #|
    def evt_area_detail(self):

        kill_evt_except()
        if not self.rna: return
        Detail(Detail.r_rna_info(self.rna))
        #|

    def reg_repeat_timer(self):
        global _timer_button_fn
        _timer_button_fn = self.fn

        _timer_button_fn()
        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        #|
    def draw_blf(self):
        e = self.blf_value
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self): pass
    #|
    #|
class ButtonFnFreeSize(             # ButtonFn                                                  
    ButtonFn):
    __slots__ = 'height'

    def __init__(self, w, rna, fn, font_size, height):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.is_repeat = True  if hasattr(rna, "is_repeat") and rna.is_repeat else False
        self.box_button = GpuButton()
        self.height = height

        # <<< 1copy (init_blf_clipping_end,, ${"D_SIZE['font_size']":'font_size'}$)
        blfSize(FONT0, font_size)
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        font_dx, font_dy, font_dT = r_widget_font_dx_dy_dT(FONT0, height)
        d = font_dx + SIZE_border[3]
        self.blf_value = BlfClipColor(r_blf_clipping_end(
            rna.default, d, D_SIZE['widget_width'] - d), rna.default, 0, 0, COL_box_button_fg)
        self.blf_value.size = font_size
        #|

    def init_bat(self, L, R, T):
        widget_rim = SIZE_border[3]
        B = T - self.height - widget_rim - widget_rim
        if hasattr(self.rna, "size") and self.rna.size != 0:
            if self.rna.size < 0:
                L = max(L, round(R - widget_rim + self.height * self.rna.size - widget_rim))
            else:
                R = min(R, round(L + widget_rim + self.height * self.rna.size + widget_rim))
        self.box_button.LRBT_upd(L, R, B, T, widget_rim)
        blfSize(FONT0, self.blf_value.size)
        self.blf_value.x = floor((R + L - blfDimen(FONT0, self.blf_value.text)[0]) / 2)
        self.blf_value.y = B + widget_rim + r_widget_font_dx_dy_dT(FONT0, self.height)[1]
        return B
        #|
    def r_height(self, width): return self.height + SIZE_border[3] * 2
    def r_override_width(self): return SIZE_border[3] * 2 + round(abs(self.height * self.rna.size))

    def draw_blf(self):
        e = self.blf_value
        blfSize(FONT0, e.size)
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|
    #|
    #|
class ButtonFnImg(                  # ButtonFn                                                  
    ButtonFn):
    __slots__ = 'box_img', 'imgLight', 'imgDark'

    def __init__(self, w, rna, fn, imgLight, imgDark=None):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.imgLight = imgLight
        self.imgDark = imgDark
        self.is_repeat = True  if hasattr(rna, "is_repeat") and rna.is_repeat else False
        self.box_button = GpuButton()
        self.box_img = getattr(blg, imgLight)()
        #|

    def init_bat(self, L, R, T):
        widget_rim = SIZE_border[3]
        B = T - D_SIZE['widget_full_h']
        if hasattr(self.rna, "size") and self.rna.size != 0:
            if self.rna.size < 0:
                L = max(L, round(R - widget_rim + SIZE_widget[0] * self.rna.size - widget_rim))
            else:
                R = min(R, round(L + widget_rim + SIZE_widget[0] * self.rna.size + widget_rim))
        self.box_button.LRBT_upd(L, R, B, T, widget_rim)
        self.box_img.LRBT_upd(*self.box_button.inner)
        return B
        #|

    def is_dark(self): return self.box_button.__class__.__name__ == self.imgDark
    def dark(self):
        if self.box_img.__class__.__name__ == self.imgDark: return
        self.box_img.__class__ = getattr(blg, self.imgDark)
        self.box_img.upd()
        Admin.REDRAW()
        #|
    def light(self):
        if self.box_img.__class__.__name__ == self.imgLight: return
        self.box_img.__class__ = getattr(blg, self.imgLight)
        self.box_img.upd()
        Admin.REDRAW()
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_img.dxy_upd(dx, dy)
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        self.box_img.bind_draw()
        #|
    def draw_blf(self): pass
    #|
    #|
class ButtonFnImgHover(             # ButtonFn                                                  
    ButtonFn):
    __slots__ = 'box_hover', 'imgLight', 'imgDark'

    def __init__(self, w, rna, fn, imgLight, imgDark=None):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.imgLight = imgLight
        self.imgDark = imgDark
        self.is_repeat = True  if hasattr(rna, "is_repeat") and rna.is_repeat else False
        self.box_button = getattr(blg, imgLight)()
        #|

    def init_bat(self, L, R, T):
        B = T - R + L
        self.box_button.LRBT_upd(L, R, B, T)
        self.box_hover = None
        return B
        #|
    def r_height(self, width): return SIZE_widget[0]

    def is_dark(self): return self.box_button.__class__.__name__ == self.imgDark
    def dark(self):
        if self.box_button.__class__.__name__ == self.imgDark: return
        self.box_button.__class__ = getattr(blg, self.imgDark)
        self.box_button.upd()
        Admin.REDRAW()
        #|
    def light(self):
        if self.box_button.__class__.__name__ == self.imgLight: return
        self.box_button.__class__ = getattr(blg, self.imgLight)
        self.box_button.upd()
        Admin.REDRAW()
        #|
    def inside_evt(self):
        Admin.REDRAW()
        self.box_hover = GpuImg_area_icon_hover(*self.box_button.r_LRBT())
        self.box_hover.upd()
        self.is_trigger_enable = True
        #|
    def outside_evt(self):
        if self.is_repeat:
            # <<< 1copy (0block_unreg_timer_button_safe,, $$)
            if timer_isreg(timer_button):
                timer_unreg(timer_button)

            # >>>
            # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
            if timer_isreg(timer_hold):
                timer_unreg(timer_hold)

            # >>>
        Admin.REDRAW()
        self.box_hover = None
        #|

    def modal(self):
        if self.is_trigger_enable is True:
            if TRIGGER['click']():
                Admin.REDRAW()
                self.is_trigger_enable = False
                # self.box_button.set_state_press()
                self.fn()
                if self.is_repeat: self.reg_repeat_timer()
                return True
        elif EVT_TYPE[0] == "TIMER_REPORT": pass
        else:
            if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                if self.is_repeat:
                    # <<< 1copy (0block_unreg_timer_button_safe,, $$)
                    if timer_isreg(timer_button):
                        timer_unreg(timer_button)

                    # >>>
                    # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
                    if timer_isreg(timer_hold):
                        timer_unreg(timer_hold)

                    # >>>
                self.is_trigger_enable = True
                # self.box_button.set_state_focus()
                Admin.REDRAW()

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True
        return False
        #|

    def to_modal_rm(self):

        kill_evt_except()
        if self.rna == None: return

        DropDownRMKeymap(self, MOUSE, [
            ("detail", self.evt_area_detail),
        ], title=self.rna.name)
        #|

    def evt_area_detail(self):

        kill_evt_except()
        if self.rna == None: return
        Detail(Detail.r_rna_info(self.rna))
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        if self.box_hover != None: self.box_hover.dxy_upd(dx, dy)
        #|
    def draw_box(self):
        if self.box_hover != None: self.box_hover.bind_draw()
        self.box_button.bind_draw()
        #|
    def draw_blf(self): pass
    #|
    #|
class ButtonFnImgHoverKeyframe(     # ButtonFnImgHover                                          
    ButtonFnImgHover):
    __slots__ = ()

    def __init__(self, w, rna, fn):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.is_repeat = False
        self.box_button = GpuImg_keyframe_false()
        #|

    def modal(self):
        if self.is_trigger_enable is True:
            if TRIGGER['click']():
                Admin.REDRAW()
                self.is_trigger_enable = False
                if is_first_press('click') == False:
                    boo = self.box_button.__class__ in {
                        GpuImg_keyframe_current_true_even,
                        GpuImg_keyframe_current_true_odd}
                    if _last_bool_state[0] != boo:
                        self.fn()
                else:
                    self.fn()
                    _last_bool_state[0] = self.box_button.__class__ in {
                        GpuImg_keyframe_current_true_even,
                        GpuImg_keyframe_current_true_odd}

                if self.is_repeat: self.reg_repeat_timer()
                return True
        elif EVT_TYPE[0] == "TIMER_REPORT": pass
        else:
            if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                if self.is_repeat:
                    # <<< 1copy (0block_unreg_timer_button_safe,, $$)
                    if timer_isreg(timer_button):
                        timer_unreg(timer_button)

                    # >>>
                    # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
                    if timer_isreg(timer_hold):
                        timer_unreg(timer_hold)

                    # >>>
                self.is_trigger_enable = True
                # self.box_button.set_state_focus()
                Admin.REDRAW()

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True
        return False
        #|
    #|
    #|
class ButtonFnImgHoverKeyframeRef(  # ButtonFnImgHover                                          
    ButtonFnImgHover):
    __slots__ = ()

    def __init__(self, w, rna, fn):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.is_repeat = False
        self.box_button = GpuImgNull()
        #|

    def inside_evt(self):
        if self.box_button.__class__ == GpuImgNull:
            self.is_trigger_enable = True
            return
        super().inside_evt()
        #|
    #|
    #|
class ButtonFnImgList(              # ButtonFn                                                  
    ButtonFn): # h = SIZE_widget[0]
    __slots__ = 'L', 'R', 'inside_evt_callback', 'outside_evt_callback'

    BLF_X = 0
    BLF_OFFSET_Y = 0
    IMG_L = 0
    IMG_R = 0
    H = 0

    @classmethod
    def set_offset(cls, L, blf_offset_y, outer, h):
        cls.BLF_OFFSET_Y = blf_offset_y
        cls.H = h
        cls.IMG_L = L + outer
        cls.IMG_R = cls.IMG_L + h
        cls.BLF_X = cls.IMG_R + blf_offset_y
        #|

    def __init__(self, w, rna, fn, imgLight, title, font_color, inside_evt_callback, outside_evt_callback):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.inside_evt_callback = inside_evt_callback
        self.outside_evt_callback = outside_evt_callback
        self.is_repeat = True  if hasattr(rna, "is_repeat") and rna.is_repeat else False
        self.box_button = getattr(blg, imgLight)()
        self.blf_value = BlfClipColor(self, unclip_text=title, color=font_color)
        #|

    def init_bat_dimen(self, L, R, T): # need set_offset, init_blf_clipping_end
        self.L = L
        self.R = R
        blf_value = self.blf_value
        B = T - ButtonFnImgList.H
        self.box_button.LRBT_upd(ButtonFnImgList.IMG_L, ButtonFnImgList.IMG_R, B, T)
        blf_value.x = ButtonFnImgList.BLF_X
        blf_value.y = B + ButtonFnImgList.BLF_OFFSET_Y
        blf_value.text = r_blf_clipping_end(blf_value.unclip_text,
            blf_value.x, R - ButtonFnImgList.BLF_OFFSET_Y)
        return B
    def init_bat(self, L, R, T):
        self.L = L
        self.R = R
        blf_value = self.blf_value
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        L += SIZE_setting_list_border[0]
        R = L + SIZE_widget[0]
        B = T - SIZE_widget[0]
        self.box_button.LRBT_upd(L, R, B, T)
        blf_value.x = R + D_SIZE['font_main_dy']
        blf_value.y = B + D_SIZE['font_main_dy']
        blf_value.text = r_blf_clipping_end(blf_value.unclip_text,
            blf_value.x, R - D_SIZE['font_main_dy'])
        return B
        #|
    def r_height(self, width): return SIZE_widget[0]

    def inside(self, mouse):
        return self.box_button.B <= mouse[1] < self.box_button.T and self.L <= mouse[0] < self.R
        #|
    def inside_evt(self):
        Admin.REDRAW()
        self.is_trigger_enable = True
        self.inside_evt_callback(self)
        #|
    def outside_evt(self):
        if self.is_repeat:
            # <<< 1copy (0block_unreg_timer_button_safe,, $$)
            if timer_isreg(timer_button):
                timer_unreg(timer_button)

            # >>>
            # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
            if timer_isreg(timer_hold):
                timer_unreg(timer_hold)

            # >>>
        Admin.REDRAW()
        self.outside_evt_callback(self)
        #|

    def modal(self):
        if self.is_trigger_enable is True:
            if TRIGGER['click']():
                Admin.REDRAW()
                self.is_trigger_enable = False
                # self.box_button.set_state_press()
                self.fn()
                if self.is_repeat: self.reg_repeat_timer()
                return True
        elif EVT_TYPE[0] == "TIMER_REPORT": pass
        else:
            if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                if self.is_repeat:
                    # <<< 1copy (0block_unreg_timer_button_safe,, $$)
                    if timer_isreg(timer_button):
                        timer_unreg(timer_button)

                    # >>>
                    # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
                    if timer_isreg(timer_hold):
                        timer_unreg(timer_hold)

                    # >>>
                self.is_trigger_enable = True
                # self.box_button.set_state_focus()
                Admin.REDRAW()

        if hasattr(self, "submodal"):
            if self.submodal(): return True
        return False
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.blf_value.x += dx
        self.blf_value.y += dy
        self.L += dx
        self.R += dx
        #|
    #|
    #|
class ButtonFnBlf(                  # ButtonFn                                                  
    ButtonFn):
    __slots__ = 'inside_evt_callback', 'outside_evt_callback'

    BLF_X = 0
    BLF_OFFSET_Y = 0
    H = 0

    @classmethod
    def set_offset(cls, L, blf_offset_x, blf_offset_y, h):
        cls.BLF_OFFSET_Y = blf_offset_y
        cls.H = h
        cls.BLF_X = L + blf_offset_x
        #|

    def __init__(self, w, rna, fn, title, font_color, inside_evt_callback, outside_evt_callback):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.inside_evt_callback = inside_evt_callback
        self.outside_evt_callback = outside_evt_callback
        self.is_repeat = True  if hasattr(rna, "is_repeat") and rna.is_repeat else False
        self.box_button = GpuBox()
        self.blf_value = BlfClipColor(self, unclip_text=title, color=font_color)
        #|

    def init_bat_dimen(self, L, R, T): # need set_offset, init_blf_clipping_end
        blf_value = self.blf_value
        B = T - ButtonFnBlf.H
        self.box_button.LRBT(L, R, B, T)
        blf_value.x = ButtonFnBlf.BLF_X
        blf_value.y = B + ButtonFnBlf.BLF_OFFSET_Y
        blf_value.text = r_blf_clipping_end(blf_value.unclip_text,
            blf_value.x, R - ButtonFnBlf.BLF_OFFSET_Y)
        return B
        #|
    def init_bat(self, L, R, T):
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value = self.blf_value
        B = T - SIZE_widget[0]
        self.box_button.LRBT(L, R, B, T)
        blf_value.x = L + D_SIZE['font_main_dx']
        blf_value.y = B + D_SIZE['font_main_dy']
        blf_value.text = r_blf_clipping_end(blf_value.unclip_text,
            blf_value.x, R - D_SIZE['font_main_dy'])
        return B
        #|
    def r_height(self, width): return SIZE_widget[0]

    def inside_evt(self):
        Admin.REDRAW()
        self.is_trigger_enable = True
        self.inside_evt_callback(self)
        #|
    def outside_evt(self):
        if self.is_repeat:
            # <<< 1copy (0block_unreg_timer_button_safe,, $$)
            if timer_isreg(timer_button):
                timer_unreg(timer_button)

            # >>>
            # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
            if timer_isreg(timer_hold):
                timer_unreg(timer_hold)

            # >>>
        Admin.REDRAW()
        self.outside_evt_callback(self)
        #|

    def modal(self):
        if self.is_trigger_enable is True:
            if TRIGGER['click']():
                Admin.REDRAW()
                self.is_trigger_enable = False
                # self.box_button.set_state_press()
                self.fn()
                if self.is_repeat: self.reg_repeat_timer()
                return True
        elif EVT_TYPE[0] == "TIMER_REPORT": pass
        else:
            if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                if self.is_repeat:
                    # <<< 1copy (0block_unreg_timer_button_safe,, $$)
                    if timer_isreg(timer_button):
                        timer_unreg(timer_button)

                    # >>>
                    # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
                    if timer_isreg(timer_hold):
                        timer_unreg(timer_hold)

                    # >>>
                self.is_trigger_enable = True
                # self.box_button.set_state_focus()
                Admin.REDRAW()

        if hasattr(self, "submodal"):
            if self.submodal(): return True
        return False
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy(dx, dy)
        self.blf_value.x += dx
        self.blf_value.y += dy
        #|

    def draw_box(self): pass
    #|
    #|
class StructButtonEnum:
    __slots__ = ()

    def r_default_value(self): return self.rna.default

    # /* 0block_StructButtonEnum_evt_set
    @ catch
    def to_modal_rm(self):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ], override_name={"dd_cut":"Copy Identifier"}, title=self.rna.name)
        #|

    @ catch
    def evt_area_cut(self, is_report=True):

        kill_evt_except()
        ob = self.get()
        if hasattr(ob, "name"):
            ob = r_ID_dp(ob)
            if not ob: return
        else:
            return
        bpy.context.window_manager.clipboard = f'{ob}'
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()

        if hasattr(self.rna, "enum_items"):
            v = self.get()
            if v == None: s = "None"
            elif isinstance(v, set):
                ls = [e.name  for e in self.rna.enum_items  if e.identifier in v]
                s = str(ls).replace("[", "{").replace("]", "}")
            else:
                s = self.rna.enum_items[v].name  if v in self.rna.enum_items else v
        else:
            s = self.get()

        bpy.context.window_manager.clipboard = f'{s}'
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            self.set(s)
            Admin.REDRAW()
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_reset_all(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_detail(self):

        kill_evt_except()
        Detail(Detail.r_rna_info(self.rna))
        #|

    def get(self):
        return getattr(self.pp, self.rna.identifier)
        #|
    def set(self, v, refresh=True, undo_push=True): # allow input name, Nonetype
        rna = self.rna
        oldvalue = getattr(self.pp, rna.identifier)
        if v in rna.enum_items:
            setattr(self.pp, rna.identifier, v)
            if refresh: update_data()
            if hasattr(self, "set_callback"): self.set_callback()
            self.evt_undo_push(undo_push, oldvalue)
        else:
            if v == None:
                if hasattr(rna, "is_never_none") and rna.is_never_none: return
            else:
                for e in rna.enum_items:
                    if e.name == v:
                        setattr(self.pp, rna.identifier, e.identifier)
                        if refresh: update_data()
                        if hasattr(self, "set_callback"): self.set_callback()
                        self.evt_undo_push(undo_push, oldvalue)
                        return
    # */
    def evt_undo_push(self, undo_push, oldvalue): pass
    #|
    #|
class ButtonEnum(                   # StructButtonEnum          ButtonString                    
    StructButtonEnum, ButtonString):
    __slots__ = 'box_icon_arrow', 'get_icon'

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        self.box_icon_arrow = GpuImg_unfold()
        self.blf_value = BlfClipColor("", "", 0, 0, COL_box_text_fg)
        self.font_id = FONT0
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        self.box_icon_arrow.LRBT_upd(R0 - SIZE_widget[0], R0, B0, T0)

        blf_value.x = L0 + D_SIZE['font_main_dx']
        blf_value.y = B0 + D_SIZE['font_main_dy']
        blf_value.unclip_text = ""
        blf_value.text = ""
        self.upd_data()
        return B
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        if hasattr(self, "poll") and self.poll(self) == False: return

        v = self.get()
        if v == None: v = "None"
        elif hasattr(self.rna, "enum_items"):
            if v in self.rna.enum_items: v = self.rna.enum_items[v].name

        return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name,
            get_icon=self.get_icon  if hasattr(self, "get_icon") else None)
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_icon_arrow.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        self.box_icon_arrow.bind_draw()
        #|
    def draw_blf(self):
        e = self.blf_value
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        blf_value = self.blf_value
        if blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return

        v = getattr(self.pp, self.rna.identifier)
        blf_value.unclip_text = v
        if v == None: v = "None"
        elif hasattr(self.rna, "enum_items"):
            if v in self.rna.enum_items: v = self.rna.enum_items[v].name

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class ButtonEnumIcon(               # ButtonEnum                                                
    ButtonEnum):
    __slots__ = 'box_icon_object', 'D_icon'

    def __init__(self, w, rna, pp, D_icon, default_icon=None):
        super().__init__(w, rna, pp)

        self.box_icon_object = default_icon
        self.D_icon = D_icon

        if D_icon:
            D_geticon_DriverVar = blg.D_geticon_DriverVar
            def get_icon(e):
                if hasattr(e, "identifier") and e.identifier in D_geticon_DriverVar:
                    return D_geticon_DriverVar[e.identifier]()
                return GpuImgNull()

            self.get_icon = get_icon
        else:
            self.get_icon = None
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        self.box_icon_arrow.LRBT_upd(R0 - SIZE_widget[0], R0, B0, T0)

        if self.box_icon_object is None: pass
        else:
            LL = L0
            L0 += SIZE_widget[0]
            self.box_icon_object.LRBT_upd(LL, L0, B0, T0)

        blf_value.x = L0 + D_SIZE['font_main_dx']
        blf_value.y = B0 + D_SIZE['font_main_dy']
        blf_value.unclip_text = ""
        blf_value.text = ""
        self.upd_data()
        return B
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_icon_arrow.dxy_upd(dx, dy)
        if self.box_icon_object is not None:
            self.box_icon_object.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        self.box_icon_arrow.bind_draw()
        if self.box_icon_object is not None:
            self.box_icon_object.bind_draw()
        #|

    def upd_data(self):
        # super
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        blf_value = self.blf_value
        if blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return

        v = getattr(self.pp, self.rna.identifier)
        blf_value.unclip_text = v

        L0, R0, B0, T0 = self.box_button.inner
        self.box_icon_object = self.D_icon[v]  if v in self.D_icon else None
        if self.box_icon_object is None: pass
        else:
            self.box_icon_object = self.box_icon_object()
            LL = L0
            L0 += SIZE_widget[0]
            self.box_icon_object.LRBT_upd(LL, L0, B0, T0)

        blf_value.x = L0 + D_SIZE['font_main_dx']

        if v == None: v = "None"
        elif hasattr(self.rna, "enum_items"):
            if v in self.rna.enum_items: v = self.rna.enum_items[v].name

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class ButtonEnumXY(                 # StructButtonEnum                                          
    StructButtonEnum):
    __slots__ = (
        'w',
        'rna',
        'pp',
        'r_pp',
        'r_object',
        'r_datapath_head',
        'box_button',
        'blf_value',
        'row_length',
        'focus_index',
        'is_trigger_enable',
        'enum_value',
        'set_callback')

    def __init__(self, w, rna, pp, row_length=1):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.row_length = row_length
        self.box_button = [GpuButtonBool()  for e in rna.enum_items]
        self.blf_value = [BlfColor(e.name, color=COL_box_button_fg)  for e in rna.enum_items]
        self.enum_value = ""
        #|

    def init_bat(self, L, R, T):
        blfSize(FONT0, D_SIZE['font_main'])
        row_length = self.row_length
        box_button = self.box_button
        blf_value = self.blf_value
        widget_rim = SIZE_border[3]
        full_h = D_SIZE['widget_full_h']
        width = (R - L) // row_length
        range_row = range(row_length)
        LRs = []
        R0 = L + width
        for _ in range_row:
            LRs.append([L, R0])
            L = R0
            R0 += width
        LRs[-1][1] = R
        B = T - full_h
        y = B + widget_rim + D_SIZE['font_main_dy']

        i = 0
        amount = len(box_button) // row_length
        for _ in range(amount):
            for r in range_row:
                # /* 0block_ButtonEnumXY_initbutton
                L0, R0 = LRs[r]
                box_button[i].LRBT_upd(L0, R0, B, T, widget_rim)
                e = blf_value[i]
                e.y = y
                e.x = floor((R0 + L0 - blfDimen(FONT0, e.text)[0]) / 2)
                i += 1
                # */

            T = B
            B -= full_h
            y -= full_h

        for r in range(len(box_button) - amount * row_length):
            # <<< 1copy (0block_ButtonEnumXY_initbutton,, $$)
            L0, R0 = LRs[r]
            box_button[i].LRBT_upd(L0, R0, B, T, widget_rim)
            e = blf_value[i]
            e.y = y
            e.x = floor((R0 + L0 - blfDimen(FONT0, e.text)[0]) / 2)
            i += 1
            # >>>

        self.upd_data()
        return box_button[-1].B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h'] * ceil(len(self.box_button) / self.row_length)

    def is_dark(self): return self.box_button[0].is_dark()
    def dark(self):
        for e in self.box_button: e.dark()
        for e in self.blf_value: e.color = COL_box_button_fg_ignore
        #|
    def light(self):
        for e in self.box_button: e.light()
        for e in self.blf_value: e.color = COL_box_button_fg
        #|

    def r_focus_index(self, mouse):
        for r, e in enumerate(self.box_button):
            if e.inbox(mouse): return r
        return None
        #|
    def fn(self, i):

        Admin.REDRAW()
        v = self.rna.enum_items[i].identifier
        self.set(v)
        #|

    def focus_button(self, i):
        if self.box_button[i].state == 0:
            self.box_button[i].set_state_off_focus()
        #|
    def unfocus_button(self, i):
        if self.box_button[i].state == 1:
            self.box_button[i].set_state_off()
        #|
    def turnon_button(self, i):
        if self.box_button[i].state in {0, 1}:
            self.box_button[i].set_state_on()
        #|
    def turnoff_button(self, i):
        if self.box_button[i].state == 2:
            self.box_button[i].set_state_off()
        #|

    def inside(self, mouse):
        box_button = self.box_button
        if mouse[0] < box_button[0].L: return False
        if mouse[0] > box_button[self.row_length - 1].R: return False
        if mouse[1] > box_button[0].T: return False
        if mouse[1] < box_button[-1].B: return False
        return True
        #|
    def inside_evt(self):
        self.focus_index = self.r_focus_index(MOUSE)
        if self.focus_index != None:
            self.focus_button(self.focus_index)
            Admin.REDRAW()
        self.is_trigger_enable = True
        #|
    def outside_evt(self):
        if hasattr(self, "focus_index"):
            if self.focus_index != None:
                self.unfocus_button(self.focus_index)
                Admin.REDRAW()
        #|

    def modal(self):
        i = self.r_focus_index(MOUSE)
        if i != self.focus_index:

            if self.focus_index != None:
                self.unfocus_button(self.focus_index)
                Admin.REDRAW()

            self.focus_index = i
            self.is_trigger_enable = True

            if i != None:
                self.focus_button(i)
                Admin.REDRAW()

        if i == None: return False

        allow_trigger = self.is_trigger_enable
        if not allow_trigger:
            if EVT_TYPE[0] == "TIMER_REPORT": pass
            else:
                if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                    self.is_trigger_enable = True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if allow_trigger:
            if TRIGGER['click']():
                self.is_trigger_enable = False
                self.fn(i)
                return True
        return False
        #|

    def dxy(self, dx, dy):
        for e in self.box_button: e.dxy_upd(dx, dy)
        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|
    def draw_box(self):
        for e in self.box_button: e.bind_draw()
        #|
    def draw_blf(self):
        blfSize(FONT0, D_SIZE['font_main'])
        for e in self.blf_value:
            blfColor(FONT0, *e.color)
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.enum_value == self.get(): return
        v = self.get()

        if v in self.rna.enum_items:
            for r, e in enumerate(self.rna.enum_items):
                self.turnon_button(r)  if e.identifier == v else self.turnoff_button(r)
        else:
            for r, e in enumerate(self.rna.enum_items): self.turnoff_button(r)

        self.enum_value = v
        #|
    #|
    #|
class ButtonEnumXYFlag(             # ButtonEnumXY                                              
    ButtonEnumXY):
    __slots__ = ()

    def r_default_value(self):
        v = self.rna.default
        if v: return v
        return set()
        #|

    def fn(self, i):

        Admin.REDRAW()
        old_v = self.get()
        v = self.rna.enum_items[i].identifier

        if old_v:
            new_v = old_v.copy()
            if v in new_v:
                new_v.remove(v)
            else:
                new_v.add(v)

            self.set(new_v)
        else:
            self.set(v)
        #|

    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            self.set(s)
            Admin.REDRAW()
        except:
            if is_report: report("Input Error")
        #|

    def set(self, v, refresh=True, undo_push=True): # str or set, None, allow input name
        rna = self.rna
        oldvalue = getattr(self.pp, rna.identifier)
        if v == None: v = set()
        if isinstance(v, str):
            if v[: 1] == "{":
                v = calc_py_exp(v)
                if not isinstance(v, set): return
            else:
                v = {v}

        name_to_id = {e.name: identifier  for identifier, e in rna.enum_items.items()}

        try:
            setattr(self.pp, rna.identifier, {(name_to_id[v]  if v in name_to_id else v)  for v in v})
            if refresh: update_data()
            self.evt_undo_push(undo_push, oldvalue)
        except: return
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.enum_value == self.get(): return
        v = self.get()

        if v:
            for r, e in enumerate(self.rna.enum_items):
                self.turnon_button(r)  if e.identifier in v else self.turnoff_button(r)
        else:
            for r, e in enumerate(self.rna.enum_items): self.turnoff_button(r)

        self.enum_value = v
        #|
    #|
    #|
class ButtonEnumObject(             # ButtonEnum                                                
    ButtonEnum):
    __slots__ = 'allow_types', 'r_except_objects', 'box_icon_object'

    def __init__(self, w, rna, pp, allow_types=None, r_except_objects=None):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        self.box_icon_arrow = GpuImg_object_picker()
        v = self.get()
        self.blf_value = BlfClipColor("", "", 0, 0, COL_box_text_fg)
        self.font_id = FONT0

        self.allow_types = allow_types
        self.r_except_objects = r_except_objects
        if allow_types is None:
            self.box_icon_object = GpuImg_OBJECT_DATA()
        else:
            if len(allow_types) == 1:
                for allow_type in allow_types: break
                self.box_icon_object = getattr(blg, f"GpuImg_OUTLINER_OB_{allow_type}", GpuImg_OBJECT_DATA)()
            else: self.box_icon_object = GpuImg_OBJECT_DATA()
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        self.box_icon_arrow.LRBT_upd(R0 - SIZE_widget[0], R0, B0, T0)
        LL = L0
        L0 += SIZE_widget[0]
        self.box_icon_object.LRBT_upd(LL, L0, B0, T0)

        blf_value.x = L0 + D_SIZE['font_main_dx']
        blf_value.y = B0 + D_SIZE['font_main_dy']
        blf_value.unclip_text = ""
        blf_value.text = ""
        self.upd_data()
        return B
        #|

    def r_default_value(self): return None

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        # <<< 1copy (0block_ButtonEnumObject_modal_update_picker_focus,, ${'Admin.REDRAW()':''}$)
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                        self.box_icon_arrow.__class__ = GpuImg_delete_focus
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_object_picker_focus:
                        self.box_icon_arrow.__class__ = GpuImg_object_picker_focus
                        

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    
        else:
            region = 0
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_object_picker:
                        self.box_icon_arrow.__class__ = GpuImg_object_picker
                        

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    
        # >>>
        Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.is_dark() is True: return

        self.box_button.color = COL_box_text
        if self.get():
            self.box_icon_arrow.__class__ = GpuImg_delete
        else:
            self.box_icon_arrow.__class__ = GpuImg_object_picker
        Admin.REDRAW()
        #|

    def modal(self):
        # /* 0block_ButtonEnumObject_modal_update_picker_focus
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                        self.box_icon_arrow.__class__ = GpuImg_delete_focus
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_object_picker_focus:
                        self.box_icon_arrow.__class__ = GpuImg_object_picker_focus
                        Admin.REDRAW()

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    Admin.REDRAW()
        else:
            region = 0
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_object_picker:
                        self.box_icon_arrow.__class__ = GpuImg_object_picker
                        Admin.REDRAW()

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    Admin.REDRAW()
        # */

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if TRIGGER['dd_preview']():
            if hasattr(self, "evt_area_preview"):
                self.evt_area_preview()
                return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.evt_click(region)
            return True
        return False
        #|

    def to_modal_rm(self): pass

    def to_dropdown(self, killevt=True, select_all=None):


        return DropDownEnumPointer(self, self.box_button.r_LRBT(), self.rna.name,
            bpy.data.objects,
            self.allow_types,
            self.r_except_objects)
        #|
    def to_modal_picker(self):

        modal_object_picker_init(self.allow_types, self.r_except_objects, self.set)
        #|

    @ catch
    def evt_click(self, region=0):
        if region == 0:
            self.to_dropdown()
        else:
            if self.get():
                self.evt_delete_object()
            else:
                self.to_modal_picker()
        #|
    @ catch
    def evt_delete_object(self):

        kill_evt_except()
        try:
            self.set(None)
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Unexpected error, please report to the author: 03\n{ex}')
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            if s[0] == ";":
                if s[0 : 2] == ";;": s = s[1 :]
                else:
                    self.set(eval(s[1 :]))
                    Admin.REDRAW()
                    return

            self.set(s)
            Admin.REDRAW()
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        ob = self.get()
        if ob == None: tx = ";None"
        else:
            if ob.library:
                tx = f';{r_ID_dp(ob)}'
            else:
                tx = ob.name
                if tx[0] == ";": tx = ";" + tx

        bpy.context.window_manager.clipboard = tx
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_jump_to_target(self):

        kill_evt_except()
        if object_select(self.get(), "EXTEND"):
            ed_undo_push(message=f'VMD jump to target "{self.get().name}"')
        #|
    @ catch
    def evt_mark_asset(self, is_report=True):

        kill_evt_except()
        ob = self.get()
        if ob == None: return
        try:
            if ob.asset_data:
                ob.asset_clear()
                if is_report: report(f'"{ob.name}" is not an asset anymore')
                ed_undo_push(message=f'VMD clear asset "{ob.name}"')
            else:
                ob.asset_mark()
                if is_report: report(f'"{ob.name}" is now an asset')
                ed_undo_push(message=f'VMD mark asset "{ob.name}"')

            update_data()
        except Exception as ex:
            if is_report: DropDownOk(None, MOUSE, input_text=str(ex))
        #|
    @ catchBug
    def evt_rename(self, is_report=True):

        kill_evt_except()
        ob = self.get()
        if ob == None: return
        L, R, B, T = self.box_button.r_LRBT()
        R += R - L

        DropDownEnumRename(None, (L, R, B, T), ob, ob, is_report=is_report)
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_icon_arrow.dxy_upd(dx, dy)
        self.box_icon_object.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        self.box_icon_arrow.bind_draw()
        self.box_icon_object.bind_draw()
        #|

    # /* 0block_ButtonEnumObject_set
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.objects: v = bpy.data.objects[v]
                    else:
                        if refresh: report("Object not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.objects: v = bpy.data.objects[v]
                    else:
                        if refresh: report("Object not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Object")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Object Type")
                    return

        setattr(self.pp, rna.identifier, v)
        if refresh: update_data()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # */

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        ob = getattr(self.pp, self.rna.identifier)
        if self.blf_value.unclip_text == (ob.name  if ob else ""): return

        blf_value = self.blf_value

        if ob == None:
            v = ""
            if self.box_icon_arrow.__class__ != GpuImg_object_picker:
                self.box_icon_arrow.__class__ = GpuImg_object_picker
        else:
            v = ob.name
            if self.box_icon_arrow.__class__ != GpuImg_delete:
                self.box_icon_arrow.__class__ = GpuImg_delete

        blf_value.unclip_text = v

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class ButtonEnumCollection(         # ButtonEnumObject                                          
    ButtonEnumObject):
    __slots__ = ()

    def __init__(self, w, rna, pp, allow_types=None, r_except_objects=None):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        self.box_icon_arrow = GpuImg_unfold()
        v = self.get()
        self.blf_value = BlfClipColor("", "", 0, 0, COL_box_text_fg)
        self.font_id = FONT0
        self.allow_types = allow_types
        self.r_except_objects = r_except_objects

        self.box_icon_object = GpuImg_ID_COLLECTION()
        #|

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        # <<< 1copy (0block_ButtonEnumCollection_modal_update_picker_focus,, ${'Admin.REDRAW()':''}$)
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.get() == None:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                        self.box_icon_arrow.__class__ = GpuImg_delete_focus
                        

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    
        else:
            region = 0
            if self.is_dark() is False:
                if self.get() == None:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    
        # >>>
        Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.is_dark() is True: return

        self.box_button.color = COL_box_text
        if self.get() == None:
            self.box_icon_arrow.__class__ = GpuImg_unfold
        else:
            self.box_icon_arrow.__class__ = GpuImg_delete
        Admin.REDRAW()
        #|

    def modal(self):
        # /* 0block_ButtonEnumCollection_modal_update_picker_focus
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.get() == None:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                        self.box_icon_arrow.__class__ = GpuImg_delete_focus
                        Admin.REDRAW()

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    Admin.REDRAW()
        else:
            region = 0
            if self.is_dark() is False:
                if self.get() == None:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        Admin.REDRAW()

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    Admin.REDRAW()
        # */

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if TRIGGER['dd_preview']():
            if hasattr(self, "evt_area_preview"):
                self.evt_area_preview()
                return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.evt_click(region)
            return True
        return False
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        return DropDownEnumPointer(self, self.box_button.r_LRBT(), self.rna.name, bpy.data.collections)
        #|
    def to_modal_picker(self): return self.to_dropdown()

    def evt_click(self, region=0):
        if region == 0:
            self.to_dropdown()
        else:
            if self.get() == None:
                self.to_modal_picker()
            else:
                self.evt_delete_object()
        #|

    # <<< 1copy (0block_ButtonEnumObject_set,, ${'.objects':'.collections', 'Object':'Collection'}$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.collections: v = bpy.data.collections[v]
                    else:
                        if refresh: report("Collection not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.collections: v = bpy.data.collections[v]
                    else:
                        if refresh: report("Collection not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Collection")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Collection Type")
                    return

        setattr(self.pp, rna.identifier, v)
        if refresh: update_data()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        ob = getattr(self.pp, self.rna.identifier)
        if self.blf_value.unclip_text == (ob.name  if ob else ""): return

        blf_value = self.blf_value

        if ob == None:
            v = ""
            if self.box_icon_arrow.__class__ != GpuImg_unfold:
                self.box_icon_arrow.__class__ = GpuImg_unfold
        else:
            v = ob.name
            if self.box_icon_arrow.__class__ != GpuImg_delete:
                self.box_icon_arrow.__class__ = GpuImg_delete

        blf_value.unclip_text = v

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class ButtonEnumParticle(           # ButtonEnumCollection                                      
    ButtonEnumCollection):
    __slots__ = 'r_particle_object'

    def __init__(self, w, rna, pp, r_particle_object, allow_types=None, r_except_objects=None):
        super().__init__(w, rna, pp, allow_types=allow_types, r_except_objects=r_except_objects)
        self.box_icon_object.__class__ = GpuImg_PARTICLE_SYSTEM
        self.r_particle_object = r_particle_object
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        target = self.r_particle_object()
        if not target: return
        if not hasattr(target, "particle_systems"): return

        return DropDownEnumPointer(self, self.box_button.r_LRBT(), self.rna.name, target.particle_systems)
        #|

    # <<< 1copy (0block_ButtonEnumObject_set,, ${
    #     'bpy.data.objects': 'self.r_particle_object().particle_systems',
    # }$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in self.r_particle_object().particle_systems: v = self.r_particle_object().particle_systems[v]
                    else:
                        if refresh: report("Object not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in self.r_particle_object().particle_systems: v = self.r_particle_object().particle_systems[v]
                    else:
                        if refresh: report("Object not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Object")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Object Type")
                    return

        setattr(self.pp, rna.identifier, v)
        if refresh: update_data()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>
    #|
    #|
class ButtonEnumTexture(            # ButtonEnumObject                                          
    StructPreview,
    ButtonEnumObject):
    __slots__ = 'box_icon_fakeuser', 'box_icon_duplicate', 'box_icon_rename', 'user_state', 'link_state', 'blf_users'

    def __init__(self, w, rna, pp, allow_types=None, r_except_objects=None):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        self.box_icon_arrow = GpuImg_ADD()
        v = self.get()
        self.blf_value = BlfClipColor("", "", 0, 0, COL_box_text_fg)
        self.font_id = FONT0
        self.allow_types = allow_types
        self.r_except_objects = r_except_objects

        self.box_icon_object = GpuImg_ID_TEXTURE()
        self.box_icon_fakeuser = GpuImg_FAKE_USER_OFF()
        self.box_icon_duplicate = GpuImg_DUPLICATE()
        self.box_icon_rename = GpuImg_rename()

        self.user_state = "NONE"
        self.link_state = "NONE"
        self.blf_users = BlfClipColor("", 0, 0, 0, COL_box_text_fg)
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        h = SIZE_widget[0]
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        L1 = R0 - h
        self.box_icon_arrow.LRBT_upd(L1, R0, B0, T0)
        L1 -= h
        R0 -= h
        self.box_icon_fakeuser.LRBT_upd(L1, R0, B0, T0)
        L1 -= h
        R0 -= h
        self.box_icon_duplicate.LRBT_upd(L1, R0, B0, T0)
        L1 -= h
        R0 -= h
        self.box_icon_rename.LRBT_upd(L1, R0, B0, T0)
        LL = L0
        L0 += h
        self.box_icon_object.LRBT_upd(LL, L0, B0, T0)

        blf_value.x = L0 + D_SIZE['font_main_dx']
        y = B0 + D_SIZE['font_main_dy']
        blf_value.y = y
        blf_value.unclip_text = ""
        blf_value.text = ""
        self.blf_users.y = y
        self.upd_data()
        return B
        #|

    def inside_evt(self):
        # <<< 1copy (0block_ButtonEnumTexture_modal_update_picker_focus,, ${'Admin.REDRAW()':''}$)
        x = MOUSE[0]
        if x >= self.box_icon_rename.L:
            if x >= self.box_icon_fakeuser.L:
                if x >= self.box_icon_arrow.L:
                    region = 1
                    if self.is_dark() is False:
                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                                self.box_icon_arrow.__class__ = GpuImg_delete_focus
                                
                        else:
                            if self.box_icon_arrow.__class__ != GpuImg_ADD_focus:
                                self.box_icon_arrow.__class__ = GpuImg_ADD_focus
                                

                        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
                            
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
                            
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
                            

                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_duplicate.__class__ != GpuImgNull:
                                self.box_icon_duplicate.__class__ = GpuImgNull
                                
                        else:
                            if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE:
                                self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
                                

                        if self.box_icon_rename.__class__ == GpuImg_rename_focus:
                            self.box_icon_rename.__class__ = GpuImg_rename
                            
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
                            
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
                            

                        if self.box_button.color != COL_box_text:
                            self.box_button.color = COL_box_text
                            

                        if self.blf_users.color != COL_box_text_fg:
                            self.blf_users.color = COL_box_text_fg
                            
                else:
                    region = 2
                    if self.is_dark() is False:
                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_arrow.__class__ != GpuImg_delete:
                                self.box_icon_arrow.__class__ = GpuImg_delete
                                
                        else:
                            if self.box_icon_arrow.__class__ != GpuImg_ADD:
                                self.box_icon_arrow.__class__ = GpuImg_ADD
                                

                        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON_focus
                            
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF_focus
                            
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB_focus
                            

                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_duplicate.__class__ != GpuImgNull:
                                self.box_icon_duplicate.__class__ = GpuImgNull
                                
                        else:
                            if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE:
                                self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
                                

                        if self.box_icon_rename.__class__ == GpuImg_rename_focus:
                            self.box_icon_rename.__class__ = GpuImg_rename
                            
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
                            
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
                            

                        if self.box_button.color != COL_box_text:
                            self.box_button.color = COL_box_text
                            

                        if self.blf_users.color != COL_box_text_fg:
                            self.blf_users.color = COL_box_text_fg
                            
            else:
                if x >= self.box_icon_duplicate.L:
                    region = 3
                    if self.is_dark() is False:
                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_arrow.__class__ != GpuImg_delete:
                                self.box_icon_arrow.__class__ = GpuImg_delete
                                
                        else:
                            if self.box_icon_arrow.__class__ != GpuImg_ADD:
                                self.box_icon_arrow.__class__ = GpuImg_ADD
                                

                        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
                            
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
                            
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
                            

                        if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE_focus:
                            self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE_focus
                            

                        if self.box_icon_rename.__class__ == GpuImg_rename_focus:
                            self.box_icon_rename.__class__ = GpuImg_rename
                            
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
                            
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
                            

                        if self.box_button.color != COL_box_text:
                            self.box_button.color = COL_box_text
                            

                        if self.blf_users.color != FLO_0000:
                            self.blf_users.color = FLO_0000
                            
                else:
                    region = 4
                    if self.is_dark() is False:
                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_arrow.__class__ != GpuImg_delete:
                                self.box_icon_arrow.__class__ = GpuImg_delete
                                
                        else:
                            if self.box_icon_arrow.__class__ != GpuImg_ADD:
                                self.box_icon_arrow.__class__ = GpuImg_ADD
                                

                        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
                            
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
                            
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
                            

                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_duplicate.__class__ != GpuImgNull:
                                self.box_icon_duplicate.__class__ = GpuImgNull
                                
                        else:
                            if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE:
                                self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
                                

                        if self.box_icon_rename.__class__ == GpuImg_rename:
                            self.box_icon_rename.__class__ = GpuImg_rename_focus
                            
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK_focus
                            
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE_focus
                            

                        if self.box_button.color != COL_box_text:
                            self.box_button.color = COL_box_text
                            

                        if self.blf_users.color != COL_box_text_fg:
                            self.blf_users.color = COL_box_text_fg
                            
        else:
            region = 0
            if self.is_dark() is False:
                if getattr(self.pp, self.rna.identifier):
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_ADD:
                        self.box_icon_arrow.__class__ = GpuImg_ADD
                        

                if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
                    
                elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
                    
                elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
                    

                if getattr(self.pp, self.rna.identifier):
                    if self.box_icon_duplicate.__class__ != GpuImgNull:
                        self.box_icon_duplicate.__class__ = GpuImgNull
                        
                else:
                    if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE:
                        self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
                        

                if self.box_icon_rename.__class__ == GpuImg_rename_focus:
                    self.box_icon_rename.__class__ = GpuImg_rename
                    
                elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
                    self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
                    
                elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
                    self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
                    

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    

                if self.blf_users.color != COL_box_text_fg:
                    self.blf_users.color = COL_box_text_fg
                    
        # >>>
        Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.is_dark() is True: return

        self.box_button.color = COL_box_text
        if getattr(self.pp, self.rna.identifier):
            if self.box_icon_arrow.__class__ != GpuImg_delete: self.box_icon_arrow.__class__ = GpuImg_delete
        else:
            if self.box_icon_arrow.__class__ != GpuImg_ADD: self.box_icon_arrow.__class__ = GpuImg_ADD

        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB

        if self.box_icon_rename.__class__ == GpuImg_rename_focus:
            self.box_icon_rename.__class__ = GpuImg_rename
        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE

        if getattr(self.pp, self.rna.identifier):
            self.box_icon_duplicate.__class__ = GpuImgNull
        else:
            self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE

        if self.box_icon_rename.__class__ == GpuImg_rename_focus:
            self.box_icon_rename.__class__ = GpuImg_rename

        if self.blf_users.color != COL_box_text_fg: self.blf_users.color = COL_box_text_fg
        Admin.REDRAW()
        #|

    def modal(self):
        # /* 0block_ButtonEnumTexture_modal_update_picker_focus
        x = MOUSE[0]
        if x >= self.box_icon_rename.L:
            if x >= self.box_icon_fakeuser.L:
                if x >= self.box_icon_arrow.L:
                    region = 1
                    if self.is_dark() is False:
                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                                self.box_icon_arrow.__class__ = GpuImg_delete_focus
                                Admin.REDRAW()
                        else:
                            if self.box_icon_arrow.__class__ != GpuImg_ADD_focus:
                                self.box_icon_arrow.__class__ = GpuImg_ADD_focus
                                Admin.REDRAW()

                        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
                            Admin.REDRAW()
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
                            Admin.REDRAW()
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
                            Admin.REDRAW()

                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_duplicate.__class__ != GpuImgNull:
                                self.box_icon_duplicate.__class__ = GpuImgNull
                                Admin.REDRAW()
                        else:
                            if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE:
                                self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
                                Admin.REDRAW()

                        if self.box_icon_rename.__class__ == GpuImg_rename_focus:
                            self.box_icon_rename.__class__ = GpuImg_rename
                            Admin.REDRAW()
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
                            Admin.REDRAW()
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
                            Admin.REDRAW()

                        if self.box_button.color != COL_box_text:
                            self.box_button.color = COL_box_text
                            Admin.REDRAW()

                        if self.blf_users.color != COL_box_text_fg:
                            self.blf_users.color = COL_box_text_fg
                            Admin.REDRAW()
                else:
                    region = 2
                    if self.is_dark() is False:
                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_arrow.__class__ != GpuImg_delete:
                                self.box_icon_arrow.__class__ = GpuImg_delete
                                Admin.REDRAW()
                        else:
                            if self.box_icon_arrow.__class__ != GpuImg_ADD:
                                self.box_icon_arrow.__class__ = GpuImg_ADD
                                Admin.REDRAW()

                        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON_focus
                            Admin.REDRAW()
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF_focus
                            Admin.REDRAW()
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB_focus
                            Admin.REDRAW()

                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_duplicate.__class__ != GpuImgNull:
                                self.box_icon_duplicate.__class__ = GpuImgNull
                                Admin.REDRAW()
                        else:
                            if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE:
                                self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
                                Admin.REDRAW()

                        if self.box_icon_rename.__class__ == GpuImg_rename_focus:
                            self.box_icon_rename.__class__ = GpuImg_rename
                            Admin.REDRAW()
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
                            Admin.REDRAW()
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
                            Admin.REDRAW()

                        if self.box_button.color != COL_box_text:
                            self.box_button.color = COL_box_text
                            Admin.REDRAW()

                        if self.blf_users.color != COL_box_text_fg:
                            self.blf_users.color = COL_box_text_fg
                            Admin.REDRAW()
            else:
                if x >= self.box_icon_duplicate.L:
                    region = 3
                    if self.is_dark() is False:
                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_arrow.__class__ != GpuImg_delete:
                                self.box_icon_arrow.__class__ = GpuImg_delete
                                Admin.REDRAW()
                        else:
                            if self.box_icon_arrow.__class__ != GpuImg_ADD:
                                self.box_icon_arrow.__class__ = GpuImg_ADD
                                Admin.REDRAW()

                        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
                            Admin.REDRAW()
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
                            Admin.REDRAW()
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
                            Admin.REDRAW()

                        if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE_focus:
                            self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE_focus
                            Admin.REDRAW()

                        if self.box_icon_rename.__class__ == GpuImg_rename_focus:
                            self.box_icon_rename.__class__ = GpuImg_rename
                            Admin.REDRAW()
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
                            Admin.REDRAW()
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
                            Admin.REDRAW()

                        if self.box_button.color != COL_box_text:
                            self.box_button.color = COL_box_text
                            Admin.REDRAW()

                        if self.blf_users.color != FLO_0000:
                            self.blf_users.color = FLO_0000
                            Admin.REDRAW()
                else:
                    region = 4
                    if self.is_dark() is False:
                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_arrow.__class__ != GpuImg_delete:
                                self.box_icon_arrow.__class__ = GpuImg_delete
                                Admin.REDRAW()
                        else:
                            if self.box_icon_arrow.__class__ != GpuImg_ADD:
                                self.box_icon_arrow.__class__ = GpuImg_ADD
                                Admin.REDRAW()

                        if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
                            Admin.REDRAW()
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
                            Admin.REDRAW()
                        elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
                            self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
                            Admin.REDRAW()

                        if getattr(self.pp, self.rna.identifier):
                            if self.box_icon_duplicate.__class__ != GpuImgNull:
                                self.box_icon_duplicate.__class__ = GpuImgNull
                                Admin.REDRAW()
                        else:
                            if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE:
                                self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
                                Admin.REDRAW()

                        if self.box_icon_rename.__class__ == GpuImg_rename:
                            self.box_icon_rename.__class__ = GpuImg_rename_focus
                            Admin.REDRAW()
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK_focus
                            Admin.REDRAW()
                        elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE:
                            self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE_focus
                            Admin.REDRAW()

                        if self.box_button.color != COL_box_text:
                            self.box_button.color = COL_box_text
                            Admin.REDRAW()

                        if self.blf_users.color != COL_box_text_fg:
                            self.blf_users.color = COL_box_text_fg
                            Admin.REDRAW()
        else:
            region = 0
            if self.is_dark() is False:
                if getattr(self.pp, self.rna.identifier):
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_ADD:
                        self.box_icon_arrow.__class__ = GpuImg_ADD
                        Admin.REDRAW()

                if self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_ON_focus:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
                    Admin.REDRAW()
                elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_OFF_focus:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF
                    Admin.REDRAW()
                elif self.box_icon_fakeuser.__class__ == GpuImg_FAKE_USER_LIB_focus:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
                    Admin.REDRAW()

                if getattr(self.pp, self.rna.identifier):
                    if self.box_icon_duplicate.__class__ != GpuImgNull:
                        self.box_icon_duplicate.__class__ = GpuImgNull
                        Admin.REDRAW()
                else:
                    if self.box_icon_duplicate.__class__ != GpuImg_DUPLICATE:
                        self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
                        Admin.REDRAW()

                if self.box_icon_rename.__class__ == GpuImg_rename_focus:
                    self.box_icon_rename.__class__ = GpuImg_rename
                    Admin.REDRAW()
                elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_LINK_focus:
                    self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
                    Admin.REDRAW()
                elif self.box_icon_rename.__class__ == GpuImg_FAKE_USER_OVERRIDE_focus:
                    self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
                    Admin.REDRAW()

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    Admin.REDRAW()

                if self.blf_users.color != COL_box_text_fg:
                    self.blf_users.color = COL_box_text_fg
                    Admin.REDRAW()
        # */

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if TRIGGER['dd_preview']():
            if hasattr(self, "evt_area_preview"):
                self.evt_area_preview()
                return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.evt_click(region)
            return True
        return False
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        return DropDownEnumTexture(self, self.box_button.r_LRBT(), self.rna.name, bpy.data.textures)
        #|

    def evt_add_button(self):

        kill_evt_except()
        e = bpy.data.textures.new("", "IMAGE")
        self.set(e)
        #|

    def evt_click(self, region=0):
        if region == 0:
            self.to_dropdown()
        elif region == 1:
            if getattr(self.pp, self.rna.identifier):
                self.evt_delete_object()
            else:
                self.evt_add_button()
        elif region == 2:
            self.evt_fakeuser()
        elif region == 3:
            self.evt_duplicate()
        else:
            self.evt_rename()
        #|
    def evt_fakeuser(self):

        kill_evt_except()
        ob = self.get()
        if not ob: return
        s = r_library_or_override_message(ob)
        if s:
            report(s)
            return

        if hasattr(ob, "asset_data") and ob.asset_data:
            if not hasattr(ob, "asset_clear"): return
            ob.asset_clear()
            update_scene_push(f"VMD {type(ob).__name__} Asset Clear")
        elif ob.use_fake_user:
            ob.use_fake_user = False
            update_scene_push(f"VMD {type(ob).__name__} Fake User disable")
        else:
            ob.use_fake_user = True
            update_scene_push(f"VMD {type(ob).__name__} Fake User enable")
        #|
    def evt_duplicate(self):

        kill_evt_except()
        ob = self.get()
        if not ob: return
        self.set(ob.copy(), undo_push=False)
        update_scene_push("VMD Texture Duplicate")
        #|
    def evt_mark_asset(self, is_report=True): pass
    def evt_rename(self, is_report=True):
        kill_evt_except()
        ob = self.get()
        if not ob: return

        if hasattr(self, "link_state"):
            if self.link_state == "LINK":
                if hasattr(ob, "override_create"):
                    try:
                        ob.override_create(remap_local_usages=True)
                        update_scene_push("VMD Override Create")
                    except: pass
                return
            if self.link_state == "OVERRIDE":
                try:
                    ob.make_local(clear_liboverride=True, clear_asset_data=True)
                    update_scene_push("VMD Make Local")
                except: pass
                return

        super().evt_rename(is_report=is_report)
        #|

    # <<< 1copy (0block_ButtonEnumObject_set,, ${'.objects':'.textures', 'Object':'Texture'}$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.textures: v = bpy.data.textures[v]
                    else:
                        if refresh: report("Texture not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.textures: v = bpy.data.textures[v]
                    else:
                        if refresh: report("Texture not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Texture")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Texture Type")
                    return

        setattr(self.pp, rna.identifier, v)
        if refresh: update_data()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_icon_arrow.dxy_upd(dx, dy)
        self.box_icon_object.dxy_upd(dx, dy)
        self.box_icon_fakeuser.dxy_upd(dx, dy)
        self.box_icon_duplicate.dxy_upd(dx, dy)
        self.box_icon_rename.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        self.blf_users.x += dx
        self.blf_users.y += dy
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        self.box_icon_arrow.bind_draw()
        self.box_icon_object.bind_draw()
        self.box_icon_fakeuser.bind_draw()
        self.box_icon_duplicate.bind_draw()
        self.box_icon_rename.bind_draw()
        #|
    def draw_blf(self):
        e = self.blf_value
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        e = self.blf_users
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        ob = getattr(self.pp, self.rna.identifier)

        if ob:
            if hasattr(ob, "asset_data") and ob.asset_data:
                user_state = "ASSET"
            else:
                user_state = "FAKEUSER"  if ob.use_fake_user else "NONE"

            if ob.library:
                link_state = "LINK"
            else:
                link_state = "OVERRIDE"  if hasattr(ob, "override_library") and ob.override_library else "NONE"

            if self.blf_value.unclip_text == ob.name and self.user_state == user_state and self.link_state == link_state and self.blf_users.unclip_text == ob.users: return


            blf_value = self.blf_value
            v = ob.name
            self.user_state = user_state
            self.link_state = link_state
            self.blf_users.unclip_text = ob.users
            self.blf_users.text = "9+"  if ob.users > 9 else str(ob.users)
            if self.box_icon_arrow.__class__ != GpuImg_delete:
                self.box_icon_arrow.__class__ = GpuImg_delete

            if user_state == "ASSET":
                if self.box_icon_fakeuser.__class__.__name__[-1] == "s":
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB_focus
                else:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_LIB
            elif user_state == "FAKEUSER":
                if self.box_icon_fakeuser.__class__.__name__[-1] == "s":
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON_focus
                else:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_ON
            else:
                if self.box_icon_fakeuser.__class__.__name__[-1] == "s":
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF_focus
                else:
                    self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF

            self.box_icon_duplicate.__class__ = GpuImgNull
            if link_state == "LINK":
                if self.box_icon_rename.__class__.__name__[-1] == "s":
                    self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK_focus
                else:
                    self.box_icon_rename.__class__ = GpuImg_FAKE_USER_LINK
            elif link_state == "OVERRIDE":
                if self.box_icon_rename.__class__.__name__[-1] == "s":
                    self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE_focus
                else:
                    self.box_icon_rename.__class__ = GpuImg_FAKE_USER_OVERRIDE
            else:
                if self.box_icon_rename.__class__.__name__[-1] == "s":
                    self.box_icon_rename.__class__ = GpuImg_rename_focus
                else:
                    self.box_icon_rename.__class__ = GpuImg_rename
        else:
            if self.blf_value.unclip_text == "" and self.user_state == "NONE" and self.link_state == "NONE" and self.blf_users.unclip_text == 0: return


            blf_value = self.blf_value
            v = ""
            self.user_state = "NONE"
            self.link_state = "NONE"
            self.blf_users.unclip_text = 0
            self.blf_users.text = ""
            if self.box_icon_arrow.__class__ != GpuImg_ADD:
                self.box_icon_arrow.__class__ = GpuImg_ADD

            if self.box_icon_fakeuser.__class__.__name__[-1] == "s":
                self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF_focus
            else:
                self.box_icon_fakeuser.__class__ = GpuImg_FAKE_USER_OFF

            self.box_icon_duplicate.__class__ = GpuImg_DUPLICATE
            if self.box_icon_rename.__class__.__name__[-1] == "s":
                self.box_icon_rename.__class__ = GpuImg_rename_focus
            else:
                self.box_icon_rename.__class__ = GpuImg_rename

        blf_value.unclip_text = v

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0] * 4)

        self.blf_users.x = round(self.box_icon_duplicate.r_center_x_float() - blfDimen(FONT0, self.blf_users.text)[0] / 2)
        #|
    #|
    #|
class ButtonEnumCacheFile(          # ButtonEnumTexture                                         
    ButtonEnumTexture):
    __slots__ = ()

    def __init__(self, w, rna, pp, allow_types=None, r_except_objects=None):
        super().__init__(w, rna, pp, allow_types=allow_types, r_except_objects=r_except_objects)
        self.box_icon_object.__class__ = GpuImg_ID_CACHEFILE
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        return DropDownEnumPointer(self, self.box_button.r_LRBT(), self.rna.name, bpy.data.cache_files,
            get_info=get_info_users, fixed_width=True)
        #|

    def evt_add_button(self):
        def end_fn(s):
            try:
                caches = [e for e in bpy.data.cache_files]
                bpy.ops.cachefile.open(filepath=s)
                new_cac = next(e for e in bpy.data.cache_files  if e not in caches)

                new_cac.user_clear()
                self.set(new_cac, undo_push=False)
                update_scene_push("VMD Import Cache File")
            except: pass

        OpScanFile.end_fn = end_fn
        bpy.ops.wm.vmd_scan_file("INVOKE_DEFAULT", filepath="")
        #|

    # <<< 1copy (0block_ButtonEnumObject_set,, ${'.objects':'.cache_files', 'Object':'Cache File'}$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.cache_files: v = bpy.data.cache_files[v]
                    else:
                        if refresh: report("Cache File not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.cache_files: v = bpy.data.cache_files[v]
                    else:
                        if refresh: report("Cache File not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Cache File")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Cache File Type")
                    return

        setattr(self.pp, rna.identifier, v)
        if refresh: update_data()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>
    #|
    #|
class ButtonEnumNodeTree(           # ButtonEnumTexture                                         
    ButtonEnumTexture):
    __slots__ = ()

    def __init__(self, w, rna, pp, allow_types=None, r_except_objects=None):
        super().__init__(w, rna, pp, allow_types=allow_types, r_except_objects=r_except_objects)
        self.box_icon_object.__class__ = GpuImg_ID_NODETREE
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        allow_types = self.allow_types
        if allow_types is None:
            node_groups = bpy.data.node_groups
        else:
            node_groups = [e  for e in bpy.data.node_groups  if e.type in allow_types]

        return DropDownEnumPointer(self, self.box_button.r_LRBT(), self.rna.name, node_groups,
            get_info=get_info_users, fixed_width=True)
        #|

    def evt_add_button(self):
        kill_evt_except()
        self.set(add_empty_geometry_node_group())
        #|

    # <<< 1copy (0block_ButtonEnumObject_set,, ${'.objects':'.node_groups', 'Object':'Node Group'}$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.node_groups: v = bpy.data.node_groups[v]
                    else:
                        if refresh: report("Node Group not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.node_groups: v = bpy.data.node_groups[v]
                    else:
                        if refresh: report("Node Group not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Node Group")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Node Group Type")
                    return

        setattr(self.pp, rna.identifier, v)
        if refresh: update_data()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>
    #|
    #|
class ButtonEnumVertexGroup(        # ButtonEnum                                                
    ButtonEnum):
    __slots__ = 'box_icon_object'

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        self.box_icon_arrow = GpuImg_unfold()
        v = getattr(self.pp, rna.identifier)
        self.blf_value = BlfClipColor("", "", 0, 0, COL_box_text_fg)
        self.font_id = FONT0

        self.box_icon_object = GpuImg_GROUP_VERTEX()
        #|

    def init_bat(self, L, R, T):
        blf_value = self.blf_value
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        self.box_icon_arrow.LRBT_upd(R0 - SIZE_widget[0], R0, B0, T0)
        LL = L0
        L0 += SIZE_widget[0]
        self.box_icon_object.LRBT_upd(LL, L0, B0, T0)

        blf_value.x = L0 + D_SIZE['font_main_dx']
        blf_value.y = B0 + D_SIZE['font_main_dy']
        blf_value.unclip_text = ""
        blf_value.text = ""
        self.upd_data()
        return B
        #|

    def r_default_value(self): return ""

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        # <<< 1copy (0block_ButtonEnumObject_modal_update_picker_focus,, ${
        #     'Admin.REDRAW()': '',
        #     'GpuImg_object_picker_focus': 'GpuImg_unfold',
        #     'GpuImg_object_picker': 'GpuImg_unfold'
        # }$)
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                        self.box_icon_arrow.__class__ = GpuImg_delete_focus
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    
        else:
            region = 0
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    
        # >>>
        Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.is_dark() is True: return

        self.box_button.color = COL_box_text
        if getattr(self.pp, self.rna.identifier):
            self.box_icon_arrow.__class__ = GpuImg_delete
        else:
            self.box_icon_arrow.__class__ = GpuImg_unfold
        Admin.REDRAW()
        #|

    def modal(self):
        # <<< 1copy (0block_ButtonEnumObject_modal_update_picker_focus,, ${
        #     'GpuImg_object_picker_focus': 'GpuImg_unfold',
        #     'GpuImg_object_picker': 'GpuImg_unfold'
        # }$)
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete_focus:
                        self.box_icon_arrow.__class__ = GpuImg_delete_focus
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        Admin.REDRAW()

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    Admin.REDRAW()
        else:
            region = 0
            if self.is_dark() is False:
                if self.get():
                    if self.box_icon_arrow.__class__ != GpuImg_delete:
                        self.box_icon_arrow.__class__ = GpuImg_delete
                        Admin.REDRAW()
                else:
                    if self.box_icon_arrow.__class__ != GpuImg_unfold:
                        self.box_icon_arrow.__class__ = GpuImg_unfold
                        Admin.REDRAW()

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    Admin.REDRAW()
        # >>>

        # <<< 1copy (0block_ButtonString_modal,, ${'self.to_dropdown()#ref':'self.evt_click(region)'}$)
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.evt_click(region)
            return True
        # >>>
        return False
        #|

    def to_modal_rm(self):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ], title=self.rna.name)
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        ob = self.r_object()
        if not hasattr(ob, "vertex_groups"): return

        return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, items=ob.vertex_groups)
        #|

    def evt_click(self, region=0):
        if region == 0:
            self.to_dropdown()
        else:
            if getattr(self.pp, self.rna.identifier):
                self.evt_delete_object()
            else:
                self.to_dropdown()
        #|
    def evt_delete_object(self):

        kill_evt_except()
        try:
            self.set("")
            Admin.REDRAW()
        except Exception as ex:
            DropDownOk(None, MOUSE, input_text=f'Unexpected error, please report to the author: 04\n{ex}')
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_icon_arrow.dxy_upd(dx, dy)
        self.box_icon_object.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def draw_box(self):
        self.box_button.bind_draw()
        self.box_icon_arrow.bind_draw()
        self.box_icon_object.bind_draw()
        #|

    def set(self, v, refresh=True, undo_push=True):
        rna = self.rna
        oldvalue = getattr(self.pp, self.rna.identifier)

        setattr(self.pp, rna.identifier, v)
        if refresh: update_data()

        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return



        blf_value = self.blf_value
        v = getattr(self.pp, self.rna.identifier)
        if v:
            if self.box_icon_arrow.__class__ != GpuImg_delete:
                self.box_icon_arrow.__class__ = GpuImg_delete
        else:
            if self.box_icon_arrow.__class__ != GpuImg_unfold:
                self.box_icon_arrow.__class__ = GpuImg_unfold

        blf_value.unclip_text = v
        if hasattr(self, "r_enum_items"):
            if v in self.r_enum_items():
                if self.is_dark() is True:
                    blf_value.color = COL_box_text_fg_ignore
                else:
                    blf_value.color = COL_box_text_fg
            else:
                if self.is_dark() is True:
                    blf_value.color = COL_box_text_fg_ignore
                else:
                    blf_value.color = COL_box_val_fg_error

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_icon_arrow.L - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class ButtonEnumUV(                 # ButtonEnumVertexGroup                                     
    ButtonEnumVertexGroup):
    __slots__ = ()

    def __init__(self, w, rna, pp):
        super().__init__(w, rna, pp)
        self.box_icon_object.__class__ = GpuImg_GROUP_UVS
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        ob = self.r_object()
        if not ob: return
        if hasattr(ob, "data"):
            if hasattr(ob.data, "uv_layers"):
                return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, items=ob.data.uv_layers)
        #|
    #|
    #|
class ButtonEnumGpLayer(            # ButtonEnumVertexGroup                                     
    ButtonEnumVertexGroup):
    __slots__ = 'r_enum_items'

    def __init__(self, w, rna, pp):
        self.r_enum_items = self.r_layers
        super().__init__(w, rna, pp)
        self.box_icon_object.__class__ = GpuImg_GREASEPENCIL
        #|

    def r_layers(self):
        ob = self.r_object()
        if ob:
            if hasattr(ob, "data"):
                if hasattr(ob.data, "layers"):
                    return ob.data.layers
        return r_collection_create(set())
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        ob = self.r_object()
        if not ob: return
        if hasattr(ob, "data"):
            if hasattr(ob.data, "layers"):
                return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, items=ob.data.layers)
        #|
    #|
    #|
class ButtonEnumVertexColor(        # ButtonEnumVertexGroup                                     
    ButtonEnumVertexGroup):
    __slots__ = ()

    def __init__(self, w, rna, pp):
        super().__init__(w, rna, pp)
        self.box_icon_object.__class__ = GpuImg_GROUP_VCOL
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        ob = self.r_object()
        if not ob: return
        if hasattr(ob, "data"):
            if hasattr(ob.data, "vertex_colors"):
                return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, items=ob.data.vertex_colors)
        #|
    #|
    #|
class ButtonEnumBone(               # ButtonEnumVertexGroup                                     
    ButtonEnumVertexGroup):
    __slots__ = 'r_armature'

    def __init__(self, w, rna, pp, r_armature):
        super().__init__(w, rna, pp)
        self.box_icon_object.__class__ = GpuImg_BONE_DATA
        self.r_armature = r_armature
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        ob = self.r_armature()
        if not ob: return
        if hasattr(ob, "data"):
            if hasattr(ob.data, "bones"):
                return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, items=ob.data.bones)
        #|
    #|
    #|
class ButtonEnumFalloff(            # ButtonEnumVertexGroup                                     
    ButtonEnumVertexGroup):
    __slots__ = ()

    D_get_icon = {}

    def __init__(self, w, rna, pp):
        super().__init__(w, rna, pp)
        self.box_icon_object.__class__ = GpuImgNull
        #|

    def inside_evt(self):
        if self.blf_value.color == COL_box_text_fg_ignore: pass
        else:
            self.box_button.color = COL_box_text_active
            Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.blf_value.color == COL_box_text_fg_ignore: pass
        else:
            self.box_button.color = COL_box_text
            Admin.REDRAW()
        #|

    def modal(self):
        # <<< 1copy (0block_ButtonString_modal,, $$)
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.to_dropdown()#ref
            return True
        # >>>
        return False
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        v = self.get()
        if v == None: v = "None"
        elif hasattr(self.rna, "enum_items"):
            if v in self.rna.enum_items: v = self.rna.enum_items[v].name

        return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, get_icon=self.get_icon)
        #|
    def get_icon(self, e):
        if e.name in ButtonEnumFalloff.D_get_icon: return ButtonEnumFalloff.D_get_icon[e.name]()
        return GpuImgNull()
        #|

    # <<< 1copy (0block_StructButtonEnum_evt_set,, $$)
    @ catch
    def to_modal_rm(self):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ], override_name={"dd_cut":"Copy Identifier"}, title=self.rna.name)
        #|

    @ catch
    def evt_area_cut(self, is_report=True):

        kill_evt_except()
        ob = self.get()
        if hasattr(ob, "name"):
            ob = r_ID_dp(ob)
            if not ob: return
        else:
            return
        bpy.context.window_manager.clipboard = f'{ob}'
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()

        if hasattr(self.rna, "enum_items"):
            v = self.get()
            if v == None: s = "None"
            elif isinstance(v, set):
                ls = [e.name  for e in self.rna.enum_items  if e.identifier in v]
                s = str(ls).replace("[", "{").replace("]", "}")
            else:
                s = self.rna.enum_items[v].name  if v in self.rna.enum_items else v
        else:
            s = self.get()

        bpy.context.window_manager.clipboard = f'{s}'
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            self.set(s)
            Admin.REDRAW()
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_reset_all(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value())
        #|
    @ catch
    def evt_area_detail(self):

        kill_evt_except()
        Detail(Detail.r_rna_info(self.rna))
        #|

    def get(self):
        return getattr(self.pp, self.rna.identifier)
        #|
    def set(self, v, refresh=True, undo_push=True): # allow input name, Nonetype
        rna = self.rna
        oldvalue = getattr(self.pp, rna.identifier)
        if v in rna.enum_items:
            setattr(self.pp, rna.identifier, v)
            if refresh: update_data()
            if hasattr(self, "set_callback"): self.set_callback()
            self.evt_undo_push(undo_push, oldvalue)
        else:
            if v == None:
                if hasattr(rna, "is_never_none") and rna.is_never_none: return
            else:
                for e in rna.enum_items:
                    if e.name == v:
                        setattr(self.pp, rna.identifier, e.identifier)
                        if refresh: update_data()
                        if hasattr(self, "set_callback"): self.set_callback()
                        self.evt_undo_push(undo_push, oldvalue)
                        return
    # >>>

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        blf_value = self.blf_value
        if blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return

        v = getattr(self.pp, self.rna.identifier)
        blf_value.unclip_text = v
        if v in ButtonEnumFalloff.D_get_icon:
            self.box_icon_object.__class__ = ButtonEnumFalloff.D_get_icon[v]
            blf_value.x = self.box_button.inner[0] + D_SIZE['font_main_dx'] + SIZE_widget[0]
        else:
            self.box_icon_object.__class__ = GpuImgNull
            blf_value.x = self.box_button.inner[0] + D_SIZE['font_main_dx']

        if v == None: v = "None"
        elif hasattr(self.rna, "enum_items"):
            if v in self.rna.enum_items: v = self.rna.enum_items[v].name

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class ButtonEnumIDType(             # ButtonEnumFalloff
    ButtonEnumFalloff):
    __slots__ = ()

    D_get_icon = {}

    def to_dropdown(self, killevt=True, select_all=None):


        return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name,
            items=self.rna.enum_items, get_icon=self.get_icon)

    def get_icon(self, e):
        s = f"GpuImg_ID_{e.identifier}"
        if hasattr(blg, s): return getattr(blg, s)()
        return GpuImgNull()
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        blf_value = self.blf_value
        if blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return

        v = getattr(self.pp, self.rna.identifier)
        blf_value.unclip_text = v
        s = f"GpuImg_ID_{v}"
        if hasattr(blg, s):
            self.box_icon_object.__class__ = getattr(blg, s)
            blf_value.x = self.box_button.inner[0] + D_SIZE['font_main_dx'] + SIZE_widget[0]
        else:
            self.box_icon_object.__class__ = GpuImgNull
            blf_value.x = self.box_button.inner[0] + D_SIZE['font_main_dx']

        if v == None: v = "None"
        else:
            if v in self.rna.enum_items: v = self.rna.enum_items[v].name

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class ButtonEnumDriverPath(         # ButtonEnumVertexGroup                                     
    ButtonEnumVertexGroup):
    __slots__ = 'r_ID'

    def __init__(self, w, rna, pp, r_ID):
        super().__init__(w, rna, pp)
        self.box_icon_object.__class__ = GpuImg_rna
        self.r_ID = r_ID
        #|

    def to_dropdown(self, killevt=True, select_all=None):

        ob = self.r_ID()
        if not ob: return

        if hasattr(ob, "animation_data") and hasattr(ob.animation_data, "drivers"):
            drivers = ob.animation_data.drivers
            if drivers:
                items = [NameValue(f'{fc.data_path}[{fc.array_index}]' if is_array_fcurve(ob, fc
                    ) else fc.data_path, fc)  for fc in drivers]

                def get_info(e):
                    name = r_fcurve_name(ob, e.value)
                    return ""  if name is None else name

                return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name,
                    items = items,
                    fixed_width = True,
                    get_info = get_info)

        return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, items=None)
        #|

    def check(self, ob):
        if hasattr(ob, "animation_data") and hasattr(ob.animation_data, "drivers"):
            drivers = ob.animation_data.drivers
            if drivers:
                datapath = self.get()
                if datapath:
                    if datapath[-1] == "]" and datapath[-2 : -1] in "0123456789":
                        i0 = datapath.rfind("[")
                        try:
                            index = int(datapath[i0 + 1 : -1])
                        except: pass
                        fc = drivers.find(datapath[ : i0], index=index)
                        if fc is not None: return fc
                    else:
                        fc = drivers.find(datapath)
                        if fc is not None: return fc
                else: return None

        setattr(self.pp, self.rna.identifier, "")
        return None
        #|
    #|
    #|
class ButtonEnumID(                 # ButtonEnumObject
    ButtonEnumObject):
    __slots__ = 'idtype'

    def __init__(self, w, rna, pp, idtype="OBJECT"):
        self.idtype = idtype
        super().__init__(w, rna, pp)
        #|

    def inside_evt(self):
        # <<< 1copy (0block_ButtonEnumID_update_picker_focus,, ${'Admin.REDRAW()':''}$)
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                clsname = self.box_icon_arrow.__class__.__name__
                if clsname == "GpuImgNull": pass
                elif clsname[-6 : ] != "_focus":
                    self.box_icon_arrow.__class__ = globals()[clsname + "_focus"]
                    

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    
        else:
            region = 0
            if self.is_dark() is False:
                clsname = self.box_icon_arrow.__class__.__name__
                if clsname == "GpuImgNull": pass
                elif clsname[-6 : ] == "_focus":
                    self.box_icon_arrow.__class__ = globals()[clsname[ : -6]]
                    

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    
        # >>>
        Admin.REDRAW()
        #|
    def outside_evt(self):
        if self.is_dark() is True: return

        self.box_button.color = COL_box_text
        clsname = self.box_icon_arrow.__class__.__name__
        if clsname == "GpuImgNull": pass
        elif clsname[-6 : ] == "_focus":
            self.box_icon_arrow.__class__ = globals()[clsname[ : -6]]
        Admin.REDRAW()
        #|

    def modal(self):
        # /* 0block_ButtonEnumID_update_picker_focus
        if MOUSE[0] >= self.box_icon_arrow.L:
            region = 1
            if self.is_dark() is False:
                clsname = self.box_icon_arrow.__class__.__name__
                if clsname == "GpuImgNull": pass
                elif clsname[-6 : ] != "_focus":
                    self.box_icon_arrow.__class__ = globals()[clsname + "_focus"]
                    Admin.REDRAW()

                if self.box_button.color != COL_box_text:
                    self.box_button.color = COL_box_text
                    Admin.REDRAW()
        else:
            region = 0
            if self.is_dark() is False:
                clsname = self.box_icon_arrow.__class__.__name__
                if clsname == "GpuImgNull": pass
                elif clsname[-6 : ] == "_focus":
                    self.box_icon_arrow.__class__ = globals()[clsname[ : -6]]
                    Admin.REDRAW()

                if self.box_button.color != COL_box_text_active:
                    self.box_button.color = COL_box_text_active
                    Admin.REDRAW()
        # */

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if isinstance(self.blf_value, list) and TRIGGER['pan']():
            self.to_area_pan_text()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True
        if TRIGGER['dd_preview']():
            if hasattr(self, "evt_area_preview"):
                self.evt_area_preview()
                return True
        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.evt_click(region)
            return True
        return False
        #|

    def submodal(self):
        if TRIGGER['ui_jump_to_target']():
            if self.get().__class__.__name__ == "Object":
                self.evt_jump_to_target()
            return True
        if TRIGGER['ui_mark_asset']():
            if hasattr(self.get(), "asset_data"):
                self.evt_mark_asset()
            return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()
        items = [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("dd_cut", self.evt_area_cut),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),
        ]
        if ob.__class__.__name__ == "Object":
            items.append(("ui_jump_to_target", self.evt_jump_to_target))
        if hasattr(ob, "asset_data"):
            items.append(("ui_mark_asset", self.evt_mark_asset))
        items.append(("Rename Object", self.evt_rename))

        override_name = {
            "dd_cut": "Copy Object Path",
            "ui_mark_asset": "Clear Asset"  if hasattr(ob, "asset_data") and ob.asset_data else "Mark as Asset"
        }
        append_rm_item_preview(self, items, self.rna)

        DropDownRMKeymap(self, MOUSE, items, override_name=override_name, title=self.rna.name)
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        if hasattr(self, "poll") and self.poll(self) == False: return

        idtype = self.idtype
        bpy_data_type = getattr(bpy.data, D_id_blendData[idtype], None)
        if bpy_data_type is None: return

        LRBT = self.box_button.r_LRBT()

        get_icon = None


        if idtype == "OBJECT": get_icon = geticon_Object
        if idtype == "IMAGE":
            return DropDownEnumImage(self, LRBT, self.rna.name, bpy_data_type)
        elif idtype == "TEXTURE":
            return DropDownEnumTexture(self, LRBT, self.rna.name, bpy_data_type)
        elif idtype == "MATERIAL":
            return DropDownEnumMaterial(self, LRBT, self.rna.name, bpy_data_type)

        return DropDownEnumPointer(self, LRBT, self.rna.name,
            bpy_data_type,
            self.allow_types,
            self.r_except_objects,
            get_icon = get_icon)
        #|

    def update_icon(self):
        idtype = self.idtype
        good_idtype = idtype in D_id_blendData and hasattr(bpy.data, D_id_blendData[idtype])
        if good_idtype is True:
            if self.is_dark() is True:
                self.light()
        else:
            if self.is_dark() is False:
                self.dark()

        ob = getattr(self.pp, self.rna.identifier)

        if ob:
            clsname = ob.__class__.__name__
            if clsname in D_cls_id:
                idtype = D_cls_id[clsname]

        if idtype == "OBJECT":
            if ob == None:
                name = ""
                self.box_icon_arrow.__class__ = GpuImg_object_picker
                self.box_icon_object.__class__ = GpuImgNull
            else:
                name = ob.name
                self.box_icon_arrow.__class__ = GpuImg_delete
                if hasattr(ob, "type"):
                    self.box_icon_object.__class__ = getattr(blg, f"GpuImg_OUTLINER_OB_{ob.type}", GpuImgNull)
                else:
                    self.box_icon_object.__class__ = GpuImg_ID_OBJECT
        else:
            self.box_icon_object.__class__ = getattr(blg, f"GpuImg_ID_{idtype}", GpuImgNull)
            if ob == None:
                name = ""
                self.box_icon_arrow.__class__ = GpuImg_unfold
            else:
                name = ob.name
                self.box_icon_arrow.__class__ = GpuImg_delete

        return name
        #|
    def check(self, idtype):
        if self.idtype == idtype:
            ob = getattr(self.pp, self.rna.identifier)
            if ob:
                try: ob.name
                except:
                    old_name = self.blf_value.unclip_text
                    if idtype in D_id_blendData:
                        bpy_data = getattr(bpy.data, D_id_blendData[idtype], None)
                        if bpy_data and old_name in bpy_data:
                            setattr(self.pp, self.rna.identifier, bpy_data[old_name])
                            self.update_icon()
                            return

                    setattr(self.pp, self.rna.identifier, None)
                    self.box_icon_arrow.__class__ = GpuImg_unfold
        else:
            self.idtype = idtype
            if getattr(self.pp, self.rna.identifier) == None: pass
            else:
                setattr(self.pp, self.rna.identifier, None)

            if self.box_icon_arrow.__class__ != GpuImg_unfold:
                self.box_icon_arrow.__class__ = GpuImg_unfold

        self.update_icon()
        #|

    def evt_click(self, region=0):
        if region == 0:
            self.to_dropdown()
        else:
            if self.get():
                self.evt_delete_object()
            else:
                if self.idtype == "OBJECT":
                    self.to_modal_picker()
                else:
                    self.to_dropdown()
        #|
    def evt_area_preview(self):

        kill_evt_except()
        mat = self.get()
        if mat:
            preview_datablock(mat)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        ob = getattr(self.pp, self.rna.identifier)
        if self.blf_value.unclip_text == (ob.name  if ob else ""): return


        blf_value = self.blf_value
        v = self.update_icon()

        blf_value.unclip_text = v

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class ButtonBoolArrayX:
    __slots__ = (
        'w',
        'rna',
        'pp',
        'r_pp',
        'r_object',
        'r_datapath_head',
        'box_button',
        'blf_value',
        'is_trigger_enable',
        'focus_index',
        'set_callback',
        'poll')

    def __init__(self, w, rna, pp, title=None):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp
        self.box_button = [GpuButtonBool()  for e in rna]
        if title is None:
            self.blf_value = [BlfColor(e.name, color=COL_box_button_fg)  for e in rna]
        else:
            self.blf_value = [BlfColor(e, color=COL_box_button_fg)  for e in title]
        #|

    def init_bat(self, L, R, T):
        # /* 0block_ButtonBoolArrayX_init_bat
        blfSize(FONT0, D_SIZE['font_main'])
        box_button = self.box_button
        blf_value = self.blf_value
        widget_rim = SIZE_border[3]
        full_h = D_SIZE['widget_full_h']
        width = (R - L) // len(box_button)

        B = T - full_h
        y = B + widget_rim + D_SIZE['font_main_dy']

        for r in range(len(box_button) - 1):
            R0 = L + width
            box_button[r].LRBT_upd(L, R0, B, T, widget_rim)
            e = blf_value[r]
            e.y = y
            e.x = floor((R0 + L - blfDimen(FONT0, e.text)[0]) / 2)
            L = R0

        box_button[-1].LRBT_upd(L, R, B, T, widget_rim)
        e = blf_value[-1]
        e.y = y
        e.x = floor((R + L - blfDimen(FONT0, e.text)[0]) / 2)

        self.upd_data()
        return B
        # */
    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_default_value(self, index): return self.rna[index].default

    def is_dark(self): return self.box_button[0].is_dark()
    def dark(self):
        for e in self.box_button: e.dark()
        for e in self.blf_value: e.color = COL_box_button_fg_ignore
        #|
    def light(self):
        for e in self.box_button: e.light()
        for e in self.blf_value: e.color = COL_box_button_fg
        #|
    def dark_index(self, r):
        self.box_button[r].dark()
        self.blf_value[r].color = COL_box_button_fg_ignore
        #|
    def light_index(self, r):
        self.box_button[r].light()
        self.blf_value[r].color = COL_box_button_fg
        #|

    def r_focus_index(self, mouse):
        for r, e in enumerate(self.box_button):
            if e.inbox(mouse): return r
        return None
        #|

    def focus_button(self, i):
        if self.box_button[i].state == 0:
            self.box_button[i].set_state_off_focus()
        #|
    def unfocus_button(self, i):
        if self.box_button[i].state == 1:
            self.box_button[i].set_state_off()
        #|
    def turnon_button(self, i):
        if self.box_button[i].state in {0, 1}:
            self.box_button[i].set_state_on()
        #|
    def turnoff_button(self, i):
        if self.box_button[i].state == 2:
            self.box_button[i].set_state_off()
        #|

    def inside(self, mouse):
        box_button = self.box_button
        if mouse[0] < box_button[0].L: return False
        if mouse[0] > box_button[-1].R: return False
        if mouse[1] > box_button[0].T: return False
        if mouse[1] < box_button[-1].B: return False
        return True
        #|
    def inside_evt(self):
        self.focus_index = self.r_focus_index(MOUSE)
        if self.focus_index != None:
            self.focus_button(self.focus_index)
            Admin.REDRAW()
        self.is_trigger_enable = True
        #|
    def outside_evt(self):
        if hasattr(self, "focus_index"):
            if self.focus_index != None:
                self.unfocus_button(self.focus_index)
                Admin.REDRAW()
        #|

    def modal(self):
        i = self.r_focus_index(MOUSE)
        if i != self.focus_index:

            if self.focus_index != None:
                self.unfocus_button(self.focus_index)
                Admin.REDRAW()

            self.focus_index = i
            self.is_trigger_enable = True

            if i != None:
                self.focus_button(i)
                Admin.REDRAW()

        if i == None: return False

        allow_trigger = self.is_trigger_enable
        if not allow_trigger:
            if EVT_TYPE[0] == "TIMER_REPORT": pass
            else:
                if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                    self.is_trigger_enable = True

        if TRIGGER['rm']():
            self.to_modal_rm(i)
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut(i)
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste(i)
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy(i)
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single(i)
            return True
        if TRIGGER['detail']():
            self.evt_area_detail(i)
            return True

        if hasattr(self, "submodal"):
            if self.submodal(i): return True

        if allow_trigger:
            if TRIGGER['click']():
                self.is_trigger_enable = False
                if is_first_press('click') == False:
                    self.set(_last_bool_state[0], i)
                else:
                    boo = not self.get(i)
                    self.set(boo, i)
                    _last_bool_state[0] = boo
                Admin.REDRAW()
                return True
        return False

    def to_modal_rm(self, i=0):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", lambda: self.evt_area_paste(i)),
            ("dd_copy", lambda: self.evt_area_copy(i)),
            ("valbox_reset_all", self.evt_area_reset_all),
            ("valbox_reset_single", lambda: self.evt_area_reset_single(i)),
            ("detail", lambda: self.evt_area_detail(i)),
        ], override_name={"valbox_reset_all":"Value Box Reset All"}, title=self.rna[i].name)
        #|

    @ catch
    def evt_area_cut(self, index=0, is_report=True):

        kill_evt_except()
        s = ""
        for r in range(len(self.rna)): s += f'{value_to_display(self.get(r))}, '

        bpy.context.window_manager.clipboard = s[: -2]
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_copy(self, index=0, is_report=True):

        kill_evt_except()
        bpy.context.window_manager.clipboard = f'{self.get(index)}'
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, index=0, is_report=True):

        kill_evt_except()
        Admin.REDRAW()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        s = s.strip()
        if s in {'True', 'true', '1', '1.0'}:
            self.set(True, index)
            return
        elif s in {'False', 'false', '0', '0.0'}:
            self.set(False, index)
            return

        try:
            Admin.REDRAW()
            if s.strip()[: 1] == "#":
                self.set(s, index)
                return

            array = calc_vec(s)
            if len(array) == 1:
                self.set(bool(int(array[0])), index)
            else:
                self.set([bool(int(e))  for e in array], (0, min(len(self.rna), len(array))))
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self, index=0):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_value(index), index)
        #|
    @ catch
    def evt_area_reset_all(self, index=0):

        kill_evt_except()
        Admin.REDRAW()
        for r in range(len(self.rna)):
            self.set(self.r_default_value(r), r)
        #|
    @ catch
    def evt_area_detail(self, index=0):

        kill_evt_except()
        Detail(Detail.r_rna_info(self.rna[index]))
        #|

    def dxy(self, dx, dy):
        for e in self.box_button: e.dxy_upd(dx, dy)
        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|
    def draw_box(self):
        for e in self.box_button: e.bind_draw()
        #|
    def draw_blf(self):
        blfSize(FONT0, D_SIZE['font_main'])
        for e in self.blf_value:
            blfColor(FONT0, *e.color)
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|

    def get(self, index):
        return getattr(self.pp, self.rna[index].identifier)
        #|
    def set(self, v, index, refresh=True, undo_push=True):
        rna = self.rna
        pp = self.pp
        if isinstance(index, int):
            oldvalue = getattr(pp, rna[index].identifier)
            setattr(pp, rna[index].identifier, v)
        else:
            oldvalue = None
            for r, v in zip(range(index[0], index[1]), v):
                setattr(pp, rna[r].identifier, v)
        if refresh: update_data()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue, index)
        #|
    def evt_undo_push(self, undo_push, oldvalue, index): pass

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        for r, e in enumerate(self.box_button):
            if self.get(r):
                if e.state in {0, 1}: self.turnon_button(r)
            else:
                if e.state in {0, 1}: continue
                self.turnoff_button(r)
        #|
    #|
    #|
class ButtonColor3(                 # StructButtonGetSetVector                                  
    StructButtonGetSetVector):
    __slots__ = (
        'w',
        'rna',
        'pp',
        'box_button',
        'color_value',
        'r_pp',
        'r_object',
        'r_datapath_head')

    def __init__(self, w, rna, pp):
        # /* 0block_buttonColor3_init
        self.w = w
        self.rna = rna
        self.pp = pp
        self.box_button = GpuRim([0.0, 0.0, 0.0, 1.0], COL_box_color_rim)
        self.color_value = None
        # */

    def init_bat(self, L, R, T):
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        self.upd_data()
        return B
        #|

    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_default_array(self): return self.rna.default_array

    def inside(self, mouse): return self.box_button.inbox(mouse)
    def inside_evt(self):
        self.box_button.color_rim = COL_box_color_rim_fo
        Admin.REDRAW()
        #|
    def outside_evt(self):
        self.box_button.color_rim = COL_box_color_rim
        Admin.REDRAW()
        #|

    def modal(self):
        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['dd_cut']():
            self.evt_area_cut()
            return True
        if TRIGGER['dd_paste']():
            self.evt_area_paste()
            return True
        if TRIGGER['dd_copy']():
            self.evt_area_copy()
            return True
        if TRIGGER['valbox_reset_all']():
            self.evt_area_reset_all()
            return True
        if TRIGGER['valbox_reset_single']():
            self.evt_area_reset_single()
            return True
        if TRIGGER['valbox_dd']():
            self.to_dropdown()
            return True
        if TRIGGER['detail']():
            self.evt_area_detail()
            return True

        if hasattr(self, "submodal"):
            if self.submodal(): return True

        if TRIGGER['click']():
            self.to_dropdown()
            return True
        return False
        #|

    def to_dropdown(self):

        DropDownColor(self, self.box_button, self.rna, self.pp)
        #|

    def to_modal_rm(self):


        DropDownRMKeymap(self, MOUSE, [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_all", self.evt_area_reset_all),
            ("detail", self.evt_area_detail),
        ])
        #|

    @ catch
    def evt_area_cut(self, is_report=True): self.evt_area_copy(is_report)
    @ catch
    def evt_area_copy(self, is_report=True):

        kill_evt_except()
        s = ""
        for e in self.get(): s += f'{value_to_display(e)}, '

        bpy.context.window_manager.clipboard = s[: -2]
        if is_report: report("Copy to Clipboard")
        #|
    @ catch
    def evt_area_paste(self, is_report=True):

        kill_evt_except()
        s = bpy.context.window_manager.clipboard
        if not s:
            if is_report: report("Clipboard is Empty")
            return

        try:
            array = calc_vec(s)
            Admin.REDRAW()
            ll = len(array)
            if ll > self.rna.array_length: array = array[: self.rna.array_length]
            self.set([float(v)  for v in array], (0, ll))
        except:
            if is_report: report("Invalid Input")
            return
        #|
    @ catch
    def evt_area_reset_single(self): self.evt_area_reset_all()
    @ catch
    def evt_area_reset_all(self):

        kill_evt_except()
        Admin.REDRAW()
        self.set(self.r_default_array(), (0, self.rna.array_length))
        #|
    @ catch
    def evt_area_detail(self):

        kill_evt_except()
        Detail(Detail.r_rna_info(self.rna))
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        #|
    def draw_box(self):
        for e, o in zip(self.box_button.color, self.color_value):
            if e != o:

                self.box_button.color[: 3] = self.color_value
                break

        self.box_button.bind_draw()
        #|
    def draw_blf(self): pass

    def upd_data(self):
        if self.color_value == self.get(): return
        self.color_value = self.get()
        #|
    #|
    #|
class ButtonColor3sRGB(             # ButtonColor3                                              
    ButtonColor3):
    __slots__ = 'color_vec3'

    def __init__(self, w, rna, pp):
        # <<< 1copy (0block_buttonColor3_init,, $$)
        self.w = w
        self.rna = rna
        self.pp = pp
        self.box_button = GpuRim([0.0, 0.0, 0.0, 1.0], COL_box_color_rim)
        self.color_value = None
        # >>>
        self.color_vec3 = [None] * 3
        #|

    def to_dropdown(self):

        DropDownColorSRGB(self, self.box_button, self.rna, self.pp, color_space="sRGB")
        #|

    def draw_box(self):
        for e, o in zip(self.color_value, self.color_vec3):
            if e != o:

                color_vec3 = self.color_value[0 : 3]
                self.color_vec3 = color_vec3
                self.box_button.color = (
                    L_rgb_to_glc[min(max(0, round(color_vec3[0] * 255)), 255)],
                    L_rgb_to_glc[min(max(0, round(color_vec3[1] * 255)), 255)],
                    L_rgb_to_glc[min(max(0, round(color_vec3[2] * 255)), 255)],
                    1.0)
                break

        self.box_button.bind_draw()
        #|
    #|
    #|
class ButtonColor4(                 # ButtonColor3                                              
    ButtonColor3):
    __slots__ = 'box_grid', 'box_rgb'

    def __init__(self, w, rna, pp):
        # /* 0block_buttonColor4_init
        self.w = w
        self.rna = rna
        self.pp = pp
        self.box_button = GpuRim(None, COL_box_color_rim)
        self.box_grid = GpuGrid()
        self.box_rgb = GpuBox()
        self.color_value = None
        # */

    def init_bat(self, L, R, T):
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        cx = (L0 + R0) // 2
        self.box_grid.LRBT_upd(cx, R0, B0, T0)
        self.box_rgb.LRBT_upd(L0, cx, B0, T0)
        self.upd_data()
        return B
        #|

    def dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_grid.dxy_upd(dx, dy)
        self.box_rgb.dxy_upd(dx, dy)
        #|
    def draw_box(self):
        self.box_grid.bind_draw()
        self.box_button.bind_draw()
        e = self.box_button.color
        self.box_rgb.bind_draw_color((e[0], e[1], e[2], 1.0))
        #|

    def upd_data(self):
        if self.color_value == self.get(): return
        v = self.get()
        self.box_button.color = v
        self.color_value = v
        #|
    #|
    #|
class ButtonColor4sRGB(             # ButtonColor4                                              
    ButtonColor4):
    __slots__ = 'color_vec4'

    def __init__(self, w, rna, pp):
        # <<< 1copy (0block_buttonColor4_init,, $$)
        self.w = w
        self.rna = rna
        self.pp = pp
        self.box_button = GpuRim(None, COL_box_color_rim)
        self.box_grid = GpuGrid()
        self.box_rgb = GpuBox()
        self.color_value = None
        # >>>
        self.color_vec4 = [None] * 4
        #|

    def to_dropdown(self):

        DropDownColorSRGB(self, self.box_button, self.rna, self.pp, color_space="sRGB")
        #|

    def draw_box(self):
        self.box_grid.bind_draw()
        for e, o in zip(self.color_value, self.color_vec4):
            if e != o:

                color_vec4 = self.color_value[0 : 4]
                self.color_vec4 = color_vec4
                r = L_rgb_to_glc[min(max(0, round(color_vec4[0] * 255)), 255)]
                g = L_rgb_to_glc[min(max(0, round(color_vec4[1] * 255)), 255)]
                b = L_rgb_to_glc[min(max(0, round(color_vec4[2] * 255)), 255)]
                self.box_button.color = r, g, b, color_vec4[3]
                self.box_rgb.color = r, g, b, 1.0
                break

        self.box_button.bind_draw()
        self.box_rgb.bind_draw()
        #|
    #|
    #|

#_c4#_c4#_c4#_c4
class ButtonBoolPref(               # ButtonBoolPref            ButtonBool                      
    StructUndoPushPref,
    ButtonBool):
    __slots__ = ()
class ButtonIntPref(                # StructUndoPushPref        ButtonInt                       
    StructUndoPushPref,
    ButtonInt):
    __slots__ = ()
class ButtonFloatPref(              # StructUndoPushPref        ButtonFloat                     
    StructUndoPushPref,
    ButtonFloat):
    __slots__ = ()
class ButtonIntVectorPref(          # StructUndoPushPrefVector  ButtonIntVector                 
    StructUndoPushPrefVector, ButtonIntVector):
    __slots__ = ()
class ButtonFloatVectorPref(        # StructUndoPushPrefVector  ButtonFloatVector               
    StructUndoPushPrefVector,
    ButtonFloatVector):
    __slots__ = ()
class ButtonStringPref(             # StructUndoPushPref        ButtonString                    
    StructUndoPushPref,
    ButtonString):
    __slots__ = ()

    def __init__(self, w, rna, pp, subtype_override=None):
        if subtype_override == "LINES":
            self.__class__ = ButtonStringXYPref
            self.__init__(w, rna, pp)
            return
        if rna.subtype in {"BYTE_STRING", "LINES"}:
            self.__class__ = ButtonStringXYPref
            self.__init__(w, rna, pp, subtype_override)
            return

        ButtonString.__init__(self, w, rna, pp, subtype_override)
        #|
    #|
    #|
class ButtonStringXYPref(           # StructUndoPushPref        ButtonStringXY                  
    StructUndoPushPref,
    ButtonStringXY):
    __slots__ = ()
class ButtonEnumPref(               # StructUndoPushPref        ButtonEnum                      
    StructUndoPushPref,
    ButtonEnum):
    __slots__ = ()
class ButtonColor3Pref(             # StructUndoPushPrefColor   ButtonColor3                    
    StructUndoPushPrefColor,
    ButtonColor3):
    __slots__ = ()
class ButtonColor4Pref(             # StructUndoPushPrefColor   ButtonColor4                    
    StructUndoPushPrefColor,
    ButtonColor4):
    __slots__ = ()
class ButtonColor3sRGBPref(         # StructUndoPushPrefColor   ButtonColor3sRGB                
    StructUndoPushPrefColor,
    ButtonColor3sRGB):
    __slots__ = ()
class ButtonColor4sRGBPref(         # StructUndoPushPrefColor   ButtonColor4sRGB                
    StructUndoPushPrefColor,
    ButtonColor4sRGB):
    __slots__ = ()
D_Preftype_button = {
    'BOOLEAN': ButtonBoolPref,
    'INT': ButtonIntPref,
    'FLOAT': ButtonFloatPref,
    'STRING': ButtonStringPref,
    'ENUM': ButtonEnumPref,
    'COLLECTION': None,
    'RNABUTTON': ButtonFn}
D_Preftype_button_array = {
    'BOOLEAN': None,
    'INT': ButtonIntVectorPref,
    'FLOAT': ButtonFloatVectorPref}

#_c4#_c4#_c4#_c4
class ButtonBoolTemp(               # ButtonBool                                                
    ButtonBool):
    __slots__ = ()

    def set(self, v, refresh=False, undo_push=False):
        oldvalue = getattr(self.pp, self.rna.identifier)
        setattr(self.pp, self.rna.identifier, v)
        if refresh: update_data()
        self.evt_undo_push(undo_push, oldvalue)

        self.upd_data()
        if hasattr(self, "set_callback"): self.set_callback(v)
        #|
    #|
    #|
class ButtonEnumXYTemp(             # ButtonEnumXY                                              
    ButtonEnumXY):
    __slots__ = ()

    def set(self, v, refresh=False, undo_push=False): # allow input name, Nonetype
        rna = self.rna
        oldvalue = getattr(self.pp, rna.identifier)
        if v in rna.enum_items:
            setattr(self.pp, rna.identifier, v)
            if refresh: update_data()
            self.evt_undo_push(undo_push, oldvalue)
        else:
            if v == None:
                if hasattr(rna, "is_never_none") and rna.is_never_none:
                    self.upd_data()
                    if hasattr(self, "set_callback"): self.set_callback(v)
                    return
            else:
                for e in rna.enum_items:
                    if e.name == v:
                        setattr(self.pp, rna.identifier, e.identifier)
                        if refresh: update_data()
                        self.evt_undo_push(undo_push, oldvalue)
                        self.upd_data()
                        if hasattr(self, "set_callback"): self.set_callback(v)
                        return

        self.upd_data()
        if hasattr(self, "set_callback"): self.set_callback(v)
        #|
    #|
    #|

SLOTS_ED = ("use_push",)
class StructPoll:
    __slots__ = ()

    def set(self, v, refresh=False, undo_push=True):
        if hasattr(self, "poll") and self.poll(self) == False: return
        if hasattr(self, "use_push") and self.use_push == False: undo_push = False
        super().set(v, refresh=refresh, undo_push=undo_push)
        #|
    #|
    #|
class StructPollVector:
    __slots__ = ()

    def set(self, v, index, refresh=False, undo_push=True):
        if hasattr(self, "poll") and self.poll(self) == False: return
        if hasattr(self, "use_push") and self.use_push == False: undo_push = False
        super().set(v, index, refresh=refresh, undo_push=undo_push)
        #|
    #|
    #|

class EdInt(            # StructPoll        StructPush      ButtonInt                               
    StructPoll,
    StructPush,
    ButtonInt):
    __slots__ = SLOTS_ED
class EdIntVector(      # StructPollVector  StructPush      ButtonIntVector
    StructPollVector,
    StructPush,
    ButtonIntVector):
    __slots__ = SLOTS_ED
class EdFloat(          # StructPoll        StructPush      ButtonFloat                             
    StructPoll,
    StructPush,
    ButtonFloat):
    __slots__ = SLOTS_ED
class EdFloatVector(    # StructPollVector  StructPush      ButtonFloatVector                   
    StructPollVector,
    StructPush,
    ButtonFloatVector):
    __slots__ = SLOTS_ED
class EdBool(           # StructPoll        StructPush      ButtonBool                          
    StructPoll,
    StructPush,
    ButtonBool):
    __slots__ = SLOTS_ED
class EdString(         # StructPoll        StructPush      ButtonString                        
    StructPoll,
    StructPush,
    ButtonString):
    __slots__ = SLOTS_ED
class EdStringVector(   # StructPoll        StructPush      ButtonStringVector                  
    StructPoll,
    StructPush,
    ButtonStringVector):
    __slots__ = SLOTS_ED
class EdEnum(           # StructPoll        StructPush      ButtonEnum                          
    StructPoll,
    StructPush,
    ButtonEnum):
    __slots__ = SLOTS_ED
class EdEnumIcon(       # StructPoll        StructPush      ButtonEnumIcon                      
    StructPoll,
    StructPush,
    ButtonEnumIcon):
    __slots__ = SLOTS_ED
class EdEnumIDType(     # StructPoll        StructPush      ButtonEnumIDType                    
    StructPoll,
    StructPush,
    ButtonEnumIDType):
    __slots__ = SLOTS_ED
class EdEnumDriverPath( # StructPoll        StructPush      ButtonEnumDriverPath                
    StructPoll,
    StructPush,
    ButtonEnumDriverPath):
    __slots__ = SLOTS_ED
class EdBoolflag(       # StructPollVector  StructPushIndex ButtonBoolArrayX                    
    StructPollVector,
    StructPushIndex,
    ButtonBoolArrayX):
    __slots__ = SLOTS_ED
class Edfn(             # ButtonFn                                                              
    ButtonFn):
    __slots__ = SLOTS_ED
class EdID(             # StructPoll        StructPush      ButtonEnumID                        
    StructPoll,
    StructPush,
    ButtonEnumID):
    __slots__ = SLOTS_ED
class EdBone(           # StructPoll        StructPush      ButtonEnumBone                      
    StructPoll,
    StructPush,
    ButtonEnumBone):
    __slots__ = SLOTS_ED

#_c4#_c4#_c4#_c4
class ButtonBoolCall(           # ButtonBool                                                    
    ButtonBool):
    __slots__ = 'set_callfront', 'get_default_value'

    def r_default_value(self):
        if hasattr(self, "get_default_value"): return self.get_default_value()
        return self.rna.default
        #|

    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "set_callfront"): v = self.set_callfront(v)

        oldvalue = getattr(self.pp, self.rna.identifier)
        setattr(self.pp, self.rna.identifier, v)
        if refresh: update_data()
        self.evt_undo_push(undo_push, oldvalue)

        if hasattr(self, "set_callback"): self.set_callback(v)
        #|
    #|
    #|
class ButtonStringMatchButton(  # ButtonString                                                  
    ButtonString):
    __slots__ = (
        'box_match_case',
        'box_match_case_bg',
        'box_match_whole_word',
        'box_match_whole_word_bg',
        'box_match_end',
        'box_match_end_bg',
        'box_match_hover',
        'is_match_case',
        'is_match_whole_word',
        'is_match_end',
        'set_callfront',
        'set_callback',
        'get_default_value')

    OFFSET_FAC = 0
    OFFSET_TEXT = ""

    def __init__(self, w, rna, pp, subtype_override=None):
        self.w = w
        self.rna = rna
        self.pp = pp
        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        v = getattr(pp, rna.identifier)
        self.blf_value = BlfClipColor(v, v, 0, 0, COL_box_text_fg)
        self.font_id = FONT0

        if subtype_override is None:
            if rna.subtype in D_subtype_display:
                self.draw_blf = self.i_draw_blf_subtype
                self.dxy = self.i_dxy_subtype
                self.blf_subtype = BlfColor(D_subtype_display[rna.subtype], 0, 0, COL_box_button_fg_info)
            else:
                self.draw_blf = self.i_draw_blf
                self.dxy = self.i_dxy
        else:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = BlfColor(subtype_override[0], 0, 0, COL_box_button_fg_info)

        self.box_match_case = GpuImg_filter_match_case()
        self.box_match_whole_word = GpuImg_filter_match_whole_word()
        self.box_match_end = GpuImg_filter_match_end_left()
        self.box_match_end_bg = GpuImg_filter_match_active()
        self.box_match_whole_word_bg = GpuImg_filter_match_active()
        self.box_match_case_bg = GpuImg_filter_match_active()
        self.is_match_end = P.filter_match_end
        self.is_match_case = P.filter_match_case
        self.is_match_whole_word = P.filter_match_whole_word
        self.box_match_hover = GpuImg_filter_match_hover()
        self.box_match_hover.set_draw_state(False)
        #|

    def r_default_value(self):
        if hasattr(self, "get_default_value"): return self.get_default_value()
        return self.rna.default
        #|

    def init_bat(self, L, R, T):
        cls = self.__class__
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value = self.blf_value
        L += round(SIZE_widget[0] * cls.OFFSET_FAC
            + blfDimen(FONT0, cls.OFFSET_TEXT)[0] + D_SIZE['font_main_title_offset'])
        B = T - D_SIZE['widget_full_h']
        self.box_button.LRBT_upd(L, R, B, T, SIZE_border[3])
        L0, R0, B0, T0 = self.box_button.inner
        blf_value.x = L0 + D_SIZE['font_main_dx']
        blf_value.y = B0 + D_SIZE['font_main_dy']
        blf_value.text = r_blf_clipping_end(
            blf_value.text, blf_value.x, R0 - D_SIZE['font_main_dx'])

        self.upd_match_button(L0, R0, B0, T0)
        return B
        #|

    def upd_match_button(self, L, R0, B0, T0):
        h = SIZE_widget[0]
        L0 = R0 - h
        if self.is_match_end == 1:
            if isinstance(self.box_match_end, GpuImg_filter_match_end_right):
                self.box_match_end.__class__ = GpuImg_filter_match_end_left
            self.box_match_end_bg.set_draw_state(True)
        elif self.is_match_end == 2:
            if isinstance(self.box_match_end, GpuImg_filter_match_end_left):
                self.box_match_end.__class__ = GpuImg_filter_match_end_right
            self.box_match_end_bg.set_draw_state(True)
        else:
            if isinstance(self.box_match_end, GpuImg_filter_match_end_right):
                self.box_match_end.__class__ = GpuImg_filter_match_end_left
            self.box_match_end_bg.set_draw_state(False)
        self.box_match_end.LRBT_upd(L0, R0, B0, T0)
        self.box_match_end_bg.LRBT_upd(L0, R0, B0, T0)

        R0 -= h
        L0 -= h
        self.box_match_whole_word.LRBT_upd(L0, R0, B0, T0)
        self.box_match_whole_word_bg.LRBT_upd(L0, R0, B0, T0)
        self.box_match_whole_word_bg.set_draw_state(self.is_match_whole_word)
        R0 -= h
        L0 -= h
        self.box_match_case.LRBT_upd(L0, R0, B0, T0)
        self.box_match_case_bg.LRBT_upd(L0, R0, B0, T0)
        self.box_match_case_bg.set_draw_state(self.is_match_case)
        #|

    def outside_evt(self):
        self.box_match_hover.set_draw_state(False)
        super().outside_evt()
        #|

    def modal(self):
        if MOUSE[0] >= self.box_match_case.L:
            if self.box_match_hover.set_draw_state(True): Admin.REDRAW()
            if MOUSE[0] >= self.box_match_end.L:
                ind = 2
                if not is_LRBT_match(self.box_match_end, self.box_match_hover):
                    Admin.REDRAW()
                    self.box_match_hover.LRBT_upd(*self.box_match_end.r_LRBT())
            elif MOUSE[0] >= self.box_match_whole_word.L:
                ind = 1
                if not is_LRBT_match(self.box_match_whole_word, self.box_match_hover):
                    Admin.REDRAW()
                    self.box_match_hover.LRBT_upd(*self.box_match_whole_word.r_LRBT())
            else:
                ind = 0
                if not is_LRBT_match(self.box_match_case, self.box_match_hover):
                    Admin.REDRAW()
                    self.box_match_hover.LRBT_upd(*self.box_match_case.r_LRBT())

            if TRIGGER['click']():
                if ind == 0: self.evt_toggle_match_case()
                elif ind == 1: self.evt_toggle_match_whole_word()
                else: self.evt_toggle_match_end()
                return True
        else:
            if self.box_match_hover.set_draw_state(False): Admin.REDRAW()
        return super().modal()
        #|

    def evt_toggle_match_case(self, v=None):

        kill_evt_except()
        Admin.REDRAW()
        if v == None: v = not self.is_match_case
        self.is_match_case = v
        self.upd_match_button(*self.box_button.inner)
        if hasattr(self, "set_callback"):
            self.set_callback((self.is_match_case, self.is_match_whole_word, self.is_match_end))
        #|
    def evt_toggle_match_whole_word(self, v=None):

        kill_evt_except()
        Admin.REDRAW()
        if v == None: v = not self.is_match_whole_word
        self.is_match_whole_word = v
        self.upd_match_button(*self.box_button.inner)
        if hasattr(self, "set_callback"):
            self.set_callback((self.is_match_case, self.is_match_whole_word, self.is_match_end))
        #|
    def evt_toggle_match_end(self, v=None):

        kill_evt_except()
        Admin.REDRAW()
        if v == None:
            v = self.is_match_end + 1
            if v == 3: v = 0
        self.is_match_end = v
        self.upd_match_button(*self.box_button.inner)
        if hasattr(self, "set_callback"):
            self.set_callback((self.is_match_case, self.is_match_whole_word, self.is_match_end))
        #|

    def i_dxy(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_match_case.dxy_upd(dx, dy)
        self.box_match_whole_word.dxy_upd(dx, dy)
        self.box_match_end.dxy_upd(dx, dy)
        self.box_match_case_bg.dxy_upd(dx, dy)
        self.box_match_whole_word_bg.dxy_upd(dx, dy)
        self.box_match_end_bg.dxy_upd(dx, dy)
        self.box_match_hover.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy
        #|
    def i_dxy_subtype(self, dx, dy):
        self.box_button.dxy_upd(dx, dy)
        self.box_match_case.dxy_upd(dx, dy)
        self.box_match_whole_word.dxy_upd(dx, dy)
        self.box_match_end.dxy_upd(dx, dy)
        self.box_match_case_bg.dxy_upd(dx, dy)
        self.box_match_whole_word_bg.dxy_upd(dx, dy)
        self.box_match_end_bg.dxy_upd(dx, dy)
        self.box_match_hover.dxy_upd(dx, dy)

        self.blf_value.x += dx
        self.blf_value.y += dy

        self.blf_subtype.x += dx
        self.blf_subtype.y += dy
        #|

    def draw_box(self):
        self.box_button.bind_draw()
        self.box_match_hover.bind_draw()
        self.box_match_case_bg.bind_draw()
        self.box_match_whole_word_bg.bind_draw()
        self.box_match_end_bg.bind_draw()
        self.box_match_case.bind_draw()
        self.box_match_whole_word.bind_draw()
        self.box_match_end.bind_draw()
        #|

    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "set_callfront"): v = self.set_callfront(v)

        oldvalue = getattr(self.pp, self.rna.identifier)
        if self.rna.subtype == "BYTE_STRING" and not isinstance(v, bytes): v = str.encode(v)
        setattr(self.pp, self.rna.identifier, v)
        if refresh: update_data()
        self.evt_undo_push(undo_push, oldvalue)

        if hasattr(self, "set_callback"): self.set_callback(v)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        if self.pp is None: return
        if self.blf_value.unclip_text == getattr(self.pp, self.rna.identifier): return


        blf_value = self.blf_value
        v = getattr(self.pp, self.rna.identifier)
        blf_value.unclip_text = v
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - 3 * SIZE_widget[0])
        #|
    #|
    #|

#_c4#_c4#_c4#_c4
@ successResult
def paste_full_data_path_as_driver_safe(s, fc, dp, ob, rna, pp, index=None, update_push=True):
    if r_library_editable(ob) is False:
        report(r_library_or_override_message(ob))
        return

    # if type(ob) != bpy.types.Object:
    #     report("This attribute does not support Reference Driver")
    #     return
    if not s:
        report("Clipboard is empty")
        return

    tar_obj, dr_path = r_obj_path_by_full_path(s)
    if tar_obj is None:
        report("Invalid path")
        return

    id_type = r_id_type(tar_obj)
    if id_type is None:
        report("Invalid Object ID Type")
        return

    if fc:
        pp.driver_remove(rna.identifier)  if index is None else pp.driver_remove(rna.identifier, index)

    if hasattr(rna, "bl_socket_idname"):
        fc = pp.driver_add(f'["{escape_identifier(rna.identifier)}"]')  if index is None else pp.driver_add(f'["{escape_identifier(rna.identifier)}"]', index)
    elif rna.is_animatable:
        fc = pp.driver_add(rna.identifier)  if index is None else pp.driver_add(rna.identifier, index)
    else:
        fc = r_md_driver_add(ob, pp.name, rna.identifier)

    vs = fc.driver.variables
    v = vs[0] if vs else vs.new()
    tar = v.targets[0]
    tar.id_type = id_type
    tar.id = tar_obj
    tar.data_path = dr_path
    fc.driver.expression = v.name

    if update_push:
        update_scene_push("VMD MD Paste Full Path as Driver")
        upd_link_data()
    #|

@ successResult
def add_new_driver(ob, rna, pp, index=None, exp="var", update_push=True):
    if r_library_editable(ob) is False:
        report(r_library_or_override_message(ob))
        return

    if hasattr(rna, "bl_socket_idname"):
        fc = pp.driver_add(f'["{escape_identifier(rna.identifier)}"]')  if index is None else pp.driver_add(f'["{escape_identifier(rna.identifier)}"]', index)
        driver = fc.driver
        driver.type = "SCRIPTED"
        driver.expression = exp
    elif rna.is_animatable:
        fc = pp.driver_add(rna.identifier)  if index is None else pp.driver_add(rna.identifier, index)
        driver = fc.driver
        driver.type = "SCRIPTED"
        driver.expression = exp
    else:
        # if type(ob) != bpy.types.Object:
        #     report("This attribute does not support Reference Driver")
        #     return

        r_md_driver_add(ob, pp.name, rna.identifier, exp=exp, use_variable=False)
    if update_push: update_scene_push("VMD Add Driver")
    #|

@ successResult
def add_new_keyframe(ob, rna, pp, index=None, update_push=True):
    if r_library_editable(ob) is False:
        report(r_library_or_override_message(ob))
        return

    if hasattr(rna, "bl_socket_idname"):
        if index is None:
            pp.keyframe_insert(f'["{escape_identifier(rna.identifier)}"]')
        else:
            pp.keyframe_insert(f'["{escape_identifier(rna.identifier)}"]', index=index)
    else:
        if not rna.is_animatable:
            report("This property cannot be animated")
            return

        if index is None:
            pp.keyframe_insert(rna.identifier)
        else:
            pp.keyframe_insert(rna.identifier, index=index)

    if update_push: update_scene_push("VMD Insert Keyframe")
    #|

@ successResult
def del_keyframe(ob, rna, pp, index=None, update_push=True):
    if r_library_editable(ob) is False:
        report(r_library_or_override_message(ob))
        return

    if hasattr(rna, "bl_socket_idname"):
        if index is None:
            pp.keyframe_delete(f'["{escape_identifier(rna.identifier)}"]')
        else:
            pp.keyframe_delete(f'["{escape_identifier(rna.identifier)}"]', index=index)
    else:
        if index is None:
            pp.keyframe_delete(rna.identifier)
        else:
            pp.keyframe_delete(rna.identifier, index=index)

    if update_push: update_scene_push("VMD Delete Keyframe")
    #|

@ successResult
def clear_keyframe(ob, fc, update_push=True):
    if r_library_editable(ob) is False:
        report(r_library_or_override_message(ob))
        return

    if ob.animation_data and ob.animation_data.action and ob.animation_data.action.fcurves:
        ob.animation_data.action.fcurves.remove(fc)

        if update_push: update_scene_push("VMD Clear Keyframe")
    #|

@ catch
def open_driver_editor_from(datablock, dp, index=None):

    w = D_EDITOR["DriverEditor"](
        id_class = "DriverEditor",
        use_pos = True,
        use_fit = True,
        pos_offset = (-15, 15)
    )
    w.set_driver_to(datablock, dp, index=index)
    #|

class Struct_bufn_keyframe:
    __slots__ = ()

    def bufn_keyframe(self):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=False)
        if pp is None: return

        if not self.rna.is_animatable:
            # if r_md_refdriver(ob, pp.name, self.rna.identifier):
            #     DropDownYesNo(None, MOUSE, self.evt_delete_driver, input_text="Do you want to delete the Reference Driver?")
            return

        dr = self.w.r_driver()
        if dr:
            DropDownYesNo(None, MOUSE, self.evt_delete_driver, input_text="Do you want to delete the Driver?")
        else:
            if not hasattr(self.w, "r_fcurve"): return
            fc = self.w.r_fcurve()
            if fc:
                kp = fc.keyframe_points
                ind_E = len(kp) -1
                r = bpy.context.scene.frame_current
                if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                    self.evt_insert_keyframe(False)
                else:
                    self.evt_delete_keyframe(False)
            else:
                self.evt_insert_keyframe(False)
        #_c4

    def evt_remove_from_keying_set(self):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        success, s = r_remove_from_keying_set(ob, f'{self.r_datapath_head()}{self.rna.identifier}')
        if s:
            DropDownOk(None, MOUSE, input_text=s)
        #|
    def evt_add_to_keying_set(self):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if not self.rna.is_animatable:
            report("This property cannot be animated")
            return

        success, s = r_add_to_keying_set(ob, f'{self.r_datapath_head()}{self.rna.identifier}')
        if s:
            DropDownOk(None, MOUSE, input_text=s)
        #|
    def evt_copy_full_data_path(self):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(True)}{self.rna.identifier}'
        report("Full Data Path is copied to the clipboard")
        #|
    def evt_copy_data_path(self):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(False)}{self.rna.identifier}'
        report("Data Path is copied to the clipboard")
        #|
    def evt_paste_full_data_path_as_driver(self):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if self.rna.identifier == "name":
            report('Cannot add driver on "Name" attribute')
            return
        if hasattr(self.w, "r_fcurve"):
            if self.w.r_fcurve():
                report("Unable to add driver when keyframe already exists")
                return

        success, ex = paste_full_data_path_as_driver_safe(
            bpy.context.window_manager.clipboard,
            self.w.r_driver(),
            self.r_datapath_head(),
            ob,
            self.rna,
            pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to add Driver.\n{ex}')
        #|
    def evt_delete_driver(self):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if r_library_editable(ob) is False:
            report(r_library_or_override_message(ob))
            return

        if self.rna.is_animatable:
            dr = self.w.r_driver()
            if dr: ob.animation_data.drivers.remove(dr)
            else:
                report("Driver not found")
                return

            self.set(self.get())
            update_scene_push("VMD Delete Driver")
        else:
            return
            # if type(ob) != bpy.types.Object: return
            # if r_md_driver_remove(ob, pp.name, self.rna.identifier): pass
            # else:
            #     report("Driver not found")
            #     return

            # self.set(self.get())
            # update_scene_push("VMD Delete Reference Driver")
        #|
    def evt_add_driver(self, exp="var", replace=False, use_editor=False):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if self.rna.identifier == "name":
            report('Cannot add driver on "Name" attribute')
            return
        if hasattr(self.w, "r_fcurve"):
            if self.w.r_fcurve():
                report("Unable to add driver when keyframe already exists")
                return
        if self.w.r_driver():
            if not replace:
                if use_editor:
                    open_driver_editor_from(ob, f'{self.r_datapath_head(False)}{self.rna.identifier}')
                return

            ob.animation_data.drivers.remove(self.w.r_driver())

        success, ex = add_new_driver(ob, self.rna, pp, exp=exp)

        if success is False:
            DropDownOk(None, MOUSE, input_text=f'Failed to add Driver.\n{ex}')
        elif use_editor and P.is_open_driver_editor:
            open_driver_editor_from(ob, f'{self.r_datapath_head(False)}{self.rna.identifier}')
        #|
    def evt_clear_keyframe(self, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if not hasattr(self.w, "r_fcurve"): return
        fc = self.w.r_fcurve()
        if not fc:
            report("Keyframe not found")
            return

        success, ex = clear_keyframe(ob, fc)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to Clear Keyframe.\n{ex}')
        #|
    def evt_delete_keyframe(self, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if not hasattr(self.w, "r_fcurve"): return
        if not self.w.r_fcurve():
            report("Keyframe not found")
            return

        success, ex = del_keyframe(ob, self.rna, pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to Delete Keyframe.\n{ex}')
        #|
    def evt_insert_keyframe(self, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if self.w.r_driver():
            report("Unable to Insert Keyframe when Driver already exists")
            return

        success, ex = add_new_keyframe(ob, self.rna, pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to add Keyframe.\n{ex}')
        #|

    def evt_batch(self):


        pp = self.r_pp()
        if not hasattr(pp, "bl_rna"): return
        rnas = pp.bl_rna.properties
        if "show_on_cage" not in rnas: return
        if not hasattr(self, "r_object"): return
        if not hasattr(self, "r_datapath_head"): return

        button_width_2 = round(D_SIZE['widget_width'] * 1.5)
        md_type = pp.type
        current_value = self.get()
        self_object = self.r_object()
        attr = self.rna.identifier

        ppp = SimpleNamespace()
        ppp.Use_code = False
        ppp.Affect_selected_objects = True
        ppp.Affect_self_object = False
        ppp.Only_same_type = True
        ppp.Only_same_name = False

        ppp.show_on_cage = False
        ppp.show_in_editmode = False
        ppp.show_viewport = False
        ppp.show_render = False
        ppp.use_apply_on_spline = False

        for at in getattr(ModAttr, md_type, []): setattr(ppp, at, False)
        # for at in getattr(ModRefAttr, md_type, []): setattr(ppp, at, False)
        for at in getattr(ModArrayAttr, md_type, []):
            for r in range(rnas[at].array_length): setattr(ppp, f'{at}{r}', False)

        if hasattr(self, "array_length"):
            index = self.active_index  if hasattr(self, "active_index") else 0
            setattr(ppp, f'{attr}{index}', True)
            datapath = f'{self.r_datapath_head(True)}{attr}[{index}]'
        else:
            setattr(ppp, attr, True)
            datapath = f'{self.r_datapath_head(True)}{attr}'

        def button_fn_cancel(button=None):
            ddw.fin_from_area()
            #|
        def button_fn_run(button=None):


            if ppp.Use_code:
                a0 = ddw.areas[0]
                success, message = eval_batch_operation(self_object, pp, a0.tex.as_string())
                if success:
                    ddw.fin_from_area()
                    update_scene_push("VMD MD Batch Operation")
                    if message: DropDownOk(None, MOUSE, input_text=message)
                else:
                    update_scene_push("VMD MD Batch Operation")
                    DropDownOk(None, MOUSE, input_text=message)
            else:
                ddw.fin_from_area()

                success, message = eval_batch_operation(self_object, pp,
                    r_code_batch_operation(self_object, ppp, datapath, current_value))

                if success:
                    update_scene_push("VMD MD Batch Operation")
                    if message: DropDownOk(None, MOUSE, input_text=message)
                else:
                    update_scene_push("VMD MD Batch Operation")
                    DropDownOk(None, MOUSE, input_text=f'Execution failed, please report to the author.\n{message}')
            #|
        def button_set_callback(v=None):
            if ppp.Use_code:
                if bb0_items[0].is_dark() is False:
                    for e in bb0_items:
                        if hasattr(e, "dark"): e.dark()
                    for e in bb1_items:
                        if hasattr(e, "dark"): e.dark()
                    for e in bb2_items:
                        if hasattr(e, "dark"): e.dark()
                return

            if bb0_items[0].is_dark() is True:
                for e in bb0_items:
                    if hasattr(e, "light"): e.light()
                for e in bb1_items:
                    if hasattr(e, "light"): e.light()
                for e in bb2_items:
                    if hasattr(e, "light"): e.light()

            a0 = ddw.areas[0]
            a0.evt_del_all(undo_push=False, evtkill=False)
            a0.beam_input_unpush(r_code_batch_operation(self_object, ppp, datapath, current_value))
            #|
        def r_button_width(): return button_width_2

        gap = SIZE_button[1]
        BlockUtil.DEFAULT_FOLD_STATE = False

        area_items = []
        button_run = ButtonFn(None, RNA_run, button_fn_run)
        button_cancel = ButtonFn(None, RNA_cancel, button_fn_cancel)

        ddw = DropDownInfoUtil(self, MOUSE,
            [ButtonSplit(None, button_run, button_cancel, gap)],
            area_items = area_items,
            title = "Batch Operation",
            input_text = r_code_batch_operation(self_object, ppp, datapath, current_value),
            font_id=FONT1, row_count=11, width_fac=4.0, block_size=14)

        area_tab = ddw.r_area_tab()

        b0 = Blocks(area_tab)
        bb0 = BlockUtil(b0, None, Title("Effects"))
        bb0.area = area_tab
        bb1 = BlockUtil(b0, None, Title("Visibility"))
        bb1.area = area_tab
        bb2 = BlockUtil(b0, None, Title("Attributes"))
        bb2.area = area_tab
        g_use_code = ButtonGroupAlignTitleLeft(b0, ButtonBoolTemp(None, RnaBool("Use_code", "Override Code"), ppp))
        g_use_code.button0.set_callback = button_set_callback
        b0.buttons = [g_use_code, bb0, bb1, bb2]

        bb0_items = [
            ButtonGroupAlignL(bb0, ButtonBoolTemp(None, RnaBool("Affect_selected_objects", "Selected Objects"), ppp)),
            ButtonGroupAlignL(bb0, ButtonBoolTemp(None, RnaBool("Affect_self_object", "Self Object"), ppp)),
            ButtonSep(3),
            ButtonGroupAlignLR(bb0, ButtonBoolTemp(None, RnaBool("Only_same_type", "Same Modifier Type"), ppp), title_head="Only"),
            ButtonGroupAlignL(bb0, ButtonBoolTemp(None, RnaBool("Only_same_name", "Same Modifier Name"), ppp)),
        ]
        for r in {0, 1, 3, 4}:
            e = bb0_items[r]
            e.r_button_width = r_button_width
            e.button0.set_callback = button_set_callback
        bb0.items = bb0_items

        bb1_items = [
            ButtonGroupAlignLR(bb1, ButtonBoolTemp(None, RnaBool("show_on_cage", "On Cage"), ppp), title_head = "Show"),
            ButtonGroupAlignL(bb1, ButtonBoolTemp(None, RnaBool("show_in_editmode", "Edit Mode"), ppp)),
            ButtonGroupAlignL(bb1, ButtonBoolTemp(None, RnaBool("show_viewport", "Viewport"), ppp)),
            ButtonGroupAlignL(bb1, ButtonBoolTemp(None, RnaBool("show_render", "Render"), ppp)),
            ButtonSep(3),
            ButtonGroupAlignL(bb1, ButtonBoolTemp(None, RnaBool("use_apply_on_spline", "Apply on Spline"), ppp)),
        ]
        for r in {0, 1, 2, 3, 5}:
            e = bb1_items[r]
            e.r_button_width = r_button_width
            e.button0.set_callback = button_set_callback
        bb1.items = bb1_items
        bb2_items = []
        for at in getattr(ModAttr, md_type, []):
            e = ButtonGroupAlignL(bb2, ButtonBoolTemp(None, RnaBool(at, rnas[at].name), ppp))
            e.r_button_width = r_button_width
            e.button0.set_callback = button_set_callback
            bb2_items.append(e)

        bb2_items.append(ButtonSep(3))
        # for at in getattr(ModRefAttr, md_type, []):
        #     e = ButtonGroupAlignL(bb2, ButtonBoolTemp(None, RnaBool(at, rnas[at].name), ppp))
        #     e.r_button_width = r_button_width
        #     e.button0.set_callback = button_set_callback
        #     bb2_items.append(e)

        bb2_items.append(ButtonSep(3))
        for at in getattr(ModArrayAttr, md_type, []):
            r = 0
            e = ButtonGroupAlignLR(bb2, ButtonBoolTemp(None, RnaBool(f'{at}{r}', f'{rnas[at].name} [{r}]'), ppp), title=str(r), title_head=rnas[at].name)
            e.r_button_width = r_button_width
            e.button0.set_callback = button_set_callback
            bb2_items.append(e)

            for r in range(1, rnas[at].array_length):
                e = ButtonGroupAlignL(bb2, ButtonBoolTemp(None, RnaBool(f'{at}{r}', f'{rnas[at].name} [{r}]'), ppp), title=str(r))
                e.r_button_width = r_button_width
                e.button0.set_callback = button_set_callback
                bb2_items.append(e)

            bb2_items.append(ButtonSep(3))

        bb2.items = bb2_items

        area_items.append(b0)
        area_tab.init_items_tab()
        #|

    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "poll") and self.poll(self) == False: return
        if r_library_editable(self.r_object()) is False:
            report(r_library_or_override_message(self.r_object()))
            return
        if isinstance(v, str) and v[: 1] == "#":
            self.evt_add_driver(exp=v[1 :], replace=True)
        else:
            super().set(v, refresh=refresh, undo_push=undo_push)
        #|
    #|
    #|
class Struct_bufn_keyframe_array:
    __slots__ = ()

    def bufn_keyframe(self, index):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if r_library_editable(ob) is False: return

        rna = self.rna[index]
        attr = rna.identifier
        if not rna.is_animatable:
            # if r_md_refdriver(ob, pp.name, attr):
            #     DropDownYesNo(None, MOUSE, self.evt_delete_driver, input_text="Do you want to delete the Reference Driver?")
            return

        dr = self.w.r_driver()[index]
        if dr:
            DropDownYesNo(None, MOUSE, self.evt_delete_driver, input_text="Do you want to delete the Driver?")
        else:
            if not hasattr(self.w, "r_fcurve"): return
            fc = self.w.r_fcurve()[index]
            if fc:
                kp = fc.keyframe_points
                ind_E = len(kp) -1
                r = bpy.context.scene.frame_current
                if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                    self.evt_insert_keyframe(index=index, evtkill=False)
                else:
                    self.evt_delete_keyframe(index=index, evtkill=False)
            else:
                self.evt_insert_keyframe(index=index, evtkill=False)
        #|

    def submodal(self, i):
        if TRIGGER['ui_remove_from_keying_set_all']():
            self.evt_remove_from_keying_set_all()
            return True
        if TRIGGER['ui_add_to_keying_set_all']():
            self.evt_add_to_keying_set_all()
            return True
        if TRIGGER['ui_remove_from_keying_set']():
            self.evt_remove_from_keying_set(i)
            return True
        if TRIGGER['ui_add_to_keying_set']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path(i)
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path(i)
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver(i)
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver(i)
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(i, use_editor=True)
            return True
        if TRIGGER['ui_clear_keyframe']():
            self.evt_clear_keyframe(i)
            return True
        if TRIGGER['ui_delete_keyframe']():
            self.evt_delete_keyframe(i)
            return True
        if TRIGGER['ui_insert_keyframe']():
            self.evt_insert_keyframe(i)
            return True
        if TRIGGER['ui_batch']():
            if hasattr(self, "evt_batch"):
                self.evt_batch(i)
                return True
        return False
        #|

    def evt_remove_from_keying_set_all(self, index=0):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        ss = ""
        for rna in self.rna:
            success, s = r_remove_from_keying_set(ob, f'{self.r_datapath_head()}{rna.identifier}')
            if s: ss += f"{s}\n"
        if ss:
            DropDownOk(None, MOUSE, input_text=ss)
        #|
    def evt_remove_from_keying_set(self, index=0):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        success, s = r_remove_from_keying_set(ob, f'{self.r_datapath_head()}{self.rna[index].identifier}')
        if s:
            DropDownOk(None, MOUSE, input_text=s)
        #|
    def evt_add_to_keying_set_all(self, index=0):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if not self.rna[0].is_animatable:
            report("This property cannot be animated")
            return

        ss = ""
        for rna in self.rna:
            success, s = r_add_to_keying_set(ob, f'{self.r_datapath_head()}{rna.identifier}')
            if s: ss += f"{s}\n"
        if ss:
            DropDownOk(None, MOUSE, input_text=ss)
        #|
    def evt_add_to_keying_set(self, index=0):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if not self.rna[index].is_animatable:
            report("This property cannot be animated")
            return

        success, s = r_add_to_keying_set(ob, f'{self.r_datapath_head()}{self.rna[index].identifier}')
        if s:
            DropDownOk(None, MOUSE, input_text=s)
        #|
    def evt_copy_full_data_path(self, index=0):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(True)}{self.rna[index].identifier}'
        report("Full Data Path is copied to the clipboard")
        #|
    def evt_copy_data_path(self, index=0):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(False)}{self.rna[index].identifier}'
        report("Data Path is copied to the clipboard")
        #|
    def evt_paste_full_data_path_as_driver(self, index=0):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if hasattr(self.w, "r_fcurve"):
            if self.w.r_fcurve()[index]:
                report("Unable to add driver when keyframe already exists")
                return

        success, ex = paste_full_data_path_as_driver_safe(
            bpy.context.window_manager.clipboard,
            self.w.r_driver()[index],
            self.r_datapath_head(),
            ob,
            self.rna[index],
            pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to add Driver.\n{ex}')
        #|
    def evt_delete_driver(self, index=0):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if r_library_editable(ob) is False:
            report(r_library_or_override_message(ob))
            return

        if self.rna[index].is_animatable:
            dr = self.w.r_driver()[index]
            if dr: ob.animation_data.drivers.remove(dr)
            else:
                report("Driver not found")
                return

            self.set(self.get(index))
            update_scene_push("VMD Delete Driver")
        else:
            return
            # if type(ob) != bpy.types.Object: return
            # if r_md_driver_remove(ob, pp.name, self.rna[index].identifier): pass
            # else:
            #     report("Driver not found")
            #     return

            # self.set(self.get(index))
            # update_scene_push("VMD Delete Reference Driver")
        #|
    def evt_add_driver(self, index=0, exp="var", replace=False, use_editor=False):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if hasattr(self.w, "r_fcurve"):
            if self.w.r_fcurve()[index]:
                report("Unable to add driver when keyframe already exists")
                return
        if self.w.r_driver()[index]:
            if not replace:
                if use_editor:
                    open_driver_editor_from(ob, f'{self.r_datapath_head(False)}{self.rna[index].identifier}')
                return

            ob.animation_data.drivers.remove(self.w.r_driver()[index])

        success, ex = add_new_driver(ob, self.rna[index], pp, exp=exp)

        if success is False:
            DropDownOk(None, MOUSE, input_text=f'Failed to add Driver.\n{ex}')
        elif use_editor and P.is_open_driver_editor:
            open_driver_editor_from(ob, f'{self.r_datapath_head(False)}{self.rna[index].identifier}')
        #|
    def evt_clear_keyframe(self, index=0, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if not hasattr(self.w, "r_fcurve"): return
        fc = self.w.r_fcurve()[index]
        if not fc:
            report("Keyframe not found")
            return

        success, ex = clear_keyframe(ob, fc)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to Clear Keyframe.\n{ex}')
        #|
    def evt_delete_keyframe(self, index=0, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if not hasattr(self.w, "r_fcurve"): return
        if not self.w.r_fcurve()[index]:
            report("Keyframe not found")
            return

        success, ex = del_keyframe(ob, self.rna[index], pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to Delete Keyframe.\n{ex}')
        #|
    def evt_insert_keyframe(self, index=0, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if self.w.r_driver()[index]:
            report("Unable to Insert Keyframe when Driver already exists")
            return

        success, ex = add_new_keyframe(ob, self.rna[index], pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to add Keyframe.\n{ex}')
        #|

    def evt_batch(self, index=0):
        e = SimpleNamespace()
        e.rna = self.rna[index]
        e.pp = self.pp
        e.r_pp = self.r_pp
        e.r_object = self.r_object
        e.r_datapath_head = self.r_datapath_head
        e.get = lambda: self.get(index)
        Struct_bufn_keyframe.evt_batch(e)
        #|

    def to_modal_rm(self, i=0):

        items = [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", lambda: self.evt_area_paste(i)),
            ("dd_copy", lambda: self.evt_area_copy(i)),
            ("valbox_reset_all", self.evt_area_reset_all),
            ("valbox_reset_single", lambda: self.evt_area_reset_single(i)),
            ("detail", lambda: self.evt_area_detail(i)),

            ("ui_remove_from_keying_set_all", self.evt_remove_from_keying_set_all),
            ("ui_add_to_keying_set_all", self.evt_add_to_keying_set_all),
            ("ui_remove_from_keying_set", lambda: self.evt_remove_from_keying_set(i)),
            ("ui_add_to_keying_set", lambda: self.evt_add_to_keying_set(i)),
            ("ui_copy_full_data_path", lambda: self.evt_copy_full_data_path(i)),
            ("ui_copy_data_path", lambda: self.evt_copy_data_path(i)),
            ("ui_paste_full_data_path_as_driver", lambda: self.evt_paste_full_data_path_as_driver(i)),
            ("ui_delete_driver", lambda: self.evt_delete_driver(i)),
            ("ui_add_driver", lambda: self.evt_add_driver(i, use_editor=True)),
            ("ui_clear_keyframe", lambda: self.evt_clear_keyframe(i)),
            ("ui_delete_keyframe", lambda: self.evt_delete_keyframe(i)),
            ("ui_insert_keyframe", lambda: self.evt_insert_keyframe(i)),
        ]
        override_name = {"valbox_reset_all":"Value Box Reset All"}
        if hasattr(self, "evt_batch"):
            items.append(("ui_batch", lambda: self.evt_batch(i)))

        DropDownRMKeymap(self, MOUSE, items, override_name=override_name, title=self.rna[i].name)
        #|

    def set(self, v, index=0, refresh=True, undo_push=True):
        if hasattr(self, "poll") and self.poll(self) == False: return
        if r_library_editable(self.r_object()) is False: return
        if isinstance(v, str) and v[: 1] == "#":
            self.evt_add_driver(index=index, exp=v[1 :], replace=True)
        else:
            super().set(v, index, refresh=refresh, undo_push=undo_push)
        #|
    #|
    #|
class Struct_bufn_keyframe_string(  # Struct_bufn_keyframe                                      
    Struct_bufn_keyframe):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        if TRIGGER['ui_batch']():
            if hasattr(self, "evt_batch"):
                self.evt_batch()
                return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()
        items = [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            # ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            # ("ui_delete_driver", self.evt_delete_driver),
            # ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
        ]
        # override_name = {
        #     "ui_paste_full_data_path_as_driver": "Paste Full Data Path as Reference Driver",
        #     "ui_delete_driver": "Delete Reference Driver",
        #     "ui_add_driver": "Add Reference Driver"
        # }
        if hasattr(self, "evt_batch"):
            items.append(("ui_batch", self.evt_batch))

        DropDownRMKeymap(self, MOUSE, items, override_name=None, title=self.rna.name)
        #|
    #|
    #|
class StructButtonEnumAnim(         # Struct_bufn_keyframe                                      
    Struct_bufn_keyframe):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_remove_from_keying_set_all']():
            self.evt_remove_from_keying_set()
            return True
        if TRIGGER['ui_add_to_keying_set_all']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_remove_from_keying_set']():
            self.evt_remove_from_keying_set()
            return True
        if TRIGGER['ui_add_to_keying_set']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        if TRIGGER['ui_clear_keyframe']():
            self.evt_clear_keyframe()
            return True
        if TRIGGER['ui_delete_keyframe']():
            self.evt_delete_keyframe()
            return True
        if TRIGGER['ui_insert_keyframe']():
            self.evt_insert_keyframe()
            return True
        if TRIGGER['ui_batch']():
            if hasattr(self, "evt_batch"):
                self.evt_batch()
                return True
        return False
        #|

    def to_modal_rm(self):

        items = [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_remove_from_keying_set", self.evt_remove_from_keying_set),
            ("ui_add_to_keying_set", self.evt_add_to_keying_set),
            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            ("ui_delete_driver", self.evt_delete_driver),
            ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            ("ui_clear_keyframe", self.evt_clear_keyframe),
            ("ui_delete_keyframe", self.evt_delete_keyframe),
            ("ui_insert_keyframe", self.evt_insert_keyframe),
        ]
        override_name = {"dd_cut":"Copy Identifier"}
        if hasattr(self, "evt_batch"):
            items.append(("ui_batch", self.evt_batch))

        DropDownRMKeymap(self, MOUSE, items, override_name=override_name, title=self.rna.name)
        #|
    #|
    #|
class StructButtonValAnim(          # Struct_bufn_keyframe                                      
    Struct_bufn_keyframe):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_remove_from_keying_set_all']():
            self.evt_remove_from_keying_set()
            return True
        if TRIGGER['ui_add_to_keying_set_all']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_remove_from_keying_set']():
            self.evt_remove_from_keying_set()
            return True
        if TRIGGER['ui_add_to_keying_set']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        if TRIGGER['ui_clear_keyframe']():
            self.evt_clear_keyframe()
            return True
        if TRIGGER['ui_delete_keyframe']():
            self.evt_delete_keyframe()
            return True
        if TRIGGER['ui_insert_keyframe']():
            self.evt_insert_keyframe()
            return True
        if TRIGGER['ui_batch']():
            if hasattr(self, "evt_batch"):
                self.evt_batch()
                return True
        return False
        #|

    def to_modal_rm(self):

        if not hasattr(self.rna, "is_animatable") or self.rna.is_animatable:
            items = [
                ("dd_paste", self.evt_area_paste),
                ("dd_copy", self.evt_area_copy),
                ("valbox_reset_single", self.evt_area_reset_single),
                ("detail", self.evt_area_detail),

                ("ui_remove_from_keying_set", self.evt_remove_from_keying_set),
                ("ui_add_to_keying_set", self.evt_add_to_keying_set),
                ("ui_copy_full_data_path", self.evt_copy_full_data_path),
                ("ui_copy_data_path", self.evt_copy_data_path),
                ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
                ("ui_delete_driver", self.evt_delete_driver),
                ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
                ("ui_clear_keyframe", self.evt_clear_keyframe),
                ("ui_delete_keyframe", self.evt_delete_keyframe),
                ("ui_insert_keyframe", self.evt_insert_keyframe),
            ]
            if hasattr(self.rna, "subtype") and self.rna.subtype == "ANGLE":
                items.append(("ui_format_toggle", self.evt_area_format))
            override_name = None
        else:
            items = [
                ("dd_paste", self.evt_area_paste),
                ("dd_copy", self.evt_area_copy),
                ("valbox_reset_single", self.evt_area_reset_single),
                ("detail", self.evt_area_detail),

                ("ui_copy_full_data_path", self.evt_copy_full_data_path),
                ("ui_copy_data_path", self.evt_copy_data_path),
                # ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
                # ("ui_delete_driver", self.evt_delete_driver),
                # ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            ]
            override_name = None
            # override_name = {
            #     "ui_paste_full_data_path_as_driver": "Paste Full Data Path as Reference Driver",
            #     "ui_delete_driver": "Delete Reference Driver",
            #     "ui_add_driver": "Add Reference Driver"
            # }

        if hasattr(self, "evt_batch"):
            items.append(("ui_batch", self.evt_batch))

        DropDownRMKeymap(self, MOUSE, items, override_name=override_name, title=self.rna.name)
        #|
    #|
    #|
@ evtVectorAnim
class StructButtonValAnimVector:
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_remove_from_keying_set_all']():
            self.evt_remove_from_keying_set(index="all")
            return True
        if TRIGGER['ui_add_to_keying_set_all']():
            self.evt_add_to_keying_set(index="all")
            return True
        if TRIGGER['ui_remove_from_keying_set']():
            self.evt_remove_from_keying_set()
            return True
        if TRIGGER['ui_add_to_keying_set']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        if TRIGGER['ui_clear_keyframe']():
            self.evt_clear_keyframe()
            return True
        if TRIGGER['ui_delete_keyframe']():
            self.evt_delete_keyframe()
            return True
        if TRIGGER['ui_insert_keyframe']():
            self.evt_insert_keyframe()
            return True
        if TRIGGER['ui_batch']():
            if hasattr(self, "evt_batch"):
                self.evt_batch()
                return True
        return False
        #|

    def to_modal_rm(self):


        items = [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_all", self.evt_area_reset_all),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_remove_from_keying_set_all", lambda: self.evt_remove_from_keying_set(index="all")),
            ("ui_add_to_keying_set_all", lambda: self.evt_add_to_keying_set(index="all")),
            ("ui_remove_from_keying_set", self.evt_remove_from_keying_set),
            ("ui_add_to_keying_set", self.evt_add_to_keying_set),
            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            ("ui_delete_driver", self.evt_delete_driver),
            ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            ("ui_clear_keyframe", self.evt_clear_keyframe),
            ("ui_delete_keyframe", self.evt_delete_keyframe),
            ("ui_insert_keyframe", self.evt_insert_keyframe),
        ]
        override_name = {
            "dd_cut": "Copy Array",
            "dd_paste": "Paste",
            "dd_copy": "Copy",
        }
        append_rm_item_rotation_unit(self, items, self.rna)
        if hasattr(self, "evt_batch"):
            items.append(("ui_batch", self.evt_batch))

        DropDownRMKeymap(self, MOUSE, items, override_name=override_name, title=self.rna.name)
        #|

    def bufn_keyframe(self, index):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        dr = self.w.r_driver()[index]
        if dr:
            DropDownYesNo(None, MOUSE, lambda: self.evt_delete_driver(index=index), input_text="Do you want to delete the Driver?")
        else:
            if not hasattr(self.w, "r_fcurve"): return
            fc = self.w.r_fcurve()[index]
            if fc:
                kp = fc.keyframe_points
                ind_E = len(kp) -1
                r = bpy.context.scene.frame_current
                if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                    self.evt_insert_keyframe(index=index, evtkill=False)
                else:
                    self.evt_delete_keyframe(index=index, evtkill=False)
            else:
                self.evt_insert_keyframe(index=index, evtkill=False)
        #|

    def evt_batch(self): Struct_bufn_keyframe.evt_batch(self)

    def set(self, v, index, refresh=True, undo_push=True):
        if hasattr(self, "poll") and self.poll(self) == False: return
        if r_library_editable(self.r_object()) is False: return
        if isinstance(index, int):
            if isinstance(v, str) and v[: 1] == "#":
                self.evt_add_driver(index=index, exp=v[1 :], replace=True)
                return
        else:
            if isinstance(v[0], str) and v[0][: 1] == "#":
                i = index[0]
                for v in v:
                    self.evt_add_driver(index=i, exp=v[1 :], replace=True)
                    i += 1
                return
        super().set(v, index, refresh=refresh, undo_push=undo_push)
        #|
    #|
    #|
StructButtonValAnimVector.r_dp = C_r_dp
class ButtonEnumPush(               # StructButtonEnumAnim      StructPush      ButtonEnum      
    StructButtonEnumAnim,
    StructPush,
    ButtonEnum):
    __slots__ = ()
class ButtonEnumXYPush(             # StructButtonEnumAnim      StructPush      ButtonEnumXY    
    StructButtonEnumAnim,
    StructPush,
    ButtonEnumXY):
    __slots__ = ()
class ButtonEnumXYFlagPush(         # StructButtonEnumAnim      StructPush      ButtonEnumXYFlag
    StructButtonEnumAnim,
    StructPush,
    ButtonEnumXYFlag):
    __slots__ = ()
class ButtonIntPush(                # StructButtonValAnim       StructPush      ButtonInt       
    StructButtonValAnim,
    StructPush,
    ButtonInt): __slots__ = ()
class ButtonFloatPush(              # StructButtonValAnim       StructPush      ButtonFloat     
    StructButtonValAnim,
    StructPush,
    ButtonFloat):
    __slots__ = ()
class ButtonFloatVectorPush(        # StructButtonValAnimVector StructPush      ButtonFloatVector
    StructButtonValAnimVector,
    StructPush,
    ButtonFloatVector):
    __slots__ = ()
class ButtonFloatVectorColorPush(ButtonFloatVectorPush):
    __slots__ = 'update_callback', 'callback_enable'

    def evt_undo_push(self, undo_push, oldvalue): pass

    def set(self, v, index, refresh=True, undo_push=True):
        super().set(v, index, refresh)
        self.upd_data()
        if self.callback_enable: self.update_callback()
        #|
    #|
    #|
class ButtonBoolVectorPush(         # StructButtonValAnimVector StructPush      ButtonBoolVector
    StructButtonValAnimVector,
    StructPush,
    ButtonBoolVector):
    __slots__ = ()

    def bufn_keyframe(self):

        w = self.w
        DDKeyframes(self,
            self.rna,
            self.get,
            self.row_length,
            w.r_fcurve,
            w.r_driver,
            upd_button_keyframe_BOOLEAN,
            self.r_keyframe_button_fn)
        #|

    def r_keyframe_button_fn(self, index):
        return lambda: StructButtonValAnimVector.bufn_keyframe(self, index)
        #|
    #|
    #|
class ButtonBoolPush(               # StructButtonValAnim       StructPush      ButtonBool      
    StructButtonValAnim,
    StructPush,
    ButtonBool):
    __slots__ = ()
class ButtonBoolXYZPush(            # StructButtonValAnimVector StructPush      ButtonBoolXYZ   
    StructButtonValAnimVector,
    StructPush,
    ButtonBoolXYZ):
    __slots__ = ()
class ButtonEnumObjectPush(         # Struct_bufn_keyframe      StructPush      ButtonEnumObject
    Struct_bufn_keyframe,
    StructPush,
    ButtonEnumObject):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        if TRIGGER['ui_jump_to_target']():
            self.evt_jump_to_target()
            return True
        if TRIGGER['ui_mark_asset']():
            self.evt_mark_asset()
            return True
        if TRIGGER['ui_batch']():
            if hasattr(self, "evt_batch"):
                self.evt_batch()
                return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()
        items = [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            # ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            # ("ui_delete_driver", self.evt_delete_driver),
            # ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            ("ui_jump_to_target", self.evt_jump_to_target),
            ("ui_mark_asset", self.evt_mark_asset),
            ("Rename Object", self.evt_rename),
        ]
        override_name = {
            # "ui_paste_full_data_path_as_driver": "Paste Full Data Path as Reference Driver",
            # "ui_delete_driver": "Delete Reference Driver",
            # "ui_add_driver": "Add Reference Driver",
            "ui_mark_asset": "Clear Asset"  if hasattr(ob, "asset_data") and ob.asset_data else "Mark as Asset"
        }
        append_rm_item_preview(self, items, self.rna)
        if hasattr(self, "evt_batch"):
            items.append(("ui_batch", self.evt_batch))

        DropDownRMKeymap(self, MOUSE, items, override_name=override_name, title=self.rna.name)
        #|

    def evt_area_paste(self, is_report=True): ButtonEnumObject.evt_area_paste(self, is_report)
    def evt_area_copy(self, is_report=True): ButtonEnumObject.evt_area_copy(self, is_report)
    def evt_jump_to_target(self): ButtonEnumObject.evt_jump_to_target(self)
    def evt_mark_asset(self, is_report=True): ButtonEnumObject.evt_mark_asset(self, is_report)
    def evt_rename(self, is_report=True): ButtonEnumObject.evt_rename(self, is_report)
    #|
    #|
class ButtonEnumCollectionPush(     # Struct_bufn_keyframe      StructPush      ButtonEnumCollection
    Struct_bufn_keyframe,
    StructPush,
    ButtonEnumCollection):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        # if TRIGGER['ui_paste_full_data_path_as_driver']():
        #     self.evt_paste_full_data_path_as_driver()
        #     return True
        # if TRIGGER['ui_delete_driver']():
        #     self.evt_delete_driver()
        #     return True
        # if TRIGGER['ui_add_driver']():
        #     self.evt_add_driver()
        #     return True
        if TRIGGER['ui_mark_asset']():
            self.evt_mark_asset()
            return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()

        DropDownRMKeymap(self, MOUSE, [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            # ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            # ("ui_delete_driver", self.evt_delete_driver),
            # ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            ("ui_mark_asset", self.evt_mark_asset),
            ("Rename Collection", self.evt_rename),
        ], override_name={
            # "ui_paste_full_data_path_as_driver": "Paste Full Data Path as Reference Driver",
            # "ui_delete_driver": "Delete Reference Driver",
            # "ui_add_driver": "Add Reference Driver",
            "ui_mark_asset": "Clear Asset"  if hasattr(ob, "asset_data") and ob.asset_data else "Mark as Asset"},
        title=self.rna.name)
        #|

    def evt_area_paste(self, is_report=True): ButtonEnumCollection.evt_area_paste(self, is_report)
    def evt_area_copy(self, is_report=True): ButtonEnumCollection.evt_area_copy(self, is_report)
    def evt_mark_asset(self, is_report=True): ButtonEnumCollection.evt_mark_asset(self, is_report)
    def evt_rename(self, is_report=True): ButtonEnumCollection.evt_rename(self, is_report)
    #|
    #|
class ButtonEnumIDPush(             # Struct_bufn_keyframe      StructPush      ButtonEnumID    
    Struct_bufn_keyframe,
    StructPush,
    ButtonEnumID):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        if TRIGGER['ui_batch']():
            if hasattr(self, "evt_batch"):
                self.evt_batch()
                return True

        return super().submodal()
    #|
    #|
class ButtonEnumParticlePush(       # Struct_bufn_keyframe      StructPush      ButtonEnumParticle
    Struct_bufn_keyframe,
    StructPush,
    ButtonEnumParticle):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()

        # override_name={
        #     "ui_paste_full_data_path_as_driver": "Paste Full Data Path as Reference Driver",
        #     "ui_delete_driver": "Delete Reference Driver",
        #     "ui_add_driver": "Add Reference Driver"}

        DropDownRMKeymap(self, MOUSE, [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            # ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            # ("ui_delete_driver", self.evt_delete_driver),
            # ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
        ],
        title=self.rna.name)
        #|

    def evt_area_paste(self, is_report=True): ButtonEnumParticle.evt_area_paste(self, is_report)
    def evt_area_copy(self, is_report=True): ButtonEnumParticle.evt_area_copy(self, is_report)
    #|
    #|
class ButtonEnumTexturePush(        # Struct_bufn_keyframe      StructPush      ButtonEnumTexture
    Struct_bufn_keyframe,
    StructPush,
    ButtonEnumTexture):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        # if TRIGGER['ui_jump_to_target']():
        #     self.evt_jump_to_target()
        #     return True
        # if TRIGGER['ui_mark_asset']():
        #     self.evt_mark_asset()
        #     return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()

        # override_name={
        #     "ui_paste_full_data_path_as_driver": "Paste Full Data Path as Reference Driver",
        #     "ui_delete_driver": "Delete Reference Driver",
        #     "ui_add_driver": "Add Reference Driver"}

        DropDownRMKeymap(self, MOUSE, [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            ("ui_delete_driver", self.evt_delete_driver),
            ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            # ("ui_jump_to_target", self.evt_jump_to_target),
            # ("ui_mark_asset", self.evt_mark_asset),
            ("Rename Texture", self.evt_rename),
            ("Toggle Fake User", self.evt_fakeuser),
            ("Duplicate Texture", self.evt_duplicate),
        ],
        title=self.rna.name)
        #|

    def evt_area_paste(self, is_report=True): ButtonEnumTexture.evt_area_paste(self, is_report)
    def evt_area_copy(self, is_report=True): ButtonEnumTexture.evt_area_copy(self, is_report)
    def evt_mark_asset(self, is_report=True): ButtonEnumTexture.evt_mark_asset(self, is_report)
    def evt_rename(self, is_report=True): ButtonEnumTexture.evt_rename(self, is_report)
    #|
    #|
class ButtonEnumCacheFilePush(      # Struct_bufn_keyframe      StructPush      ButtonEnumCacheFile
    Struct_bufn_keyframe,
    StructPush,
    ButtonEnumCacheFile):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        # if TRIGGER['ui_jump_to_target']():
        #     self.evt_jump_to_target()
        #     return True
        # if TRIGGER['ui_mark_asset']():
        #     self.evt_mark_asset()
        #     return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()

        # override_name={
        #     "ui_paste_full_data_path_as_driver": "Paste Full Data Path as Reference Driver",
        #     "ui_delete_driver": "Delete Reference Driver",
        #     "ui_add_driver": "Add Reference Driver"}

        DropDownRMKeymap(self, MOUSE, [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            ("ui_delete_driver", self.evt_delete_driver),
            ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            # ("ui_jump_to_target", self.evt_jump_to_target),
            # ("ui_mark_asset", self.evt_mark_asset),
            ("Rename Texture", self.evt_rename),
            ("Toggle Fake User", self.evt_fakeuser),
            ("Duplicate Texture", self.evt_duplicate),
        ],
        title=self.rna.name)
        #|

    def evt_area_paste(self, is_report=True): ButtonEnumCacheFile.evt_area_paste(self, is_report)
    def evt_area_copy(self, is_report=True): ButtonEnumCacheFile.evt_area_copy(self, is_report)
    def evt_mark_asset(self, is_report=True): ButtonEnumCacheFile.evt_mark_asset(self, is_report)
    def evt_rename(self, is_report=True): ButtonEnumCacheFile.evt_rename(self, is_report)
    #|
    #|
class ButtonEnumNodeTreePush(       # Struct_bufn_keyframe      StructPush      ButtonEnumNodeTree
    Struct_bufn_keyframe,
    StructPush,
    ButtonEnumNodeTree):
    __slots__ = ()

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        # if TRIGGER['ui_jump_to_target']():
        #     self.evt_jump_to_target()
        #     return True
        # if TRIGGER['ui_mark_asset']():
        #     self.evt_mark_asset()
        #     return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()

        # override_name={
        #     "ui_paste_full_data_path_as_driver": "Paste Full Data Path as Reference Driver",
        #     "ui_delete_driver": "Delete Reference Driver",
        #     "ui_add_driver": "Add Reference Driver"}

        DropDownRMKeymap(self, MOUSE, [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            ("ui_delete_driver", self.evt_delete_driver),
            ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            # ("ui_jump_to_target", self.evt_jump_to_target),
            # ("ui_mark_asset", self.evt_mark_asset),
            ("Rename Texture", self.evt_rename),
            ("Toggle Fake User", self.evt_fakeuser),
            ("Duplicate Texture", self.evt_duplicate),
        ],
        title=self.rna.name)
        #|

    def evt_area_paste(self, is_report=True): ButtonEnumNodeTree.evt_area_paste(self, is_report)
    def evt_area_copy(self, is_report=True): ButtonEnumNodeTree.evt_area_copy(self, is_report)
    def evt_mark_asset(self, is_report=True): ButtonEnumNodeTree.evt_mark_asset(self, is_report)
    def evt_rename(self, is_report=True): ButtonEnumNodeTree.evt_rename(self, is_report)
    #|
    #|
class ButtonEnumVertexGroupPush(    # Struct_bufn_keyframe_string   StructPush  ButtonEnumVertexGroup
    Struct_bufn_keyframe_string,
    StructPush,
    ButtonEnumVertexGroup):
    __slots__ = ()
class ButtonEnumUVPush(             # Struct_bufn_keyframe_string   StructPush  ButtonEnumUV    
    Struct_bufn_keyframe_string,
    StructPush,
    ButtonEnumUV):
    __slots__ = ()
class ButtonEnumGpLayerPush(             # Struct_bufn_keyframe_string   StructPush ButtonEnumGpLayer
    Struct_bufn_keyframe_string,
    StructPush,
    ButtonEnumGpLayer):
    __slots__ = ()
class ButtonEnumVertexColorPush(    # Struct_bufn_keyframe_string   StructPush  ButtonEnumVertexColor
    Struct_bufn_keyframe_string,
    StructPush,
    ButtonEnumVertexColor):
    __slots__ = ()
class ButtonEnumBonePush(           # Struct_bufn_keyframe_string   StructPush  ButtonEnumBone  
    Struct_bufn_keyframe_string,
    StructPush,
    ButtonEnumBone):
    __slots__ = ()
class ButtonEnumFalloffPush(        # StructButtonEnumAnim      StructPush      ButtonEnumFalloff
    StructButtonEnumAnim,
    StructPush,
    ButtonEnumFalloff):
    __slots__ = ()
class ButtonFnPush(                 # StructPush                ButtonFn                        
    StructPush,
    ButtonFn):
    __slots__ = ()
class ButtonStringPush(             # Struct_bufn_keyframe_string   StructPush  ButtonString    
    Struct_bufn_keyframe_string,
    StructPush,
    ButtonString):
    __slots__ = ()
class ButtonStringObjectPathPush(   # Struct_bufn_keyframe_string   StructPush  ButtonStringObjectPath
    Struct_bufn_keyframe_string,
    StructPush,
    ButtonStringObjectPath):
    __slots__ = ()
class ButtonStringFilePush(         # Struct_bufn_keyframe_string   StructPush  ButtonStringFile
    Struct_bufn_keyframe_string,
    StructPush,
    ButtonStringFile):
    __slots__ = ()
class ButtonBoolArrayXPush(         # Struct_bufn_keyframe_array    ButtonBoolArrayX            
    Struct_bufn_keyframe_array,
    ButtonBoolArrayX):
    __slots__ = ()

    def evt_undo_push(self, undo_push, oldvalue, index):
        if isinstance(undo_push, tuple):
            oldvalue = undo_push[0]
            undo_push = True

        if undo_push:
            if oldvalue == None:
                ed_undo_push(message=f'VMD MD change multiple values')
            else:
                newvalue = getattr(self.pp, self.rna[index].identifier)
                if oldvalue == newvalue: return

                ed_undo_push(message=f'VMD MD {self.rna[index].name} :  {newvalue}')
        #|
    #|
    #|
class ButtonColor3Push(             # StructButtonValAnimVector     StructPush  ButtonColor3    
    StructButtonValAnimVector,
    StructPush,
    ButtonColor3):
    __slots__ = ()

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        self.r_pp, self.r_object, self.r_datapath_head = pp
        self.pp = self.r_pp()

        self.box_button = GpuRim(None, COL_box_color_rim)
        self.color_value = None
        #|

    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_default_array(self): return self.rna.default_array
    def r_default_value(self): return self.rna.default_array

    def to_dropdown(self):

        DropDownColorAnim(self, self.box_button, self.rna, self.pp)
        #|

    def bufn_keyframe(self):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=False)
        if pp is None: return

        dr = self.w.r_driver()
        if any(dr):
            indexs = [r  for r, e in enumerate(dr) if e]
            DropDownYesNo(None, MOUSE, self.evt_delete_driver_all, input_text=f"Do you want to delete the Driver(s)?\nFor index in {indexs}")
        else:
            if not hasattr(self.w, "r_fcurve"): return
            fcs = self.w.r_fcurve()
            if any(fcs):
                r = bpy.context.scene.frame_current
                is_current_keyframe = False
                for fc in fcs:
                    if fc:
                        if is_current_keyframe is False:
                            kp = fc.keyframe_points
                            ind_E = len(kp) -1
                            if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) != None:
                                is_current_keyframe = True
                                break

                if is_current_keyframe is True:
                    for r, fc in enumerate(fcs):
                        if fc: del_keyframe(ob, self.rna, pp, index=r, update_push=False)
                    update_scene_push("VMD Delete Keyframes")
                else:
                    for r, fc in enumerate(fcs): add_new_keyframe(ob, self.rna, pp, index=r, update_push=False)
                    update_scene_push("VMD Insert Keyframes")
            else:
                for r, fc in enumerate(fcs): add_new_keyframe(ob, self.rna, pp, index=r, update_push=False)
                update_scene_push("VMD Insert Keyframes")
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: v = getattr(self.pp, self.rna.identifier)
        except: return

        if self.color_value == list(v): return

        v = list(v)
        # srgb = [
        #     scene_linear_to_hex(v[0]),
        #     scene_linear_to_hex(v[1]),
        #     scene_linear_to_hex(v[2]),
        # ]
        self.box_button.color = [
            L_rgb_to_glc[min(max(0, scene_linear_to_hex(v[0])), 255)],
            L_rgb_to_glc[min(max(0, scene_linear_to_hex(v[1])), 255)],
            L_rgb_to_glc[min(max(0, scene_linear_to_hex(v[2])), 255)],
            1.0
        ]
        self.color_value = v
        #|
    #|
    #|

class ButtonListLayerMedia:
    __slots__ = (
        'w',
        'box_button',
        'r_collection',
        'r_active_index',
        'set_active_index',
        'focus_element')

    def __init__(self, w, r_collection, r_active_index, set_active_index):
        self.w = w
        self.r_collection = r_collection
        self.r_active_index = r_active_index
        self.set_active_index = set_active_index

        self.box_button = [
            GpuImg_rename(),
            GpuImg_ADD(),
            GpuImg_REMOVE(),
            GpuImg_TRIA_UP(),
            GpuImg_TRIA_DOWN(),
        ]

        self.focus_element = None
        #|

    def init_bat(self, L, R, T):
        box_button = self.box_button
        widget_rim = SIZE_border[3]
        h = SIZE_widget[0]
        T0 = T - widget_rim
        B0 = T0 - h
        L0 = L + widget_rim
        R0 = L0 + h

        box_button[0].LRBT_upd(L0, R0, B0, T0)

        R0 = R - widget_rim
        L0 = R0 - h
        box_button[4].LRBT_upd(L0, R0, B0, T0)
        R0 = L0 - widget_rim
        L0 = R0 - h
        box_button[3].LRBT_upd(L0, R0, B0, T0)
        R0 = L0 - h // 2
        L0 = R0 - h
        box_button[2].LRBT_upd(L0, R0, B0, T0)
        R0 = L0 - widget_rim
        L0 = R0 - h
        box_button[1].LRBT_upd(L0, R0, B0, T0)

        return B0 - widget_rim
        #|

    def r_height(self, width): return D_SIZE['widget_full_h']

    def is_dark(self): return False
    def dark(self): pass
    def light(self): pass

    def inside(self, mouse):
        for e in self.box_button:
            if e.inbox(mouse): return True
        return False
        #|
    def inside_evt(self):
        Admin.REDRAW()
        self.focus_element = None
        #|
    def outside_evt(self):
        Admin.REDRAW()
        box_button = self.box_button

        box_button[0].__class__ = GpuImg_rename
        box_button[1].__class__ = GpuImg_ADD
        box_button[2].__class__ = GpuImg_REMOVE
        box_button[3].__class__ = GpuImg_TRIA_UP
        box_button[4].__class__ = GpuImg_TRIA_DOWN
        #|

    def modal(self):
        e = None
        box_button = self.box_button

        for o in box_button:
            if o.inbox(MOUSE):
                e = o
                break

        if e is None:
            if self.focus_element is not None:
                o = self.focus_element
                if o == box_button[0]: o.__class__ = GpuImg_rename
                elif o == box_button[1]: o.__class__ = GpuImg_ADD
                elif o == box_button[2]: o.__class__ = GpuImg_REMOVE
                elif o == box_button[3]: o.__class__ = GpuImg_TRIA_UP
                elif o == box_button[4]: o.__class__ = GpuImg_TRIA_DOWN

                self.focus_element = None
                Admin.REDRAW()
        else:
            if self.focus_element != e:
                o = self.focus_element
                if o == box_button[0]: o.__class__ = GpuImg_rename
                elif o == box_button[1]: o.__class__ = GpuImg_ADD
                elif o == box_button[2]: o.__class__ = GpuImg_REMOVE
                elif o == box_button[3]: o.__class__ = GpuImg_TRIA_UP
                elif o == box_button[4]: o.__class__ = GpuImg_TRIA_DOWN

                self.focus_element = e
                o = e
                if o == box_button[0]: o.__class__ = GpuImg_rename_focus
                elif o == box_button[1]: o.__class__ = GpuImg_ADD_focus
                elif o == box_button[2]: o.__class__ = GpuImg_REMOVE_focus
                elif o == box_button[3]: o.__class__ = GpuImg_TRIA_UP_focus
                elif o == box_button[4]: o.__class__ = GpuImg_TRIA_DOWN_focus

                Admin.REDRAW()

            if TRIGGER['click']():
                kill_evt_except()

                o = e
                if o == box_button[0]: self.evt_rename()
                elif o == box_button[1]: self.evt_add()
                elif o == box_button[2]: self.evt_remove()
                elif o == box_button[3]: self.evt_active_up()
                elif o == box_button[4]: self.evt_active_down()
                return True

        return False
        #|

    @ catch
    def evt_rename(self):

        active_index = self.r_active_index()
        if active_index in {None, -1}: return
        collection = self.r_collection()
        if not collection: return
        if 0 <= active_index < len(collection):
            e = collection[active_index]
        else: return

        def end_fn(s):
            active_index = self.r_active_index()
            if active_index in {None, -1}: return
            collection = self.r_collection()
            if not collection: return
            if 0 <= active_index < len(collection):
                collection[active_index].filepath = s
                update_scene_push("VMD Layer Filepath Change")

        OpScanFile.end_fn = end_fn
        bpy.ops.wm.vmd_scan_file("INVOKE_DEFAULT", filepath=e.filepath)
        #|
    @ catch
    def evt_add(self):

        collection = self.r_collection()
        if collection == None: return

        def end_fn(s):
            collection = self.r_collection()
            if collection == None: return

            collection.new(s)
            update_scene_push("VMD Layer Add")

        OpScanFile.end_fn = end_fn
        bpy.ops.wm.vmd_scan_file("INVOKE_DEFAULT", filepath="")
        #|
    @ catch
    def evt_remove(self):

        collection = self.r_collection()
        if collection:
            collection.remove(collection[self.r_active_index()])
            update_scene_push("VMD Layer Remove")
        #|
    @ catch
    def evt_active_up(self):

        active_index = self.r_active_index()
        if active_index in {None, -1, 0}: return
        collection = self.r_collection()
        if not collection: return
        if len(collection) == 1: return

        try:
            e0 = collection[active_index]
            e1 = collection[active_index - 1]
            path0 = e0.filepath
            hide0 = e0.hide_layer
            path1 = e1.filepath
            hide1 = e1.hide_layer

            e0.filepath = path1
            e0.hide_layer = hide1
            e1.filepath = path0
            e1.hide_layer = hide0
            self.set_active_index(active_index - 1, push=False)
            update_scene_push("VMD Layer Move Up")
        except: pass
        #|
    @ catch
    def evt_active_down(self):

        active_index = self.r_active_index()
        if active_index in {None, -1}: return
        collection = self.r_collection()
        if not collection: return
        if len(collection) == 1: return
        if active_index == len(collection) - 1: return

        try:
            e0 = collection[active_index]
            e1 = collection[active_index + 1]
            path0 = e0.filepath
            hide0 = e0.hide_layer
            path1 = e1.filepath
            hide1 = e1.hide_layer

            e0.filepath = path1
            e0.hide_layer = hide1
            e1.filepath = path0
            e1.hide_layer = hide0
            self.set_active_index(active_index + 1, push=False)
            update_scene_push("VMD Layer Move Down")
        except: pass
        #|

    def dxy(self, dx, dy):
        for e in self.box_button: e.dxy_upd(dx, dy)
        #|
    def draw_box(self):
        for e in self.box_button: e.bind_draw()
        #|
    def draw_blf(self): pass
    def upd_data(self): pass
    #|
    #|
class ButtonListLayer:
    __slots__ = (
        'w',
        'r_collection',
        'r_element_name',
        'box_rim',
        'box_active',
        'box_icon_eye',
        'blf_value',
        'r_active_index',
        'set_active_index',
        'active_index',
        'button_media')

    def __init__(self, w, r_collection, r_element_name, r_active_index, set_active_index, button_media):
        self.w = w
        self.r_collection = r_collection
        self.r_element_name = r_element_name
        collection = r_collection()
        if collection:
            self.blf_value = [BlfClipColor("", r_element_name(e), 0, 0, COL_block_fg)  for e in collection]
            self.box_icon_eye = [GpuImg_HIDE_OFF()  for e in collection]
        else:
            self.blf_value = []
            self.box_icon_eye = []

        self.box_rim = GpuRim(COL_box_filter, COL_box_filter_rim)
        self.box_active = GpuBox_box_filter_active_bg()
        self.r_active_index = r_active_index
        self.set_active_index = set_active_index
        self.active_index = -1
        self.button_media = button_media
        #|

    def init_bat(self, L, R, T):
        widget_rim = SIZE_border[3]
        self.active_index = self.r_active_index()

        if not self.blf_value:
            self.box_active.LRBT_upd(0, 0, 0, 0)
            self.box_rim.LRBT_upd(L, R, T, T - widget_rim - widget_rim, widget_rim)
            return T

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        full_h = D_SIZE['widget_full_h']
        h = SIZE_widget[0]
        T0 = T - widget_rim
        x = L + h
        y = T0 - full_h + widget_rim + D_SIZE['font_main_dy']
        R2 = R - widget_rim
        R1 = R2 - D_SIZE['font_main_dx']
        L1 = R1 - h
        R0 = L1 - D_SIZE['font_main_dx']
        T1 = T0 - widget_rim
        B1 = T1 - h

        for e, o in zip(self.blf_value, self.box_icon_eye):
            o.LRBT_upd(L1, R1, B1, T1)
            e.x = x
            e.y = y
            e.text = r_blf_clipping_end(e.unclip_text, x, R0)
            y -= full_h
            T1 -= full_h
            B1 -= full_h

        if self.active_index in {None, -1}:
            self.box_active.LRBT_upd(0, 0, 0, 0)
        else:
            B = self.blf_value[self.active_index].y - D_SIZE['font_main_dy'] - widget_rim
            self.box_active.LRBT_upd(L + widget_rim, R2, B, B + full_h)

        B = self.blf_value[-1].y - D_SIZE['font_main_dy'] - widget_rim - widget_rim
        self.box_rim.LRBT_upd(L, R, B, T, widget_rim)
        return B
        #|

    def r_height(self, width): return D_SIZE['widget_full_h'] * len(self.blf_value) + SIZE_border[3] * 2

    def is_dark(self): return False
    def dark(self): pass
    def light(self): pass

    def inside(self, mouse): return self.box_rim.inbox(mouse)
    def inside_evt(self):
        Admin.REDRAW()
        #|
    def outside_evt(self):
        Admin.REDRAW()
        #|

    def modal(self):
        if not self.blf_value: return False

        if TRIGGER['rename']():
            self.evt_rename()
            return True
        if TRIGGER['click']():
            if hasattr(self, "box_icon_eye") and MOUSE[0] >= self.box_icon_eye[0].L:
                if is_first_press('click') == False:
                    self.evt_eye(_last_bool_state[0])
                else:
                    self.evt_eye()
            else:
                self.evt_index()
            Admin.REDRAW()
            return True
        return False
        #|

    def r_index_mouse(self): # if blf_value
        return (self.blf_value[0].y + D_SIZE['font_main_dT'] + SIZE_border[3] - MOUSE[1]) // D_SIZE['widget_full_h']
        #|
    @ catch
    def evt_index(self):
        if not self.blf_value: return

        i = self.r_index_mouse()
        if 0 <= i < len(self.blf_value):
            self.set_active_index(i)
        #|
    @ catch
    def evt_eye(self, boo=None):
        if not self.blf_value: return

        i = self.r_index_mouse()
        if 0 <= i < len(self.blf_value):
            e = self.r_collection()[i]
            if boo is None: boo = not e.hide_layer
            e.hide_layer = boo
            _last_bool_state[0] = boo
            update_scene_push(f'VMD Hide Layer: {boo}')
        #|
    def evt_rename(self):
        self.button_media.evt_rename()
        #|

    def dxy(self, dx, dy):
        self.box_rim.dxy_upd(dx, dy)
        self.box_active.dxy_upd(dx, dy)

        for e in self.box_icon_eye: e.dxy_upd(dx, dy)

        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|
    def draw_box(self):
        self.box_rim.bind_draw()
        self.box_active.bind_draw()
        for e in self.box_icon_eye: e.bind_draw()
        #|
    def draw_blf(self):
        blfSize(FONT0, D_SIZE['font_main'])
        for e in self.blf_value:
            blfColor(FONT0, *e.color)
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|

    def upd_collection(self):
        r_element_name = self.r_element_name
        collection = self.r_collection()
        if collection == None: collection = []
        if len(self.blf_value) != len(collection):
            self.blf_value = [BlfClipColor("", r_element_name(e), 0, 0, COL_block_fg)  for e in collection]
            self.box_icon_eye = [GpuImg_HIDE_OFF()  for e in collection]
            return True

        tag = False
        for o, oo, e in zip(self.blf_value, self.box_icon_eye, collection):
            if o.unclip_text != r_element_name(e):
                o.unclip_text = r_element_name(e)
                tag = True

            if e.hide_layer:
                if oo.__class__ == GpuImg_HIDE_OFF: oo.__class__ = GpuImg_HIDE_ON
                elif oo.__class__ == GpuImg_HIDE_OFF_focus: oo.__class__ = GpuImg_HIDE_ON_focus
            else:
                if oo.__class__ == GpuImg_HIDE_ON: oo.__class__ = GpuImg_HIDE_OFF
                elif oo.__class__ == GpuImg_HIDE_ON_focus: oo.__class__ = GpuImg_HIDE_OFF_focus

        if self.active_index != self.r_active_index(): return True
        return tag
        #|
    def upd_data(self): pass
    #|
    #|
class ButtonListSegmentMedia(ButtonListLayerMedia):
    __slots__ = 'r_object', 'r_modifier'

    def __init__(self, w, r_collection, r_active_index, set_active_index, r_object, r_modifier):
        super().__init__(w, r_collection, r_active_index, set_active_index)
        self.r_object = r_object
        self.r_modifier = r_modifier
        #|

    @ catch
    def evt_rename(self):

        modifier = self.r_modifier()
        segment = modifier.segments[modifier.segment_active_index]
        L, R, B, T = self.box_button[0].r_LRBT()
        R = self.box_button[-1].R

        DropDownEnumRename(None, (L, R, B, T), self.r_object(), segment, modifier.segments)
        #|
    @ catch
    def evt_add(self):

        collection = self.r_collection()
        if collection == None: return
        modifier = self.r_modifier()
        if not modifier: return

        with bpy.context.temp_override(object=self.r_object()):
            if modifier.type == "GREASE_PENCIL_TIME":
                grease_pencil_time_modifier_segment_add(modifier=modifier.name)
            elif modifier.type == "GREASE_PENCIL_DASH":
                grease_pencil_dash_modifier_segment_add(modifier=modifier.name)
            else:
                return
            update_scene_push("VMD Segments Add")
        #|
    @ catch
    def evt_remove(self):

        collection = self.r_collection()
        if collection == None: return
        modifier = self.r_modifier()
        if not modifier: return

        with bpy.context.temp_override(object=self.r_object()):
            if modifier.type == "GREASE_PENCIL_TIME":
                grease_pencil_time_modifier_segment_remove(modifier=modifier.name)
            elif modifier.type == "GREASE_PENCIL_DASH":
                grease_pencil_dash_modifier_segment_remove(modifier=modifier.name)
            else:
                return
            update_scene_push("VMD Segments Remove")
        #|
    @ catch
    def evt_active_up(self):

        collection = self.r_collection()
        if collection == None: return
        modifier = self.r_modifier()
        if not modifier: return

        with bpy.context.temp_override(object=self.r_object()):
            if modifier.type == "GREASE_PENCIL_TIME":
                grease_pencil_time_modifier_segment_move(modifier=modifier.name, type='UP')
            elif modifier.type == "GREASE_PENCIL_DASH":
                grease_pencil_dash_modifier_segment_move(modifier=modifier.name, type='UP')
            else:
                return
            update_scene_push("VMD Segments Move Up")
        #|
    @ catch
    def evt_active_down(self):

        collection = self.r_collection()
        if collection == None: return
        modifier = self.r_modifier()
        if not modifier: return

        with bpy.context.temp_override(object=self.r_object()):
            if modifier.type == "GREASE_PENCIL_TIME":
                grease_pencil_time_modifier_segment_move(modifier=modifier.name, type='DOWN')
            elif modifier.type == "GREASE_PENCIL_DASH":
                grease_pencil_dash_modifier_segment_move(modifier=modifier.name, type='DOWN')
            else:
                return
            update_scene_push("VMD Segments Move Down")
        #|
    #|
    #|
class ButtonListSegment(ButtonListLayer):
    __slots__ = ()

    def __init__(self, w, r_collection, r_element_name, r_active_index, set_active_index, button_media):
        self.w = w
        self.r_collection = r_collection
        self.r_element_name = r_element_name
        collection = r_collection()
        if collection:
            self.blf_value = [BlfClipColor("", r_element_name(e), 0, 0, COL_block_fg)  for e in collection]
            # self.box_icon_eye = [GpuImg_HIDE_OFF()  for e in collection]
        else:
            self.blf_value = []
            # self.box_icon_eye = []

        self.box_rim = GpuRim(COL_box_filter, COL_box_filter_rim)
        self.box_active = GpuBox_box_filter_active_bg()
        self.r_active_index = r_active_index
        self.set_active_index = set_active_index
        self.active_index = -1
        self.button_media = button_media
        #|

    def init_bat(self, L, R, T):
        widget_rim = SIZE_border[3]
        self.active_index = self.r_active_index()

        if not self.blf_value:
            self.box_active.LRBT_upd(0, 0, 0, 0)
            self.box_rim.LRBT_upd(L, R, T, T - widget_rim - widget_rim, widget_rim)
            return T

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        full_h = D_SIZE['widget_full_h']
        h = SIZE_widget[0]
        T0 = T - widget_rim
        x = L + h
        y = T0 - full_h + widget_rim + D_SIZE['font_main_dy']
        R2 = R - widget_rim
        R1 = R2 - D_SIZE['font_main_dx']
        L1 = R1 - h
        R0 = L1 - D_SIZE['font_main_dx']
        T1 = T0 - widget_rim
        B1 = T1 - h

        for e in self.blf_value:
            e.x = x
            e.y = y
            e.text = r_blf_clipping_end(e.unclip_text, x, R0)
            y -= full_h
            T1 -= full_h
            B1 -= full_h

        if self.active_index in {None, -1}:
            self.box_active.LRBT_upd(0, 0, 0, 0)
        else:
            B = self.blf_value[self.active_index].y - D_SIZE['font_main_dy'] - widget_rim
            self.box_active.LRBT_upd(L + widget_rim, R2, B, B + full_h)

        B = self.blf_value[-1].y - D_SIZE['font_main_dy'] - widget_rim - widget_rim
        self.box_rim.LRBT_upd(L, R, B, T, widget_rim)
        return B
        #|

    def dxy(self, dx, dy):
        self.box_rim.dxy_upd(dx, dy)
        self.box_active.dxy_upd(dx, dy)

        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|
    def draw_box(self):
        self.box_rim.bind_draw()
        self.box_active.bind_draw()
        #|
    def upd_collection(self):
        r_element_name = self.r_element_name
        collection = self.r_collection()
        if collection == None: collection = []
        if len(self.blf_value) != len(collection):
            self.blf_value = [BlfClipColor("", r_element_name(e), 0, 0, COL_block_fg)  for e in collection]
            return True

        tag = False
        for o, e in zip(self.blf_value, collection):
            if o.unclip_text != r_element_name(e):
                o.unclip_text = r_element_name(e)
                tag = True

        if self.active_index != self.r_active_index():
            self.active_index = self.r_active_index()
            return True
        return tag
        #|
    #|
    #|


class BlockSep(             # ButtonSep                                                         
    ButtonSep):
    __slots__ = 'box_block'

    def __init__(self):
        self.box_block = GpuBox()
        #|

    def init_bat(self, L, R, T):
        B = T - SIZE_block[6]
        self.box_block.LRBT(L, R, B, T)
        return B
    def r_height(self, width): return SIZE_block[6]

    def dxy(self, dx, dy): self.box_block.dxy(dx, dy)
    #|
    #|

class BlockSubtab:
    __slots__ = (
        'w',
        'rna',
        'fn',
        'box_block',
        'box_icon',
        'blf_title',
        'blf_info')

    def __init__(self, w, rna, fn):
        self.w = w
        self.rna = rna
        self.fn = fn
        self.box_block = GpuBox(COL_block)
        self.blf_title = Blf(rna.name)
        self.blf_info = []
        self.box_icon = getattr(blg, rna.icon_id, BoxFake)()
        #|

    def init_bat(self, L, R, T):
        blf_info = self.blf_info
        font_subtitle_dx = D_SIZE['font_subtitle_dx']
        offset_x = SIZE_block[1] + font_subtitle_dx
        L0 = L + offset_x
        T0 = T - SIZE_block[4]
        y = T0 - D_SIZE['font_subtitle_dT']
        B0 = y - D_SIZE['font_subtitle_dy']
        icon_h = T0 - B0
        R0 = L0 + icon_h
        self.box_icon.LRBT_upd(L0, R0, B0 - font_subtitle_dx, T0 - font_subtitle_dx)
        x = R0 + offset_x
        self.blf_title.x = x
        self.blf_title.y = y
        y -= SIZE_block[5]

        blfSize(FONT0, D_SIZE['font_label'])
        infos = self.rna.description.split('\n')
        if len(infos) == 1:
            blf_info[:] = rl_blf_wrap_LR(infos[0], x, R - offset_x, y,
                floor((D_SIZE['font_label_dy'] + D_SIZE['font_label_dT']) * SIZE_foreground_height[3]))
        else:
            blf_info.clear()
            depth = floor((D_SIZE['font_label_dy'] + D_SIZE['font_label_dT']) * SIZE_foreground_height[3])
            for info in infos:
                blf_info += rl_blf_wrap_LR(info, x, R - offset_x, y, depth)
                y = blf_info[-1].y - depth

        B = (blf_info[-1].y  if blf_info else y) - D_SIZE['font_label_dy'] - SIZE_block[3]
        self.box_block.LRBT_upd(L, R, B, T)
        return B
        #|
    def r_height(self, width):
        R = width
        T = 0
        blf_info = []
        offset_x = SIZE_block[1] + D_SIZE['font_subtitle_dx']
        x = offset_x
        y = T - SIZE_block[4] - D_SIZE['font_subtitle_dT']
        y -= SIZE_block[5]

        blfSize(FONT0, D_SIZE['font_label'])
        infos = self.rna.description.split('\n')
        if len(infos) == 1:
            blf_info[:] = rl_blf_wrap_LR(infos[0], x, R - offset_x, y,
                floor((D_SIZE['font_label_dy'] + D_SIZE['font_label_dT']) * SIZE_foreground_height[3]))
        else:
            blf_info.clear()
            depth = floor((D_SIZE['font_label_dy'] + D_SIZE['font_label_dT']) * SIZE_foreground_height[3])
            for info in infos:
                blf_info += rl_blf_wrap_LR(info, x, R - offset_x, y, depth)
                y = blf_info[-1].y - depth

        B = (blf_info[-1].y  if blf_info else y) - D_SIZE['font_label_dy'] - SIZE_block[3]
        return -B
        #|

    def inside_evt(self):
        self.box_block.color = COL_block_fo
        #|
    def outside_evt(self):
        self.box_block.color = COL_block
        #|

    def modal(self):
        if TRIGGER['click'](): self.fn()
        #|

    def dxy(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.box_icon.dxy_upd(dx, dy)
        self.blf_title.x += dx
        self.blf_title.y += dy
        for e in self.blf_info:
            e.x += dx
            e.y += dy
        #|

    def draw_box(self):
        self.box_block.bind_draw()
        self.box_icon.bind_draw()
        #|
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_subtitle'])
        blfColor(FONT0, *COL_block_fg)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        blfSize(FONT0, D_SIZE['font_label'])
        blfColor(FONT0, *COL_block_fg_info)
        for e in self.blf_info:
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|

    def upd_data(self): pass
    #|
    #|
class BlockCalcDisplay:
    __slots__ = (
        'w',
        'box_block',
        'blf_title',
        'blf_info')

    def __init__(self, w):
        self.w = w
        self.box_block = GpuBox(COL_block_calc_display)
        self.blf_title = Blf("Click here to calculate")
        self.blf_info = []
        #|

    def init_bat(self, L, R, T):
        rna = self.w.w.data["rna"]
        blf_info = self.blf_info
        offset_x = SIZE_block[1] + D_SIZE['font_main_dx']
        x = L + offset_x
        y = T - SIZE_block[4] - D_SIZE['font_main_dT']
        self.blf_title.x = x
        self.blf_title.y = y
        y -= SIZE_block[5]

        # blfSize(FONT0, D_SIZE['font_label'])
        depth = floor((D_SIZE['font_label_dy'] + D_SIZE['font_label_dT']) * SIZE_foreground_height[3])
        if hasattr(rna, "hard_min"):
            hard_min = rna.hard_min
            hard_max = rna.hard_max
        else:
            hard_min = rna.min_value
            hard_max = rna.max_value

        blf_info[:] = [
            Blf(f"min :  {value_to_display(hard_min)}", x, y),
            Blf(f"max :  {value_to_display(hard_max)}", x, y - depth)]

        B = blf_info[-1].y - D_SIZE['font_label_dy'] - SIZE_block[3]
        self.box_block.LRBT_upd(L, R, B, T)
        return B
        #|
    def r_height(self, width):
        R = width
        T = 0
        rna = self.w.w.data["rna"]
        blf_info = []
        offset_x = SIZE_block[1] + D_SIZE['font_main_dx']
        x = offset_x
        y = T - SIZE_block[4] - D_SIZE['font_main_dT']
        y -= SIZE_block[5]

        # blfSize(FONT0, D_SIZE['font_label'])
        depth = floor((D_SIZE['font_label_dy'] + D_SIZE['font_label_dT']) * SIZE_foreground_height[3])
        if hasattr(rna, "hard_min"):
            hard_min = rna.hard_min
            hard_max = rna.hard_min
        else:
            hard_min = rna.min_value
            hard_max = rna.max_value

        blf_info[:] = [
            Blf(f"min :  {value_to_display(hard_min)}", x, y),
            Blf(f"max :  {value_to_display(hard_max)}", x, y - depth)]

        B = blf_info[-1].y - D_SIZE['font_label_dy'] - SIZE_block[3]
        return -B
        #|

    def outside_evt(self):
        self.box_block.color = COL_block_calc_display
        Admin.REDRAW()
        #|

    def modal(self):
        if TRIGGER['click']():
            self.w.w.area_textbox.calc_text()
            return True
        return False
        #|

    def dxy(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.blf_title.x += dx
        self.blf_title.y += dy
        for e in self.blf_info:
            e.x += dx
            e.y += dy
        #|

    def draw_box(self):
        self.box_block.bind_draw()
        #|
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *COL_block_fg)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        blfSize(FONT0, D_SIZE['font_label'])
        blfColor(FONT0, *COL_block_fg_info)
        for e in self.blf_info:
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|

    def upd_data(self): pass
    #|
    #|

class BlockPref:
    __slots__ = (
        'w',
        'button0',
        'button_fold',
        'box_block',
        'blf_title',
        'blf_info',
        'is_fold',
        'init_bat',
        'draw_blf',
        'r_height',
        'dxy',
        'upd_data',
        'focus_element',
        'area')

    def __init__(self, w, rna, pp):
        if hasattr(w, "area"): self.area = w.area
        self.w = w
        self.box_block = GpuBox_block()
        self.blf_title = Blf(rna.name)
        self.blf_info = []
        self.button_fold = ButtonFold(self)
        self.init_fold()  if P_SettingEditor.is_fold else self.init_unfold()

        if hasattr(rna, "is_array") and rna.is_array:
            if rna.subtype == "COLOR":
                if rna.identifier in SRGB_ATTRS:
                    if rna.array_length == 4: self.button0 = ButtonColor4sRGBPref(self, rna, pp)
                    else: self.button0 = ButtonColor3sRGBPref(self, rna, pp)
                else:
                    if rna.array_length == 4: self.button0 = ButtonColor4Pref(self, rna, pp)
                    else: self.button0 = ButtonColor3Pref(self, rna, pp)
            else: self.button0 = D_Preftype_button_array[rna.type](self, rna, pp)
        else:
            self.button0 = D_Preftype_button[rna.type](self, rna, pp)

        self.upd_data = self.button0.upd_data
        #|
    def init_fold(self, recursive=False):
        self.is_fold = True
        self.init_bat = self.i_init_bat_fold
        self.draw_blf = self.i_draw_blf_fold
        self.r_height = self.i_r_height_fold
        self.dxy = self.i_dxy_fold
        self.button_fold.box_button = GpuImg_fold()
        #|
    def init_unfold(self, recursive=False):
        self.is_fold = False
        self.init_bat = self.i_init_bat
        self.draw_blf = self.i_draw_blf
        self.r_height = self.i_r_height
        self.dxy = self.i_dxy
        self.button_fold.box_button = GpuImg_unfold()
        #|

    def i_init_bat(self, L, R, T):
        h = SIZE_widget[0]
        L0 = L + SIZE_block[1]
        if hasattr(self, "area"): L0 += h // 2
        x = L0 + h
        T0 = T - SIZE_block[4]
        T1 = T0 - h

        self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
        y = T0 - D_SIZE['font_main_dT']
        self.blf_title.x = x
        self.blf_title.y = y
        R0 = R - SIZE_block[2]
        self.init_blf_info(x, y - SIZE_block[5], R0)

        if self.button0.rna.type == "BOOLEAN":
            self.button0.init_bat(R0 - D_SIZE['widget_bool_full_h'], R0,
                T0 + SIZE_border[3] - D_SIZE['widget_bool_dT'])
            B = T1 - SIZE_border[3]
        else:
            B = self.button0.init_bat(R0 - D_SIZE['widget_width'], R0, T0 + SIZE_border[3])

        B = min(B, self.blf_info[-1].y - D_SIZE['font_label_dy']) - SIZE_block[3]
        self.box_block.LRBT_upd(L, R, B, T)
        return B
        #|
    def i_init_bat_fold(self, L, R, T):
        h = SIZE_widget[0]
        L0 = L + SIZE_block[1]
        if hasattr(self, "area"): L0 += h // 2
        x = L0 + h
        T0 = T - SIZE_block[4]
        T1 = T0 - h

        self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
        y = T0 - D_SIZE['font_main_dT']
        self.blf_title.x = x
        self.blf_title.y = y
        R0 = R - SIZE_block[2]

        if self.button0.rna.type == "BOOLEAN":
            self.button0.init_bat(R0 - D_SIZE['widget_bool_full_h'], R0,
                T0 + SIZE_border[3] - D_SIZE['widget_bool_dT'])
            B = T1 - SIZE_block[4]
        else:
            B = self.button0.init_bat(R0 - D_SIZE['widget_width'], R0,
                T0 + SIZE_border[3]) + SIZE_border[3] - SIZE_block[4]

        self.box_block.LRBT_upd(L, R, B, T)
        return B
        #|
    def i_r_height(self, width):
        h = SIZE_widget[0]
        T0 = - SIZE_block[4]
        # T1 = T0 - h
        # L0 = SIZE_block[1]
        # R0 = width - SIZE_block[2]
        # x = L0 + h
        # y = T0 - D_SIZE['font_main_dT']
        # B = min(T1 - SIZE_border[3], T0 + SIZE_border[3] - self.button0.r_height(width))
        # B = min(B, self.r_blf_info_y(x, y - SIZE_block[5], R0) - D_SIZE['font_label_dy']) - SIZE_block[3]
        return - min(min(T0 - h - SIZE_border[3], T0 + SIZE_border[3] - self.button0.r_height(width)
            ), self.r_blf_info_y(SIZE_block[1] + h, T0 - D_SIZE['font_main_dT'] - SIZE_block[5
            ], width - SIZE_block[2]) - D_SIZE['font_label_dy']) + SIZE_block[3]
        #|
    def i_r_height_fold(self, width):
        # h = SIZE_widget[0]
        # T0 = - SIZE_block[4]
        # T1 = T0 - h
        # if self.button0.rna.type == "BOOLEAN":
        #     B = T1 - SIZE_block[4]
        # else:
        #     B = T0 + SIZE_border[3] - self.button0.r_height(width) + SIZE_border[3] - SIZE_block[4]
        return SIZE_block[4] + SIZE_block[4] + SIZE_widget[0]  if self.button0.rna.type == "BOOLEAN" else SIZE_block[4] + SIZE_block[4] - SIZE_border[3] + self.button0.r_height(width) - SIZE_border[3]
        #|
    def init_blf_info(self, x, y, R0):
        # /* 0block_BlockPref_init_blf_info
        blfSize(FONT0, D_SIZE['font_label'])
        infos = self.button0.rna.description.split('\n')
        R0 -= D_SIZE['widget_width'] + D_SIZE['font_label_dx']
        depth = floor((D_SIZE['font_label_dy'] + D_SIZE['font_label_dT']) * SIZE_foreground_height[3])
        if len(infos) == 1:
            self.blf_info[:] = rl_blf_wrap_LR(infos[0], x, R0, y, depth)
        else:
            blf_info = self.blf_info
            blf_info.clear()
            for info in infos:
                blf_info += rl_blf_wrap_LR(info, x, R0, y, depth)
                y = blf_info[-1].y - depth
        # */
    def r_blf_info_y(self, x, y, R0):
        # <<< 1copy (0block_BlockPref_init_blf_info,, ${
        #     'self.blf_info[:]': 'blf_info',
        #     'blf_info = self.blf_info': 'blf_info = []',
        #     'blf_info.clear()': '',
        # }$)
        blfSize(FONT0, D_SIZE['font_label'])
        infos = self.button0.rna.description.split('\n')
        R0 -= D_SIZE['widget_width'] + D_SIZE['font_label_dx']
        depth = floor((D_SIZE['font_label_dy'] + D_SIZE['font_label_dT']) * SIZE_foreground_height[3])
        if len(infos) == 1:
            blf_info = rl_blf_wrap_LR(infos[0], x, R0, y, depth)
        else:
            blf_info = []
            
            for info in infos:
                blf_info += rl_blf_wrap_LR(info, x, R0, y, depth)
                y = blf_info[-1].y - depth
        # >>>
        return blf_info[-1].y
        #|

    def inside(self, mouse): return self.box_block.inbox(mouse)
    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        self.button0.outside_evt()
        self.button_fold.outside_evt()
        #|

    def modal(self):
        if self.button0.inside(MOUSE): e = self.button0
        elif self.button_fold.inside(MOUSE): e = self.button_fold
        else: e = None

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['fold_toggle']():
            self.evt_fold_toggle()
            return True
        return False
        #|

    def to_modal_rm(self):

        # <<< 1copy (0block_BlockUtil_to_modal_rm,, $$)
        items = []
        if hasattr(self.w, "evt_fold_all_toggle"):
            items.append(("Unfold All", self.w.evt_unfold_all))
            items.append(("Fold All", self.w.evt_fold_all))
            items.append(("fold_all_toggle", self.w.evt_fold_all_toggle))
        elif hasattr(self, "area") and hasattr(self.area, "evt_fold_all_toggle"):
            area = self.area
            items.append(("Unfold All", area.evt_unfold_all))
            items.append(("Fold All", area.evt_fold_all))
            items.append(("fold_all_toggle", area.evt_fold_all_toggle))

        items.append(("Unfold Recursive", lambda: self.evt_unfold(recursive=True)))
        items.append(("Fold Recursive", lambda: self.evt_fold(recursive=True)))
        items.append(("Unfold", self.evt_unfold))
        items.append(("Fold", self.evt_fold))
        items.append(("fold_recursive_toggle", lambda: self.evt_fold_toggle(recursive=True)))
        items.append(("fold_toggle", self.evt_fold_toggle))

        if hasattr(self.w, "w") and hasattr(self.w.w, "evt_undo"):
            items.append(("redo", self.w.w.evt_redo))
            items.append(("undo", self.w.w.evt_undo))

        DropDownRMKeymap(self, MOUSE, items)
        # >>>
        #|

    def i_dxy(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.button_fold.box_button.dxy_upd(dx, dy)
        self.button0.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy
        for e in self.blf_info:
            e.x += dx
            e.y += dy
        #|
    def i_dxy_fold(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.button_fold.box_button.dxy_upd(dx, dy)
        self.button0.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy
        #|
    def draw_box(self):
        self.box_block.bind_draw()
        self.button_fold.box_button.bind_draw()
        self.button0.draw_box()
        #|
    def i_draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *COL_block_fg)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        self.button0.draw_blf()

        blfSize(FONT0, D_SIZE['font_label'])
        blfColor(FONT0, *COL_block_fg_info)
        for e in self.blf_info:
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|
    def i_draw_blf_fold(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *COL_block_fg)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        self.button0.draw_blf()
        #|

    def evt_unfold(self, kill_evt=True, recursive=False):

        if kill_evt: kill_evt_except()
        # Admin.REDRAW()
        self.init_unfold()
        e = self.box_block
        self.init_bat(e.L, e.R, e.T)

        if hasattr(self, "area"): self.area.redraw_from_headkey()
        else: self.w.redraw_from_headkey()
        _last_bool_state[0] = False
        #|
    def evt_fold(self, kill_evt=True, recursive=False):

        if kill_evt: kill_evt_except()
        # Admin.REDRAW()
        self.init_fold()
        e = self.box_block
        self.init_bat(e.L, e.R, e.T)

        if hasattr(self, "area"): self.area.redraw_from_headkey()
        else: self.w.redraw_from_headkey()
        _last_bool_state[0] = True
        #|
    def evt_fold_toggle(self, kill_evt=True, recursive=False):
        # Admin.REDRAW()
        if self.is_fold:
            self.evt_unfold(kill_evt=kill_evt)
        else:
            self.evt_fold(kill_evt=kill_evt)
        #|
    #|
    #|
class BlockPrefNoInfo(      # BlockPref                                                         
    BlockPref):
    __slots__ = ()

    def __init__(self, w, rna, pp, subtype_override=None):
        if hasattr(w, "area"): self.area = w.area
        self.w = w
        self.box_block = GpuBox_block()
        self.blf_title = Blf(rna.name)
        self.blf_info = []
        self.button_fold = ButtonFold(self)
        self.init_fold()  if P_SettingEditor.is_fold else self.init_unfold()

        if hasattr(rna, "is_array") and rna.is_array:
            if rna.subtype == "COLOR":
                if rna.array_length == 4: self.button0 = ButtonColor4(self, rna, pp)
                else: self.button0 = ButtonColor3(self, rna, pp)
            else:
                if subtype_override is None:
                    self.button0 = D_Preftype_button_array[rna.type](self, rna, pp)
                else:
                    self.button0 = D_Preftype_button_array[rna.type](self, rna, pp, subtype_override)
        else:
            if subtype_override is None:
                self.button0 = D_Preftype_button[rna.type](self, rna, pp)
            else:
                self.button0 = D_Preftype_button[rna.type](self, rna, pp, subtype_override)

        self.upd_data = self.button0.upd_data
        #|

    def init_blf_info(self, x, y, R0):
        self.blf_info[:] = [Blf('', x, y)]
        #|
    def r_blf_info_y(self, x, y, R0): return y
    #|
    #|
class BlockPrefCustom(      # BlockPref                                                         
    BlockPref):
    __slots__ = ()

    def __init__(self, w, button0):
        self.w = w
        self.box_block = GpuBox_block()
        self.blf_title = Blf(button0.rna.name)
        self.blf_info = []
        self.button_fold = ButtonFold(self)
        self.init_fold()  if P_SettingEditor.is_fold else self.init_unfold()

        self.button0 = button0
        button0.w = self
        self.upd_data = button0.upd_data
        #|
    #|
    #|

class FnDarkButton0:
    __slots__ = ()

    def dark(self):
        if hasattr(self.button0, "dark"): self.button0.dark()
        #|
    def light(self):
        if hasattr(self.button0, "light"): self.button0.light()
        #|
    #|
    #|
class FnDarkButtons:
    __slots__ = ()

    def dark(self):
        for e in self.buttons:
            if hasattr(e, "dark"): e.dark()
        #|
    def light(self):
        for e in self.buttons:
            if hasattr(e, "light"): e.light()
        #|
    #|
    #|
class FnDarkItems:
    __slots__ = ()

    def dark(self):
        for e in self.items:
            if hasattr(e, "dark"): e.dark()
        #|
    def light(self):
        for e in self.items:
            if hasattr(e, "light"): e.light()
        #|
    #|
    #|
class BlockFull(FnDarkButton0):
    __slots__ = (
        'w',
        'button0',
        'box_block',
        'upd_data',
        'focus_element')

    def __init__(self, w, button0):
        self.w = w
        self.box_block = GpuBox_block()
        self.button0 = button0
        button0.w = self
        self.upd_data = button0.upd_data
        #|

    def init_bat(self, L, R, T):
        B = self.button0.init_bat(L, R, T)
        self.box_block.LRBT_upd(L, R, B, T)
        return B
        #|
    def r_height(self, width):
        return self.button0.r_height(width)
        #|

    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        self.button0.outside_evt()
        #|

    def modal(self):
        if self.button0.inside(MOUSE): e = self.button0
        else: e = None

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        return False
        #|

    def to_modal_rm(self):

        items = []
        if hasattr(self.w, "evt_fold_all_toggle"):
            items.append(("Unfold All", self.w.evt_unfold_all))
            items.append(("Fold All", self.w.evt_fold_all))
            items.append(("fold_all_toggle", self.w.evt_fold_all_toggle))
        if hasattr(self.w, "w") and hasattr(self.w.w, "evt_undo"):
            items.append(("redo", self.w.w.evt_redo))
            items.append(("undo", self.w.w.evt_undo))

        if items: DropDownRMKeymap(self, MOUSE, items)
        #|

    def dxy(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.button0.dxy(dx, dy)
        #|
    def draw_box(self):
        self.box_block.bind_draw()
        self.button0.draw_box()
        #|
    def draw_blf(self):
        self.button0.draw_blf()
        #|
    #|
    #|
class BlockR(FnDarkButtons):
    __slots__ = (
        'w',
        'buttons',
        'box_block',
        'focus_element')

    def __init__(self, w):
        self.w = w
        self.box_block = GpuBox_block()
        #|

    def init_bat(self, LL, RR, TT):
        gap = SIZE_button[1]
        full_h = D_SIZE['widget_full_h']
        T = TT - SIZE_block[4]
        B = T - full_h
        R = RR - SIZE_block[2]
        L = R - D_SIZE['widget_width']
        Lb = R - D_SIZE['widget_bool_full_h']

        for e in self.buttons:
            if hasattr(e, "rna") and hasattr(e, "type") and e.rna.type == "BOOLEAN":
                T = e.init_bat(Lb, R, T - D_SIZE['widget_bool_dT']) - D_SIZE['widget_bool_dB'] - gap
            else:
                T = e.init_bat(L, R, T) - gap

        B = T + gap - SIZE_block[3]
        self.box_block.LRBT_upd(LL, RR, B, TT)
        return B
        #|
    def r_height(self, width):
        return sum(e.r_height(width) for e in self.buttons) + (len(self.buttons) - 1) * SIZE_button[1] + SIZE_block[4] + SIZE_block[3]
        #|

    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        for e in self.buttons: e.outside_evt()
        #|

    def modal(self):
        e = None
        for button in self.buttons:
            if button.inside(MOUSE):
                e = button
                break

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True

        return False
        #|

    def dxy(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        for e in self.buttons: e.dxy(dx, dy)
        #|
    def draw_box(self):
        self.box_block.bind_draw()
        for e in self.buttons: e.draw_box()
        #|
    def draw_blf(self):
        for e in self.buttons: e.draw_blf()
        #|

    def background_off(self):
        self.box_block.__class__ = GpuBox
        self.box_block.color = FLO_0000
        #|

    def upd_data(self):
        for e in self.buttons: e.upd_data()
        #|
    #|
    #|
class Blocks(               # BlockR                                                            
    BlockR):
    __slots__ = 'area', 'level', 'is_fold'

    def __init__(self, w):
        self.w = w
        self.box_block = GpuBox_block()
        self.is_fold = False
        #|

    def init_bat(self, LL, RR, TT):
        gap = SIZE_button[1]
        full_h = D_SIZE['widget_full_h']
        T = TT - SIZE_block[4]
        B = T - full_h
        R = RR - SIZE_block[2]
        L = LL + SIZE_block[1]

        for e in self.buttons:
            if hasattr(e, "level"):
                T = e.init_bat(LL, RR, T) - gap
            else:
                T = e.init_bat(L, R, T) - gap

        B = T + gap - SIZE_block[3]
        self.box_block.LRBT_upd(LL, RR, B, TT)
        return B
        #|

    def init_fold(self, recursive=False):
        self.is_fold = True
        for e in self.buttons:
            if hasattr(e, "init_fold"): e.init_fold(recursive=recursive)
        #|
    def init_unfold(self, recursive=False):
        self.is_fold = False
        for e in self.buttons:
            if hasattr(e, "init_unfold"): e.init_unfold(recursive=recursive)
        #|
    #|
    #|

class BlockCalcButton:
    __slots__ = (
        'w',
        'rna',
        'box_block',
        'box_button',
        'blf_value',
        'is_inside_button',
        'is_trigger_enable',
        'is_repeat',
        'active_index',
        'active_tab')

    def __init__(self, w, ty="Float"):
        self.w = w
        self.is_repeat = True

        self.box_block = GpuBox(COL_block_calc_button_bg)
        self.box_button = [GpuButton()  for _ in range(10)]
        self.rna = []
        self.blf_value = [BlfClipColor(color=COL_box_button_fg) for _ in range(10)]

        self.active_index = None
        self.active_tab = ty
        #|

    def init_bat(self, L, R, T):
        offset_x = SIZE_block[1] + D_SIZE['font_main_dx']
        x = L + offset_x

        h = D_SIZE['widget_full_h']
        widget_spacing = SIZE_widget[3]
        widget_rim = SIZE_border[3]
        T0 = T - widget_spacing
        B0 = T0 - h
        L0 = L + widget_spacing
        R0 = R - widget_spacing
        L0_R0 = R0 + L0
        R1 = floor(L0_R0 / 2 - widget_spacing)
        L1 = R1 + widget_spacing
        L0_R1 = L0 + R1
        L1_R0 = L1 + R0
        depth = h + widget_spacing
        y = T0 - D_SIZE['font_main_dT']
        blfSize(FONT0, D_SIZE['font_main'])

        box_button = self.box_button
        blf_value = self.blf_value
        box_button[0].LRBT_upd(L0, R1, B0, T0, widget_rim)
        blf_value[0].y = y
        box_button[1].LRBT_upd(L1, R0, B0, T0, widget_rim)
        blf_value[1].y = y
        T0 -= depth
        B0 -= depth
        y -= depth
        box_button[2].LRBT_upd(L0, R1, B0, T0, widget_rim)
        blf_value[2].y = y
        box_button[3].LRBT_upd(L1, R0, B0, T0, widget_rim)
        blf_value[3].y = y
        T0 -= depth
        B0 -= depth
        y -= depth
        box_button[4].LRBT_upd(L0, R1, B0, T0, widget_rim)
        blf_value[4].y = y
        box_button[5].LRBT_upd(L1, R0, B0, T0, widget_rim)
        blf_value[5].y = y
        T0 -= depth
        B0 -= depth
        y -= depth
        box_button[6].LRBT_upd(L0, R1, B0, T0, widget_rim)
        blf_value[6].y = y
        box_button[7].LRBT_upd(L1, R0, B0, T0, widget_rim)
        blf_value[7].y = y
        T0 -= depth
        B0 -= depth
        y -= depth
        box_button[8].LRBT_upd(L0, R0, B0, T0, widget_rim)
        blf_value[8].y = y
        T0 -= depth
        B0 -= depth
        y -= depth
        box_button[9].LRBT_upd(L0, R0, B0, T0, widget_rim)
        blf_value[9].y = y

        B = B0 - widget_spacing
        self.box_block.LRBT_upd(L, R, B, T)
        self.update_buttons(self.active_tab)
        return B
        #|
    def r_height(self, width): return 0

    def inside_evt(self):
        pass
        #|
    def outside_evt(self):
        if self.is_repeat:
            # <<< 1copy (0block_unreg_timer_button_safe,, $$)
            if timer_isreg(timer_button):
                timer_unreg(timer_button)

            # >>>
            # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
            if timer_isreg(timer_hold):
                timer_unreg(timer_hold)

            # >>>

        if self.active_index is not None:
            self.box_button[self.active_index].set_state_default()
            Admin.REDRAW()
        self.active_index = None
        #|

    def modal(self):
        for r, e in enumerate(self.box_button):
            if e.inbox(MOUSE):
                if self.active_index != r:
                    # <<< 1copy (0block_BlockButtons_outside_button,, ${'self.active_index = None':''}$)
                    if self.active_index is not None:
                        if self.is_repeat:
                            # <<< 1copy (0block_unreg_timer_button_safe,, $$)
                            if timer_isreg(timer_button):
                                timer_unreg(timer_button)

                            # >>>
                            # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
                            if timer_isreg(timer_hold):
                                timer_unreg(timer_hold)

                            # >>>

                        self.box_button[self.active_index].set_state_default()
                        Admin.REDRAW()
                        
                    # >>>

                    e.set_state_focus()
                    Admin.REDRAW()
                    self.active_index = r
                    self.is_trigger_enable = True

                if self.is_trigger_enable is True:
                    if TRIGGER['click']():
                        Admin.REDRAW()
                        self.is_trigger_enable = False
                        e.set_state_press()
                        if hasattr(self.fn, '__len__'): self.fn[r]()
                        else: self.fn()
                        if self.is_repeat: self.reg_repeat_timer()
                        return True
                elif EVT_TYPE[0] == "TIMER_REPORT": pass
                else:
                    if EVT_TYPE[1] == 'RELEASE' or (EVT_TYPE[1] == 'NOTHING' and Admin.EVT.value_prev == 'RELEASE'):
                        if self.is_repeat:
                            # <<< 1copy (0block_unreg_timer_button_safe,, $$)
                            if timer_isreg(timer_button):
                                timer_unreg(timer_button)

                            # >>>
                            # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
                            if timer_isreg(timer_hold):
                                timer_unreg(timer_hold)

                            # >>>
                        self.is_trigger_enable = True
                        e.set_state_focus()
                        Admin.REDRAW()
                return False

        # /* 0block_BlockButtons_outside_button
        if self.active_index is not None:
            if self.is_repeat:
                # <<< 1copy (0block_unreg_timer_button_safe,, $$)
                if timer_isreg(timer_button):
                    timer_unreg(timer_button)

                # >>>
                # <<< 1copy (0block_unreg_timer_hold_safe,, $$)
                if timer_isreg(timer_hold):
                    timer_unreg(timer_hold)

                # >>>

            self.box_button[self.active_index].set_state_default()
            Admin.REDRAW()
            self.active_index = None
        # */
        return False
        #|

    def reg_repeat_timer(self):
        global _timer_button_fn
        _timer_button_fn = self.fn[self.active_index]  if hasattr(self.fn, '__len__') else self.fn

        # <<< 1copy (0block_reg_timer_hold_safe,, $$)
        if timer_isreg(timer_hold) == False:
            timer_reg(timer_hold, first_interval=P.button_repeat_time)

        # >>>
        #|

    def dxy(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        for e in self.box_button: e.dxy_upd(dx, dy)
        for e in self.blf_value:
            e.x += dx
            e.y += dy
        #|
    def draw_box(self):
        self.box_block.bind_draw()
        for e in self.box_button: e.bind_draw()
        #|
    def draw_blf(self):
        blfSize(FONT0, D_SIZE['font_main'])
        for e in self.blf_value:
            blfColor(FONT0, *e.color)
            blfPos(FONT0, e.x, e.y, 0)
            blfDraw(FONT0, e.text)
        #|

    def fn(self):

        area_textbox = self.w.w.area_textbox
        area_textbox.calc_text()
        area_textbox.beam_input_replace(self.rna[self.active_index].description)
        area_textbox.calc_text(False)
        if is_value(area_textbox.calc.ans_flo):
            area_textbox.beam_input_replace(self.w.w.area_display.item.blf_title.text)
        #|

    def update_buttons(self, ty):
        rna = self.rna
        rna[:] = r_calc_button_rnas(ty)
        self.active_tab = ty
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value = self.blf_value

        d2 = (D_SIZE['font_main_dx'] + SIZE_border[3]) * 2
        L0 = self.box_button[0].L
        R0 = self.box_button[0].R
        L9 = self.box_button[9].L
        R9 = self.box_button[9].R
        LR0 = L0 + R0
        LR9 = L9 + R9
        LR1 = self.box_button[1].L + self.box_button[1].R
        clip_R0 = R0 - L0 - d2
        clip_R9 = R9 - L9 - d2
        for r in range(10):
            e = blf_value[r]
            e.unclip_text = rna[r].default
            if r > 7:
                e.text = r_blf_clipping_end(e.unclip_text, 0, clip_R9)
                e.x = floor((LR9 - blfDimen(FONT0, e.text)[0]) / 2)
            else:
                e.text = r_blf_clipping_end(e.unclip_text, 0, clip_R0)
                if r % 2 == 0:
                    e.x = floor((LR0 - blfDimen(FONT0, e.text)[0]) / 2)
                else:
                    e.x = floor((LR1 - blfDimen(FONT0, e.text)[0]) / 2)
        #|

    def upd_data(self): pass
    #|
    #|

class BlockUtil(FnDarkItems):                # One header button
    __slots__ = (
        'w',
        'items',
        'button0',
        'button_fold',
        'box_block',
        'blf_title',
        'is_fold',
        'init_bat',
        'draw_box',
        'draw_blf',
        'r_height',
        'dxy',
        'focus_element',
        'level',
        'area',
        'box_guideline',
        'box_title')

    DEFAULT_FOLD_STATE = False

    def __init__(self, w, items, button0=None, title=""):
        self.w = w
        if hasattr(w, "level"):
            self.level = w.level + 1
            self.area = w.area
            if self.level % 2 == 0:
                self.box_block = GpuBox_block()
                self.box_title = GpuBox(COL_block_title)
                self.box_guideline = GpuBox(COL_block_guideline0)
            else:
                self.box_block = GpuBox(COL_block_even)
                self.box_title = GpuBox(COL_block_title_even)
                self.box_guideline = GpuBox(COL_block_guideline1)
        else:
            self.level = 0
            self.area = w
            self.box_block = GpuBox_block()
            self.box_title = GpuBox(COL_block_title)
            self.box_guideline = GpuBox(COL_block_guideline0)

        self.button0 = button0
        if button0 is not None: button0.w = self
        self.blf_title = Blf(title)
        self.button_fold = ButtonFold(self)
        self.items = items
        self.init_fold()  if BlockUtil.DEFAULT_FOLD_STATE else self.init_unfold()
        #|
    def init_fold(self, recursive=False):
        self.is_fold = True
        self.init_bat = self.i_init_bat_fold
        self.draw_box = self.i_draw_box_fold
        self.draw_blf = self.i_draw_blf_fold
        self.r_height = self.i_r_height_fold
        self.dxy = self.i_dxy_fold
        self.button_fold.box_button = GpuImg_fold()

        if recursive and self.items:
            for e in self.items:
                if hasattr(e, "init_fold"): e.init_fold(recursive=recursive)
        #|
    def init_unfold(self, recursive=False):
        self.is_fold = False
        self.init_bat = self.i_init_bat
        self.draw_box = self.i_draw_box
        self.draw_blf = self.i_draw_blf
        self.r_height = self.i_r_height
        self.dxy = self.i_dxy
        self.button_fold.box_button = GpuImg_unfold()

        if recursive and self.items:
            for e in self.items:
                if hasattr(e, "init_unfold"): e.init_unfold(recursive=recursive)
        #|

    def i_init_bat(self, L, R, T):
        guideline_width = SIZE_block[7]

        if self.level == 0:
            h = SIZE_widget[0]
            L0 = L + SIZE_block[1]
            x = L0 + h
            T0 = T - SIZE_block[4]
            T1 = T0 - h
            block_gap = SIZE_block[0]
            button_gap = SIZE_button[1]
            R0 = R - SIZE_block[2]

            self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
            y = T0 - D_SIZE['font_main_dT']
            self.blf_title.x = x
            self.blf_title.y = y
            if self.button0 is None: B = T1 - SIZE_border[3] - SIZE_block[3]
            else:
                if self.blf_title.text:
                    B = self.button0.init_bat(L0, R0, T0 + SIZE_border[3]) - SIZE_block[3]
                else:
                    B = self.button0.init_bat(x, R0, T0 + SIZE_border[3]) - SIZE_block[3]
            B0 = B + SIZE_border[3] + SIZE_block[3] // 2

            for e in self.items:
                if hasattr(e, "level"):
                    B = e.init_bat(L, R, B) - block_gap
                else:
                    B = e.init_bat(L0, R0, B) - button_gap

            B -= SIZE_block[3]
            self.box_block.LRBT_upd(L, R, B, T)
            self.box_guideline.LRBT_upd(L0, L0 + guideline_width, B, T1)
            self.box_title.LRBT_upd(L, R, B0, T)
        else:
            h = SIZE_widget[0]
            L += h // 2
            L0 = L + SIZE_block[1]
            x = L0 + h
            T0 = T - SIZE_block[4]
            T1 = T0 - h
            block_gap = SIZE_block[0]
            button_gap = SIZE_button[1]
            R0 = R - SIZE_block[2]

            self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
            y = T0 - D_SIZE['font_main_dT']
            self.blf_title.x = x
            self.blf_title.y = y
            if self.button0 is None: B = T1 - SIZE_border[3] - SIZE_block[3]
            else:
                if self.blf_title.text:
                    B = self.button0.init_bat(L0, R0, T0 + SIZE_border[3]) - SIZE_block[3]
                else:
                    B = self.button0.init_bat(x, R0, T0 + SIZE_border[3]) - SIZE_block[3]
            B0 = B + SIZE_border[3] + SIZE_block[3] // 2

            for e in self.items:
                if hasattr(e, "level"):
                    B = e.init_bat(L, R, B) - block_gap
                else:
                    B = e.init_bat(L0, R0, B) - button_gap

            B -= SIZE_block[3]
            self.box_block.LRBT_upd(L, R, B, T)
            self.box_guideline.LRBT_upd(L0, L0 + guideline_width, B, T1)
            self.box_title.LRBT_upd(L, R, B0, T)
        return B
        #|
    def i_init_bat_fold(self, L, R, T):
        if self.level == 0:
            h = SIZE_widget[0]
            L0 = L + SIZE_block[1]
            x = L0 + h
            T0 = T - SIZE_block[4]
            T1 = T0 - h
            block_gap = SIZE_block[0]
            button_gap = SIZE_button[1]
            R0 = R - SIZE_block[2]

            self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
            y = T0 - D_SIZE['font_main_dT']
            self.blf_title.x = x
            self.blf_title.y = y
            if self.button0 is None: B = T1 - SIZE_border[3] - SIZE_block[3]
            else:
                if self.blf_title.text:
                    B = self.button0.init_bat(L0, R0, T0 + SIZE_border[3]) - SIZE_block[3]
                else:
                    B = self.button0.init_bat(x, R0, T0 + SIZE_border[3]) - SIZE_block[3]
            B0 = B + SIZE_border[3] + SIZE_block[3] // 2

            # for e in self.items:
            #     if hasattr(e, "level"):
            #         B = e.init_bat(L, R, B) - block_gap
            #     else:
            #         B = e.init_bat(L0, R0, B) - button_gap

            self.box_block.LRBT_upd(L, R, B0, T)
            self.box_title.LRBT_upd(L, R, B0, T)
        else:
            h = SIZE_widget[0]
            L += h // 2
            L0 = L + SIZE_block[1]
            x = L0 + h
            T0 = T - SIZE_block[4]
            T1 = T0 - h
            block_gap = SIZE_block[0]
            button_gap = SIZE_button[1]
            R0 = R - SIZE_block[2]

            self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
            y = T0 - D_SIZE['font_main_dT']
            self.blf_title.x = x
            self.blf_title.y = y
            if self.button0 is None: B = T1 - SIZE_border[3] - SIZE_block[3]
            else:
                if self.blf_title.text:
                    B = self.button0.init_bat(L0, R0, T0 + SIZE_border[3]) - SIZE_block[3]
                else:
                    B = self.button0.init_bat(x, R0, T0 + SIZE_border[3]) - SIZE_block[3]
            B0 = B + SIZE_border[3] + SIZE_block[3] // 2

            # for e in self.items:
            #     if hasattr(e, "level"):
            #         B = e.init_bat(L, R, B) - block_gap
            #     else:
            #         B = e.init_bat(L0, R0, B) - button_gap

            self.box_block.LRBT_upd(L, R, B0, T)
            self.box_title.LRBT_upd(L, R, B0, T)
        return B0
        #|
    def i_r_height(self, width):
        block_gap = SIZE_block[0]
        button_gap = SIZE_button[1]

        if self.button0 is None: B = - SIZE_block[4] - SIZE_widget[0] - SIZE_border[3] - SIZE_block[3]
        else:
            B = - SIZE_block[4] + SIZE_border[3] - self.button0.r_height(width) - SIZE_block[3]

        width_button = width - SIZE_block[1] - SIZE_block[2]
        for e in self.items:
            if hasattr(e, "level"):
                B -= e.r_height(width) + block_gap
            else:
                B -= e.r_height(width_button) + button_gap

        return SIZE_block[3] - B
        #|
    def i_r_height_fold(self, width):
        # return SIZE_block[4] + SIZE_widget[0] + SIZE_border[3] + SIZE_block[3
        #     ]  if self.button0 is None else SIZE_block[4] - SIZE_border[3
        #     ] + self.button0.r_height(width) + SIZE_block[3]
        return SIZE_block[4] + SIZE_widget[0] + SIZE_block[3] - SIZE_block[3] // 2  if self.button0 is None else SIZE_block[4] - SIZE_border[3
            ] + self.button0.r_height(width) + SIZE_block[3] - SIZE_border[3] - SIZE_block[3] // 2
        #|

    def inside(self, mouse): return self.box_block.inbox(mouse)
    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        if self.button0 is not None: self.button0.outside_evt()
        self.button_fold.outside_evt()
        for e in self.items: e.outside_evt()
        #|

    def modal(self):
        if self.button0 is not None and self.button0.inside(MOUSE): e = self.button0
        elif self.button_fold.inside(MOUSE): e = self.button_fold
        else:
            e = None
            for o in self.items:
                if o.inside(MOUSE):
                    e = o
                    break

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['fold_recursive_toggle']():
            self.evt_fold_toggle(recursive=True)
            return True
        if TRIGGER['fold_toggle']():
            self.evt_fold_toggle()
            return True
        return False
        #|

    def to_modal_rm(self):

        # /* 0block_BlockUtil_to_modal_rm
        items = []
        if hasattr(self.w, "evt_fold_all_toggle"):
            items.append(("Unfold All", self.w.evt_unfold_all))
            items.append(("Fold All", self.w.evt_fold_all))
            items.append(("fold_all_toggle", self.w.evt_fold_all_toggle))
        elif hasattr(self, "area") and hasattr(self.area, "evt_fold_all_toggle"):
            area = self.area
            items.append(("Unfold All", area.evt_unfold_all))
            items.append(("Fold All", area.evt_fold_all))
            items.append(("fold_all_toggle", area.evt_fold_all_toggle))

        items.append(("Unfold Recursive", lambda: self.evt_unfold(recursive=True)))
        items.append(("Fold Recursive", lambda: self.evt_fold(recursive=True)))
        items.append(("Unfold", self.evt_unfold))
        items.append(("Fold", self.evt_fold))
        items.append(("fold_recursive_toggle", lambda: self.evt_fold_toggle(recursive=True)))
        items.append(("fold_toggle", self.evt_fold_toggle))

        if hasattr(self.w, "w") and hasattr(self.w.w, "evt_undo"):
            items.append(("redo", self.w.w.evt_redo))
            items.append(("undo", self.w.w.evt_undo))

        DropDownRMKeymap(self, MOUSE, items)
        # */

    def i_dxy(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.box_guideline.dxy_upd(dx, dy)
        self.box_title.dxy_upd(dx, dy)
        self.button_fold.box_button.dxy_upd(dx, dy)
        if self.button0 is not None: self.button0.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy

        for e in self.items: e.dxy(dx, dy)
        #|
    def i_dxy_fold(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.box_title.dxy_upd(dx, dy)
        self.button_fold.box_button.dxy_upd(dx, dy)
        if self.button0 is not None: self.button0.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy
        #|
    def i_draw_box(self):
        self.box_block.bind_draw()
        self.box_guideline.bind_draw()
        self.box_title.bind_draw()
        self.button_fold.box_button.bind_draw()
        if self.button0 is not None: self.button0.draw_box()
        for e in self.items: e.draw_box()
        #|
    def i_draw_box_fold(self):
        self.box_block.bind_draw()
        self.box_title.bind_draw()
        self.button_fold.box_button.bind_draw()
        if self.button0 is not None: self.button0.draw_box()
        #|
    def i_draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *COL_block_fg)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        if self.button0 is not None: self.button0.draw_blf()

        for e in self.items: e.draw_blf()
        #|
    def i_draw_blf_fold(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *COL_block_fg)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        if self.button0 is not None: self.button0.draw_blf()
        #|

    def evt_unfold(self, kill_evt=True, recursive=False):

        if kill_evt: kill_evt_except()
        # Admin.REDRAW()
        self.init_unfold(recursive=recursive)
        e = self.box_block
        self.init_bat(e.L, e.R, e.T)

        self.area.redraw_from_headkey()
        if hasattr(self.area, "upd_data_callback"): self.area.upd_data_callback()
        _last_bool_state[0] = False
        #|
    def evt_fold(self, kill_evt=True, recursive=False):

        if kill_evt: kill_evt_except()
        # Admin.REDRAW()
        self.init_fold(recursive=recursive)
        e = self.box_block
        self.init_bat(e.L, e.R, e.T)

        self.area.redraw_from_headkey()
        if hasattr(self.area, "upd_data_callback"): self.area.upd_data_callback()
        _last_bool_state[0] = True
        #|
    def evt_fold_toggle(self, kill_evt=True, recursive=False):
        # Admin.REDRAW()
        if self.is_fold:
            self.evt_unfold(kill_evt=kill_evt, recursive=recursive)
        else:
            self.evt_fold(kill_evt=kill_evt, recursive=recursive)
        #|

    def upd_data(self):
        if self.button0 is not None: self.button0.upd_data()
        for e in self.items: e.upd_data()
        #|
    #|
    #|
class BlockUtils(BlockUtil):    # Multi header buttons
    __slots__ = 'buttons'

    def __init__(self, w, items, buttons=None, title=""):
        self.w = w
        if hasattr(w, "level"):
            self.level = w.level + 1
            self.area = w.area
            if self.level % 2 == 0:
                self.box_block = GpuBox_block()
                self.box_title = GpuBox(COL_block_title)
                self.box_guideline = GpuBox(COL_block_guideline0)
            else:
                self.box_block = GpuBox(COL_block_even)
                self.box_title = GpuBox(COL_block_title_even)
                self.box_guideline = GpuBox(COL_block_guideline1)
        else:
            self.level = 0
            self.area = w
            self.box_block = GpuBox_block()
            self.box_title = GpuBox(COL_block_title)
            self.box_guideline = GpuBox(COL_block_guideline0)

        self.buttons = []  if buttons is None else buttons
        self.blf_title = Blf(title)
        self.button_fold = ButtonFold(self)
        self.init_fold()  if BlockUtil.DEFAULT_FOLD_STATE else self.init_unfold()
        self.items = items
        #|

    def i_init_bat(self, L, R, T):
        guideline_width = SIZE_block[7]

        if self.level == 0:
            h = SIZE_widget[0]
            L0 = L + SIZE_block[1]
            x = L0 + h
            T0 = T - SIZE_block[4]
            T1 = T0 - h
            block_gap = SIZE_block[0]
            button_gap = SIZE_button[1]
            R0 = R - SIZE_block[2]

            self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
            y = T0 - D_SIZE['font_main_dT']
            self.blf_title.x = x
            self.blf_title.y = y
            if self.buttons:
                B = T0 + SIZE_border[3]
                for e in self.buttons:
                    B = e.init_bat(L0, R0, B) - button_gap
                B -= SIZE_block[3]
            else: B = T1 - SIZE_border[3] - SIZE_block[3]
            B0 = B + SIZE_border[3] + SIZE_block[3] // 2

            for e in self.items:
                if hasattr(e, "level"):
                    B = e.init_bat(L, R, B) - block_gap
                else:
                    B = e.init_bat(L0, R0, B) - button_gap

            B -= SIZE_block[3]
            self.box_block.LRBT_upd(L, R, B, T)
            self.box_guideline.LRBT_upd(L0, L0 + guideline_width, B, T1)
            self.box_title.LRBT_upd(L, R, B0, T)
        else:
            h = SIZE_widget[0]
            L += h // 2
            L0 = L + SIZE_block[1]
            x = L0 + h
            T0 = T - SIZE_block[4]
            T1 = T0 - h
            block_gap = SIZE_block[0]
            button_gap = SIZE_button[1]
            R0 = R - SIZE_block[2]

            self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
            y = T0 - D_SIZE['font_main_dT']
            self.blf_title.x = x
            self.blf_title.y = y
            if self.buttons:
                B = T0 + SIZE_border[3]
                for e in self.buttons:
                    B = e.init_bat(L0, R0, B) - button_gap
                B -= SIZE_block[3]
            else: B = T1 - SIZE_border[3] - SIZE_block[3]
            B0 = B + SIZE_border[3] + SIZE_block[3] // 2

            for e in self.items:
                if hasattr(e, "level"):
                    B = e.init_bat(L, R, B) - block_gap
                else:
                    B = e.init_bat(L0, R0, B) - button_gap

            B -= SIZE_block[3]
            self.box_block.LRBT_upd(L, R, B, T)
            self.box_guideline.LRBT_upd(L0, L0 + guideline_width, B, T1)
            self.box_title.LRBT_upd(L, R, B0, T)
        return B
        #|
    def i_init_bat_fold(self, L, R, T):
        if self.level == 0:
            h = SIZE_widget[0]
            L0 = L + SIZE_block[1]
            x = L0 + h
            T0 = T - SIZE_block[4]
            T1 = T0 - h
            block_gap = SIZE_block[0]
            button_gap = SIZE_button[1]
            R0 = R - SIZE_block[2]

            self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
            y = T0 - D_SIZE['font_main_dT']
            self.blf_title.x = x
            self.blf_title.y = y
            if self.buttons:
                B = T0 + SIZE_border[3]
                for e in self.buttons:
                    B = e.init_bat(L0, R0, B) - button_gap
                B -= SIZE_block[3]
            else: B = T1 - SIZE_border[3] - SIZE_block[3]
            B0 = B + SIZE_border[3] + SIZE_block[3] // 2

            # for e in self.items:
            #     if hasattr(e, "level"):
            #         B = e.init_bat(L, R, B) - block_gap
            #     else:
            #         B = e.init_bat(L0, R0, B) - button_gap

            self.box_block.LRBT_upd(L, R, B0, T)
            self.box_title.LRBT_upd(L, R, B0, T)
        else:
            h = SIZE_widget[0]
            L += h // 2
            L0 = L + SIZE_block[1]
            x = L0 + h
            T0 = T - SIZE_block[4]
            T1 = T0 - h
            block_gap = SIZE_block[0]
            button_gap = SIZE_button[1]
            R0 = R - SIZE_block[2]

            self.button_fold.box_button.LRBT_upd(L0, x, T1, T0)
            y = T0 - D_SIZE['font_main_dT']
            self.blf_title.x = x
            self.blf_title.y = y
            if self.buttons:
                B = T0 + SIZE_border[3]
                for e in self.buttons:
                    B = e.init_bat(L0, R0, B) - button_gap
                B -= SIZE_block[3]
            else: B = T1 - SIZE_border[3] - SIZE_block[3]
            B0 = B + SIZE_border[3] + SIZE_block[3] // 2

            # for e in self.items:
            #     if hasattr(e, "level"):
            #         B = e.init_bat(L, R, B) - block_gap
            #     else:
            #         B = e.init_bat(L0, R0, B) - button_gap

            self.box_block.LRBT_upd(L, R, B0, T)
            self.box_title.LRBT_upd(L, R, B0, T)
        return B0
        #|
    def i_r_height(self, width):
        block_gap = SIZE_block[0]
        button_gap = SIZE_button[1]
        width_button = width - SIZE_block[1] - SIZE_block[2]

        if self.buttons:
            B = - SIZE_block[4] + SIZE_border[3]
            for e in self.buttons:
                B = B - e.r_height(width_button) - button_gap
            B -= SIZE_block[3]
        else: B = - SIZE_block[4] - SIZE_widget[0] - SIZE_border[3] - SIZE_block[3]

        for e in self.items:
            if hasattr(e, "level"):
                B = B - e.r_height(width) - block_gap
            else:
                B = B - e.r_height(width_button) - button_gap

        return SIZE_block[3] - B
        #|
    def i_r_height_fold(self, width):
        button_gap = SIZE_button[1]
        width_button = width - SIZE_block[1] - SIZE_block[2]

        if self.buttons:
            B = - SIZE_block[4] + SIZE_border[3]
            for e in self.buttons:
                B = B - e.r_height(width_button) - button_gap
            B -= SIZE_block[3]
        else: B = - SIZE_block[4] - SIZE_widget[0] - SIZE_border[3] - SIZE_block[3]

        return - B - SIZE_border[3] - SIZE_block[3] // 2
        #|

    def outside_evt(self):
        for e in self.buttons: e.outside_evt()
        self.button_fold.outside_evt()
        for e in self.items: e.outside_evt()
        #|

    def modal(self):
        if self.button_fold.inside(MOUSE): e = self.button_fold
        else:
            e = None
            for o in self.buttons:
                if o.inside(MOUSE):
                    e = o
                    break

            if e is None:
                for o in self.items:
                    if o.inside(MOUSE):
                        e = o
                        break

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['fold_toggle']():
            self.evt_fold_toggle()
            return True
        return False
        #|

    def i_dxy(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.box_guideline.dxy_upd(dx, dy)
        self.box_title.dxy_upd(dx, dy)
        self.button_fold.box_button.dxy_upd(dx, dy)
        for e in self.buttons: e.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy

        for e in self.items: e.dxy(dx, dy)
        #|
    def i_dxy_fold(self, dx, dy):
        self.box_block.dxy_upd(dx, dy)
        self.box_title.dxy_upd(dx, dy)
        self.button_fold.box_button.dxy_upd(dx, dy)
        for e in self.buttons: e.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy
        #|
    def i_draw_box(self):
        self.box_block.bind_draw()
        self.box_guideline.bind_draw()
        self.box_title.bind_draw()
        self.button_fold.box_button.bind_draw()
        for e in self.buttons: e.draw_box()
        for e in self.items: e.draw_box()
        #|
    def i_draw_box_fold(self):
        self.box_block.bind_draw()
        self.box_title.bind_draw()
        self.button_fold.box_button.bind_draw()
        for e in self.buttons: e.draw_box()
        #|
    def i_draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *COL_block_fg)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        for e in self.buttons: e.draw_blf()

        for e in self.items: e.draw_blf()
        #|
    def i_draw_blf_fold(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *COL_block_fg)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        for e in self.buttons: e.draw_blf()
        #|

    def upd_data(self):
        for e in self.buttons: e.upd_data()
        for e in self.items: e.upd_data()
        #|
    #|
    #|

class ButtonGroup:
    __slots__ = (
        'w',
        'button0',
        'blf_title',
        'inside',
        'inside_evt',
        'outside_evt',
        'evtkill',
        'r_button_width',
        'r_offset')

    def __init__(self, w, button0, title=None):
        self.w = w
        self.button0 = button0
        button0.w = self
        self.blf_title = BlfClipColor(unclip_text=button0.rna.name  if title is None else title,
            color=COL_block_fg)
        self.inside = button0.inside
        self.inside_evt = button0.inside_evt
        self.outside_evt = button0.outside_evt
        #|

    def init_bat(self, LL, RR, TT):
        L = RR - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        if self.button0.rna.type == "BOOLEAN":
            self.evtkill = False
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
        else:
            B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        if hasattr(self.button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(self.button0.blf_subtype, "__len__"):
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    max(blfDimen(FONT0, o.text)[0]  for o in self.button0.blf_subtype))
            else:
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    blfDimen(FONT0, self.button0.blf_subtype.text)[0])
        else:
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])
        return B
        #|
    def r_height(self, width):
        return self.button0.r_height(width)
        #|

    def is_dark(self):
        return True  if self.button0.is_dark() else False
        #|
    def dark(self):
        self.button0.dark()
        self.blf_title.color = COL_block_fg_ignore
        #|
    def light(self):
        self.button0.light()
        self.blf_title.color = COL_block_fg
        #|

    def modal(self): return self.button0.modal()

    def dxy(self, dx, dy):
        self.button0.dxy(dx, dy)
        self.blf_title.x += dx
        self.blf_title.y += dy
        #|
    def draw_box(self):
        self.button0.draw_box()
        #|
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        self.button0.draw_blf()
        #|

    def upd_data(self): return self.button0.upd_data()
    #|
    #|
class ButtonGroupTitle:
    __slots__ = (
        'w',
        'blf_title')

    def __init__(self, w, title=""):
        self.w = w
        self.blf_title = BlfClipColor(unclip_text=title, color=COL_block_fg)
        #|

    def init_bat(self, LL, RR, TT):
        blfSize(FONT0, D_SIZE['font_main'])
        e = self.blf_title
        e.text = e.unclip_text
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        e.x = LL + D_SIZE['font_main_dx']
        return TT - D_SIZE['widget_full_h']
        #|
    def r_height(self, width): return D_SIZE['widget_full_h']
    def is_dark(self): return False
    def dark(self): pass
    def light(self): pass
    def inside(self, mouse): return False
    def inside_evt(self): pass
    def outside_evt(self): pass

    def modal(self): return False

    def dxy(self, dx, dy):
        self.blf_title.x += dx
        self.blf_title.y += dy
        #|
    def draw_box(self): pass
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self): pass
    #|
    #|
class ButtonGroupAlignL(                # ButtonGroup                                           
    ButtonGroup):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        L = RR - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        if self.button0.rna.type == "BOOLEAN":
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
        else:
            B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        if hasattr(self.button0.box_button, 'R'):
            e.x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']
        else:
            e.x = self.button0.box_button[-1].R + D_SIZE['font_main_title_offset_R']
        e.text = e.unclip_text
        return B
        #|
    #|
    #|
class ButtonGroupBoolT(                 # ButtonGroup                                           
    ButtonGroup):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        LL += D_SIZE['font_main_dx']
        if hasattr(self, "r_offset"): LL += self.r_offset()

        if self.button0.rna.type == "BOOLEAN":
            self.button0.init_bat(LL, LL + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
        else:
            B = self.button0.init_bat(LL, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        if hasattr(self.button0.box_button, 'R'):
            e.x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']
        else:
            e.x = self.button0.box_button[-1].R + D_SIZE['font_main_title_offset_R']
        e.text = e.unclip_text
        return B
        #|
    #|
    #|
class ButtonGroupAlignTitleLeft(        # ButtonGroup                                           
    ButtonGroup):
    __slots__ = "aligntitle"

    def init_bat(self, LL, RR, TT):
        blfSize(FONT0, D_SIZE['font_main'])
        e = self.blf_title
        e.text = e.unclip_text
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        e.x = LL + D_SIZE['font_main_dx']
        L = e.x + round(blfDimen(FONT0, self.aligntitle  if hasattr(self, "aligntitle") else e.text)[0]) + D_SIZE['font_main_title_offset_R']
        if self.button0.rna.type == "BOOLEAN":
            self.evtkill = False
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            return TT - D_SIZE['widget_full_h']
        else:
            return self.button0.init_bat(L, RR, TT)
        #|
    #|
    #|
class ButtonGroupHeadL(                 # ButtonGroup                                           
    ButtonGroup):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        LL += SIZE_widget[0]
        blfSize(FONT0, D_SIZE['font_main'])
        e = self.blf_title
        e.text = e.unclip_text
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        e.x = LL + D_SIZE['font_main_dx']
        if e.text == "":
            L = LL + D_SIZE['font_main_title_offset_R']
        else:
            L = e.x + round(blfDimen(FONT0, e.text)[0]) + D_SIZE['font_main_title_offset_R']
        if self.button0.rna.type == "BOOLEAN":
            self.evtkill = False
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            return TT - D_SIZE['widget_full_h']
        else:
            button_width = self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width']
            return self.button0.init_bat(L, LL + button_width, TT)
        #|
    #|
    #|
class ButtonGroupLC(                    # ButtonGroup                                           
    ButtonGroup):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        L = RR - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        if self.button0.rna.type == "BOOLEAN":
            self.evtkill = False
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
        else:
            B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        e.x = LL + D_SIZE['font_main_dx'] + D_SIZE['font_main_title_offset_R']
        if hasattr(self.button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(self.button0.blf_subtype, "__len__"):
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    max(blfDimen(FONT0, o.text)[0]  for o in self.button0.blf_subtype))
            else:
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    blfDimen(FONT0, self.button0.blf_subtype.text)[0])
        else:
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        return B
        #|
    #|
    #|
class ButtonGroupAlignLR(               # ButtonGroup                                           
    ButtonGroup):
    __slots__ = 'blf_title_head'

    def __init__(self, w, button0, title=None, title_head=""):
        self.w = w
        self.button0 = button0
        button0.w = self
        self.blf_title = BlfClipColor(unclip_text=button0.rna.name  if title is None else title,
            color=COL_block_fg)
        self.blf_title_head = BlfClipColor(unclip_text=title_head, color=COL_block_fg)
        self.inside = button0.inside
        self.inside_evt = button0.inside_evt
        self.outside_evt = button0.outside_evt
        #|

    def init_bat(self, LL, RR, TT):
        L = RR - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        if self.button0.rna.type == "BOOLEAN":
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
            self.evtkill = False
        else:
            B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title_head
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        if hasattr(self.button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(self.button0.blf_subtype, "__len__"):
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    max(blfDimen(FONT0, o.text)[0]  for o in self.button0.blf_subtype))
            else:
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    blfDimen(FONT0, self.button0.blf_subtype.text)[0])
        else:
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])

        e = self.blf_title
        e.y = self.blf_title_head.y
        e.x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']
        e.text = e.unclip_text
        return B
        #|

    def dxy(self, dx, dy):
        self.button0.dxy(dx, dy)
        self.blf_title.x += dx
        self.blf_title.y += dy
        self.blf_title_head.x += dx
        self.blf_title_head.y += dy
        #|
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        e = self.blf_title_head
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        self.button0.draw_blf()
        #|
    #|
    #|
class ButtonGroupFull(                  # ButtonGroup                                           
    ButtonGroup):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        LL += D_SIZE['font_main_dx']
        L = RR - D_SIZE['widget_width']
        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        if hasattr(self.button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(self.button0.blf_subtype, "__len__"):
                width_subtype = round(max(blfDimen(FONT0, o.text)[0]  for o in self.button0.blf_subtype))
            else:
                width_subtype = round(blfDimen(FONT0, self.button0.blf_subtype.text)[0])
            R0 = L - D_SIZE['font_main_title_offset'] - width_subtype
        else:
            width_subtype = 0
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL, R0)
        e.x = LL

        if width_subtype == 0:
            B = self.button0.init_bat(
                LL + round(blfDimen(FONT0, e.text)[0]) + D_SIZE['font_main_title_offset'], RR, TT)
        else:
            B = self.button0.init_bat(width_subtype + D_SIZE['font_label_dx'] +
                LL + round(blfDimen(FONT0, e.text)[0]) + D_SIZE['font_main_title_offset'], RR, TT)
        return B
        #|
    #|
    #|
class ButtonGroupTwo:
    __slots__ = (
        'w',
        'button0',
        'button1',
        'blf_title',
        'focus_element',
        'evtkill')

    def __init__(self, w, button0, button1, title=""):
        self.w = w
        self.button0 = button0
        self.button1 = button1
        button0.w = self
        button1.w = self
        self.blf_title = BlfClipColor(unclip_text=title, color=COL_block_fg)
        #|

    def init_bat(self, LL, RR, TT):
        L = RR - D_SIZE['widget_width']

        # /* 0block_ButtonGroupTwo_init_bat
        if self.button0.rna.type == "BOOLEAN":
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
        else:
            B = self.button0.init_bat(L, RR, TT)

        R1 = self.button0.box_button.L - SIZE_widget[3]
        if self.button1.rna.type == "BOOLEAN":
            self.button1.init_bat(R1 - D_SIZE['widget_bool_full_h'], R1, TT - D_SIZE['widget_bool_dT'])
            B1 = TT - D_SIZE['widget_full_h']
        else:
            B1 = self.button1.init_bat(R1 - D_SIZE['widget_width'], R1, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        R0 = self.button1.box_button.L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])
        return min(B, B1)
        # */
    def r_height(self, width):
        return max(self.button0.r_height(D_SIZE['widget_width']), self.button1.r_height(D_SIZE['widget_width']))
        #|

    def is_dark(self):
        return self.button0.is_dark()
        #|
    def dark(self):
        self.button0.dark()
        self.button1.dark()
        self.blf_title.color = COL_block_fg_ignore
        #|
    def light(self):
        self.button0.light()
        self.button1.light()
        self.blf_title.color = COL_block_fg
        #|

    def inside(self, mouse):
        if self.button0.inside(mouse):
            self.evtkill = False  if hasattr(self.button0, "evtkill") and self.button0.evtkill == False else True
            return True
        if self.button1.inside(mouse):
            self.evtkill = False  if hasattr(self.button1, "evtkill") and self.button1.evtkill == False else True
            return True
        return False
        #|
    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        self.button0.outside_evt()
        self.button1.outside_evt()
        #|

    def modal(self):
        if self.button0.inside(MOUSE): e = self.button0
        elif self.button1.inside(MOUSE): e = self.button1
        else: e = None

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True
        return False
        #|

    def dxy(self, dx, dy):
        self.button0.dxy(dx, dy)
        self.button1.dxy(dx, dy)
        self.blf_title.x += dx
        self.blf_title.y += dy
        #|
    def draw_box(self):
        self.button0.draw_box()
        self.button1.draw_box()
        #|
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        self.button0.draw_blf()
        self.button1.draw_blf()
        #|

    def upd_data(self):
        self.button0.upd_data()
        self.button1.upd_data()
        #|
    #|
    #|
class ButtonGroupTwoHalf(ButtonGroupTwo):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        L = RR - D_SIZE['widget_width'] // 2

        # <<< 1copy (0block_ButtonGroupTwo_init_bat,, ${"R1 - D_SIZE['widget_width']":"RR - D_SIZE['widget_width']"}$)
        if self.button0.rna.type == "BOOLEAN":
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
        else:
            B = self.button0.init_bat(L, RR, TT)

        R1 = self.button0.box_button.L - SIZE_widget[3]
        if self.button1.rna.type == "BOOLEAN":
            self.button1.init_bat(R1 - D_SIZE['widget_bool_full_h'], R1, TT - D_SIZE['widget_bool_dT'])
            B1 = TT - D_SIZE['widget_full_h']
        else:
            B1 = self.button1.init_bat(RR - D_SIZE['widget_width'], R1, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        R0 = self.button1.box_button.L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])
        return min(B, B1)
        # >>>
        #|
    #|
    #|
class ButtonGroupY:
    __slots__ = (
        'w',
        'buttons',
        'focus_element',
        'gap',
        'evtkill',
        'r_button_width')

    def __init__(self, w, buttons, gap=0):
        self.w = w
        self.buttons = buttons
        self.gap = gap
        #|

    def init_bat(self, LL, RR, TT):
        gap = self.gap()  if callable(self.gap) else self.gap
        for button in self.buttons:
            TT = button.init_bat(LL, RR, TT) - gap
        return TT + gap
        #|
    def r_height(self, width):
        gap = self.gap()  if callable(self.gap) else self.gap
        return sum(button.r_height(width)  for button in self.buttons) + (len(self.buttons) - 1) * gap
        #|

    def dark(self):
        for e in self.buttons:
            if hasattr(e, "dark"): e.dark()
        #|
    def light(self):
        for e in self.buttons:
            if hasattr(e, "light"): e.light()
        #|

    def inside(self, mouse):
        for button in self.buttons:
            if button.inside(mouse):
                self.evtkill = False  if hasattr(button, "evtkill") and button.evtkill == False else True
                return True
        return False
        #|
    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        for button in self.buttons:
            button.outside_evt()
        #|

    def modal(self):
        e = None
        for button in self.buttons:
            if button.inside(MOUSE):
                e = button
                break

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True
        return False
        #|

    def dxy(self, dx, dy):
        for e in self.buttons: e.dxy(dx, dy)
        #|
    def draw_box(self):
        for e in self.buttons: e.draw_box()
        #|
    def draw_blf(self):
        for e in self.buttons: e.draw_blf()
        #|

    def upd_data(self):
        for e in self.buttons: e.upd_data()
        #|
    #|
    #|
class ButtonGroupArray(                 # ButtonGroup                                           
    ButtonGroup):
    __slots__ = ()

    def __init__(self, w, button0, title=None):
        self.w = w
        self.button0 = button0
        button0.w = self
        self.blf_title = BlfClipColor(unclip_text=""  if title is None else title,
            color=COL_block_fg)
        self.inside = button0.inside
        self.inside_evt = button0.inside_evt
        self.outside_evt = button0.outside_evt
        #|

    def init_bat(self, LL, RR, TT):
        h = SIZE_widget[0]
        widget_rim = SIZE_border[3]
        L = RR - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])
        B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])
        return B
        #|
    #|
    #|
class ButtonSplit:
    __slots__ = (
        'w',
        'button0',
        'button1',
        'focus_element',
        'factor',
        'gap',
        'evtkill')

    def __init__(self, w, button0, button1, gap=0, factor=0.5):
        self.w = w
        self.gap = gap
        self.factor = factor
        self.button0 = button0
        self.button1 = button1
        button0.w = self
        button1.w = self
        #|

    def init_bat(self, LL, RR, TT):
        gap = self.gap()  if callable(self.gap) else self.gap
        R0 = round(LL + (RR - LL - gap) * self.factor)
        return min(self.button0.init_bat(LL, R0, TT), self.button1.init_bat(R0 + gap, RR, TT))
        #|
    def r_height(self, width):
        return max(self.button0.r_height(width), self.button1.r_height(width))
        #|

    def dark(self):
        if hasattr(self.button0, "dark"): self.button0.dark()
        if hasattr(self.button1, "dark"): self.button1.dark()
        #|
    def light(self):
        if hasattr(self.button0, "light"): self.button0.light()
        if hasattr(self.button1, "light"): self.button1.light()
        #|

    def inside(self, mouse):
        if self.button0.inside(mouse):
            self.evtkill = False  if hasattr(self.button0, "evtkill") and self.button0.evtkill == False else True
            return True
        if self.button1.inside(mouse):
            self.evtkill = False  if hasattr(self.button1, "evtkill") and self.button1.evtkill == False else True
            return True
        return False
        #|
    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        self.button0.outside_evt()
        self.button1.outside_evt()
        #|

    def modal(self):
        if self.button0.inside(MOUSE): e = self.button0
        elif self.button1.inside(MOUSE): e = self.button1
        else: e = None

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True
        return False
        #|

    def dxy(self, dx, dy):
        self.button0.dxy(dx, dy)
        self.button1.dxy(dx, dy)
        #|
    def draw_box(self):
        self.button0.draw_box()
        self.button1.draw_box()
        #|
    def draw_blf(self):
        self.button0.draw_blf()
        self.button1.draw_blf()
        #|

    def upd_data(self):
        self.button0.upd_data()
        self.button1.upd_data()
        #|
    #|
    #|
class ButtonSplitBool(                  # ButtonSplit                                           
    ButtonSplit):
    __slots__ = 'r_sep_x'

    def __init__(self, w, button0, button1, r_sep_x, gap=0):
        self.w = w
        self.gap = gap
        self.r_sep_x = r_sep_x
        self.button0 = button0
        self.button1 = button1
        button0.w = self
        button1.w = self
        #|

    def init_bat(self, LL, RR, TT):
        gap = self.gap()  if callable(self.gap) else self.gap
        B = self.button1.init_bat(LL, RR, TT)
        L = self.r_sep_x() - gap
        self.button0.init_bat(LL, L, TT)
        return B
        #|
    #|
    #|
class ButtonOverlay(                    # ButtonSplit                                           
    ButtonSplit):
    __slots__ = ()

    def __init__(self, w, button0, button1):
        self.w = w
        self.button0 = button0
        self.button1 = button1
        button0.w = self
        button1.w = self
        #|

    def init_bat(self, LL, RR, TT):
        return min(self.button0.init_bat(LL, RR, TT), self.button1.init_bat(LL, RR, TT))
        #|
    #|
    #|

class ButtonGroupAnim(                  # ButtonGroupTwo                                        
    ButtonGroupTwo):
    __slots__ = 'upd_button_keyframe', 'r_fcurve', 'r_driver', 'enums', 'r_button_width'

    def __init__(self, w, button0, r_fcurve, r_driver, title=None):
        self.w = w
        self.button0 = button0
        button0.w = self
        self.blf_title = BlfClipColor(unclip_text=button0.rna.name  if title is None else title,
            color=COL_block_fg)

        self.button1 = ButtonFnImgHoverKeyframe(self, RNA_button_keyframe, button0.bufn_keyframe)
        self.r_fcurve = r_fcurve
        self.r_driver = r_driver

        if hasattr(button0.rna, "type"):
            ty = button0.rna.type
            if ty == "BOOLEAN":
                self.upd_button_keyframe = self.upd_button_keyframe_BOOLEAN
            elif ty == "ENUM":
                self.enums = button0.rna.enum_items
                if button0.rna.is_enum_flag:
                    self.upd_button_keyframe = self.upd_button_keyframe_ENUM_FLAG
                else:
                    self.upd_button_keyframe = self.upd_button_keyframe_ENUM
            else:
                self.upd_button_keyframe = self.upd_button_keyframe_VAL
        #|

    def init_bat(self, LL, RR, TT):
        R2 = RR - SIZE_widget[0]
        R1 = R2 - SIZE_border[3]
        L = R1 - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        if self.button0.rna.type == "BOOLEAN":
            self.evtkill = False
            self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
        else:
            B = self.button0.init_bat(L, R1, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        if hasattr(self.button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(self.button0.blf_subtype, "__len__"):
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    max(blfDimen(FONT0, o.text)[0]  for o in self.button0.blf_subtype))
            else:
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    blfDimen(FONT0, self.button0.blf_subtype.text)[0])
        else:
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])

        self.button1.init_bat(R2, RR, TT - SIZE_border[3])
        return B
        #|
    def set_text(self, s):
        e = self.blf_title
        e.unclip_text = s
        e.text = s
        #|

    def is_dark(self):
        return self.button0.is_dark()
        #|
    def dark(self):
        self.button0.dark()
        self.blf_title.color = COL_block_fg_ignore
        #|
    def light(self):
        self.button0.light()
        self.blf_title.color = COL_block_fg
        #|

    def upd_button_keyframe_BOOLEAN(self):
        dr = self.r_driver()
        if dr:
            if self.button1.box_button.__class__ != GpuImg_driver_true:
                self.button1.box_button.__class__ = GpuImg_driver_true
            return

        fc = self.r_fcurve()
        if fc:
            kp = fc.keyframe_points
            ind_E = len(kp) -1
            r = bpy.context.scene.frame_current
            if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                if round(fc.evaluate(r)) == int(self.button0.get()):
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_odd
            else:
                if round(fc.evaluate(r)) == int(self.button0.get()):
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_odd
            return

        if self.button1.box_button.__class__ != GpuImg_keyframe_false:
            self.button1.box_button.__class__ = GpuImg_keyframe_false
        #|
    def upd_button_keyframe_VAL(self):
        dr = self.r_driver()
        if dr:
            if self.button1.box_button.__class__ != GpuImg_driver_true:
                self.button1.box_button.__class__ = GpuImg_driver_true
            return

        fc = self.r_fcurve()
        if fc:
            kp = fc.keyframe_points
            ind_E = len(kp) -1
            r = bpy.context.scene.frame_current
            if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                if fc.evaluate(r) == self.button0.get():
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_odd
            else:
                if fc.evaluate(r) == self.button0.get():
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_odd
            return

        if self.button1.box_button.__class__ != GpuImg_keyframe_false:
            self.button1.box_button.__class__ = GpuImg_keyframe_false
        #|
    def upd_button_keyframe_ENUM(self):
        dr = self.r_driver()
        if dr:
            if self.button1.box_button.__class__ != GpuImg_driver_true:
                self.button1.box_button.__class__ = GpuImg_driver_true
            return

        fc = self.r_fcurve()
        if fc:
            kp = fc.keyframe_points
            ind_E = len(kp) -1
            r = bpy.context.scene.frame_current
            if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                v = getattr(self.button0.pp, self.button0.rna.identifier)
                if v in self.enums and self.enums[v].value == round(fc.evaluate(r)):
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_odd
            else:
                v = getattr(self.button0.pp, self.button0.rna.identifier)
                if v in self.enums and self.enums[v].value == round(fc.evaluate(r)):
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_odd
            return

        if self.button1.box_button.__class__ != GpuImg_keyframe_false:
            self.button1.box_button.__class__ = GpuImg_keyframe_false
        #|
    def upd_button_keyframe_ENUM_FLAG(self):
        dr = self.r_driver()
        if dr:
            if self.button1.box_button.__class__ != GpuImg_driver_true:
                self.button1.box_button.__class__ = GpuImg_driver_true
            return

        fc = self.r_fcurve()
        if fc:
            kp = fc.keyframe_points
            ind_E = len(kp) -1
            r = bpy.context.scene.frame_current
            if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                v = getattr(self.button0.pp, self.button0.rna.identifier)
                if v:
                    enums = self.enums
                    if sum(enums[v].value for v in v) == round(fc.evaluate(r)):
                        if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_even:
                            self.button1.box_button.__class__ = GpuImg_keyframe_next_false_even
                    else:
                        if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                            self.button1.box_button.__class__ = GpuImg_keyframe_next_false_odd
                else:
                    if 0 == round(fc.evaluate(r)):
                        if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_even:
                            self.button1.box_button.__class__ = GpuImg_keyframe_next_false_even
                    else:
                        if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                            self.button1.box_button.__class__ = GpuImg_keyframe_next_false_odd
            else:
                v = getattr(self.button0.pp, self.button0.rna.identifier)
                if v:
                    enums = self.enums
                    if sum(enums[v].value for v in v) == round(fc.evaluate(r)):
                        if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_even:
                            self.button1.box_button.__class__ = GpuImg_keyframe_current_true_even
                    else:
                        if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                            self.button1.box_button.__class__ = GpuImg_keyframe_current_true_odd
                else:
                    if 0 == round(fc.evaluate(r)):
                        if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_even:
                            self.button1.box_button.__class__ = GpuImg_keyframe_current_true_even
                    else:
                        if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                            self.button1.box_button.__class__ = GpuImg_keyframe_current_true_odd
            return

        if self.button1.box_button.__class__ != GpuImg_keyframe_false:
            self.button1.box_button.__class__ = GpuImg_keyframe_false
        #|

    def upd_button_keyframe_VAL_gn_float(self):
        dr = self.r_driver()
        if dr:
            if self.button1.box_button.__class__ != GpuImg_driver_true:
                self.button1.box_button.__class__ = GpuImg_driver_true
            return

        fc = self.r_fcurve()
        if fc:
            kp = fc.keyframe_points
            ind_E = len(kp) -1
            r = bpy.context.scene.frame_current
            if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                if abs(fc.evaluate(r) - self.button0.get()) <= 0.0000001:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_odd
            else:
                if abs(fc.evaluate(r) - self.button0.get()) <= 0.0000001:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_odd
            return

        if self.button1.box_button.__class__ != GpuImg_keyframe_false:
            self.button1.box_button.__class__ = GpuImg_keyframe_false
        #|

    def upd_data(self):
        self.button0.upd_data()
        self.upd_button_keyframe()
        #|
    #|
    #|
class ButtonGroupAnimBoolVector(        # ButtonGroupAnim                                       
    ButtonGroupAnim):
    __slots__ = ()

    def __init__(self, w, button0, r_fcurve, r_driver, title=None):
        self.w = w
        self.button0 = button0
        button0.w = self
        self.blf_title = BlfClipColor(unclip_text=button0.rna.name  if title is None else title,
            color=COL_block_fg)

        self.button1 = ButtonFnImgHoverKeyframe(self, RNA_button_keyframe, button0.bufn_keyframe)
        self.r_fcurve = r_fcurve
        self.r_driver = r_driver
        #|

    def init_bat(self, LL, RR, TT):
        R2 = RR - SIZE_widget[0]
        R1 = R2 - SIZE_border[3]
        L = R1 - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        B = self.button0.init_bat(L, R1, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        if hasattr(self.button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(self.button0.blf_subtype, "__len__"):
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    max(blfDimen(FONT0, o.text)[0]  for o in self.button0.blf_subtype))
            else:
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    blfDimen(FONT0, self.button0.blf_subtype.text)[0])
        else:
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])

        self.button1.init_bat(R2, RR, TT - SIZE_border[3])
        return B
        #|

    def upd_data(self):
        self.button0.upd_data()

        if any(self.r_driver()):
            if self.button1.box_button.__class__ != GpuImg_driver_true:
                self.button1.box_button.__class__ = GpuImg_driver_true
            return

        fcs = self.r_fcurve()
        if any(fcs):
            r = bpy.context.scene.frame_current
            is_current_true_odd = False
            is_next_false_even = False

            for fc, v in zip(fcs, self.button0.get()):
                if fc is None: continue
                box_button = self.button1.box_button
                kp = fc.keyframe_points
                ind_E = len(kp) -1
                if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                    if round(fc.evaluate(r)) == int(v):
                        is_next_false_even = True
                    else:
                        if box_button.__class__ != GpuImg_keyframe_next_false_odd:
                            box_button.__class__ = GpuImg_keyframe_next_false_odd
                        return
                else:
                    if round(fc.evaluate(r)) == int(v): pass
                    else: is_current_true_odd = True

            if is_next_false_even is True:
                if box_button.__class__ != GpuImg_keyframe_next_false_even:
                    box_button.__class__ = GpuImg_keyframe_next_false_even
            elif is_current_true_odd is True:
                if box_button.__class__ != GpuImg_keyframe_current_true_odd:
                    box_button.__class__ = GpuImg_keyframe_current_true_odd
            else:
                if box_button.__class__ != GpuImg_keyframe_current_true_even:
                    box_button.__class__ = GpuImg_keyframe_current_true_even
        else:
            if self.button1.box_button.__class__ != GpuImg_keyframe_false:
                self.button1.box_button.__class__ = GpuImg_keyframe_false
        #|
    #|
    #|
class ButtonGroupAnimColor(             # ButtonGroupAnim                                       
    ButtonGroupAnim):
    __slots__ = ()

    def upd_data(self):
        self.button0.upd_data()

        dr = self.r_driver()
        fc = self.r_fcurve()

        if any(dr):
            if self.button1.box_button.__class__ != GpuImg_driver_true:
                self.button1.box_button.__class__ = GpuImg_driver_true
            return

        if any(fc):
            r = bpy.context.scene.frame_current
            is_current_keyframe = False
            is_all_match = True

            for fc, v in zip(fc, self.button0.get()):
                if fc:
                    if is_current_keyframe is False:
                        kp = fc.keyframe_points
                        ind_E = len(kp) -1
                        if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) != None:
                            is_current_keyframe = True

                    if is_all_match is True:
                        if abs(fc.evaluate(r) - v) > 0.0000001: is_all_match = False

            if is_current_keyframe is False:
                if is_all_match is True:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_next_false_odd
            else:
                if is_all_match is True:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_even:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_even
                else:
                    if self.button1.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                        self.button1.box_button.__class__ = GpuImg_keyframe_current_true_odd
            return

        if self.button1.box_button.__class__ != GpuImg_keyframe_false:
            self.button1.box_button.__class__ = GpuImg_keyframe_false
        #|
    #|
    #|
class ButtonGroupAnimAlignL(            # ButtonGroupAnim                                       
    ButtonGroupAnim): # no blf_subtype
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        RR -= SIZE_widget[0]
        # L = RR - D_SIZE['widget_width']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>

        if self.button0.rna.type == "BOOLEAN":
            self.evtkill = False
            self.button0.init_bat(LL, LL + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']

            e = self.blf_title
            e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
            x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']

            e.text = r_blf_clipping_end(e.unclip_text, x, RR)
            e.x = x

            R0 = x + round(blfDimen(FONT0, e.text)[0]) + SIZE_border[3]
            self.button1.init_bat(R0, R0 + SIZE_widget[0], TT - SIZE_border[3])
        else:
            e = self.blf_title
            e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
            x = LL + SIZE_border[3]
            e.x = x
            e.text = r_blf_clipping_end(e.unclip_text, x, RR - D_SIZE['widget_width'] - D_SIZE['font_main_title_offset'])

            L = x + round(blfDimen(FONT0, e.text)[0]) + D_SIZE['font_main_title_offset']
            R0 = L + D_SIZE['widget_width']
            B = self.button0.init_bat(L, R0, TT)
            R0 += SIZE_border[3]
            self.button1.init_bat(R0, R0 + SIZE_widget[0], TT - SIZE_border[3])
        return B
        #|
    #|
    #|
class ButtonGroupAnimAlignTitleLeft(    # ButtonGroupAnim                                       
    ButtonGroupAnim): # BOOLEAN only, no blf_subtype
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        R2 = RR - SIZE_widget[0]
        R1 = R2 - SIZE_border[3]
        L = R1 - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        # if self.button0.rna.type == "BOOLEAN":
        self.evtkill = False
        self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
        B = TT - D_SIZE['widget_full_h']
        # else:
        #     B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, x, R1)
        e.x = x

        self.button1.init_bat(R2, RR, TT - SIZE_border[3])
        return B
        #|
    #|
    #|
class ButtonGroupAnimAlignLR(           # ButtonGroupAnim                                       
    ButtonGroupAnim): # BOOLEAN only, no blf_subtype
    __slots__ = 'blf_title_head'

    def __init__(self, w, button0, r_fcurve, r_driver, title=None, title_head=""):
        super().__init__(w, button0, r_fcurve, r_driver, title=title)
        self.blf_title_head = BlfClipColor(unclip_text=title_head, color=COL_block_fg)
        #|

    def init_bat(self, LL, RR, TT):
        R2 = RR - SIZE_widget[0]
        R1 = R2 - SIZE_border[3]
        L = R1 - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        # if self.button0.rna.type == "BOOLEAN":
        self.evtkill = False
        self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
        B = TT - D_SIZE['widget_full_h']
        # else:
        #     B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, x, R1)
        e.x = x

        o = self.blf_title_head
        o.y = e.y
        R0 = L - D_SIZE['font_main_title_offset']
        o.text = r_blf_clipping_end(o.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        o.x = R0 - round(blfDimen(FONT0, o.text)[0])

        self.button1.init_bat(R2, RR, TT - SIZE_border[3])
        return B
        #|

    def dxy(self, dx, dy):
        self.button0.dxy(dx, dy)
        self.button1.dxy(dx, dy)
        self.blf_title.x += dx
        self.blf_title.y += dy
        self.blf_title_head.x += dx
        self.blf_title_head.y += dy
        #|
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        e = self.blf_title_head
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        self.button0.draw_blf()
        self.button1.draw_blf()
        #|
    #|
    #|
class ButtonGroupAnimFull(              # ButtonGroupAnim                                       
    ButtonGroupAnim): # non-BOOLEAN, no blf_subtype
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        h = SIZE_widget[0]
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        x = LL + h
        e.x = x
        e.text = r_blf_clipping_end(e.unclip_text, x, x + D_SIZE['widget_width'])

        L = x + round(blfDimen(FONT0, e.text)[0]) + D_SIZE['font_main_title_offset']
        R0 = RR - h
        B = self.button0.init_bat(L, R0 - SIZE_border[3], TT)
        self.button1.init_bat(R0, RR, TT - SIZE_border[3])
        return B
        #|
    #|
    #|
class ButtonGroupAnimRef(               # ButtonGroupAnim                                       
    ButtonGroupAnim):
    __slots__ = ()

    def __init__(self, w, button0, r_driver, title=None):
        self.w = w
        self.button0 = button0
        button0.w = self
        self.blf_title = BlfClipColor(unclip_text=button0.rna.name  if title is None else title,
            color=COL_block_fg)

        self.button1 = ButtonFnImgHoverKeyframeRef(self, RNA_button_keyframe, button0.bufn_keyframe)
        self.r_driver = r_driver
        #|

    def is_dark(self):
        return self.button0.is_dark()
        #|
    def dark(self):
        self.button0.dark()
        self.blf_title.color = COL_block_fg_ignore
        #|
    def light(self):
        self.button0.light()
        self.blf_title.color = COL_block_fg
        #|

    def upd_data(self):
        self.button0.upd_data()

        dr = self.r_driver()
        if dr:
            if self.button1.box_button.__class__ != GpuImg_driver_ref:
                self.button1.box_button.__class__ = GpuImg_driver_ref
            return

        if self.button1.box_button.__class__ != GpuImgNull:
            self.button1.box_button.__class__ = GpuImgNull
        #|
    #|
    #|
class ButtonGroupAnimRefAlignL(         # ButtonGroupAnimRef                                    
    ButtonGroupAnimRef): # no blf_subtype
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        RR -= SIZE_widget[0]
        # L = RR - D_SIZE['widget_width']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>

        if self.button0.rna.type == "BOOLEAN":
            self.evtkill = False
            self.button0.init_bat(LL, LL + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']

            e = self.blf_title
            e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
            x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']

            e.text = r_blf_clipping_end(e.unclip_text, x, RR)
            e.x = x

            R0 = x + round(blfDimen(FONT0, e.text)[0]) + SIZE_border[3]
            self.button1.init_bat(R0, R0 + SIZE_widget[0], TT - SIZE_border[3])
        else:
            e = self.blf_title
            e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
            x = LL + SIZE_border[3]
            e.x = x
            e.text = r_blf_clipping_end(e.unclip_text, x, RR - D_SIZE['widget_width'] - D_SIZE['font_main_title_offset'])

            L = x + round(blfDimen(FONT0, e.text)[0]) + D_SIZE['font_main_title_offset']
            R0 = L + D_SIZE['widget_width']
            B = self.button0.init_bat(L, R0, TT)
            R0 += SIZE_border[3]
            self.button1.init_bat(R0, R0 + SIZE_widget[0], TT - SIZE_border[3])
        return B
        #|
    #|
    #|
class ButtonGroupAnimRefAlignTitleLeft( # ButtonGroupAnimRef                                    
    ButtonGroupAnimRef): # BOOLEAN only, no blf_subtype
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        R2 = RR - SIZE_widget[0]
        R1 = R2 - SIZE_border[3]
        L = R1 - D_SIZE['widget_width']

        # if self.button0.rna.type == "BOOLEAN":
        self.evtkill = False
        self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
        B = TT - D_SIZE['widget_full_h']
        # else:
        #     B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, x, R1)
        e.x = x

        self.button1.init_bat(R2, RR, TT - SIZE_border[3])
        return B
        #|
    #|
    #|
class ButtonGroupAnimRefAlignLR(        # ButtonGroupAnimRef                                    
    ButtonGroupAnimRef): # BOOLEAN only, no blf_subtype
    __slots__ = 'blf_title_head'

    def __init__(self, w, button0, r_driver, title=None, title_head=""):
        super().__init__(w, button0, r_driver, title=title)
        self.blf_title_head = BlfClipColor(unclip_text=title_head, color=COL_block_fg)
        #|

    def init_bat(self, LL, RR, TT):
        R2 = RR - SIZE_widget[0]
        R1 = R2 - SIZE_border[3]
        L = R1 - D_SIZE['widget_width']

        # if self.button0.rna.type == "BOOLEAN":
        self.evtkill = False
        self.button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
        B = TT - D_SIZE['widget_full_h']
        # else:
        #     B = self.button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, x, R1)
        e.x = x

        o = self.blf_title_head
        o.y = e.y
        R0 = L - D_SIZE['font_main_title_offset']
        o.text = r_blf_clipping_end(o.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        o.x = R0 - round(blfDimen(FONT0, o.text)[0])

        self.button1.init_bat(R2, RR, TT - SIZE_border[3])
        return B
        #|

    def dxy(self, dx, dy):
        self.button0.dxy(dx, dy)
        self.button1.dxy(dx, dy)
        self.blf_title.x += dx
        self.blf_title.y += dy
        self.blf_title_head.x += dx
        self.blf_title_head.y += dy
        #|
    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        e = self.blf_title_head
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)

        self.button0.draw_blf()
        self.button1.draw_blf()
        #|
    #|
    #|
class ButtonGroupAnimRefFull(           # ButtonGroupAnimRef                                    
    ButtonGroupAnimRef): # no blf_subtype
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        widget_rim = SIZE_border[3]
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>

        e = self.blf_title
        e.y = TT - widget_rim - D_SIZE['font_main_dT']
        x = LL + widget_rim
        e.x = x
        e.text = r_blf_clipping_end(e.unclip_text, x, x + D_SIZE['widget_width'])

        L = x + round(blfDimen(FONT0, e.text)[0]) + D_SIZE['font_main_title_offset']
        R0 = RR - SIZE_widget[0]
        B = self.button0.init_bat(L, R0 - widget_rim, TT)
        self.button1.init_bat(R0, RR, TT - widget_rim)
        return B
        #|
    #|
    #|
class ButtonGroupAnimVector(            # ButtonGroupY                                          
    ButtonGroupY):
    __slots__ = 'upd_button_keyframe', 'r_fcurve', 'r_driver', 'enums', 'blf_title'

    def __init__(self, w, button0, r_fcurve, r_driver, title=None):
        self.w = w
        button0.w = self
        self.blf_title = BlfClipColor(unclip_text=button0.rna.name  if title is None else title,
            color=COL_block_fg)

        self.buttons = [ButtonFnImgHoverKeyframe(self, RNA_button_keyframe, self.r_bufn_keyframe(r))
            for r in range(len(button0.blf_value))] + [button0]

        self.r_fcurve = r_fcurve
        self.r_driver = r_driver

        self.upd_button_keyframe = self.upd_button_keyframe_VAL
        #|

    def init_bat(self, LL, RR, TT):
        h = SIZE_widget[0]
        widget_rim = SIZE_border[3]
        RR -= h + widget_rim
        L = RR - D_SIZE['widget_width']
        button0 = self.buttons[-1]

        if button0.rna.type == "BOOLEAN":
            TODO
            self.evtkill = False
            button0.init_bat(L, L + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
            B = TT - D_SIZE['widget_full_h']
        else:
            B = button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - widget_rim - D_SIZE['font_main_dT']
        if hasattr(button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(button0.blf_subtype, "__len__"):
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    max(blfDimen(FONT0, o.text)[0]  for o in button0.blf_subtype))
            else:
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    blfDimen(FONT0, button0.blf_subtype.text)[0])
        else:
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])

        L0 = button0.box_button.R + widget_rim
        R0 = L0 + h
        TT -= widget_rim
        for e in self.buttons[ : -1]:
            e.init_bat(L0, R0, TT)
            TT -= h
        return B
        #|
    def r_height(self, width): return self.buttons[-1].r_height(width)
    def r_bufn_keyframe(self, index):
        def bufn_keyframe_index():
            self.buttons[-1].bufn_keyframe(index)
        return bufn_keyframe_index
        #|

    def is_dark(self):
        return self.buttons[-1].is_dark()
        #|
    def dark(self):
        self.buttons[-1].dark()
        self.blf_title.color = COL_block_fg_ignore
        #|
    def light(self):
        self.buttons[-1].light()
        self.blf_title.color = COL_block_fg
        #|

    def upd_button_keyframe_VAL(self):
        for button, dr, fc, v in zip(self.buttons[ : -1], self.r_driver(), self.r_fcurve(), self.buttons[-1].get()):
            if dr:
                if button.box_button.__class__ != GpuImg_driver_true:
                    button.box_button.__class__ = GpuImg_driver_true
                continue

            if fc:
                r = bpy.context.scene.frame_current
                kp = fc.keyframe_points
                ind_E = len(kp) -1
                if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                    if fc.evaluate(r) == v:
                        if button.box_button.__class__ != GpuImg_keyframe_next_false_even:
                            button.box_button.__class__ = GpuImg_keyframe_next_false_even
                    else:
                        if button.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                            button.box_button.__class__ = GpuImg_keyframe_next_false_odd
                else:
                    if fc.evaluate(r) == v:
                        if button.box_button.__class__ != GpuImg_keyframe_current_true_even:
                            button.box_button.__class__ = GpuImg_keyframe_current_true_even
                    else:
                        if button.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                            button.box_button.__class__ = GpuImg_keyframe_current_true_odd
                continue

            if button.box_button.__class__ != GpuImg_keyframe_false:
                button.box_button.__class__ = GpuImg_keyframe_false
        #|

    def dxy(self, dx, dy):
        for e in self.buttons: e.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy
        #|

    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        for e in self.buttons: e.draw_blf()
        #|

    def upd_data(self):
        self.buttons[-1].upd_data()
        self.upd_button_keyframe()
        #|
    #|
    #|
class ButtonGroupAnimFn(                # ButtonGroup                                           
    ButtonGroup): # Custom Button only, no blf_subtype
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        R2 = RR - SIZE_widget[0]
        R1 = R2 - SIZE_border[3]
        L = R1 - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        B = self.button0.init_bat(L, R1, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])
        return B
        #|

    def is_dark(self):
        return self.button0.is_dark()
        #|
    def dark(self):
        self.button0.dark()
        self.blf_title.color = COL_block_fg_ignore
        #|
    def light(self):
        self.button0.light()
        self.blf_title.color = COL_block_fg
        #|

    def upd_data(self): pass
    #|
    #|
class ButtonGroupAnimBoolArray(         # ButtonGroupY                                          
    ButtonGroupY):
    __slots__ = 'r_fcurve', 'r_driver', 'blf_title', 'full_size'

    def __init__(self, w, rna, pp, r_fcurve, r_driver, title="", button_text=None):
        self.w = w
        button0 = ButtonBoolArrayXPush(self, rna, pp, title=button_text)
        self.buttons = [ButtonFnImgHoverKeyframe(self, RNA_button_keyframe, self.r_bufn_keyframe(r))
            for r in range(len(rna))] + [button0]

        self.blf_title = BlfClipColor(unclip_text=title, color=COL_block_fg)

        self.r_fcurve = r_fcurve
        self.r_driver = r_driver
        #|

    def init_bat(self, LL, RR, TT):
        LL += D_SIZE['font_main_dx']
        h = SIZE_widget[0]
        widget_rim = SIZE_border[3]
        RR -= h + widget_rim
        if hasattr(self, "full_size"):
            L = LL
        else:
            L = RR - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])
        button0 = self.buttons[-1]

        R1 = RR - h * (len(self.buttons) - 2)
        B = button0.init_bat(L, R1, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL, R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])

        L0 = R1 + widget_rim
        R0 = L0 + h
        TT -= SIZE_border[3]
        for e in self.buttons[ : -1]:
            e.init_bat(L0, R0, TT)
            L0 += h
            R0 += h
        return B
        #|
    def r_height(self, width): return self.buttons[-1].r_height(width)
    def r_bufn_keyframe(self, index):
        def bufn_keyframe_index():
            self.buttons[-1].bufn_keyframe(index)
        return bufn_keyframe_index
        #|

    def is_dark(self):
        return self.buttons[-1].is_dark()
        #|
    def dark(self):
        self.buttons[-1].dark()
        self.blf_title.color = COL_block_fg_ignore
        #|
    def light(self):
        self.buttons[-1].light()
        self.blf_title.color = COL_block_fg
        #|
    def dark_title(self): self.blf_title.color = COL_block_fg_ignore
    def light_title(self): self.blf_title.color = COL_block_fg

    def dxy(self, dx, dy):
        for e in self.buttons: e.dxy(dx, dy)

        self.blf_title.x += dx
        self.blf_title.y += dy
        #|

    def draw_blf(self):
        e = self.blf_title
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        for e in self.buttons: e.draw_blf()
        #|

    def upd_data(self):
        e = self.buttons[-1]
        e.upd_data()
        pp = e.pp
        for button, fc, dr, rna in zip(self.buttons, self.r_fcurve(), self.r_driver(), e.rna):
            upd_button_keyframe_BOOLEAN(button, fc, dr, getattr(pp, rna.identifier))
        #|
    #|
    #|
class ButtonGroupAnimBoolXYZ(           # ButtonGroupAnimBoolArray                              
    ButtonGroupAnimBoolArray):
    __slots__ = ()

    def __init__(self, w, button0, r_fcurve, r_driver, title=None):
        self.w = w
        button0.w = self
        self.blf_title = BlfClipColor(unclip_text=button0.rna.name  if title is None else title,
            color=COL_block_fg)

        self.buttons = [ButtonFnImgHoverKeyframe(self, RNA_button_keyframe, self.r_bufn_keyframe(r))
            for r in range(len(button0.blf_value))] + [button0]

        self.r_fcurve = r_fcurve
        self.r_driver = r_driver
        #|

    def upd_data(self):
        button0 = self.buttons[-1]
        button0.upd_data()

        for e, fc, dr, v in zip(self.buttons[ : -1], self.r_fcurve(), self.r_driver(), getattr(button0.pp, button0.rna.identifier)):
            upd_button_keyframe_BOOLEAN(e, fc, dr, v)
        #|
    #|
    #|
class ButtonGroupAnimBoolAlignR(        # ButtonGroupAnim                                       
    ButtonGroupAnim):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        h = SIZE_widget[0]
        widget_rim = SIZE_border[3]
        L0 = RR - h
        # L = RR - D_SIZE['widget_width']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>

        self.evtkill = False
        self.button0.init_bat(L0, L0 + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
        B = TT - D_SIZE['widget_full_h']

        L0 -= h + widget_rim
        self.button1.init_bat(L0, L0 + h, TT - widget_rim)
        L0 -= widget_rim

        e = self.blf_title
        e.y = TT - widget_rim - D_SIZE['font_main_dT']

        e.text = r_blf_clipping_end(e.unclip_text, LL, L0)
        e.x = L0 - round(blfDimen(FONT0, e.text)[0])
        return B
        #|
    #|
    #|

def upd_button_keyframe_BOOLEAN(button, fc, dr, v):
    if dr:
        if button.box_button.__class__ != GpuImg_driver_true:
            button.box_button.__class__ = GpuImg_driver_true
        return

    if fc:
        kp = fc.keyframe_points
        ind_E = len(kp) -1
        r = bpy.context.scene.frame_current
        if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
            if round(fc.evaluate(r)) == int(v):
                if button.box_button.__class__ != GpuImg_keyframe_next_false_even:
                    button.box_button.__class__ = GpuImg_keyframe_next_false_even
            else:
                if button.box_button.__class__ != GpuImg_keyframe_next_false_odd:
                    button.box_button.__class__ = GpuImg_keyframe_next_false_odd
        else:
            if round(fc.evaluate(r)) == int(v):
                if button.box_button.__class__ != GpuImg_keyframe_current_true_even:
                    button.box_button.__class__ = GpuImg_keyframe_current_true_even
            else:
                if button.box_button.__class__ != GpuImg_keyframe_current_true_odd:
                    button.box_button.__class__ = GpuImg_keyframe_current_true_odd
        return

    if button.box_button.__class__ != GpuImg_keyframe_false:
        button.box_button.__class__ = GpuImg_keyframe_false
    #|

class BlockActiveObjectSync:
    __slots__ = (
        'w',
        'items',
        'button0',
        'button1',
        'blf_text',
        'box_block',
        'focus_element',
        'active_object_name',
        'r_object_name',
        'r_object',
        'r_is_sync',
        'set_active_object',
        'set_sync')

    def __init__(self, w, r_object_name, r_object, r_is_sync, set_active_object, set_sync):
        self.w = w
        self.box_block = GpuBox_block()
        self.button0 = ButtonFnImgHover(self, RNA_active_object, self.bufn_object, "GpuImg_OBJECT_DATA")
        self.button1 = ButtonFnImgHover(self, RNA_active_object_sync, self.bufn_object_sync,
            "GpuImg_pin", "GpuImg_unpin")
        self.blf_text = BlfClipColor(color=COL_block_fg)
        self.active_object_name = ""
        self.r_object_name = r_object_name
        self.r_object = r_object
        self.r_is_sync = r_is_sync
        self.set_active_object = set_active_object
        self.set_sync = set_sync
        #|

    def init_bat(self, L, R, T):
        R0 = L + SIZE_widget[0]
        B = self.button0.init_bat(L, R0, T)
        x = R0 + D_SIZE['font_main_dx']
        L0 = R - SIZE_widget[0]
        self.button1.init_bat(L0, R, T)
        self.blf_text.x = x
        self.blf_text.y = B + D_SIZE['font_main_dy']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        self.blf_text.text = r_blf_clipping_end(
            self.blf_text.text, x, L0 - D_SIZE['font_main_dx'])
        self.box_block.LRBT(L, R, B, T)
        return B
        #|
    def r_height(self, width): return SIZE_widget[0]

    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        self.button0.outside_evt()
        self.button1.outside_evt()
        #|

    def modal(self):
        if self.button0.inside(MOUSE): e = self.button0
        elif self.button1.inside(MOUSE): e = self.button1
        else: e = None

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['rename']():
            self.evt_rename()
            return True
        return False
        #|

    def to_modal_rm(self):

        items = [
            ("rename", self.evt_rename),
        ]
        DropDownRMKeymap(self, MOUSE, items)
        #|

    def bufn_object(self):

        def write_text(tx, best_item, use_text_output):
            if use_text_output or best_item == None:
                # <<< 1copy (bl_objects_find,, ${'_i_':'i', '_name_':'str(tx)'}$)
                i = bpy.context.view_layer.objects.find(str(tx))
                # >>>
                if i == -1: return
                self.set_active_object(object=(
                    # <<< 1copy (bl_objects,, $$)
                    bpy.context.view_layer.objects
                    # >>>
                )[i])
            else:
                self.set_active_object(object=best_item)

        widget_rim = SIZE_border[3]
        L, R, B, T = self.box_block.r_LRBT()
        title_h = SIZE_title[1] + widget_rim
        T += widget_rim - title_h
        B -= widget_rim - title_h
        DropDownEnum(self, (L, R, B, T), "Object", r_all_objects(),
            input_text="", fixed_width=True, write_text=write_text,
            get_icon=geticon_Object, get_info=getinfo_Object)
        #|
    def bufn_object_sync(self):
        Admin.REDRAW()
        kill_evt_except()
        self.set_sync(not self.button1.is_dark())
        #|
    @ catchBug
    def evt_rename(self):

        ob = self.r_object()
        DropDownEnumRename(None, self.box_block.r_LRBT(), ob, ob)
        #|

    def dxy(self, dx, dy):
        self.box_block.dxy(dx, dy)
        self.button0.dxy(dx, dy)
        self.button1.dxy(dx, dy)
        self.blf_text.x += dx
        self.blf_text.y += dy
        #|
    def draw_box(self):
        self.button0.draw_box()
        self.button1.draw_box()
        #|
    def draw_blf(self):
        e = self.blf_text
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        self.button1.dark()  if self.r_is_sync() else self.button1.light()

        if self.active_object_name == self.r_object_name(): return


        self.active_object_name = self.blf_text.unclip_text = self.blf_text.text = self.r_object_name()
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        self.blf_text.text = r_blf_clipping_end(
            self.blf_text.text, self.blf_text.x, self.button1.box_button.L - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class BlockActiveModifierSync:
    __slots__ = (
        'w',
        'items',
        'button0',
        'button1',
        'button2',
        'button3',
        'blf_text',
        'box_block',
        'focus_element',
        'active_modifier_name',
        'r_modifier_name',
        'r_modifier',
        'r_is_sync',
        'set_active_modifier',
        'set_sync')

    def __init__(self, w, r_modifier_name, r_modifier, r_is_sync, set_active_modifier, set_sync):
        self.w = w
        self.box_block = GpuBox_block()
        self.button0 = ButtonFnImgHover(self, RNA_active_modifier, self.bufn_modifier, "GpuImg_MODIFIER")
        self.button1 = ButtonFnImgHover(self, RNA_active_modifier_sync, self.bufn_modifier_sync,
            "GpuImg_pin", "GpuImg_unpin")
        self.button2 = ButtonFnImgHover(self, RNA_remove_modifier, self.bufn_remove, "GpuImg_REMOVE")
        self.button3 = ButtonFnImgHover(self, RNA_new_modifier, self.bufn_new_modifier, "GpuImg_ADD")
        self.blf_text = BlfClipColor(color=COL_block_fg)
        self.active_modifier_name = ""
        self.r_modifier_name = r_modifier_name
        self.r_modifier = r_modifier
        self.r_is_sync = r_is_sync
        self.set_active_modifier = set_active_modifier
        self.set_sync = set_sync
        #|

    def init_bat(self, L, R, T):
        h = SIZE_widget[0]
        R0 = L + h
        B = self.button0.init_bat(L, R0, T)
        x = R0 + D_SIZE['font_main_dx']
        L0 = R - h
        self.button1.init_bat(L0, R, T)
        R1 = L0 - h // 2
        L1 = R1 - h
        self.button2.init_bat(L1, R1, T)
        R1 = L1
        L1 -= h
        self.button3.init_bat(L1, R1, T)

        self.blf_text.x = x
        self.blf_text.y = B + D_SIZE['font_main_dy']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        self.blf_text.text = r_blf_clipping_end(
            self.blf_text.text, x, L1 - D_SIZE['font_main_dx'])
        self.box_block.LRBT(L, R, B, T)
        return B
        #|
    def r_height(self, width): return SIZE_widget[0]

    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        self.button0.outside_evt()
        self.button1.outside_evt()
        self.button2.outside_evt()
        self.button3.outside_evt()
        #|

    def modal(self):
        if self.button0.inside(MOUSE): e = self.button0
        elif self.button1.inside(MOUSE): e = self.button1
        elif self.button2.inside(MOUSE): e = self.button2
        elif self.button3.inside(MOUSE): e = self.button3
        else: e = None

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['rename']():
            self.evt_rename()
            return True
        return False
        #|

    def to_modal_rm(self):

        items = [
            ("rename", self.evt_rename),
        ]
        DropDownRMKeymap(self, MOUSE, items)
        #|

    def bufn_modifier(self):

        oj = self.w.w.active_object
        if not hasattr(oj, "modifiers"): return
        if not oj.modifiers: return

        def write_text(tx, best_item, use_text_output):
            if use_text_output or best_item == None:
                i = oj.modifiers.find(str(tx))
                if i == -1: return
                self.set_active_modifier(object=oj.modifiers[i])
            else:
                self.set_active_modifier(object=best_item)

        widget_rim = SIZE_border[3]
        L, R, B, T = self.box_block.r_LRBT()
        title_h = SIZE_title[1] + widget_rim
        T += widget_rim - title_h
        B -= widget_rim - title_h
        DropDownEnum(self, (L, R, B, T), "Modifier", tuple(oj.modifiers),
            input_text="", fixed_width=True, write_text=write_text,
            get_icon=geticon_Modifier, get_info=None)
        #|
    def bufn_modifier_sync(self):
        Admin.REDRAW()
        kill_evt_except()
        self.set_sync(not self.button1.is_dark())
        #|
    def bufn_new_modifier(self):

        oj = self.w.w.active_object
        if not hasattr(oj, "modifiers"): return

        s = r_library_or_override_message(oj)
        if s:
            report(s)
            return

        box_button = self.button3.box_button
        DropDownNewModifier(self, (box_button.L, box_button.T), oj)
        #|
    def bufn_remove(self, override=None):

        self.w.w.area_mds.evt_del(override=override)
        #|
    @ catchBug
    def evt_rename(self):

        DropDownEnumRename(None, self.box_block.r_LRBT(), self.w.w.active_object, self.r_modifier())
        #|

    def dxy(self, dx, dy):
        self.box_block.dxy(dx, dy)
        self.button0.dxy(dx, dy)
        self.button1.dxy(dx, dy)
        self.button2.dxy(dx, dy)
        self.button3.dxy(dx, dy)
        self.blf_text.x += dx
        self.blf_text.y += dy
        #|
    def draw_box(self):
        self.button0.draw_box()
        self.button1.draw_box()
        self.button2.draw_box()
        self.button3.draw_box()
        #|
    def draw_blf(self):
        e = self.blf_text
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        self.button1.dark()  if self.r_is_sync() else self.button1.light()

        if self.active_modifier_name == self.r_modifier_name(): return


        self.active_modifier_name = self.blf_text.unclip_text = self.blf_text.text = self.r_modifier_name()
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        self.blf_text.text = r_blf_clipping_end(
            self.blf_text.text, self.blf_text.x, self.button3.box_button.L - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class BlockActiveVar:
    __slots__ = (
        'w',
        'items',
        'button0',
        'button1',
        'button2',
        'blf_text',
        'box_block',
        'focus_element',
        'active_var_name',
        'r_var_name',
        'r_var',
        'set_active_var')

    def __init__(self, w, r_var_name, r_var, set_active_var):
        self.w = w
        self.box_block = GpuBox_block()
        self.button0 = ButtonFnImgHover(self, RNA_active_item, self.bufn_var, "GpuImg_VARIABLE")
        self.button1 = ButtonFnImgHover(self, RNA_remove_item, self.bufn_remove, "GpuImg_REMOVE")
        self.button2 = ButtonFnImgHover(self, RNA_new_item, self.bufn_new_var, "GpuImg_ADD")
        self.blf_text = BlfClipColor(color=COL_block_fg)
        self.active_var_name = ""
        self.r_var_name = r_var_name
        self.r_var = r_var
        self.set_active_var = set_active_var
        #|

    def init_bat(self, L, R, T):
        h = SIZE_widget[0]
        R0 = L + h
        B = self.button0.init_bat(L, R0, T)
        x = R0 + D_SIZE['font_main_dx']
        L1 = R - h
        self.button1.init_bat(L1, R, T)
        R1 = L1
        L1 -= h
        self.button2.init_bat(L1, R1, T)

        self.blf_text.x = x
        self.blf_text.y = B + D_SIZE['font_main_dy']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        self.blf_text.text = r_blf_clipping_end(
            self.blf_text.text, x, L1 - D_SIZE['font_main_dx'])
        self.box_block.LRBT(L, R, B, T)
        return B
        #|
    def r_height(self, width): return SIZE_widget[0]

    def inside_evt(self):
        self.focus_element = None
        #|
    def outside_evt(self):
        self.button0.outside_evt()
        self.button1.outside_evt()
        self.button2.outside_evt()
        #|

    def modal(self):
        if self.button0.inside(MOUSE): e = self.button0
        elif self.button1.inside(MOUSE): e = self.button1
        elif self.button2.inside(MOUSE): e = self.button2
        else: e = None

        if e is None:
            if self.focus_element is not None:
                self.focus_element.outside_evt()
                self.focus_element = None
        else:
            if self.focus_element != e:
                if self.focus_element is not None: self.focus_element.outside_evt()
                self.focus_element = e
                e.inside_evt()

            if e.modal(): return True

        if TRIGGER['rm']():
            self.to_modal_rm()
            return True
        if TRIGGER['rename']():
            self.evt_rename()
            return True
        return False
        #|

    def to_modal_rm(self):

        items = [
            ("rename", self.evt_rename),
        ]
        DropDownRMKeymap(self, MOUSE, items)
        #|

    def bufn_var(self):

        w = self.w.w
        props = w.props
        fc = w.bars["driver"].button0.check(props.id)
        if not hasattr(fc, "driver"): return
        dr = fc.driver
        if not hasattr(dr, "variables"): return
        if not dr.variables: return

        def write_text(tx, best_item, use_text_output):
            if use_text_output or best_item == None:
                i = dr.variables.find(str(tx))
                if i == -1: return
                self.set_active_var(object=dr.variables[i])
            else:
                self.set_active_var(object=best_item)

        widget_rim = SIZE_border[3]
        L, R, B, T = self.box_block.r_LRBT()
        title_h = SIZE_title[1] + widget_rim
        T += widget_rim - title_h
        B -= widget_rim - title_h
        DropDownEnum(self, (L, R, B, T), "Variable", tuple(dr.variables),
            input_text="", fixed_width=True, write_text=write_text,
            get_icon=geticon_DriverVar, get_info=None)
        #|
    def bufn_remove(self, override=None):

        self.w.w.area_vars.evt_del(override=override)
        #|
    def bufn_new_var(self):

        w = self.w.w
        props = w.props
        fc = w.bars["driver"].button0.check(props.id)
        if not hasattr(fc, "driver"): return
        dr = fc.driver
        if not hasattr(dr, "variables"): return
        dr.variables.new()
        update_scene_push("VMD add driver variable")
        #|
    @ catchBug
    def evt_rename(self):

        w = self.w.w
        ob = w.active_object
        filt = w.area_vars.filt
        active_index = filt.active_index
        @ catch
        def callback():
            filt.set_active_index(active_index, callback=True)

        DropDownEnumRename(None, self.box_block.r_LRBT(), w.props.id, w.active_var,
            items = ob.variables,
            write_callback = callback)
        #|

    def dxy(self, dx, dy):
        self.box_block.dxy(dx, dy)
        self.button0.dxy(dx, dy)
        self.button1.dxy(dx, dy)
        self.button2.dxy(dx, dy)
        self.blf_text.x += dx
        self.blf_text.y += dy
        #|
    def draw_box(self):
        self.button0.draw_box()
        self.button1.draw_box()
        self.button2.draw_box()
        #|
    def draw_blf(self):
        e = self.blf_text
        blfSize(FONT0, D_SIZE['font_main'])
        blfColor(FONT0, *e.color)
        blfPos(FONT0, e.x, e.y, 0)
        blfDraw(FONT0, e.text)
        #|

    def upd_data(self):
        if self.active_var_name == self.r_var_name(): return


        self.active_var_name = self.blf_text.unclip_text = self.blf_text.text = self.r_var_name()
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        self.blf_text.text = r_blf_clipping_end(
            self.blf_text.text, self.blf_text.x, self.button2.box_button.L - D_SIZE['font_main_dx'])
        #|
    #|
    #|

#_c4#_c4#_c4#_c4
class StructGnGetSet:
    __slots__ = ()

    def get(self):
        return self.pp[f'{self.rna.identifier}']
    def set(self, v, refresh=True, undo_push=True):
        if r_library_editable(self.r_object()) is False: return
        oldvalue = self.get()
        self.pp[f'{self.rna.identifier}'] = v
        if refresh:
            # /* 0block_gn_set_update
            bpy.context.scene.update_tag()
            P.refresh = True
            try: self.r_object().data.update()
            except: pass
            # */
        self.evt_undo_push(undo_push, oldvalue)
        #|
    #|
    #|
class StructGnGetSetVector:
    __slots__ = ()

    def get(self, index=None):
        if index == None: return self.pp[f'{self.rna.identifier}']
        elif isinstance(index, int): return self.pp[f'{self.rna.identifier}'][index]
        else: return self.pp[f'{self.rna.identifier}'][index[0] : index[1]]
        #|
    def set(self, v, index, refresh=True, undo_push=True):
        if r_library_editable(self.r_object()) is False: return
        array = self.pp[f'{self.rna.identifier}']
        oldvalue = [e  for e in array]
        if isinstance(index, int): array[index] = v
        else:
            l = list(array)
            l[index[0] : index[1]] = v
            array[:] = l
        if refresh:
            # <<< 1copy (0block_gn_set_update,, $$)
            bpy.context.scene.update_tag()
            P.refresh = True
            try: self.r_object().data.update()
            except: pass
            # >>>
        self.evt_undo_push(undo_push, oldvalue)
        #|
    #|
    #|
class StructGnRef_evt:
    __slots__ = ()

    def bufn_keyframe(self): pass

    def r_default_value(self): return self.rna.default_value

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()

        items = [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
        ]
        if hasattr(self, "evt_area_preview"): items.append(("dd_preview", self.evt_area_preview))
        override_name = {}

        if ob == None:
            items.insert(0, ("dd_cut", self.evt_area_cut))
            override_name["dd_cut"] = f"Copy Value Path"
        elif hasattr(ob, "name"):
            cls_ob_name = type(ob).__name__
            if cls_ob_name in D_cls_blendData:
                items.insert(0, ("dd_cut", self.evt_area_cut))
                override_name["dd_cut"] = f"Copy {cls_ob_name} Path"

        DropDownRMKeymap(self, MOUSE, items, override_name=override_name, title=self.rna.name)
        #|

    def evt_remove_from_keying_set(self): pass
    def evt_add_to_keying_set(self): pass
    def evt_copy_full_data_path(self):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(True)}["{escape_identifier(self.rna.identifier)}"]'
        report("Full Data Path is copied to the clipboard")
        #|
    def evt_copy_data_path(self):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(False)}["{escape_identifier(self.rna.identifier)}"]'
        report("Data Path is copied to the clipboard")
        #|
    def evt_paste_full_data_path_as_driver(self): pass
    def evt_delete_driver(self): pass
    def evt_add_driver(self, exp="var", replace=False, use_editor=False): pass
    def evt_clear_keyframe(self, evtkill=True): pass
    def evt_delete_keyframe(self, evtkill=True): pass
    def evt_insert_keyframe(self, evtkill=True): pass
    #|
    #|
class StructGn_evt:
    __slots__ = ()

    def bufn_keyframe(self):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=False)
        if pp is None: return

        dr = self.w.r_driver()
        if dr:
            DropDownYesNo(None, MOUSE, self.evt_delete_driver, input_text="Do you want to delete the Driver?")
        else:
            if not hasattr(self.w, "r_fcurve"): return
            fc = self.w.r_fcurve()
            if fc:
                kp = fc.keyframe_points
                ind_E = len(kp) -1
                r = bpy.context.scene.frame_current
                if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) == None:
                    self.evt_insert_keyframe(False)
                else:
                    self.evt_delete_keyframe(False)
            else:
                self.evt_insert_keyframe(False)
        #|

    def r_default_value(self): return self.rna.default_value

    def submodal(self):
        if TRIGGER['ui_remove_from_keying_set_all']():
            self.evt_remove_from_keying_set()
            return True
        if TRIGGER['ui_add_to_keying_set_all']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_remove_from_keying_set']():
            self.evt_remove_from_keying_set()
            return True
        if TRIGGER['ui_add_to_keying_set']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        if TRIGGER['ui_clear_keyframe']():
            self.evt_clear_keyframe()
            return True
        if TRIGGER['ui_delete_keyframe']():
            self.evt_delete_keyframe()
            return True
        if TRIGGER['ui_insert_keyframe']():
            self.evt_insert_keyframe()
            return True
        if TRIGGER['ui_attr_toggle']():
            self.evt_attr_toggle()
            return True
        return False
        #|

    def to_modal_rm(self):

        items = [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_remove_from_keying_set", self.evt_remove_from_keying_set),
            ("ui_add_to_keying_set", self.evt_add_to_keying_set),
            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            ("ui_delete_driver", self.evt_delete_driver),
            ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            ("ui_clear_keyframe", self.evt_clear_keyframe),
            ("ui_delete_keyframe", self.evt_delete_keyframe),
            ("ui_insert_keyframe", self.evt_insert_keyframe),
            ("ui_attr_toggle", self.evt_attr_toggle),
        ]
        if hasattr(self.rna, "subtype") and self.rna.subtype == "ANGLE":
            items.append(("ui_format_toggle", self.evt_area_format))
        override_name = None

        DropDownRMKeymap(self, MOUSE, items, override_name=override_name, title=self.rna.name)
        #|

    def evt_remove_from_keying_set(self):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        success, s = r_remove_from_keying_set(ob, f'{self.r_datapath_head()}["{escape_identifier(self.rna.identifier)}"]')
        if s:
            DropDownOk(None, MOUSE, input_text=s)
        #|
    def evt_add_to_keying_set(self):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        success, s = r_add_to_keying_set(ob, f'{self.r_datapath_head()}["{escape_identifier(self.rna.identifier)}"]')
        if s:
            DropDownOk(None, MOUSE, input_text=s)
        #|
    def evt_copy_full_data_path(self):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(True)}["{escape_identifier(self.rna.identifier)}"]'
        report("Full Data Path is copied to the clipboard")
        #|
    def evt_copy_data_path(self):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(False)}["{escape_identifier(self.rna.identifier)}"]'
        report("Data Path is copied to the clipboard")
        #|
    def evt_paste_full_data_path_as_driver(self):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if hasattr(self.w, "r_fcurve"):
            if self.w.r_fcurve():
                report("Unable to add driver when keyframe already exists")
                return

        success, ex = paste_full_data_path_as_driver_safe(
            bpy.context.window_manager.clipboard,
            self.w.r_driver(),
            self.r_datapath_head(),
            ob,
            self.rna,
            pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to add Driver.\n{ex}')
        #|
    def evt_delete_driver(self):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        dr = self.w.r_driver()
        if dr: ob.animation_data.drivers.remove(dr)
        else:
            report("Driver not found")
            return

        update_scene_push("VMD Delete Driver")
        #|
    def evt_add_driver(self, exp="var", replace=False, use_editor=False):

        pp, ob = C_evt_head(self, poll_library=True)
        if pp is None: return

        if hasattr(self.w, "r_fcurve"):
            if self.w.r_fcurve():
                report("Unable to add driver when keyframe already exists")
                return
        if self.w.r_driver():
            if not replace:
                if use_editor:
                    open_driver_editor_from(ob, f'{self.r_datapath_head(False)}["{escape_identifier(self.rna.identifier)}"]')
                return

            ob.animation_data.drivers.remove(self.w.r_driver())

        success, ex = add_new_driver(ob, self.rna, pp, exp=exp)

        if success is False:
            DropDownOk(None, MOUSE, input_text=f'Failed to add Driver.\n{ex}')
        elif use_editor and P.is_open_driver_editor:
            open_driver_editor_from(ob, f'{self.r_datapath_head(False)}["{escape_identifier(self.rna.identifier)}"]')
        #|
    def evt_clear_keyframe(self, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if not hasattr(self.w, "r_fcurve"): return
        fc = self.w.r_fcurve()
        if not fc:
            report("Keyframe not found")
            return

        success, ex = clear_keyframe(ob, fc)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to Clear Keyframe.\n{ex}')
        #|
    def evt_delete_keyframe(self, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if not hasattr(self.w, "r_fcurve"): return
        if not self.w.r_fcurve():
            report("Keyframe not found")
            return

        success, ex = del_keyframe(ob, self.rna, pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to Delete Keyframe.\n{ex}')
        #|
    def evt_insert_keyframe(self, evtkill=True):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=evtkill)
        if pp is None: return

        if self.w.r_driver():
            report("Unable to Insert Keyframe when Driver already exists")
            return

        success, ex = add_new_keyframe(ob, self.rna, pp)

        if success is False: DropDownOk(None, MOUSE, input_text=f'Failed to add Keyframe.\n{ex}')
        #|

    def evt_attr_toggle(self):

        kill_evt_except()
        try:
            with bpy.context.temp_override(object=self.r_object()):
                bpy.ops.object.geometry_nodes_input_attribute_toggle(
                    input_name=f'{self.rna.identifier}', modifier_name=self.r_pp().name)
            update_scene_push("VMD Input Attribute Toggle")
        except: pass
        #|

    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "poll") and self.poll(self) == False: return
        if r_library_editable(self.r_object()) is False: return
        if isinstance(v, str) and v[: 1] == "#":
            self.evt_add_driver(exp=v[1 :], replace=True)
        else:
            super().set(v, refresh=refresh, undo_push=undo_push)
        #|
    #|
    #|
@ evtVectorAnim
class StructGnVector_evt:
    __slots__ = ()

    def r_default_value(self): return self.rna.default_value

    def submodal(self):
        if TRIGGER['ui_remove_from_keying_set_all']():
            self.evt_remove_from_keying_set(index="all")
            return True
        if TRIGGER['ui_add_to_keying_set_all']():
            self.evt_add_to_keying_set(index="all")
            return True
        if TRIGGER['ui_remove_from_keying_set']():
            self.evt_remove_from_keying_set()
            return True
        if TRIGGER['ui_add_to_keying_set']():
            self.evt_add_to_keying_set()
            return True
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_paste_full_data_path_as_driver']():
            self.evt_paste_full_data_path_as_driver()
            return True
        if TRIGGER['ui_delete_driver']():
            self.evt_delete_driver()
            return True
        if TRIGGER['ui_add_driver']():
            self.evt_add_driver(use_editor=True)
            return True
        if TRIGGER['ui_clear_keyframe']():
            self.evt_clear_keyframe()
            return True
        if TRIGGER['ui_delete_keyframe']():
            self.evt_delete_keyframe()
            return True
        if TRIGGER['ui_insert_keyframe']():
            self.evt_insert_keyframe()
            return True
        if TRIGGER['ui_attr_toggle']():
            self.evt_attr_toggle()
            return True
        return False
        #|

    def to_modal_rm(self):

        items = [
            ("dd_cut", self.evt_area_cut),
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_all", self.evt_area_reset_all),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_remove_from_keying_set_all", lambda: self.evt_remove_from_keying_set(index="all")),
            ("ui_add_to_keying_set_all", lambda: self.evt_add_to_keying_set(index="all")),
            ("ui_remove_from_keying_set", self.evt_remove_from_keying_set),
            ("ui_add_to_keying_set", self.evt_add_to_keying_set),
            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
            ("ui_paste_full_data_path_as_driver", self.evt_paste_full_data_path_as_driver),
            ("ui_delete_driver", self.evt_delete_driver),
            ("ui_add_driver", lambda: self.evt_add_driver(use_editor=True)),
            ("ui_clear_keyframe", self.evt_clear_keyframe),
            ("ui_delete_keyframe", self.evt_delete_keyframe),
            ("ui_insert_keyframe", self.evt_insert_keyframe),
            ("ui_attr_toggle", self.evt_attr_toggle),
        ]
        if hasattr(self, "unit") and self.unit == "ROTATION": items.append(
            ("ui_format_toggle", self.evt_area_format)
        )

        DropDownRMKeymap(self, MOUSE, items, override_name={
            "dd_cut": "Copy Array",
            "dd_paste": "Paste",
            "dd_copy": "Copy",
        }, title=self.rna.name)
        #|

    def evt_attr_toggle(self):

        kill_evt_except()
        try:
            with bpy.context.temp_override(object=self.r_object()):
                bpy.ops.object.geometry_nodes_input_attribute_toggle(
                    input_name=f'{self.rna.identifier}', modifier_name=self.r_pp().name)
            update_scene_push("VMD Input Attribute Toggle")
        except: pass
        #|

    def set(self, v, index, refresh=True, undo_push=True):
        if hasattr(self, "poll") and self.poll(self) == False: return
        if r_library_editable(self.r_object()) is False: return
        if isinstance(index, int):
            if isinstance(v, str) and v[: 1] == "#":
                self.evt_add_driver(index=index, exp=v[1 :], replace=True)
                return
        else:
            if isinstance(v[0], str) and v[0][: 1] == "#":
                i = index[0]
                for v in v:
                    self.evt_add_driver(index=i, exp=v[1 :], replace=True)
                    i += 1
                return
        super().set(v, index, refresh=refresh, undo_push=undo_push)
        #|
    #|
    #|
StructGnVector_evt.r_dp = C_r_dp_gn
StructGnVector_evt.evt_area_format = C_evt_area_format_gn

class GnString(         # StructGnRef_evt       StructGnGetSet          ButtonStringPush                    
    StructGnRef_evt,
    StructGnGetSet,
    ButtonStringPush):
    __slots__ = ()

    def __init__(self, w, rna, pp):
        self.w = w
        self.rna = rna
        if type(pp) is tuple:
            self.r_pp, self.r_object, self.r_datapath_head = pp
            self.pp = self.r_pp()
        else:
            self.pp = pp

        self.box_button = GpuRim(COL_box_text, COL_box_text_rim)
        v = self.get()
        self.blf_value = BlfClipColor(v, v, 0, 0, COL_box_text_fg)
        self.font_id = FONT0

        self.draw_blf = self.i_draw_blf
        self.dxy = self.i_dxy
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: v = self.pp[f'{self.rna.identifier}']
        except: return
        if self.blf_value.unclip_text == v: return


        blf_value = self.blf_value
        blf_value.unclip_text = v
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class GnStringAttrName( # GnString                                                              
    GnString):
    __slots__ = ()

    def r_default_value(self): return self.rna.default_attribute_name

    def submodal(self):
        if TRIGGER['ui_copy_full_data_path']():
            self.evt_copy_full_data_path()
            return True
        if TRIGGER['ui_copy_data_path']():
            self.evt_copy_data_path()
            return True
        if TRIGGER['ui_attr_toggle']():
            self.evt_attr_toggle()
            return True
        return False
        #|

    def to_modal_rm(self):

        ob = self.get()
        items = [
            ("dd_paste", self.evt_area_paste),
            ("dd_copy", self.evt_area_copy),
            ("valbox_reset_single", self.evt_area_reset_single),
            ("detail", self.evt_area_detail),

            ("ui_copy_full_data_path", self.evt_copy_full_data_path),
            ("ui_copy_data_path", self.evt_copy_data_path),
        ]
        if self.rna.in_out == "INPUT":
            items.append(("ui_attr_toggle", self.evt_attr_toggle))

        DropDownRMKeymap(self, MOUSE, items, title=self.rna.name)
        #|

    def evt_copy_full_data_path(self):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(True)}["{escape_identifier(self.rna.identifier)}_attribute_name"]'
        report("Full Data Path is copied to the clipboard")
        #|
    def evt_copy_data_path(self):

        pp, ob = C_evt_head(self, poll_library=False)
        if pp is None: return

        bpy.context.window_manager.clipboard = f'{self.r_datapath_head(False)}["{escape_identifier(self.rna.identifier)}_attribute_name"]'
        report("Data Path is copied to the clipboard")
        #|

    def evt_attr_toggle(self):

        kill_evt_except()
        try:
            with bpy.context.temp_override(object=self.r_object()):
                bpy.ops.object.geometry_nodes_input_attribute_toggle(
                    input_name=f'{self.rna.identifier}', modifier_name=self.r_pp().name)
            update_scene_push("VMD Input Attribute Toggle")
        except: pass
        #|

    def get(self):
        return self.pp[f'{self.rna.identifier}_attribute_name']
    def set(self, v, refresh=True, undo_push=True):
        if r_library_editable(self.r_object()) is False: return
        oldvalue = self.get()
        self.pp[f'{self.rna.identifier}_attribute_name'] = v
        if refresh:
            update_scene()
            try: self.r_object().data.update()
            except: pass

        self.evt_undo_push(undo_push, oldvalue)
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: v = self.pp[f'{self.rna.identifier}_attribute_name']
        except: return
        if self.blf_value.unclip_text == v: return


        blf_value = self.blf_value
        blf_value.unclip_text = v
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'])
        #|
    #|
    #|
class GnBool(           # StructGn_evt          StructGnGetSet          ButtonBoolPush                      
    StructGn_evt,
    StructGnGetSet,
    ButtonBoolPush):
    __slots__ = ()

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: v = self.pp[f'{self.rna.identifier}']
        except: return
        self.box_button.value = v
        #|
    #|
    #|
class GnVector(         # StructGnVector_evt    StructGnGetSetVector    ButtonFloatVectorPush   
    StructGnVector_evt,
    StructGnGetSetVector,
    ButtonFloatVectorPush):
    __slots__ = 'step', 'unit'

    def __init__(self, w, rna, pp, step=1.0):
        self.w = w
        self.rna = rna
        self.step = step
        subtype = rna.subtype
        self.unit = D_gn_subtype_unit[subtype]

        self.r_pp, self.r_object, self.r_datapath_head = pp
        self.pp = self.r_pp()

        self.box_button = GpuRim(COL_box_val, COL_box_val_rim)
        self.box_active = GpuBox(COL_box_val_fo)

        if self.unit == "ROTATION" and hasattr(rna, "vmd_is_radian"):
            if rna.vmd_is_radian:
                self.text_format = UnitSystem.format_float
            else:
                self.text_format = UnitSystem.rs_format_deg
        else:
            self.text_format = D_format[self.unit]

        vv = self.get()
        self.array_length = len(vv)
        self.blf_value = [BlfClip(self.text_format(v), v)  for v in vv]
        self.blf_value[0].color = COL_box_val_fg

        if subtype in D_subtype_display:
            self.draw_blf = self.i_draw_blf_subtype
            self.dxy = self.i_dxy_subtype
            self.blf_subtype = [Blf(tx)  for _, tx in zip(vv, D_subtype_display[subtype])]
            self.blf_subtype[0].color = COL_box_button_fg_info
        else:
            self.draw_blf = self.i_draw_blf
            self.dxy = self.i_dxy

        self.draw_box = self.i_draw_box
        self.active_index = None
        #|

    def init_bat(self, L, R, T):
        widget_rim = SIZE_border[3]
        h = SIZE_widget[0]
        x = L + widget_rim
        y = T - widget_rim - D_SIZE['font_main_dT']
        for e in self.blf_value:
            e.x = x
            e.y = y
            y -= h

        B = T - D_SIZE['widget_full_h'] - (self.array_length - 1) * h
        self.box_button.LRBT_upd(L, R, B, T, widget_rim)

        if hasattr(self, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            y = self.box_button.inner[3] - D_SIZE['font_label_dT']
            for e in self.blf_subtype:
                e.y = y
                y -= h
                e.x = L - D_SIZE['font_label_dx'] - ceil(blfDimen(FONT0, e.text)[0])
        return B
        #|
    def r_height(self, width): return D_SIZE['widget_full_h'] + (self.array_length - 1) * SIZE_widget[0]
    def r_default_array(self): return self.rna.default_value

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: v = self.pp[f'{self.rna.identifier}']
        except: return

        for e, o in zip(self.blf_value, v):
            if e.unclip_text == o: continue
            e.unclip_text = o
            e.text = self.text_format(o)
        #|
    #|
    #|
class GnInt(            # StructGn_evt          StructGnGetSet          ButtonIntPush           
    StructGn_evt, StructGnGetSet, ButtonIntPush):
    __slots__ = 'step'

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: v = self.pp[f'{self.rna.identifier}']
        except: return

        if self.blf_value.unclip_text == v: return

        self.blf_value.unclip_text = v
        self.blf_value.text = self.text_format(v)
        #|
    #|
    #|
class GnFloat(          # StructGn_evt          StructGnGetSet          ButtonFloatPush         
    StructGn_evt,
    StructGnGetSet,
    ButtonFloatPush):
    __slots__ = 'step', 'unit'

    def __init__(self, w, rna, pp, step=1.0):
        self.w = w
        self.rna = rna
        self.step = step
        subtype = rna.subtype
        self.unit = D_gn_subtype_unit[subtype]

        self.r_pp, self.r_object, self.r_datapath_head = pp
        self.pp = self.r_pp()

        self.box_button = GpuRim(COL_box_val, COL_box_val_rim)
        self.text_format = D_format[self.unit]
        v = self.get()
        self.blf_value = BlfClipColor(self.text_format(v), v, 0, 0, COL_box_val_fg)

        self.draw_blf = self.i_draw_blf
        self.dxy = self.i_dxy

        self.draw_box = self.i_draw_box
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: v = self.pp[f'{self.rna.identifier}']
        except: return

        if self.blf_value.unclip_text == v: return

        self.blf_value.unclip_text = v
        self.blf_value.text = self.text_format(v)
        #|
    #|
    #|
class GnCollection(     # StructGnRef_evt       StructGnGetSet      StructPush  ButtonEnumCollection
    StructGnRef_evt,
    StructGnGetSet,
    StructPush,
    ButtonEnumCollection):
    __slots__ = ()

    # <<< 1copy (0block_ButtonEnumObject_set,, ${
    #     '.objects': '.collections',
    #     'Object': 'Collection',
    #     'setattr(self.pp, rna.identifier, v)': "self.pp[f'{self.rna.identifier}'] = v",
    #     'update_data()': 'update_scene()'
    # }$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.collections: v = bpy.data.collections[v]
                    else:
                        if refresh: report("Collection not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.collections: v = bpy.data.collections[v]
                    else:
                        if refresh: report("Collection not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Collection")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Collection Type")
                    return

        self.pp[f'{self.rna.identifier}'] = v
        if refresh: update_scene()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: ob = self.pp[f'{self.rna.identifier}']
        except: return

        if self.blf_value.unclip_text == (ob.name  if ob else ""): return

        blf_value = self.blf_value

        if ob == None:
            v = ""
            if self.box_icon_arrow.__class__ != GpuImg_unfold:
                self.box_icon_arrow.__class__ = GpuImg_unfold
        else:
            v = ob.name
            if self.box_icon_arrow.__class__ != GpuImg_delete:
                self.box_icon_arrow.__class__ = GpuImg_delete

        blf_value.unclip_text = v

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class GnTexture(        # GnCollection                                                          
    StructPreview,
    GnCollection):
    __slots__ = ()

    def __init__(self, w, rna, pp, allow_types=None, r_except_objects=None):
        super().__init__(w, rna, pp, allow_types=allow_types, r_except_objects=r_except_objects)
        self.box_icon_object.__class__ = GpuImg_ID_TEXTURE
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        return DropDownEnumTexture(self, self.box_button.r_LRBT(), self.rna.name, bpy.data.textures)
        #|

    # <<< 1copy (0block_ButtonEnumObject_set,, ${
    #     '.objects': '.textures',
    #     'Object': 'Texture',
    #     'setattr(self.pp, rna.identifier, v)': "self.pp[f'{self.rna.identifier}'] = v",
    #     'update_data()': 'update_scene()'
    # }$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.textures: v = bpy.data.textures[v]
                    else:
                        if refresh: report("Texture not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.textures: v = bpy.data.textures[v]
                    else:
                        if refresh: report("Texture not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Texture")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Texture Type")
                    return

        self.pp[f'{self.rna.identifier}'] = v
        if refresh: update_scene()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>
    #|
    #|
class GnImage(          # GnCollection                                                          
    StructPreview,
    GnCollection):
    __slots__ = ()

    def __init__(self, w, rna, pp, allow_types=None, r_except_objects=None):
        super().__init__(w, rna, pp, allow_types=allow_types, r_except_objects=r_except_objects)
        self.box_icon_object.__class__ = GpuImg_ID_IMAGE
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        return DropDownEnumImage(self, self.box_button.r_LRBT(), self.rna.name, bpy.data.images)
        #|

    # <<< 1copy (0block_ButtonEnumObject_set,, ${
    #     '.objects': '.images',
    #     'Object': 'Image',
    #     'setattr(self.pp, rna.identifier, v)': "self.pp[f'{self.rna.identifier}'] = v",
    #     'update_data()': 'update_scene()'
    # }$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.images: v = bpy.data.images[v]
                    else:
                        if refresh: report("Image not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.images: v = bpy.data.images[v]
                    else:
                        if refresh: report("Image not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Image")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Image Type")
                    return

        self.pp[f'{self.rna.identifier}'] = v
        if refresh: update_scene()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>
    #|
    #|
class GnMaterial(       # GnCollection                                                          
    StructPreview,
    GnCollection):
    __slots__ = ()

    def __init__(self, w, rna, pp, allow_types=None, r_except_objects=None):
        super().__init__(w, rna, pp, allow_types=allow_types, r_except_objects=r_except_objects)
        self.box_icon_object.__class__ = GpuImg_ID_MATERIAL
        #|

    def to_dropdown(self, killevt=True, select_all=None):


        return DropDownEnumMaterial(self, self.box_button.r_LRBT(), self.rna.name, bpy.data.materials)
        #|

    # <<< 1copy (0block_ButtonEnumObject_set,, ${
    #     '.objects': '.materials',
    #     'Object': 'Material',
    #     'setattr(self.pp, rna.identifier, v)': "self.pp[f'{self.rna.identifier}'] = v",
    #     'update_data()': 'update_scene()'
    # }$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.materials: v = bpy.data.materials[v]
                    else:
                        if refresh: report("Material not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.materials: v = bpy.data.materials[v]
                    else:
                        if refresh: report("Material not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Material")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Material Type")
                    return

        self.pp[f'{self.rna.identifier}'] = v
        if refresh: update_scene()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>
    #|
    #|
class GnObject(         # StructGnRef_evt       StructGnGetSet  StructPush  ButtonEnumObject        
    StructGnRef_evt,
    StructGnGetSet,
    StructPush,
    ButtonEnumObject):
    __slots__ = ()

    # <<< 1copy (0block_ButtonEnumObject_set,, ${
    #     'setattr(self.pp, rna.identifier, v)': "self.pp[f'{self.rna.identifier}'] = v",
    #     'update_data()': 'update_scene()'
    # }$)
    def set(self, v, refresh=True, undo_push=True):
        if hasattr(self, "r_object"):
            ob = self.r_object()
            if hasattr(ob, "is_editable") and not ob.is_editable:
                report(r_library_or_override_message(ob))
                return

        rna = self.rna
        oldvalue = self.get()

        if isinstance(v, str):
            if v:
                if v[: 2] == ";;":
                    v = v[1 :]
                    if v in bpy.data.objects: v = bpy.data.objects[v]
                    else:
                        if refresh: report("Object not found")
                        return
                elif v[0] == ";":
                    try: v = eval(v[1 :])
                    except:
                        if refresh: report("Eval failed")
                        return
                else:
                    if v in bpy.data.objects: v = bpy.data.objects[v]
                    else:
                        if refresh: report("Object not found")
                        return
            else:
                v = None

        if self.r_except_objects != None and v in self.r_except_objects():
            if refresh: report("Invalid Object")
            return
        if hasattr(v, "type"):
            if self.allow_types != None:
                if v.type not in self.allow_types:
                    if refresh: report("Invalid Object Type")
                    return

        self.pp[f'{self.rna.identifier}'] = v
        if refresh: update_scene()
        if hasattr(self, "set_callback"): self.set_callback()
        self.evt_undo_push(undo_push, oldvalue)
    # >>>

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: ob = self.pp[f'{self.rna.identifier}']
        except: return

        if self.blf_value.unclip_text == (ob.name  if ob else ""): return

        blf_value = self.blf_value

        if ob == None:
            v = ""
            if self.box_icon_arrow.__class__ != GpuImg_object_picker:
                self.box_icon_arrow.__class__ = GpuImg_object_picker
        else:
            v = ob.name
            if self.box_icon_arrow.__class__ != GpuImg_delete:
                self.box_icon_arrow.__class__ = GpuImg_delete

        blf_value.unclip_text = v

        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        blf_value.text = r_blf_clipping_end(v,
            blf_value.x, self.box_button.inner[1] - D_SIZE['font_main_dx'] - SIZE_widget[0])
        #|
    #|
    #|
class GnColor(          # StructGnVector_evt    StructGnGetSetVector    StructPush  ButtonColor4
    StructGnVector_evt,
    StructGnGetSetVector,
    StructPush,
    ButtonColor4):
    __slots__ = 'r_pp', 'r_object', 'r_datapath_head', 'r_fcurve', 'r_driver'

    def __init__(self, w, rna, pp, r_fcurve, r_driver):
        self.w = w
        self.rna = rna
        self.r_pp, self.r_object, self.r_datapath_head = pp
        self.pp = self.r_pp()

        self.box_button = GpuRim(None, COL_box_color_rim)
        self.box_grid = GpuGrid()
        self.box_rgb = GpuBox()
        self.color_value = None
        self.r_fcurve = r_fcurve
        self.r_driver = r_driver
        #|

    def r_height(self, width): return D_SIZE['widget_full_h']
    def r_default_array(self): return self.rna.default_value
    def r_default_value(self): return self.rna.default_value

    def to_dropdown(self):

        DropDownColorAnim(self, self.box_button, self.rna, self.pp)
        #|

    def bufn_keyframe(self):

        pp, ob = C_evt_head(self, poll_library=True, evtkill=False)
        if pp is None: return

        dr = self.w.r_driver()
        if any(dr):
            indexs = [r  for r, e in enumerate(dr) if e]
            DropDownYesNo(None, MOUSE, self.evt_delete_driver_all, input_text=f"Do you want to delete the Driver(s)?\nFor index in {indexs}")
        else:
            if not hasattr(self.w, "r_fcurve"): return
            fcs = self.r_fcurve()
            if any(fcs):
                r = bpy.context.scene.frame_current
                is_current_keyframe = False
                for fc in fcs:
                    if fc:
                        if is_current_keyframe is False:
                            kp = fc.keyframe_points
                            ind_E = len(kp) -1
                            if bin_search(0, ind_E, r, lambda x: kp[x].co[0], lambda x: None) != None:
                                is_current_keyframe = True
                                break

                if is_current_keyframe is True:
                    for r, fc in enumerate(fcs):
                        if fc: del_keyframe(ob, self.rna, pp, index=r, update_push=False)
                    update_scene_push("VMD Delete Keyframes")
                else:
                    for r, fc in enumerate(fcs): add_new_keyframe(ob, self.rna, pp, index=r, update_push=False)
                    update_scene_push("VMD Insert Keyframes")
            else:
                for r, fc in enumerate(fcs): add_new_keyframe(ob, self.rna, pp, index=r, update_push=False)
                update_scene_push("VMD Insert Keyframes")
        #|

    def upd_data(self):
        if hasattr(self, "r_pp"): self.pp = self.r_pp()
        try: v = self.pp[f'{self.rna.identifier}']
        except: return

        if self.color_value == list(v): return

        v = list(v)
        # srgb = [
        #     scene_linear_to_hex(v[0]),
        #     scene_linear_to_hex(v[1]),
        #     scene_linear_to_hex(v[2]),
        # ]
        self.box_button.color = [
            L_rgb_to_glc[min(max(0, scene_linear_to_hex(v[0])), 255)],
            L_rgb_to_glc[min(max(0, scene_linear_to_hex(v[1])), 255)],
            L_rgb_to_glc[min(max(0, scene_linear_to_hex(v[2])), 255)],
            v[3],
        ]
        self.color_value = v
        #|
    #|
    #|
class GnOutputAttrName( # GnStringAttrName                                                      
    GnStringAttrName):
    __slots__ = ()

    def evt_attr_toggle(self): pass

    def to_dropdown(self, killevt=True, select_all=None):

        ob = self.r_object()

        items = [e  for e in ob.data.attributes  if not e.is_internal] + [e  for e in ob.vertex_groups]
        D_domain_name = {identifier : e.name  for identifier, e in bpy.types.Attribute.bl_rna.properties["domain"].enum_items.items()}
        D_datatype_name = {identifier : e.name  for identifier, e in bpy.types.Attribute.bl_rna.properties["data_type"].enum_items.items()}

        def get_info(e):
            if hasattr(e, "domain"):
                return f'{D_domain_name[e.domain]}  ►  {D_datatype_name[e.data_type]}'
            return "Point  ►  Float"

        return DropDownEnum(self, self.box_button.r_LRBT(), self.rna.name, items=items, get_info=get_info)
        #|
    #|
    #|

class StructGnGroup_init_bat:
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        R2 = RR - SIZE_widget[0]
        R1 = R2 - SIZE_border[3]
        L = R1 - (self.r_button_width() if hasattr(self, "r_button_width") else D_SIZE['widget_width'])

        B = self.button0.init_bat(L, R1, TT)

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        if hasattr(self.button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(self.button0.blf_subtype, "__len__"):
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    max(blfDimen(FONT0, o.text)[0]  for o in self.button0.blf_subtype))
            else:
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    blfDimen(FONT0, self.button0.blf_subtype.text)[0])
        else:
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])

        self.button1.init_bat(R2, RR, TT - SIZE_border[3])
        return B
        #|
    #|
    #|
class GnGroupBool(          # ButtonGroupAnimAlignTitleLeft                                     
    ButtonGroupAnimAlignTitleLeft):
    __slots__ = ()

    def upd_data(self):
        self.button0.upd_data()
        self.upd_button_keyframe_BOOLEAN()
        #|
    #|
    #|
class GnGroupBoolStack(     # GnGroupBool                                                       
    GnGroupBool):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        RR -= SIZE_widget[0]
        # L = RR - D_SIZE['widget_width']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>

        self.evtkill = False
        self.button0.init_bat(LL, LL + D_SIZE['widget_bool_full_h'], TT - D_SIZE['widget_bool_dT'])
        B = TT - D_SIZE['widget_full_h']

        e = self.blf_title
        e.y = TT - SIZE_border[3] - D_SIZE['font_main_dT']
        x = (self.button0.box_button[0].R  if isinstance(self.button0.box_button, list) else self.button0.box_button.R) + D_SIZE['font_main_title_offset_R']

        e.text = r_blf_clipping_end(e.unclip_text, x, RR)
        e.x = x

        R0 = x + round(blfDimen(FONT0, e.text)[0]) + SIZE_border[3]
        self.button1.init_bat(R0, R0 + SIZE_widget[0], TT - SIZE_border[3])
        return B
        #|
    #|
    #|
class GnGroupRef(           # StructGnGroup_init_bat        ButtonGroupAnimRef                  
    StructGnGroup_init_bat,
    ButtonGroupAnimRef):
    __slots__ = ()
class GnGroup(              # StructGnGroup_init_bat        ButtonGroupAnim                     
    StructGnGroup_init_bat,
    ButtonGroupAnim):
    __slots__ = ()
class GnGroupColor(         # GnGroup                                                           
    GnGroup):
    __slots__ = ()
GnGroupColor.upd_data = ButtonGroupAnimColor.upd_data
class GnGroupVector(        # ButtonGroupAnimVector                                             
    ButtonGroupAnimVector):
    __slots__ = ()

    def init_bat(self, LL, RR, TT):
        h = SIZE_widget[0]
        widget_rim = SIZE_border[3]
        RR -= h + widget_rim
        L = RR - D_SIZE['widget_width']
        button0 = self.buttons[-1]

        B = button0.init_bat(L, RR, TT)

        e = self.blf_title
        e.y = TT - widget_rim - D_SIZE['font_main_dT']
        if hasattr(button0, "blf_subtype"):
            blfSize(FONT0, D_SIZE['font_label'])
            if hasattr(button0.blf_subtype, "__len__"):
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    max(blfDimen(FONT0, o.text)[0]  for o in button0.blf_subtype))
            else:
                R0 = L - D_SIZE['font_main_title_offset'] - D_SIZE['font_label_dx'] - round(
                    blfDimen(FONT0, button0.blf_subtype.text)[0])
        else:
            R0 = L - D_SIZE['font_main_title_offset']
        # <<< 1copy (init_blf_clipping_end,, ${'font_size':'font_main'}$)
        blfSize(FONT0, D_SIZE['font_main'])
        blg.CLIPPING_END_STR_DIMEN = floor(blfDimen(FONT0, blg.CLIPPING_END_STR)[0])
        # >>>
        e.text = r_blf_clipping_end(e.unclip_text, LL + D_SIZE['font_main_dx'], R0)
        e.x = R0 - round(blfDimen(FONT0, e.text)[0])

        L0 = button0.box_button.R + widget_rim
        R0 = L0 + h
        TT -= widget_rim
        for e in self.buttons[ : -1]:
            e.init_bat(L0, R0, TT)
            TT -= h
        return B
        #|
    #|
    #|
class GnVectorColor(GnVector):
    __slots__ = 'update_callback', 'callback_enable'

    def __init__(self, w, rna, pp, step=1.0, subtype_override=None):
        self.w = w
        self.rna = rna
        self.step = step
        self.unit = "NONE"

        self.r_pp, self.r_object, self.r_datapath_head = pp
        self.pp = self.r_pp()

        self.box_button = GpuRim(COL_box_val, COL_box_val_rim)
        self.box_active = GpuBox(COL_box_val_fo)

        self.text_format = D_format[self.unit]

        vv = self.get()
        self.array_length = len(vv)
        self.blf_value = [BlfClip(self.text_format(v), v)  for v in vv]
        self.blf_value[0].color = COL_box_val_fg

        self.draw_blf = self.i_draw_blf_subtype
        self.dxy = self.i_dxy_subtype
        self.blf_subtype = [Blf(tx)  for _, tx in zip(vv, subtype_override)]
        self.blf_subtype[0].color = COL_box_button_fg_info

        self.draw_box = self.i_draw_box
        self.active_index = None
        #|

    def evt_undo_push(self, undo_push, oldvalue): pass

    def set(self, v, index, refresh=True, undo_push=True):
        super().set(v, index, refresh)
        self.upd_data()
        if self.callback_enable: self.update_callback()
        #|
    #|
    #|

def gn_ui_AttrName(w, rna, pp, rr_fcdr):
    return GnGroupRef(w, GnStringAttrName(None, rna, pp), lambda: "")
    #|
def gn_ui_NodeSocketString(w, rna, pp, rr_fcdr):
    return GnGroupRef(w, GnString(None, rna, pp), lambda: "")
    #|
def gn_ui_NodeSocketBool(w, rna, pp, rr_fcdr):
    return GnGroupBool(w, GnBool(None, rna, pp), *rr_fcdr(rna.identifier))
    #|
def gn_ui_NodeSocketMaterial(w, rna, pp, rr_fcdr):
    return GnGroupRef(w, GnMaterial(None, rna, pp), lambda: "")
    #|
def gn_ui_NodeSocketVector(w, rna, pp, rr_fcdr):
    e = GnGroupVector(w, GnVector(None, rna, pp), *rr_fcdr(rna.identifier, RANGE_3))
    e.upd_button_keyframe = e.upd_button_keyframe_VAL
    return e
    #|
def gn_ui_NodeSocketInt(w, rna, pp, rr_fcdr):
    e = GnGroup(w, GnInt(None, rna, pp), *rr_fcdr(rna.identifier))
    e.upd_button_keyframe = e.upd_button_keyframe_VAL
    if rna.subtype == "PERCENTAGE":
        button0 = e.button0
        button0.text_format = UnitSystem.rs_format_percentage_int
        button0.blf_value.text = button0.text_format(button0.blf_value.unclip_text)
    return e
    #|
def gn_ui_NodeSocketFloat(w, rna, pp, rr_fcdr):
    e = GnGroup(w, GnFloat(None, rna, pp), *rr_fcdr(rna.identifier))
    e.upd_button_keyframe = e.upd_button_keyframe_VAL_gn_float
    if rna.subtype == "PERCENTAGE":
        button0 = e.button0
        button0.text_format = UnitSystem.rs_format_percentage_float
        button0.blf_value.text = button0.text_format(button0.blf_value.unclip_text)
    return e
    #|
def gn_ui_NodeSocketCollection(w, rna, pp, rr_fcdr):
    return GnGroupRef(w, GnCollection(None, rna, pp), lambda: "")
    #|
def gn_ui_NodeSocketObject(w, rna, pp, rr_fcdr):
    return GnGroupRef(w, GnObject(None, rna, pp), lambda: "")
    #|
def gn_ui_NodeSocketTexture(w, rna, pp, rr_fcdr):
    return GnGroupRef(w, GnTexture(None, rna, pp), lambda: "")
    #|
def gn_ui_NodeSocketImage(w, rna, pp, rr_fcdr):
    return GnGroupRef(w, GnImage(None, rna, pp), lambda: "")
    #|
def gn_ui_NodeSocketColor(w, rna, pp, rr_fcdr):
    r_fc, r_dr = rr_fcdr(rna.identifier, RANGE_4)
    return GnGroupColor(w, GnColor(None, rna, pp, r_fc, r_dr), r_fc, r_dr)
    #|
D_gn_ui = {
    "NodeSocketString": gn_ui_NodeSocketString,
    "NodeSocketBool": gn_ui_NodeSocketBool,
    "NodeSocketMaterial": gn_ui_NodeSocketMaterial,
    "NodeSocketVector": gn_ui_NodeSocketVector,
    "NodeSocketInt": gn_ui_NodeSocketInt,
    "NodeSocketCollection": gn_ui_NodeSocketCollection,
    "NodeSocketTexture": gn_ui_NodeSocketTexture,
    "NodeSocketFloat": gn_ui_NodeSocketFloat,
    "NodeSocketColor": gn_ui_NodeSocketColor,
    "NodeSocketObject": gn_ui_NodeSocketObject,
    "NodeSocketRotation": gn_ui_NodeSocketVector,
    "NodeSocketImage": gn_ui_NodeSocketImage
}
D_gn_subtype_unit = {
    "NONE": "NONE",
    "TRANSLATION": "LENGTH",
    "DIRECTION": "LENGTH",
    "VELOCITY": "VELOCITY",
    "ACCELERATION": "ACCELERATION",
    "EULER": "ROTATION",
    "XYZ": "NONE",

    "PERCENTAGE": "NONE",
    "FACTOR": "NONE",
    "ANGLE": "ROTATION",
    "TIME": "TIME",
    "TIME_ABSOLUTE": "TIME_ABSOLUTE",
    "DISTANCE": "LENGTH",
}
S_gn_output_sockets = {
    "NodeSocketBool",
    "NodeSocketVector",
    "NodeSocketInt",
    "NodeSocketFloat",
    "NodeSocketColor",
    "NodeSocketRotation"
}
#_c4#_c4#_c4#_c4

def r_calc_button_rnas(ty):
    return [RnaButton(str(r), str(r), e[1], e[0])  for r, e in enumerate(CALC_EXP[ty])]
    #|


class Layout:
    __slots__ = (
        'w',
        'items')

    def __init__(self, w):
        self.w = w
        items = w.items  if hasattr(w, "items") else w.buttons
        items.clear()
        self.items = items
        #|

    def set_fold_state(self, boo):
        BlockUtil.DEFAULT_FOLD_STATE = boo
        #|

    def new_block(self, title=None):
        if title is None:
            e = Blocks(self.w)
            e.buttons = []
            e.level = -1
            e.area = self.w
        else:
            if isinstance(title, str):
                e = BlockUtil(self.w, [], Title(title))
            elif isinstance(title, list):
                e = BlockUtils(self.w, [], title)
            else:
                e = BlockUtil(self.w, [], title)

        self.items.append(e)
        return Layout(e)
        #|

    def sep(self, factor=1.0):
        self.items.append(ButtonSep(factor))
        #|
    def split(self, group0, group1, gap=0, factor=0.5, append=True):
        group = ButtonSplit(self.w, group0, group1, gap=gap, factor=factor)
        if append: self.items.append(group)
        return group
        #|
    def overlay(self, group0, group1, append=True):
        group = ButtonOverlay(self.w, group0, group1)
        if append: self.items.append(group)
        return group
        #|
    def title(self, title=""):
        group = ButtonGroupTitle(self.w, title)
        self.items.append(group)
        return group
        #|

    def prop(self, pp, rna, title=None, align=None, set_callback=None, option=None, append=True, use_push=None):
        ty = rna.type
        if ty == "FLOAT":
            if rna.is_array:
                if rna.subtype == "STRING_VECTOR":
                    button0 = EdStringVector(None, rna, pp)
                    group = ButtonGroup(self.w, button0, title=title)
                    group.r_button_width = lambda: round(D_SIZE['widget_width'] * 1.7)
                else:
                    button0 = EdFloatVector(None, rna, pp)
                    group = ButtonGroup(self.w, button0, title=title)

                    button0.to_modal_drag_callfront = disable_auto_upd
                    button0.end_modal_drag_callback = enable_auto_upd
            else:
                button0 = EdFloat(None, rna, pp)
                group = ButtonGroup(self.w, button0, title=title)

                button0.to_modal_drag_callfront = disable_auto_upd
                button0.end_modal_drag_callback = enable_auto_upd
        elif ty == "BOOLEAN":
            button0 = EdBool(None, rna, pp)

            if align is None:
                group = ButtonGroup(self.w, button0, title=title)
            elif align == "R":
                group = ButtonGroupAlignL(self.w, button0, title=title)
            elif align == "L":
                group = ButtonGroupAlignTitleLeft(self.w, button0, title=title)
            elif align == "T":
                group = ButtonGroupBoolT(self.w, button0, title=title)
            else:
                group = ButtonGroup(self.w, button0, title=title)
        elif ty == "INT":
            if rna.is_array:
                button0 = EdIntVector(None, rna, pp)
                group = ButtonGroup(self.w, button0, title=title)

                button0.to_modal_drag_callfront = disable_auto_upd
                button0.end_modal_drag_callback = enable_auto_upd
            else:
                button0 = EdInt(None, rna, pp)
                group = ButtonGroup(self.w, button0, title=title)

                button0.to_modal_drag_callfront = disable_auto_upd
                button0.end_modal_drag_callback = enable_auto_upd
        elif ty == "STRING":
            if option is None:
                button0 = EdString(None, rna, pp)
            else:
                if "r_armature" in option:
                    button0 = EdBone(None, rna, pp, option["r_armature"])
                else:
                    button0 = EdString(None, rna, pp)

            if align is None:
                group = ButtonGroup(self.w, button0, title=title)
            else:
                group = ButtonGroupAlignTitleLeft(self.w, button0, title=title)
        elif ty == "ENUM":
            if hasattr(rna, "icon"):
                rna_icon = rna.icon
                if isinstance(rna_icon, dict):
                    button0 = EdEnumIcon(None, rna, pp, rna_icon,
                        rna.icon_default  if hasattr(rna, "icon_default") else None)
                else:
                    at = f"ENUM_{rna_icon}"
                    if hasattr(self, at):
                        button0 = getattr(self, at)(rna, pp, option)
                    else:
                        button0 = EdEnum(None, rna, pp)
            else:
                button0 = EdEnum(None, rna, pp)

            if align is None:
                group = ButtonGroup(self.w, button0, title=title)
            else:
                group = ButtonGroupAlignTitleLeft(self.w, button0, title=title)
        elif ty == "RNABUTTON":
            if use_push:
                def localfn():
                    pp()
                    ed_undo_push(message=f'VMD {rna.name}')
                button0 = Edfn(None, rna, localfn)
            else:
                button0 = Edfn(None, rna, pp)

            if align is None:
                group = ButtonGroup(self.w, button0, title=title)
            elif align == "HL":
                group = ButtonGroupHeadL(self.w, button0, title=title)
            elif align == "LC":
                group = ButtonGroupLC(self.w, button0, title=title)
            else:
                TODO
        elif ty == "POINTER":
            button0 = EdID(None, rna, pp)
            group = ButtonGroup(self.w, button0, title=title)
        else:

            TODO

        # /* 0block_Layout_prop_end
        button0.poll = poll_hard_disable
        if set_callback is None:
            button0.set_callback = update_data
        elif set_callback is True:
            button0.set_callback = lambda: button0.upd_data()
        elif set_callback is False: pass
        else:
            _option = {"button": button0}
            if option is not None:
                _option.update(option)

            if hasattr(button0, "active_index"):
                button0.set_callback = lambda: set_callback(_option, button0.get(button0.active_index))
            else:
                button0.set_callback = lambda: set_callback(_option, button0.get())


        if append: self.items.append(group)
        if use_push is not None: button0.use_push = use_push
        return group
        # */
    def prop_boolflag(self, pp, li_rna, li_name=None, title=None, align=None, set_callback=None, option=None, append=True, use_push=None):
        button0 = EdBoolflag(None, li_rna, pp, title=li_name)

        group = ButtonGroupArray(self.w, button0, title=title)

        button0.poll = poll_hard_disable
        if set_callback is None:
            button0.set_callback = update_data
        else:
            _option = {"button": button0}
            if option is not None:
                _option.update(option)

            button0.set_callback = lambda: set_callback(_option, button0.get(button0.focus_index))

        if append: self.items.append(group)
        if use_push is not None: button0.use_push = use_push
        return group
        #|

    def ENUM_idtype(self, rna, pp, option):
        return EdEnumIDType(None, rna, pp)
        #|
    def ENUM_driver_path(self, rna, pp, option):
        return EdEnumDriverPath(None, rna, pp, option["r_ID"])
        #|
    def ENUM_variable_type(self, rna, pp, option):
        return EdEnumVariableType(None, rna, pp)
        #|

    @staticmethod
    def no_background(button0):
        cls = button0.__class__
        class NewCls(cls):
            __slots__ = ()

            def draw_box(self): pass

        button0.__class__ = NewCls
        #|
    @staticmethod
    def wrap_inout_evt(button0, inevt, outevt):
        class LocalWrapInoutEvt(button0.__class__):
            __slots__ = ()

            def inside_evt(self):
                super().inside_evt()
                inevt()
            def outside_evt(self):
                super().outside_evt()
                outevt()

        button0.__class__ = LocalWrapInoutEvt
        #|
    #|
    #|


## _file_ ##
def _import_():
    #|
    import bpy
    from bpy.app.timers import register as timer_reg
    from bpy.app.timers import unregister as timer_unreg
    from bpy.app.timers import is_registered as timer_isreg
    from blf import size as blfSize
    from blf import color as blfColor
    from blf import position as blfPos
    from blf import draw as blfDraw
    from blf import dimensions as blfDimen
    from gpu.state import blend_set, scissor_get, scissor_set
    from math import floor, ceil
    from mathutils import Vector
    from types import SimpleNamespace

    from .  import m

    from . api import D_cls_id, D_id_blendData, D_cls_blendData
    from . area import preview_datablock
    from . colorlist import (
        L_rgb_to_glc,
        L_rgb_to_scene_linear,
        scene_linear_to_hex,
    )
    from . dd import(
        DropDownVal,
        DropDownRMKeymap,
        DropDownRM,
        DropDownString,
        DropDownStringXY,
        DropDownEnum,
        DropDownEnumRename,
        DropDownEnumPointer,
        DropDownEnumTexture,
        DropDownEnumImage,
        DropDownEnumMaterial,
        DropDownColor,
        DropDownColorAnim,
        DropDownColorSRGB,
        DropDownOk,
        DropDownYesNo,
        DropDownInfoUtil,
        DropDownNewModifier,
        DropDownAddOpsShortcut,
        DropDownEditOpsShortcut,
        DDKeyframes,
        get_info_users,
    )
    from . handle import upd_link_data
    from . keysys import (
        kill_evt_except,
        MOUSE,
        EVT_TYPE,
        TRIGGER,
        r_end_trigger,
        CALC_EXP,
        is_first_press,
    )
    from . m import(
        P,
        Admin,
        W_HEAD,
        update_data,
        init_loop_mouse,
        end_loop_mouse,
        loop_mouse,
        r_mouse_dxy,
        UnitSystem,
        r_unit_factor,
        modal_object_picker_init,
        object_select,
        disable_auto_upd,
        enable_auto_upd,
    )
    from . prefs import SRGB_ATTRS
    from . rna import (
        RNA_active_object,
        RNA_active_object_sync,
        RNA_active_modifier,
        RNA_active_modifier_sync,
        RNA_new_modifier,
        RNA_remove_modifier,
        RNA_active_item,
        RNA_new_item,
        RNA_remove_item,
        RNA_button_keyframe,
        RNA_run,
        RNA_cancel,
    )
    from . userops import D_EDITOR
    from . win import Head, Detail

    from . evals.evalbatchoperation import eval_batch_operation, r_code_batch_operation

    from . util.com import value_to_display, is_value, bin_search, rs_format_float6_vec
    from . util.const import FLO_0000, RANGE_3, RANGE_4
    from . util.txt import Text
    from . util.types import (
        RnaButton,
        NameValue,
        LocalHistory,
        HistoryValue,
        Name,
        RnaBool,
        r_collection_create,
    )

    from . utilbl import blg
    from . utilbl.blg import (
        D_SIZE,
        FONT0,
        FONT1,
        SIZE_widget,
        SIZE_border,
        SIZE_block,
        SIZE_foreground_height,
        SIZE_button,
        SIZE_setting_list_border,
        SIZE_title,
        COL_block,
        COL_block_even,
        COL_block_fo,
        COL_block_fg,
        COL_block_fg_ignore,
        COL_block_fg_info,
        COL_block_calc_display,
        COL_block_calc_button_bg,
        COL_block_guideline0,
        COL_block_guideline1,
        COL_block_title,
        COL_block_title_even,
        COL_box_val,
        COL_box_val_rim,
        COL_box_val_ignore,
        COL_box_val_rim_ignore,
        COL_box_val_fo,
        COL_box_val_active,
        COL_box_val_bool,
        COL_box_val_bool_fo,
        COL_box_val_fg,
        COL_box_val_fg_ignore,
        COL_box_val_fg_error,
        COL_box_button_fg,
        COL_box_button_fg_info,
        COL_box_button_fg_ignore,
        COL_box_text,
        COL_box_text_rim,
        COL_box_text_ignore,
        COL_box_text_rim_ignore,
        COL_box_text_active,
        COL_box_text_fg,
        COL_box_text_fg_ignore,
        COL_box_text_read,
        COL_box_text_read_rim,
        COL_box_text_read_fg,
        COL_box_text_selection,
        COL_box_color_rim,
        COL_box_color_rim_fo,
        COL_box_filter,
        COL_box_filter_rim,
        Blf,
        BlfClip,
        BlfColor,
        BlfClipColor,
        r_blf_clipping_end,
        rl_blf_wrap_LR,
        r_widget_font_dx_dy_dT,
        BoxFake,
        GpuBox,
        GpuBox_block,
        GpuRim,
        GpuButton,
        GpuButtonBool,
        GpuCheckbox,
        GpuGrid,
        GpuBox_box_filter_active_bg,
        GpuImgNull,
        GpuImg_valuebox_left,
        GpuImg_valuebox_right,
        GpuImg_fold,
        GpuImg_fold_focus,
        GpuImg_unfold,
        GpuImg_unfold_focus,
        GpuImg_ADD,
        GpuImg_ADD_focus,
        GpuImg_REMOVE,
        GpuImg_REMOVE_focus,
        GpuImg_TRIA_UP,
        GpuImg_TRIA_UP_focus,
        GpuImg_TRIA_DOWN,
        GpuImg_TRIA_DOWN_focus,
        GpuImg_FAKE_USER_OFF,
        GpuImg_FAKE_USER_OFF_focus,
        GpuImg_FAKE_USER_ON,
        GpuImg_FAKE_USER_ON_focus,
        GpuImg_FAKE_USER_LIB,
        GpuImg_FAKE_USER_LIB_focus,
        GpuImg_FAKE_USER_LINK,
        GpuImg_FAKE_USER_LINK_focus,
        GpuImg_FAKE_USER_OVERRIDE,
        GpuImg_FAKE_USER_OVERRIDE_focus,
        GpuImg_area_icon_hover,
        GpuImg_filter_match_case,
        GpuImg_filter_match_whole_word,
        GpuImg_filter_match_end_left,
        GpuImg_filter_match_end_right,
        GpuImg_filter_match_active,
        GpuImg_filter_match_hover,
        GpuImg_keyframe_false,
        GpuImg_keyframe_current_true_even,
        GpuImg_keyframe_current_true_odd,
        GpuImg_keyframe_next_false_even,
        GpuImg_keyframe_next_false_odd,
        GpuImg_driver_true,
        GpuImg_driver_ref,
        GpuImg_OBJECT_DATA,
        GpuImg_ID_OBJECT,
        GpuImg_ID_COLLECTION,
        GpuImg_ID_TEXTURE,
        GpuImg_ID_MATERIAL,
        GpuImg_ID_IMAGE,
        GpuImg_ID_CACHEFILE,
        GpuImg_GROUP_VERTEX,
        GpuImg_BONE_DATA,
        GpuImg_GREASEPENCIL,
        GpuImg_GROUP_UVS,
        GpuImg_ID_NODETREE,
        GpuImg_object_picker,
        GpuImg_object_picker_focus,
        GpuImg_delete,
        GpuImg_delete_focus,
        GpuImg_rename,
        GpuImg_rename_focus,
        GpuImg_rna,
        GpuImg_DUPLICATE,
        GpuImg_DUPLICATE_focus,
        GpuImg_HIDE_OFF,
        GpuImg_HIDE_OFF_focus,
        GpuImg_HIDE_ON,
        GpuImg_HIDE_ON_focus,
        GpuImg_SMOOTHCURVE,
        GpuImg_SPHERECURVE,
        GpuImg_ROOTCURVE,
        GpuImg_SHARPCURVE,
        GpuImg_LINCURVE,
        GpuImg_NOCURVE,
        GpuImg_RNDCURVE,
        GpuImg_IPO_CONSTANT,
        GpuImg_FILE_FOLDER,
        GpuImg_FILE_FOLDER_focus,
        GpuImg_GROUP_VCOL,
        GpuImg_PARTICLE_SYSTEM,
        Scissor,
        report,
        is_LRBT_match,
        geticon_Object,
        getinfo_Object,
        geticon_Modifier,
        geticon_DriverVar,
    )
    from . utilbl.calc import calc_vec, round_dec
    from . utilbl.general import (
        r_obj_path_by_full_path,
        r_add_to_keying_set,
        r_remove_from_keying_set,
        r_library_or_override_message,
        r_library_editable,
        r_fcurve_name,
        update_scene,
        update_scene_push,
        is_array_fcurve,
        r_ID_dp,
    )
    from . utilbl.md import (
        r_md_driver_add,
        r_md_driver_remove,
        r_md_keyframe,
        r_md_driver,
        r_md_refdriver,
        r_id_type,
        add_empty_geometry_node_group,
        ModAttr,
        ModArrayAttr,
        # ModRefAttr,
    )
    from . utilbl.ops import OpScanFile, OpScanFolder
    from . utilbl.pymath import calc_py_exp


    r_intersect_scissor = Scissor.r_intersect_scissor
    ed_undo_push = bpy.ops.ed.undo_push

    _xy = [0, 0]
    _valboxdata = [None]
    _time = [0]
    _timer_button_fn = None
    _last_bool_state = [False]

    D_format = UnitSystem.D_format
    P_SettingEditor = P.SettingEditor

    r_all_objects = m.BlendDataTemp.r_all_objects
    tag_obj_rename = m.tag_obj_rename

    D_subtype_display = {
        'PIXEL': ('px', ),
        'DISTANCE': ('X', 'Y', 'Z'),
        'ANGLE': ('X', 'Y', 'Z', 'W'),
        'TRANSLATION': ('X', 'Y', 'Z'),
        'XYZ_LENGTH': ('X', 'Y', 'Z'),
        'XYZ': ('X', 'Y', 'Z'),
        'EULER': ('X', 'Y', 'Z'),
        'DIRECTION': ('X', 'Y', 'Z'),
        'VELOCITY': ('X', 'Y', 'Z'),
        'ACCELERATION': ('X', 'Y', 'Z')}
    ButtonEnumFalloff.D_get_icon.clear()
    ButtonEnumFalloff.D_get_icon.update({
        "Smooth": GpuImg_SMOOTHCURVE,
        "Sphere": GpuImg_SPHERECURVE,
        "Root": GpuImg_ROOTCURVE,
        "Inverse Square": GpuImg_ROOTCURVE,
        "Sharp": GpuImg_SHARPCURVE,
        "Linear": GpuImg_LINCURVE,
        "Constant": GpuImg_NOCURVE,
        "RND": GpuImg_NOCURVE,
        "Custom Curve": GpuImg_RNDCURVE,
        "Random": GpuImg_RNDCURVE,
        "Median Step": GpuImg_IPO_CONSTANT,

        "SMOOTH": GpuImg_SMOOTHCURVE,
        "SPHERE": GpuImg_SPHERECURVE,
        "ROOT": GpuImg_ROOTCURVE,
        "INVERSE_SQUARE": GpuImg_ROOTCURVE,
        "SHARP": GpuImg_SHARPCURVE,
        "LINEAR": GpuImg_LINCURVE,
        "CONSTANT": GpuImg_NOCURVE,
        "CURVE": GpuImg_RNDCURVE,
        "RANDOM": GpuImg_RNDCURVE,
        "STEP": GpuImg_IPO_CONSTANT,
        "ICON_SPHERECURVE": GpuImg_SPHERECURVE,
    })

    PREF_HISTORY = LocalHistory(None, 1)
    MODAL_DRAG_STATE = [-1]

    globals().update(locals())
    #|
