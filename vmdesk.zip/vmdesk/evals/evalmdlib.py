import bpy

def eval_md_lib(code):
    localdict = {}
    try:
        exec(code, {"__builtins__": None}, localdict)
    except Exception as exx:
        return None, str(exx)

    try:
        if "directories" in localdict: return localdict["directories"], ""

        return None, 'Local variable "directories" requires'
    except Exception as exx:
        return None, str(exx)

    return None, "Unknown Error"
    #|
