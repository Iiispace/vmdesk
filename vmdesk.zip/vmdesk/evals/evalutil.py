import bpy

def bpyeval(s): return eval(s)
def bpyeval_ob(s, ob): return eval(s)
