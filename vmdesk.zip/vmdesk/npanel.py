import bpy
from bpy.types import Panel

P = None

class VmdPanel(Panel):
    __slots__ = ()

    bl_idname = "VMD_PT_Panel"
    bl_label = "Control Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "VMD"

    def __init__(self):
        global P
        # <<< 1copy (assignP,, $$)
        P = bpy.context.preferences.addons[__package__].preferences
        # >>>
        #|

    def draw(self, context):
        #|
        layout = self.layout
        row = layout.row
        sep = layout.separator

        row().operator("wm.vmd_window_manager", text="Window Manager")

        for name in EDITORS:
            e = row().operator("wm.vmd_editor", text=name)
            e.id_class = name
            e.use_pos = False

        sep()
        row().operator("wm.save_userpref")
        row().operator("wm.vmd_addon_factory", text="Load Addon Factory Setting")
        row().operator("wm.vmd_reload_icon", text="Reload Icon")
        row().operator("wm.vmd_reload_font", text="Reload Font")






















        #|
    #|
    #|

class VmdPanelTemp(Panel):
    bl_idname = "VMD_TEMP_PT_Panel"
    bl_label = "Temporary Data"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"
    bl_parent_id = "VMD_PT_Panel"

    @classmethod
    def poll(self, context):
        if Admin.IS_RUNNING:
            if W_MODAL: return True

        return False
        #|

    def draw(self, context):
        #|
        row = self.layout.row
        PP = P.temp

        # <<< 1ifmatch (0prefs_temp, 8,
        #     $lambda line: (f'row().prop(PP, "{line.split(":", 1)[0].lstrip()}")\n', True)$,
        #     $lambda line: ('', False)  if line.find('#sep()') == -1 else ('sep()\n', True)$,
        #     ${'Property('}$)
        row().prop(PP, "pos")
        row().prop(PP, "size")
        row().prop(PP, "canvas")
        # >>>
        #|
    #|
    #|
class VmdPanelGeneral(Panel):
    bl_idname = "VMD_GENERAL_PT_Panel"
    bl_label = "General"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"
    bl_parent_id = "VMD_PT_Panel"

    def draw(self, context):
        #|
        layout = self.layout
        row = layout.row
        sep = layout.separator

        # <<< 1ifmatch (0prefs, 8,
        #     $lambda line: (f'row().split(factor=1.0).prop(P, "{line.split(":", 1)[0].lstrip()}")\n', True
        #         )  if line.find('PointerProperty') == -1 else ('', False)$,
        #     $lambda line: ('', False)  if line.find('#sep()') == -1 else ('sep()\n', True)$,
        #     ${'Property('}$)
        row().split(factor=1.0).prop(P, "sys_auto_off")
        row().split(factor=1.0).prop(P, "show_length_unit")
        row().split(factor=1.0).prop(P, "lock_win_size")
        row().split(factor=1.0).prop(P, "th_drag")
        row().split(factor=1.0).prop(P, "th_double_click")
        row().split(factor=1.0).prop(P, "win_check_overlap")
        row().split(factor=1.0).prop(P, "win_overlap_offset")
        row().split(factor=1.0).prop(P, "filter_match_case")
        row().split(factor=1.0).prop(P, "filter_match_whole_word")
        row().split(factor=1.0).prop(P, "filter_match_end")
        row().split(factor=1.0).prop(P, "filter_autopan_active")
        row().split(factor=1.0).prop(P, "filter_adaptive_selection")
        row().split(factor=1.0).prop(P, "filter_delete_behavior")
        row().split(factor=1.0).prop(P, "cursor_beam_time")
        row().split(factor=1.0).prop(P, "use_select_all")
        row().split(factor=1.0).prop(P, "pan_invert")
        row().split(factor=1.0).prop(P, "scroll_distance")
        row().split(factor=1.0).prop(P, "valbox_drag_fac_int")
        row().split(factor=1.0).prop(P, "valbox_drag_fac_float")
        row().split(factor=1.0).prop(P, "button_repeat_time")
        row().split(factor=1.0).prop(P, "button_repeat_interval")
        row().split(factor=1.0).prop(P, "use_py_exp")
        row().split(factor=1.0).prop(P, "show_rm_keymap")
        row().split(factor=1.0).prop(P, "adaptive_enum_input")
        row().split(factor=1.0).prop(P, "undo_steps_local")
        row().split(factor=1.0).prop(P, "format_float")
        row().split(factor=1.0).prop(P, "format_hex")
        row().split(factor=1.0).prop(P, "anim_filter")
        row().split(factor=1.0).prop(P, "animtime_filter")
        row().split(factor=1.0).prop(P, "cursor_picker")
        row().split(factor=1.0).prop(P, "cursor_pan")
        row().split(factor=1.0).prop(P, "md_lib_filepath")
        row().split(factor=1.0).prop(P, "md_lib_filter")
        row().split(factor=1.0).prop(P, "md_lib_method")
        row().split(factor=1.0).prop(P, "md_lib_use_essentials")
        row().split(factor=1.0).prop(P, "preview_scale")
        row().split(factor=1.0).prop(P, "preview_showname")
        row().split(factor=1.0).prop(P, "prop_image_dd_showicon")
        row().split(factor=1.0).prop(P, "fontpath_method")
        row().split(factor=1.0).prop(P, "fontpath_ui")
        row().split(factor=1.0).prop(P, "fontpath_ui_mono")
        row().split(factor=1.0).prop(P, "npanel_reg_settings")
        row().split(factor=1.0).prop(P, "is_open_driver_editor")
        # >>>
        #|
    #|
    #|
class VmdPanelSize(Panel):
    bl_idname = "VMD_SIZE_PT_Panel"
    bl_label = "Size"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"
    bl_parent_id = "VMD_PT_Panel"

    def draw(self, context):
        #|
        layout = self.layout
        row = layout.row
        sep = layout.separator
        PP = P.size

        layout.label(text='Press "Reload Icon" after changing UI size', icon="INFO")
        layout.label(text="This behavior will be performed automatically in the Settings Editor")
        row().operator("wm.vmd_reload_icon", text="Reload Icon")
        sep()
        row().operator("wm.vmd_ui_scale", text="Set UI Scale to 1.0").factor = 1.0
        row().operator("wm.vmd_ui_scale", text="Set UI Scale to 1.33").factor = 1.33
        row().operator("wm.vmd_ui_scale", text="Set UI Scale to 1.66").factor = 1.66
        row().operator("wm.vmd_ui_scale", text="Set UI Scale to 2.0").factor = 2.0
        sep()

        # <<< 1ifmatch (0prefs_size, 8,
        #     $lambda line: (f'row().split(factor=1.0).prop(PP, "{line.split(":", 1)[0].lstrip()}")\n', True)$,
        #     $lambda line: ('', False)  if line.find('#sep()') == -1 else ('sep()\n', True)$,
        #     ${'Property('}$)
        row().split(factor=1.0).prop(PP, "widget")
        row().split(factor=1.0).prop(PP, "title")
        row().split(factor=1.0).prop(PP, "border")
        row().split(factor=1.0).prop(PP, "dd_border")
        row().split(factor=1.0).prop(PP, "filter")
        row().split(factor=1.0).prop(PP, "tb")
        row().split(factor=1.0).prop(PP, "win_shadow_offset")
        row().split(factor=1.0).prop(PP, "dd_shadow_offset")
        row().split(factor=1.0).prop(PP, "shadow_softness")
        row().split(factor=1.0).prop(PP, "setting_list_border")
        row().split(factor=1.0).prop(PP, "block")
        row().split(factor=1.0).prop(PP, "button")
        row().split(factor=1.0).prop(PP, "foreground")
        row().split(factor=1.0).prop(PP, "foreground_height")
        row().split(factor=1.0).prop(PP, "widget_fac")
        # >>>
        #|
    #|
    #|
class VmdPanelColor(Panel):
    bl_idname = "VMD_COLOR_PT_Panel"
    bl_label = "Color"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"
    bl_parent_id = "VMD_PT_Panel"

    def draw(self, context):
        #|
        layout = self.layout
        row = layout.row
        sep = layout.separator
        PP = P.color

        layout.label(text="This category does not provide a", icon="INFO")
        layout.label(text="correct color space preview,")
        layout.label(text="to preview accurate results please go")
        layout.label(text="to the Settings Editor >")
        layout.label(text="Personalization > UI Color")

        # <<< 1ifmatch (0prefs_color, 8,
        #     $lambda line: (f'row().prop(PP, "{line.split(":", 1)[0].lstrip()}")\n', True)$,
        #     $lambda line: ('', False)  if line.find('#sep()') == -1 else ('sep()\n', True)$,
        #     ${'Property('}$)
        row().prop(PP, "win_title")
        row().prop(PP, "win_title_inactive")
        row().prop(PP, "win")
        row().prop(PP, "win_inactive")
        row().prop(PP, "win_rim")
        row().prop(PP, "win_shadow")
        row().prop(PP, "dd_title")
        row().prop(PP, "dd")
        row().prop(PP, "dd_rim")
        row().prop(PP, "dd_shadow")
        row().prop(PP, "area")
        row().prop(PP, "box_area_region")
        row().prop(PP, "box_area_region_rim")
        row().prop(PP, "box_area_hover")
        row().prop(PP, "box_area_hover_rim")
        row().prop(PP, "box_area_header_bg")
        row().prop(PP, "block")
        row().prop(PP, "block_even")
        row().prop(PP, "block_title")
        row().prop(PP, "block_title_even")
        row().prop(PP, "block_calc_display")
        row().prop(PP, "block_calc_display_fo")
        row().prop(PP, "block_calc_button_bg")
        row().prop(PP, "block_fo")
        row().prop(PP, "block_guideline0")
        row().prop(PP, "block_guideline1")
        row().prop(PP, "box_tb")
        row().prop(PP, "box_tb_multibar")
        row().prop(PP, "box_text_active")
        row().prop(PP, "box_text")
        row().prop(PP, "box_text_rim")
        row().prop(PP, "box_text_ignore")
        row().prop(PP, "box_text_rim_ignore")
        row().prop(PP, "box_text_read")
        row().prop(PP, "box_text_read_rim")
        row().prop(PP, "box_color_rim")
        row().prop(PP, "box_color_rim_fo")
        row().prop(PP, "box_val")
        row().prop(PP, "box_val_rim")
        row().prop(PP, "box_val_ignore")
        row().prop(PP, "box_val_rim_ignore")
        row().prop(PP, "box_val_fo")
        row().prop(PP, "box_val_active")
        row().prop(PP, "box_val_bool")
        row().prop(PP, "box_val_bool_rim")
        row().prop(PP, "box_val_bool_fo")
        row().prop(PP, "box_val_bool_ignore")
        row().prop(PP, "box_val_bool_rim_ignore")
        row().prop(PP, "box_button")
        row().prop(PP, "box_button_rim")
        row().prop(PP, "box_button_ignore")
        row().prop(PP, "box_button_rim_ignore")
        row().prop(PP, "box_button_fo")
        row().prop(PP, "box_button_rim_fo")
        row().prop(PP, "box_button_active")
        row().prop(PP, "box_button_rim_active")
        row().prop(PP, "box_buttonoff")
        row().prop(PP, "box_buttonoff_rim")
        row().prop(PP, "box_buttonoff_fo")
        row().prop(PP, "box_buttonoff_rim_fo")
        row().prop(PP, "box_buttonon")
        row().prop(PP, "box_buttonon_rim")
        row().prop(PP, "box_buttonon_fo")
        row().prop(PP, "box_buttonon_rim_fo")
        row().prop(PP, "box_filter")
        row().prop(PP, "box_filter_rim")
        row().prop(PP, "box_filter_num_modal")
        row().prop(PP, "box_filter_num_modal_rim")
        row().prop(PP, "box_filter_region")
        row().prop(PP, "box_filter_region_rim")
        row().prop(PP, "box_filter_active_bg")
        row().prop(PP, "box_filter_select_bg")
        row().prop(PP, "box_filter_hover_bg")
        row().prop(PP, "box_cursor_beam")
        row().prop(PP, "box_cursor_beam_off")
        row().prop(PP, "box_text_selection")
        row().prop(PP, "box_text_selection_off")
        row().prop(PP, "box_scrollbar_bg")
        row().prop(PP, "box_scrollbar")
        row().prop(PP, "box_block_scrollbar_bg")
        row().prop(PP, "box_block_scrollbar")
        row().prop(PP, "box_setting_list_bg")
        row().prop(PP, "box_setting_list_active")
        row().prop(PP, "box_setting_list_active_rim")
        row().prop(PP, "box_blfbutton_text_hover")
        row().prop(PP, "box_blfbutton_text_hover_rim")
        row().prop(PP, "box_hue_bg")
        row().prop(PP, "box_selectbox_bg")
        row().prop(PP, "box_selectbox_rim")
        row().prop(PP, "box_selectbox_gap")
        row().prop(PP, "box_selectbox_subtract_bg")
        row().prop(PP, "box_selectbox_subtract_rim")
        row().prop(PP, "box_selectbox_subtract_gap")
        row().prop(PP, "win_title_fg")
        row().prop(PP, "dd_title_fg")
        row().prop(PP, "box_text_fg")
        row().prop(PP, "box_text_fg_ignore")
        row().prop(PP, "box_text_read_fg")
        row().prop(PP, "box_val_fg")
        row().prop(PP, "box_val_fg_ignore")
        row().prop(PP, "box_val_fg_error")
        row().prop(PP, "box_filter_fg")
        row().prop(PP, "box_filter_fg_info")
        row().prop(PP, "box_filter_fg_label")
        row().prop(PP, "box_filter_fg_apply")
        row().prop(PP, "box_filter_fg_del")
        row().prop(PP, "box_setting_list_fg")
        row().prop(PP, "block_fg")
        row().prop(PP, "block_fg_ignore")
        row().prop(PP, "block_fg_info")
        row().prop(PP, "box_button_fg")
        row().prop(PP, "box_button_fg_ignore")
        row().prop(PP, "box_button_fg_info")
        row().prop(PP, "win_title_hover")
        row().prop(PP, "win_title_hover_red")
        row().prop(PP, "win_title_hover_hold")
        row().prop(PP, "win_title_hover_hold_red")
        # >>>
        #|
    #|
    #|
class VmdPanelModifierEditor(Panel):
    bl_idname = "VMD_MODIFIER_EDITOR_PT_Panel"
    bl_label = "Modifier Editor"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"
    bl_parent_id = "VMD_PT_Panel"

    def draw(self, context):
        #|
        layout = self.layout
        row = layout.row
        sep = layout.separator
        PP = P.ModifierEditor

        # <<< 1ifmatch (0prefs_modifier_editor, 8,
        #     $lambda line: (f'row().split(factor=1.0).prop(PP, "{line.split(":", 1)[0].lstrip()}")\n', True)$,
        #     $lambda line: ('', False)  if line.find('#sep()') == -1 else ('sep()\n', True)$,
        #     ${'Property('}$)
        row().split(factor=1.0).prop(PP, "pos")
        row().split(factor=1.0).prop(PP, "size")
        row().split(factor=1.0).prop(PP, "is_fold")
        row().split(factor=1.0).prop(PP, "is_sync_object")
        row().split(factor=1.0).prop(PP, "is_sync_modifier")
        row().split(factor=1.0).prop(PP, "is_sync_object_2")
        row().split(factor=1.0).prop(PP, "is_sync_modifier_2")
        row().split(factor=1.0).prop(PP, "md_copy_use_keyframe")
        row().split(factor=1.0).prop(PP, "md_copy_use_driver")
        row().split(factor=1.0).prop(PP, "md_copy_to_selected_use_keyframe")
        row().split(factor=1.0).prop(PP, "md_copy_to_selected_use_driver")
        row().split(factor=1.0).prop(PP, "md_copy_to_selected_use_mouse_index")
        row().split(factor=1.0).prop(PP, "md_copy_to_selected_use_selection")
        row().split(factor=1.0).prop(PP, "md_copy_to_selected_use_self")
        row().split(factor=1.0).prop(PP, "md_copy_to_selected_operation")
        row().split(factor=1.0).prop(PP, "area_rowlen_obj")
        row().split(factor=1.0).prop(PP, "md_copy_to_selected_use_code")
        row().split(factor=1.0).prop(PP, "area_rowlen_mds")
        row().split(factor=1.0).prop(PP, "area_widthfac_tab")
        row().split(factor=1.0).prop(PP, "area_widthfac_filter")
        row().split(factor=1.0).prop(PP, "area_list_inner")
        # >>>
        #|
    #|
    #|
class VmdPanelSettingEditor(Panel):
    bl_idname = "VMD_SETTING_EDITOR_PT_Panel"
    bl_label = "Settings Editor"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"
    bl_parent_id = "VMD_PT_Panel"

    def draw(self, context):
        #|
        layout = self.layout
        row = layout.row
        sep = layout.separator
        PP = P.SettingEditor

        # <<< 1ifmatch (0prefs_setting_editor, 8,
        #     $lambda line: (f'row().split(factor=1.0).prop(PP, "{line.split(":", 1)[0].lstrip()}")\n', True)$,
        #     $lambda line: ('', False)  if line.find('#sep()') == -1 else ('sep()\n', True)$,
        #     ${'Property('}$)
        row().split(factor=1.0).prop(PP, "pos")
        row().split(factor=1.0).prop(PP, "size")
        row().split(factor=1.0).prop(PP, "is_fold")
        row().split(factor=1.0).prop(PP, "is_fold_search")
        row().split(factor=1.0).prop(PP, "use_search_id")
        row().split(factor=1.0).prop(PP, "use_search_name")
        row().split(factor=1.0).prop(PP, "use_search_description")
        row().split(factor=1.0).prop(PP, "use_search_cat_pref")
        row().split(factor=1.0).prop(PP, "use_search_cat_pref_color")
        row().split(factor=1.0).prop(PP, "use_search_cat_pref_size")
        row().split(factor=1.0).prop(PP, "use_search_cat_pref_keymap")
        row().split(factor=1.0).prop(PP, "use_search_cat_pref_apps")
        row().split(factor=1.0).prop(PP, "area_height")
        # >>>
        #|
    #|
    #|


## _file_ ##
def _import_():
    #|
    from . userops import EDITORS
    from . m import Admin, W_MODAL

    globals().update(locals())
    #|
