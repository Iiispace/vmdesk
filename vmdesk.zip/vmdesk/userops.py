from bpy.types import Operator
from bpy.props import (
    StringProperty,
    EnumProperty,
    BoolProperty,
    IntVectorProperty,
    FloatVectorProperty,
    FloatProperty)


class PollEditMesh(Operator):
    __slots__ = ()

    @classmethod
    def poll(cls, context):
        if context.area.type == "VIEW_3D":
            ob = context.object
            if hasattr(ob, "mode") and ob.mode == "EDIT":
                if hasattr(ob, "type") and ob.type == "MESH": return True
        return False
        #|
    #|
    #|
class Bmesh:
    __slots__ = 'bm', 'verts_sel', 'edges_sel', 'faces_sel'

    def __init__(self, bm, verts_sel, edges_sel, faces_sel):
        self.bm = bm
        self.verts_sel = verts_sel
        self.edges_sel = edges_sel
        self.faces_sel = faces_sel
        #|
    #|
    #|


class OpsWinman(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_window_manager"
    bl_label = "VMD Window Manager"
    bl_options = {"REGISTER"}
    bl_description = "Open Window Manager in 3D Viewport"
    bl_keycategory = "3D View"

    def invoke(self, context, event):
        if call_admin(context):
            if m.P.is_first_use:
                from . dd import call_dd_license
                call_dd_license()

        m.Admin.REDRAW()
        return {'FINISHED'}
        #|
    #|
    #|

class OpsEditor(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_editor"
    bl_label = "VMD Editor"
    bl_options = {"REGISTER"}
    bl_description = "Open Editor in 3D Viewport"
    bl_keycategory = "3D View"

    id_class: EnumProperty(
        name = "Class",
        description = "Editor Type.",
        items = (
            # <<< 1forfile (_editor_,, $lambda _file_, _cls_: f'("{_cls_}", "{split_upper(_cls_)}", ""),\n'$)
            ("DriverEditor", "Driver Editor", ""),
            ("ModifierEditor", "Modifier Editor", ""),
            ("MeshEditor", "Mesh Editor", ""),
            ("SettingEditor", "Setting Editor", ""),
            # >>>
        ),
        options = set())
    use_pos: BoolProperty(
        name = "Override Position",
        description = "Use cursor position instead of default position.",
        default = True,
        options = set())
    pos_offset: IntVectorProperty(
        name = "Offset",
        description = "Window offset when Override Position is enabled.",
        size = 2,
        default = (-150, 15),
        subtype = "TRANSLATION",
        options = set())
    use_fit: BoolProperty(
        name = "Auto Size",
        description = "Use Auto Size instead of default size.",
        default = True,
        options = set())


    def invoke(self, context, event):
        if call_admin(context):
            if m.P.is_first_use:
                from . dd import call_dd_license
                call_dd_license()
            else:
                D_EDITOR[self.id_class](
                id_class = self.id_class,
                use_pos = self.use_pos,
                use_fit = self.use_fit,
                pos_offset = self.pos_offset,

                event = event)

        return {'FINISHED'}
        #|

class OpsLoadFactory(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_addon_factory"
    bl_label = "VMD Load Addon Factory Setting"
    bl_options = {"REGISTER"}
    bl_description = "Load vmdesk Factory Setting, this process cannot be 'Undo'"
    bl_keycategory = "Window"

    @classmethod
    def poll(cls, context):
        if m.P: return True
        return False

    def execute(self, context):
        if m.ADMIN: m.ADMIN.evt_sys_off(sleep=False)

        from . apps.settingeditor.areas import P_BL_RNA_PROPS

        def reset_prefs(pp):
            for identifier, rna in pp.bl_rna.properties.items():
                if identifier in {'bl_idname', 'name', 'rna_type'}: continue

                if rna.type == "POINTER":
                    reset_prefs(getattr(pp, identifier))
                    continue

                if hasattr(rna, "is_array") and rna.is_array:
                    setattr(pp, identifier, rna.default_array)
                else:
                    if rna.subtype == "BYTE_STRING":
                        setattr(pp, identifier, rna.default.encode('utf-8'))
                    else:
                        setattr(pp, identifier, rna.default)

        reset_prefs(m.P)
        self.report({'INFO'}, "Reset successful, requires manual saving of preferences")
        return {'FINISHED'}
        #|
    #|
    #|


class OpsReloadIcon(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_reload_icon"
    bl_label = "VMD Reload Icon"
    bl_options = {"REGISTER"}
    bl_description = "Reload icons after changing UI size"
    bl_keycategory = "Window"

    @classmethod
    def poll(cls, context):
        if m.P: return True
        return False

    def invoke(self, context, event):
        blg.reload_icon()
        return {'FINISHED'}
        #|
    #|
    #|
class OpsReloadFont(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_reload_font"
    bl_label = "VMD Reload Font"
    bl_options = {"REGISTER"}
    bl_description = "Reload UI Fonts after changing blender Theme / Text Rendering settings (like Subpixel Anti-Aliasing)"
    bl_keycategory = "Window"

    @classmethod
    def poll(cls, context):
        if m.P: return True
        return False

    def invoke(self, context, event):
        blg.reload_font()
        return {'FINISHED'}
        #|
    #|
    #|
class OpsUiScale(Operator):
    __slots__ = ()

    bl_idname = "wm.vmd_ui_scale"
    bl_label = "VMD UI Scale"
    bl_options = {"REGISTER"}
    bl_description = "Set add-on UI scale"
    bl_keycategory = "Window"

    factor: FloatProperty(default=1.0)

    @classmethod
    def poll(cls, context):
        if m.P: return True
        return False

    def execute(self, context):
        fac = self.factor
        P = m.P
        pp = P.size

        if fac < 1.32:
            rnas = pp.bl_rna.properties
            pp.widget[:] = rnas["widget"].default_array
            pp.title[:] = rnas["title"].default_array
            pp.border[:] = rnas["border"].default_array
            pp.dd_border[:] = rnas["dd_border"].default_array
            pp.filter[:] = rnas["filter"].default_array
            pp.tb[:] = rnas["tb"].default_array
            pp.win_shadow_offset[:] = rnas["win_shadow_offset"].default_array
            pp.dd_shadow_offset[:] = rnas["dd_shadow_offset"].default_array
            pp.shadow_softness[:] = rnas["shadow_softness"].default_array
            pp.setting_list_border[:] = rnas["setting_list_border"].default_array
            pp.block[:] = rnas["block"].default_array
            pp.button[:] = rnas["button"].default_array

            P.ModifierEditor.area_list_inner = 8
        elif fac <= 1.34:
            pp.widget[:] = (24, 2, 8, 1)
            pp.title[:] = (36, 30)
            pp.border[:] = (5, 4, 1, 1)
            pp.dd_border[:] = (1, 1, 1)
            pp.filter[:] = (266, 2, 2, 2)
            pp.tb[:] = (36, 400, 4)
            pp.win_shadow_offset[:] = (-13, 27, -30, 8)
            pp.dd_shadow_offset[:] = (-8, 11, -15, 5)
            pp.shadow_softness[:] = (57, 20)
            pp.setting_list_border[:] = (11, 7, 1)
            pp.block[:] = (3, 3, 7, 7, 4, 20, 13, 1)
            pp.button[:] = (11, 1, 4, 340)

            P.ModifierEditor.area_list_inner = 11
        elif fac <= 1.67:
            pp.widget[:] = (30, 3, 10, 2)
            pp.title[:] = (45, 37)
            pp.border[:] = (7, 5, 2, 2)
            pp.dd_border[:] = (2, 2, 2)
            pp.filter[:] = (332, 3, 3, 3)
            pp.tb[:] = (45, 498, 5)
            pp.win_shadow_offset[:] = (-17, 33, -38, 10)
            pp.dd_shadow_offset[:] = (-10, 13, -18, 7)
            pp.shadow_softness[:] = (57, 20)
            pp.setting_list_border[:] = (13, 8, 2)
            pp.block[:] = (3, 3, 8, 8, 5, 25, 17, 2)
            pp.button[:] = (13, 2, 5, 425)

            P.ModifierEditor.area_list_inner = 13
        else:
            pp.widget[:] = (36, 4, 12, 2)
            pp.title[:] = (54, 44)
            pp.border[:] = (8, 6, 2, 2)
            pp.dd_border[:] = (2, 2, 2)
            pp.filter[:] = (400, 4, 4, 4)
            pp.tb[:] = (54, 600, 6)
            pp.win_shadow_offset[:] = (-20, 40, -46, 12)
            pp.dd_shadow_offset[:] = (-12, 16, -22, 8)
            pp.shadow_softness[:] = (57, 20)
            pp.setting_list_border[:] = (16, 10, 2)
            pp.block[:] = (4, 4, 10, 10, 6, 30, 20, 2)
            pp.button[:] = (16, 3, 6, 512)

            P.ModifierEditor.area_list_inner = 16

        blg.reload_icon()
        return {'FINISHED'}
    #|
    #|



## _import_first_ ##
def _import_first_():
    #|
    from .  import m

    # <<< 1forfile (_editor_,, $lambda _file_, _cls_: f'from . {_file_[1 : _file_.rfind(chr(92))].replace(".py", ""
    #     ).replace(chr(92), ".")}.{_file_[_file_.rfind(chr(92)) + 1 :].replace(".py", "")} import {_cls_}\n'$)
    from . apps.dreditor.ed import DriverEditor
    from . apps.mdeditor.ed import ModifierEditor
    from . apps.mesheditor.ed import MeshEditor
    from . apps.settingeditor.ed import SettingEditor
    # >>>

    D_EDITOR = {
        # <<< 1forfile (_editor_,, $lambda _file_, _cls_: f'"{_cls_}": {_cls_},\n'$)
        "DriverEditor": DriverEditor,
        "ModifierEditor": ModifierEditor,
        "MeshEditor": MeshEditor,
        "SettingEditor": SettingEditor,
        # >>>
    }

    EDITORS = [e for e in D_EDITOR]
    EDITORS.sort()


    register_ops = (
        OpsWinman,
        OpsEditor,
        OpsLoadFactory,
        OpsReloadIcon,
        OpsReloadFont,
        OpsUiScale,
    )
    globals().update(locals())
    #|

## _file_ ##
def _import_():
    #|
    import bpy

    from .  import m

    from . m import call_admin, kill_admin

    from . utilbl import blg

    globals().update(locals())
    #|
