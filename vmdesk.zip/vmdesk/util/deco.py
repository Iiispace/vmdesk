
def catch(func):
    def wrapper(*k, **kw):
        try: return func(*k, **kw)
        except Exception as e: return str(e)
    return wrapper
    #|
def catchNone(func):
    def wrapper(*k, **kw):
        try: return func(*k, **kw)
        except: return None
    return wrapper
    #|
def catchFalse(func):
    def wrapper(*k, **kw):
        try: return func(*k, **kw)
        except: return False
    return wrapper
    #|
def catchBug(func):
    def wrapper(*k, **kw):
        try: return func(*k, **kw)
        except Exception as e: print(str(e))
    return wrapper
    #|
def successResult(func):
    def wrapper(*k, **kw):
        try: return True, func(*k, **kw)
        except Exception as e: return False, str(e)
    return wrapper
    #|
def noRecursive(func):
    func.is_running = False
    def wrapper(*k, **kw):
        if func.is_running: return

        func.is_running = True
        try:
            result = func(*k, **kw)
        except Exception as ex:
            result = str(ex)



        func.is_running = False
        return result
    return wrapper
