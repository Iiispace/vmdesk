import bpy
from bpy.utils import escape_identifier
from bpy.types import CollectionProperty, BlendData

from .. util.deco import catchNone


def format_exception(ex):
    ss = str(ex).split('poll()', 1)
    return ss if len(ss) == 1 else ss[1].lstrip()
    #|

def r_obj_path_by_full_path(path):
    try:
        # names = {e.identifier for e in BlendData.bl_rna.properties  if isinstance(e, CollectionProperty)}

        ind_data = path.find("data.")

        ind_obj_start = ind_data + 5
        ind_obj_end = path.find("[", ind_obj_start)
        bpy_colls = getattr(bpy.data, path[ind_obj_start : ind_obj_end])

        ind_name_start = ind_obj_end + 1
        ind_name_end = path.find("]", ind_name_start)
        tar_obj = bpy_colls[path[ind_name_start + 1 : ind_name_end - 1]]
        dr_path = path[ind_name_end + 2 :]  if path[ind_name_end + 1] == "." else path[ind_name_end + 1 :]
        return tar_obj, dr_path
    except: return None, None
    #|
def r_ID_dp(obj):
    try:
        if obj.library:
            return f'bpy.data.{D_cls_blendData[obj.rna_type.identifier]}["{escape_identifier(obj.name)}", "{escape_identifier(obj.library.filepath)}"]'
        else:
            return f'bpy.data.{D_cls_blendData[obj.rna_type.identifier]}["{escape_identifier(obj.name)}"]'
    except:
        return ""
    #|

def r_add_to_keying_set(ob, dp, index=None, undo_push=True):
    try:
        keying_sets = bpy.context.scene.keying_sets
        act_ks = keying_sets.active
        if act_ks is None:
            act_ks = keying_sets.new(idname='Button Keying Set', name='Button Keying Set')
            # act_ks.use_insertkey_xyz_to_rgb = True # removed:4.1
            # act_ks.use_insertkey_override_xyz_to_rgb = True # removed:4.1

        kspath = act_ks.paths.add(ob, dp)
        if not kspath: return False, "Failed to add keying set, path may already exist"

        if index is not None:
            if index == "all":
                kspath.use_entire_array = True
            else:
                kspath.use_entire_array = False
                kspath.array_index = index
        keying_sets.active = keying_sets.active
        if undo_push:
            ed_undo_push(message="VMD Add to Keying Set")
        blg.report(f'Property added to Keying Set: "{act_ks.bl_idname}"')
        return True, ""
    except Exception as ex:
        return False, str(ex)
    #|
def r_remove_from_keying_set(ob, dp, index=None, undo_push=True):
    try:
        keying_sets = bpy.context.scene.keying_sets
        act_ks = keying_sets.active
        if act_ks is None:
            return False, "Keying Set not find"

        paths = act_ks.paths
        tag = False
        if index is None:
            for p in paths:
                if p.id != ob: continue
                if p.data_path != dp: continue
                paths.remove(p)
                tag = True
        elif index == "all":
            for p in paths:
                if p.id != ob: continue
                if p.data_path != dp: continue
                if p.use_entire_array:
                    paths.remove(p)
                    tag = True
        else:
            for p in paths:
                if p.id != ob: continue
                if p.data_path != dp: continue
                if p.use_entire_array: continue
                if p.array_index == index:
                    paths.remove(p)
                    tag = True

        if tag:
            keying_sets.active = keying_sets.active
            if undo_push:
                ed_undo_push(message="VMD Remove from Keying Set")
            blg.report(f'Property removed from Keying Set: "{act_ks.bl_idname}"')
            return True, ""
        else:
            return False, "Keying Set not find"
    except Exception as ex:
        return False, str(ex)
    #|

def r_library_or_override_message(ob):
    if hasattr(ob, "library") and ob.library:
        return "This operation cannot be performed\nfrom a linked data-block"
    if hasattr(ob, 'override_library') and ob.override_library and ob.override_library.is_system_override:
        return "This operation cannot be performed\nfrom a system override data-block"
    return ""
    #|
def r_library_editable(ob):
    if hasattr(ob, "library") and ob.library:
        return False
    if hasattr(ob, 'override_library') and ob.override_library and ob.override_library.is_system_override:
        return False
    return True
    #|
def is_allow_remove_modifier(ob, modifier):
    if ob.is_editable == False: return False
    if hasattr(modifier, "is_override_data") and modifier.is_override_data:
        if hasattr(ob, "override_library") and ob.override_library:
            return False
    return True
    #|

def datapath_split(dp):
    # 'modifiers["x.x"].hide'       'modifiers["x.x"]', 'hide'
    # 'location'                    '', 'location'
    # '["ab"]["x.\\"x"]'            '["ab"]', '["x.\\"x"]'

    if dp[-2 : ] == '"]':
        i0 = dp.rfind('["', 0, -2)
        if i0 == -1: return "", dp
        return dp[ : i0], dp[i0 : ]

    i0 = dp.rfind('.')
    if i0 == -1: return "", dp
    return dp[ : i0], dp[i0 + 1 : ]
    #|
def is_array_fcurve(ob, fc):
    try:
        v = ob.path_resolve(fc.data_path)
    except:
        return False

    if isinstance(v, str): return False
    return hasattr(v, "__len__")
    #|
def r_fcurve_name(ob, fc):
    at0, at1 = datapath_split(fc.data_path)

    if at0:
        try:
            ob = ob.path_resolve(at0)
        except:
            return None

    if hasattr(ob, "bl_rna"):
        rnas = ob.bl_rna.properties
        if at1 in rnas:
            rna = rnas[at1]
            if hasattr(rna, "name"):
                return rna.name

    return None
    #|

def is_allow_add_driver(ob, dp_head, attr, pp=None):
    try:
        if pp is None:
            if dp_head:
                pp = ob.path_resolve(dp_head[ : -1]  if dp_head[-1] == "." else dp_head)
            else:
                pp = ob

        if not pp:
            is_allow_add_driver.message = "Path not found"
            return False

        if attr in pp.bl_rna.properties:
            rna = pp.bl_rna.properties[attr]
            if hasattr(rna, "is_readonly") and rna.is_readonly:
                is_allow_add_driver.message = "Property is readonly"
                return False

            if hasattr(rna, "is_animatable") and rna.is_animatable == False:
                is_allow_add_driver.message = "Property is not animatable"
                return False

        is_override_library = True  if hasattr(ob, 'override_library') and ob.override_library else False

        if isinstance(pp, Modifier):
            if attr == "show_viewport":
                is_allow_add_driver.message = ""
                return True

            if attr in {"show_in_editmode", "show_on_cage", "use_apply_on_spline"}:
                if is_override_library and hasattr(pp, "is_override_data") and pp.is_override_data:
                    is_allow_add_driver.message = "Override data is not animatable"
                    return False

            if ob.is_editable == False or (is_override_library and ob.override_library.is_system_override):
                is_allow_add_driver.message = "Linked data is not animatable"
                return False
        else:
            if ob.is_editable == False or (is_override_library and ob.override_library.is_system_override):
                is_allow_add_driver.message = "Linked data is not animatable"
                return False

        is_allow_add_driver.message = ""
        return True
    except Exception as ex:
        is_allow_add_driver.message = str(ex)
        return False
    #|
@ catchNone
def r_driver_add_safe(ob, dp_head, attr, exp="var", index=None, use_variable=True):
    if dp_head:
        pp = ob.path_resolve(dp_head[ : -1]  if dp_head[-1] == "." else dp_head)
    else:
        pp = ob

    if is_allow_add_driver(ob, dp_head, attr, pp=pp) is False: return None

    if index is None:
        dr = tr_driver(ob, dp_head + attr)
        if dr: return None
        dr = pp.driver_add(attr)
    else:
        dr = pp.driver_add(attr, index)
        if dr: return None

    driver = dr.driver
    driver.type = 'SCRIPTED'
    if use_variable:
        if not driver.variables:
            v = driver.variables.new()
    else:
        if driver.variables:
            variables_remove = driver.variables.remove
            for e in driver.variables:
                variables_remove(e)

    driver.expression = exp
    return dr
    #|


def update_scene():
    bpy.context.scene.update_tag()
    P.refresh = True
    Admin.REDRAW()
    update_data()
    #|
def update_scene_push(push_message=""):
    bpy.context.scene.update_tag()
    P.refresh = True
    Admin.REDRAW()
    update_data()
    ed_undo_push(message=push_message)
    #|

class FakeDriverTarget:
    __slots__ = (
        'bone_target',
        'context_property',
        'data_path',
        'id',
        'id_type',
        'rotation_mode',
        'transform_space',
        'transform_type')
    #|
    #|
class FakeDriverVariable:
    __slots__ = (
        'is_name_valid',
        'name',
        'targets',
        'type')

    def __init__(self, len_target):
        self.targets = [FakeDriverTarget() for _ in range(len_target)]
        #|
    #|
    #|

def copy_driver_variable(v_from, v_to, copy_name=True):
    v_to.type   = v_from.type
    if copy_name:
        v_to.name   = v_from.name

    tar_to      = v_to.targets[0]
    tar_from    = v_from.targets[0]

    try:
        tar_to.id_type          = tar_from.id_type
    except: pass
    tar_to.id               = tar_from.id
    tar_to.data_path        = tar_from.data_path
    tar_to.rotation_mode    = tar_from.rotation_mode
    tar_to.transform_type   = tar_from.transform_type
    tar_to.transform_space  = tar_from.transform_space
    tar_to.bone_target      = tar_from.bone_target
    tar_to.context_property = tar_from.context_property

    if len(v_from.targets) == 2:
        tar_to      = v_to.targets[1]
        tar_from    = v_from.targets[1]

        try:
            tar_to.id_type          = tar_from.id_type
        except: pass
        tar_to.id               = tar_from.id
        tar_to.data_path        = tar_from.data_path
        tar_to.rotation_mode    = tar_from.rotation_mode
        tar_to.transform_type   = tar_from.transform_type
        tar_to.transform_space  = tar_from.transform_space
        tar_to.bone_target      = tar_from.bone_target
        tar_to.context_property = tar_from.context_property
    #|
def driver_var_move_to_index(var_name, index):
    variables = driver_var_move_to_index.variables
    old_index = variables.find(var_name)
    if old_index == index: return

    dic = {e: k  for k, e in variables.items()}
    temp_var = FakeDriverVariable(len(variables[old_index].targets))
    copy_driver_variable(variables[old_index], temp_var, False)

    if index > old_index:
        for r in range(old_index, index):
            dic[variables[r]] = variables[r + 1].name
            copy_driver_variable(variables[r + 1], variables[r], False)

        dic[variables[index]] = variables[old_index].name
        copy_driver_variable(temp_var, variables[index], False)
    else:
        for r in range(old_index, index, -1):
            dic[variables[r]] = variables[r - 1].name
            copy_driver_variable(variables[r - 1], variables[r], False)

        dic[variables[index]] = variables[old_index].name
        copy_driver_variable(temp_var, variables[index], False)


    name_set = {e  for e in dic.values()}
    for e in variables.values():
        i = 0
        while True:
            new_name = str(i)
            i += 1
            if new_name in name_set: continue

            e.name = new_name
            name_set.add(new_name)
            break

    for e in variables.values():
        e.name = dic[e]
    #|
def driver_var_name_set(variables, variable, name):
    if name in variables:
        i = 0
        while True:
            new_name = f"{name}_{i}"
            if len(new_name) >= 63:
                i = 0
                name = "var"
                new_name = f"{name}_{i}"
            if new_name in variables:
                i += 1
                continue

            variable.name = new_name
            break
        return False
    else:
        variable.name = name
        return True
    #|


## _file_ ##
def _import_():
    #|
    import bpy
    Modifier = bpy.types.Modifier

    from .. api import D_cls_blendData
    from .. m import (
        P,
        Admin,
        update_data,
    )

    from . import blg
    from . md import tr_driver

    ed_undo_push = bpy.ops.ed.undo_push

    globals().update(locals())
    #|
