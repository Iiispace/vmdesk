import bpy

from bpy.types import Operator
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty

## _reg_ ##
class OpInternal(Operator):
    __slots__ = ()
    bl_idname = "wm.vmd_internal"
    bl_label = "VMD Internal"
    bl_options = {'INTERNAL'}

    MAIN = None

    def invoke(self, context, event):

        OpInternal.MAIN()
        return {'FINISHED'}
        #|
    #|
    #|
## _reg_ ##
class OpBevelProfile(Operator):
    bl_idname = "wm.vmd_bevel_profile"
    bl_label = "Custom Profile"
    bl_options = {'INTERNAL'}

    md = None

    def execute(self, context): return {'FINISHED'}
    def invoke(self, context, event): return context.window_manager.invoke_props_dialog(self)
    def draw(self, context): self.layout.template_curveprofile(OpBevelProfile.md, "custom_profile")
    #|
    #|
## _reg_ ##
class OpFalloffCurve(Operator):
    bl_idname = "wm.vmd_falloff_curve"
    bl_label = "Falloff Curve"
    bl_options = {'INTERNAL'}

    md = None
    attr = None

    def execute(self, context): return {'FINISHED'}
    def invoke(self, context, event): return context.window_manager.invoke_props_dialog(self)
    def draw(self, context): self.layout.template_curve_mapping(OpFalloffCurve.md, OpFalloffCurve.attr)
    #|
    #|
## _reg_ ##
class OpColorRamp(Operator):
    bl_idname = "wm.vmd_color_ramp"
    bl_label = "Color Ramp"
    bl_options = {'INTERNAL'}

    md = None
    attr = None

    def execute(self, context): return {'FINISHED'}
    def invoke(self, context, event): return context.window_manager.invoke_props_dialog(self)
    def draw(self, context): self.layout.template_color_ramp(OpColorRamp.md, OpColorRamp.attr)
    #|
    #|
## _reg_ ##
class OpScanFile(Operator):
    bl_idname = "wm.vmd_scan_file"
    bl_label = "Accept"
    bl_options = {'INTERNAL'}
    filepath: StringProperty(subtype="FILE_PATH", default="")
    check_existing: BoolProperty(default=False, options={"HIDDEN"})

    end_fn = None

    def execute(self, context):
        self.check_existing = True
        try:    self.fin(self.filepath)
        except: pass
        return {'FINISHED'}

    def invoke(self, context, event):
        self.fin = OpScanFile.end_fn
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    #|
    #|
## _reg_ ##
class OpScanFolder(Operator):
    bl_idname = "wm.vmd_scan_folder"
    bl_label = "Accept"
    bl_options = {'INTERNAL'}

    end_fn = None

    directory: StringProperty(name="Directory", description="Folder Directory")
    filter_folder: BoolProperty(default=True, options={"HIDDEN"})

    def execute(self, context):
        try:    self.fin(self.directory)
        except: pass
        return {'FINISHED'}

    def invoke(self, context, event):
        self.fin = OpScanFolder.end_fn
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    #|
    #|
## _reg_ ##
class OpsIDPreview(Operator):
    __slots__ = '_ID', '_scale_y', '_show_name'
    bl_idname = "wm.vmd_id_preview"
    bl_label = "ID Preview"
    bl_options = {'INTERNAL'}

    ID = None
    scale_y = 1.0
    show_name = False

    preview_scale: FloatProperty(min=1.0, max=8.0)

    def __del__(self):
        self.__class__.ID = None

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        cls = self.__class__
        cls.scale_y = 0.95  if cls.scale_y == 1.0 else 1.0
        self._ID = cls.ID
        self._show_name = cls.show_name
        self._scale_y = cls.scale_y * self.preview_scale
        return context.window_manager.invoke_popup(self, width=round(150 * self.preview_scale))

    def draw(self, context):
        if self._show_name:
            self.layout.label(text=self._ID.name)
        self.layout.scale_y = self._scale_y
        self.layout.template_preview(self._ID, show_buttons=False)
    #|
    #|

## _reg_ ##
class OpsWrapperRelease(Operator):
    __slots__ = 'keytypes'
    bl_idname = "wm.vmd_wrapper_release"
    bl_label = "VMD Wrapper Release"
    bl_options = {'REGISTER', 'BLOCKING'}

    idname: StringProperty(name="ID Name", description="Operator ID name", options={"HIDDEN"})
    use_invoke: BoolProperty(name="Use Invoke Default", options={"HIDDEN"})
    undopush: StringProperty(name="Undo Push", options={"HIDDEN"})
    keytype0: StringProperty(name="Key Type 0", options={"HIDDEN"})
    keytype1: StringProperty(name="Key Type 1", options={"HIDDEN"})
    keytype2: StringProperty(name="Key Type 2", options={"HIDDEN"})

    def execute(self, context):
        try:
            ats = self.idname.split(".")

            e = bpy.ops
            for at in ats:
                if hasattr(e, at):
                    e = getattr(e, at)

            e("INVOKE_DEFAULT")  if self.use_invoke is True else e()
        except Exception as ex:
            try:
                self.report({'WARNING'}, str(ex))
            except: pass

        keytypes = set()
        if self.keytype0: keytypes.add(self.keytype0)
        if self.keytype1: keytypes.add(self.keytype1)
        if self.keytype2: keytypes.add(self.keytype2)

        self.keytypes = keytypes
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
        #|

    def fin(self):
        if self.undopush: bpy.ops.ed.undo_push(message=self.undopush)
        return {'FINISHED'}
        #|

    def modal(self, context, event):
        if event.type == "ESC": return self.fin()
        if event.value == "RELEASE":
            if event.type in self.keytypes:
                self.keytypes.remove(event.type)

        if self.keytypes: return {'RUNNING_MODAL'}
        return self.fin()
        #|
    #|
    #|
