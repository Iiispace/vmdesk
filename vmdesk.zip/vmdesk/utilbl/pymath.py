import bpy
from math import *

def calc_py_exp(s):
    try:    return eval(s)
    except: return None
