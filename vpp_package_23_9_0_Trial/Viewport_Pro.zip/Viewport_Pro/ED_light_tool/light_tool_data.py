import bpy, bmesh
from blf import size as blf_size

from .. import m
from .. m import BOX, BLF
from .. win_cls import AREA

from . light_tool_block import B_DEFAULT, B_LIGHT

P = None
F = None
font_0 = None

class DATA_DEFAULT(AREA):
    __slots__ = 'data'
    def R_bo_data(self): return self.w.bo["me_info"]
    def get_data(self):
        self.data = {}
        self.oo_keys = [B_DEFAULT(self), B_LIGHT(self)]
    def upd_data(self):
        b_default, b_light = self.oo.values()

        if self.w.obj_mode == "EDIT":
            s = bpy.context.scene.statistics(bpy.context.view_layer)
            i0 = s.find("Faces")
            if i0 == -1:    b_default.oo[0].ti.text = "Selected Faces :  0"
            else:
                i0 += 6
                b_default.oo[0].ti.text = f'Selected Faces :  {s[i0 : s.find("/", i0)]}'
        else:
            b_default.oo[0].ti.text = "Selected Faces"

        if self.w.props["light_tool_ed_use_collection"]:
            if b_default.oo[7].is_enable is False:
                b_default.oo[7].enable()
        else:
            if b_default.oo[7].is_enable is True:
                b_default.oo[7].disable()

        # <<< 1copy (0light_tool_block_lights,, $$)
        lights = [e_ for e_ in bpy.context.selected_objects if e_.type in {"LIGHT", "LIGHT_PROBE"}]
        # >>>
        oo_ti, oo_dis, oo_init = b_light.oo
        if lights:
            if oo_dis.is_enable is False:
                oo_dis.enable()
                oo_init.enable()

            ll = len(lights)
            oo_ti.ti.text = f"Selected Lights :  {ll}"

            if len(lights) == 1:
                if oo_dis.ti != "Offset":
                    oo_dis.ti.text = "Offset"
                    blf_size(font_0, F[9])
                    oo_dis.get_bo(*oo_dis.rim[0].R_LRBT())

                b_light.props["offset"][:] = lights[0].vpp_offset
            else:
                if oo_dis.ti.text != "Avg Offset":
                    oo_dis.ti.text = "Avg Offset"
                    blf_size(font_0, F[9])
                    oo_dis.get_bo(*oo_dis.rim[0].R_LRBT())

                try:
                    vs = [0, 0, 0]
                    for light in lights:
                        vs[0] += light.vpp_offset[0]
                        vs[1] += light.vpp_offset[1]
                        vs[2] += light.vpp_offset[2]

                    b_light.props["offset"][:] = vs[0] / ll, vs[1] / ll, vs[2] / ll
                except:
                    b_light.props["offset"][:] = 0.0, 0.0, 0.0
        else:
            if oo_dis.is_enable is True:
                oo_dis.disable()
                oo_init.disable()

            oo_ti.ti.text = "Selected Lights"

        b_default.upd_oo()
        b_light.upd_oo()

    def get_face_data(self, oj):
        data = self.data
        data.clear()

        if oj.mode == "OBJECT":
            data["oj"] = oj
            polygons = {}
            ll_faces = 0
            is_act_oj_selected = False
            for o in bpy.context.selected_objects:
                if o.type != "MESH": continue
                if o == oj: is_act_oj_selected = True
                ee = [e for e in o.data.polygons if e.select]
                polygons[o] = ee
                ll_faces += len(ee)
            if is_act_oj_selected is False:
                o = oj
                ee = [e for e in o.data.polygons if e.select]
                polygons[o] = ee
                ll_faces += len(ee)

            if polygons:    data["polygons"] = polygons
            data["ll_faces"] = ll_faces
            data["ll_act_faces"] = len(polygons[oj])
        else:
            self.kill_data()

