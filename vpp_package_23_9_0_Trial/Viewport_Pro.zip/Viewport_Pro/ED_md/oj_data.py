import bpy
from blf import size as blf_size

from .. import m
from .. bu import BU, BUTI, BUDA, BUDA_RENAME, TI_TYPE
from .. dd import DDTX_FN, DDTX_RENAME
from .. filt import FIL_TYPE_EXC
from .. fn import T_set_context_object, TR_object, R_lib_tuple

P = None
F = None
N = None
BOX = None
font_0 = None

class OJ:
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'sci',
        'oo',
        'oo_free',
        'oo_12',
        'oo_9',
    )
    def __init__(self, w):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.sci            = w.sci

        self.oo = {
            "ti_oj":        BUTI(self, "ti_oj", "OBJECT", self.bu_fn_ti_oj),
            "ti_md":        BUTI(self, "ti_md", "MODIFIER", self.bu_fn_ti_md),
            "ti_type":      TI_TYPE(self, "ti_type", "OBJ TYPE    "),
            "ti_sync":      TI_TYPE(self, "ti_sync", "Sync Active"),
            "ti_lib":       TI_TYPE(self, "ti_lib", ""),
            "da_oj":        BUDA_RENAME(self, "da_oj", self.bu_fn_da_oj),
            "da_md":        BUDA_RENAME(self, "da_md", self.bu_fn_da_md),
            "bu_sync_oj":   BU(self, "bu_sync_oj", "Object", self.bu_fn_sync_oj, offset_y_key=6),
            "bu_sync_md":   BU(self, "bu_sync_md", "Modifier", self.bu_fn_sync_md, offset_y_key=6),
        }
        self.oo["da_oj"].enable_half_size_method()
        self.oo["da_md"].enable_half_size_method()

        self.oo_free = {self.oo[k] for k in {
            "da_oj",
            "da_md",
        }}
        self.oo_12 = {self.oo[k] for k in {
            "ti_oj",
            "ti_md",
        }}
        self.oo_9 = {self.oo[k] for k in {
            "ti_type",
            "ti_sync",
            "ti_lib",
            "bu_sync_oj",
            "bu_sync_md",
        }}

    def get_bo(self):
        oo  = self.oo
        w   = self.w
        bo  = w.bo
        x   = bo["oj_info"].L
        y   = bo["oj_info"].T

        blf_size(font_0, F[12])
        L   = x + F[8]
        B   = y - F[21]
        oo["ti_oj"].LBT(L, B, B + F[15], 3.8)
        B   = oo["ti_oj"].rim.B - F[18.1]
        oo["ti_md"].LBT(L, B, B + F[15], 3.8)
        rim = oo["ti_oj"].rim
        L   = rim.L + F[82] + F[3]
        R   = bo["oj_info"].R - F[7]
        oo["da_oj"].LRBT(L, R, rim.B, rim.T, 3.8)
        oo["da_oj"].upd_half_size(R)
        rim = oo["ti_md"].rim
        oo["da_md"].LRBT(L, R, rim.B, rim.T, 3.8)
        oo["da_md"].upd_half_size(R)

        blf_size(font_0, F[9])
        oo["ti_type"].xy(rim.L + F[1], B - F[16])
        R   = bo["md_info"].R - F[6]
        B   = round(oo["ti_type"].ti.y) - F[7]
        wi  = F[46] + F[2]
        oo["bu_sync_md"].LRBT(R - wi, R, B, B + F[18])
        oo["bu_sync_oj"].before_bu(oo["bu_sync_md"], wi)
        oo["ti_sync"].before_bu(oo["bu_sync_oj"], dx=9, dy=7)
        oo["ti_lib"].xy(0, oo["ti_type"].ti.y)

        bo["oj_info"].B = oo["bu_sync_oj"].rim.B - F[3]

        if w.I_upd_data == w.I_upd_data_follow:     oo["bu_sync_oj"].on()
        if w.U_upd_act_ob == w.I_upd_act_md_sync:   oo["bu_sync_md"].on()

    def dxy_upd(self, x, y):
        for e in self.oo.values():  e.dxy_upd(x, y)

    def I_modal_main(self, evt):
        self.RET = False
        oo  = self.oo
        x   = evt.mouse_region_x
        y   = evt.mouse_region_y

        if y > oo["ti_oj"].rim.T:       return self.RET
        if y >= oo["ti_oj"].rim.B:
            if oo["ti_oj"].rim.in_LR_x(x):      oo["ti_oj"].inside(evt)
            elif oo["da_oj"].rim.in_LR_x(x):    oo["da_oj"].inside(evt)
            return self.RET

        if y > oo["ti_md"].rim.T:       return self.RET
        if y >= oo["ti_md"].rim.B:
            if oo["ti_md"].rim.in_LR_x(x):      oo["ti_md"].inside(evt)
            elif oo["da_md"].rim.in_LR_x(x):    oo["da_md"].inside(evt)
            return self.RET

        if y > oo["bu_sync_oj"].rim.T:  return self.RET
        if y >= oo["bu_sync_oj"].rim.B:
            if oo["bu_sync_oj"].rim.in_LR_x(x):     oo["bu_sync_oj"].inside(evt)
            elif oo["bu_sync_md"].rim.in_LR_x(x):   oo["bu_sync_md"].inside(evt)
            return self.RET

        return self.RET

    def bu_fn_ti_oj(self):

        w = self.w
        w.I_upd_data()
        r = self.oo["da_oj"].rim
        L = round(r.L)
        R = L + round(P.dd_width * P.scale[0])
        T = round(r.T)

        def confirm_fn(tx):

            tx = R_lib_tuple(bpy.data.objects, tx)
            if w.I_upd_data == w.I_upd_data_follow:
                T_set_context_object(tx)
                m.undo_str = '[Modifier Editor] change active object'
                m.undo_push()
            else:
                ob = TR_object(tx)
                if ob is None:  return

                w.kill_data()
                w.oj    = ob
                self.oo["da_oj"].da.text = ob.name
            w.I_upd_data()

        DDTX_FN(
            m.EVT.evt,
            w.oj.name  if w.oj else "",
            FIL_TYPE_EXC(bpy.data.objects),
            (L, R, T - F[16], T),
            confirm_fn,
            tx_clear = True
        )
    def bu_fn_ti_md(self):

        w = self.w
        w.I_upd_data()
        r = self.oo["da_md"].rim
        L = round(r.L)
        R = L + round(P.dd_width * P.scale[0])
        T = round(r.T)

        def confirm_fn(tx):

            w_mods = w.A_mods
            if w_mods.obs:
                ind = w_mods.obs.find(tx)
                if ind != -1:
                    w_mods.sel_by_ind(ind)

        DDTX_FN(
            m.EVT.evt,
            w.act_md.name  if w.act_md else "",
            FIL_TYPE_EXC(w.A_mods.obs  if w.oj else ()),
            (L, R, T - F[16], T),
            confirm_fn,
            tx_clear = True
        )
    def bu_fn_da_oj(self):

        w   = self.w
        w.I_upd_data()
        ob  = w.oj
        if ob is None:  return

        DDTX_RENAME(
            m.EVT.evt,
            ob.name,
            (ob, "name"),
            FIL_TYPE_EXC(bpy.data.objects),
            target          = f'objects["{ob.name}"].name',
            confirm_upd     = N
        )
    def bu_fn_da_md(self):

        w   = self.w
        w.I_upd_data()
        md  = w.act_md
        if md is None:  return

        DDTX_RENAME(
            m.EVT.evt,
            md.name,
            (md, "name"),
            FIL_TYPE_EXC(w.A_mods.obs),
            target          = f'modifiers["{md.name}"].name',
            full_path_head  = f'bpy.data.objects["{w.oj.name}"].',
            confirm_upd     = w.I_upd_data
        )
    def bu_fn_sync_oj(self):

        w = self.w
        if w.I_upd_data == w.I_upd_data_follow:
            w.I_upd_data = w.I_upd_data_lock
            self.oo["ti_oj"].off()
        else:
            w.I_upd_data = w.I_upd_data_follow
            self.oo["ti_oj"].on()
        if w.upd_data != N:   w.upd_data = w.I_upd_data
        w.I_upd_data()
    def bu_fn_sync_md(self):

        w = self.w
        if w.U_upd_act_ob == w.I_upd_act_md_sync:   self.do_unsync_md()
        else:   self.do_sync_md()
        w.I_upd_data()

    def do_sync_md(self):
        w = self.w
        w.U_upd_act_ob = w.I_upd_act_md_sync
        w.A_mods.set_act = w.A_mods.I_set_act_sync
        self.oo["ti_md"].on()
        self.oo["bu_sync_md"].on()
    def do_unsync_md(self):
        w = self.w
        w.U_upd_act_ob = w.I_upd_act_md_unsync
        w.A_mods.set_act = w.A_mods.I_set_act_unsync
        self.oo["ti_md"].off()
        self.oo["bu_sync_md"].off()

    def I_draw(self):
        m.bind_color_bu_1_rim()
        for e in self.oo.values():   e.draw_rim()
        for e in self.oo.values():   e.draw_bg()

        blf_size(font_0, F[12])
        for e in self.oo_12:    e.draw_ti()
        blf_size(font_0, F[9])
        for e in self.oo_9:     e.draw_ti()
        for e in self.oo_free:  e.draw_ti()

    def upd_data(self):
        w   = self.w
        oo  = self.oo
        R   = w.bo["oj_info"].R - F[7]
        if w.oj == None:
            oo["da_oj"].upd_da_half_size("", R)
            oo["ti_type"].upd_val("")
            oo["da_md"].upd_da_half_size("", R)
            oo["ti_lib"].upd_val("")
        else:
            oo["da_oj"].upd_da_half_size(w.oj.name, R)
            oo["ti_type"].upd_val(w.oj.type)
            oo["da_md"].upd_da_half_size(w.act_md.name if w.act_md else "", R)

            if w.oj.library:
                s = w.oj.library.filepath
                if oo["ti_lib"].ti.size != s:

                    e = oo["ti_lib"].ti
                    e.size = s
                    e.text = s
                    blf_size(font_0, F[9])
                    RR = w.bo["oj_info"].R - F[8]
                    e.align_R(RR)
                    e.fix_long_text_L(oo["bu_sync_md"].rim.R + F[6], F[12])
                    e.align_R(RR)
            else:
                oo["ti_lib"].upd_val("")
