import bpy
from pathlib import Path

from . import m
from . fn import R_blends_by_path, FAKE_OBJECT_LINK

def upd_geo_lib():
    try:

        P = m.P
        geo_lib_path = m.geo_lib_path
        libs = bpy.data.libraries
        old_libs = set(libs)
        nodes = bpy.data.node_groups

        geo_lib_path.clear()
        blends = R_blends_by_path(Path(P.geo_lib_path))

        if P.geo_lib_filter:
            tx = P.geo_lib_filter
            def filter_fx(name):
                try:    return eval(tx)
                except: return False
        else:
            filter_fx = lambda name: True

        for blend_path in blends:
            try:
                old_nodes = set(nodes)

                with libs.load(blend_path, link=True) as (data_from, data_to):
                    data_to.node_groups = data_from.node_groups

                names = set()
                if P.geo_lib_mark_only:
                    for node in set(nodes).difference(old_nodes):
                        if node.type == "GEOMETRY":
                            if node.asset_data:
                                if filter_fx(node.name):
                                    names.add(FAKE_OBJECT_LINK(node.name, blend_path))
                        nodes.remove(node)
                else:
                    for node in set(nodes).difference(old_nodes):
                        if node.type == "GEOMETRY":
                            if filter_fx(node.name):
                                names.add(FAKE_OBJECT_LINK(node.name, blend_path))
                        nodes.remove(node)
                geo_lib_path[blend_path] = names
            except:
                geo_lib_path[blend_path] = set()

        for e in set(libs).difference(old_libs):
            libs.remove(e)

        return True
    except:
        return False