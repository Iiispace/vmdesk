import bpy, math, time
from contextlib import redirect_stdout
from blf import size as blf_size
from bpy.app.timers import register as thread_reg
from bpy.app.timers import unregister as thread_unreg
from gpu.shader import from_builtin

from . import m, win_mess
from . link_data import copy_md_driver, copy_md_kf, TR_drivers, TR_action_fcurves, TR_dr_add, link_modifier, deep_link_modifier, D_only_one
from . dd import DDTX_RENAME
from . filt import FIL

P = None
F = None
K = None
N = None
BOX = None
BLF = None
font_0 = None
str_unsort = "Unable to sort library modifiers."
str_undel = "Unable to remove library modifiers."
str_unapply = "Unable to apply library modifiers."
str_uncopy = "Unable to add library modifiers."


class BOX_ACT:
    __slots__ = "rim", "bg", "ind"
    def __init__(self):
        self.rim = BOX(P.color_box_mod_act_rim)
        self.bg = BOX(P.color_box_mod_act)
        self.ind = None

    def init(self, L, R):
        _1 = F[1]
        self.rim.L = L
        self.rim.R = R
        self.bg.L = L + _1
        self.bg.R = R - _1
        self.rim.upd()
        self.bg.upd()
    def get(self, cv, i):
        T = cv.T  if i == -1 else cv.T - F[-999] * i
        B = T - F[-911] + F[1]
        T -= F[1]
        rim = self.rim
        bg = self.bg
        rim.B = B
        rim.T = T
        bg.B = rim.B + F[1]
        bg.T = rim.T - F[1]
        rim.upd()
        bg.upd()

    def upd_check(self, w, cv, i): # i != -1
        if i == self.ind:   return
        old = self.ind
        if old in w.sel_range:  del w.sel_range[old]
        w.sel_range[i] = None
        w.get_draw_ind_by_sel_range()
        self.ind = i
        self.get(cv, i)

    def disable(self):
        if self.ind is None:    return
        self.ind = None
        r = self.rim
        b = self.bg
        r.B = r.T = b.B = b.T = 0
        r.upd()
        b.upd()

    def U_draw(self):
        self.rim.bind_draw()
        self.bg.bind_draw()

class MD_POP_MULTI:
    __slots__ = "rim", "bg", "bo", "name", "amt"
    def __init__(self, L, R, B, T, ll): # bg
        _1              = F[1]
        _d              = F[2]
        _dd             = F[5]
        self.bg         = BOX(P.color_box_mod_sel, L, R, B, T)
        self.bg.upd()
        self.rim        = BOX(P.color_bg_mod, L - _1, R + _1, B - _1, T + _1)
        self.rim.upd()
        self.bo         = BOX(P.color_box_mod, L + _d, R - F[61], B + _d, T - _d)
        self.bo.upd()
        self.name       = BLF(P.color_font, "Multi Group", "Multi Group", L + _dd, B + _dd)
        self.amt        = BLF(P.color_font, f'{ll} items', ll, self.bo.R + F[8], B + _dd)

    def dxy_upd(self, x, y):
        self.bg.dxy_upd(x, y)
        self.rim.dxy_upd(x, y)
        self.bo.dxy_upd(x, y)
        self.name.dxy(x, y)
        self.amt.dxy(x, y)
    # def dxy_upd_init(self, x, y):
    #     e = self.bg
    #     e.dxy(x, y)
    #     self.rim.dxy_upd(x, y)
    #     self.bo.dxy_upd(x, y)
    #     self.name.dxy(x, y)
    #     self.amt.dxy(x, y)

    def U_draw(self):
        BLEND()
        self.rim.bind_draw()
        self.bg.bind_draw()
        self.bo.bind_draw()
        blf_size(font_0, F[10])
        self.name.draw_color_pos()
        blf_size(font_0, F[8])
        self.amt.draw_color_pos()

    def thread_color_kill(self, thread_li, v):
        self.rim.color  = [*self.rim.color]
        self.bg.color   = [*self.bg.color]
        self.bo.color   = [*self.bo.color]
        self.name.color = [*self.name.color]
        self.amt.color  = [*self.amt.color]
        colors = [
            self.rim.color,
            self.bg.color,
            self.bo.color,
            self.name.color,
            self.amt.color
        ]
        thread_li["pop_color"] = AN_color_0(colors, None, v)



class LL:
    __slots__ = (
        'color_bg_desel',
        'color_bg_sel',
        'color_num',
        'w',
        'w_oj',
        'max_ll',
        'li_type',
        'y',
        'hi',
        'sci',
        'cv',
        'ind_sel',
        'ind_desel',
        'sel_range',
        'U_draw',
        'U_modal',
        'U_modal_thread',
        'U_mt_modal',
        'actbox',
        'md_h',
        'md_hi',
        'd_cy',
        'obs',
        'll_bpy',
        'ref',
        'li',
        'll_li',
        'headkey',
        'endkey',
        'tm_autoB',
        'tm_autoT',
        'tm_pan_speed',
        'tm_syslimdn',
        'tm_syslimup',
        'tm_limyup',
        'tm_ind',
        'tm_dif',
        'tm_selbox',
        'tm_an_speed',
        'tm_unit_speed',
        'tm_pop_ind',
        'tm_pop_ind_org',
        'tm_pop_ind_old',
        'tm_pop_dxy_fn',
        'tm_sel_name',
        'tm_pop',
        'tm_table',
        'tm_evt_region',
        'tm_oj_name',
        'tm_md_name',
        'tm_mouse',
        'tm_obs',
        'll_tm_sel',
        'region_L',
        'region_R',
        'region_B',
        'region_T',
        'region_win_L',
        'region_win_R',
        'region_win_B',
        'region_win_T',
        'region_apply_B',
        'mt_wins',
        'mt_win',
        'mt_win_mods',
        'frame_time',
        'threads',
        'thread_li_y',
        'thread_sep',
        'context_object',
        'bpy_ops_init_mode',
        'context_selected',
        'key_end',
        'modal_mode',
        'modal_sort_fin_D1',
        'job_ind',
        'top_win',
        'set_act',
        'drivers',
        'fcurves',
        'is_draw_bu_focus',
    )
    def __init__(self, w, L, R, T, hi, ll_li=28):
        self.color_bg_desel = P.color_box_mod
        self.color_bg_sel   = P.color_box_mod_sel
        self.color_num      = P.color_font_mod_num

        self.w              = w
        self.hi             = hi
        self.max_ll         = ll_li
        self.y              = T
        self.sci            = m.SCISSOR()
        self.upd_sci()
        self.cv             = m.CANVAS_Y(P.color_bg_mod, L, R, T, T)

        self.ind_sel        = {}
        self.ind_desel      = {}
        self.sel_range      = {}
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.U_modal_thread = None
        self.actbox         = BOX_ACT()

        self.md_h           = F[-911]
        self.md_hi          = F[-999]
        self.d_cy           = F[-997]

        self.is_draw_bu_focus   = False

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def upd_sci(self):
        y_default   = self.R_y_default()
        sci         = self.sci
        wsci        = self.w.sci
        sci.x       = wsci.x
        sci.w       = wsci.w
        sci.y       = max(y_default - self.hi, wsci.y)
        y2          = min(y_default, wsci.y + wsci.h)
        sci.h       = 0  if y2 < sci.y else y2 - sci.y

    def get_draw_ind_by_sel_range(self):
        self.ind_sel    = {k : None  for k in self.li if k in self.sel_range}
        self.ind_desel  = {k : None  for k in self.li if k not in self.ind_sel}

    def glopan_end_fn(self):

        self.ref.upd()
        self.w.I_upd_data()
        m.redraw()

    def R_headkey(self): # self.ll_li != 0
        d = self.cv.T - self.y
        return int(max(0, d // self.md_hi - 1  if d % self.md_hi == 0 else d // self.md_hi))
    def R_endkey(self): # self.ll_li
        d = self.cv.T - self.y
        headkey = int(max(0, d // self.md_hi - 1  if d % self.md_hi == 0 else d // self.md_hi))
        return headkey + self.ll_li - 1
    def R_headkey_endkey(self): # self.ll_li
        d = self.cv.T - self.y
        headkey = int(max(0, d // self.md_hi - 1  if d % self.md_hi == 0 else d // self.md_hi))
        return headkey, headkey + self.ll_li - 1

    def R_act_ind(self):
        try:    return self.obs.find(self.w.act_md.name)
        except: return -1
    def R_ind_by_name(self, name):
        return self.obs.find(name)

    def R_ind_by_mou(self, y):
        return int((self.cv.T - y) // self.md_hi)
    def R_ind_by_mou_safe(self, y):
        i = int((self.cv.T - y) // self.md_hi)
        return i  if 0 <= i < self.ll_bpy else None

    def get_auto_pan_data(self):
        self.tm_autoB       = self.sci.y + F[2]
        self.tm_autoT       = self.sci.R_T() - F[2]
        self.tm_pan_speed   = max(0.00001, P.auto_pan_speed * self.ll_bpy)

        cvh                 = self.cv.R_h()
        self.tm_syslimdn    = self.sci.R_T()
        self.tm_syslimup    = self.tm_syslimdn + max(0, min(cvh, self.hi) - self.sci.h)
        self.tm_limyup      = self.y + max(0, cvh - self.hi)
        self.tm_ind         = self.R_act_ind()

    def is_inside(self, evt):
        if self.cv.L <= evt.mouse_region_x <= self.cv.R:
            if self.sci.y <= evt.mouse_region_y <= self.y:  return True
        return False
    def is_link_area(self, evt):
        if self.cv.L <= evt.mouse_region_x <= self.cv.R:
            if self.w.box["rim"].B <= evt.mouse_region_y <= self.sci.R_T() + self.md_hi:  return True
        return False

    def init_thread(self):
        if self.U_modal_thread is None:
            self.U_modal_thread = self.I_modal_thread
            self.frame_time     = P.anim_frame_time
            self.thread_li_y    = {}
            self.thread_sep     = {}
            thread_reg(self.U_modal_thread)

    def kill_thread(self):
        if self.U_modal_thread is not None:
            thread_unreg(self.U_modal_thread)
            self.U_modal_thread = None


    def bpy_ops_init(self): # fail when object hidden
        self.context_object = bpy.context.object
        if self.context_object.mode != "OBJECT":
            self.bpy_ops_init_mode = (False, self.context_object.mode)
            bpy.ops.object.mode_set(mode = 'OBJECT')
        else:
            self.bpy_ops_init_mode = (False, False)
        m.set_active_object(self.w.oj)
    def bpy_ops_select_init(self): # fail when object hidden
        self.context_object = bpy.context.object
        if self.context_object.mode != "OBJECT":
            self.bpy_ops_init_mode = (True, self.context_object.mode)
            bpy.ops.object.mode_set(mode = 'OBJECT')
        else:
            self.bpy_ops_init_mode = (True, False)
        self.context_selected = bpy.context.selected_objects
        for e in self.context_selected: e.select_set(False)
        m.set_active_object(self.w.oj)
    def bpy_ops_end(self):
        is_rev_select, rev_mode = self.bpy_ops_init_mode
        if is_rev_select is True:
            for e in bpy.context.selected_objects:  e.select_set(False)
            for e in self.context_selected:         e.select_set(True)
            del self.context_selected
        m.set_active_object(self.context_object)
        if rev_mode in {'OBJECT', 'EDIT', 'SCULPT', 'VERTEX_PAINT', 'WEIGHT_PAINT', 'TEXTURE_PAINT'}:
            bpy.ops.object.mode_set(mode = rev_mode)

        m.undo_push()


    def poll(self):
        self.w.I_upd_data()
        if self.ll_bpy == 0:    return True
        return False
    def call_win_not_match(self, x, y, hide_tb = True):
        if x is None:   x, y = self.top_win.R_center_pos()
        win_mess.MESS(x, y, "Some modifiers must on top.", hide_tb = hide_tb)

    def copy_kf(self, oj, oj_tar, tar_md, dp, dp_tar):
        fcurves = TR_action_fcurves(oj)
        if fcurves:
            for attr in dir(tar_md):
                fc = fcurves.find(dp + attr)
                if fc is not None:  copy_md_kf(fc, oj_tar, dp_tar + attr)
    def copy_dr(self, oj, oj_tar, tar_md, dp, dp_tar):
        drivers = TR_drivers(oj)
        if drivers:
            for attr in dir(tar_md):
                dr = drivers.find(dp + attr)
                if dr is not None:  copy_md_driver(dr, oj_tar, dp_tar + attr)

    def off_show_viewport(self, modifiers):
        if "show_viewport" not in win_mess.TM:
            dic = {}
            win_mess.TM["show_viewport"] = dic
        else:
            dic = win_mess.TM["show_viewport"]
        for e in reversed(modifiers):
            dic[e]              = e.show_viewport
            e.show_viewport     = False

    def multi_user_do(self, oj):
        me          = oj.data
        users       = [o for o in bpy.data.objects if o.data == me and o != oj]
        tm_mesh     = bpy.data.meshes.new("tm_mesh")
        for user in users:  user.data = tm_mesh
        return me, users, tm_mesh
    def multi_user_restore(self, me, users, tm_mesh):
        for user in users:  user.data = me
        bpy.data.meshes.remove(tm_mesh)
        users.clear()

# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_modal_main(self, evt):
        if K["me_pan0"].true():
            self.key_end = K["me_pan_E0"]  ;self.to_modal_pan(evt)  ;return True
        if K["me_pan1"].true():
            self.key_end = K["me_pan_E1"]  ;self.to_modal_pan(evt)  ;return True
        if self.sub_modal(evt): return True

        if K["me_rename0"].true():      self.evt_rename(evt)    ;return True
        if K["me_rename1"].true():      self.evt_rename(evt)    ;return True
        if K["me_sel_ext0"].true():     self.do_modal_sel_ext(evt)  ;return True
        if K["me_sel_ext1"].true():     self.do_modal_sel_ext(evt)  ;return True
        if K["me_sel0"].true():         self.do_modal_sel(evt)  ;return True
        if K["me_sel1"].true():         self.do_modal_sel(evt)  ;return True
        if K["me_box_ext0"].true():
            self.modal_mode = True      ;self.key_end = K["me_box_ext_E0"]
            self.to_modal_box(evt, K["me_box_ext0"])    ;return True
        if K["me_box_ext1"].true():
            self.modal_mode = True      ;self.key_end = K["me_box_ext_E1"]
            self.to_modal_box(evt, K["me_box_ext1"])    ;return True
        if K["me_box0"].true():
            self.modal_mode = None      ;self.key_end = K["me_box_E0"]
            self.to_modal_box(evt, K["me_box0"])    ;return True
        if K["me_box1"].true():
            self.modal_mode = None      ;self.key_end = K["me_box_E1"]
            self.to_modal_box(evt, K["me_box1"])    ;return True

        return False

    def to_modal_pan(self, evt):
        if self.poll(): return

        self.key_end.true()
        m.head_modal.append(self.I_modal_pan)
        self.is_draw_bu_focus = False

        m.U_pan_cursor(self, evt)
        rim = self.w.resize_rim
        m.get_loop_mou_info_region(evt, rim.L, rim.R, rim.B, rim.T)
        m.get_mou(evt)

        cvh = self.cv.R_h()
        self.tm_syslimdn = self.sci.R_T()
        self.tm_syslimup = self.tm_syslimdn + max(0, min(cvh, self.hi) - self.sci.h)
        self.tm_limyup = self.y + max(0, cvh - self.hi)
        self.tm_ind = self.R_act_ind()
        m.redraw()

    def modal_pan_end(self):

        del m.head_modal[-1]
        m.U_end_pan(self)
        m.init_wait_release()
        self.w.I_upd_data()
        m.redraw()
    def I_modal_pan(self, evt): # self.ll_li >= 28
        if evt.type == 'ESC' and evt.value == 'RELEASE':
            self.modal_pan_end()
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_pan_end()
                return
        m.U_pan(evt)

        y = self.cv.T + m.dy
        if y < self.y:
            self.tm_dif = self.y - y
            m.dy += self.tm_dif
        elif y > self.tm_limyup:
            self.tm_dif = self.tm_limyup - y
            m.dy += self.tm_dif
        else:   self.tm_dif = 0
        self.pan_y()

        m.loop_mou(evt)
        m.redraw()
    def pan_y(self): # self.ll_li != 0, self.headkey, self.endkey
        y       = m.dy
        li      = self.li
        d_cy    = self.d_cy
        h       = self.md_h
        L       = self.cv.L
        R       = self.cv.R
        self.cv.dy(y)
        headkey = self.R_headkey()

        if self.tm_dif != 0:
            new_y = min(max(self.y - self.tm_dif, self.tm_syslimdn), self.tm_syslimup)
            dif = new_y - self.y
            self.y = new_y
            self.tm_limyup += dif
            y += dif
            self.cv.dy(dif)
        self.cv.upd()

        if self.headkey != headkey:
            blf_size(font_0, F[9])
            dn = headkey - self.headkey
            drivers         = self.drivers
            fcurves         = self.fcurves
            upd_li_data     = self.upd_li_data
            if dn > 0:
                if dn >= self.max_ll:   dn = self.max_ll - 1

                hi = self.md_hi
                li_y = li[self.endkey].y - hi
                newkey = self.endkey + 1
                newhead = self.headkey + dn
                for r in range(self.headkey, newhead):
                    li[newkey] = li.pop(r)
                    e = li[newkey]
                    upd_li_data(newkey, e, drivers, fcurves)
                    e.upd_blf_y(li_y)
                    li_y -= hi
                    newkey += 1

                self.headkey    = newhead
                self.endkey     = newkey - 1
            else:
                if -dn >= self.max_ll:  dn = 1 - self.max_ll

                hi = self.md_hi
                li_y = li[self.headkey].y + hi
                newkey = self.headkey - 1
                newend = self.endkey + dn
                for r in range(self.endkey, newend, -1):
                    li[newkey] = li.pop(r)
                    e = li[newkey]
                    upd_li_data(newkey, e, drivers, fcurves)
                    e.upd_blf_y(li_y)
                    li_y += hi
                    newkey -= 1

                self.headkey    = newkey + 1
                self.endkey     = newend

            self.get_draw_ind_by_sel_range()

        ref_ic = self.ref.ic
        for e in li.values():
            e.dy_blf(y)
            T = e.y + d_cy
            e.bg.upd_bat(L, R, T - h, T)
            e.ic.upd(ref_ic, e.y)
        self.actbox.rim.dy_upd(y)
        self.actbox.bg.dy_upd(y)

    def sel_by_ind(self, i):
        m.upd_disable()
        self.set_act(i)
        self.sel_range = {i : None}
        self.get_draw_ind_by_sel_range()
        m.refresh()
        m.upd_enable()
        m.redraw()
    def sel_ext_by_ind(self, i):
        m.upd_disable()
        if i in self.li:
            self.set_act(i)
            self.sel_range[i] = None
            if i in self.ind_desel: self.ind_sel[i] = self.ind_desel.pop(i)
            self.actbox.ind = i
            self.actbox.get(self.cv, i)
        else:
            self.sel_range[i] = None

        m.refresh()
        m.upd_enable()
        m.redraw()
    def do_modal_sel(self, evt):

        if self.poll(): return

        i = self.R_ind_by_mou_safe(evt.mouse_region_y)
        if i is None:   return
        self.sel_by_ind(i)
    def do_modal_sel_ext(self, evt):

        if self.poll(): return

        i = self.R_ind_by_mou_safe(evt.mouse_region_y)
        if i is None:   return
        m.upd_disable()
        self.set_act(i)
        self.sel_range[i] = None
        if i in self.ind_desel: self.ind_sel[i] = self.ind_desel.pop(i)
        self.actbox.ind = i
        self.actbox.get(self.cv, i)
        m.refresh()
        m.upd_enable()
        m.redraw()

    def to_modal_box(self, evt, k):

        if self.poll(): return

        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if k.value == 'DRAG':
            org_x   = k.org_x + x-evt.mouse_x
            org_y   = k.org_y + y-evt.mouse_y
        else:
            org_x   = x
            org_y   = y

        i = self.R_ind_by_mou(org_y)
        if i < 0: return

        self.get_auto_pan_data()
        self.tm_selbox = m.SELBOX(org_x, x, y, org_y)

        if self.modal_mode is None:
            self.sel_range = {}  if self.actbox.ind is None else {self.actbox.ind : None}
            self.get_draw_ind_by_sel_range()
        elif i in self.sel_range:   self.modal_mode = False

        m.head_modal.append(self.I_modal_box)
        m.W_D.append(self.tm_selbox)
        m.get_mou(evt)
        self.key_end.true()
        m.upd_disable()
        m.redraw()
    def I_modal_box(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                B = self.tm_selbox.bg.B
                T = self.tm_selbox.bg.T
                if B > T:
                    B, T = T, B
                    T = min(T, self.sci.R_T() - F[2])
                    flip = True
                else:
                    B = max(B, self.sci.y + F[2])
                    flip = False

                imax = self.ll_bpy - 1
                i0 = min(imax, max(0, self.R_ind_by_mou(T)))
                i1 = min(imax, max(0, self.R_ind_by_mou(B)))
                act_ind = i0  if flip else i1

                if self.modal_mode is None:
                    self.sel_range = {r : None for r in range(i0, i1 + 1)}
                elif self.modal_mode is True:
                    for r in range(i0, i1 + 1):     self.sel_range[r] = None
                else:
                    for r in range(i0, i1 + 1):
                        if r in self.sel_range:     del self.sel_range[r]
                    act_ind = self.tm_ind
                    self.sel_range[act_ind] = None

                self.get_draw_ind_by_sel_range()
                self.set_act(act_ind)
                self.actbox.ind = act_ind
                self.actbox.get(self.cv, act_ind)

                del m.head_modal[-1]
                del m.W_D[-1]
                m.init_wait_release()
                m.refresh()
                m.upd_enable()
                m.redraw()
                return

        if evt.mouse_region_y < self.tm_autoB:
            m.dy = max(1, int((self.tm_autoB - evt.mouse_region_y) * self.tm_pan_speed))
            old_T = self.cv.T
            y = old_T + m.dy
            if y < self.y:
                self.tm_dif = self.y - y
                m.dy += self.tm_dif
            elif y > self.tm_limyup:
                self.tm_dif = self.tm_limyup - y
                m.dy += self.tm_dif
            else:   self.tm_dif = 0
            self.pan_y()
            self.tm_selbox.dy_T(self.cv.T - old_T)
        elif evt.mouse_region_y > self.tm_autoT:
            m.dy = -max(1, int((evt.mouse_region_y - self.tm_autoT) * self.tm_pan_speed))
            old_T = self.cv.T
            y = old_T + m.dy
            if y < self.y:
                self.tm_dif = self.y - y
                m.dy += self.tm_dif
            elif y > self.tm_limyup:
                self.tm_dif = self.tm_limyup - y
                m.dy += self.tm_dif
            else:   self.tm_dif = 0
            self.pan_y()
            self.tm_selbox.dy_T(self.cv.T - old_T)

        self.tm_selbox.dxy_upd_RB(evt.mouse_x - m.mou_x, evt.mouse_y - m.mou_y)
        m.get_mou(evt)
        m.redraw()

    def evt_rename(self, evt, override=False):

        if override is False:
            if self.poll(): return

            n = self.R_ind_by_mou_safe(evt.mouse_region_y)
            if n is None:   return
        else:
            n = override

        modifier = self.obs[n]
        md_name = modifier.name
        from . import dd, filt
        DDTX_RENAME(evt, md_name, (modifier, "name"), FIL(self.obs),
            target=f'objects["{self.w.oj.name}"].modifiers["{md_name}"].name',
            confirm_upd=self.w.I_upd_data
        )
        m.redraw()

    def modal_all(self, evt):

        m.EVT.kill_except(evt)
        if self.poll(): return

        if len(self.sel_range) == self.ll_bpy:
            i = self.R_act_ind()
            if i == -1: return
            self.sel_range = {i : None}
        else:
            self.sel_range = {r : None for r in range(self.ll_bpy)}
        self.get_draw_ind_by_sel_range()
        m.redraw()
        self.w.I_upd_data()
    def modal_act_up(self, evt):

        if self.poll(): return

        i = self.R_act_ind() - 1
        if i == -2: return
        self.sel_by_ind(min(max(0, i), self.ll_bpy - 1))
    def modal_act_down(self, evt):

        if self.poll(): return

        i = self.R_act_ind() + 1
        if i == 0: return
        self.sel_by_ind(min(max(0, i), self.ll_bpy - 1))
    def modal_act_up_ext(self, evt):

        if self.poll(): return

        i = self.R_act_ind() - 1
        if i == -2: return
        self.sel_ext_by_ind(min(max(0, i), self.ll_bpy - 1))
    def modal_act_down_ext(self, evt):

        if self.poll(): return

        i = self.R_act_ind() + 1
        if i == 0: return
        self.sel_ext_by_ind(min(max(0, i), self.ll_bpy - 1))
    def modal_li_up(self, evt):

        if self.poll(): return

        name = self.w.act_md.name
        m.undo_str = f'[Modifier Editor] md move up ◀ {name}'
        m.upd_disable()
        try:
            self.bpy_ops_init()
            bpy.ops.object.modifier_move_up(modifier = name)
            self.bpy_ops_end()
            self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")

            m.upd_enable()
            m.refresh()
            m.redraw()
        except:
            m.upd_enable()
    def modal_li_down(self, evt):

        if self.poll(): return

        name = self.w.act_md.name
        m.undo_str = f'[Modifier Editor] md move down ◀ {name}'
        m.upd_disable()
        try:
            self.bpy_ops_init()
            bpy.ops.object.modifier_move_down(modifier = name)
            self.bpy_ops_end()
            self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")

            m.upd_enable()
            m.refresh()
            m.redraw()
        except:
            m.upd_enable()
    def modal_del(self, evt):

        m.EVT.kill_except(evt)
        if self.poll(): return

        def do_del():
            m.undo_str = '[Modifier Editor] md delete'
            m.upd_disable()
            try:
                self.bpy_ops_init()
                bpy_remove_by_name = self.bpy_remove_by_name
                obs = self.obs
                lis = [obs[r] for r in range(self.ll_bpy -1,-1,-1) if r in self.sel_range]
                for md in lis:  bpy_remove_by_name(md.name)
                self.bpy_ops_end()
                self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")

                m.upd_enable()
                m.refresh()
                del lis
            except:
                m.upd_enable()

        if P.confirm_del:
            win_mess.MESS_BOOL(evt.mouse_region_x, evt.mouse_region_y,
                "Do you want to delete the modifier(s)?", do_del, N)
        else: do_del()
    def modal_apply(self, evt):

        m.EVT.kill_except(evt)
        if self.poll(): return

        def do_apply():
            m.undo_str = '[Modifier Editor] md apply'
            m.upd_disable()
            try:
                self.bpy_ops_init()
                bpy_apply_by_name = self.bpy_apply_by_name
                obs = self.obs
                lis = [obs[r] for r in range(self.ll_bpy) if r in self.sel_range]
                for md in lis:  bpy_apply_by_name(md.name)
                self.bpy_ops_end()
                self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")

                m.upd_enable()
                m.refresh()
                del lis
            except:
                m.upd_enable()

        if P.confirm_apply:
            win_mess.MESS_BOOL(evt.mouse_region_x, evt.mouse_region_y,
                "Do you want to apply the modifier(s)?", do_apply, N)
        else: do_apply()

    # SORT
    def to_modal_sort(self, evt):

        m.refresh()
        m.redraw()
        if self.ll_bpy == 0:    return

        li  = self.li
        cv  = self.cv
        i   = self.R_ind_by_mou_safe(evt.mouse_region_y)
        if i not in li: return

        d_cy                    = self.d_cy
        md_h                    = self.md_h
        md_hi                   = self.md_hi
        self.tm_an_speed        = P.anim_speed
        self.tm_unit_speed      = max(0.00001, self.tm_an_speed / md_hi)
        self.tm_pop_ind         = i
        self.tm_pop_ind_org     = i
        L                       = cv.L
        R                       = cv.R
        T                       = li[i].y + d_cy
        B                       = T - md_h
        sel_range               = self.sel_range
        self.ll_tm_sel          = len(sel_range)
        sci_B                   = self.sci.y
        sci_T                   = sci_B + self.sci.h
        self.region_L           = L
        self.region_R           = R
        self.region_B           = sci_B - d_cy
        self.region_T           = sci_T + d_cy
        w                       = self.w
        self.region_win_L       = w.box["rim"].L
        self.region_win_R       = w.box["rim"].R
        self.region_win_B       = w.box["rim"].B
        self.region_win_T       = w.box["rim"].T
        self.region_apply_B     = w.R_bo_info_B()

        self.mt_win             = None
        self.mt_win_mods        = None
        global W_MO
        W_MO                    = w.__class__.W
        self.mt_wins            = [e for e in reversed(m.W_M)  if e in W_MO and e != w]
        obs                     = self.obs
        self.tm_sel_name        = {obs[r].name for r in sel_range}

        self.init_thread()
        self.threads    = {}

        if i not in sel_range or self.ll_tm_sel == 1:
            self.tm_pop = self.R_tm_pop()(li.pop(i), self.ref, self.color_bg_desel, L, R, B, T)
            self.tm_pop_dxy_fn = self.tm_pop.dxy_upd
            self.modal_sort_fin_D1 = self.modal_sort_fin_D1_default
        else:
            self.modal_sort_fin_D1 = self.modal_sort_fin_D1_multi
            blf_size(font_0, F[9])
            li_type         = self.li_type
            ll_bpy          = self.ll_bpy
            headkey         = self.headkey
            # endkey          = self.endkey
            # endname         = li[endkey].name.size
            # y               = li[endkey].y - md_hi
            thread_sep      = self.thread_sep
            pop_name        = li[i].name.size
            for r in li.copy():
                if r in sel_range:  del li[r]

            self.tm_pop     = MD_POP_MULTI(L, R, B, T, self.ll_tm_sel)
            tm_pop          = self.tm_pop
            des             = tm_pop.bg.T
            u_speed         = self.tm_unit_speed
            top_pop         = [r for r in sel_range if r < headkey]
            ll_top_pop      = len(top_pop)


            self.tm_obs     = self.obs
            self.obs        = [obs[r] for r in range(ll_bpy) if r not in sel_range or r == i]
            obs             = self.obs
            tm_table        = {e.name : r for r, e in enumerate(obs)}
            self.tm_table   = tm_table
            ll_bpy          = len(obs)
            self.ll_bpy     = ll_bpy
            thread_li_y     = self.thread_li_y

            new_li  = {}

            if li:
                r               = min(li.keys())
                li_head_name    = li[r].name.size
                li_head_new_ind = tm_table[li_head_name]
                new_cv_T        = min(self.y + max(0, ll_bpy * md_hi - self.hi),
                    max(self.y, li[r].y + li_head_new_ind * md_hi + d_cy)
                )


            else:


                li_head_new_ind = 0
                new_cv_T        = self.y


            cv.T    = new_cv_T
            cv.B    = new_cv_T - ll_bpy * md_hi
            li0_y   = new_cv_T - d_cy
            new_end = -1

            for k, e in li.items():
                newkey  = tm_table[e.name.size]
                new_end = max(new_end, newkey)
                new_li[newkey] = e
                e.get_ind(newkey)
                des     = li0_y - newkey * md_hi

                if des != e.y:
                    v = (des - e.y) * u_speed
                    thread_li_y[e] = AN(des,
                        min(-1, round(v)) if v < 0 else max(1, round(v)),
                    )

            self.li         = new_li
            li              = self.li
            new_head        = self.R_headkey()
            self.headkey    = new_head
            self.endkey     = min(new_head + self.max_ll - 1, ll_bpy - 1)


            B       = self.y
            T       = B + md_h
            ic_x    = self.ref.ic
            y       = T - d_cy

            pop_ind                 = tm_table[pop_name]
            self.tm_pop_ind_old     = i
            self.tm_pop_ind         = pop_ind
            self.tm_pop_ind_org     = pop_ind
            drivers                 = self.drivers
            fcurves                 = self.fcurves
            init_li_data            = self.init_li_data

            for r in reversed(range(new_head, li_head_new_ind)):
                if r != pop_ind:
                    e       = li_type()
                    li[r]   = e
                    init_li_data(r, e, drivers, fcurves)
                    e.get_pos(L, R, B, T, y, ic_x)

                    des     = li0_y - r * md_hi
                    v       = (des - y) * u_speed
                    thread_li_y[e] = AN(des,
                        min(-1, round(v)) if v < 0 else max(1, round(v)),
                    )

                B += md_hi
                T += md_hi
                y += md_hi

            T       = self.y - self.hi
            B       = T - md_h
            y       = T - d_cy
            for r in range(new_end + 1, self.endkey + 1):
                if r != pop_ind:
                    e       = li_type()
                    li[r]   = e
                    init_li_data(r, e, drivers, fcurves)
                    e.get_pos(L, R, B, T, y, ic_x)

                    des     = li0_y - r * md_hi
                    v       = (des - y) * u_speed
                    thread_li_y[e] = AN(des,
                        min(-1, round(v)) if v < 0 else max(1, round(v)),
                    )

                B -= md_hi
                T -= md_hi
                y -= md_hi

            # syslim
            cvh         = cv.R_h()
            syslimdn    = self.sci.R_T()
            syslimup    = syslimdn + max(0, min(cvh, self.hi) - self.sci.h)

            if self.y < syslimdn:

                dy = syslimdn - self.y
            elif self.y > syslimup:

                dy = syslimup - self.y
            else:
                dy = 0

            if dy != 0:
                cv.dy(dy)
                v           = self.tm_unit_speed * dy
                thread_add  = self.thread_li_y_add
                for e in li.values():   thread_add(e, dy, v)

            cv.upd()
            self.tm_pop_dxy_fn  = self.tm_pop.dxy_upd

        m.head_modal.append(self.I_modal_sort)
        m.W_D.append(self.tm_pop)
        self.tm_evt_region  = self.evt_region_sort
        self.U_draw         = self.I_draw_modal_sort
        m.admin.U_modal     = m.admin.I_modal_progress
        m.M.U_add_timer()

        m.get_mou(evt)
        self.get_auto_pan_data()
        self.key_end.true()
        m.upd_disable()
    def I_modal_sort(self, evt):

        # if evt.type == "F17" and evt.value == "PRESS":
        #     li = self.li
        #     for r in range(self.headkey, self.tm_pop_ind):
        #         e = li[r]
        #         print(f"        ll  I_modal_sort:  name: {e.name.text}, key: {r, e.ind.size}, y: {e.y}")
        #     for r in range(self.tm_pop_ind + 1, self.endkey):
        #         e = li[r]
        #         print(f"        ll  I_modal_sort:  name: {e.name.text}, key: {r, e.ind.size}, y: {e.y}")

        if K["cancel0"].true() or K["cancel1"].true():
            self.tm_evt_region = self.evt_region_mt_cancel

            if type(self.tm_pop) is MD_POP_MULTI:
                self.modal_sort_exit_multi(evt)
            else:
                self.modal_sort_exit(evt)
            return
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                if type(self.tm_pop) is MD_POP_MULTI:   self.modal_sort_exit_multi(evt)
                else: self.modal_sort_exit(evt)
                return

        evt_y = evt.mouse_region_y
        self.tm_pop_dxy_fn(evt.mouse_x - m.mou_x, evt.mouse_y - m.mou_y)

        pop_ind = min(max(self.headkey, self.R_ind_by_mou(evt_y)), self.endkey)
        d_ind = pop_ind - self.tm_pop_ind

        if d_ind > 0:
            li  = self.li
            i   = self.tm_pop_ind
            hi  = self.md_hi
            v   = self.tm_an_speed

            for r in range(i, i + d_ind):
                e       = li.pop(r + 1)
                li[r]   = e
                self.thread_li_y_add(e, hi, v)

        elif d_ind < 0:
            li  = self.li
            i   = self.tm_pop_ind
            hi  = - self.md_hi
            v   = - self.tm_an_speed

            for r in range(i, i + d_ind, -1):
                e       = li.pop(r - 1)
                li[r]   = e
                self.thread_li_y_add(e, hi, v)

        if evt_y < self.tm_autoB:
            dy = max(1, int((self.tm_autoB - evt_y) * self.tm_pan_speed))
            old_T = self.cv.T
            y = old_T + dy
            if y < self.y:
                tm_dif = self.y - y
                dy += tm_dif
            elif y > self.tm_limyup:
                tm_dif = self.tm_limyup - y
                dy += tm_dif
            else:   tm_dif = 0
            self.pan_y_sort(dy, tm_dif)

        elif evt_y > self.tm_autoT:
            dy = -max(1, int((evt_y - self.tm_autoT) * self.tm_pan_speed))
            old_T = self.cv.T
            y = old_T + dy
            if y < self.y:
                tm_dif = self.y - y
                dy += tm_dif
            elif y > self.tm_limyup:
                tm_dif = self.tm_limyup - y
                dy += tm_dif
            else:   tm_dif = 0
            self.pan_y_sort(dy, tm_dif)

        self.tm_pop_ind = pop_ind
        self.tm_evt_region(evt)
        m.get_mou(evt)
    def pan_y_sort(self, dy, tm_dif):
        li          = self.li
        cv          = self.cv
        d_cy        = self.d_cy
        h           = self.md_h
        L, R        = cv.L, cv.R
        cv_T_old    = cv.T
        cv.dy(dy)
        headkey     = self.R_headkey()

        if tm_dif != 0:
            new_y = min(max(self.y - tm_dif, self.tm_syslimdn), self.tm_syslimup)
            dif = new_y - self.y
            self.y = new_y
            self.tm_limyup += dif
            dy += dif
            cv.dy(dif)
        cv.upd()

        if self.headkey != headkey:
            blf_size(font_0, F[9])
            dn              = headkey - self.headkey
            drivers         = self.drivers
            fcurves         = self.fcurves
            init_li_data    = self.init_li_data

            if dn > 0:
                if dn >= self.max_ll:   dn = self.max_ll - 1

                hi = self.md_hi
                li_y = cv_T_old - d_cy - self.endkey * hi

                newkey          = self.endkey + 1
                newhead         = self.headkey + dn

                for r in range(self.headkey, newhead):
                    if r in li:  del li[r]
                    e           = self.li_type()
                    li[newkey]  = e

                    init_li_data(newkey  if newkey > self.tm_pop_ind_org else newkey - 1, e, drivers, fcurves)
                    e.upd_blf_y(li_y  if newkey < self.tm_pop_ind else li_y - hi)
                    li_y -= hi
                    newkey += 1

                self.headkey    = newhead
                self.endkey     = newkey - 1
            else:
                if -dn >= self.max_ll:  dn = 1 - self.max_ll

                hi = self.md_hi
                li_y = cv_T_old - d_cy - self.headkey * hi

                newkey = self.headkey - 1
                newend = self.endkey + dn
                for r in range(self.endkey, newend, -1):
                    if r in li:  del li[r]
                    e           = self.li_type()
                    li[newkey]  = e

                    init_li_data(newkey + 1  if newkey >= self.tm_pop_ind_org else newkey, e, drivers, fcurves)
                    e.upd_blf_y(li_y + hi  if newkey < self.tm_pop_ind else li_y)
                    li_y += hi
                    newkey -= 1

                self.headkey    = newkey + 1
                self.endkey     = newend

        ref_ic = self.ref.ic
        for e in li.values():
            e.dy_blf(dy)
            T = e.y + d_cy
            e.bg.upd_bat(L, R, T - h, T)
            e.ic.upd(ref_ic, e.y)
        for e, an in self.thread_li_y.items():
            an.des += dy
            if e.y > an.des:
                if an.v > 0:    an.v = - an.v
            elif an.v < 0:      an.v = - an.v
    def modal_sort_fin(self, init_wait_release = True):

        m.admin.U_modal     = m.admin.I_modal
        m.M.U_kill_timer()

        del m.head_modal[-1]
        m.W_D.remove(self.tm_pop)
        m.upd_enable()
        self.kill_thread()
        self.U_draw = self.I_draw
        self.mt_win = None
        self.mt_wins.clear()
        if init_wait_release:   m.init_wait_release()
        self.w.U_upd_act_ob()
        self.modal_sort_fin_D1()
        evt = m.EVT.evt
        if self.w.resize_rim.inbox(evt) and not self.w.is_out_region(evt.mouse_region_x, evt.mouse_region_y):
            bpy.context.window.cursor_modal_set('DEFAULT')
        m.redraw()
    def modal_sort_fin_D1_default(self):
        act_ind = self.R_act_ind()
        if act_ind == -1:
            self.actbox.disable()
            self.sel_range.clear()
            self.get_draw_ind_by_sel_range()
            m.refresh()
        else:
            self.actbox.get(self.cv, act_ind)
            self.sel_range = {act_ind : None}
            self.get_draw_ind_by_sel_range()
            m.refresh()
            dict_ind = {e.name : i  for i, e in enumerate(self.obs)}
            self.sel_range = {dict_ind[name] : None for name in self.tm_sel_name if name in dict_ind}
            self.sel_range[act_ind] = None
            self.get_draw_ind_by_sel_range()
    def modal_sort_fin_D1_multi(self):
        m.refresh()
    def modal_sort_desel_all(self):
        obs = self.R_bpy_obs()
        if obs:
            i = self.R_act_ind()
            if i == -1: return
            self.sel_range = {i : None}
            self.get_draw_ind_by_sel_range()
            amt = self.w.da["amt"]
            amt.size = len(obs)
            amt.text = f"{len(self.sel_range)} / {amt.size}"

    def anim_cancel(self, v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org, del_pop=False):
        if self.mt_win is not None: self.end_mt_sort()

        if del_pop: tm_pop.thread_color(self.thread_sep, -v)
        else:
            self.thread_sep_add_pop(tm_pop, cv.L + F[8], cv.T - d_cy - pop_ind_org * hi)
        thread_li_y_add = self.thread_li_y_add

        if pop_ind >= pop_ind_org:
            hi  = - hi
            v   = - v
            for r in range(pop_ind, max(self.headkey, pop_ind_org), -1):
                e       = li.pop(r - 1)
                li[r]   = e
                thread_li_y_add(e, hi, v)
        else:
            for r in range(pop_ind, min(self.endkey, pop_ind_org)):
                e       = li.pop(r + 1)
                li[r]   = e
                thread_li_y_add(e, hi, v)

        self.thread_sep[self] = AN_AUTOKILL_ALL(self.threads, self.exit_fn_cancel)
    def anim_cancel_multi(self, tm_pop):
        if self.mt_win is not None: self.end_mt_sort()
        sci             = self.sci
        self.sort_end_upd_li(self.R_bpy_obs())
        tm_pop.thread_color_kill(self.thread_sep, -0.05 * self.tm_an_speed)
        self.thread_sep[sci] = AN_sci(sci.h,
            max(1, round(sci.h * self.tm_unit_speed))
        )
        sci.y += sci.h
        sci.h = 0
        self.thread_sep[self] = AN_AUTOKILL_ALL(self.threads, N)
        self.get_draw_ind_by_sel_range()
        self.U_draw = self.I_draw
        self.actbox.get(self.cv, self.R_act_ind())
    def anim_del(self, v, hi, d_cy, cv, li, tm_pop, pop_ind):
        obs = self.obs
        newl = len(obs)
        if self.mt_win is not None: self.end_mt_sort()

        tm_pop.thread_color(self.thread_sep, -v)
        thread_li_y_add = self.thread_li_y_add

        newkey = self.endkey

        if newkey < newl:
            y = cv.T - d_cy - newkey * hi - hi
            e = self.li_type()
            li[newkey + 1] = e

            self.init_li_data(newkey, e, self.drivers, self.fcurves)
            e.upd_blf_y(y)
            T = y + d_cy
            e.bg.upd_bat(cv.L, cv.R, T - self.md_h, T)
            e.ic.upd(self.ref.ic, y)

            for r in range(pop_ind, newkey + 1):
                e       = li.pop(r + 1)
                li[r]   = e
                thread_li_y_add(e, hi, v)
        else:
            if self.headkey == 0:
                if self.y == cv.T:
                    for r in range(pop_ind, self.endkey):
                        e       = li.pop(r + 1)
                        li[r]   = e
                        thread_li_y_add(e, hi, v)
                else:
                    u_speed = self.tm_unit_speed
                    d = self.y - cv.T
                    cv.dy(d)
                    ve = min(-1, round(u_speed * d))
                    for r in range(self.headkey, pop_ind):
                        thread_li_y_add(li[r], d, ve)
                    d += hi
                    ve = round(u_speed * d)
                    ve = min(-1, ve)  if ve < 0 else max(1, ve)
                    for r in range(pop_ind, self.endkey):
                        e       = li.pop(r + 1)
                        li[r]   = e
                        thread_li_y_add(e, d, ve)
                self.endkey -= 1
            else:
                newkey = self.headkey - 1
                y = cv.T - d_cy - newkey * hi
                e = self.li_type()
                li[newkey] = e
                self.init_li_data(newkey, e, self.drivers, self.fcurves)
                e.upd_blf_y(y)
                T = y + self.d_cy
                e.bg.upd_bat(cv.L, cv.R, T - self.md_h, T)
                e.ic.upd(self.ref.ic, y)

                for r in range(pop_ind, self.endkey):
                    li[r]   = li.pop(r + 1)
                for r in range(newkey, pop_ind):
                    e       = li[r]
                    thread_li_y_add(e, -hi, -v)
                self.endkey -= 1
                self.headkey = newkey
                cv.dy(-hi)

        cv.B += hi
        cv.upd()
        self.thread_sep[self] = AN_AUTOKILL_ALL(self.threads, self.exit_fn_del)
    def sort_end_upd_li(self, bpy_obs):   # blf_size(font_0, F[9])
        self.obs        = bpy_obs
        ll_bpy          = len(bpy_obs)
        self.ll_bpy     = ll_bpy
        cv              = self.cv
        md_hi           = self.md_hi
        li_type         = self.li_type

        cvh             = ll_bpy * md_hi
        T               = min(self.y + max(0, cvh - self.hi), max(self.y, cv.T))
        cv.T            = T
        cv.B            = T - cvh
        cv.upd()
        ic_x            = self.ref.ic
        headkey         = self.R_headkey()
        self.headkey    = headkey
        li              = self.li
        li.clear()

        L               = cv.L
        R               = cv.R
        T               = T - md_hi * headkey
        B               = T - self.md_h
        y               = T - self.d_cy
        drivers         = self.drivers
        fcurves         = self.fcurves
        init_li_data    = self.init_li_data

        for r in range(headkey, min(ll_bpy, headkey + self.max_ll)):
            e = li_type()
            init_li_data(r, e, drivers, fcurves)
            e.get_pos(L, R, B, T, y, ic_x)
            li[r] = e

            B -= md_hi
            T -= md_hi
            y -= md_hi

        self.ll_li  = len(li)
        self.endkey = self.R_endkey()
    def sort_end_multi_R_li_sort(self, pop_ind, pop_ind_org, override=None):
        if override is None:
            tm_obs      = self.tm_obs
            obs         = self.obs
            sel_range   = self.sel_range
            ll_bpy      = self.ll_bpy
        else:
            tm_obs, obs, sel_range, ll_bpy = override

        if pop_ind <= pop_ind_org:
            li_sort = {r : obs[r].name for r in range(pop_ind)}
            i = pop_ind
            for r, e in enumerate(tm_obs):
                if r in sel_range:
                    li_sort[i] = e.name
                    i += 1
            for r in range(pop_ind, ll_bpy):
                if r == pop_ind_org: continue
                li_sort[i] = obs[r].name
                i += 1
        else:
            li_sort = {r : obs[r].name for r in range(pop_ind_org)}
            i = pop_ind_org
            pop_ind += 1
            for r in range(pop_ind_org + 1, pop_ind):
                li_sort[i] = obs[r].name
                i += 1
            for r, e in enumerate(tm_obs):
                if r in sel_range:
                    li_sort[i] = e.name
                    i += 1
            for r in range(pop_ind, ll_bpy):
                li_sort[i] = obs[r].name
                i += 1
        return li_sort

    def modal_sort_exit(self, evt):
        m.head_modal[-1]    = N

        li          = self.li
        hi          = self.md_hi
        v           = self.tm_an_speed
        oj          = self.w_oj
        cv          = self.cv
        d_cy        = self.d_cy
        tm_pop      = self.tm_pop
        region      = self.tm_evt_region
        pop_ind     = self.tm_pop_ind
        pop_ind_org = self.tm_pop_ind_org

        tm_pop.name.text    = tm_pop.name.size
        tm_pop.name.color   = P.color_font_mod_name

        if region == self.evt_region_sort:
            if self.mt_win is not None: self.end_mt_sort()

            if oj.library:
                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, str_unsort)
                return

            if pop_ind == pop_ind_org:  is_success = True
            else:
                md_name = self.obs[pop_ind_org].name

                m.undo_str = f'[Modifier Editor] md sort'
                try:
                    self.bpy_ops_init()
                    self.bpy_move_to_ind(md_name, self.tm_pop_ind)
                    self.bpy_ops_end()
                    self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")

                    is_success = True if self.obs.find(md_name) == self.tm_pop_ind else False
                except:
                    self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                    win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, "Object is hidden")
                    return

            if is_success:

                self.thread_sep_add_pop(tm_pop, cv.L + F[8], cv.T - d_cy - pop_ind * hi)
                self.thread_sep[self] = AN_AUTOKILL_ALL(self.threads, self.exit_fn_sort)
            else:

                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                self.call_win_not_match(evt.mouse_region_x, evt.mouse_region_y)
        elif region in {self.evt_region_del, self.evt_region_mt_del}:

            if oj.library:
                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, str_undel)
                return

            m.undo_str = '[Modifier Editor] md delete'
            try:
                self.bpy_ops_init()
                self.bpy_remove_by_name(self.obs[pop_ind_org].name)
                self.bpy_ops_end()
                self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
            except:
                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, "Object is hidden")
                return

            self.anim_del(v, hi, d_cy, cv, li, tm_pop, pop_ind)
        elif region == self.evt_region_apply:
            if oj.library:
                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, str_unapply)
                return

            if oj.data.users > 1:

                self.w.U_modal = N
                del m.head_modal[-1]

                def fn_no():
                    self.w.U_modal = self.w.default_modal
                    m.head_modal.append(N)
                    self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                def fn_yes():
                    self.w.U_modal = self.w.default_modal
                    m.head_modal.append(N)
                    m.undo_str = f'[Modifier Editor] md apply (multi-user)'
                    try:
                        self.bpy_ops_init()
                    except:
                        self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                        win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, "Object is hidden")
                        return

                    me, users, tm_mesh = self.multi_user_do(oj)

                    is_success = self.bpy_apply_by_name(self.obs[pop_ind_org].name)
                    self.bpy_ops_end()
                    self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")

                    self.multi_user_restore(me, users, tm_mesh)
                    self.anim_del(v, hi, d_cy, cv, li, tm_pop, pop_ind)

                    if is_success is False:
                        win_mess.MESS(*self.top_win.R_center_pos(),
                            "No data to apply. Removed."
                        )

                self.top_win = win_mess.MESS_BOOL(evt.mouse_region_x, evt.mouse_region_y,
                    "Multi-user detected. Do you want to continue?",
                    fn_yes, fn_no,
                    hide_tb = True)
            else:

                m.undo_str = f'[Modifier Editor] md apply'
                try:
                    self.bpy_ops_init()
                except:
                    self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                    win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, "Object is hidden")
                    return
                is_success = self.bpy_apply_by_name(self.obs[pop_ind_org].name)
                self.bpy_ops_end()
                self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")

                self.anim_del(v, hi, d_cy, cv, li, tm_pop, pop_ind)

                if is_success is False:
                    win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y,
                        "No data to apply. Removed."
                    )
        elif region == self.evt_region_mt_link:


            if self.mt_win.oj.type != oj.type:

                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y,
                    "Different object type are detected. Cancelled.")
                return

            if self.mt_win.oj.library:
                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, str_uncopy)
                return

            self.w.U_modal = N
            del m.head_modal[-1]
            self.tm_mouse = evt.mouse_region_x, evt.mouse_region_y

            self.top_win = win_mess.MENU_MOD_LINK(
                evt.mouse_region_x, evt.mouse_region_y,
                [
                    ("bu_move", "Move"),
                    ("bu_copy", "Copy"),
                    ("bu_link", "Link by Driver"),
                    ("bu_dlink", "Deep Link by Driver")
                ],
                self.link_menu_end
            )
            if oj.library:  self.top_win.oo["bu_move"].disable()
        elif region == self.evt_region_mt_apply:

            if oj.library:
                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                win_mess.MESS(evt.mouse_region_x, evt.mouse_region_y, str_unapply)
                return

            mt_win  = self.mt_win
            mt_oj   = mt_win.oj

            def call_mess(tx):  return win_mess.MESS(*self.top_win.R_center_pos(), tx)
            def fn_no():
                self.w.U_modal = self.w.default_modal
                m.head_modal.append(N)
                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
            def call_menu(is_multi_user):
                def fn_yes():
                    self.w.U_modal = self.w.default_modal
                    m.head_modal.append(N)
                    keep_org = self.top_win.oo["keep"].da.name

                    if is_multi_user:
                        m.undo_str = f'[Modifier Editor] md apply to object (multi-user)'
                        me, users, tm_mesh = self.multi_user_do(mt_oj)
                    else:
                        m.undo_str = f'[Modifier Editor] md apply to object'

                    if mt_oj == oj:

                        try:
                            self.bpy_ops_init()
                        except:
                            self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                            self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                            new_mess = call_mess("Copy failed. Cancelled.")
                            new_mess.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                            if is_multi_user:   self.multi_user_restore(me, users, tm_mesh)
                            return
                        if keep_org:
                            if self.bpy_copy(self.obs[pop_ind_org].name):
                                if self.bpy_apply_by_name(self.obs.active.name):
                                    self.bpy_ops_end()

                                    self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                                    self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org, del_pop=True)
                                else:
                                    self.bpy_ops_end()

                                    self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                                    self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org, del_pop=True)
                                    new_mess = call_mess("No data to apply. Removed.")
                                    new_mess.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                            else:
                                self.bpy_ops_end()

                                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                                self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                                new_mess = call_mess("Copy failed. Cancelled.")
                                new_mess.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                        else:
                            if self.bpy_apply_by_name(self.obs[pop_ind_org].name):
                                self.bpy_ops_end()

                                self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                                self.anim_del(v, hi, d_cy, cv, li, tm_pop, pop_ind)
                            else:
                                self.bpy_ops_end()

                                self.anim_del(v, hi, d_cy, cv, li, tm_pop, pop_ind)
                                new_mess = call_mess("No data to apply. Removed.")
                                new_mess.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                    else:
                        try:
                            self.bpy_ops_select_init()
                        except:
                            if oj_visible is False: mt_oj.hide_set(True)
                            self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                            new_mess = call_mess("Copy failed. Cancelled.")
                            new_mess.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                            if is_multi_user:   self.multi_user_restore(me, users, tm_mesh)
                            return
                        oj_visible = mt_oj.visible_get()
                        if oj_visible is False: mt_oj.hide_set(False)

                        mt_oj.select_set(True)
                        oj.select_set(True)

                        if self.bpy_copy_to(self.obs[pop_ind_org].name):
                            m.set_active_object(mt_oj)
                            is_success = self.bpy_apply_by_name(mt_oj.modifiers.active.name)

                            if keep_org:
                                if oj_visible is False: mt_oj.hide_set(True)
                                self.bpy_ops_end()

                                self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                                self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org, del_pop=True)
                            else:
                                m.set_active_object(oj)
                                self.bpy_remove_by_name(self.obs[pop_ind_org].name)
                                if oj_visible is False: mt_oj.hide_set(True)
                                self.bpy_ops_end()

                                self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                                self.anim_del(v, hi, d_cy, cv, li, tm_pop, pop_ind)

                            if is_success is False: call_mess("No data to apply. Removed.")
                        else:
                            if oj_visible is False: mt_oj.hide_set(True)
                            self.bpy_ops_end()

                            self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
                            new_mess = call_mess("Copy failed. Cancelled.")
                            new_mess.callfront = lambda x: m.M.set_mou_ic("DEFAULT")

                    if is_multi_user:   self.multi_user_restore(me, users, tm_mesh)

                if is_multi_user:
                    evt_x, evt_y = self.top_win.R_center_pos()
                else:
                    evt_x   = evt.mouse_region_x
                    evt_y   = evt.mouse_region_y

                top_win = win_mess.MESS_BOOL(evt_x, evt_y,
                    "It will be applied to this object, do you want to continue?",
                    fn_yes,
                    fn_no,
                    hide_tb = True,
                    height  = F[150]
                )
                self.top_win = top_win
                bu_keep = win_mess.bu.BU_BOOL(top_win.main_area, "keep",
                    "Keep the original"
                )
                top_win.oo["keep"] = bu_keep
                blf_size(font_0, F[9])
                e = top_win.box["main"]
                bu_keep.RB(e.R - F[13], e.B + F[52])

            self.w.U_modal = N
            del m.head_modal[-1]

            if mt_oj.data.users > 1:

                def fn_yes():   call_menu(True)

                top_win = win_mess.MESS_BOOL(
                    evt.mouse_region_x, evt.mouse_region_y,
                    "Multi-user detected. Do you want to continue?",
                    fn_yes, fn_no,
                    hide_tb = True,
                )
                self.top_win = top_win
            else:   call_menu(False)
        else:

            self.anim_cancel(v, hi, d_cy, cv, li, tm_pop, pop_ind, pop_ind_org)
    def modal_sort_exit_multi(self, evt):
        m.head_modal[-1]    = N
        blf_size(font_0, F[9])

        tm_pop          = self.tm_pop
        cv              = self.cv
        md_hi           = self.md_hi
        region          = self.tm_evt_region
        pop_ind         = self.tm_pop_ind
        pop_ind_org     = self.tm_pop_ind_org
        oj              = self.w.oj

        self.tm_oj_name     = oj.name
        self.tm_md_name     = self.w.act_md.name
        self.tm_mouse       = evt.mouse_region_x, evt.mouse_region_y

        if region == self.evt_region_sort:
            if oj.library:
                def call_mess():
                    win_mess.MESS(*self.tm_mouse, str_unsort)
                self.modal_sort_fin_D1 = call_mess
                self.anim_cancel_multi(tm_pop)
                return

            li_sort         = self.sort_end_multi_R_li_sort(pop_ind, pop_ind_org)
            self.job_ind    = 0
            l               = len(li_sort)
            move_to_ind     = self.bpy_move_to_ind
            modifiers       = oj.modifiers

            def job_fn(i):
                move_to_ind(li_sort[i], i)
                self.job_ind += 1
                return self.job_ind
            def to_restore():
                dic                     = win_mess.TM["show_viewport"]
                job_restore             = self.job_fn_restore_show_viewport
                self.top_win.gen        = (job_restore(dic, e) for e in modifiers)
                self.top_win.end_fn     = self.job_fn_end_sort
            def call_progress():
                m.upd_disable()
                self.off_show_viewport(modifiers)
                try:
                    self.bpy_ops_init()
                except:
                    m.upd_enable()
                    m.admin.report({'INFO'}, "Object is hidden")
                    return
                self.top_win = win_mess.PROGRESS(*self.tm_mouse, self, l + l,
                    (job_fn(r) for r in range(l -1, -1, -1)),
                    to_restore, self.job_fn_abort, self.job_fn_undo, N
                )

            TM = win_mess.TM
            TM["md_sels"]   = {md for i, md in enumerate(modifiers) if i in self.sel_range}
            TM["li_match"]  = li_sort
            TM["modifiers"] = modifiers
            self.modal_sort_fin_D1      = call_progress
            m.undo_str = '[Modifier Editor] md sort Start'
            m.undo_push()
            m.undo_str = '[Modifier Editor] md sort End'
        elif region in {self.evt_region_del, self.evt_region_mt_del}:
            if oj.library:
                def call_mess():
                    win_mess.MESS(*self.tm_mouse, str_undel)
                self.modal_sort_fin_D1 = call_mess
                self.anim_cancel_multi(tm_pop)
                return

            tm_obs  = self.tm_obs
            job_li  = [tm_obs[r] for r in range(len(tm_obs)-1,-1,-1) if r in self.sel_range]

            self.job_ind    = 0
            l               = len(job_li)
            remove_md       = self.bpy_remove_by_name

            def job_fn(name):
                remove_md(name)
                self.job_ind += 1
                return self.job_ind
            def job_fn_final():
                self.job_fn_end_del()
                job_li.clear()
                win_mess.TM.clear()
                self.modal_sort_desel_all()
            def call_progress():
                m.upd_disable()
                try:
                    self.bpy_ops_init()
                except:
                    m.upd_enable()
                    m.admin.report({'INFO'}, "Object is hidden")
                    return
                self.top_win = win_mess.PROGRESS(*self.tm_mouse, self, l,
                    (job_fn(md.name) for md in job_li),
                    job_fn_final, self.job_fn_abort, self.job_fn_undo, N
                )

            self.modal_sort_fin_D1      = call_progress
            m.undo_str = f'[Modifier Editor] md remove Start'
            m.undo_push()
            m.undo_str = f'[Modifier Editor] md remove End'
        elif region == self.evt_region_apply:
            if oj.library:
                def call_mess():
                    win_mess.MESS(*self.tm_mouse, str_unapply)
                self.modal_sort_fin_D1 = call_mess
                self.anim_cancel_multi(tm_pop)
                return

            tm_obs  = self.tm_obs
            job_li  = [tm_obs[r] for r in range(len(tm_obs)) if r in self.sel_range]

            self.job_ind    = 0
            l               = len(job_li)
            apply_md        = self.bpy_apply_by_name

            def call_progress(me=None, users=None, tm_mesh=None):
                def job_fn(name):
                    apply_md(name)
                    self.job_ind += 1
                    return self.job_ind
                def job_fn_final():
                    if me is not None:
                        self.multi_user_restore(me, users, tm_mesh)
                    self.job_fn_end_del()
                    job_li.clear()
                    win_mess.TM.clear()
                    self.modal_sort_desel_all()

                m.upd_disable()
                try:
                    self.bpy_ops_init()
                except:
                    m.upd_enable()
                    m.admin.report({'INFO'}, "Object is hidden")
                    return
                self.top_win = win_mess.PROGRESS(*self.tm_mouse, self, l,
                    (job_fn(md.name) for md in job_li),
                    job_fn_final, self.job_fn_abort, self.job_fn_undo, N
                )

            if oj.data.users > 1:
                def fn_yes():
                    m.undo_str = f'[Modifier Editor] md apply Start (multi-user)'
                    m.undo_push()
                    m.undo_str = f'[Modifier Editor] md apply End (multi-user)'

                    call_progress(*self.multi_user_do(oj))
                def call_mess():
                    self.top_win = win_mess.MESS_BOOL(*self.tm_mouse,
                        "Multi-user detected. Do you want to continue?",
                        fn_yes, N)

                self.modal_sort_fin_D1      = call_mess
            else:
                self.modal_sort_fin_D1      = call_progress
                m.undo_str = f'[Modifier Editor] md apply Start'
                m.undo_push()
                m.undo_str = f'[Modifier Editor] md apply End'
        elif region == self.evt_region_mt_link:
            if self.mt_win.oj.type != oj.type:
                def call_mess():
                    win_mess.MESS(*self.tm_mouse, "Different object type are detected. Cancelled.")
                self.modal_sort_fin_D1 = call_mess
                self.anim_cancel_multi(tm_pop)
                return

            if self.mt_win.oj.library:
                def call_mess():
                    win_mess.MESS(*self.tm_mouse, str_uncopy)
                self.modal_sort_fin_D1 = call_mess
                self.anim_cancel_multi(tm_pop)
                return

            def call_mess():
                self.top_win = win_mess.MENU_MOD_LINK(
                    *self.tm_mouse,
                    [
                        ("bu_move", "Move"),
                        ("bu_copy", "Copy"),
                        ("bu_link", "Link by Driver"),
                        ("bu_dlink", "Deep Link by Driver")
                    ],
                    self.link_menu_end_multi)
                if oj.library:  self.top_win.oo["bu_move"].disable()

            self.modal_sort_fin_D1 = call_mess
            TM = win_mess.TM
            TM["mt_win"]        = self.mt_win
            TM["sel_range"]     = self.sel_range.copy()
            TM["obs"]           = self.obs
            TM["ll_bpy"]        = self.ll_bpy
        elif region == self.evt_region_mt_apply:
            if self.mt_win.oj.type != oj.type:
                def call_mess():
                    win_mess.MESS(*self.tm_mouse, "Different object type are detected. Cancelled.")
                self.modal_sort_fin_D1 = call_mess
                self.anim_cancel_multi(tm_pop)
                return

            if oj.library:
                def call_mess():
                    win_mess.MESS(*self.tm_mouse, str_unapply)
                self.modal_sort_fin_D1 = call_mess
                self.anim_cancel_multi(tm_pop)
                return

            mt_oj   = self.mt_win.oj
            tm_obs  = self.tm_obs
            job_li  = [tm_obs[r] for r in range(len(tm_obs)) if r in self.sel_range]
            self.job_ind    = 0
            l               = len(job_li)
            apply_md        = self.bpy_apply_by_name
            TM              = win_mess.TM

            def when_copy_fail():

                self.top_win.fin()
                self.bpy_ops_end()
                m.undo()
                if bpy.context.object.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode = "OBJECT")
                    m.undo_str = "UNDO REVERSE"
                    m.undo_push()
                    m.undo()
                new_mess = win_mess.MESS(*self.tm_mouse, "Can't Move/Copy to this object. Cancelled")
                new_mess.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
                m.admin.push_modal()
            def job_fn_apply(name):
                apply_md(name)
                self.job_ind += 1
                return self.job_ind
            def fn_yes():
                act_md_org      = self.w.act_md
                keep_org        = self.top_win.oo["keep"].da.name
                m.upd_disable()
                if TM["multi_user_data"]:
                    m.undo_str = f'[Modifier Editor] md apply to object Start (multi-user)'
                    m.undo_push()
                    m.undo_str = f'[Modifier Editor] md apply to object End (multi-user)'
                    TM["multi_user_data"] = self.multi_user_do(mt_oj)
                else:
                    m.undo_str = f'[Modifier Editor] md apply to object Start'
                    m.undo_push()
                    m.undo_str = f'[Modifier Editor] md apply to object End'
                if oj == mt_oj:
                    try:
                        self.bpy_ops_init()
                    except:
                        m.upd_enable()
                        m.admin.report({'INFO'}, "Object is hidden")
                        return

                    if keep_org:
                        modifiers   = oj.modifiers
                        self.off_show_viewport(modifiers)
                        dic_show_viewport   = TM["show_viewport"]
                        md_table            = {md.name : md for md in job_li}
                        md_copied   = []
                        bpy_copy    = self.bpy_copy
                        job_fn_view = self.job_fn_restore_show_viewport

                        def job_fn_copy(name):
                            if bpy_copy(name):
                                new_md = modifiers.active
                                md_copied.append(new_md)
                                dic_show_viewport[new_md] = dic_show_viewport[md_table[name]]
                            else:
                                when_copy_fail()

                            self.job_ind += 1
                            return self.job_ind
                        def job_fn_copy_end():
                            self.top_win.gen = (job_fn_view(dic_show_viewport, md)
                                for md in md_copied)
                            self.top_win.end_fn = job_fn_view_end
                        def job_fn_view_end():
                            self.top_win.gen = (job_fn_apply(md.name) for md in md_copied)
                            self.top_win.end_fn = job_fn_apply_end
                        def job_fn_apply_end():
                            self.top_win.gen = (job_fn_view(dic_show_viewport, md)
                                for md in modifiers)
                            self.top_win.end_fn = job_fn_final
                        def job_fn_final():
                            if TM["multi_user_data"]:
                                self.multi_user_restore(*TM["multi_user_data"])
                            self.job_fn_end_del()
                            md_copied.clear()
                            job_li.clear()
                            md_table.clear()
                            if "show_viewport" in TM:   TM["show_viewport"].clear()
                            TM.clear()
                            act_ind = modifiers.find(act_md_org.name)
                            if act_ind != -1:
                                old_ind = self.actbox.ind
                                self.sel_ext_by_ind(act_ind)
                                if old_ind in self.sel_range:
                                    del self.sel_range[old_ind]
                                    if old_ind in self.ind_sel:
                                        del self.ind_sel[old_ind]
                                        self.ind_desel[old_ind] = None

                        self.top_win = win_mess.PROGRESS(*self.top_win.R_center_pos(), self,
                            l*3 + len(modifiers),
                            (job_fn_copy(md.name) for md in job_li),
                            job_fn_copy_end, self.job_fn_abort, self.job_fn_undo, N)
                    else:
                        def job_fn_final():
                            if TM["multi_user_data"]:
                                self.multi_user_restore(*TM["multi_user_data"])
                            self.job_fn_end_del()
                            job_li.clear()
                            if "show_viewport" in TM:   TM["show_viewport"].clear()
                            TM.clear()
                            self.modal_sort_desel_all()

                        self.top_win = win_mess.PROGRESS(*self.top_win.R_center_pos(), self, l,
                            (job_fn_apply(md.name) for md in job_li),
                            job_fn_final, self.job_fn_abort, self.job_fn_undo, N)
                else: # Different object
                    modifiers       = oj.modifiers
                    mt_modifiers    = mt_oj.modifiers
                    mt_visible      = mt_oj.visible_get()
                    if mt_visible is False: mt_oj.hide_set(False)
                    self.off_show_viewport(modifiers)
                    self.off_show_viewport(mt_modifiers)
                    try:
                        self.bpy_ops_select_init()
                    except:
                        m.upd_enable()
                        m.admin.report({'INFO'}, "Object is hidden")
                        return
                    dic_show_viewport   = TM["show_viewport"]
                    md_table            = {md.name : md for md in job_li}
                    md_copied       = []
                    bpy_copy_to     = self.bpy_copy_to
                    job_fn_view     = self.job_fn_restore_show_viewport
                    bpy_del_md      = self.bpy_remove_by_name
                    mt_oj.select_set(True)

                    def job_fn_del(name):
                        bpy_del_md(name)
                        self.job_ind += 1
                        return self.job_ind
                    def job_fn_copy_to(name):
                        if bpy_copy_to(name):
                            new_md = mt_modifiers.active
                            md_copied.append(new_md)
                            dic_show_viewport[new_md] = dic_show_viewport[md_table[name]]
                        else:
                            when_copy_fail()

                        self.job_ind += 1
                        return self.job_ind
                    def job_fn_copy_end():
                        self.top_win.gen = (job_fn_view(dic_show_viewport, md)
                            for md in md_copied)
                        self.top_win.end_fn = job_fn_view_end
                        m.set_active_object(mt_oj)
                    def job_fn_view_end():
                        self.top_win.gen = (job_fn_apply(md.name) for md in md_copied)
                        self.top_win.end_fn = job_fn_apply_end
                    def job_fn_del_end():
                        self.top_win.gen = (job_fn_view(dic_show_viewport, md)
                            for md in mt_modifiers)
                        self.top_win.end_fn = job_fn_mt_view_end
                    def job_fn_apply_end():
                        if keep_org:    job_fn_del_end()
                        else:
                            m.set_active_object(oj)
                            self.top_win.gen = (job_fn_del(md.name)
                                for md in reversed(job_li))
                            self.top_win.end_fn = job_fn_del_end
                    def job_fn_mt_view_end():
                        self.top_win.gen = (job_fn_view(dic_show_viewport, md)
                            for md in modifiers)
                        self.top_win.end_fn = job_fn_final
                    def job_fn_final():
                        if TM["multi_user_data"]:
                            self.multi_user_restore(*TM["multi_user_data"])
                        if mt_visible is False: mt_oj.hide_set(True)
                        self.job_fn_end_del()
                        md_copied.clear()
                        job_li.clear()
                        md_table.clear()
                        if "show_viewport" in TM:   TM["show_viewport"].clear()
                        TM.clear()

                        if not keep_org:    self.modal_sort_desel_all()

                    self.top_win = win_mess.PROGRESS(*self.top_win.R_center_pos(), self,
                        l*3 + len(modifiers) + len(mt_modifiers),
                        (job_fn_copy_to(md.name) for md in job_li),
                        job_fn_copy_end, self.job_fn_abort, self.job_fn_undo, N)

            def call_mess():
                if TM["multi_user_data"]:   evt_x, evt_y = self.top_win.R_center_pos()
                else:                       evt_x, evt_y = self.tm_mouse
                top_win = win_mess.MESS_BOOL(evt_x, evt_y,
                    "It will be applied to this object, do you want to continue?",
                    fn_yes,
                    N,
                    hide_tb = True,
                    height  = F[150])

                self.top_win = top_win
                bu_keep = win_mess.bu.BU_BOOL(top_win.main_area, "keep",
                    "Keep the original")

                top_win.oo["keep"] = bu_keep
                blf_size(font_0, F[9])
                e = top_win.box["main"]
                bu_keep.RB(e.R - F[13], e.B + F[52])

            if mt_oj.data.users > 1:
                def call_mess_confirm():
                    self.top_win = win_mess.MESS_BOOL(*self.tm_mouse,
                        "Multi-user detected. Do you want to continue?",
                        call_mess, N)

                TM["multi_user_data"]       = True
                self.modal_sort_fin_D1      = call_mess_confirm
            else:
                TM["multi_user_data"]       = False
                self.modal_sort_fin_D1      = call_mess
        else:   self.modal_sort_fin_D1 = N
        # do cancel
        self.anim_cancel_multi(tm_pop)
    # MT LINK MENU
    def link_menu_end(self):

        m.head_modal.append(N)
        self.w.U_modal = self.w.default_modal

        job         = win_mess.TM["job"]
        mt          = self.mt_win
        mt_mods     = mt.R_A_ll()

        if job is False:
            self.tm_evt_region = self.evt_region_mt_cancel
            self.modal_sort_exit(None)
            del self.top_win
            return

        top_win     = self.top_win
        li          = self.li
        hi          = self.md_hi
        v           = self.tm_an_speed
        cv          = self.cv
        d_cy        = self.d_cy
        tm_pop      = self.tm_pop
        oj          = self.w.oj
        mt_oj       = mt.oj
        pop_name    = self.obs[self.tm_pop_ind_org].name
        mt_obs      = mt_mods.obs
        mt_sel_name = {mt_obs[i].name for i in mt_mods.sel_range}

        tm_pop.name.text    = tm_pop.name.size
        tm_pop.name.color   = P.color_font_mod_name

        if oj == mt_oj:

            try:
                self.bpy_ops_init()
            except:
                self.tm_evt_region = self.evt_region_mt_cancel
                self.modal_sort_exit(None)
                del self.top_win
                return
            is_same_oj  = True
            bpy_copy    = self.bpy_copy
            oj_visible  = True
            mt_oj_visible = True
        else:
            try:
                self.bpy_ops_select_init()
            except:
                self.tm_evt_region = self.evt_region_mt_cancel
                self.modal_sort_exit(None)
                del self.top_win
                return
            is_same_oj  = False
            bpy_copy    = self.bpy_copy_to
            oj_visible  = oj.visible_get()
            mt_oj_visible  = mt_oj.visible_get()
            if oj_visible is False:     oj.hide_set(False)
            if mt_oj_visible is False:  mt_oj.hide_set(False)
            mt_oj.select_set(True)
            oj.select_set(True)

        if is_same_oj and job == "bu_move":

            if mt_mods.tm_pop_ind > self.tm_pop_ind_org: mt_mods.tm_pop_ind -= 1

            self.bpy_move_to_ind(pop_name, mt_mods.tm_pop_ind)
            if oj.modifiers[mt_mods.tm_pop_ind].name != pop_name:
                self.call_win_not_match(None, None)
        elif is_same_oj and oj.modifiers[pop_name].type in D_only_one:

            win_mess.MESS(*self.tm_mouse, "Only one modifier of this type is allowed: CLOTH, COLLISION, FLUID, SOFT_BODY")
        elif bpy_copy(pop_name):
            new_ob      = mt_oj.modifiers.active
            new_ind     = mt_mods.R_ind_by_name(new_ob.name)


            if is_same_oj:  pass
            else:
                mt_oj.select_set(False)
                oj.select_set(False)
                m.set_active_object(mt_oj)
            mt_mods.bpy_move_to_ind(new_ob.name, mt_mods.tm_pop_ind)
            if mt_mods.R_ind_by_name(new_ob.name) != mt_mods.tm_pop_ind:
                self.call_win_not_match(None, None)

            dp      = f'modifiers["{pop_name}"].'
            dp_tar  = f'modifiers["{new_ob.name}"].'

            if job in {"bu_move", "bu_copy"}:
                if top_win.oo["bu_kf"].da.name:
                    self.copy_kf(oj, mt_oj, new_ob, dp, dp_tar)
                if top_win.oo["bu_dr"].da.name:
                    self.copy_dr(oj, mt_oj, new_ob, dp, dp_tar)

                if job == "bu_move":

                    m.set_active_object(oj)
                    self.bpy_remove_by_name(pop_name)
            elif job == "bu_link":  link_modifier(oj, mt_oj, oj.modifiers[pop_name], new_ob)
            else:              deep_link_modifier(oj, mt_oj, oj.modifiers[pop_name], new_ob)
        else:

            win_mess.MESS(*self.tm_mouse, "Can't Move/Copy to this object. Cancelled")

        m.undo_str = f'[Modifier Editor] md {job[3:]}'
        if oj_visible is False:     oj.hide_set(True)
        if mt_oj_visible is False:  mt_oj.hide_set(True)
        self.bpy_ops_end()

        self.w.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
        self.kill_mt_sort()

        self.thread_li_y.clear()
        self.thread_sep.clear()
        self.threads.clear()
        self.U_draw = self.I_draw
        self.kill_mods()

        self.modal_sort_fin(init_wait_release = False)
        dict_ind            = {e.name : i  for i, e in enumerate(mt_mods.obs)}
        mt_mods.sel_range   = {dict_ind[name] : None for name in mt_sel_name if name in dict_ind}
        mt_mods.sel_range[mt_mods.R_act_ind()] = None
        mt_mods.get_draw_ind_by_sel_range()
        del self.top_win
    def link_menu_end_multi(self):

        TM          = win_mess.TM
        job         = TM["job"]

        if job is False:    return

        mt          = TM["mt_win"]
        mt_mods     = mt.R_A_ll()
        w_oj        = self.w.oj
        mt_oj       = mt.oj
        top_win     = self.top_win
        ind         = mt_mods.tm_pop_ind
        obs         = TM["obs"]
        tm_obs      = w_oj.modifiers
        mt_obs      = mt_oj.modifiers
        sel_range   = TM["sel_range"]

        if w_oj == mt_oj and job != "bu_move":
            if any([tm_obs[r].type in D_only_one for r in sel_range]):
                win_mess.MESS(*self.tm_mouse, "Abort, Contains modifier types that cannot be copied. Only one modifier of this type is allowed: CLOTH, COLLISION, FLUID, SOFT_BODY")
                return

        m.upd_disable()

        m.undo_str = f'[Modifier Editor] md {job[3:]} Start'
        m.undo_push()
        m.undo_str = f'[Modifier Editor] md {job[3:]} End'

        self.off_show_viewport(tm_obs)

        if w_oj == mt_oj:

            try:
                self.bpy_ops_init()
            except:
                m.upd_enable()
                m.admin.report({'INFO'}, "Object is hidden")
                return
            is_same_oj  = True
            tm_job_fn   = self.bpy_copy
            oj_visible  = True
            mt_oj_visible = True
        else:
            try:
                self.bpy_ops_select_init()
            except:
                m.upd_enable()
                m.admin.report({'INFO'}, "Object is hidden")
                return
            is_same_oj  = False
            tm_job_fn   = self.bpy_copy_to
            oj_visible  = w_oj.visible_get()
            mt_oj_visible  = mt_oj.visible_get()
            if oj_visible is False:     w_oj.hide_set(False)
            if mt_oj_visible is False:  mt_oj.hide_set(False)
            mt_oj.select_set(True)
            w_oj.select_set(True)

            self.off_show_viewport(mt_obs)

        dic_show_viewport   = TM["show_viewport"]
        self.job_ind        = 0

        if is_same_oj and job == "bu_move":

            pop_ind         = ind - sum(e < ind for e in sel_range)
            pop_ind_org     = self.tm_pop_ind_org

            li_sort         = self.sort_end_multi_R_li_sort(pop_ind, pop_ind_org,
                (tm_obs, obs, sel_range, TM["ll_bpy"]))

            l               = len(li_sort)
            move_to_ind     = self.bpy_move_to_ind

            def job_fn(i):
                move_to_ind(li_sort[i], i)
                self.job_ind += 1
                return self.job_ind
            def to_restore():
                job_restore             = self.job_fn_restore_show_viewport
                self.top_win.gen        = (job_restore(dic_show_viewport, e) for e in tm_obs)
                self.top_win.end_fn     = self.job_fn_end_sort

            TM["md_sels"]      = {md for i, md in enumerate(tm_obs) if i in sel_range}
            TM["li_match"]     = li_sort
            TM["modifiers"]    = tm_obs

            self.top_win = win_mess.PROGRESS(*self.tm_mouse, self, l + l,
                (job_fn(r) for r in range(l -1, -1, -1)),
                to_restore, self.job_fn_abort, self.job_fn_undo, N
            )
            return

        job_li          = [e for r, e in enumerate(tm_obs) if r in sel_range]
        md_table        = {md.name : md for md in job_li}
        l               = len(job_li)
        md_copied       = []
        keep_kf         = top_win.oo["bu_kf"].da.name
        keep_dr         = top_win.oo["bu_dr"].da.name
        copy_kf         = self.copy_kf
        copy_dr         = self.copy_dr
        move_to_ind     = self.bpy_move_to_ind
        remove_md       = self.bpy_remove_by_name
        obs_copy        = [e for e in mt_obs]

        def check_is_match():
            for r in range(ind):
                if mt_obs[r] != obs_copy[r]:    return False
            n   = 0
            r0  = ind + len(md_copied)
            for r in range(ind, r0):
                if mt_obs[r] != md_copied[n]:   return False
                n += 1
            n   = ind
            for r in range(r0, len(mt_obs)):
                if mt_obs[r] != obs_copy[n]:    return False
                n += 1
            return True
        def job_fn_move(name):
            move_to_ind(name, ind)
            self.job_ind += 1
            return self.job_ind
        def job_fn_move_end():
            job_restore             = self.job_fn_restore_show_viewport
            self.top_win.gen        = (job_restore(dic_show_viewport, e) for e in tm_obs)
            self.top_win.end_fn     = job_fn_done  if is_same_oj else job_fn_move_end2
        def job_fn_move_end2():
            job_restore             = self.job_fn_restore_show_viewport
            self.top_win.gen        = (job_restore(dic_show_viewport, e) for e in mt_obs)
            self.top_win.end_fn     = job_fn_done
        def job_fn_done():
            self.top_win.when_job_done()
            if oj_visible is False:     w_oj.hide_set(True)
            if mt_oj_visible is False:  mt_oj.hide_set(True)
            self.bpy_ops_end()

            self.top_win.callfront = lambda x: m.M.set_mou_ic("DEFAULT")
            m.upd_enable()
            m.refresh()

            fix_ind = False
            act_ind = self.R_act_ind()
            if act_ind != -1:
                m.upd_disable()
                sel_range = self.sel_range
                sel_range.clear()
                sel_range[act_ind] = None
                for i, md in enumerate(tm_obs):
                    if md in job_li:    sel_range[i] = None
                self.get_draw_ind_by_sel_range()
                fix_ind = True
            if md_copied:
                act_ind = mt_mods.R_act_ind()
                if act_ind != -1:
                    m.upd_disable()
                    mt_sel_range = mt_mods.sel_range
                    mt_sel_range.clear()
                    mt_sel_range[act_ind] = None
                    for i, md in enumerate(mt_obs):
                        if md in md_copied:    mt_sel_range[i] = None
                    mt_mods.get_draw_ind_by_sel_range()
                    fix_ind = True

            if fix_ind:
                m.upd_enable()
                m.refresh()



            if check_is_match() is False:   self.call_win_not_match(None, None, hide_tb = False)

            obs_copy.clear()
            md_copied.clear()
            job_li.clear()
            md_table.clear()
            TM.clear()
        def job_fn_copy(name):
            if tm_job_fn(name):
                new_md      = mt_obs.active
                md_copied.append(new_md)
                dic_show_viewport[new_md] = dic_show_viewport[md_table[name]]
                dp          = f'modifiers["{name}"].'
                dp_tar      = f'modifiers["{new_md.name}"].'

                if keep_kf: copy_kf(w_oj, mt_oj, new_md, dp, dp_tar)
                if keep_dr: copy_dr(w_oj, mt_oj, new_md, dp, dp_tar)
            else:

                self.top_win.fin()
                self.bpy_ops_end()
                m.undo()
                if bpy.context.object.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode = "OBJECT")
                    m.undo_str = "UNDO REVERSE"
                    m.undo_push()
                    m.undo()
                new_mess = win_mess.MESS(*self.tm_mouse, "Can't Move/Copy to this object. Cancelled")
                new_mess.callfront = lambda xx: m.admin.push_modal(lambda x: m.M.set_mou_ic("DEFAULT"))

            self.job_ind += 1
            return self.job_ind
        def job_fn_del_org(name):
            remove_md(name)
            self.job_ind += 1
            return self.job_ind
        def job_next_del_org():
            m.set_active_object(w_oj)
            self.top_win.gen = (job_fn_del_org(md.name) for md in job_li)
            self.top_win.end_fn = job_fn_move_end
        TM["job_next"] = False
        def job_next():

            if is_same_oj:
                if TM["job_next"]:
                    self.top_win.gen = (job_fn_move(e.name) for e in reversed(md_copied))
                    self.top_win.end_fn = job_fn_move_end
                    return

                TM["job_next"]  = True
                end_ind         = len(mt_obs) - 1
                def job_fn_move_to_end(name):
                    move_to_ind(name, end_ind)
                    self.job_ind += 1
                    return self.job_ind
                self.top_win.gen = (job_fn_move_to_end(e.name) for e in md_copied)
            else:
                m.set_active_object(mt_oj)
                self.top_win.gen = (job_fn_move(e.name) for e in reversed(md_copied))
                if job == "bu_move":    self.top_win.end_fn = job_next_del_org
                else:                   self.top_win.end_fn = job_fn_move_end


        if job == "bu_copy":
            self.top_win = win_mess.PROGRESS(*self.tm_mouse, self,
                l*4 + len(tm_obs)  if is_same_oj else l*3 + len(mt_obs) + len(tm_obs),
                (job_fn_copy(md.name) for md in job_li),
                job_next, self.job_fn_abort, self.job_fn_undo, N
            )
        elif job == "bu_move":
            self.top_win = win_mess.PROGRESS(*self.tm_mouse, self,
                l*3 + len(mt_obs) + len(tm_obs),
                (job_fn_copy(md.name) for md in job_li),
                job_next, self.job_fn_abort, self.job_fn_undo, N
            )
        elif job in {"bu_link", "bu_dlink"}:
            option = link_modifier  if job == "bu_link" else deep_link_modifier
            def job_fn_link(name):
                if tm_job_fn(name):
                    new_md      = mt_obs.active
                    md_copied.append(new_md)
                    source_md   = md_table[name]
                    dic_show_viewport[new_md] = dic_show_viewport[source_md]
                    dp          = f'modifiers["{name}"].'
                    dp_tar      = f'modifiers["{new_md.name}"].'

                    option(w_oj, mt_oj, source_md, new_md)
                else:

                    self.top_win.fin()
                    self.bpy_ops_end()
                    m.undo()
                    if bpy.context.object.mode != "OBJECT":
                        bpy.ops.object.mode_set(mode = "OBJECT")
                        m.undo_str = "UNDO REVERSE"
                        m.undo_push()
                        m.undo()
                    new_mess = win_mess.MESS(*self.tm_mouse, "Can't Move/Copy to this object. Cancelled")
                    new_mess.callfront = lambda xx: m.admin.push_modal(lambda x: m.M.set_mou_ic("DEFAULT"))

                self.job_ind += 1
                return self.job_ind

            self.top_win = win_mess.PROGRESS(*self.tm_mouse, self,
                l*4 + len(tm_obs)  if is_same_oj else l*3 + len(mt_obs) + len(tm_obs),
                (job_fn_link(md.name) for md in job_li),
                job_next, self.job_fn_abort, self.job_fn_undo, N
            )
        else:
            "TODO"

    def exit_fn_cancel(self, _self):
        li          = self.li
        cv          = self.cv
        i           = min(max(self.headkey, self.tm_pop_ind_org), self.endkey)

        blf_size(font_0, F[9])
        e       = self.li_type()
        li[i]   = e

        self.init_li_data(i, e, self.drivers, self.fcurves)
        e.upd_blf_y(cv.T - self.d_cy - i * self.md_hi)
        T       = e.y + self.d_cy
        e.bg.upd_bat(cv.L, cv.R, T - self.md_h, T)
        e.ic.upd(self.ref.ic, e.y)
    def exit_fn_sort(self, _self):
        li          = self.li
        cv          = self.cv
        i           = min(max(self.headkey, self.tm_pop_ind), self.endkey)

        blf_size(font_0, F[9])
        e       = self.li_type()
        li[i]   = e

        self.init_li_data(i, e, self.drivers, self.fcurves)
        e.upd_blf_y(cv.T - self.d_cy - i * self.md_hi)
        T       = e.y + self.d_cy
        e.bg.upd_bat(cv.L, cv.R, T - self.md_h, T)
        e.ic.upd(self.ref.ic, e.y)
    def exit_fn_del(self, _self):
        self.ll_li  = len(self.li)
        self.ll_bpy = len(self.obs)
        self.headkey, self.endkey = self.R_headkey_endkey()

    # REGION EVT
    def evt_region_sort(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.region_win_L <= x <= self.region_win_R and self.region_win_B <= y <= self.region_win_T:
            if self.region_L <= x <= self.region_R and self.region_B <= y <= self.region_T: pass
            else:
                if x > self.region_R:               self.to_region_del()
                elif x < self.region_L:
                    if y >= self.region_apply_B:    self.to_region_apply()
                    else:                           self.to_region_cancel()
                else:                               self.to_region_cancel()
        else:
            self.get_mt_win(evt)
            self.init_mt_sort(evt)
    def evt_region_cancel(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.region_win_L <= x <= self.region_win_R and self.region_win_B <= y <= self.region_win_T:
            if self.region_L <= x <= self.region_R and self.region_B <= y <= self.region_T:
                self.to_region_sort()
            elif x > self.region_R:     self.to_region_del()
            elif x < self.region_L and y >= self.region_apply_B:    self.to_region_apply()
        else:
            self.get_mt_win(evt)
            self.init_mt_sort(evt)
    def evt_region_del(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.region_win_L <= x <= self.region_win_R and self.region_win_B <= y <= self.region_win_T:
            if self.region_L <= x <= self.region_R and self.region_B <= y <= self.region_T:
                self.to_region_sort()
            elif x < self.region_L:
                if y >= self.region_apply_B:    self.to_region_apply()
                else:                           self.to_region_cancel()
            elif x > self.region_R:   pass
            else:   self.to_region_cancel()
        else:
            self.get_mt_win(evt)
            self.init_mt_sort(evt)
    def evt_region_apply(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.region_win_L <= x <= self.region_win_R and self.region_win_B <= y <= self.region_win_T:
            if self.region_L <= x <= self.region_R and self.region_B <= y <= self.region_T:
                self.to_region_sort()
            elif x > self.region_R:     self.to_region_del()
            elif x < self.region_L and y >= self.region_apply_B:  pass
            else:   self.to_region_cancel()
        else:
            self.get_mt_win(evt)
            self.init_mt_sort(evt)
    def evt_region_mt_link(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.region_win_L <= x <= self.region_win_R and self.region_win_B <= y <= self.region_win_T:
            if self.region_L <= x <= self.region_R and self.region_B <= y <= self.region_T:
                self.to_region_sort()
            elif x > self.region_R:     self.to_region_del()
            elif x < self.region_L and y >= self.region_apply_B:  self.to_region_apply()
            else:   self.to_region_cancel()

            self.end_mt_sort()
            return
        e = self.mt_win
        if e.box["rim"].inbox(evt) is False:
            self.end_mt_sort()
            self.get_mt_win(evt)
            self.init_mt_sort(evt)
            return
        if e.is_link_area(evt):     pass
        elif evt.mouse_region_y >= e.R_bo_info_B() and evt.mouse_region_x < e.R_A_ll().cv.L:
            self.to_region_mt_apply()
        else: self.to_region_mt_cancel()
        self.U_mt_modal(evt)
    def evt_region_mt_apply(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.region_win_L <= x <= self.region_win_R and self.region_win_B <= y <= self.region_win_T:
            if self.region_L <= x <= self.region_R and self.region_B <= y <= self.region_T:
                self.to_region_sort()
            elif x > self.region_R:     self.to_region_del()
            elif x < self.region_L and y >= self.region_apply_B:  self.to_region_apply()
            else:   self.to_region_cancel()

            self.end_mt_sort()
            return
        e = self.mt_win
        if e.box["rim"].inbox(evt) is False:
            self.end_mt_sort()
            self.get_mt_win(evt)
            self.init_mt_sort(evt)
            return
        if e.is_link_area(evt):     self.to_region_mt_link()
        elif evt.mouse_region_y >= e.R_bo_info_B() and evt.mouse_region_x < e.R_A_ll().cv.L:
            pass
        else: self.to_region_mt_cancel()
        self.U_mt_modal(evt)
    def evt_region_mt_cancel(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.region_win_L <= x <= self.region_win_R and self.region_win_B <= y <= self.region_win_T:
            if self.region_L <= x <= self.region_R and self.region_B <= y <= self.region_T:
                self.to_region_sort()
            elif x > self.region_R:     self.to_region_del()
            elif x < self.region_L and y >= self.region_apply_B:  self.to_region_apply()
            else:   self.to_region_cancel()

            self.end_mt_sort()
            return
        e = self.mt_win
        if e.box["rim"].inbox(evt) is False:
            self.end_mt_sort()
            self.get_mt_win(evt)
            self.init_mt_sort(evt)
            return
        if e.is_link_area(evt):     self.to_region_mt_link()
        elif evt.mouse_region_y >= e.R_bo_info_B() and evt.mouse_region_x < e.R_A_ll().cv.L:
            self.to_region_mt_apply()
        self.U_mt_modal(evt)
    def evt_region_mt_del(self, evt):
        x = evt.mouse_region_x
        y = evt.mouse_region_y
        if self.region_win_L <= x <= self.region_win_R and self.region_win_B <= y <= self.region_win_T:
            if self.region_L <= x <= self.region_R and self.region_B <= y <= self.region_T:
                self.to_region_sort()
            elif x > self.region_R:     self.to_region_del()
            elif x < self.region_L and y >= self.region_apply_B:  self.to_region_apply()
            else:   self.to_region_cancel()

            return

        for e in self.mt_wins:
            if e.box["rim"].inbox(evt):
                if e.is_link_area(evt):     self.to_region_mt_link()
                elif evt.mouse_region_y >= e.R_bo_info_B() and evt.mouse_region_x < e.R_A_ll().cv.L:
                    self.to_region_mt_apply()
                else: self.to_region_mt_cancel()
                self.mt_win = e

                self.init_mt_sort(evt)
                return

    def to_region_sort(self):

        self.tm_evt_region = self.evt_region_sort
        e = self.tm_pop.name
        e.text = e.size
        e.color = P.color_font_mod_name
    def to_region_cancel(self):

        self.tm_evt_region = self.evt_region_cancel
        e = self.tm_pop.name
        e.text = " CANCEL"
        e.color = P.color_font
    def to_region_del(self):

        self.tm_evt_region = self.evt_region_del
        e = self.tm_pop.name
        e.text = " REMOVE"
        e.color = P.color_font_red
    def to_region_apply(self):

        self.tm_evt_region = self.evt_region_apply
        e = self.tm_pop.name
        e.text = " APPLY TO TOP"
        e.color = P.color_font_sub_ti
    def to_region_mt_link(self):

        self.tm_evt_region = self.evt_region_mt_link
        e = self.tm_pop.name
        e.text = " MOVE COPY LINK"
        e.color = P.color_font
    def to_region_mt_apply(self):

        self.tm_evt_region = self.evt_region_mt_apply
        e = self.tm_pop.name
        e.text = " APPLY HERE"
        e.color = P.color_font_sub_ti
    def to_region_mt_cancel(self):

        self.tm_evt_region = self.evt_region_mt_cancel
        e = self.tm_pop.name
        e.text = " CANCEL"
        e.color = P.color_font
    def to_region_mt_del(self):

        self.tm_evt_region = self.evt_region_mt_del
        e = self.tm_pop.name
        e.text = " REMOVE"
        e.color = P.color_font_red

    def get_mt_win(self, evt):
        for e in self.mt_wins:
            if e.box["rim"].inbox(evt):
                if e.is_link_area(evt):     self.to_region_mt_link()
                elif evt.mouse_region_y >= e.R_bo_info_B() and evt.mouse_region_x < e.R_A_ll().cv.L:
                    self.to_region_mt_apply()
                else: self.to_region_mt_cancel()
                self.mt_win = e

                return
        self.to_region_mt_del()
        self.mt_win = None
    # MT SORT
    def init_mt_sort(self, evt):
        mt_win = self.mt_win
        if mt_win is None:     return

        i = m.W_M.index(self.w)
        if m.W_M[i - 1] != mt_win:
            w = self.w
            m.W_M.remove(mt_win)
            m.W_M.insert(i - 1, mt_win)
            i = m.W_D.index(w)
            m.W_D.remove(mt_win)
            m.W_D.insert(i - 1, mt_win)
            self.mt_wins    = [e for e in reversed(m.W_M)  if e in W_MO and e != w]
        w = self.mt_win.R_A_ll()
        if w.ll_bpy == 0:
            self.U_mt_modal = N
            w.tm_pop_ind    = 0
            w.thread_li_y   = {}
            w.thread_sep    = {}
            return

        self.U_mt_modal     = self.I_mt_modal
        self.mt_win_mods    = w
        w.U_draw            = w.I_draw_modal_sort
        w.tm_unit_speed     = self.tm_unit_speed
        li                  = w.li
        hi                  = - self.md_hi
        v                   = - self.tm_an_speed

        if w.U_modal_thread is not None:    w.thread_sep.clear()
        else:
            w.init_thread()
            self.threads[w] = None

        w.get_auto_pan_data()
        i = min(max(w.headkey, w.R_ind_by_mou(evt.mouse_region_y)), w.endkey)
        for r in range(i, w.endkey + 1):    w.thread_li_y_add(li[r], hi, v)
        w.tm_pop_ind        = i
        w.tm_pop_ind_org    = i


    def end_mt_sort(self):
        w = self.mt_win_mods

        if w is None:       return
        if w.ll_bpy == 0:   return

        self.U_mt_modal = N
        li              = w.li
        hi              = self.md_hi
        v               = self.tm_an_speed

        for r in range(w.tm_pop_ind, w.endkey + 1):     w.thread_li_y_add(li[r], hi, v)

        w.get_draw_ind_by_sel_range()
        w.thread_sep[w] = AN_AUTOKILL(self.threads, self.mt_end_fn)
    def kill_mt_sort(self):
        w = self.mt_win.R_A_ll()
        if w is None:   return

        w.U_draw = w.I_draw
        w.thread_li_y.clear()
        w.thread_sep.clear()
        w.kill_thread()
        self.threads.clear()
        w.kill_mods()

    def mt_end_fn(self, w):
        w.U_draw        = w.I_draw
        w.actbox.get(w.cv, w.R_act_ind())

    def I_mt_modal(self, evt):
        evt_y   = evt.mouse_region_y
        w       = self.mt_win_mods
        pop_ind = min(max(w.headkey, w.R_ind_by_mou(evt_y)), w.endkey + 1)
        d_ind   = pop_ind - w.tm_pop_ind

        if d_ind > 0:
            li  = w.li
            i   = w.tm_pop_ind
            hi  = self.md_hi
            v   = self.tm_an_speed

            for r in range(i, i + d_ind):   w.thread_li_y_add(li[r], hi, v)

        elif d_ind < 0:
            li  = w.li
            i   = w.tm_pop_ind - 1
            hi  = - self.md_hi
            v   = - self.tm_an_speed

            for r in range(i, i + d_ind, -1):   w.thread_li_y_add(li[r], hi, v)

        if evt_y < w.tm_autoB:
            dy = max(1, int((w.tm_autoB - evt_y) * w.tm_pan_speed))
            old_T = w.cv.T
            y = old_T + dy
            if y < w.y:
                tm_dif = w.y - y
                dy += tm_dif
            elif y > w.tm_limyup:
                tm_dif = w.tm_limyup - y
                dy += tm_dif
            else:   tm_dif = 0
            self.pan_y_sort_mt(dy, tm_dif)
        elif evt_y > w.tm_autoT:
            dy = -max(1, int((evt_y - w.tm_autoT) * w.tm_pan_speed))
            old_T = w.cv.T
            y = old_T + dy
            if y < w.y:
                tm_dif = w.y - y
                dy += tm_dif
            elif y > w.tm_limyup:
                tm_dif = w.tm_limyup - y
                dy += tm_dif
            else:   tm_dif = 0
            w.pan_y_sort(dy, tm_dif)

        w.tm_pop_ind = pop_ind

    def pan_y_sort_mt(self, dy, tm_dif):
        w       = self.mt_win_mods
        li      = w.li
        cv      = w.cv
        d_cy    = self.d_cy
        h       = self.md_h
        L       = cv.L
        R       = cv.R

        cv_T_old    = cv.T
        cv.dy(dy)
        headkey     = w.R_headkey()

        if tm_dif != 0:
            new_y = min(max(w.y - tm_dif, w.tm_syslimdn), w.tm_syslimup)
            dif = new_y - w.y
            w.y = new_y
            w.tm_limyup += dif
            dy += dif
            cv.dy(dif)
        cv.upd()

        if w.headkey != headkey:
            blf_size(font_0, F[9])
            dn              = headkey - w.headkey
            drivers         = w.drivers
            fcurves         = w.fcurves
            init_li_data    = w.init_li_data
            if dn > 0:
                if dn >= w.max_ll:   dn = w.max_ll - 1

                hi = w.md_hi
                li_y = cv_T_old - d_cy - w.endkey * hi - hi

                newkey  = w.endkey + 1
                newhead = w.headkey + dn

                for r in range(w.headkey, newhead):
                    if r in li:  del li[r]
                    li[newkey]  = w.li_type()
                    e           = li[newkey]

                    init_li_data(newkey, e, drivers, fcurves)
                    e.upd_blf_y(li_y  if newkey < w.tm_pop_ind else li_y - hi)
                    li_y -= hi
                    newkey += 1

                w.headkey   = newhead
                w.endkey    = newkey - 1
            else:
                if -dn >= w.max_ll:  dn = 1 - w.max_ll

                hi = w.md_hi
                li_y = cv_T_old - d_cy - w.headkey * hi

                newkey = w.headkey - 1
                newend = w.endkey + dn
                for r in range(w.endkey, newend, -1):
                    if r in li:  del li[r]
                    li[newkey]  = w.li_type()
                    e           = li[newkey]

                    init_li_data(newkey, e, drivers, fcurves)
                    e.upd_blf_y(li_y + hi  if newkey < w.tm_pop_ind else li_y)
                    li_y += hi
                    newkey -= 1

                w.headkey   = newkey + 1
                w.endkey    = newend

        ref_ic = w.ref.ic
        for e in li.values():
            e.dy_blf(dy)
            T = e.y + d_cy
            e.bg.upd_bat(L, R, T - h, T)
            e.ic.upd(ref_ic, e.y)
        for e, an in w.thread_li_y.items():
            an.des += dy
            if e.y > an.des:
                if an.v > 0:    an.v = - an.v
            elif an.v < 0:      an.v = - an.v

# ▅▅▅  THREAD                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_modal_thread(self):
        for e, an in self.thread_li_y.copy().items():
            v       = an.v
            des     = e.y + v

            if v > 0:
                if des >= an.des:
                    v = an.des - e.y
                    del self.thread_li_y[e]
            elif des <= an.des:
                v = an.des - e.y
                del self.thread_li_y[e]

            e.dy_upd(v)

        if self.thread_sep:
            for e, an in self.thread_sep.copy().items():
                if an.fn(e):    del self.thread_sep[e]
        # m.redraw()
        return self.frame_time

    def thread_li_y_add(self, e, dy, v):
        if e in self.thread_li_y:
            an = self.thread_li_y[e]
            an.des += dy
            new_v = (an.des - e.y) * self.tm_unit_speed
            an.v = min(-1, round(new_v)) if new_v < 0 else max(1, round(new_v))
        else:
            self.thread_li_y[e] = AN(e.y + dy, v)
    def thread_sep_add_pop(self, tm_pop, x, y):
        v_over_hi = self.tm_an_speed / self.md_hi
        dy = y - tm_pop.y
        dx = x - tm_pop.x
        vy = max(1, int(v_over_hi * dy))  if dy >= 0 else min(-1, int(v_over_hi * dy))
        vx = max(1, int(v_over_hi * dx))  if dx >= 0 else min(-1, int(v_over_hi * dx))
        self.thread_sep[tm_pop] = AN_POP(tm_pop.x + dx, tm_pop.y + dy, vx, vy)

    def job_fn_end_sort_uncheck(self):
        self.top_win.when_job_done()
        m.undo_push()

        TM          = win_mess.TM
        modifiers   = TM["modifiers"]

        m.upd_enable()
        m.refresh()

        act_ind = self.R_act_ind()
        if act_ind != -1:
            m.upd_disable()
            sel_range = self.sel_range
            sel_range.clear()
            sel_range[act_ind] = None
            md_sels = TM["md_sels"]
            for i, md in enumerate(modifiers):
                if md.name in md_sels:   sel_range[i] = None
            self.get_draw_ind_by_sel_range()
            m.upd_enable()
            m.refresh()

        TM["md_sels"].clear()
        TM["li_match"].clear()
        TM.clear()
    def job_fn_end_sort(self):
        self.top_win.when_job_done()
        self.bpy_ops_end()
        m.admin.push_modal(lambda x: m.M.set_mou_ic("DEFAULT"))

        TM          = win_mess.TM
        li_sort     = TM["li_match"]
        modifiers   = TM["modifiers"]
        if any(e.name != li_sort[i] for i, e in enumerate(modifiers)):
            self.call_win_not_match(None, None, hide_tb = False)

        m.upd_enable()
        m.refresh()

        act_ind = self.R_act_ind()
        if act_ind != -1:
            m.upd_disable()
            sel_range = self.sel_range
            sel_range.clear()
            sel_range[act_ind] = None
            md_sels = TM["md_sels"]
            for i, md in enumerate(modifiers):
                if md in md_sels:   sel_range[i] = None
            self.get_draw_ind_by_sel_range()
            m.upd_enable()
            m.refresh()

        li_sort.clear()
        TM["md_sels"].clear()
        if "show_viewport" in TM:   TM["show_viewport"].clear()
        TM.clear()
    def job_fn_end_del(self):
        self.top_win.when_job_done()
        self.bpy_ops_end()
        m.admin.push_modal(lambda x: m.M.set_mou_ic("DEFAULT"))
        m.upd_enable()
        m.refresh()
    def job_fn_abort(self):
        self.bpy_ops_end()
        self.top_win.callfront = lambda xx: m.admin.push_modal(lambda x: m.M.set_mou_ic("DEFAULT"))
        m.upd_enable()
        m.refresh()
    def job_fn_undo(self):
        self.top_win.when_undo()
        if bpy.context.object.mode != "OBJECT":

            bpy.ops.object.mode_set(mode = "OBJECT")
            m.undo_str = "UNDO REVERSE"
            m.undo_push()
            m.undo()
            self.top_win.callfront = lambda xx: m.admin.push_modal(lambda x: m.M.set_mou_ic("DEFAULT"))

    def job_fn_restore_show_viewport(self, dic, md):
        try:    md.show_viewport = dic[md]
        except: pass
        finally:
            self.job_ind += 1
            return self.job_ind



class AN:
    __slots__ = "des", "v"
    def __init__(self, des, v):
        self.des    = des
        self.v      = v

class AN_POP:
    __slots__ = "des_x", "des_y", "v_x", "v_y"
    def __init__(self, des_x, des_y, v_x, v_y):
        self.des_x  = des_x
        self.des_y  = des_y
        self.v_x    = v_x
        self.v_y    = v_y
    def fn(self, e):
        vx          = self.v_x
        des         = e.x + vx
        is_x_fin    = False
        is_y_fin    = False

        if vx > 0:
            if des >= self.des_x:
                vx = self.des_x - e.x
                is_x_fin = True
        elif des <= self.des_x:
            vx = self.des_x - e.x
            is_x_fin = True

        vy          = self.v_y
        des         = e.y + vy
        if vy > 0:
            if des >= self.des_y:
                vy = self.des_y - e.y
                is_y_fin = True
        elif des <= self.des_y:
            vy = self.des_y - e.y
            is_y_fin = True

        e.dxy_upd(vx, vy)
        return is_x_fin and is_y_fin

class AN_AUTOKILL:
    __slots__ = "des", "v", "threads", "end_fn"
    def __init__(self, threads, end_fn):
        self.des        = -1
        self.v          = 0
        self.threads    = threads
        self.end_fn     = end_fn
    def fn(self, e):
        if e.thread_li_y:           return False
        if len(e.thread_sep) > 1:   return False

        self.end_fn(e)
        e.kill_thread()
        del self.threads[e]
        return True

class AN_AUTOKILL_ALL(AN_AUTOKILL):
    __slots__ = ()
    def fn(self, e):
        if e.thread_li_y:           return False
        if len(e.thread_sep) > 1:   return False
        if e.threads:               return False

        self.end_fn(e)
        e.kill_thread()
        e.modal_sort_fin()
        return True

class AN_color_0:
    __slots__ = "colors", "des", "v"
    def __init__(self, colors, des, v):
        self.colors = colors
        self.des    = des
        self.v      = v
    def fn(self, dum):
        v       = self.v
        is_end  = True

        for c in self.colors:
            c[3] += v
            if c[3] <= 0:   c[3] = 0.0
            else:           is_end = False

        return is_end

class AN_color_1(AN_color_0):
    __slots__ = ()
    def fn(self, dum):
        v       = self.v
        des     = self.des
        is_end  = True

        for i, c in enumerate(self.colors):
            c[3] += v
            if c[3] >= des[i]:  c[3] = des[i]
            else:               is_end = False

        return is_end

# class AN_POP_MULTI_INIT:
#     __slots__ = "host", "tm_pop", "v_B", "v_T"
#     def __init__(self, host, tm_pop, v_B, v_T):
#         self.host   = host
#         self.tm_pop = tm_pop
#         self.v_B    = v_B
#         self.v_T    = v_T

#     def fn(self, dum):
#         pop         = self.tm_pop
#         pop.bg_dB   += self.v_B
#         pop.bg_dT   += self.v_T

#         if self.v_B < 0:
#             if pop.bg_dB <= 0:
#                 pop.bg_dB = 0
#                 ret = True
#             else:
#                 ret = False
#         else:
#             if pop.bg_dB >= 0:
#                 pop.bg_dB = 0
#                 ret = True
#             else:
#                 ret = False

#         if self.v_T < 0:
#             if pop.bg_dT <= 0:
#                 pop.bg_dT = 0
#                 ret = ret and True
#             else:
#                 ret = False
#         else:
#             if pop.bg_dT >= 0:
#                 pop.bg_dT = 0
#                 ret = ret and True
#             else:
#                 ret = False

#         bg = pop.bg
#         bg.upd_bat(bg.L, bg.R, bg.B + pop.bg_dB, bg.T + pop.bg_dT)
#         if ret:
#             self.host.tm_pop_dxy_fn = self.host.tm_pop.dxy_upd
#             return True
#         else:
#             return False

class AN_sci:
    __slots__ = "des", "v"
    def __init__(self, des, v):
        self.des    = des
        self.v      = v

    def fn(self, sci):
        sci.h += self.v
        sci.y -= self.v
        if sci.h >= self.des:
            sci.y   += sci.h - self.des
            sci.h   = self.des
            return True
        return False