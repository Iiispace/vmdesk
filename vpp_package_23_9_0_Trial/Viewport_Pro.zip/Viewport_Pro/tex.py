import bpy
from blf import size as blf_size
from . import m, win, bu, dd
from . props import EDITOR

P = None
F = None
K = None
N = None
BOX = None
BLF = None
font_0 = None
BLEND = None

class OP_TEX(EDITOR):
    __slots__ = ()
    bl_idname = "wm.tx_editor_operator"
    bl_label = "Text Editor"

    def R_cls(self): return TEX


class TEX(win.WIN):
    __slots__ = (

    )
    name = "Text Editor"
    W = []
    IND = []

    def init_D1(self):
        c = self.color
        c.font = P.color_font

        self.bo = {

        }
        self.ti = {
            "temp":     BLF(c.font, text = "In develop..."),
        }
        self.da = {

        }

        self.I_upd_data = N

        def get_first_win():
            self.tit["ti"].text = TEX.name
            self.tit["ti"].ind  = 1
        def get_after_win(i):
            self.tit["ti"].text = f"{TEX.name }{i}"
            self.tit["ti"].ind  = i

        TEX.get_win(get_first_win, get_after_win)
        self.upd_data = self.I_upd_data

# ▅▅▅  GET BO                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def get_bo_main(self):
        bo  = self.bo
        ti  = self.ti
        da  = self.da
        box = self.box
        L   = box["main"].L
        T   = box["main"].T

        ti["temp"].x    = L + F[4]
        ti["temp"].y    = T - F[12]
# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def modal_main_area(self, evt):
        return False


# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def draw_main(self):
        blf_size(font_0, F[38])
        self.ti["temp"].set_color()     ;self.ti["temp"].draw_pos()

# ▅▅▅  UPD DATA                    ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅


class TEX_EDIT(dd.DDTX): # head_modal
    __slots__ = (
        'attr',
        'oo',
        'RET',
    )
    def __init__(self, w, evt, attr, target, tx = None):

        x   = evt.mouse_region_x
        y   = evt.mouse_region_y

        self.w      = w
        self.attr   = attr

        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.U_draw_cursor  = self.I_draw_cursor
        self.U_sw_cursor    = self.I_sw_cursor_on
        self.cursor_time    = P.cursor_flash_rate

        bo_cursor           = BOX(P.color_tx_cursor)
        self.bo_cursor      = bo_cursor

        bo = {
            "bg":           BOX(P.color_tex_bg),
            "main":         BOX(P.color_tex_main),
            "tx":           BOX(P.color_bu_3_on),
            "fil":          BOX(P.color_filter),
            "highlight":    BOX(P.color_tx_sel),
        }
        self.bo = bo

        ti = {
            "ti":           BLF(P.color_font, "Data Editor"),
            "target":       BLF(P.color_font, f"Target :  {target}"),
            "info":         BLF(P.color_font,
                "Warning :  Accept will save all setting in Preferences"),
        }
        self.ti = ti

        if tx is None:  tx = getattr(*attr)
        da = {
            "tx":       BLF(P.color_font, tx)
        }
        self.da = da

        self.sci        = m.SCISSOR()
        self.sci_tx     = m.SCISSOR()
        oo = {
            "accept":   bu.BURE(self, "accept", "Accept", self.bu_fn_accept,
                base_evt = self.base_evt),
            "cancel":   bu.BURE(self, "cancel", "Cancel", self.fin,
                base_evt = self.base_evt),
        }
        self.oo = oo

        m.admin.tb.draw_top.append(self)
        m.head_modal.append(self.run_modal)

        _1          = F[1]
        _2          = F[2]
        bo_bg       = bo["bg"]

        bo_bg.LRBT(x - F[150], x + F[150], y - F[52], y + F[52])
        L   = bo_bg.L + _2
        R   = bo_bg.R - _2
        T   = bo_bg.T - F[22]
        bo["tx"].LRBT(L, R, T - F[16], T)
        self.sci_tx.box_round(bo["tx"])
        bo["main"].LRBT(L, R, bo_bg.B + _2, bo["tx"].B - _2)
        self.sci.box_round(bo["main"])
        ti["ti"].x = L + F[5]
        ti["ti"].y = bo_bg.T - F[15]
        da["tx"].LB(bo["tx"], F[5], F[4])
        ti["target"].x, ti["target"].y = ti["ti"].x, bo["tx"].B - F[14]
        ti["info"].x, ti["info"].y = ti["ti"].x, ti["target"].y - F[14]
        buB = bo_bg.B + F[9]
        buT = buB + F[16]
        buL = L + F[61]
        blf_size(font_0, F[9])
        oo["accept"].LRBT(buL, buL + F[46], buB, buT)
        buR = R - F[61]
        oo["cancel"].LRBT(buR - F[46], buR, buB, buT)

        bo_cursor.B         = bo["tx"].B + _1
        bo_cursor.T         = bo["tx"].T - _1
        self.bo_cursor_wi   = F[P.cursor_thickness]
        bo["highlight"].B   = bo_cursor.B + _1 
        bo["highlight"].T   = bo_cursor.T - _1

        ll = len(da["tx"].text)
        if P.auto_sel_text:     self.set_highlight(0, ll)
        else:                   self.set_highlight(ll, ll)

        if P.win_shade_on:
            bo["shade"] = m.SHADE(P.win_shade_color)
            bo["shade"].get_by_rim(
                bo_bg.L, bo_bg.R, bo_bg.B, bo_bg.T,
                P.win_shade_softness, P.win_shade_offset, P.scale[0]
            )
        else:   bo["shade"] = m.BOX_FAKE()

        for e in bo.values():  e.upd()

        self.thread_cursor  = self.I_thread_cursor
        self.thread_copy    = self.I_thread_tx_copy
        self.I_init_thread_cursor()
        self.tx_limL        = da["tx"].x
        self.bo_tx_Rm4      = bo["tx"].R - F[4]
        self.calc_tx_lim()
        if self.tx_limL != self.tx_limR:
            self.dxi0 = bo["highlight"].L - da["tx"].x
            self.dxi1 = bo["highlight"].R - da["tx"].x
            da["tx"].x = self.tx_limR
            self.upd_highlight()

        self.th_auto_L  = bo["tx"].L + F[4]
        self.th_auto_R  = bo["tx"].R - F[4]
        if bo["tx"].inbox(evt):     m.M.set_mou_ic('TEXT')
        self.init_li    = N
        self.upd_fil    = N

        dx, dy = m.R_protect_dxy_LT(bo_bg, F[-1])
        if dx == 0 and dy == 0: pass
        else:   self.dxy_upd(dx, dy)

        m.init_wait_release()
        m.redraw()

    def fin(self):

        del m.head_modal[-1]
        m.admin.tb.draw_top.remove(self)
        self.U_kill_thread_cursor()
        m.M.set_mou_ic('DEFAULT')
        m.init_wait_release()
        m.redraw()

# ▅▅▅  FN                          ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def dxy_upd(self, x, y):
        for e in self.bo.values():  e.dxy_upd(x, y)
        for e in self.ti.values():  e.dxy(x, y)
        for e in self.oo.values():  e.dxy_upd(x, y)
        self.bo_cursor.dxy_upd(x, y)
        self.da["tx"].dxy(x, y)
        self.sci.dxy(x, y)
        self.sci_tx.dxy(x, y)

    def bu_fn_accept(self):

        setattr(*self.attr, self.da["tx"].text)
        bpy.ops.wm.save_userpref()
        self.w.U_modal(None)
        self.fin()
# ▅▅▅  MODAL                       ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_modal_main(self, evt):
        if self.bo["bg"].inbox(evt) == False:
            if K["tex_cancel0"].true():  self.fin()  ;return
            if K["tex_cancel1"].true():  self.fin()  ;return
            if K["sel0"].true() or K["sel1"].true():

                return
            self.unicode_evt(evt)
            return

        if self.bo["tx"].inbox(evt):
            m.M.set_mou_ic('TEXT')
            self.U_modal = self.I_modal_tx
            self.I_modal_tx(evt)
            return

        if evt.mouse_region_y > self.bo["tx"].T:
            if K["tex_cancel0"].true():  self.fin()  ;return
            if K["tex_cancel1"].true():  self.fin()  ;return
            if K["ti_mov0"].true():
                self.key_end = K["ti_mov_E0"]
                self.key_end.true()
                self.to_modal_mov(evt)
                return
            if K["ti_mov1"].true():
                self.key_end = K["ti_mov_E1"]
                self.key_end.true()
                self.to_modal_mov(evt)
                return
            self.unicode_evt(evt)
            return

        if K["tex_cancel0"].true():  self.fin()  ;return
        if K["tex_cancel1"].true():  self.fin()  ;return

        for e in self.oo.values():
            if e.rim.inbox(evt):    e.inside(evt)  ;return

        self.unicode_evt(evt)

    def I_modal_tx(self, evt):
        if self.bo["tx"].inbox(evt) == False:
            m.M.set_mou_ic('DEFAULT')
            self.U_modal = self.I_modal_main
            self.I_modal_main(evt)
            return

        if K["tex_cancel0"].true():  self.fin()  ;return
        if K["tex_cancel1"].true():  self.fin()  ;return

        self.unicode_evt(evt)

    def base_evt(self, evt):
        if K["tex_cancel0"].true():  self.fin()  ;return True
        if K["tex_cancel1"].true():  self.fin()  ;return True
        return False

    def to_modal_mov(self, evt):

        m.head_modal.append(self.I_modal_mov)
        self.U_modal = N
        m.get_mou(evt)
    def protect_pos(self):
        new_x, new_y = m.UR_protect_pos(self.bo["bg"], F[-1])
        dx = new_x - self.bo["bg"].L
        dy = new_y - self.bo["bg"].T
        if dx == 0 and dy == 0: return
        self.dxy_upd(dx, dy)
    def modal_mov_end(self):

        del m.head_modal[-1]
        self.protect_pos()

        bo  = self.bo

        self.th_auto_L  = bo["tx"].L + F[4]
        self.th_auto_R  = bo["tx"].R - F[4]
        self.tx_limL    = self.da["tx"].x
        self.bo_tx_Rm4  = bo["tx"].R - F[4]
        self.calc_tx_lim()

        self.U_modal    = self.I_modal_main
        m.EVT.kill()
        m.EVT.U_ENABLE_evt()
        m.redraw()
    def I_modal_mov(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_mov_end()
                return
        m.dx = evt.mouse_x - m.mou_x
        m.dy = evt.mouse_y - m.mou_y
        self.dxy_upd(m.dx, m.dy)
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()
# ▅▅▅  DRAW                        ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
    def I_draw(self):
        BLEND()
        bo = self.bo
        ti = self.ti
        da = self.da
        oo = self.oo

        bo["shade"].draw()
        bo["bg"].bind_draw()                ;bo["tx"].bind_draw()
        bo["main"].bind_draw()
        m.bind_color_bu_1_rim()
        for e in oo.values():   e.draw_rim()
        for e in oo.values():   e.draw_bg()

        self.sci_tx.ENABLE()
        bo["highlight"].bind_draw()         ;self.U_draw_cursor()

        blf_size(font_0, F[9])
        da["tx"].draw_color_pos()
        self.sci_tx.DISABLE()

        for e in oo.values():   e.draw_ti()

        blf_size(font_0, F[12])
        ti["ti"].draw_color_pos()

        blf_size(font_0, F[9])
        ti["target"].draw_color_pos()
        ti["info"].draw_color_pos()
# ▅▅▅  THREAD                      ▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅▅
