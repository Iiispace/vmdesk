from . import m
from blf import size as blf_size
from blf import color as blf_color

P = None
F = None
K = None
font_0 = None
BLEND = None

class MOVE_FULL_PROTECT:
    __slots__ = ()
    def to_modal_mov(self, evt):
        self.key_end.true()
        m.head_modal.append(self.I_modal_mov)
        m.get_mou(evt)
    def modal_mov_end_D1(self): pass
    def modal_mov_end(self):

        del m.head_modal[-1]
        r = self.bo["rim"]
        dx, dy = m.R_full_protect_dxy(r.L, r.R, r.B, r.T)
        if dx or dy:    self.dxy_upd(dx, dy)

        m.EVT.kill()
        m.redraw()
        self.modal_mov_end_D1()
    def I_modal_mov(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_mov_end()
                return
        if K["cancel0"].true() or K["cancel1"].true():
            self.modal_mov_end()
            return

        m.dx    = evt.mouse_x - m.mou_x
        m.dy    = evt.mouse_y - m.mou_y
        self.dxy_upd(m.dx, m.dy)
        m.mou_x = evt.mouse_x
        m.mou_y = evt.mouse_y
        m.redraw()

class FLASH:
    __slots__ = ()
    def do_flash(self):
        if m.thread_isreg(m.flash_box_thread_fn):   return
        r = self.bo["rim"]
        m.FLASH_BOX.init(r.L, r.R, r.B, r.T)

class OO_FO:
    __slots__ = 'oo_fo'
    def unfocus(self):
        if self.oo_fo is not None:
            self.oo_fo.unfocus()
            self.oo_fo = None
            m.redraw()
    def focus_check(self, evt, fo):
        if self.oo_fo is None:
            fo.focus()
            self.oo_fo = fo
            m.redraw()
        elif self.oo_fo != fo:
            self.oo_fo.unfocus()
            fo.focus()
            self.oo_fo = fo
            m.redraw()
        elif evt.value == 'RELEASE':
            if hasattr(fo, "is_allow"): fo.is_allow = True


class A_DATA_PAN:
    __slots__ = (
        'tm_L',
        'tm_R',
        'tm_B',
        'tm_T',
        'tm_pan_h',
        'tm_1',
    )
    def to_modal_pan(self, evt):

        m.redraw()

        _1 = F[1]
        sci = self.sci
        self.tm_L = sci.x + _1
        self.tm_R = sci.x + sci.w - _1
        self.tm_T = sci.y + sci.h - _1
        self.tm_B = sci.y + _1
        self.tm_pan_h = self.li_h > self.tm_T - self.tm_B
        self.tm_1 = _1

        self.key_end.true()
        m.head_modal.append(self.I_modal_pan)
        m.U_pan_cursor(self, evt)
        rim = self.w.resize_rim
        m.get_loop_mou_info_region(evt, rim.L, rim.R, rim.B, rim.T)
        m.get_mou(evt)
    def modal_pan_end(self):

        del m.head_modal[-1]
        m.U_end_pan(self)
        m.init_wait_release()
        self.w.I_upd_data()
        m.redraw()
    def I_modal_pan(self, evt):
        if self.key_end.true():
            if self.key_end.value != 'PRESS' or evt.value == 'PRESS':
                self.modal_pan_end()
                return
        m.U_pan(evt)

        dx = m.dx
        dy = m.dy
        li = self.li
        bo0 = li[self.headkey].rim

        if dx < 0:
            R = bo0.R + dx
            if R < self.tm_R:   dx -= R - self.tm_R
        else:
            L = bo0.L + dx
            if L > self.tm_L:   dx -= L - self.tm_L

        if dy < 0:
            headkey = self.headkey
            T = bo0.T + dy
            if headkey == 0:
                if T < self.tm_T:   dy -= T - self.tm_T
            else:
                tm_T = self.tm_T
                if T < tm_T:
                    oo = self.oo
                    endkey = self.endkey
                    L = bo0.L
                    R = bo0.R
                    _1 = self.tm_1

                    while headkey != 0:


                        blf_size(font_0, F[9])
                        B = li[headkey].rim.T + _1
                        headkey -= 1
                        e = oo[headkey]
                        e.get_bo(L, R, B + e.hi)
                        # for o in e.oo:  o.da_upd()
                        li[headkey] = e
                        T += e.hi + _1
                        if T >= tm_T:   break

                    if headkey == 0:
                        T = li[headkey].rim.T + dy
                        if T < tm_T:    dy -= T - tm_T

                    T0 = li[endkey].rim.T + dy
                    while T0 < self.tm_B:


                        del li[endkey]
                        endkey -= 1
                        T0 = li[endkey].rim.T + dy

                    self.headkey = headkey
                    self.endkey = endkey
                    self.w.I_upd_data()

        elif self.tm_pan_h:
            endkey = self.endkey
            bo1 = li[endkey].rim
            B = bo1.B + dy
            if endkey == self.max_ind:
                if B > self.tm_B:   dy -= B - self.tm_B
            else:
                tm_B = self.tm_B
                if B > tm_B:
                    oo = self.oo
                    headkey = self.headkey
                    max_ind = self.max_ind
                    L = bo1.L
                    R = bo1.R
                    _1 = self.tm_1

                    while endkey != max_ind:


                        blf_size(font_0, F[9])
                        T = li[endkey].rim.B - _1
                        endkey += 1
                        e = oo[endkey]
                        e.get_bo(L, R, T)
                        # for o in e.oo:  o.da_upd()
                        li[endkey] = e
                        B -= e.hi + _1
                        if B <= tm_B:   break

                    if endkey == max_ind:
                        B = li[endkey].rim.B + dy
                        if B > tm_B:    dy -= B - tm_B

                    B0 = bo0.B + dy
                    while B0 > self.tm_T:


                        del li[headkey]
                        headkey += 1
                        B0 = li[headkey].rim.B + dy

                    self.headkey = headkey
                    self.endkey = endkey
                    self.w.I_upd_data()

        else:
            dy = 0

        for e in li.values():  e.dxy(dx, dy)

        m.loop_mou(evt)
        m.redraw()

    def fix_pan(self):
        li = self.li
        sci = self.sci
        _1 = F[1]
        dx = 0
        dy = 0
        rim = li[self.headkey].rim
        if rim.T < sci.R_T() - _1:
            tm_T = sci.R_T() - _1
            oo = self.oo
            headkey = self.headkey
            L = rim.L
            R = rim.R
            while headkey != 0:
                B = li[headkey].rim.T + _1
                headkey -= 1
                e = oo[headkey]
                e.get_bo(L, R, B + e.hi)
                li[headkey] = e
                if e.rim.T >= tm_T: break

            if li[headkey].rim.T < tm_T:
                dy = tm_T - li[headkey].rim.T

            B = li[self.endkey].rim.B + dy
            if B > sci.y + _1:
                tm_B = sci.y + _1
                endkey = self.endkey
                max_ind = self.max_ind
                while endkey != max_ind:
                    T = li[endkey].rim.B - _1
                    endkey += 1
                    e = oo[endkey]
                    e.get_bo(L, R, T)
                    li[endkey] = e
                    B -= e.hi + _1
                    if B <= tm_B: break
                self.endkey = endkey

            self.headkey = headkey

        elif li[self.endkey].rim.B > sci.y + _1:
            tm_B = sci.y + _1
            oo = self.oo
            endkey = self.endkey
            L = rim.L
            R = rim.R
            max_ind = self.max_ind
            while endkey != max_ind:
                T = li[endkey].rim.B - _1
                endkey += 1
                e = oo[endkey]
                e.get_bo(L, R, T)
                li[endkey] = e
                if e.rim.B <= tm_B: break

            B = li[endkey].rim.B
            if B > tm_B:
                dy = tm_B - B
                headkey = self.headkey
                e = oo[headkey]
                T = rim.T + dy
                if T < sci.R_T() - _1:
                    tm_T = sci.R_T() - _1
                    while headkey != 0:
                        T += e.hi + _1
                        headkey -= 1
                        e = oo[headkey]
                        e.get_bo(L, R, T)
                        if T >= tm_T:   break

                    self.headkey = headkey

                    if T < tm_T:    dy += tm_T - T

            self.endkey = endkey


        if rim.L > sci.x + _1:          dx = sci.x + 1 - rim.L
        elif rim.R < sci.R_R() - _1:    dx = sci.R_R() - _1 - rim.R

        if dx or dy:
            for e in li.values():   e.dxy(dx, dy)

class AREA(A_DATA_PAN):
    __slots__ = (
        'w',
        'RET',
        'U_draw',
        'U_modal',
        'default_modal',
        'sci',
        'oo',
        'li',
        'max_ind',
        'headkey',
        'endkey',
        'key_end',
        'oo_keys',
        # 'description_wi',
        'ref_L',
        'ref_R',
        'hi',
        'li_h',
    )
    def get_data(self): pass
    def upd_data(self): pass
    def R_bo_data(self): return self.w.bo["data"]
    def __init__(self, w, upd=True):
        self.w              = w
        self.RET            = False
        self.U_draw         = self.I_draw
        self.U_modal        = self.I_modal_main
        self.default_modal  = self.I_modal_main
        self.sci            = m.SCISSOR()
        self.upd_sci()

        blf_size(font_0, F[9])
        self.get_data()
        self.init_oo()

        li = {}
        self.li = li

        bo_data = self.R_bo_data()
        _1 = F[1]

        L = bo_data.L + _1
        R = bo_data.R - _1
        T = bo_data.T - _1
        self.ref_L = L
        self.ref_R = R

        hi_max = bo_data.R_h()
        self.hi = hi_max
        hi = _1
        oo = self.oo
        for r in range(len(oo)):
            # /* 0win_cls_AREA_for_li
            e = oo[r]
            e.get_bo(L, R, T)
            li[r] = e
            hi += e.hi + _1
            if hi >= hi_max:    break
            T = e.rim.B - _1
            # */

        self.li_h = hi - _1 - _1
        self.max_ind = len(oo) - 1
        self.headkey = 0
        self.endkey = r

        if upd: self.upd_data()
    def init_oo(self):
        self.oo = {r: e  for r, e in enumerate(self.oo_keys)}

    def get_bo_from_head(self):
        oo = self.oo
        li = self.li
        hi_max = self.hi
        rim = li[self.headkey].rim
        T = rim.T
        L = rim.L
        R = rim.R
        li.clear()
        _1 = F[1]
        hi = _1

        for r in range(self.headkey, len(oo)):
            # <<< 1copy (0win_cls_AREA_for_li,, $$)
            e = oo[r]
            e.get_bo(L, R, T)
            li[r] = e
            hi += e.hi + _1
            if hi >= hi_max:    break
            T = e.rim.B - _1
            # >>>
        self.endkey = r
        self.upd_data()
    def R_li_hi(self):
        hi = 0
        _1 = F[1]
        for e in self.li.values():
            hi += e.hi + _1
        return hi - _1
    def dxy_upd(self, x, y):
        for e in self.li.values():  e.dxy(x, y)

        self.upd_sci()
    def upd_sci(self):
        sci         = self.sci
        wsci        = self.w.sci
        L, R, B, T  = self.R_bo_data().R_LRBT()
        sci.x       = max(L, wsci.x)
        sci.w       = max(0, min(R, wsci.x + wsci.w) - sci.x)
        sci.y       = max(B, wsci.y)
        sci.h       = max(0, min(T, wsci.y + wsci.h) - sci.y)
    def unfocus(self):
        if self.U_modal == self.default_modal: return
        self.U_modal.__self__.outside()
        self.U_modal = self.default_modal


    def I_modal_main(self, evt):
        y = evt.mouse_region_y

        if K["pan0"].true():
            self.key_end = K["pan_E0"]
            self.to_modal_pan(evt)
            return True
        if K["pan1"].true():
            self.key_end = K["pan_E1"]
            self.to_modal_pan(evt)
            return True

        for e in self.li.values():
            if e.rim.in_BT_y(y):
                return e.I_modal_main(evt)
        self.unfocus()
        return False

    def I_draw(self):
        BLEND()
        self.sci.use()
        values = self.li.values()

        for e in values:    e.draw_box()

        blf_size(font_0, F[9])
        blf_color(font_0, *P.color_font)
        for e in values:    e.draw_blf()